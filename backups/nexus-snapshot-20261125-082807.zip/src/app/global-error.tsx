"use client";

// ── NEXUS//SIGNALS — GLOBAL-ERROR AUTO-RECOVERY (trace 1a1fdf2796033005) ────
// Post-reset recovery audit (2026-11-21): the sanctioned steady-state on this
// 4GB dev sandbox is a CONTROLLED recycle every few minutes (ram-shed lanes →
// rc=0 exit → heal chain respawn ≤45s). During every recycle the open browser
// tab hits Turbopack ChunkLoadError → Next's default screen froze the console
// on "Application error" until the operator manually reloaded — that freeze
// IS the «داشبورد ناپایدار» experience, not an engine failure.
//
// This boundary replaces that dead screen with an honest terminal panel:
// countdown auto-reload lands on the healthy server once the heal chain
// finishes (≤45s warm-cache contract), with a treadmill guard (≤3 auto-reloads
// per 90s window) so a genuinely dead backend never loops the browser.
// Never logs or echoes secrets — only the public digest.

import { useEffect, useRef, useState } from "react";
import "./globals.css";

const GUARD_KEY = "nexus-err-reload-ring";
const RING_WINDOW_MS = 90_000;
const MAX_AUTO_RELOADS = 3;
const COUNTDOWN_START = 8;

function registerReloadRing(): number[] {
  try {
    const now = Date.now();
    const arr: number[] = JSON.parse(
      sessionStorage.getItem(GUARD_KEY) ?? "[]"
    ).filter((t: number) => now - t < RING_WINDOW_MS);
    arr.push(now);
    sessionStorage.setItem(GUARD_KEY, JSON.stringify(arr));
    return arr;
  } catch {
    // sessionStorage unavailable (private mode) — treat as first attempt
    return [Date.now()];
  }
}

export default function GlobalError({
  error,
}: {
  error: Error & { digest?: string };
}) {
  const [ui, setUi] = useState({ countdown: COUNTDOWN_START, ringLen: 0 });
  const countdownRef = useRef(COUNTDOWN_START);

  useEffect(() => {
    console.error("[nexus-global-error]", error?.digest ?? error?.message);
    const ring = registerReloadRing();
    const t = setInterval(() => {
      const c = countdownRef.current - 1;
      countdownRef.current = c;
      setUi({ countdown: c, ringLen: ring.length });
      if (c <= 0 && ring.length <= MAX_AUTO_RELOADS) window.location.reload();
    }, 1_000);
    return () => clearInterval(t);
  }, [error]);

  const autoDisabled = ui.ringLen > MAX_AUTO_RELOADS;
  const pct = Math.max(
    0,
    Math.min(
      100,
      ((COUNTDOWN_START - Math.max(0, ui.countdown)) / COUNTDOWN_START) * 100
    )
  );

  return (
    <html lang="en">
      <body
        style={{
          background: "#05070a",
          color: "#e6f7ef",
          fontFamily: "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace",
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "24px",
          margin: 0,
        }}
      >
        <main
          aria-live="polite"
          style={{
            width: "min(560px, 100%)",
            border: "1px solid rgba(0,255,163,0.25)",
            borderRadius: "12px",
            padding: "28px 24px",
            background: "rgba(0,255,163,0.03)",
          }}
        >
          <p style={{ margin: 0, fontSize: 12, letterSpacing: "0.18em", color: "rgba(0,255,163,0.85)" }}>
            NEXUS//SIGNALS
          </p>
          <h1 style={{ margin: "10px 0 6px", fontSize: 20, fontWeight: 700 }}>
            UPLINK INTERRUPTED — CONTROLLED RECYCLE
          </h1>
          <p style={{ margin: 0, fontSize: 13, lineHeight: 1.7, color: "rgba(230,247,239,0.78)" }}>
            The engine process is cycling through its sanctioned memory-defense
            chain (ram-shed → heal respawn ≤45s). This tab re-arms itself on the
            healthy server automatically — no data was lost; the outbox sweeper
            replays any card cut mid-send.
          </p>
          {error?.digest ? (
            <p style={{ margin: "12px 0 0", fontSize: 11, color: "rgba(230,247,239,0.45)" }}>
              digest {error.digest}
            </p>
          ) : null}

          {!autoDisabled ? (
            <>
              <div
                role="progressbar"
                aria-label="Auto-reload countdown"
                aria-valuenow={pct}
                aria-valuemin={0}
                aria-valuemax={100}
                style={{
                  marginTop: 18,
                  height: 4,
                  borderRadius: 4,
                  background: "rgba(0,255,163,0.12)",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    width: `${pct}%`,
                    height: "100%",
                    background: "#00ffa3",
                    transition: "width 1s linear",
                  }}
                />
              </div>
              <p style={{ margin: "10px 0 0", fontSize: 12, color: "rgba(230,247,239,0.65)" }}>
                auto-reload in {Math.max(0, ui.countdown)}s · attempt {ui.ringLen}/{MAX_AUTO_RELOADS}
              </p>
            </>
          ) : (
            <p style={{ margin: "18px 0 0", fontSize: 12, color: "#ffb347" }}>
              AUTO-RELOAD PAUSED — backend has not healed within the window.
              Press Ctrl+R (⌘R) when the stack is back.
            </p>
          )}

          <button
            onClick={() => window.location.reload()}
            style={{
              marginTop: 20,
              padding: "10px 18px",
              fontSize: 12,
              letterSpacing: "0.12em",
              color: "#05070a",
              background: "#00ffa3",
              border: "none",
              borderRadius: 6,
              cursor: "pointer",
              fontWeight: 700,
            }}
          >
            RETRY NOW
          </button>
        </main>
        <footer style={{ marginTop: 18, fontSize: 11, color: "rgba(230,247,239,0.4)" }}>
          FLOWRADAR//NEO · RESEARCH TERMINAL · NOT FINANCIAL ADVICE
        </footer>
      </body>
    </html>
  );
}
