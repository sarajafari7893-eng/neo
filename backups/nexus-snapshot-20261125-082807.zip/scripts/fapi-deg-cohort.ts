// ── FAPI-DEG vs clean-cohort WR comparison — trace 1a1ba99d0cb24dd9 (2026-11-19) ──
// Operator order: «توصیه‌های پیشنهادی را کامل ومهندسی اجرا کن» — instrument the
// DEGRADED-CAPTURE quality question: do signals issued during fapi-ban windows
// (tagged FAPI-DEG by raw-cal v14.4) perform differently from clean-cohort ones?
//
// Run:  bun scripts/fapi-deg-cohort.ts [windowHours]
//       (default window = all-time; pass e.g. 168 for the last 7 days)
//
// Verdict doctrine (honesty-over-volume): a difference is only reported when the
// degraded cohort has >= MIN_SAMPLE settles; below that the script says so and
// keeps accumulating. The ~50-settle evaluation target: at 50+ FAPI-DEG settles
// the WR delta becomes decision-grade for the degraded-capture policy.
//
// Read-only on db/custom.db — safe to run any time, also from cron.

import { Database } from "bun:sqlite";

const MIN_SAMPLE = 50; // decision-grade sample per the operator's ~50-settle plan
const windowHours = Number(process.argv[2] ?? 0);
const windowMs = windowHours > 0 ? windowHours * 3600_000 : null;

const db = new Database("/home/z/my-project/db/custom.db", { readonly: true });
const rows = db
  .query(
    `SELECT serial, symbol, direction, strategy, status, tags, pnlPercent, marginUsd, createdAt
     FROM Signal
     WHERE status IN ('SL','EXPIRED','TP3','CLOSED','VOID')`
  )
  .all() as Array<{
  serial: number; symbol: string; direction: string; strategy: string;
  status: string; tags: string | null; pnlPercent: number | null; marginUsd: number | null; createdAt: number;
}>;
db.close();

const settled = windowMs ? rows.filter((r) => Number(r.createdAt) >= Date.now() - windowMs) : rows;
const usd = (r: (typeof rows)[number]) => ((r.marginUsd ?? 0) * (r.pnlPercent ?? 0)) / 100;
const wr = (a: typeof rows) => (a.length ? (100 * a.filter((r) => (r.pnlPercent ?? 0) > 0).length) / a.length : 0);
const sum = (a: typeof rows) => Math.round(a.reduce((s, r) => s + usd(r), 0) * 100) / 100;

const deg = settled.filter((r) => String(r.tags ?? "").includes("FAPI-DEG"));
const clean = settled.filter((r) => !String(r.tags ?? "").includes("FAPI-DEG"));

const fmt = (label: string, a: typeof rows) =>
  `${label.padEnd(10)} n=${String(a.length).padStart(5)}  WR=${wr(a).toFixed(1)}%  $PnL=${sum(a) >= 0 ? "+" : ""}${sum(a)}  avgTrade=${a.length ? ((sum(a)) / a.length).toFixed(3) : "0.000"}`;

console.log(`FAPI-DEG vs clean cohort — settled ledger${windowMs ? ` (last ${windowHours}h)` : " (all-time)"} · ${new Date().toISOString()}`);
console.log(fmt("FAPI-DEG", deg));
console.log(fmt("clean", clean));
if (deg.length && clean.length) {
  console.log(`WR delta: ${(wr(deg) - wr(clean)).toFixed(1)}pp · avgTrade delta: ${((sum(deg) / deg.length) - (sum(clean) / clean.length)).toFixed(3)}$/trade`);
}
console.log(`decision-grade sample: ${deg.length >= MIN_SAMPLE ? "YES" : `NO — ${deg.length}/${MIN_SAMPLE} FAPI-DEG settles accumulated`}`);
// per-strategy split for the degraded cohort (which lanes run during bans)
const byStrat: Record<string, number> = {};
for (const r of deg) byStrat[r.strategy] = (byStrat[r.strategy] ?? 0) + 1;
console.log("FAPI-DEG by strategy:", JSON.stringify(byStrat));
