var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/src_lib_08d5c02e._.js")
R.c("server/chunks/[root-of-the-server]__0bb7d6e3._.js")
R.m("[project]/src/instrumentation.ts [instrumentation] (ecmascript)")
module.exports=R.m("[project]/src/instrumentation.ts [instrumentation] (ecmascript)").exports
