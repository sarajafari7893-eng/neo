module.exports = [
"[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_d2d68b55._.js",
  "server/chunks/[root-of-the-server]__ba7bb8ea._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ebed90ed._.js",
  "server/chunks/src_lib_engine_ts_a868ea96._.js",
  "server/chunks/src_lib_99e156e4._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__8d16f881._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/engine.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/notify.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__657bae63._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/notify.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/shadow-veto.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__92ea5ce4._.js",
  "server/chunks/[root-of-the-server]__448f0d4e._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/shadow-veto.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/calibration.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_7e3fb435._.js",
  "server/chunks/[root-of-the-server]__d5cdc743._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/calibration.ts [instrumentation] (ecmascript)");
    });
});
}),
];