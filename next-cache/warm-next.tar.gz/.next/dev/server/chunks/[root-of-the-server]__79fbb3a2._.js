module.exports = [
"[project]/src/lib/db.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "configureFapiGate",
    ()=>configureFapiGate,
    "effectiveBudgetPer60s",
    ()=>effectiveBudgetPer60s,
    "fapiBanActivity",
    ()=>fapiBanActivity,
    "fapiBanRemainingMs",
    ()=>fapiBanRemainingMs,
    "fapiEgressStatus",
    ()=>fapiEgressStatus,
    "fapiGateStats",
    ()=>fapiGateStats,
    "gateFetch",
    ()=>gateFetch,
    "isUnknownScopeKey",
    ()=>isUnknownScopeKey,
    "sampleEgressIp",
    ()=>sampleEgressIp
]);
// ── NEXUS//SIGNALS FAPI GATE (server-only, v10.24 — Task 34-a) ──────────────
// Process-wide WEIGHT-BASED token bucket for Binance USDT-M futures REST
// (fapi.binance.com). WHY: 9+ modules in the Next.js process each did their own
// uncoordinated fetch() to the same host and the trade mini-service added
// ~1800 weight/min on top → Binance answered with HTTP 418 IP-bans carrying
// stacked multi-hour "banned until <ms>" windows. This gate is the single
// choke-point every futures-REST call in THIS process must pass:
//
//   · WEIGHT BUDGET — rolling-60s sliding window, default 1100 weight/min
//     (fapi real limit is 2400/min per IP; ~2× headroom absorbs drift between
//     weight estimates and the ungated mini-service until Task 34-b).
//   · LANES — "critical" (engine price feed, trigger measurements) executes
//     immediately when tokens exist, with ONE small negative retry after
//     250ms when momentarily empty; "telemetry" (every rotating scanner/
//     sampler/board) is DROPPED (returns null) when tokens are missing —
//     no unbounded queues, no storm amplification. All callers are
//     null-tolerant by contract.
//   · GLOBAL BAN AWARENESS (refined for the multi-IP egress pool — measured
//     2026-09-26: the sandbox egress rotates across several IPs and Binance's
//     418 body NAMES the banned one: «IP(47.57.x.x) banned until <ms>», with
//     different pool IPs banned in different windows):
//       – 418/429 body naming an IP → PER-IP ban record (capped now+35min),
//         the request's weight is REFUNDED (ban responses carry no weight
//         cost) and the call RETRIES (≤2, 120ms apart) — the pool usually
//         rotates onto a clean IP, so one unlucky draw never starves the app.
//       – ALL retries land on banned IPs → one unlucky draw too many: arm a
//         SHORT 60s global block, and only when that happens 3 times IN A ROW
//         (no successful call between) treat the pool as saturated and arm the
//         full zero-network window min(worst ban end, now+35min). A single
//         clean 2xx resets the streak — self-healing probes.
//       – 418/429 body WITHOUT a parseable IP (unknown scope — the classic
//         single-IP case): arm the global zero-network window immediately —
//         "banned until X" → min(X, now+35min); unparseable 418 → 10min;
//         unparseable 429 → 2min.
//       – While the global window is live, gateFetch returns null INSTANTLY —
//         zero network calls, so a live ban can never be extended by us.
//   · SINGLE-FLIGHT — one shared request per (host,path) while in flight and
//     for a 2s result window, so multiple modules asking the same endpoint
//     inside one tick share one weight spend.
//   · HOST AWARENESS — default host fapi.binance.com, optional alt host
//     (fapi1) for the market-feed availability ladder; bans/weight are
//     per-IP so both hosts share the SAME budget and ban state.
//
// NEVER THROWS: gateFetch returns parsed JSON or null on any failure.
// State lives on globalThis so Turbopack's dev module-graph duplication
// (route graph vs engine graph) still shares ONE process-wide bucket.
//
// SPOT (api.binance.com) and mirror-plane hosts (v14.0 Binance-only) must
// NOT pass through here — futures fapi host only.
//
// ── v12.0 EGRESS/IP MANAGER (Task 44-②, operator order «مدیریت egress/IP
// برای رفع بن fapi») ──────────────────────────────────────────────────────────
// Measured 2026-10-18: the sandbox egress is a rotating NAT pool and Binance
// bans POOL IPs with LONG windows (three named IPs banned until 10-18 19:47Z /
// 22:37Z / 10-19 13:26Z — each plain request is a lottery draw). Three new
// weapons:
//   1. EGRESS SAMPLER — api.ipify.org probe (3.5s timeout, 120s cache,
//      single-flight, never throws) tells us WHICH pool IP a draw exited from.
//   2. ROTATION-AWARE EARLY PROBE — while a global ban window is live, ONE
//      critical-lane call per 120s may bypass the silence IF the sampled IP is
//      clean: the moment the pool rotates, the window LIFTS instantly instead
//      of waiting out the 35min cap. A failed probe costs nothing (banned
//      responses carry no weight) and keeps the window armed.
//   3. BAN-LEDGER PERSISTENCE — named-IP ban records survive process
//      restarts (.data/fapi-gate/bans.json, 30s debounced) so a recycle no
//      longer re-learns the minefield by burning fresh probes.
//
// v10.25 (Task 41, operator order «بایننس ای پی را بلاک نکرده باشد و قابل
// جایگزینی باشد»): the host is env-swappable WITHOUT a code change — if fapi
// is ever hard-blocked (451/region/grey-list, not just a timed 418), set
// NEXUS_FAPI_HOST in .env to a reachable futures-mirror and restart the app.
// Default stays the canonical host. Downstream replaceability ladder is
// already layered: fapi-gate (this) → SPOT-MIRROR aggTrade WS → spot REST
// klines/price fallback → Binance-only liq lanes (v14.0).
//
// ── v14.2 BAN-AWARE RECOVERY PACER (operator order «توصیه‌ها را کامل و مهندسی
// انجام بده», trace 1a1a15fb6bc0bd75 — audit rec #3 «throttle REST بن-آگاه»,
// NX-3247 forensics fc143950) ───────────────────────────────────────────────
// WHY: the old budget was FLAT — the instant a ban window expired the full
// 1100 weight/min came back at once, every starved scanner refilled its
// rotation in the same minute, and the pool re-saturated into a fresh 418
// spiral (measured 10-19: 11:58Z→12:34Z→13:09Z pause spiral). The pacer:
//   · RECOVERY RAMP — for 10min after a global ban window ends, the effective
//     budget ramps 25%→100% linearly. Early recovery minutes carry the
//     CRITICAL lane first (engine price feed / triggers), telemetry scanners
//     stretch back out gradually instead of stampeding.
//   · POOL-DISTRESS CAP — while ≥2 named egress IPs sit inside live ban
//     windows (the 10-18 measurement: 3 named IPs banned simultaneously),
//     the effective budget is capped at 50% — fewer lottery draws, less ban
//     pressure, named-IP evidence stays intel-shaped.
// CRITICAL lane keeps its negative retry; the floor (200/min) is the same
// clamp configureFapiGate enforces, so the pacer can never zero the plane.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
;
const FAPI_HOST = process.env.NEXUS_FAPI_HOST?.trim().replace(/\/+$/, "") || "https://fapi.binance.com";
const DEFAULT_TIMEOUT_MS = 6500;
const WINDOW_MS = 60_000;
const DEFAULT_BUDGET = 1100; // real fapi limit 2400/min per IP — headroom by design
const BAN_CAP_MS = 35 * 60_000; // never record a ban window longer than 35min even if Binance claims hours
// v12.6.1 — mixed-pool era: an UNPARSEABLE 418 is evidence of ONE banned draw,
// not a pool-wide ban (measured 2026-10-20 19:32Z: boot's first draw 418'd
// unparseable while 6/10 fresh connections succeeded — the old 10min arm
// locked the whole app out of a majority-clean pool). 2min + the streak
// escalation ladder covers true saturation.
const BAN_418_DEFAULT_MS = 2 * 60_000; // unparseable 418 → short backoff (was 10min — pool-starvation lesson)
const BAN_429_DEFAULT_MS = 2 * 60_000; // unparseable 429 → short warning backoff
const CRITICAL_RETRY_MS = 250; // the "small negative retry" for the critical lane
const SF_RESULT_MS = 2_000; // single-flight result sharing window
const SF_MAP_CAP = 512;
const SPEND_CAP = 4096; // defensive cap on window entries (~worst-case small-weight bursts)
const BAN_RETRIES = 3; // extra attempts after a named-IP ban (pool rotation)
// v12.6.2 ESCALATING RETRY CADENCE: the NAT egress mapping rotates over ~30s
// (measured 2026-10-20 19:41Z: keep-alive 6×418 → 30s later 6×200), so three
// retries 120ms apart shared ONE doomed mapping. Spacing the retries across
// it (120ms → 2s → 8s) lets draws 2-4 land on a rotated mapping — higher
// per-call success, fewer 60s short blocks. Worst added latency ~10s on a
// banned stretch; the ladder still escalates to the 60s block on failure.
const BAN_RETRY_DELAYS_MS = [
    120,
    2_000,
    8_000
];
const POOL_BLOCK_SHORT_MS = 60_000; // all-retries-banned → short block, let the pool rotate
const POOL_STREAK_FOR_LONG_BLOCK = 3; // consecutive all-banned calls ⇒ pool saturated
const IP_BAN_MAP_CAP = 16;
// ── v12.0 egress manager constants ──
const EGRESS_SAMPLE_TTL_MS = 120_000; // ipify cache — one draw sample per 2min
const EGRESS_TIMEOUT_MS = 3_500;
const PROBE_COOLDOWN_MS = 120_000; // one early-probe attempt per 2min while a window is live
const BAN_PERSIST_DIR = `${process.cwd()}/.data/fapi-gate`;
const BAN_PERSIST_PATH = `${BAN_PERSIST_DIR}/bans.json`;
const BAN_PERSIST_DEBOUNCE_MS = 30_000;
// v14.2 ban-aware recovery pacer
const PACER_RECOVERY_MS = 10 * 60_000; // post-ban ramp window (25%→100%)
const PACER_RAMP_FLOOR = 0.25; // budget fraction at the first recovery minute
const PACER_DISTRESS_CAP = 0.5; // budget cap while ≥2 named IPs are banned live
const PACER_MIN_BUDGET = 200; // same clamp floor as configureFapiGate
// globalThis singleton — survives Turbopack dev module-graph duplication
const g = globalThis;
const state = g.__nexusFapiGate ?? (g.__nexusFapiGate = {
    budgetPer60s: DEFAULT_BUDGET,
    banUntil: 0,
    spend: [],
    windowSum: 0,
    inflight: new Map(),
    ipBans: new Map(),
    recentBanEvents: [],
    allBanStreak: 0,
    aimdFactor: 1,
    lastBanEventAt: 0,
    lastAimdRecoverAt: 0,
    sampledIp: null,
    sampledAt: 0,
    lastBannedIp: null,
    lastProbeAt: 0,
    stats: {
        attempted: 0,
        allowed: 0,
        droppedBudget: 0,
        droppedBan: 0,
        lastBanUntil: 0,
        singleFlightShared: 0,
        retriesAfterBan: 0,
        probesIssued: 0,
        probeLifts: 0,
        effectiveBudgetPer60s: DEFAULT_BUDGET
    }
});
function isUnknownScopeKey(key) {
    return !/^\d{1,3}(\.\d{1,3}){3}$/.test(key); // anything that is not an IPv4 literal ("_pool", hostnames…)
}
try {
    const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
    const nowMs = Date.now();
    let unknownMax = 0;
    let named = 0;
    for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
        if (typeof until !== "number" || until <= nowMs) continue;
        if (isUnknownScopeKey(key)) {
            if (until > unknownMax) unknownMax = until;
        } else {
            state.ipBans.set(key, until);
            named++;
        }
    }
    if (unknownMax > state.banUntil) {
        state.banUntil = unknownMax;
        console.log(`[fapi-gate] v12.6 restored UNKNOWN-SCOPE pool ban from disk — silence armed until ${new Date(unknownMax).toISOString()}`);
    }
    if (state.ipBans.size > 0) {
        // v12.6: named-IP records are INTEL only — no global arm at boot. The
        // first gateFetch takes the lottery draw; a banned draw retries around
        // the named IP (pool rotation) exactly like any other 418.
        console.log(`[fapi-gate] v12.6 restored ${named} named-IP ban record(s) as intel (no global arm — majority-clean pool policy)`);
    }
} catch  {}
let banPersistTimer = null;
function persistBans() {
    if (banPersistTimer) return;
    banPersistTimer = setTimeout(()=>{
        banPersistTimer = null;
        try {
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"])(BAN_PERSIST_DIR, {
                recursive: true
            });
            const nowMs = Date.now();
            const ipBans = {};
            // v12.1 TASK-49 — READ-MERGE-WRITE: mini-services write their own 418
            // discoveries (incl. "_pool" unknown-scope markers with REAL ends) to
            // this same file. Blindly overwriting with state-only data DELETED a
            // 15:20Z pool ban mid-storm (2026-10-19) — never shorten/lose foreign
            // entries: merge disk first, then overlay ours, keep live only.
            try {
                const disk = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
                for (const [ip, until] of Object.entries(disk?.ipBans ?? {})){
                    if (typeof until === "number" && until > nowMs) ipBans[ip] = until;
                }
            } catch  {
            /* no ledger yet */ }
            for (const [ip, until] of state.ipBans)if (until > nowMs) ipBans[ip] = Math.max(ipBans[ip] ?? 0, until);
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["writeFileSync"])(BAN_PERSIST_PATH, JSON.stringify({
                savedAt: new Date().toISOString(),
                ipBans
            }, null, 1));
        } catch  {}
    }, BAN_PERSIST_DEBOUNCE_MS);
}
// ── v12.0 egress IP sampler (which pool IP did this draw exit from?) ──
let egressInflight = null;
async function sampleEgressIp() {
    if (state.sampledIp && Date.now() - state.sampledAt < EGRESS_SAMPLE_TTL_MS) return state.sampledIp;
    if (egressInflight) return egressInflight;
    egressInflight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const t = setTimeout(()=>ctrl.abort(), EGRESS_TIMEOUT_MS);
            const res = await fetch("https://api.ipify.org?format=json", {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(t);
            if (!res.ok) return null;
            const j = await res.json();
            const ip = typeof j.ip === "string" && j.ip ? j.ip : null;
            if (ip) {
                state.sampledIp = ip;
                state.sampledAt = Date.now();
            }
            return ip;
        } catch  {
            return null; // sampler down — never blocks the gate (fail-open)
        } finally{
            egressInflight = null;
        }
    })();
    return egressInflight;
}
function fapiEgressStatus() {
    const now = Date.now();
    const bannedIps = [];
    for (const [ip, until] of state.ipBans)if (until > now) bannedIps.push({
        ip,
        until,
        remainingMs: until - now
    });
    bannedIps.sort((a, b)=>b.until - a.until);
    return {
        banUntil: state.banUntil,
        banRemainingMs: Math.max(0, state.banUntil - now),
        sampledIp: state.sampledIp,
        sampledAt: state.sampledAt || null,
        lastBannedIp: state.lastBannedIp,
        bannedIps,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        lastProbeAt: state.lastProbeAt
    };
}
function configureFapiGate(opts) {
    if (opts?.budgetPer60s !== undefined) {
        const b = Math.max(200, Math.min(2300, Math.round(opts.budgetPer60s)));
        state.budgetPer60s = b;
    }
}
function fapiBanRemainingMs() {
    return Math.max(0, state.banUntil - Date.now());
}
function fapiBanActivity() {
    const now = Date.now();
    const globalRemainingMs = Math.max(0, state.banUntil - now);
    const namedLiveIps = namedLiveBanCount(now);
    if (globalRemainingMs > 0) {
        return {
            active: true,
            reason: `fapi GLOBAL ban window live — ${Math.round(globalRemainingMs / 1000)}s left`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    if (namedLiveIps >= 2) {
        return {
            active: true,
            reason: `fapi pool distress — ${namedLiveIps} named egress IPs inside live ban windows`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    return {
        active: false,
        reason: null,
        globalRemainingMs,
        namedLiveIps,
        effectiveBudgetPer60s: effectiveBudgetPer60s()
    };
}
function fapiGateStats() {
    const now = Date.now();
    pruneWindow(now);
    let bannedIps = 0;
    for (const [, until] of state.ipBans)if (until > now) bannedIps++;
    return {
        attempted: state.stats.attempted,
        allowed: state.stats.allowed,
        droppedBudget: state.stats.droppedBudget,
        droppedBan: state.stats.droppedBan,
        lastBanUntil: state.stats.lastBanUntil,
        budgetPer60s: state.budgetPer60s,
        usedLast60s: state.windowSum,
        singleFlightShared: state.stats.singleFlightShared,
        banRemainingMs: fapiBanRemainingMs(),
        bannedPoolIps: bannedIps,
        retriesAfterBan: state.stats.retriesAfterBan,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        effectiveBudgetPer60s: effectiveBudgetPer60s(),
        aimdFactor: Number(state.aimdFactor.toFixed(3))
    };
}
// ── weight table (Binance USDT-M futures documented weights) ────────────────
// klines ~2 (limit≤100) · depth 2-5-10 by limit · aggTrades 20 · trades 20 ·
// ticker/24hr 1 per-symbol / 40 full-universe · premiumIndex 1 per-symbol /
// 10 all-markers · futures/data/* 1 (openInterestHist, L/S ratios, basis…) ·
// exchangeInfo 1 · ping/time 1 · unknown default 5 (conservative).
function resolveWeight(path) {
    const qIdx = path.indexOf("?");
    const ep = (qIdx === -1 ? path : path.slice(0, qIdx)).replace(/^\//, "").replace(/\/+$/, "");
    const query = qIdx === -1 ? "" : path.slice(qIdx + 1);
    const limit = ()=>{
        const m = /[?&]limit=(\d+)/.exec(query);
        return m ? Number(m[1]) : null;
    };
    switch(ep){
        case "fapi/v1/ping":
        case "fapi/v1/time":
        case "fapi/v1/exchangeInfo":
            return 1;
        case "fapi/v1/klines":
            {
                const l = limit() ?? 500;
                return l <= 100 ? 2 : l <= 499 ? 5 : 10;
            }
        case "fapi/v1/depth":
            {
                const l = limit() ?? 100;
                return l <= 100 ? 2 : l <= 500 ? 5 : 10;
            }
        case "fapi/v1/aggTrades":
        case "fapi/v1/trades":
            return 20;
        case "fapi/v1/ticker/24hr":
            return /[?&]symbol=/.test(query) ? 1 : 40;
        case "fapi/v1/premiumIndex":
            return /[?&]symbol=/.test(query) ? 1 : 10;
        default:
            if (ep.startsWith("futures/data/")) return 1; // openInterestHist / L-S ratios / basis family
            return 5; // unknown → conservative default (covers fapi/v1/fundingRate etc.)
    }
}
function pruneWindow(now) {
    const cutoff = now - WINDOW_MS;
    while(state.spend.length > 0 && state.spend[0].at <= cutoff){
        const e = state.spend.shift();
        state.windowSum -= e.w;
    }
    if (state.spend.length > SPEND_CAP) {
        // defensive: drop the oldest half rather than grow unbounded
        const keep = state.spend.slice(Math.floor(state.spend.length / 2));
        let sum = 0;
        for (const e of keep)sum += e.w;
        state.spend = keep;
        state.windowSum = sum;
    }
}
/** Reserve `weight` from the rolling window. Returns the spend entry (for refunds) or null. */ // ── v14.2 BAN-AWARE RECOVERY PACER ────────────────────────────────────────
// The ONLY budget the rolling window spends against. A flat budget after a
// ban ended = instant re-saturation stampede (the 10-19 spiral); the pacer
// gives the pool a 10min ramp and caps telemetry while the pool shows live
// distress. Global-window minutes are NOT handled here (gateFetch drops
// everything while the window is live) — the pacer shapes the BEFORE
// (distress) and AFTER (recovery) of each ban episode.
function namedLiveBanCount(now) {
    let n = 0;
    for (const [, until] of state.ipBans)if (until > now) n++;
    return n;
}
// ── v14.3 ROLLING-CYCLE AIMD PACER (chapter-7 item ② «backoff واقعی», operator
// mandate trace 1a1a8ea4186c6571) — the missing third leg of the v14.2 pacer.
// Measured failure mode (engineering report NX3247+LIVE): the 3-IP egress pool
// rides a ROLLING ~20min ban cycle — bans expire, the full budget floods back
// instantly (named-IP bans never armed the global window ⇒ no ramp), the pool
// re-saturates in the same minute and re-bans. Fix: an AIMD shed factor that
// DECREASES multiplicatively on every named-IP ban event (×0.7, floor 0.25) and
// recovers ADDITIVELY during clean minutes (+0.05/min, cap 1.0). Sustained ban
// churn ⇒ progressively quieter pool without any operator tuning; a genuinely
// healthy pool heals back to full budget in ~15 clean minutes.
const AIMD_DROP = 0.7;
const AIMD_FLOOR = 0.25;
const AIMD_RECOVER_PER_MIN = 0.05;
function recoverAimd(now) {
    if (state.aimdFactor >= 1) {
        state.lastAimdRecoverAt = now;
        return;
    }
    if (state.lastBanEventAt === 0) return;
    const anchor = Math.max(state.lastAimdRecoverAt, state.lastBanEventAt);
    const cleanMin = Math.floor((now - anchor) / 60_000);
    if (cleanMin <= 0) return;
    state.aimdFactor = Math.min(1, state.aimdFactor + cleanMin * AIMD_RECOVER_PER_MIN);
    state.lastAimdRecoverAt = now;
}
function noteAimdBanEvent(now) {
    recoverAimd(now);
    state.aimdFactor = Math.max(AIMD_FLOOR, state.aimdFactor * AIMD_DROP);
    state.lastBanEventAt = now;
    state.lastAimdRecoverAt = now;
}
function effectiveBudgetPer60s() {
    const now = Date.now();
    let factor = 1;
    recoverAimd(now); // v14.3 — additive clean-minute recovery before clamping
    factor = Math.min(factor, state.aimdFactor);
    // POOL DISTRESS — ≥2 named egress IPs inside live ban windows: cap telemetry.
    if (namedLiveBanCount(now) >= 2) factor = Math.min(factor, PACER_DISTRESS_CAP);
    // RECOVERY RAMP — 10min linear 25%→100% after the last global window ends.
    if (state.banUntil > 0) {
        const sinceBan = now - state.banUntil;
        if (sinceBan >= 0 && sinceBan < PACER_RECOVERY_MS) {
            factor = Math.min(factor, PACER_RAMP_FLOOR + (1 - PACER_RAMP_FLOOR) * (sinceBan / PACER_RECOVERY_MS));
        }
    }
    return Math.max(PACER_MIN_BUDGET, Math.round(state.budgetPer60s * factor));
}
function takeWeight(weight) {
    const now = Date.now();
    pruneWindow(now);
    if (state.windowSum + weight > effectiveBudgetPer60s()) return null;
    const entry = {
        at: now,
        w: weight
    };
    state.spend.push(entry);
    state.windowSum += weight;
    return entry;
}
/** 418/429 responses carry no weight cost — give the reservation back. */ function refundWeight(entry) {
    if (!entry) return;
    const idx = state.spend.indexOf(entry);
    if (idx === -1) return; // already pruned out of the window (its cost is gone too)
    state.spend.splice(idx, 1);
    state.windowSum -= entry.w;
}
function armGlobalBan(until) {
    if (until > state.banUntil) {
        state.banUntil = until;
        state.stats.lastBanUntil = until;
    }
}
/** Record a 418/429 body. Returns { ip, until } when the body NAMES the banned egress IP. */ function noteBanBody(status, body) {
    const now = Date.now();
    const named = /IP\(([\d.]+)\)\s*banned until (\d+)/i.exec(body);
    if (named) {
        const ip = named[1];
        // v12.1 TASK-49: the LEDGER carries Binance's REAL end (sanity-capped 24h) —
        // the cosmetic +35min cap only applies to the global silence window below.
        // Capping the ledger made the early probe fire at a fake expiry and the
        // resulting 418 contact re-escalated the real ban (11:58→12:34→13:09 spiral).
        const realUntil = Math.min(Number(named[2]), now + 24 * 60_000);
        const until = Math.min(realUntil, now + BAN_CAP_MS);
        state.ipBans.set(ip, realUntil);
        state.lastBannedIp = ip;
        persistBans(); // v12.0 — named-IP ban ledger survives restarts (30s debounce)
        if (state.ipBans.size > IP_BAN_MAP_CAP) {
            // evict the soonest-expiring record
            let oldestKey = null;
            let oldestVal = Infinity;
            for (const [k, v] of state.ipBans)if (v < oldestVal) {
                oldestVal = v;
                oldestKey = k;
            }
            if (oldestKey) state.ipBans.delete(oldestKey);
        }
        state.recentBanEvents.push({
            at: now,
            ip
        });
        if (state.recentBanEvents.length > 64) state.recentBanEvents.splice(0, state.recentBanEvents.length - 64);
        noteAimdBanEvent(now); // v14.3 — every named-IP ban deepens the rolling-cycle shed
        return {
            ip,
            until
        };
    }
    const untilMatch = /banned until (\d+)/i.exec(body);
    if (untilMatch) {
        armGlobalBan(Math.min(Number(untilMatch[1]), now + BAN_CAP_MS)); // unknown scope — assume it's us
        return null;
    }
    // unparseable body — conservative defaults (taxonomy precedent for 418)
    armGlobalBan(now + (status === 429 ? BAN_429_DEFAULT_MS : BAN_418_DEFAULT_MS));
    return null;
}
/** Every retry landed on a (named) banned IP — escalate the global silence window. */ function escalatePoolBlock(worstNamedUntil) {
    const now = Date.now();
    state.allBanStreak++;
    if (state.allBanStreak >= POOL_STREAK_FOR_LONG_BLOCK) {
        // repeated independent evidence — the egress pool is saturated: full
        // zero-network window, capped at 35min, then a fresh probe self-heals.
        armGlobalBan(Math.min(worstNamedUntil, now + BAN_CAP_MS));
        state.allBanStreak = 0;
    } else {
        armGlobalBan(now + POOL_BLOCK_SHORT_MS);
    }
}
function pruneInflight(now) {
    for (const [k, e] of state.inflight){
        if (e.settled && now - e.startedAt >= SF_RESULT_MS) state.inflight.delete(k);
    }
}
function delay(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}
/**
 * THE gate body. Resolves parsed JSON, or null on: live IP ban, weight-budget
 * shed, HTTP failure, timeout, or parse error. Never throws, never queues.
 */ async function executeGated(path, opts) {
    const lane = opts?.priority ?? "telemetry";
    const weight = Math.max(1, Math.round(opts?.weight ?? resolveWeight(path)));
    const timeoutMs = opts?.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    let entry = takeWeight(weight);
    if (!entry) {
        if (lane !== "critical") {
            state.stats.droppedBudget++;
            return null; // telemetry: drop instead of queueing a storm
        }
        await delay(CRITICAL_RETRY_MS); // one small negative retry
        entry = takeWeight(weight);
        if (!entry) {
            state.stats.droppedBudget++;
            return null;
        }
    }
    const host = opts?.host ?? FAPI_HOST;
    let attempt = 0;
    while(true){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        let res;
        try {
            // v12.6.1 CONNECTION-RECYCLE (measured 2026-10-20 19:41Z, bun runtime):
            // a keep-alive fetch POOLS one TCP flow ⇒ ONE egress IP for its whole
            // life — a pinned-banned connection turned 231 gate calls into 0 allowed
            // while 6/10 fresh connections succeeded. `Connection: close` = a fresh
            // NAT lottery draw per request; the TLS cost (~60ms) is trivial next to
            // the starvation it prevents.
            res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store",
                headers: {
                    Connection: "close"
                }
            });
        } catch  {
            return null; // timeout/abort/network — weight may have been consumed, keep the reservation
        } finally{
            clearTimeout(timer);
        }
        if (res.ok) {
            const text = await res.text().catch(()=>"");
            if (!text) return null; // empty 200 — nothing to invent
            state.stats.allowed++;
            state.allBanStreak = 0; // a clean 2xx proves the pool still serves us
            try {
                return JSON.parse(text);
            } catch  {
                return null;
            }
        }
        if (res.status === 418 || res.status === 429) {
            const body = await res.text().catch(()=>"");
            refundWeight(entry); // banned responses carry no weight cost
            entry = null;
            const named = noteBanBody(res.status, body);
            if (opts?.singleProbe) return null; // v12.0 early probe — single attempt, window stays armed
            if (!named) return null; // unknown-scope ban — global zero-network window already armed
            if (attempt >= BAN_RETRIES) {
                escalatePoolBlock(named.until);
                return null;
            }
            attempt++;
            state.stats.retriesAfterBan++;
            await delay(BAN_RETRY_DELAYS_MS[Math.min(attempt - 1, BAN_RETRY_DELAYS_MS.length - 1)]); // span the NAT rotation window
            entry = takeWeight(weight);
            if (!entry) {
                state.stats.droppedBudget++;
                return null;
            }
            continue;
        }
        return null; // other non-ok status — honest null, no retry
    }
}
/** v12.1 TASK-49 — a recorded ban counts ONLY while its real end is in the future. */ function isIpBanned(ip, now) {
    if (!ip) return false;
    return (state.ipBans.get(ip) ?? 0) > now;
}
// v12.1 TASK-49 — SHARED LEDGER REFRESH: trade-service / price-ws write their
// own 418 discoveries (with REAL ends) to the same bans.json. Merge live disk
// entries into state every 30s (extend-only). v12.6 scope split: UNKNOWN-SCOPE
// entries extend the global silence (pool-suspect evidence); NAMED-IP entries
// merge into ipBans as intel only — a majority-clean pool must not be
// blacked out because one pool member drew a ban.
let lastLedgerCheckAt = 0;
function refreshLedgerOnce() {
    const nowMs = Date.now();
    lastLedgerCheckAt = nowMs;
    try {
        const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
        let unknownMax = 0;
        for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
            if (typeof until !== "number" || until <= nowMs) continue;
            if (isUnknownScopeKey(key)) {
                if (until > unknownMax) unknownMax = until;
                continue;
            }
            if (until > (state.ipBans.get(key) ?? 0)) state.ipBans.set(key, until);
        }
        // unknown-scope knowledge extends the global silence window (extend-only)
        if (unknownMax > state.banUntil) {
            state.banUntil = unknownMax;
            console.log(`[fapi-gate] v12.6 ledger refresh — UNKNOWN-SCOPE pool ban extends silence until ${new Date(unknownMax).toISOString()}`);
        }
    } catch  {
    /* ledger gone/unreadable — keep in-memory state */ }
}
try {
    const refresh = setInterval(refreshLedgerOnce, 30_000);
    if (typeof refresh.unref === "function") refresh.unref();
} catch  {
/* non-blocking env — skip refresh */ }
async function gateFetch(path, opts) {
    state.stats.attempted++;
    const now = Date.now();
    // v12.1 TASK-49 — LAZY LEDGER GUARD: the instant our global window expires,
    // re-check the shared ledger (throttled to one disk read / 15s) BEFORE any
    // network call — closes the poke-gap where the window died but the refresh
    // interval hadn't fired yet. While the pool is ledger-banned, zero pokes.
    if (now >= state.banUntil && now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
    if (now < state.banUntil) state.stats.droppedBan++; // ledger re-armed the window — shed instantly
    // GLOBAL BAN AWARENESS — while a global ban window is live, zero network calls
    // …except the v12.0 ROTATION-AWARE EARLY PROBE: one critical-lane attempt per
    // PROBE_COOLDOWN_MS when the sampled egress IP is clean — the pool rotates,
    // so the window can be LIFTED the moment a clean draw appears instead of
    // waiting out the full 35min cap. A failed probe keeps the window armed.
    if (now < state.banUntil) {
        state.stats.droppedBan++;
        const canProbe = (opts?.priority ?? "telemetry") === "critical" && now - state.lastProbeAt >= PROBE_COOLDOWN_MS;
        if (!canProbe) return null;
        // v12.1 TASK-49 — LEDGER FRESHNESS BEFORE PROBE: state may hold a cosmetic
        // cap while the disk carries a longer REAL end another process discovered.
        // A probe fired on stale state pokes a still-banned pool and re-escalates.
        // Re-read the ledger (15s throttle) and re-arm BEFORE the probe decision.
        if (now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
        if (now < state.banUntil) return null; // ledger extended the silence — no probe
        state.lastProbeAt = now;
        const ip = await sampleEgressIp();
        // v12.1 TASK-49: expiry-aware check — a recorded ban whose real end passed
        // no longer blocks the probe (the old .has() kept ghost entries armed).
        if (!ip || isIpBanned(ip, now)) return null; // sampled draw is banned/unknown — stay silent
        state.stats.probesIssued++;
        const probeResult = await executeGated(path, {
            ...opts,
            singleProbe: true
        });
        if (probeResult !== null) {
            state.banUntil = 0; // clean draw proved the pool rotated — lift instantly
            state.allBanStreak = 0;
            state.stats.probeLifts++;
            console.log(`[fapi-gate] v12.0 ban window LIFTED early — egress rotated to clean IP ${ip}`);
        }
        return probeResult;
    }
    // SINGLE-FLIGHT per (host,path): share the request while it is in flight and
    // for a 2s result window — concurrent module askers pay the weight once.
    const key = `${opts?.host ?? FAPI_HOST}${path}`;
    const existing = state.inflight.get(key);
    if (existing) {
        const age = now - existing.startedAt;
        if (!existing.settled || age < SF_RESULT_MS) {
            state.stats.singleFlightShared++;
            return existing.promise;
        }
        state.inflight.delete(key);
    }
    if (state.inflight.size >= SF_MAP_CAP) pruneInflight(now);
    const promise = executeGated(path, opts);
    const entry = {
        startedAt: now,
        settled: false,
        promise
    };
    state.inflight.set(key, entry);
    void promise.catch(()=>null) // executeGated never rejects — belt & suspenders
    .finally(()=>{
        entry.settled = true;
    });
    return promise;
}
}),
"[project]/src/lib/liquidations.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLiquidationSnapshot",
    ()=>getLiquidationSnapshot,
    "getLiquidationStatus",
    ()=>getLiquidationStatus,
    "liquidationPressure",
    ()=>liquidationPressure
]);
// ── FlowRadar Neo liquidation feed client (server-only) ──
// Reads mini-services/liq-service (:3010). Honesty contract: when the stream
// is stalled or down we return null — never a fabricated "quiet tape".
const LIQ_URL = process.env.LIQ_SERVICE_URL ?? "http://localhost:3010";
const TIMEOUT_MS = 2500;
const CACHE_TTL = 20_000;
let cache = null;
let inFlight = null;
async function getLiquidationSnapshot() {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.snap;
    if (inFlight) return inFlight;
    inFlight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${LIQ_URL}/liquidations`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (!res.ok) throw new Error(`liq ${res.status}`);
            const snap = await res.json();
            cache = {
                at: Date.now(),
                snap
            };
            return snap;
        } catch  {
            cache = {
                at: Date.now(),
                snap: null
            };
            return null;
        } finally{
            inFlight = null;
        }
    })();
    return inFlight;
}
async function getLiquidationStatus() {
    const snap = await getLiquidationSnapshot();
    if (!snap) return null;
    return {
        online: true,
        ...snap.status
    };
}
async function liquidationPressure(symbol) {
    const snap = await getLiquidationSnapshot();
    if (!snap || snap.status.dataStalled || !snap.status.connected) return null;
    const row = snap.bySymbol[symbol];
    if (!row) return {
        usd10m: 0,
        longsUsd10m: 0,
        shortsUsd10m: 0
    };
    return {
        usd10m: row.usd10m,
        longsUsd10m: row.longsUsd10m,
        shortsUsd10m: row.shortsUsd10m
    };
}
}),
"[project]/src/lib/spot-host-gate.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noteSpotHostThrottle",
    ()=>noteSpotHostThrottle,
    "spotHostReady",
    ()=>spotHostReady,
    "spotHostsReady",
    ()=>spotHostsReady,
    "spotLadderJson",
    ()=>spotLadderJson
]);
// ── NEXUS//SIGNALS spot-host gate (v13.2.1 SPOT-BAN-BACKOFF) ────────────────
// Completes the v13.2 SPOT-HOST LADDER: the ladder could DETECT a 418/429
// (fall through to the next rung) but had NO per-host backoff, so every tick
// re-poked the banned host first — wasting weight and keeping ban pressure
// alive. Live evidence 2026-10-25T00:48Z: data-api.binance.vision flapped
// 429/418 at x-mbx-used-weight-1m: 467 with retry-after: 889s while fapi
// served 200 @73ms (separate ban pools per host confirmed).
//
// Contract (read-only, zero data invention):
//   · 418 → host silent for retry-after seconds (capped 15min)
//   · 429 → soft 60s pause (retry-after respected when present)
//   · ladders ask spotHostsReady() and skip mid-ban hosts → traffic
//     auto-redistributes to the healthy rung and slides back on expiry.
//   · globalThis dedupe — Turbopack can instantiate per-route bundles; the
//     engine tick loop and /api routes MUST share one ban map (fbStats pattern).
const CAP_MS = 15 * 60_000;
const g = globalThis;
g.__nexusSpotHostGate ??= {
    bannedUntil: {}
};
const S = g.__nexusSpotHostGate;
function spotHostReady(host, now = Date.now()) {
    return (S.bannedUntil[host] ?? 0) <= now;
}
function spotHostsReady(hosts, now = Date.now()) {
    return hosts.filter((h)=>spotHostReady(h, now));
}
function noteSpotHostThrottle(host, status, headers) {
    const now = Date.now();
    let ms = status === 418 ? CAP_MS : 60_000;
    const ra = Number(headers.get("retry-after"));
    if (Number.isFinite(ra) && ra > 0) ms = Math.min(ra * 1000, CAP_MS);
    const prev = S.bannedUntil[host] ?? 0;
    if (prev < now + 1000) {
        console.warn(`[spot-host-gate] ${host} → ${status} — leg silent ${Math.round(ms / 1000)}s (weight1m=${headers.get("x-mbx-used-weight-1m") ?? "?"})`);
    }
    S.bannedUntil[host] = Math.max(prev, now + ms);
}
async function spotLadderJson(path, hosts, timeoutMs = 8000) {
    for (const host of spotHostsReady(hosts)){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        try {
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                noteSpotHostThrottle(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) continue;
            return await res.json();
        } catch  {
            continue;
        } finally{
            clearTimeout(timer);
        }
    }
    return null;
}
}),
"[project]/src/lib/flow-bridge.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bridgeDepth",
    ()=>bridgeDepth,
    "bridgeKlines",
    ()=>bridgeKlines,
    "bridgeOiHist",
    ()=>bridgeOiHist,
    "bridgeTape",
    ()=>bridgeTape,
    "fapi5mMove",
    ()=>fapi5mMove,
    "futTickerMap",
    ()=>futTickerMap,
    "futTickerRow",
    ()=>futTickerRow,
    "spot5mMove",
    ()=>spot5mMove,
    "spotMirrorDepth",
    ()=>spotMirrorDepth,
    "spotMirrorKlines",
    ()=>spotMirrorKlines,
    "spotMirrorTape",
    ()=>spotMirrorTape
]);
// ── FlowRadar Neo FLOW BRIDGE (server-only, v14.0 BINANCE-ONLY) ──
// Operator mandate (trace 1a185042c872b4f9 — «ردپای OKX/Bybit در کجا وجود
// دارد و با بایننس جایگزین شود»): the v12.2 cross-venue bridge is retired.
// Every ladder is now BINANCE-ONLY, riding the two independent Binance REST
// planes measured live from this egress:
//
//  ① fapi plane — gated (fapi-gate, weight budget, ban ledger), perp-native.
//  ② SPOT-MIRROR plane — the v13.3 spot-host ladder (data-api.binance.vision
//     → api-gcp → api1-4 → api.binance.com) with the shared per-host 418/429
//     gate: SEPARATE ban pool from fapi, SAME kline shape (field-9 taker
//     volume intact), zero fapi weight.
//
// LADDERS (best → last): klines fapi→SPOT-MIRROR · tape fapi→SPOT-MIRROR ·
// OI history fapi (perp-native — no spot equivalent, honest null on ban) ·
// depth fapi→SPOT-MIRROR · batched tickers fapi(composite)→SPOT-MIRROR.
// HONESTY LAWS unchanged: a plane that fails degrades to null — never to
// invented data; every result carries its SOURCE so cards/journals say which
// Binance plane the number came from. crowd/top-trader L/S ratios stay
// Binance-only and honestly null. FLAT-10 engine policy untouched.
//
// Note: 1000X-style perp symbols (1000PEPEUSDT…) have no spot pair — the
// SPOT-MIRROR rung 404s on them and the ladder ends honestly (fapi rung
// serves them whenever the gate is open).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [instrumentation] (ecmascript)");
;
;
const TIMEOUT_MS = 6500;
async function jfetch(url, init) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
    try {
        const res = await fetch(url, {
            ...init,
            signal: ctrl.signal,
            cache: "no-store"
        });
        if (!res.ok) return null;
        return await res.json();
    } catch  {
        return null;
    } finally{
        clearTimeout(timer);
    }
}
// ── klines rungs ────────────────────────────────────────────────────────
// ── v13.2 SPOT-HOST LADDER (operator mandate trace 1a1704d407f00dad —
// «از data-api.binance.vision استفاده کن؛ جریان زندهٔ لحظه‌ای باید با بایننس
// باشد»): measured live 2026-10-25 — data-api.binance.vision 32/32 HTTP 200
// p50 57ms while api.binance.com rides 418 ban-storms from this shared egress.
// v13.2.3 (trace 1a170bba02dff781): api1-4 added as mid rungs, api last.
// v14.0: this ladder is now the ONLY fallback plane (Binance-only mandate).
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
// v13.2.1 — per-host 418/429 backoff via the shared spot-host gate: a banned
// rung is SKIPPED (not re-poked every tick) and traffic slides to the healthy
// host until retry-after expires (live evidence: vision 418 @467wt/min while
// jfetch swallowed the status and kept hammering).
async function spotLadderFetch(path) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["spotLadderJson"])(path, SPOT_HOSTS, TIMEOUT_MS);
}
function binanceKlineRows(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5]),
            takerBuyBase: Number(k[9])
        }));
}
async function spotMirrorKlines(symbol, interval, limit) {
    const spot = await spotLadderFetch(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
    if (!spot || spot.length === 0) return null;
    return binanceKlineRows(spot);
}
async function bridgeKlines(symbol, interval, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.length > 0) return {
        rows: binanceKlineRows(raw),
        source: "BINANCE"
    };
    const spot = await spotMirrorKlines(symbol, interval, limit).catch(()=>null);
    if (spot && spot.length > 0) return {
        rows: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function spotMirrorTape(symbol) {
    const spot = await spotLadderFetch(`/api/v3/trades?symbol=${symbol}&limit=1000`);
    if (!spot || spot.length === 0) return null;
    return spot.map((t)=>({
            price: Number(t.price),
            qty: Number(t.qty),
            quoteQty: Number(t.quoteQty) || Number(t.price) * Number(t.qty),
            isBuyerMaker: t.isBuyerMaker,
            time: t.time
        }));
}
async function bridgeTape(symbol) {
    const agg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (agg && agg.length > 0) {
        return {
            trades: agg.map((t)=>({
                    price: Number(t.p),
                    qty: Number(t.q),
                    quoteQty: Number(t.p) * Number(t.q),
                    isBuyerMaker: t.m,
                    time: t.T
                })),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorTape(symbol).catch(()=>null);
    if (spot && spot.length > 0) return {
        trades: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function bridgeOiHist(symbol, period, limit) {
    const f = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/futures/data/openInterestHist?symbol=${symbol}&period=${period}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (f && f.length > 0) {
        return {
            rows: f.map((h)=>({
                    sumOpenInterest: Number(h.sumOpenInterest),
                    sumOpenInterestValue: Number(h.sumOpenInterestValue),
                    timestamp: h.timestamp
                })),
            source: "BINANCE"
        };
    }
    return null;
}
async function spotMirrorDepth(symbol, limit) {
    const steps = [
        5,
        10,
        20,
        50,
        100,
        500
    ];
    const lv = steps.find((s)=>s >= limit) ?? 500;
    const raw = await spotLadderFetch(`/api/v3/depth?symbol=${symbol}&limit=${lv}`);
    if (!raw || raw.bids.length === 0 || raw.asks.length === 0) return null;
    return {
        bids: raw.bids.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        asks: raw.asks.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        source: "SPOT-MIRROR"
    };
}
async function bridgeDepth(symbol, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/depth?symbol=${symbol}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.bids.length > 0 && raw.asks.length > 0) {
        return {
            bids: raw.bids.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            asks: raw.asks.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorDepth(symbol, limit).catch(()=>null);
    if (spot) return spot;
    return null;
}
// ── batched tickers — funding + mark + 24h board for the WHOLE domain ──────
// v14.0 BINANCE-ONLY composite: ONE gated /fapi/v1/ticker/24hr (weight 40) +
// ONE gated /fapi/v1/premiumIndex batch (weight 10) merged per symbol. On a
// fapi ban the SPOT-MIRROR ticker batch prices the board (mark/funding/OI
// honestly null — spot plane carries no perp derivatives).
const TICKERS_TTL = 15_000;
let tickCache = null;
let tickInFlight = null;
async function futTickerMap() {
    if (tickCache && Date.now() - tickCache.at < TICKERS_TTL) return tickCache.map;
    if (tickInFlight) return tickInFlight;
    tickInFlight = (async ()=>{
        const out = new Map();
        const [board, prem] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/ticker/24hr", {
                priority: "telemetry",
                weight: 40,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/premiumIndex", {
                priority: "telemetry",
                weight: 10,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null)
        ]);
        if (board && board.length > 0) {
            const premMap = new Map((prem ?? []).map((p)=>[
                    p.symbol,
                    p
                ]));
            for (const r of board){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                const pm = premMap.get(r.symbol);
                const mark = Number(pm?.markPrice) || null;
                const funding = Number(pm?.lastFundingRate);
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: mark,
                    fundingRate: Number.isFinite(funding) && pm ? funding : null,
                    nextFundingTime: Number(pm?.nextFundingTime) || null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "BINANCE"
                });
            }
            tickCache = {
                at: Date.now(),
                map: out,
                src: "BINANCE"
            };
            return out;
        }
        // fapi banned — SPOT-MIRROR board (price-only rows, honest nulls on perp fields)
        const spot = await spotLadderFetch("/api/v3/ticker/24hr");
        if (spot && spot.length > 0) {
            for (const r of spot){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: null,
                    fundingRate: null,
                    nextFundingTime: null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "SPOT-MIRROR"
                });
            }
        }
        tickCache = {
            at: Date.now(),
            map: out,
            src: "SPOT-MIRROR"
        };
        return out;
    })();
    try {
        return await tickInFlight;
    } finally{
        tickInFlight = null;
    }
}
async function futTickerRow(symbol) {
    const map = await futTickerMap().catch(()=>new Map());
    const row = map.get(symbol);
    if (!row) return null;
    // v14.0 — OI enrichment: /fapi/v1/openInterest is per-symbol (weight 1);
    // fill it only for rows priced by the fapi plane and only when missing.
    if (row.source === "BINANCE" && row.openInterest === null) {
        const oi = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/openInterest?symbol=${symbol}`, {
            priority: "telemetry",
            timeoutMs: 4000
        }).catch(()=>null);
        const v = Number(oi?.openInterest);
        if (Number.isFinite(v) && v > 0) {
            row.openInterest = v;
            if (row.markPrice) row.openInterestValue = v * row.markPrice;
        }
    }
    return row;
}
async function spot5mMove(symbol) {
    const rows = await spotMirrorKlines(symbol, "5m", 4);
    if (!rows || rows.length < 4) return null;
    const open = rows[0].open;
    const close = rows[rows.length - 1].close;
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
async function fapi5mMove(symbol) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=4`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (!raw || raw.length < 4) return null;
    const open = Number(raw[0][1]);
    const close = Number(raw[raw.length - 1][4]);
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
}),
"[project]/src/lib/core-revert.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCoreRevert",
    ()=>getCoreRevert
]);
// ── NEXUS//SIGNALS v13.0 CORE-REVERT knob (server-only) ──
// Operator mandate 2026-10-24 («پیشنهاد من سیستم به همان وضعیت برگردد و با
// دیتای موجود نقاط ضعف را فیلتر کند») after the W42 performance audit:
//   · v12.7 era (10-21 → 10-23 15:18): 111 signals, WR 60.4%, +$39.74,
//     median event→entry delay 13.2min — the SUCCESSFUL core configuration.
//   · v12.8/v12.9 era (10-23 15:31 → now): confirmation stack (CHASE-EXTREME,
//     FLUSH-EXHAUSTION/KNIFE-CATCH/STOP-FLOOR, SINGLE-VENUE, NO-BINANCE +12,
//     SURROGATE-FLOW cap, MULTI-VENUE clamp, STALE-BAR) DOUBLED the median
//     delay to 27.4min and starved the board behind a 200+ veto wall, while
//     the hard-SL class it targeted kept printing (7× −61.2% on 10-24 alone).
// enabled=true (default) → the v12.8+ hard gates become ADVISORY: they keep
// journaling (gate-journal audit trail preserved for future recalibration)
// but never refuse a deploy — deploy semantics return to the v12.7 core.
// Weaknesses are filtered from EXISTING data instead (STALE-CHASE gate +
// REARM-BRAKE-BE window in engine.ts), not by new blocking regimes.
// enabled=false → exact v12.9 blocking behavior, one EngineSetting flip.
// Cached 30s per process; fail-open to the operator mandate default.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
;
const DEFAULT_CFG = {
    enabled: true
};
const CACHE_MS = 30_000;
const g = globalThis;
async function getCoreRevert() {
    const hit = g.__nexusCoreRevert;
    if (hit && Date.now() - hit.at < CACHE_MS) return hit.val;
    let val = {
        ...DEFAULT_CFG
    };
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "core-revert"
            }
        });
        if (row) {
            const p = JSON.parse(row.value);
            if (typeof p.enabled === "boolean") val = {
                enabled: p.enabled
            };
        }
    } catch  {
    /* fail-open → operator-mandate default (enabled) */ }
    g.__nexusCoreRevert = {
        at: Date.now(),
        val
    };
    return val;
}
}),
"[project]/src/lib/flow.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WHALE_PRINT_MIN_USD",
    ()=>WHALE_PRINT_MIN_USD,
    "detectLiquiditySweep",
    ()=>detectLiquiditySweep,
    "ensureFlow",
    ()=>ensureFlow,
    "fetchFlowMetrics",
    ()=>fetchFlowMetrics,
    "flowCoverageOf",
    ()=>flowCoverageOf,
    "getFlowHistory",
    ()=>getFlowHistory,
    "getFlowSource",
    ()=>getFlowSource,
    "getFlowStatus",
    ()=>getFlowStatus,
    "scoreFlow",
    ()=>scoreFlow
]);
// ── FlowRadar Neo order-flow module (server-only) ──
// Real Binance USDT-M flow metrics: OI delta, taker CVD, crowd L/S, funding.
// scoreFlow → ±25 along candidate direction · OI-notional weighting (v4.5)
// · in-memory per-symbol history ring for sparklines (R17).
// v10.24 Task 34-a: fapi REST now goes through the process-wide fapi-gate
// (weight budget + global ban awareness + single-flight). Telemetry lane —
// sheddable under pressure; every caller is throw/null-tolerant already.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)"); // v13.3 — ch.7-ب: honest fapi-plane health for the surrogate demote
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/core-revert.ts [instrumentation] (ecmascript)"); // v13.0 CORE-REVERT — operator revert mandate
;
;
;
;
const TIMEOUT_MS = 6500;
const CACHE_TTL = 150_000; // 2.5min
const STALE_GRACE = 600_000; // 10min
/** Decision-relevant metric keys — cvdNetBase is structurally null in the
 *  current pipeline and excluded from coverage on purpose. */ const COVERAGE_KEYS = [
    "oiDelta10m",
    "oiDelta1h",
    "oiValueUsd",
    "cvdNetPctOfVol",
    "takerRatio",
    "takerMean",
    "crowdLongShort",
    "topLongShort",
    "funding8h",
    "cvdUsd60s"
];
function flowCoverageOf(m) {
    return COVERAGE_KEYS.reduce((a, k)=>a + (m[k] != null ? 1 : 0), 0);
}
const BLIND_CACHE_TTL = 20_000; // v12.1: all-null metrics are a STARVATION state,
// v12.2 TASK-52 — venue that fed the last metrics bundle per symbol
const flowSrcMap = new Map();
function getFlowSource(symbol) {
    return flowSrcMap.get(symbol) ?? null;
}
// v12.9 MULTI-VENUE CONSENSUS — per-key 60s cache + in-flight dedupe so the
// second-venue cross-check costs at most ONE fetch per venue per minute per
// symbol on the hot path. Fail-soft: any throw → cached null → consensus
// skips (never blocks, never invents).
const consensusCache = new Map();
const consensusInFlight = new Map();
async function cachedConsensusVal(key, ttlMs, fn) {
    const hit = consensusCache.get(key);
    if (hit && Date.now() - hit.at < ttlMs) return hit.val ?? null;
    const inflight = consensusInFlight.get(key);
    if (inflight) return await inflight ?? null;
    const p = (async ()=>{
        let val = null;
        try {
            val = await fn();
        } catch  {
            val = null;
        }
        consensusCache.set(key, {
            at: Date.now(),
            val
        });
        if (consensusCache.size > 800) {
            const oldest = consensusCache.keys().next().value;
            if (oldest) consensusCache.delete(oldest);
        }
        return val;
    })().finally(()=>consensusInFlight.delete(key));
    consensusInFlight.set(key, p);
    return await p ?? null;
}
const WHALE_PRINT_MIN_USD = 250_000;
const flowCache = new Map();
const flowInFlight = new Map();
// per-symbol history ring: 1 point per FRESH sample, cap 60 (~2.5h)
const HISTORY_CAP = 60;
const flowHistory = new Map();
function getFlowStatus() {
    let lastOkAt = null;
    let lastError = null;
    let covered = 0;
    for (const [, e] of flowCache){
        if (Date.now() - e.at < STALE_GRACE) covered++;
        lastOkAt = Math.max(lastOkAt ?? 0, e.at) || null;
    }
    return {
        covered,
        lastOkAt,
        lastError
    };
}
async function fapi(path) {
    const v = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    });
    if (v === null) throw new Error(`fapi ${path} → unavailable`); // preserved throw semantics — allSettled callers treat it as partial absence
    return v;
}
async function fetchFlowMetrics(symbol) {
    const cached = flowCache.get(symbol);
    const cachedTtl = cached?.blind ? BLIND_CACHE_TTL : CACHE_TTL;
    if (cached && Date.now() - cached.at < cachedTtl) return cached.metrics;
    if (cached && Date.now() - cached.at < STALE_GRACE && flowInFlight.has(symbol)) return cached.metrics;
    const existing = flowInFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            const base = symbol.replace("USDT", "");
            const [oiHist, takerLS, crowd, premium, aggTrades, topPos] = await Promise.allSettled([
                fapi(`/futures/data/openInterestHist?symbol=${symbol}&period=5m&limit=13`),
                fapi(`/futures/data/takerlongshortRatio?symbol=${symbol}&period=5m&limit=13`),
                fapi(`/futures/data/globalLongShortAccountRatio?symbol=${symbol}&period=5m&limit=2`),
                fapi(`/fapi/v1/premiumIndex?symbol=${symbol}`),
                fapi(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`),
                fapi(`/futures/data/topLongShortPositionRatio?symbol=${symbol}&period=5m&limit=2`)
            ]);
            // v12.2 TASK-52 — FLOW BRIDGE: when a fapi lane starves (ban/pool silence),
            // recover the recoverable lanes over the bridge instead of sliding into
            // blindness. Honest sourcing: the bundle records the venue that fed it.
            let flowSrc = "BINANCE";
            const srcNote = (s)=>{
                if (flowSrc === "BINANCE") flowSrc = s;
                else if (flowSrc !== s) flowSrc = "MIXED";
            };
            let oi = oiHist.status === "fulfilled" ? oiHist.value : [];
            if (oi.length === 0) {
                const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["bridgeOiHist"])(symbol, "5m", 13).catch(()=>null);
                if (b && b.rows.length > 0) {
                    oi = b.rows.map((r)=>({
                            symbol,
                            sumOpenInterest: String(r.sumOpenInterest),
                            sumOpenInterestValue: String(r.sumOpenInterestValue ?? 0),
                            timestamp: r.timestamp
                        }));
                    srcNote(b.source);
                // v14.0 — OI history is fapi-only (perp-native): rows carry the real
                // notional from Binance. No cross-venue rung exists anymore.
                }
            }
            const taker = takerLS.status === "fulfilled" ? takerLS.value : [];
            const crowdArr = crowd.status === "fulfilled" ? crowd.value : [];
            // crowd/top-trader L/S ratios have NO public equivalent on any other
            // venue — during a fapi starvation they stay null (honest absence).
            let prem = premium.status === "fulfilled" ? premium.value : null;
            if (!prem) {
                // v14.0 — premiumIndex/marketPrice fallback via the Binance composite
                // ticker leg (fapi merged board; funding null on a spot-plane board →
                // the guard below fails honestly when fapi is banned).
                const t = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["futTickerRow"])(symbol).catch(()=>null);
                if (t && t.fundingRate !== null) {
                    prem = {
                        lastFundingRate: String(t.fundingRate),
                        markPrice: String(t.markPrice ?? t.lastPrice)
                    };
                    srcNote("BINANCE");
                }
            }
            let oiDelta10m = null;
            let oiDelta1h = null;
            let oiValueUsd = null;
            if (oi.length >= 3) {
                const last = oi[oi.length - 1];
                const first = oi[0];
                const cur = Number(last.sumOpenInterest);
                oiValueUsd = Number(last.sumOpenInterestValue);
                oiDelta10m = first ? (cur - Number(oi[Math.max(0, oi.length - 3)].sumOpenInterest)) / Number(oi[Math.max(0, oi.length - 3)].sumOpenInterest) * 100 : null;
                oiDelta1h = Number(first.sumOpenInterest) > 0 ? (cur - Number(first.sumOpenInterest)) / Number(first.sumOpenInterest) * 100 : null;
            }
            // CVD proxy from taker ratio series: (ratio−1) averaged, weighted by recency
            let takerMean = null;
            let takerRatio = null;
            if (taker.length >= 2) {
                const ratios = taker.map((t)=>Number(t.buySellRatio));
                takerRatio = ratios[ratios.length - 1];
                takerMean = ratios.reduce((a, b)=>a + b, 0) / ratios.length;
            }
            const crowdLongShort = crowdArr.length > 0 ? Number(crowdArr[crowdArr.length - 1].longShortRatio) : null;
            const crowdLongPct = crowdArr.length > 0 ? Number(crowdArr[crowdArr.length - 1].longAccount) * 100 : null;
            const topPosArr = topPos.status === "fulfilled" ? topPos.value : [];
            const topLongShort = topPosArr.length > 0 ? Number(topPosArr[topPosArr.length - 1].longShortRatio) : null;
            const funding8h = prem ? Number(prem.lastFundingRate) * 100 : null;
            // v6.7: real USD taker flow + whale prints from the same aggTrades pull
            // (trades ≤1000 ≈ last minutes on liquid symbols; windows clipped by T).
            // v12.2 TASK-52 (v14.0): tape ladder — fapi aggTrades → SPOT-MIRROR trades →
            // SPOT-MIRROR trades (spot = last resort: spot flow ≠ perp flow).
            let agg = aggTrades.status === "fulfilled" ? aggTrades.value : [];
            if (agg.length === 0) {
                const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["bridgeTape"])(symbol).catch(()=>null);
                if (b && b.trades.length > 0) {
                    agg = b.trades.map((t)=>({
                            p: t.price,
                            q: t.qty,
                            T: t.time,
                            m: t.isBuyerMaker
                        }));
                    srcNote(b.source);
                }
            }
            const t60 = Date.now() - 60_000;
            const t300 = Date.now() - 300_000;
            let buy60 = 0;
            let sell60 = 0;
            const wp = {
                count: 0,
                totalUsd: 0,
                maxUsd: 0,
                buyUsd: 0,
                sellUsd: 0
            };
            for (const t of agg){
                const usd = t.p * t.q;
                if (t.T >= t60) {
                    if (t.m) sell60 += usd;
                    else buy60 += usd;
                }
                if (t.T >= t300 && usd >= WHALE_PRINT_MIN_USD) {
                    wp.count++;
                    wp.totalUsd += usd;
                    if (usd > wp.maxUsd) wp.maxUsd = usd;
                    if (t.m) wp.sellUsd += usd;
                    else wp.buyUsd += usd;
                }
            }
            const cvdUsd60s = agg.length > 0 ? Math.round(buy60 - sell60) : null;
            const whalePrint5m = wp.count > 0 ? {
                count: wp.count,
                totalUsd: Math.round(wp.totalUsd),
                maxUsd: Math.round(wp.maxUsd),
                buyUsd: Math.round(wp.buyUsd),
                sellUsd: Math.round(wp.sellUsd)
            } : null;
            // v12.2 TASK-52: when the fapi taker-ratio series is absent but a REAL
            // tape exists (bridge), the net-buy % of volume is measured from that
            // same tape — window-capped at 10min (a 1000-trade slice spanning hours
            // on an illiquid symbol is a stale read, not a flow read).
            const winStart = agg.length > 0 ? agg[0].T : 0;
            let buyWin = 0;
            let sellWin = 0;
            for (const t of agg){
                const usd = t.p * t.q;
                if (t.m) sellWin += usd;
                else buyWin += usd;
            }
            const cvdFromTape = agg.length > 0 && buyWin + sellWin > 0 && winStart > 0 && Date.now() - winStart <= 600_000 ? (buyWin - sellWin) / (buyWin + sellWin) * 100 : null;
            const cvdNetPctOfVol = takerMean !== null ? (takerMean - 1) * 100 : cvdFromTape; // % of taker volume net buys
            const metrics = {
                oiDelta10m: oiDelta10m === null ? null : Number(oiDelta10m.toFixed(3)),
                oiDelta1h: oiDelta1h === null ? null : Number(oiDelta1h.toFixed(3)),
                oiValueUsd,
                cvdNetBase: null,
                cvdNetPctOfVol: cvdNetPctOfVol === null ? null : Number(cvdNetPctOfVol.toFixed(3)),
                takerRatio,
                takerMean,
                crowdLongShort,
                crowdLongPct,
                topLongShort: topLongShort === null ? null : Number(topLongShort.toFixed(3)),
                funding8h: funding8h === null ? null : Number(funding8h.toFixed(4)),
                cvdUsd60s,
                whalePrint5m
            };
            const blind = flowCoverageOf(metrics) === 0;
            flowCache.set(symbol, {
                at: Date.now(),
                metrics,
                blind
            });
            flowSrcMap.set(symbol, flowSrc);
            // history ring (fresh samples only)
            if (metrics.oiDelta1h !== null) {
                const ring = flowHistory.get(symbol) ?? [];
                ring.push({
                    at: Date.now(),
                    oiDelta1h: metrics.oiDelta1h
                });
                if (ring.length > HISTORY_CAP) ring.shift();
                flowHistory.set(symbol, ring);
            }
            return metrics;
        } catch  {
            return null;
        } finally{
            flowInFlight.delete(symbol);
        }
    })();
    flowInFlight.set(symbol, p);
    return p;
}
async function ensureFlow(symbols, concurrency = 3) {
    const queue = [
        ...symbols
    ];
    const workers = Array.from({
        length: Math.min(concurrency, queue.length)
    }, async ()=>{
        while(queue.length > 0){
            const s = queue.shift();
            if (s) await fetchFlowMetrics(s);
        }
    });
    await Promise.all(workers);
}
function getFlowHistory(symbol) {
    return flowHistory.get(symbol) ?? [];
}
function fmtUsdShort(v) {
    if (v >= 1e9) return `$${(v / 1e9).toFixed(2)}B`;
    if (v >= 1e6) return `$${(v / 1e6).toFixed(1)}M`;
    return `$${(v / 1e3).toFixed(0)}K`;
}
function detectLiquiditySweep(candles, direction) {
    if (!candles || candles.length < 26) return {
        swept: false,
        supportive: false,
        detail: ""
    };
    const c = candles[candles.length - 1];
    const prior = candles.slice(candles.length - 25, candles.length - 1);
    const swingHigh = Math.max(...prior.map((k)=>k.high));
    const swingLow = Math.min(...prior.map((k)=>k.low));
    const range = c.high - c.low;
    if (range <= 0) return {
        swept: false,
        supportive: false,
        detail: ""
    };
    if (c.high > swingHigh && c.close < swingHigh && (c.high - c.close) / range >= 0.5) {
        const detail = `SMC sweep: bar traded ${((c.high - swingHigh) / swingHigh * 100).toFixed(2)}% above the 24-bar swing high then closed back inside (${Math.round((c.high - c.close) / range * 100)}% rejection wick) — buy-side liquidity grabbed`;
        return {
            swept: true,
            supportive: direction === "SHORT",
            detail: supportive_(detail, direction === "SHORT")
        };
    }
    if (c.low < swingLow && c.close > swingLow && (c.close - c.low) / range >= 0.5) {
        const detail = `SMC sweep: bar pierced ${((swingLow - c.low) / swingLow * 100).toFixed(2)}% below the 24-bar swing low then closed back inside (${Math.round((c.close - c.low) / range * 100)}% rejection wick) — sell-side liquidity grabbed`;
        return {
            swept: true,
            supportive: direction === "LONG",
            detail: supportive_(detail, direction === "LONG")
        };
    }
    return {
        swept: false,
        supportive: false,
        detail: ""
    };
}
function supportive_(detail, ok) {
    return ok ? `${detail}, supports the candidate direction` : detail;
}
async function scoreFlow(symbol, direction, price1hAgoPct) {
    const m = await fetchFlowMetrics(symbol);
    if (!m) {
        return {
            verdict: "UNAVAILABLE",
            score: 0,
            reasons: [
                "flow metrics unavailable — no numbers invented"
            ],
            metrics: {
                oiDelta10m: null,
                oiDelta1h: null,
                oiValueUsd: null,
                cvdNetBase: null,
                cvdNetPctOfVol: null,
                takerRatio: null,
                takerMean: null,
                crowdLongShort: null,
                crowdLongPct: null,
                topLongShort: null,
                funding8h: null,
                cvdUsd60s: null,
                whalePrint5m: null
            },
            oiWeight: 1,
            calibrated: false,
            coverage: 0,
            blind: true
        };
    }
    const coverage = flowCoverageOf(m);
    const dir = direction === "LONG" ? 1 : -1;
    const reasons = [];
    // v12.1 Task-48 ② — HONEST NO-DATA: a fetch that completed with every
    // decision metric null (fapi ban window / budget shed) is BLINDNESS, not a
    // neutral book. The 48h census showed 70% of deploys rode this state while
    // the card read "FLOW-NEUTRAL". Blind flow never votes (score 0) but now
    // carries the NO-DATA verdict so cards, journals and gates can tell the
    // difference. (Gate on blindness = EngineSetting "flow-gate", default
    // tag-only: 10d ledger blind +$204.20 WR 57.1% vs sighted +$7.11 WR 52.8% —
    // blocking the blind cohort would have CUT +$204 of net.)
    if (coverage === 0) {
        return {
            verdict: "NO-DATA",
            score: 0,
            reasons: [
                "flow-blind — every decision metric null (fapi-gate starvation/ban window); no numbers invented, no neutral read claimed"
            ],
            metrics: m,
            oiWeight: 1,
            calibrated: true,
            coverage: 0,
            blind: true
        };
    }
    // v12.2 TASK-52 — honest sourcing: when the bundle rode the bridge, say so
    // on the card/journal instead of silently mixing venues.
    const bridgeSrc = getFlowSource(symbol);
    if (bridgeSrc && bridgeSrc !== "BINANCE") {
        reasons.push(`flow source: ${bridgeSrc} bridge (fapi starved — flow numbers measured on the bridge venue, not Binance)`);
    }
    let raw = 0;
    // 1. CVD imbalance ±9
    if (m.cvdNetPctOfVol !== null) {
        const aligned = m.cvdNetPctOfVol * dir;
        const v = Math.max(-9, Math.min(9, aligned * 1.8));
        raw += v;
        const usdCtx = m.cvdUsd60s !== null ? ` (${m.cvdUsd60s >= 0 ? "+" : ""}$${(m.cvdUsd60s / 1000).toFixed(0)}K net taker USD/60s)` : "";
        reasons.push(`taker CVD ${m.cvdNetPctOfVol >= 0 ? "+" : ""}${m.cvdNetPctOfVol.toFixed(2)}% of taker volume ${aligned > 1 ? "agrees" : aligned < -1 ? "opposes" : "is neutral"}${usdCtx}`);
    }
    // 7. WHALE PRINTS ±5 (v6.7 SMC package): single fills ≥$250K near the entry
    // are the visible footprint of size players — aligned prints confirm, prints
    // against the thesis are distribution risk.
    if (m.whalePrint5m && m.whalePrint5m.totalUsd >= 400_000) {
        const whaleSide = m.whalePrint5m.buyUsd >= m.whalePrint5m.sellUsd ? 1 : -1;
        const aligned = whaleSide * dir;
        const desc = `${m.whalePrint5m.count} fill(s) ≥$250K totaling $${(m.whalePrint5m.totalUsd / 1000).toFixed(0)}K in 5m (max $${(m.whalePrint5m.maxUsd / 1000).toFixed(0)}K, ${m.whalePrint5m.buyUsd >= m.whalePrint5m.sellUsd ? "buy" : "sell"}-side dominant)`;
        if (aligned > 0) {
            raw += 5;
            reasons.push(`WHALE PRINTS ${desc} — pressing WITH the ${direction.toLowerCase()} thesis (smart-money participation)`);
        } else {
            raw -= 5;
            reasons.push(`WHALE PRINTS ${desc} — pressing AGAINST the ${direction.toLowerCase()} thesis (distribution risk)`);
        }
    }
    // 2. OI × price matrix ±7
    if (m.oiDelta1h !== null && price1hAgoPct !== null) {
        const priceDir = price1hAgoPct * dir; // >0: price moving in candidate's favor
        const oiUp = m.oiDelta1h > 0;
        if (priceDir > 0 && oiUp) {
            raw += 7;
            reasons.push(`new positions conviction — price ${price1hAgoPct >= 0 ? "+" : ""}${price1hAgoPct.toFixed(2)}%/1h with OI ${m.oiDelta1h >= 0 ? "+" : ""}${m.oiDelta1h.toFixed(2)}%/1h (fresh ${direction.toLowerCase()}s pressing)`);
        } else if (priceDir > 0 && !oiUp) {
            raw += 2;
            reasons.push(`short-covering style move — OI unwinding ${m.oiDelta1h.toFixed(2)}%/1h while price drifts favorably`);
        } else if (priceDir < 0 && oiUp) {
            raw -= 7;
            reasons.push(`opposing new positions — OI ${m.oiDelta1h.toFixed(2)}%/1h building against the ${direction.toLowerCase()} thesis`);
        } else {
            raw -= 2;
            reasons.push(`capitulation washout pattern — OI and price both unwinding`);
        }
    }
    // 3. REAL liquidation cascade (R16) — exhaustion logic ±3
    const liq = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["liquidationPressure"])(symbol);
    if (liq) {
        if (liq.usd10m >= 400_000) {
            const sideWrecked = direction === "LONG" ? liq.longsUsd10m : liq.shortsUsd10m;
            if (sideWrecked > liq.usd10m * 0.6) {
                raw += 3;
                reasons.push(`REAL liquidation cascade: ${fmtUsdShort(liq.usd10m)} wrecked in 10m — ${direction === "LONG" ? "longs" : "shorts"} flushed (forceOrder), exhaustion tailwind`);
            } else {
                raw -= 1;
                reasons.push(`cascade ${fmtUsdShort(liq.usd10m)} in 10m hit the opposing side — momentum risk`);
            }
        } else {
            reasons.push(`no material liquidation cascade (${fmtUsdShort(liq.usd10m)} in 10m)`);
        }
    }
    // 4. Funding contrarian ±5
    if (m.funding8h !== null) {
        if (m.funding8h > 0.05) {
            const v = dir > 0 ? -5 : 5;
            raw += v;
            reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — crowded longs pay, contrarian edge`);
        } else if (m.funding8h < -0.05) {
            const v = dir > 0 ? 5 : -5;
            raw += v;
            reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — shorts pay, squeeze fuel for longs`);
        } else reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — neutral carry`);
    }
    // 5. Crowd positioning ±4
    if (m.crowdLongShort !== null) {
        if (m.crowdLongShort > 2.2) {
            raw += dir > 0 ? -4 : 4;
            reasons.push(`retail crowd ${m.crowdLongShort.toFixed(2)}:1 long — fade risk on longs`);
        } else if (m.crowdLongShort < 0.5) {
            raw += dir > 0 ? 4 : -4;
            reasons.push(`retail crowd ${m.crowdLongShort.toFixed(2)}:1 (heavy shorts) — contrarian tailwind for longs`);
        }
    }
    // 5b. TOP-TRADER positioning ±4 (v6.7 SMC): the top-20% cohort's POSITION
    // sizing — where size actually sits. Extremes fade; a top-vs-retail DIVERGENCE
    // (smart money leaning where the crowd is not) adds a +2 alignment bonus.
    if (m.topLongShort !== null) {
        if (m.topLongShort > 2) {
            raw += dir > 0 ? -4 : 4;
            reasons.push(`top traders ${m.topLongShort.toFixed(2)}:1 net-LONG by position size — crowded smart-money side, fade risk on longs`);
        } else if (m.topLongShort < 0.5) {
            raw += dir > 0 ? 4 : -4;
            reasons.push(`top traders ${m.topLongShort.toFixed(2)}:1 net-SHORT by position size — crowded smart-money side, tailwind against longs`);
        }
        if (m.crowdLongShort !== null && (m.crowdLongShort > 1.5 && m.topLongShort < 0.8 || m.crowdLongShort < 0.7 && m.topLongShort > 1.5)) {
            const smartSide = m.topLongShort > 1 ? 1 : -1;
            raw += smartSide === dir ? 2 : -2;
            reasons.push(`top-vs-retail divergence: crowd ${m.crowdLongShort.toFixed(2)}:1 vs top traders ${m.topLongShort.toFixed(2)}:1 — size sits with the ${smartSide === 1 ? "longs" : "shorts"}`);
        }
    }
    // 6. Taker acceleration ±5
    if (m.takerRatio !== null && m.takerMean !== null) {
        const accel = m.takerRatio - m.takerMean;
        const aligned = accel * dir;
        if (Math.abs(aligned) > 0.06) {
            raw += Math.max(-5, Math.min(5, aligned * 40));
            reasons.push(`taker buy/sell ${m.takerRatio.toFixed(3)} vs mean ${m.takerMean.toFixed(3)} — ${aligned > 0 ? "accelerating in favor" : "decelerating"}`);
        }
    }
    // OI-notional weighting (v4.5): deep books trusted more
    const oiWeight = m.oiValueUsd ? Math.max(0.5, Math.min(1.2, Math.sqrt(m.oiValueUsd / 50_000_000))) : 1;
    let score = Math.round(Math.max(-25, Math.min(25, raw * oiWeight)));
    if (Math.abs(oiWeight - 1) >= 0.15) reasons.push(`flow weighted ×${oiWeight.toFixed(2)} by OI notional ${fmtUsdShort(m.oiValueUsd ?? 0)} — deep-book flow trusted`);
    // ── v12.9 SECOND-PLANE CONSENSUS (AUDIT-NX3046-20261023, operator mandate
    // «باید از تمام صرافی‌ها مخصوصاً BINANCE تیکت گرفته بشه»; v14.0 Binance-only) ──
    // The bundle rode ONE plane's tape; nothing ever asked a SECOND plane
    // whether the tape agrees. NX-3046: a single-plane JCT tape showed CVD
    // +18.5% OPPOSING the short and OI unwinding — the bundle still rode
    // neutral, and no second plane was consulted. Now: the primary plane's
    // 15m-window (4×5m-bar) direction is compared against the INDEPENDENT
    // Binance plane (fapi-tape → SPOT-MIRROR cross-check; SPOT-MIRROR-tape →
    // gated fapi cross-check). Sign-opposed moves diverging >1.5% clamp
    // conviction to ±6 (below the ±8 CONFIRMS/CONFLICTS line) — cross-plane
    // conflict can never confirm a deploy. 60s per-symbol caches + in-flight
    // dedupe keep the hot path cheap; any fetch failure fails OPEN (consensus
    // simply does not run, no numbers invented). Symbols the second plane
    // cannot price (second rung null) are handled by the engine-side
    // SINGLE-VENUE deploy block.
    const consensusSrc = bridgeSrc ?? null;
    if (consensusSrc) {
        try {
            const pri = await cachedConsensusVal(`PRI5M|${symbol}`, 60_000, async ()=>{
                const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["bridgeKlines"])(symbol, "5m", 4).catch(()=>null);
                if (!r || r.rows.length < 4) return null;
                const o = r.rows[0].open, c = r.rows[r.rows.length - 1].close;
                return {
                    move: o > 0 && c > 0 ? (c - o) / o * 100 : null,
                    source: r.source
                };
            });
            const priMove = pri?.move ?? null;
            let secondName = null;
            let secondMove = null;
            // v14.0 — the second-plane cross-check is Binance-only: the plane the
            // primary did NOT ride (fapi primary → SPOT-MIRROR ladder check;
            // SPOT-MIRROR primary → gated fapi check, honest null when banned).
            if (consensusSrc === "BINANCE") {
                secondName = "BINANCE-SPOT";
                secondMove = await cachedConsensusVal(`SPOT5M|${symbol}`, 60_000, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["spot5mMove"])(symbol));
            } else if (consensusSrc === "SPOT-MIRROR" || consensusSrc === "MIXED") {
                secondName = "BINANCE-FAPI";
                secondMove = await cachedConsensusVal(`FAPI5M|${symbol}`, 60_000, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fapi5mMove"])(symbol));
            }
            if (priMove !== null && secondName && secondMove !== null) {
                const disagree = Math.sign(priMove) !== Math.sign(secondMove) && Math.abs(priMove - secondMove) > 1.5;
                if (disagree) {
                    const cr = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["getCoreRevert"])();
                    if (!cr.enabled) score = Math.max(-6, Math.min(6, score));
                    reasons.push(`MULTI-VENUE DISAGREE: primary ${consensusSrc} 15m-window ${priMove >= 0 ? "+" : ""}${priMove.toFixed(2)}% vs ${secondName} ${secondMove >= 0 ? "+" : ""}${secondMove.toFixed(2)}% — cross-venue tapes conflict${cr.enabled ? " · CORE-REVERT advisory: clamp lifted, telemetry only (v12.7 doctrine)" : ", conviction clamped ±6, cannot CONFIRM (operator mandate: confirmation from all venues, especially Binance — v12.9)"}`);
                } else if (Math.sign(priMove) === Math.sign(secondMove) && Math.abs(priMove - secondMove) <= 1.5) {
                    reasons.push(`MULTI-VENUE AGREE: primary ${consensusSrc} ${priMove >= 0 ? "+" : ""}${priMove.toFixed(2)}% ≈ ${secondName} ${secondMove >= 0 ? "+" : ""}${secondMove.toFixed(2)}% over 15m — cross-venue tape concordant (v12.9)`);
                }
            }
        } catch  {
        /* fail-open — consensus is telemetry, never a wedging gate */ }
    }
    // ── v12.8 SURROGATE-FLOW CAP (AUDIT-20261023, operator mandate «اصلاح
    // پیشنهادی را کامل و مهندسی اجرا کن») ──
    // Forensics NX-3014 (BTWUSDT 03:13Z): the flow bundle read "CONFIRMS +10"
    // while its source was the SPOT-MIRROR bridge (fapi banned) on a symbol whose
    // BINANCE quote was null and whose cross-venue dislocation ran 90-105bps —
    // the price collapsed −4.5% within 48s of deploy (SL −61.2% in 103s). A
    // surrogate venue's tape is REAL tape, but it is the WRONG venue's tape for
    // a Binance-doctrine engine on dislocated micro-caps: it must not be allowed
    // to CONFIRM a deploy. Cap: when the feeding source is not BINANCE, flow
    // conviction is clamped to ±6 — below the ±8 CONFIRMS/CONFLICTS line, so a
    // surrogate bundle can never confirm NOR fully veto; it can still feed the
    // flowVetoScore ≤−4 soft veto (score −5/−6 survives the clamp) and rides as
    // honest telemetry. BINANCE-sourced bundles are untouched.
    //
    // ── v13.3 SURROGATE-FLOW DEMOTE (ch.7 item ①-ب, operator mandate trace
    // 1a1a8ea4186c6571 «پیشنهادات باقی مانده مهندسی را کامل اجرا کن») ──
    // NX-3247 anatomy (engineering report ch.4-1): with fapi starved, the flow
    // verdict was sourced «SPOT-MIRROR bridge» and read CONFLICTS −9 against a
    // REAL Binance-futures buy flow the operator could see — the engine decided
    // with a surrogate's eyes at the exact top. While the fapi plane is starving
    // (global ban window live OR ≥2 egress IPs banned — fapiBanActivity()), a
    // non-BINANCE bundle is demoted to INFORMATIONAL-ONLY: score contribution 0,
    // verdict NEUTRAL, reason carries the demote tag. This branch runs BEFORE the
    // core-revert advisory check — CORE-REVERT restores the v12.7 core, it was
    // never an authorization for surrogate verdict-making during famine. When
    // fapi recovers, the historical v12.8 cap semantics resume unchanged.
    if (bridgeSrc && bridgeSrc !== "BINANCE") {
        const famine = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fapiBanActivity"])().active; // v13.3 ch.7-ب — honest fapi-plane health
        if (famine) {
            score = 0;
            reasons.push(`SURROGATE-FLOW DEMOTE (ch.7-ب): fapi starved + source ${bridgeSrc} → flow bundle is INFORMATIONAL-ONLY this evaluation (score contribution 0, verdict NEUTRAL; NX-3247 CONFLICTS-9-from-mirror forensics — the engine does not decide on a surrogate's eyes while the real perp plane is starved)`);
        } else {
            const crSurrogate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["getCoreRevert"])();
            if (!crSurrogate.enabled) score = Math.max(-6, Math.min(6, score));
            reasons.push(`SURROGATE-FLOW CAP: source ${bridgeSrc} ≠ BINANCE${crSurrogate.enabled ? " · CORE-REVERT advisory: clamp lifted, surrogate tape rides as telemetry (v12.7 doctrine — the +12/+8/cap stack was the no-Binance drought engine)" : " — conviction clamped ±6, surrogate flow cannot CONFIRM a deploy (NX-3014 48s-collapse forensics, v12.8)"}`);
        }
    }
    const verdict = score >= 8 ? "CONFIRMS" : score <= -8 ? "CONFLICTS" : "NEUTRAL";
    return {
        verdict,
        score,
        reasons,
        metrics: m,
        oiWeight: Number(oiWeight.toFixed(2)),
        calibrated: true,
        coverage,
        blind: false,
        source: bridgeSrc ?? undefined
    };
}
}),
"[project]/src/lib/price-armor.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── NEXUS//SIGNALS PRICE-ARMOR (v12.0 · Task 44-① — write-side phantom anchor) ──
// Operator order 2026-10-18: «ترمیم writer فید (خنثی‌سازی anchor فانتوم سمت
// نوشتن، نه فقط deploy)»
//
// FORENSIC ROOT (Task 45/44, hard evidence): Binance serves ZOMBIE spot
// listings — XMRUSDT spot answers lastPrice=118.70 with bidPrice=0 AND
// askPrice=0 (empty order book, frozen delisting-era print) while the real
// perp trades ~592. The v10.16 spot-overlay fallback (fetchTickers) trusted
// that print as source:"live" whenever fapi was IP-banned → the engine WROTE
// 118.7 into MarketAsset and PricePoint → NX-2736/2744 phantom stops (Task 43).
// The v11.9 PHANTOM-FEED gate catches this at DEPLOY time; this module kills
// the class at WRITE time — the tape itself must never carry phantom prints.
//
// Three writer-side weapons:
//   1. ZOMBIE-TICKER REJECTION — a ticker with a two-sided-empty book
//      (bid=0 && ask=0) is not a market; never a terminal price.
//   2. CROSS-PLANE DIVERGENCE GUARD — a spot-overlay quote deviating >10%
//      from the last live-verified perp anchor (or from the venue consensus)
//      is refused as a terminal source (perp↔spot basis is normally <1%;
//      real crashes are fapi/consensus-sourced and unaffected).
//   3. ANCHOR-LOCKED SIM DRIFT — the sim fallback drifts around the last
//      LIVE-verified price (not around MarketAsset.price, which a platform
//      restore can rewind to an era value — the 118.7 anchor class), with a
//      hard ±0.25% excursion cap, and sim ticks NEVER reach PricePoint /
//      tick-archive (a gap in the tape is honest; a phantom print is poison).
//
// Pure + client-safe. Consumers: market-feed (zombie filter), engine writer
// (resolveTerminalPrice), verify scripts (offline decision tests).
/** A ticker that has no two-sided market is a zombie/halted listing. */ __turbopack_context__.s([
    "REWIND_DETECT_PCT",
    ()=>REWIND_DETECT_PCT,
    "SIM_DRIFT_CAP_PCT",
    ()=>SIM_DRIFT_CAP_PCT,
    "SPOT_PERP_DIVERGENCE_PCT",
    ()=>SPOT_PERP_DIVERGENCE_PCT,
    "isTradeableTicker",
    ()=>isTradeableTicker,
    "resolveTerminalPrice",
    ()=>resolveTerminalPrice
]);
function isTradeableTicker(t) {
    const bid = Number(t.bidPrice ?? 0);
    const ask = Number(t.askPrice ?? 0);
    if (!Number.isFinite(bid) || !Number.isFinite(ask)) return true; // fields absent (some planes) → cannot disprove
    return !(bid === 0 && ask === 0);
}
const SPOT_PERP_DIVERGENCE_PCT = 10;
const REWIND_DETECT_PCT = 5;
const SIM_DRIFT_CAP_PCT = 0.25;
const rnd = ()=>Math.random();
function resolveTerminalPrice(inp, jitter = rnd) {
    const { tPrice, tZombie, tSpotOverlay, consMedian, consVenues, anchor, storedPrice } = inp;
    const out = {
        next: 0,
        liveNow: false,
        priceClass: "frozen",
        zombieRejected: false,
        rewound: false
    };
    // ① consensus (≥2 venues, robust median) — always trusted, wins over ticker
    if (consVenues >= 2 && consMedian && consMedian > 0) {
        return {
            ...out,
            next: consMedian,
            liveNow: true,
            priceClass: "live-consensus"
        };
    }
    // ② ticker — but only a tradeable one; the cross-plane divergence guard is
    // SPOT-OVERLAY-ONLY (fapi perp prints are the market itself — a real crash
    // must pass; an overlay quote deviating >10% from the perp truth is zombie-adjacent)
    if (tPrice && tPrice > 0 && !tZombie) {
        let reject = false;
        if (tSpotOverlay) {
            if (consMedian && consMedian > 0 && Math.abs(tPrice - consMedian) / consMedian * 100 > SPOT_PERP_DIVERGENCE_PCT) reject = true;
            if (!reject && anchor && anchor > 0 && Math.abs(tPrice - anchor) / anchor * 100 > SPOT_PERP_DIVERGENCE_PCT) reject = true;
        }
        if (!reject) return {
            ...out,
            next: tPrice,
            liveNow: true,
            priceClass: "live-ticker"
        };
        out.zombieRejected = true;
    } else if (tPrice && tPrice > 0 && tZombie) {
        out.zombieRejected = true;
    }
    // ③ sim drift — ANCHOR-LOCKED: drift around the last live-verified price.
    const base = anchor && anchor > 0 ? anchor : storedPrice;
    if (base > 0) {
        if (anchor && anchor > 0 && storedPrice > 0 && Math.abs(storedPrice - anchor) / anchor * 100 > REWIND_DETECT_PCT) out.rewound = true;
        const walk = base * (1 + (jitter() - 0.5) * 0.001);
        // excursion cap keeps a long outage from walking the sim price away
        const capped = Math.max(base * (1 - SIM_DRIFT_CAP_PCT / 100), Math.min(base * (1 + SIM_DRIFT_CAP_PCT / 100), walk));
        out.next = capped;
        out.liveNow = false;
        out.priceClass = "sim-drift";
        return out;
    }
    // ④ nothing sane — freeze (caller keeps the previous stored price untouched)
    out.next = 0;
    out.priceClass = "frozen";
    return out;
}
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[project]/src/lib/market-feed.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FUTURES_FAPI",
    ()=>FUTURES_FAPI,
    "fetchFuturesKlines",
    ()=>fetchFuturesKlines,
    "fetchFuturesPoolStats",
    ()=>fetchFuturesPoolStats,
    "fetchFuturesSymbols",
    ()=>fetchFuturesSymbols,
    "fetchFuturesUniverse",
    ()=>fetchFuturesUniverse,
    "fetchKlines",
    ()=>fetchKlines,
    "fetchTickers",
    ()=>fetchTickers,
    "futwsQuoteMap",
    ()=>futwsQuoteMap,
    "getFeedStatus",
    ()=>getFeedStatus,
    "getFutwsStatus",
    ()=>getFutwsStatus,
    "markFeedOk",
    ()=>markFeedOk
]);
// ── FlowRadar Neo live market feed (server-only) ──
// Binance REST client: USDT-M FUTURES tickers (primary) + spot overlay for
// spot-only listings + futures universe + klines.
// v10.16 P1 FUTURES PRICE UNIFICATION: perp signals must settle on perp
// prices — /fapi/v1 is now the PRIMARY ticker source; SPOT is only overlaid
// for universe symbols the futures response does not carry, and those rows
// stay source:"live". If BOTH fail the caller's sim fallback is unchanged.
// Resilience ladder: LIVE → STALE (≤5min grace) → SIMULATED drift.
// v10.24 Task 34-a FAPI GATE: every futures (fapi) REST call now goes through
// the process-wide weight gate (src/lib/fapi-gate.ts) — budget, global IP-ban
// awareness and single-flight. SPOT calls (api.binance.com) stay direct —
// they have their own separate IP budget.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)"); // v13.4 spot-print liveness probe
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$price$2d$armor$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/price-armor.ts [instrumentation] (ecmascript)"); // v12.0 Task 44-① zombie-ticker rejection at the feed layer
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [instrumentation] (ecmascript)");
;
;
;
// v13.3 BINANCE-LADDER (trace 1a184429d4bd0d05, restored 1a1849f647778885) —
// full official spot-REST set per binance-spot-api-docs: vision (dedicated
// market-data pool) → api-gcp (official GCP mirror, 200 6/6 @59ms 2026-10-28)
// → api1-4 mirrors → api last. Per-host 418/429 backoff via spot-host-gate.
const BINANCE_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
const FAPI = "https://fapi.binance.com";
// dual-host failover for the futures REST plane — fapi is the ONLY official
// USDT-M futures REST host: fapi1.binance.com probed 2026-10-25 = HTTP 302
// redirect (not an API host) → removed as a dead rung.
const FAPI_HOSTS = [
    "https://fapi.binance.com"
];
const TIMEOUT_MS = 6500;
;
const feedStatus = {
    source: "LIVE",
    lastOkAt: null,
    latencyMs: null,
    consecutiveFailures: 0,
    host: null,
    fallbackVenue: null
};
// v12.5 — throttled telemetry for the fallback rungs (one line / 10min max)
let lastFallbackEventAt = 0;
// ── v13.4 SPOT-PRINT-LIVENESS (trace 1a1849f647778885 — operator mandate:
// «سیستم کاملا از دیتای زنده و لحظه‌ای بایننس استفاده کند») ──────────────────
// price-ws (:3003) owns the hours-proven Binance spot !miniTicker@arr WS and
// pushes ~400 genuine live Binance spot prints into .data/spotws-quotes.json
// EVERY 3s — and since v13.4 it writes the file DIRECTLY (survives app
// restarts). getFeedStatus() recognizes that plane: fresh prints (≤90s,
// exchange timestamps) = LIVE with host labeled spot-ws-ring. 3s memo keeps
// the hot pulse path cheap; REST truth stays in charge when prints age out.
const SPOTWS_FILE = ".data/spotws-quotes.json";
const SPOTWS_FRESH_MS = 90_000;
let spotwsProbe = {
    at: 0,
    fresh: false,
    printAt: null,
    rows: 0
};
// ── v13.5 FUTWS-LIVENESS (trace 1a184d8bbb826f0d) — .data/futws-quotes.json
// is written DIRECTLY by price-ws :3003 every 3s from the futures bookTicker
// ring (43 liquid perps after the v13.5.1 ring repair — 5 entries were
// spot-named/dead and printed zero frames, best bid/ask → mid). Fresh file (≤90s payload) = the
// Binance FUTURES plane is exchange-pushed live: source stays LIVE through
// app restarts, REST pool bans and boot windows, and fetchTickers overlays
// those mids as perp-native quotes (see fetchTickers rung 2). 3s memo keeps
// the hot pulse path cheap.
const FUTWS_FILE = ".data/futws-quotes.json";
const FUTWS_FRESH_MS = 90_000;
let futwsProbe = {
    at: 0,
    fresh: false,
    printAt: null,
    rows: []
};
function futwsLiveness() {
    const now = Date.now();
    if (now - futwsProbe.at < 3_000) return futwsProbe;
    futwsProbe = {
        at: now,
        fresh: false,
        printAt: null,
        rows: []
    };
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(FUTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const rows = Array.isArray(j.rows) ? j.rows : [];
        const payloadAt = Number(j.at) || 0;
        if (payloadAt > 0 && now - payloadAt < FUTWS_FRESH_MS + 10_000 && rows.length > 0) {
            futwsProbe = {
                at: now,
                fresh: true,
                printAt: payloadAt,
                rows
            };
        }
    } catch  {
    /* file missing/unreadable → not fresh; REST truth stays in charge */ }
    return futwsProbe;
}
function getFutwsStatus() {
    const p = futwsLiveness();
    return {
        fresh: p.fresh,
        rows: p.rows.length,
        ageMs: p.printAt ? Date.now() - p.printAt : null
    };
}
function futwsQuoteMap() {
    const out = new Map();
    const p = futwsLiveness();
    if (!p.fresh) return out;
    const now = Date.now();
    for (const r of p.rows){
        if (!r || !r.s || !(r.m > 0)) continue;
        if (now - (r.t ?? 0) > 30_000) continue;
        out.set(r.s, {
            bid: r.b,
            ask: r.a,
            mid: r.m,
            t: r.t
        });
    }
    return out;
}
function spotPrintLiveness() {
    const now = Date.now();
    if (now - spotwsProbe.at < 3_000) return spotwsProbe;
    spotwsProbe = {
        at: now,
        fresh: false,
        printAt: null,
        rows: 0
    };
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(SPOTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const rows = Array.isArray(j.rows) ? j.rows : [];
        const payloadAt = Number(j.at) || 0;
        if (payloadAt > 0 && now - payloadAt < SPOTWS_FRESH_MS + 10_000 && rows.length > 0) {
            spotwsProbe = {
                at: now,
                fresh: true,
                printAt: payloadAt,
                rows: rows.length
            };
        }
    } catch  {
    /* file missing/unreadable → not fresh; REST truth stays in charge */ }
    return spotwsProbe;
}
// v14.3 TICKER-WEIGHT-DETENTE (operator trace 1a1c1ecd9694a129, 2026-11-09) —
// the spot REST overlay used to pull the FULL /api/v3/ticker/24hr board
// (weight 200) on EVERY engine tick (3.5s) while fapi was banned, because the
// futws ring (43 mids) never covers the whole 64-symbol universe. Measured
// fallout: ~11,400+ spot weight/min → family-wide 418 ("IP banned until …",
// host weight1m counters 13,5K–16,1K observed) — which is what kept the
// BINANCE-SPOT / BINANCE-GCP consensus planes dead and the EXCHANGE CONSENSUS
// card unstable even while the WS planes were healthy. New ladder inside
// fetchTickers: rung 2.5 = THIS map (real Binance spot prints pushed by
// price-ws :3003 every 3s — ~439 symbols, ZERO REST weight); rung 3 = REST
// pull ONLY for symbols still missing AND proven spot-listed (membership
// oracle = this file), via the ?symbols= filter (weight 4). Futures-only
// microcaps were NEVER in the spot response (the old full-board pull filtered
// them out locally) — they stay honestly missing, no invented data. If the
// print file is unreadable (price-ws down), rung 3 falls back to the legacy
// full-board pull (old behavior, old weight) so the overlay never goes dark.
function spotwsPrintMap() {
    const out = new Map();
    const now = Date.now();
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(SPOTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const payloadAt = Number(j.at) || 0;
        if (!(payloadAt > 0) || now - payloadAt > SPOTWS_FRESH_MS + 10_000) return out; // stale file — rung skips honestly
        for (const r of Array.isArray(j.rows) ? j.rows : []){
            const sym = String(r?.s ?? "").toUpperCase();
            const p = Number(r?.p);
            const t = Number(r?.t);
            if (!sym.endsWith("USDT") || !(p > 0) || !(t > 0) || now - t > SPOTWS_FRESH_MS) continue;
            out.set(sym, p);
        }
    } catch  {
    /* file missing/unreadable → empty map; legacy rung covers */ }
    return out;
}
function getFeedStatus() {
    // v13.5 — futures bookTicker ring FIRST: a live Binance FUTURES plane beats
    // the spot mirror in the host label (operator mandate «دیتای زندهٔ بایننس
    // فیوچرز»); both files come from the same price-ws :3003 process.
    const futws = futwsLiveness();
    if (futws.fresh) {
        const FUT_HOST = "fut-ws-book + spot-ws-ring (price-ws :3003)";
        if (feedStatus.host !== FUT_HOST) {
            feedStatus.host = FUT_HOST;
            feedStatus.fallbackVenue = null; // native Binance futures plane — no fallback
        }
        // v14.3 STALE-DATA-DEPLOY-FIX (trace 1a1c1ecd9694a129): the reset used to fire
        // only on HOST CHANGE — meanwhile every banned REST rung tick incremented
        // consecutiveFailures, so after a few minutes failures≥3 flagged the feed
        // "stale" in the deploy gate (engine.ts feedStalePre) while the exchange was
        // pushing live prints every 3s. Raw evidence: failures=78 with lastOkAt 2s
        // fresh, RAW-CAL refused with STALE_DATA for 6h (last serial NX-3495).
        // WS-fresh ⇒ LIVE, full stop: REST-failure streaks are superseded data-path
        // noise, not staleness. The counter still tells the truth whenever NO WS
        // plane is fresh (the stale path below keeps accumulating it).
        feedStatus.consecutiveFailures = 0;
        feedStatus.source = "LIVE";
        if (!feedStatus.lastOkAt || Date.now() - feedStatus.lastOkAt > 20_000) feedStatus.lastOkAt = futws.printAt ?? Date.now();
        return {
            ...feedStatus
        };
    }
    const spotws = spotPrintLiveness();
    if (spotws.fresh) {
        // live Binance spot prints ≤90s old — the feed IS live regardless of the
        // REST poller's in-memory state (app restarts, pool bans, boot windows).
        // The host label PREFERS the Binance ring whenever it is fresh — the
        // operator's mandate is «دیتای زندهٔ بایننس»; a fallback REST rung must
        // not mask the Binance plane printing every 3s.
        if (feedStatus.host !== "spot-ws-ring (price-ws :3003)") {
            feedStatus.host = "spot-ws-ring (price-ws :3003)";
            feedStatus.fallbackVenue = "SPOT-MIRROR";
        }
        feedStatus.consecutiveFailures = 0; // v14.3 — same WS-fresh ⇒ LIVE rule as the futws branch above
        feedStatus.source = "LIVE";
        if (!feedStatus.lastOkAt || Date.now() - feedStatus.lastOkAt > 20_000) feedStatus.lastOkAt = spotws.printAt ?? Date.now();
        return {
            ...feedStatus
        };
    }
    if (feedStatus.lastOkAt && feedStatus.source !== "SIMULATED") {
        const age = Date.now() - feedStatus.lastOkAt;
        if (age > 5 * 60_000) return {
            ...feedStatus,
            source: "SIMULATED"
        };
        if (age > 20_000 && feedStatus.source === "LIVE") return {
            ...feedStatus,
            source: "STALE"
        };
    }
    return {
        ...feedStatus
    };
}
function markFeedOk(host) {
    feedStatus.lastOkAt = Date.now();
    feedStatus.latencyMs = null; // non-fapi rung — latency not comparable
    feedStatus.host = host;
    feedStatus.consecutiveFailures = 0;
    // DATA-REVIVAL — honest sourcing: name the Binance plane that actually fed the feed
    feedStatus.fallbackVenue = host.includes("futws") ? "FUTWS-RING" : host.includes("binance.vision") ? "SPOT-MIRROR" : feedStatus.fallbackVenue;
    if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
}
async function fetchJson(path, hosts = BINANCE_HOSTS) {
    let lastErr;
    const ready = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["spotHostsReady"])(hosts); // v13.2.1 — mid-ban hosts are skipped, traffic slides to the healthy rung
    if (ready.length === 0) throw new Error(`spot-host-gate: all hosts mid-ban for ${path}`);
    for (const host of ready){
        const t0 = Date.now();
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["noteSpotHostThrottle"])(host, res.status, res.headers);
                throw new Error(`${host}${path} → ${res.status} (gate armed)`);
            }
            if (!res.ok) throw new Error(`${host}${path} → ${res.status}`);
            const json = await res.json();
            feedStatus.lastOkAt = Date.now();
            feedStatus.latencyMs = Date.now() - t0;
            feedStatus.consecutiveFailures = 0;
            feedStatus.host = host.replace("https://", "");
            feedStatus.fallbackVenue = null; // Binance plane healthy — no fallback active
            if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
            return json;
        } catch (err) {
            lastErr = err;
            feedStatus.consecutiveFailures++;
        }
    }
    throw lastErr;
}
async function fetchTickers(symbols) {
    const out = new Map();
    const want = new Set(symbols);
    // v12.0 price-armor — zombie filter on BOTH planes: a halted/delisted
    // listing (empty book) must never masquerade as a live terminal price.
    const zombie = (t)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$price$2d$armor$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["isTradeableTicker"])(t);
    try {
        const all = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
            priority: "critical",
            weight: 40
        }); // full-universe ticker — heavy, gated
        for (const t of all)if (want.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
            ...t,
            plane: "fapi"
        });
    } catch  {
    /* fall through to the spot overlay below */ }
    const missing = symbols.filter((s)=>!out.has(s));
    // v13.5 FUTWS OVERLAY rung — the live Binance futures bookTicker mid from
    // price-ws :3003. When the fapi board is throttled/banned but the WS ring
    // is printing (it is REST-weight-free), missing symbols get a PERP-NATIVE
    // live price instead of sliding to the spot overlay (basis) or the ring.
    if (missing.length > 0) {
        const fut = futwsQuoteMap();
        for (const s of missing){
            const q = fut.get(s);
            if (!q) continue;
            const t = {
                symbol: s,
                lastPrice: String(q.mid),
                priceChangePercent: "0",
                highPrice: String(q.mid),
                lowPrice: String(q.mid),
                quoteVolume: "0",
                bidPrice: String(q.bid),
                askPrice: String(q.ask),
                plane: "futws"
            };
            if (!zombie(t)) out.set(s, t);
        }
    }
    const stillMissingAfterFutws = symbols.filter((s)=>!out.has(s));
    if (stillMissingAfterFutws.length > 0) {
        // v14.3 rung 2.5 — spotws print file: real Binance spot prints (zero REST
        // weight) cover spot-listed misses before any REST contact is made.
        const spotws = spotwsPrintMap();
        for (const s of stillMissingAfterFutws){
            const p = spotws.get(s);
            if (p === undefined) continue;
            const t = {
                symbol: s,
                lastPrice: String(p),
                priceChangePercent: "0",
                highPrice: String(p),
                lowPrice: String(p),
                quoteVolume: "0",
                plane: "spot"
            };
            if (!zombie(t)) out.set(s, t);
        }
    }
    const stillMissingAfterSpotws = symbols.filter((s)=>!out.has(s));
    if (stillMissingAfterSpotws.length > 0) {
        try {
            // v14.3 rung 3 — REST, oracle-gated: only symbols still missing AND
            // present in the spotws membership file are requested (?symbols= filter,
            // weight 4 instead of the 200-weight full board). Symbols missing from
            // BOTH the futws ring and the spotws file are futures-only microcaps the
            // spot board could never price — the old code burned weight 200 to learn
            // exactly that. No spotws file at all (price-ws down) → legacy full-board
            // fallback so the overlay never goes dark.
            const spotws = spotwsPrintMap();
            const restWant = stillMissingAfterSpotws.filter((s)=>spotws.has(s)).slice(0, 100);
            if (restWant.length > 0) {
                const q = `?symbols=${encodeURIComponent(JSON.stringify(restWant))}`;
                const spot = await fetchJson(`/api/v3/ticker/24hr${q}`);
                for (const t of spot)if (want.has(t.symbol) && !out.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
                    ...t,
                    plane: "spot"
                });
            } else if (spotws.size === 0 && spotPrintLiveness().fresh === false) {
                const spot = await fetchJson("/api/v3/ticker/24hr");
                for (const t of spot)if (want.has(t.symbol) && !out.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
                    ...t,
                    plane: "spot"
                });
            }
        } catch  {
        /* fallback rung below */ }
    }
    // v14.0 BINANCE-ONLY — the v12.5 cross-venue mirror rung is retired. After
    // the futws ring + the spot overlay, futures-only tickers missing from both
    // stay honestly missing when fapi is banned (no invented data, no foreign
    // venue) — the caller falls back to sim drift exactly as documented.
    return out;
}
// identical response mapping for both kline planes (v10.16 — single mapper)
function mapKlines(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5])
        }));
}
async function fetchKlines(symbol, interval, limit) {
    try {
        const spot = await fetchJson(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
        if (spot.length) return mapKlines(spot);
    } catch  {
    /* fapi rung below */ }
    try {
        const perp = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
            priority: "critical"
        });
        if (perp && perp.length) return mapKlines(perp);
    } catch  {
    /* honest failure below */ }
    throw new Error(`fetchKlines: all Binance rungs failed for ${symbol} ${interval}`);
}
async function fetchFuturesKlines(symbol, interval, limit) {
    try {
        const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
            priority: "critical"
        });
        if (raw && raw.length) return mapKlines(raw);
    } catch  {
    /* spot rung below */ }
    try {
        const spot = await fetchJson(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
        if (spot.length) return mapKlines(spot);
    } catch  {
    /* honest failure below */ }
    throw new Error(`fetchFuturesKlines: all Binance rungs failed for ${symbol} ${interval}`);
}
// ── futures-only universe (R15) ───────────────────────────────
const STABLE_BASES = new Set([
    "USDC",
    "FDUSD",
    "TUSD",
    "BUSD",
    "DAI",
    "USDP",
    "EUR",
    "AEUR",
    "USDE",
    "USDS",
    "USR",
    "USDX",
    "USDTB",
    "USD1",
    "USTC",
    "U",
    "RLUSD",
    "PAXG"
]);
const LEVERAGED = /(UP|DOWN|BULL|BEAR)USDT$/;
function isStablePrice(p) {
    return p > 0.985 && p < 1.015;
}
async function fetchFuturesUniverse(n) {
    const tickers = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
        priority: "critical",
        weight: 40
    });
    return tickers.filter((t)=>t.symbol.endsWith("USDT")).filter((t)=>!LEVERAGED.test(t.symbol)).map((t)=>({
            symbol: t.symbol,
            quoteVolume: Number(t.quoteVolume),
            lastPrice: Number(t.lastPrice)
        })).filter((r)=>r.quoteVolume > 1_000_000 && !isStablePrice(r.lastPrice) && !STABLE_BASES.has(r.symbol.replace("USDT", ""))).sort((a, b)=>b.quoteVolume - a.quoteVolume).slice(0, n);
}
async function fetchFuturesSymbols() {
    const info = await fetchJsonFapi("/fapi/v1/exchangeInfo", {
        priority: "critical",
        weight: 1
    });
    return new Set(info.symbols.filter((s)=>s.contractType === "PERPETUAL" && s.status === "TRADING" && s.quoteAsset === "USDT").map((s)=>s.symbol));
}
let poolCache = null;
const POOL_TTL = 15 * 60_000;
// v5.2 TASK-53: persist the last good board so an app restart during an fapi
// ban doesn't zero the POOL readout (23:14Z boot with the ban live did exactly
// that — lastPoolSize seeded from nothing while the ban starved both rungs).
const POOL_FILE = ".data/pool-stats.json";
const POOL_PERSIST_MAX_AGE = 24 * 60 * 60_000;
function persistPool(value) {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const fs = __turbopack_context__.r("[externals]/fs [external] (fs, cjs)");
        fs.writeFileSync(POOL_FILE, JSON.stringify(value), "utf8");
    } catch  {
    /* best-effort telemetry — never a gate */ }
}
function persistedPool() {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const fs = __turbopack_context__.r("[externals]/fs [external] (fs, cjs)");
        const raw = JSON.parse(fs.readFileSync(POOL_FILE, "utf8"));
        if (!raw || typeof raw.totalUsdtPerps !== "number") return null;
        if (Date.now() - new Date(raw.measuredAt).getTime() > POOL_PERSIST_MAX_AGE) return null;
        return {
            ...raw,
            source: "PERSISTED"
        };
    } catch  {
        return null;
    }
}
async function fetchFuturesPoolStats() {
    if (poolCache && Date.now() - poolCache.at < POOL_TTL) return poolCache.value;
    try {
        const tickers = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
            priority: "telemetry",
            weight: 40
        }); // 15min-cached board stat — sheddable
        const usdtPerps = tickers.filter((t)=>t.symbol.endsWith("USDT") && !LEVERAGED.test(t.symbol));
        const value = {
            totalUsdtPerps: usdtPerps.length,
            liquidPool: usdtPerps.filter((t)=>Number(t.quoteVolume) > 1_000_000 && !isStablePrice(Number(t.lastPrice)) && !STABLE_BASES.has(t.symbol.replace("USDT", ""))).length,
            measuredAt: new Date().toISOString(),
            source: "BINANCE-FAPI"
        };
        poolCache = {
            at: Date.now(),
            value
        };
        persistPool(value);
        return value;
    } catch  {
        // fapi banned/unreachable — persisted board (Task 53, v14.0)
        const saved = persistedPool();
        if (saved) {
            poolCache = {
                at: Date.now(),
                value: saved
            };
            return saved;
        }
        return poolCache?.value ?? {
            totalUsdtPerps: 0,
            liquidPool: 0,
            measuredAt: new Date().toISOString(),
            source: "BINANCE-FAPI"
        };
    }
}
const FUTURES_FAPI = FAPI;
// ── v10.24 Task 34-a — gated futures fetch (fapi plane ONLY) ───────────────
// Same contract as fetchJson (resolve JSON or THROW) so every existing caller
// keeps its exact semantics; failures just become MORE common under weight
// pressure / IP bans — by design (callers are throw-tolerant with fallbacks).
// Walks FAPI_HOSTS through the gate: bans/weight are per-IP, so the alt host
// shares the same budget/ban state (a ban nulls the alt attempt instantly).
async function fetchJsonFapi(path, opts) {
    let lastErr;
    for (const host of FAPI_HOSTS){
        const t0 = Date.now();
        const json = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
            ...opts,
            host
        });
        if (json !== null) {
            feedStatus.lastOkAt = Date.now();
            feedStatus.latencyMs = Date.now() - t0;
            feedStatus.consecutiveFailures = 0;
            feedStatus.host = host.replace("https://", "");
            feedStatus.fallbackVenue = null; // Binance plane healthy — no fallback active
            if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
            return json;
        }
        feedStatus.consecutiveFailures++;
        lastErr = new Error(`fapi ${path} unavailable via ${host}`);
    }
    throw lastErr;
}
}),
"[project]/src/lib/volOnset.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ONSET_RULES",
    ()=>ONSET_RULES,
    "coreToTag",
    ()=>coreToTag,
    "detectOnset",
    ()=>detectOnset,
    "getOnsetBoard",
    ()=>getOnsetBoard,
    "isHot",
    ()=>isHot,
    "latestOnsetCore",
    ()=>latestOnsetCore,
    "onsetGateViewFor",
    ()=>onsetGateViewFor,
    "onsetScoreOf",
    ()=>onsetScoreOf,
    "onsetTagFor",
    ()=>onsetTagFor,
    "onsetTagStats",
    ()=>onsetTagStats,
    "resampleTicks",
    ()=>resampleTicks
]);
// ── VOL-ONSET · eruption-bar onset detector (v1 rebuilt 2026-09-07) ──
// Research finding (2026-09-06 session): the |Δ24h| Top-movers board is a
// LAGGING view — by the time a symbol tops the board the move is 6–16h old.
// The LEADING pattern is the "eruption bar": a single 15m candle whose
// |return| ≥ 5× the trailing-24h median |return|. Measured lead: 6–16h
// before board entry; fwd-6h same-direction drift +10.7% avg on 3/3 samples.
//
// CONTRACT (calibration audit 2026-09-06): VOL-ONSET is TELEMETRY ONLY.
// It tags signals + votes 0 in the factor ledger. It NEVER changes score,
// thresholds, sizing or any live gate until the learning loop proves an
// edge on settled outcomes (onsetTagStats).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [instrumentation] (ecmascript)");
;
;
const ONSET_RULES = {
    tfMinutes: 15,
    eruptionMult: 5,
    trailingBars: 96,
    hotMinutes: 90,
    minBars: 110,
    halfLifeMin: 180,
    tickWindowHours: 50
};
function resampleTicks(points, tfMs = ONSET_RULES.tfMinutes * 60_000) {
    const out = [];
    let bucket = -1;
    let cur = null;
    for (const pt of points){
        const b = Math.floor(pt.t / tfMs);
        if (b !== bucket) {
            if (cur) out.push(cur);
            bucket = b;
            cur = {
                openTime: b * tfMs,
                open: pt.p,
                high: pt.p,
                low: pt.p,
                close: pt.p,
                volume: 0
            };
        } else if (cur) {
            cur.high = Math.max(cur.high, pt.p);
            cur.low = Math.min(cur.low, pt.p);
            cur.close = pt.p;
        }
    }
    if (cur) out.push(cur);
    return out;
}
// ── helpers ─────────────────────────────────────────────────────
function median(xs) {
    if (xs.length === 0) return 0;
    const s = [
        ...xs
    ].sort((a, b)=>a - b);
    const mid = s.length >> 1;
    return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}
function percentileRank(xs, v) {
    if (xs.length === 0) return 0.5;
    let below = 0;
    for (const x of xs)if (x <= v) below++;
    return below / xs.length;
}
const clamp01 = (x)=>Math.min(1, Math.max(0, x));
function detectOnset(bars, nowMs = Date.now()) {
    if (!bars || bars.length < ONSET_RULES.minBars) return null;
    const TRAIL = ONSET_RULES.trailingBars;
    const window = bars.slice(-TRAIL);
    const baseline = bars.slice(0, Math.max(0, bars.length - TRAIL));
    if (window.length < TRAIL) return null;
    // median |return| across the trailing window (robust to the eruption itself)
    const absRets = window.map((b, i)=>i === 0 ? 0 : Math.abs((b.close - window[i - 1].close) / window[i - 1].close) * 100);
    const med = median(absRets.slice(1));
    if (!(med > 0)) return null;
    // first eruption bar in the window
    let idx = -1;
    for(let i = 1; i < window.length; i++){
        const prev = window[i - 1];
        const b = window[i];
        const ret = (b.close - prev.close) / prev.close * 100;
        if (Math.abs(ret) >= ONSET_RULES.eruptionMult * med) {
            idx = i;
            break;
        }
    }
    if (idx < 0) return null;
    const erupt = window[idx];
    const prevClose = window[idx - 1].close;
    const eruptRetPct = (erupt.close - prevClose) / prevClose * 100;
    const direction = eruptRetPct >= 0 ? 1 : -1;
    const displacementX = Math.abs(eruptRetPct) / med;
    const minutesSince = Math.max(0, Math.round((nowMs - erupt.openTime) / 60_000));
    // pre-eruption warmth: mean range% of the 8 bars before the eruption,
    // ranked against the baseline distribution ("eruptions start warm,
    // not from dead squeezes" — 2026-09-06 finding: 28–85th pct)
    const preBars = bars.slice(Math.max(0, bars.indexOf(erupt) - 8), bars.indexOf(erupt));
    const preRanges = preBars.map((b)=>(b.high - b.low) / b.close * 100);
    const baseRanges = baseline.map((b)=>(b.high - b.low) / b.close * 100);
    const preRangePct = preRanges.length ? percentileRank(baseRanges, median(preRanges)) : 0.5;
    // pre-eruption slope (%/bar over the same 8 bars)
    let preSlope = 0;
    if (preBars.length >= 2) {
        const first = preBars[0];
        const last = preBars[preBars.length - 1];
        preSlope = (last.close - first.close) / first.close * 100 / (preBars.length - 1);
    }
    // follow-through: drift since the eruption bar close, in eruption direction
    const last = window[window.length - 1];
    const rawFt = (last.close - erupt.close) / erupt.close * 100;
    const followThroughPct = rawFt * direction;
    return {
        eruptionAt: erupt.openTime,
        minutesSince,
        direction,
        eruptRetPct,
        displacementX,
        preRangePct,
        preSlope,
        followThroughPct
    };
}
function onsetScoreOf(core) {
    const displacement = 40 * clamp01((core.displacementX - 1) / 9);
    const recency = 30 * Math.pow(0.5, core.minutesSince / ONSET_RULES.halfLifeMin);
    const ftRatio = clamp01(core.followThroughPct / Math.max(Math.abs(core.eruptRetPct), 0.3));
    let followThrough = 20 * ftRatio;
    if (core.followThroughPct < 0) followThrough = 20 * 0.35 * clamp01(Math.abs(core.followThroughPct) / Math.max(Math.abs(core.eruptRetPct), 0.3));
    const inWarmBelt = core.preRangePct >= 0.28 && core.preRangePct <= 0.85;
    const warming = 10 * (inWarmBelt ? 1 : 0.45);
    return Math.round(Math.min(100, Math.max(0, displacement + recency + followThrough + warming)));
}
function isHot(core) {
    return core.minutesSince <= ONSET_RULES.hotMinutes && core.displacementX >= ONSET_RULES.eruptionMult && (core.followThroughPct >= 0 || Math.abs(core.followThroughPct) < 0.5);
}
function coreToTag(core) {
    const score = onsetScoreOf(core);
    const dir = core.direction === 1 ? "UP" : "DOWN";
    const age = core.minutesSince >= 60 ? `${(core.minutesSince / 60).toFixed(1)}h` : `${core.minutesSince}m`;
    const ft = `${core.followThroughPct >= 0 ? "+" : ""}${core.followThroughPct.toFixed(1)}%`;
    // direction-aware tag (2026-09-07 forward study, n=469): UP-eruptions mean fwd6h +0.88%
    // while DOWN-eruptions mean -1.55% — the calibrator must learn them SEPARATELY.
    const tag = `VOL-ONSET${core.direction === 1 ? "↑" : "↓"}`;
    return {
        hot: isHot(core),
        tag,
        score,
        minutesSince: core.minutesSince,
        direction: dir,
        detail: `15m eruption ×${core.displacementX.toFixed(1)} ${dir.toLowerCase()} ${age} ago · follow-through ${ft} · onset ${score}/100`
    };
}
// ── data sourcing ───────────────────────────────────────────────
async function candlesFromTicks(symbol, windowHours = ONSET_RULES.tickWindowHours) {
    try {
        const since = new Date(Date.now() - windowHours * 3600_000);
        const pts = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].pricePoint.findMany({
            where: {
                symbol,
                createdAt: {
                    gte: since
                }
            },
            orderBy: {
                createdAt: "asc"
            },
            select: {
                price: true,
                createdAt: true
            }
        });
        if (pts.length < ONSET_RULES.minBars * 2) return null; // need density for 15m buckets
        return resampleTicks(pts.map((p)=>({
                t: p.createdAt.getTime(),
                p: p.price
            })));
    } catch  {
        return null;
    }
}
async function onsetTagFor(symbol, candles) {
    try {
        let bars = null;
        let source = "kline";
        if (candles && candles.length >= ONSET_RULES.minBars) {
            bars = candles;
        } else {
            try {
                bars = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(symbol, "15m", 220);
            } catch  {
                bars = null;
            }
        }
        if (!bars || bars.length < ONSET_RULES.minBars) {
            bars = await candlesFromTicks(symbol);
            source = "ticks";
        }
        if (!bars) return null;
        const core = detectOnset(bars);
        if (!core) return null;
        const tag = coreToTag(core);
        void source; // per-symbol source only tracked in board rows
        return tag;
    } catch  {
        return null; // contract: telemetry must never break the deploy path
    }
}
function latestOnsetCore(bars, nowMs = Date.now()) {
    try {
        if (!bars || bars.length < ONSET_RULES.minBars) return null;
        const TRAIL = ONSET_RULES.trailingBars;
        const window = bars.slice(-TRAIL);
        if (window.length < TRAIL) return null;
        const absRets = window.map((b, i)=>i === 0 ? 0 : Math.abs((b.close - window[i - 1].close) / window[i - 1].close) * 100);
        const med = median(absRets.slice(1));
        if (!(med > 0)) return null;
        const tfMs = ONSET_RULES.tfMinutes * 60_000;
        const hotCutoff = nowMs - (ONSET_RULES.hotMinutes + ONSET_RULES.tfMinutes) * 60_000;
        for(let i = window.length - 1; i >= 1; i--){
            const b = window[i];
            if (b.openTime < hotCutoff) return null; // walked past the hot window — nothing fresh
            const ret = (b.close - window[i - 1].close) / window[i - 1].close * 100;
            if (Math.abs(ret) < ONSET_RULES.eruptionMult * med) continue;
            // most recent eruption bar (may be the FORMING bar — intra-bar legs are the storm class)
            const eruptRetPct = ret;
            const direction = eruptRetPct >= 0 ? 1 : -1;
            const minutesSince = Math.max(0, Math.round((nowMs - b.openTime) / 60_000));
            const last = window[window.length - 1];
            const rawFt = (last.close - b.close) / b.close * 100;
            const followThroughPct = rawFt * direction;
            const baseline = bars.slice(0, Math.max(0, bars.length - TRAIL));
            const idx = bars.indexOf(b);
            const preBars = bars.slice(Math.max(0, idx - 8), idx);
            const preRanges = preBars.map((c)=>(c.high - c.low) / c.close * 100);
            const baseRanges = baseline.map((c)=>(c.high - c.low) / c.close * 100);
            const preRangePct = preRanges.length && baseRanges.length ? percentileRank(baseRanges, median(preRanges)) : 0.5;
            let preSlope = 0;
            if (preBars.length >= 2) {
                const first = preBars[0];
                const lastPre = preBars[preBars.length - 1];
                preSlope = (lastPre.close - first.close) / first.close * 100 / (preBars.length - 1);
            }
            return {
                eruptionAt: b.openTime,
                minutesSince,
                direction,
                eruptRetPct,
                displacementX: Math.abs(eruptRetPct) / med,
                preRangePct,
                preSlope,
                followThroughPct
            };
        }
        return null;
    } catch  {
        return null;
    }
}
async function onsetGateViewFor(symbol, candles) {
    try {
        let bars = null;
        if (candles && candles.length >= ONSET_RULES.minBars) {
            bars = candles;
        } else {
            try {
                bars = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(symbol, "15m", 220);
            } catch  {
                bars = null;
            }
        }
        if (!bars || bars.length < ONSET_RULES.minBars) {
            bars = await candlesFromTicks(symbol);
        }
        if (!bars) return null;
        const core = latestOnsetCore(bars);
        if (!core) return null;
        return {
            tag: coreToTag(core),
            core,
            bars
        };
    } catch  {
        return null;
    }
}
let boardCache = null;
let boardBuilding = null;
const BOARD_TTL = 90_000;
// resilience (egress-outage lesson 2026-09-07): never let the route hang on a
// rebuild — answer with the last-good board after this deadline; the rebuild
// keeps running in the background and the next poll picks up fresh rows.
const BOARD_DEADLINE = 12_000;
const BOARD_MAX_SYMBOLS = 48;
const KLINE_CONCURRENCY = 5;
async function detectForSymbol(symbol) {
    let bars = null;
    let source = "kline";
    try {
        bars = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(symbol, "15m", 220);
    } catch  {
        bars = null;
    }
    if (!bars || bars.length < ONSET_RULES.minBars) {
        bars = await candlesFromTicks(symbol);
        source = "ticks";
    }
    if (!bars) return null;
    const core = detectOnset(bars);
    if (!core) return null;
    return {
        symbol,
        score: onsetScoreOf(core),
        hot: isHot(core),
        minutesSince: core.minutesSince,
        direction: core.direction === 1 ? "UP" : "DOWN",
        displacementX: core.displacementX,
        eruptRetPct: core.eruptRetPct,
        followThroughPct: core.followThroughPct,
        source
    };
}
async function rebuildBoard() {
    try {
        const assets = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
            orderBy: {
                volume24h: "desc"
            },
            take: BOARD_MAX_SYMBOLS,
            select: {
                symbol: true
            }
        });
        const rows = [];
        for(let i = 0; i < assets.length; i += KLINE_CONCURRENCY){
            const batch = assets.slice(i, i + KLINE_CONCURRENCY).map((a)=>a.symbol);
            const results = await Promise.all(batch.map((s)=>detectForSymbol(s).catch(()=>null)));
            for (const r of results)if (r) rows.push(r);
        }
        rows.sort((a, b)=>b.score - a.score);
        // only overwrite the cache with a real result — an egress outage must not
        // replace the last-good board with an empty one
        if (rows.length > 0 || !boardCache) boardCache = {
            at: Date.now(),
            rows
        };
    } catch  {
    /* keep last-good boardCache — never throw */ }
}
async function getOnsetBoard() {
    if (boardCache && Date.now() - boardCache.at < BOARD_TTL) {
        return {
            rows: boardCache.rows,
            computedAt: boardCache.at,
            fromCache: true
        };
    }
    // single-flight rebuild + deadline: the caller NEVER waits longer than
    // BOARD_DEADLINE — stale rows beat a hung upstream (2026-09-07 egress outage)
    if (!boardBuilding) boardBuilding = rebuildBoard().finally(()=>{
        boardBuilding = null;
    });
    const raced = await Promise.race([
        boardBuilding.then(()=>"fresh"),
        new Promise((res)=>setTimeout(()=>res("deadline"), BOARD_DEADLINE))
    ]);
    if (raced === "fresh" && boardCache) {
        return {
            rows: boardCache.rows,
            computedAt: boardCache.at,
            fromCache: false
        };
    }
    return {
        rows: boardCache?.rows ?? [],
        computedAt: boardCache?.at ?? Date.now(),
        fromCache: true
    };
}
// ── learning loop: tagged vs rest on SETTLED signals ────────────
// SETTLED = TP1 | TP2 | TP3 | SL | EXPIRED | CLOSED (outcomes known)
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
function groupStats(signals) {
    const n = signals.length;
    const wins = signals.filter((s)=>s.pnlPercent > 0).length;
    const totalNetUsd = signals.reduce((a, s)=>a + s.marginUsd * s.pnlPercent / 100, 0);
    return {
        n,
        wins,
        winRatePct: n > 0 ? Number((wins / n * 100).toFixed(1)) : null,
        avgNetPct: n > 0 ? Number((signals.reduce((a, s)=>a + s.pnlPercent, 0) / n).toFixed(2)) : null,
        totalNetUsd: Number(totalNetUsd.toFixed(2))
    };
}
async function onsetTagStats() {
    try {
        const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                status: {
                    in: [
                        ...SETTLED_STATUSES
                    ]
                }
            },
            select: {
                tags: true,
                direction: true,
                pnlPercent: true,
                marginUsd: true
            }
        });
        const hasTag = (t)=>t.split(",").map((x)=>x.trim()).some((x)=>x.startsWith("VOL-ONSET"));
        const taggedSignals = settled.filter((s)=>hasTag(s.tags));
        const restSignals = settled.filter((s)=>!hasTag(s.tags));
        const aligned = taggedSignals.filter((s)=>s.direction === "LONG" && s.tags.includes("VOL-ONSET↑") || s.direction === "SHORT" && s.tags.includes("VOL-ONSET↓"));
        const counter = taggedSignals.filter((s)=>!aligned.includes(s));
        return {
            settledTotal: settled.length,
            tagged: groupStats(taggedSignals),
            taggedAligned: groupStats(aligned),
            taggedCounter: groupStats(counter),
            rest: groupStats(restSignals)
        };
    } catch  {
        return {
            settledTotal: 0,
            tagged: groupStats([]),
            taggedAligned: groupStats([]),
            taggedCounter: groupStats([]),
            rest: groupStats([])
        };
    }
}
}),
"[project]/src/lib/volCause.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LEARN_GATE",
    ()=>LEARN_GATE,
    "VOL_CAUSES",
    ()=>VOL_CAUSES,
    "captureTopVolCauses",
    ()=>captureTopVolCauses,
    "getVolCauseBoard",
    ()=>getVolCauseBoard,
    "learnVolCauses",
    ()=>learnVolCauses,
    "sessionOf",
    ()=>sessionOf,
    "settlePendingVolCauses",
    ()=>settlePendingVolCauses,
    "volCauseBoost",
    ()=>volCauseBoost
]);
// ── FlowRadar Neo VOL-CAUSE forensics (server-only) ────────────────────────
// Operator request 2026-09-07: «با تحقیق و جستجوی عمیق دلایل شکل گیری
// Top volatility در MARKET MATRIX رو یاد بگیر و در سیستم برای ردیابی و
// یادگیری و استفاده پیاده کن» — WHY do the top-|Δ24h| movers (the MARKET
// MATRIX "Top volatility" board) actually move?
//
// RESEARCH BASIS (web research round 2026-09-07, distilled):
//   1. WHALE-PUSH       — large players accumulate quietly (OI rises) then hit
//                         the tape aggressively (taker CVD aligned with the
//                         move); footprint = OI Δ↑ + CVD↑ same sign as move.
//   2. LIQUIDATION CASCADE — one forced closure pushes price enough to trigger
//                         the next; visible as a burst of liquidation notional
//                         on the side that is being flushed.
//   3. FUNDING-SQUEEZE  — extreme funding marks crowded leverage; the crowded
//                         side becomes cascade fuel when price moves against it.
//   4. OI-SURGE         — OI surges backing a move = NEW positions, not
//                         day-trading noise → continuation fuel (per OI research).
//   5. UNWIND           — OI dropping hard while price moves = deleveraging,
//                         trend fuel draining.
//   6. CROWD-FLUSH      — retail crowd positioned heavily one way gets flushed
//                         (contrarian crowd input, already measured per symbol).
//   7. VOL-ONSET        — our own measured 15m eruption bar (leading, in-system).
//   8. THIN-TAPE        — small open-interest book: modest flow produces
//                         outsized |Δ24h| (weekend/off-hours amplifies).
//   9. SESSION-THIN     — liquidity drains in off-session hours / weekends.
//
// PIPELINE: capture (top-|Δ24h| entries, 6h dedupe) → attribute (transparent
// rule weights) → settle (real fwd 2h/6h returns from futures klines) →
// learn (per-cause expectancy + continuation rate → EngineSetting
// "volcause.study") → use (engine reads volCauseBoost at deploy; learned
// continuation profiles nudge conviction/sizing ONLY after n ≥ 30 ·
// cont ≥ 55% · |mean fwd6h| ≥ 0.12% — otherwise telemetry-only, vote 0).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volOnset$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/volOnset.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [instrumentation] (ecmascript)");
;
;
;
;
;
const VOL_CAUSES = [
    "WHALE-PUSH",
    "LIQ-CASCADE",
    "FUNDING-SQUEEZE",
    "OI-SURGE",
    "UNWIND",
    "CROWD-FLUSH",
    "VOL-ONSET",
    "THIN-TAPE",
    "SESSION-THIN",
    "MOMENTUM-CARRY",
    "MIXED"
];
function sessionOf(d) {
    const day = d.getUTCDay();
    if (day === 0 || day === 6) return "WEEKEND";
    const h = d.getUTCHours();
    if (h >= 13 && h < 21) return "US";
    if (h >= 7 && h < 13) return "EUROPE";
    return "ASIA";
}
// ── attribution: transparent rule weights (research-derived) ────────────────
function attributeCauses(f) {
    const up = f.change24h >= 0;
    const dirSign = up ? 1 : -1;
    const raw = [];
    // 1) WHALE-PUSH — OI rising while aggressive takers push the same way
    const oi = f.oiDelta1h;
    const cvd = f.cvdPct;
    if (oi !== null && cvd !== null && oi >= 1.5 && Math.abs(cvd) >= 2 && Math.sign(cvd) === dirSign) {
        const w = 26 + Math.min(18, oi * 4 + (Math.abs(cvd) - 2) * 2);
        raw.push({
            cause: "WHALE-PUSH",
            w,
            note: `OI +${oi.toFixed(1)}%/1h with taker CVD ${cvd >= 0 ? "+" : ""}${cvd.toFixed(1)}% flowing ${up ? "into" : "against"} the move — large-player accumulation footprint`
        });
    }
    // 2) OI-SURGE — fresh positions backing the move (continuation fuel)
    if (oi !== null && oi >= 3) {
        raw.push({
            cause: "OI-SURGE",
            w: 12 + Math.min(14, (oi - 3) * 2.5),
            note: `open interest surged +${oi.toFixed(1)}%/1h — new positions, not noise, backing the move`
        });
    }
    // 3) UNWIND — deleveraging: OI draining while price moves
    if (oi !== null && oi <= -2) {
        raw.push({
            cause: "UNWIND",
            w: 14 + Math.min(14, Math.abs(oi) * 2.5),
            note: `open interest unwinding ${oi.toFixed(1)}%/1h — forced de-risking driving the tape, fuel draining`
        });
    }
    // 4) LIQ-CASCADE — liquidation burst on the flushed side
    if (f.liqUsd1h !== null && f.liqUsd1h >= 200_000) {
        const flushed = f.liqDominant ?? (up ? "SHORTS" : "LONGS");
        const aligned = up && flushed === "SHORTS" || !up && flushed === "LONGS";
        raw.push({
            cause: "LIQ-CASCADE",
            w: (16 + Math.min(20, f.liqUsd1h / 50_000)) * (aligned ? 1 : 0.5),
            note: `$${Math.round(f.liqUsd1h / 1000)}k liquidated/10m window, ${flushed === "LONGS" ? "longs" : "shorts"} flushed — cascade mechanics in play`
        });
    }
    // 5) FUNDING-SQUEEZE — crowded leverage as cascade fuel
    if (f.funding8h !== null && Math.abs(f.funding8h) >= 0.0005) {
        const crowded = f.funding8h > 0 ? "LONGS" : "SHORTS";
        // the crowded side becomes fuel when the move runs AGAINST it
        const isFuel = !up && crowded === "LONGS" || up && crowded === "SHORTS";
        raw.push({
            cause: "FUNDING-SQUEEZE",
            w: (10 + Math.min(14, (Math.abs(f.funding8h) - 0.0005) * 12_000)) * (isFuel ? 1 : 0.6),
            note: `funding ${(f.funding8h * 100).toFixed(3)}%/8h — ${crowded === "LONGS" ? "longs" : "shorts"} pay to stay crowded; ${isFuel ? "they are the squeeze fuel here" : "crowd aligned with the move (momentum carry)"}`
        });
    }
    // 6) CROWD-FLUSH — retail crowd on the wrong side
    if (f.crowdLS !== null && (!up && f.crowdLS >= 2 || up && f.crowdLS <= 0.8)) {
        raw.push({
            cause: "CROWD-FLUSH",
            w: 12,
            note: `retail crowd ${f.crowdLS >= 1 ? "long-biased" : "short-biased"} (L/S ${f.crowdLS.toFixed(2)}) caught on the wrong side — flush fuel`
        });
    }
    // 7) VOL-ONSET — our measured eruption bar
    if (f.onsetScore !== null && f.onsetScore >= 30) {
        raw.push({
            cause: "VOL-ONSET",
            w: 10 + Math.min(16, f.onsetScore * 0.2),
            note: `15m eruption bar on the radar (onset score ${f.onsetScore}/100) — measured displacement onset`
        });
    }
    // 8) THIN-TAPE — small book amplifies flow
    if (f.oiValueUsd !== null && f.oiValueUsd < 30_000_000) {
        raw.push({
            cause: "THIN-TAPE",
            w: 10,
            note: `open interest only $${(f.oiValueUsd / 1e6).toFixed(1)}M — a thin book amplifies every order`
        });
    }
    // 9) SESSION-THIN — off-hours / weekend liquidity
    if (f.session === "WEEKEND" || f.hourUtc >= 21 || f.hourUtc < 5) {
        raw.push({
            cause: "SESSION-THIN",
            w: 6,
            note: f.session === "WEEKEND" ? "weekend liquidity drain amplifies moves" : `thin ${f.session === "ASIA" ? "pre-Asia" : "late-US"} hours (${String(f.hourUtc).padStart(2, "0")}:00 UTC)`
        });
    }
    // fallback
    if (raw.length === 0) {
        raw.push({
            cause: "MOMENTUM-CARRY",
            w: 20,
            note: "no single dominant footprint — directional drift carried by steady flow"
        });
    }
    const total = raw.reduce((a, r)=>a + r.w, 0);
    const causes = raw.sort((a, b)=>b.w - a.w).slice(0, 4).map((r)=>({
            cause: r.cause,
            weight: Math.round(r.w / total * 100),
            note: r.note
        }));
    const top = causes[0];
    return {
        causes,
        primary: top.weight >= 18 ? top.cause : "MIXED"
    };
}
// ── capture: top-|Δ24h| entries (the MARKET MATRIX board), 6h dedupe ───────
const CAPTURE_TOP_N = 4;
const CAPTURE_THROTTLE_MS = 180_000; // 3min
const DEDUPE_WINDOW_MS = 6 * 3600_000;
const MIN_ABS_RET = 3.5; // |Δ24h| must clear this to be "top volatility" material
let lastCaptureAt = 0;
let captureRunning = false;
async function captureTopVolCauses() {
    if (captureRunning || Date.now() - lastCaptureAt < CAPTURE_THROTTLE_MS) return 0;
    captureRunning = true;
    lastCaptureAt = Date.now();
    try {
        const assets = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
            orderBy: {
                volume24h: "desc"
            },
            take: 60,
            select: {
                symbol: true,
                price: true,
                change24h: true
            }
        });
        const ranked = assets.filter((a)=>Math.abs(a.change24h) >= MIN_ABS_RET).sort((a, b)=>Math.abs(b.change24h) - Math.abs(a.change24h)).slice(0, CAPTURE_TOP_N);
        if (ranked.length === 0) return 0;
        const since = new Date(Date.now() - DEDUPE_WINDOW_MS);
        const recent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findMany({
            where: {
                detectedAt: {
                    gte: since
                },
                symbol: {
                    in: ranked.map((r)=>r.symbol)
                }
            },
            select: {
                symbol: true,
                direction: true
            }
        });
        // v12.11 — DIRECTION-AWARE dedupe (IRYS forensics): the old per-symbol 6h
        // key meant a captured +565% pump BLACKED OUT the following −77.4% collapse
        // (zero DOWN events for 6h). Dedupe is now (symbol, direction) — an UP
        // regime and a DOWN regime are separate events; rank-0 tick-plane rows
        // (TICK-ONSET) participate equally so the slow plane doesn't duplicate them.
        const recentSet = new Set(recent.map((r)=>`${r.symbol}|${r.direction}`));
        const todo = ranked.filter((r)=>!recentSet.has(`${r.symbol}|${r.change24h >= 0 ? "UP" : "DOWN"}`));
        if (todo.length === 0) return 0;
        // onset radar is cached (90s) — read once
        const onset = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volOnset$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["getOnsetBoard"])().catch(()=>null);
        const onsetMap = new Map((onset?.rows ?? []).map((r)=>[
                r.symbol,
                r.score
            ]));
        let created = 0;
        const now = new Date();
        for (const a of todo){
            const [flow, liq] = await Promise.all([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fetchFlowMetrics"])(a.symbol).catch(()=>null),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["liquidationPressure"])(a.symbol).catch(()=>null)
            ]);
            const liqUsd1h = liq ? liq.usd10m * 6 : null; // scale the 10m window to an hour-equivalent (honest: measured 10m × 6)
            const liqDominant = liq ? liq.longsUsd10m >= liq.shortsUsd10m ? "LONGS" : "SHORTS" : null;
            const snap = {
                symbol: a.symbol,
                change24h: a.change24h,
                price: a.price,
                oiDelta10m: flow?.oiDelta10m ?? null,
                oiDelta1h: flow?.oiDelta1h ?? null,
                oiValueUsd: flow?.oiValueUsd ?? null,
                cvdPct: flow?.cvdNetPctOfVol ?? null,
                takerRatio: flow?.takerRatio ?? null,
                crowdLS: flow?.crowdLongShort ?? null,
                funding8h: flow?.funding8h ?? null,
                liqUsd1h,
                liqDominant,
                onsetScore: onsetMap.get(a.symbol) ?? null,
                hourUtc: now.getUTCHours(),
                session: sessionOf(now)
            };
            const { causes, primary } = attributeCauses(snap);
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.create({
                data: {
                    symbol: a.symbol,
                    detectedAt: now,
                    rank: ranked.indexOf(a) + 1,
                    direction: a.change24h >= 0 ? "UP" : "DOWN",
                    change24h: a.change24h,
                    price: a.price,
                    oiDelta10m: snap.oiDelta10m,
                    oiDelta1h: snap.oiDelta1h,
                    oiValueUsd: snap.oiValueUsd,
                    cvdPct: snap.cvdPct,
                    takerRatio: snap.takerRatio,
                    crowdLS: snap.crowdLS,
                    funding8h: snap.funding8h,
                    liqUsd1h: snap.liqUsd1h,
                    onsetScore: snap.onsetScore,
                    hourUtc: snap.hourUtc,
                    session: snap.session,
                    causesJson: JSON.stringify(causes),
                    primaryCause: primary
                }
            });
            created++;
        }
        return created;
    } catch  {
        return 0; // telemetry — never throws
    } finally{
        captureRunning = false;
    }
}
// ── settle: real forward returns from futures klines ────────────────────────
const SETTLE_LOOKBACK_CANDLES = 14; // 1h candles → covers 14h
function priceAt(candles, tMs) {
    const c = candles.find((k)=>k.openTime <= tMs && k.openTime + 3600_000 > tMs);
    return c ? c.close : null;
}
let lastSettleAt = 0;
let settleRunning = false;
async function settlePendingVolCauses() {
    if (settleRunning || Date.now() - lastSettleAt < 120_000) return 0;
    settleRunning = true;
    lastSettleAt = Date.now();
    try {
        const pending = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findMany({
            where: {
                settledAt: null,
                detectedAt: {
                    lt: new Date(Date.now() - 2 * 3600_000)
                }
            },
            orderBy: {
                detectedAt: "asc"
            },
            take: 12
        });
        let n = 0;
        for (const ev of pending){
            let candles = null;
            try {
                candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(ev.symbol, "1h", SETTLE_LOOKBACK_CANDLES);
            } catch  {
                continue; // keep pending — retry next round
            }
            if (!candles || candles.length === 0) continue;
            const t0 = ev.detectedAt.getTime();
            const p2 = priceAt(candles, t0 + 2 * 3600_000);
            const p6 = priceAt(candles, t0 + 6 * 3600_000);
            const ageOk = Date.now() - t0 >= 13 * 3600_000; // beyond kline window → settle with what we have
            if (p6 === null && !ageOk) continue;
            const base = ev.price;
            const data = {
                settledAt: new Date()
            };
            if (p2 !== null) data.fwd2hPct = Number(((p2 - base) / base * 100).toFixed(3));
            if (p6 !== null) data.fwd6hPct = Number(((p6 - base) / base * 100).toFixed(3));
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.update({
                where: {
                    id: ev.id
                },
                data
            });
            n++;
        }
        return n;
    } catch  {
        return 0;
    } finally{
        settleRunning = false;
    }
}
const STUDY_KEY = "volcause.study";
let studyCache = null;
const STUDY_CACHE_TTL = 300_000;
const LEARN_GATE = {
    minN: 30,
    minContPct: 55,
    minAbsFwd: 0.12
};
async function learnVolCauses(force = false) {
    if (!force && studyCache && Date.now() - studyCache.at < STUDY_CACHE_TTL) return studyCache.study;
    try {
        const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findMany({
            where: {
                fwd6hPct: {
                    not: null
                }
            },
            select: {
                causesJson: true,
                primaryCause: true,
                direction: true,
                fwd2hPct: true,
                fwd6hPct: true
            }
        });
        const byCause = new Map();
        const add = (cause, f2, f6, cont)=>{
            const e = byCause.get(cause) ?? {
                n: 0,
                s2: 0,
                s6: 0,
                cont: 0
            };
            e.n++;
            e.s2 += f2 ?? 0;
            e.s6 += f6;
            if (cont) e.cont++;
            byCause.set(cause, e);
        };
        for (const ev of settled){
            const f6 = ev.fwd6hPct ?? 0;
            const cont = ev.direction === "UP" ? f6 > 0 : f6 < 0;
            add(ev.primaryCause, ev.fwd2hPct, f6, cont);
            // also credit attributed causes with meaningful weight
            try {
                const causes = JSON.parse(ev.causesJson);
                for (const c of causes){
                    if (c.cause !== ev.primaryCause && c.weight >= 15) add(c.cause, ev.fwd2hPct, f6, cont);
                }
            } catch  {
            /* single bad row must not kill the study */ }
        }
        const causes = [
            ...byCause.entries()
        ].map(([cause, e])=>{
            const meanFwd6h = Number((e.s6 / e.n).toFixed(3));
            return {
                cause,
                n: e.n,
                meanFwd2h: e.n > 0 ? Number((e.s2 / e.n).toFixed(3)) : null,
                meanFwd6h,
                continuationRatePct: Math.round(e.cont / e.n * 100),
                learnedAllowed: e.n >= LEARN_GATE.minN && e.cont / e.n * 100 >= LEARN_GATE.minContPct && Math.abs(meanFwd6h) >= LEARN_GATE.minAbsFwd
            };
        }).sort((a, b)=>b.n - a.n);
        const allowed = causes.filter((c)=>c.learnedAllowed);
        const study = {
            at: Date.now(),
            settled: settled.length,
            causes,
            verdict: settled.length === 0 ? "NO SETTLED EVENTS YET — the loop settles each capture with real 2h/6h forward returns" : allowed.length > 0 ? `LEARNED CONTINUATION PROFILES ACTIVE: ${allowed.map((c)=>`${c.cause} (n=${c.n}, cont ${c.continuationRatePct}%)`).join(", ")} — engine may nudge conviction/sizing on fresh matching events` : `TELEMETRY-ONLY — no cause has cleared the learned gate (n ≥ ${LEARN_GATE.minN} · cont ≥ ${LEARN_GATE.minContPct}% · |fwd6h| ≥ ${LEARN_GATE.minAbsFwd}%)`
        };
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: STUDY_KEY
            },
            create: {
                key: STUDY_KEY,
                value: JSON.stringify(study)
            },
            update: {
                value: JSON.stringify(study)
            }
        });
        studyCache = {
            at: Date.now(),
            study
        };
        return study;
    } catch  {
        return studyCache?.study ?? null;
    }
}
async function loadStudy() {
    if (studyCache && Date.now() - studyCache.at < STUDY_CACHE_TTL) return studyCache.study;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: STUDY_KEY
            }
        });
        if (!row) return null;
        const study = JSON.parse(row.value);
        studyCache = {
            at: Date.now(),
            study
        };
        return study;
    } catch  {
        return null;
    }
}
async function volCauseBoost(symbol, direction) {
    try {
        const ev = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findFirst({
            where: {
                symbol,
                detectedAt: {
                    gte: new Date(Date.now() - DEDUPE_WINDOW_MS)
                }
            },
            orderBy: {
                detectedAt: "desc"
            }
        });
        if (!ev) return {
            boost: 0,
            cause: null,
            basis: "NO-RECENT-EVENT",
            detail: null
        };
        const study = await loadStudy();
        const attr = JSON.parse(ev.causesJson).filter((c)=>c.weight >= 25).map((c)=>c.cause);
        const candidates = [
            ev.primaryCause,
            ...attr
        ].filter((c, i, arr)=>arr.indexOf(c) === i);
        const eventDir = ev.direction === "UP" ? "LONG" : "SHORT";
        for (const cause of candidates){
            const cs = study?.causes.find((c)=>c.cause === cause);
            if (cs?.learnedAllowed && direction === eventDir) {
                const boost = Math.max(2, Math.min(4, Math.round(Math.abs(cs.meanFwd6h ?? 0) * 10)));
                return {
                    boost,
                    cause,
                    basis: "LEARNED-CONTINUATION",
                    detail: `${cause} continuation profile n=${cs.n} · mean fwd6h ${cs.meanFwd6h !== null ? `${cs.meanFwd6h >= 0 ? "+" : ""}${cs.meanFwd6h}%` : "—"} · cont ${cs.continuationRatePct}%`
                };
            }
        }
        return {
            boost: 0,
            cause: candidates[0] ?? null,
            basis: "TELEMETRY-ONLY",
            detail: `recent top-vol event (${candidates[0] ?? "MIXED"}) — learned gate not cleared for this profile yet`
        };
    } catch  {
        return {
            boost: 0,
            cause: null,
            basis: "UNAVAILABLE",
            detail: null
        };
    }
}
async function getVolCauseBoard() {
    const [events, total, unsettled, study] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findMany({
            orderBy: {
                detectedAt: "desc"
            },
            take: 24
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.count(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].volCauseEvent.count({
            where: {
                settledAt: null
            }
        }),
        loadStudy()
    ]);
    return {
        computedAt: Date.now(),
        rules: {
            capture: `top-${CAPTURE_TOP_N} of MARKET MATRIX (|Δ24h| ≥ ${MIN_ABS_RET}%), 6h dedupe per symbol`,
            settle: "real fwd 2h/6h returns from 1h futures klines",
            learnGate: `n ≥ ${LEARN_GATE.minN} · continuation ≥ ${LEARN_GATE.minContPct}% · |mean fwd6h| ≥ ${LEARN_GATE.minAbsFwd}%`,
            engineUse: "learned profiles nudge conviction (+2..4) and sizing (×1.15) at deploy; otherwise telemetry-only vote 0"
        },
        totals: {
            total,
            unsettled
        },
        study,
        events: events.map((e)=>({
                id: e.id,
                symbol: e.symbol,
                detectedAt: e.detectedAt.toISOString(),
                rank: e.rank,
                direction: e.direction,
                change24h: e.change24h,
                price: e.price,
                oiDelta10m: e.oiDelta10m,
                oiDelta1h: e.oiDelta1h,
                cvdPct: e.cvdPct,
                crowdLS: e.crowdLS,
                funding8h: e.funding8h,
                liqUsd1h: e.liqUsd1h,
                onsetScore: e.onsetScore,
                session: e.session,
                causes: JSON.parse(e.causesJson || "[]"),
                primaryCause: e.primaryCause,
                fwd2hPct: e.fwd2hPct,
                fwd6hPct: e.fwd6hPct,
                settled: e.settledAt !== null
            }))
    };
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__79fbb3a2._.js.map