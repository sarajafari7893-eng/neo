module.exports = [
"[project]/src/lib/db.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client-2c3a283f134fdcb6", () => require("@prisma/client-2c3a283f134fdcb6"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__269fda7f._.js.map