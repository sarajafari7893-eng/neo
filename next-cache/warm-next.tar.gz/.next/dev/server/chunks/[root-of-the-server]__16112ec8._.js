module.exports = [
"[project]/src/lib/liquidations.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLiquidationSnapshot",
    ()=>getLiquidationSnapshot,
    "getLiquidationStatus",
    ()=>getLiquidationStatus,
    "liquidationPressure",
    ()=>liquidationPressure
]);
// ── FlowRadar Neo liquidation feed client (server-only) ──
// Reads mini-services/liq-service (:3010). Honesty contract: when the stream
// is stalled or down we return null — never a fabricated "quiet tape".
const LIQ_URL = process.env.LIQ_SERVICE_URL ?? "http://localhost:3010";
const TIMEOUT_MS = 2500;
const CACHE_TTL = 20_000;
let cache = null;
let inFlight = null;
async function getLiquidationSnapshot() {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.snap;
    if (inFlight) return inFlight;
    inFlight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${LIQ_URL}/liquidations`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (!res.ok) throw new Error(`liq ${res.status}`);
            const snap = await res.json();
            cache = {
                at: Date.now(),
                snap
            };
            return snap;
        } catch  {
            cache = {
                at: Date.now(),
                snap: null
            };
            return null;
        } finally{
            inFlight = null;
        }
    })();
    return inFlight;
}
async function getLiquidationStatus() {
    const snap = await getLiquidationSnapshot();
    if (!snap) return null;
    return {
        online: true,
        ...snap.status
    };
}
async function liquidationPressure(symbol) {
    const snap = await getLiquidationSnapshot();
    if (!snap || snap.status.dataStalled || !snap.status.connected) return null;
    const row = snap.bySymbol[symbol];
    if (!row) return {
        usd10m: 0,
        longsUsd10m: 0,
        shortsUsd10m: 0
    };
    return {
        usd10m: row.usd10m,
        longsUsd10m: row.longsUsd10m,
        shortsUsd10m: row.shortsUsd10m
    };
}
}),
"[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bridgeDepth",
    ()=>bridgeDepth,
    "bridgeKlines",
    ()=>bridgeKlines,
    "bridgeOiHist",
    ()=>bridgeOiHist,
    "bridgeTape",
    ()=>bridgeTape,
    "fapi5mMove",
    ()=>fapi5mMove,
    "futTickerMap",
    ()=>futTickerMap,
    "futTickerRow",
    ()=>futTickerRow,
    "spot5mMove",
    ()=>spot5mMove,
    "spotMirrorDepth",
    ()=>spotMirrorDepth,
    "spotMirrorKlines",
    ()=>spotMirrorKlines,
    "spotMirrorTape",
    ()=>spotMirrorTape
]);
// ── FlowRadar Neo FLOW BRIDGE (server-only, v14.0 BINANCE-ONLY) ──
// Operator mandate (trace 1a185042c872b4f9 — «ردپای OKX/Bybit در کجا وجود
// دارد و با بایننس جایگزین شود»): the v12.2 cross-venue bridge is retired.
// Every ladder is now BINANCE-ONLY, riding the two independent Binance REST
// planes measured live from this egress:
//
//  ① fapi plane — gated (fapi-gate, weight budget, ban ledger), perp-native.
//  ② SPOT-MIRROR plane — the v13.3 spot-host ladder (data-api.binance.vision
//     → api-gcp → api1-4 → api.binance.com) with the shared per-host 418/429
//     gate: SEPARATE ban pool from fapi, SAME kline shape (field-9 taker
//     volume intact), zero fapi weight.
//
// LADDERS (best → last): klines fapi→SPOT-MIRROR · tape fapi→SPOT-MIRROR ·
// OI history fapi (perp-native — no spot equivalent, honest null on ban) ·
// depth fapi→SPOT-MIRROR · batched tickers fapi(composite)→SPOT-MIRROR.
// HONESTY LAWS unchanged: a plane that fails degrades to null — never to
// invented data; every result carries its SOURCE so cards/journals say which
// Binance plane the number came from. crowd/top-trader L/S ratios stay
// Binance-only and honestly null. FLAT-10 engine policy untouched.
//
// Note: 1000X-style perp symbols (1000PEPEUSDT…) have no spot pair — the
// SPOT-MIRROR rung 404s on them and the ladder ends honestly (fapi rung
// serves them whenever the gate is open).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
const TIMEOUT_MS = 6500;
async function jfetch(url, init) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
    try {
        const res = await fetch(url, {
            ...init,
            signal: ctrl.signal,
            cache: "no-store"
        });
        if (!res.ok) return null;
        return await res.json();
    } catch  {
        return null;
    } finally{
        clearTimeout(timer);
    }
}
// ── klines rungs ────────────────────────────────────────────────────────
// ── v13.2 SPOT-HOST LADDER (operator mandate trace 1a1704d407f00dad —
// «از data-api.binance.vision استفاده کن؛ جریان زندهٔ لحظه‌ای باید با بایننس
// باشد»): measured live 2026-10-25 — data-api.binance.vision 32/32 HTTP 200
// p50 57ms while api.binance.com rides 418 ban-storms from this shared egress.
// v13.2.3 (trace 1a170bba02dff781): api1-4 added as mid rungs, api last.
// v14.0: this ladder is now the ONLY fallback plane (Binance-only mandate).
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
// v13.2.1 — per-host 418/429 backoff via the shared spot-host gate: a banned
// rung is SKIPPED (not re-poked every tick) and traffic slides to the healthy
// host until retry-after expires (live evidence: vision 418 @467wt/min while
// jfetch swallowed the status and kept hammering).
async function spotLadderFetch(path) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotLadderJson"])(path, SPOT_HOSTS, TIMEOUT_MS);
}
function binanceKlineRows(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5]),
            takerBuyBase: Number(k[9])
        }));
}
async function spotMirrorKlines(symbol, interval, limit) {
    const spot = await spotLadderFetch(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
    if (!spot || spot.length === 0) return null;
    return binanceKlineRows(spot);
}
async function bridgeKlines(symbol, interval, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.length > 0) return {
        rows: binanceKlineRows(raw),
        source: "BINANCE"
    };
    const spot = await spotMirrorKlines(symbol, interval, limit).catch(()=>null);
    if (spot && spot.length > 0) return {
        rows: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function spotMirrorTape(symbol) {
    const spot = await spotLadderFetch(`/api/v3/trades?symbol=${symbol}&limit=1000`);
    if (!spot || spot.length === 0) return null;
    return spot.map((t)=>({
            price: Number(t.price),
            qty: Number(t.qty),
            quoteQty: Number(t.quoteQty) || Number(t.price) * Number(t.qty),
            isBuyerMaker: t.isBuyerMaker,
            time: t.time
        }));
}
async function bridgeTape(symbol) {
    const agg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (agg && agg.length > 0) {
        return {
            trades: agg.map((t)=>({
                    price: Number(t.p),
                    qty: Number(t.q),
                    quoteQty: Number(t.p) * Number(t.q),
                    isBuyerMaker: t.m,
                    time: t.T
                })),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorTape(symbol).catch(()=>null);
    if (spot && spot.length > 0) return {
        trades: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function bridgeOiHist(symbol, period, limit) {
    const f = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/futures/data/openInterestHist?symbol=${symbol}&period=${period}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (f && f.length > 0) {
        return {
            rows: f.map((h)=>({
                    sumOpenInterest: Number(h.sumOpenInterest),
                    sumOpenInterestValue: Number(h.sumOpenInterestValue),
                    timestamp: h.timestamp
                })),
            source: "BINANCE"
        };
    }
    return null;
}
async function spotMirrorDepth(symbol, limit) {
    const steps = [
        5,
        10,
        20,
        50,
        100,
        500
    ];
    const lv = steps.find((s)=>s >= limit) ?? 500;
    const raw = await spotLadderFetch(`/api/v3/depth?symbol=${symbol}&limit=${lv}`);
    if (!raw || raw.bids.length === 0 || raw.asks.length === 0) return null;
    return {
        bids: raw.bids.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        asks: raw.asks.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        source: "SPOT-MIRROR"
    };
}
async function bridgeDepth(symbol, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/depth?symbol=${symbol}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.bids.length > 0 && raw.asks.length > 0) {
        return {
            bids: raw.bids.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            asks: raw.asks.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorDepth(symbol, limit).catch(()=>null);
    if (spot) return spot;
    return null;
}
// ── batched tickers — funding + mark + 24h board for the WHOLE domain ──────
// v14.0 BINANCE-ONLY composite: ONE gated /fapi/v1/ticker/24hr (weight 40) +
// ONE gated /fapi/v1/premiumIndex batch (weight 10) merged per symbol. On a
// fapi ban the SPOT-MIRROR ticker batch prices the board (mark/funding/OI
// honestly null — spot plane carries no perp derivatives).
const TICKERS_TTL = 15_000;
let tickCache = null;
let tickInFlight = null;
async function futTickerMap() {
    if (tickCache && Date.now() - tickCache.at < TICKERS_TTL) return tickCache.map;
    if (tickInFlight) return tickInFlight;
    tickInFlight = (async ()=>{
        const out = new Map();
        const [board, prem] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/ticker/24hr", {
                priority: "telemetry",
                weight: 40,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/premiumIndex", {
                priority: "telemetry",
                weight: 10,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null)
        ]);
        if (board && board.length > 0) {
            const premMap = new Map((prem ?? []).map((p)=>[
                    p.symbol,
                    p
                ]));
            for (const r of board){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                const pm = premMap.get(r.symbol);
                const mark = Number(pm?.markPrice) || null;
                const funding = Number(pm?.lastFundingRate);
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: mark,
                    fundingRate: Number.isFinite(funding) && pm ? funding : null,
                    nextFundingTime: Number(pm?.nextFundingTime) || null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "BINANCE"
                });
            }
            tickCache = {
                at: Date.now(),
                map: out,
                src: "BINANCE"
            };
            return out;
        }
        // fapi banned — SPOT-MIRROR board (price-only rows, honest nulls on perp fields)
        const spot = await spotLadderFetch("/api/v3/ticker/24hr");
        if (spot && spot.length > 0) {
            for (const r of spot){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: null,
                    fundingRate: null,
                    nextFundingTime: null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "SPOT-MIRROR"
                });
            }
        }
        tickCache = {
            at: Date.now(),
            map: out,
            src: "SPOT-MIRROR"
        };
        return out;
    })();
    try {
        return await tickInFlight;
    } finally{
        tickInFlight = null;
    }
}
async function futTickerRow(symbol) {
    const map = await futTickerMap().catch(()=>new Map());
    const row = map.get(symbol);
    if (!row) return null;
    // v14.0 — OI enrichment: /fapi/v1/openInterest is per-symbol (weight 1);
    // fill it only for rows priced by the fapi plane and only when missing.
    if (row.source === "BINANCE" && row.openInterest === null) {
        const oi = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/openInterest?symbol=${symbol}`, {
            priority: "telemetry",
            timeoutMs: 4000
        }).catch(()=>null);
        const v = Number(oi?.openInterest);
        if (Number.isFinite(v) && v > 0) {
            row.openInterest = v;
            if (row.markPrice) row.openInterestValue = v * row.markPrice;
        }
    }
    return row;
}
async function spot5mMove(symbol) {
    const rows = await spotMirrorKlines(symbol, "5m", 4);
    if (!rows || rows.length < 4) return null;
    const open = rows[0].open;
    const close = rows[rows.length - 1].close;
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
async function fapi5mMove(symbol) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=4`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (!raw || raw.length < 4) return null;
    const open = Number(raw[0][1]);
    const close = Number(raw[raw.length - 1][4]);
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
}),
"[project]/src/lib/core-revert.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCoreRevert",
    ()=>getCoreRevert
]);
// ── NEXUS//SIGNALS v13.0 CORE-REVERT knob (server-only) ──
// Operator mandate 2026-10-24 («پیشنهاد من سیستم به همان وضعیت برگردد و با
// دیتای موجود نقاط ضعف را فیلتر کند») after the W42 performance audit:
//   · v12.7 era (10-21 → 10-23 15:18): 111 signals, WR 60.4%, +$39.74,
//     median event→entry delay 13.2min — the SUCCESSFUL core configuration.
//   · v12.8/v12.9 era (10-23 15:31 → now): confirmation stack (CHASE-EXTREME,
//     FLUSH-EXHAUSTION/KNIFE-CATCH/STOP-FLOOR, SINGLE-VENUE, NO-BINANCE +12,
//     SURROGATE-FLOW cap, MULTI-VENUE clamp, STALE-BAR) DOUBLED the median
//     delay to 27.4min and starved the board behind a 200+ veto wall, while
//     the hard-SL class it targeted kept printing (7× −61.2% on 10-24 alone).
// enabled=true (default) → the v12.8+ hard gates become ADVISORY: they keep
// journaling (gate-journal audit trail preserved for future recalibration)
// but never refuse a deploy — deploy semantics return to the v12.7 core.
// Weaknesses are filtered from EXISTING data instead (STALE-CHASE gate +
// REARM-BRAKE-BE window in engine.ts), not by new blocking regimes.
// enabled=false → exact v12.9 blocking behavior, one EngineSetting flip.
// Cached 30s per process; fail-open to the operator mandate default.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const DEFAULT_CFG = {
    enabled: true
};
const CACHE_MS = 30_000;
const g = globalThis;
async function getCoreRevert() {
    const hit = g.__nexusCoreRevert;
    if (hit && Date.now() - hit.at < CACHE_MS) return hit.val;
    let val = {
        ...DEFAULT_CFG
    };
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "core-revert"
            }
        });
        if (row) {
            const p = JSON.parse(row.value);
            if (typeof p.enabled === "boolean") val = {
                enabled: p.enabled
            };
        }
    } catch  {
    /* fail-open → operator-mandate default (enabled) */ }
    g.__nexusCoreRevert = {
        at: Date.now(),
        val
    };
    return val;
}
}),
"[project]/src/lib/flow.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WHALE_PRINT_MIN_USD",
    ()=>WHALE_PRINT_MIN_USD,
    "detectLiquiditySweep",
    ()=>detectLiquiditySweep,
    "ensureFlow",
    ()=>ensureFlow,
    "fetchFlowMetrics",
    ()=>fetchFlowMetrics,
    "flowCoverageOf",
    ()=>flowCoverageOf,
    "getFlowHistory",
    ()=>getFlowHistory,
    "getFlowSource",
    ()=>getFlowSource,
    "getFlowStatus",
    ()=>getFlowStatus,
    "scoreFlow",
    ()=>scoreFlow
]);
// ── FlowRadar Neo order-flow module (server-only) ──
// Real Binance USDT-M flow metrics: OI delta, taker CVD, crowd L/S, funding.
// scoreFlow → ±25 along candidate direction · OI-notional weighting (v4.5)
// · in-memory per-symbol history ring for sparklines (R17).
// v10.24 Task 34-a: fapi REST now goes through the process-wide fapi-gate
// (weight budget + global ban awareness + single-flight). Telemetry lane —
// sheddable under pressure; every caller is throw/null-tolerant already.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)"); // v13.3 — ch.7-ب: honest fapi-plane health for the surrogate demote
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/core-revert.ts [app-route] (ecmascript)"); // v13.0 CORE-REVERT — operator revert mandate
;
;
;
;
const TIMEOUT_MS = 6500;
const CACHE_TTL = 150_000; // 2.5min
const STALE_GRACE = 600_000; // 10min
/** Decision-relevant metric keys — cvdNetBase is structurally null in the
 *  current pipeline and excluded from coverage on purpose. */ const COVERAGE_KEYS = [
    "oiDelta10m",
    "oiDelta1h",
    "oiValueUsd",
    "cvdNetPctOfVol",
    "takerRatio",
    "takerMean",
    "crowdLongShort",
    "topLongShort",
    "funding8h",
    "cvdUsd60s"
];
function flowCoverageOf(m) {
    return COVERAGE_KEYS.reduce((a, k)=>a + (m[k] != null ? 1 : 0), 0);
}
const BLIND_CACHE_TTL = 20_000; // v12.1: all-null metrics are a STARVATION state,
// v12.2 TASK-52 — venue that fed the last metrics bundle per symbol
const flowSrcMap = new Map();
function getFlowSource(symbol) {
    return flowSrcMap.get(symbol) ?? null;
}
// v12.9 MULTI-VENUE CONSENSUS — per-key 60s cache + in-flight dedupe so the
// second-venue cross-check costs at most ONE fetch per venue per minute per
// symbol on the hot path. Fail-soft: any throw → cached null → consensus
// skips (never blocks, never invents).
const consensusCache = new Map();
const consensusInFlight = new Map();
async function cachedConsensusVal(key, ttlMs, fn) {
    const hit = consensusCache.get(key);
    if (hit && Date.now() - hit.at < ttlMs) return hit.val ?? null;
    const inflight = consensusInFlight.get(key);
    if (inflight) return await inflight ?? null;
    const p = (async ()=>{
        let val = null;
        try {
            val = await fn();
        } catch  {
            val = null;
        }
        consensusCache.set(key, {
            at: Date.now(),
            val
        });
        if (consensusCache.size > 800) {
            const oldest = consensusCache.keys().next().value;
            if (oldest) consensusCache.delete(oldest);
        }
        return val;
    })().finally(()=>consensusInFlight.delete(key));
    consensusInFlight.set(key, p);
    return await p ?? null;
}
const WHALE_PRINT_MIN_USD = 250_000;
const flowCache = new Map();
const flowInFlight = new Map();
// per-symbol history ring: 1 point per FRESH sample, cap 60 (~2.5h)
const HISTORY_CAP = 60;
const flowHistory = new Map();
function getFlowStatus() {
    let lastOkAt = null;
    let lastError = null;
    let covered = 0;
    for (const [, e] of flowCache){
        if (Date.now() - e.at < STALE_GRACE) covered++;
        lastOkAt = Math.max(lastOkAt ?? 0, e.at) || null;
    }
    return {
        covered,
        lastOkAt,
        lastError
    };
}
async function fapi(path) {
    const v = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    });
    if (v === null) throw new Error(`fapi ${path} → unavailable`); // preserved throw semantics — allSettled callers treat it as partial absence
    return v;
}
async function fetchFlowMetrics(symbol) {
    const cached = flowCache.get(symbol);
    const cachedTtl = cached?.blind ? BLIND_CACHE_TTL : CACHE_TTL;
    if (cached && Date.now() - cached.at < cachedTtl) return cached.metrics;
    if (cached && Date.now() - cached.at < STALE_GRACE && flowInFlight.has(symbol)) return cached.metrics;
    const existing = flowInFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            const base = symbol.replace("USDT", "");
            const [oiHist, takerLS, crowd, premium, aggTrades, topPos] = await Promise.allSettled([
                fapi(`/futures/data/openInterestHist?symbol=${symbol}&period=5m&limit=13`),
                fapi(`/futures/data/takerlongshortRatio?symbol=${symbol}&period=5m&limit=13`),
                fapi(`/futures/data/globalLongShortAccountRatio?symbol=${symbol}&period=5m&limit=2`),
                fapi(`/fapi/v1/premiumIndex?symbol=${symbol}`),
                fapi(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`),
                fapi(`/futures/data/topLongShortPositionRatio?symbol=${symbol}&period=5m&limit=2`)
            ]);
            // v12.2 TASK-52 — FLOW BRIDGE: when a fapi lane starves (ban/pool silence),
            // recover the recoverable lanes over the bridge instead of sliding into
            // blindness. Honest sourcing: the bundle records the venue that fed it.
            let flowSrc = "BINANCE";
            const srcNote = (s)=>{
                if (flowSrc === "BINANCE") flowSrc = s;
                else if (flowSrc !== s) flowSrc = "MIXED";
            };
            let oi = oiHist.status === "fulfilled" ? oiHist.value : [];
            if (oi.length === 0) {
                const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeOiHist"])(symbol, "5m", 13).catch(()=>null);
                if (b && b.rows.length > 0) {
                    oi = b.rows.map((r)=>({
                            symbol,
                            sumOpenInterest: String(r.sumOpenInterest),
                            sumOpenInterestValue: String(r.sumOpenInterestValue ?? 0),
                            timestamp: r.timestamp
                        }));
                    srcNote(b.source);
                // v14.0 — OI history is fapi-only (perp-native): rows carry the real
                // notional from Binance. No cross-venue rung exists anymore.
                }
            }
            const taker = takerLS.status === "fulfilled" ? takerLS.value : [];
            const crowdArr = crowd.status === "fulfilled" ? crowd.value : [];
            // crowd/top-trader L/S ratios have NO public equivalent on any other
            // venue — during a fapi starvation they stay null (honest absence).
            let prem = premium.status === "fulfilled" ? premium.value : null;
            if (!prem) {
                // v14.0 — premiumIndex/marketPrice fallback via the Binance composite
                // ticker leg (fapi merged board; funding null on a spot-plane board →
                // the guard below fails honestly when fapi is banned).
                const t = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerRow"])(symbol).catch(()=>null);
                if (t && t.fundingRate !== null) {
                    prem = {
                        lastFundingRate: String(t.fundingRate),
                        markPrice: String(t.markPrice ?? t.lastPrice)
                    };
                    srcNote("BINANCE");
                }
            }
            let oiDelta10m = null;
            let oiDelta1h = null;
            let oiValueUsd = null;
            if (oi.length >= 3) {
                const last = oi[oi.length - 1];
                const first = oi[0];
                const cur = Number(last.sumOpenInterest);
                oiValueUsd = Number(last.sumOpenInterestValue);
                oiDelta10m = first ? (cur - Number(oi[Math.max(0, oi.length - 3)].sumOpenInterest)) / Number(oi[Math.max(0, oi.length - 3)].sumOpenInterest) * 100 : null;
                oiDelta1h = Number(first.sumOpenInterest) > 0 ? (cur - Number(first.sumOpenInterest)) / Number(first.sumOpenInterest) * 100 : null;
            }
            // CVD proxy from taker ratio series: (ratio−1) averaged, weighted by recency
            let takerMean = null;
            let takerRatio = null;
            if (taker.length >= 2) {
                const ratios = taker.map((t)=>Number(t.buySellRatio));
                takerRatio = ratios[ratios.length - 1];
                takerMean = ratios.reduce((a, b)=>a + b, 0) / ratios.length;
            }
            const crowdLongShort = crowdArr.length > 0 ? Number(crowdArr[crowdArr.length - 1].longShortRatio) : null;
            const crowdLongPct = crowdArr.length > 0 ? Number(crowdArr[crowdArr.length - 1].longAccount) * 100 : null;
            const topPosArr = topPos.status === "fulfilled" ? topPos.value : [];
            const topLongShort = topPosArr.length > 0 ? Number(topPosArr[topPosArr.length - 1].longShortRatio) : null;
            const funding8h = prem ? Number(prem.lastFundingRate) * 100 : null;
            // v6.7: real USD taker flow + whale prints from the same aggTrades pull
            // (trades ≤1000 ≈ last minutes on liquid symbols; windows clipped by T).
            // v12.2 TASK-52 (v14.0): tape ladder — fapi aggTrades → SPOT-MIRROR trades →
            // SPOT-MIRROR trades (spot = last resort: spot flow ≠ perp flow).
            let agg = aggTrades.status === "fulfilled" ? aggTrades.value : [];
            if (agg.length === 0) {
                const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeTape"])(symbol).catch(()=>null);
                if (b && b.trades.length > 0) {
                    agg = b.trades.map((t)=>({
                            p: t.price,
                            q: t.qty,
                            T: t.time,
                            m: t.isBuyerMaker
                        }));
                    srcNote(b.source);
                }
            }
            const t60 = Date.now() - 60_000;
            const t300 = Date.now() - 300_000;
            let buy60 = 0;
            let sell60 = 0;
            const wp = {
                count: 0,
                totalUsd: 0,
                maxUsd: 0,
                buyUsd: 0,
                sellUsd: 0
            };
            for (const t of agg){
                const usd = t.p * t.q;
                if (t.T >= t60) {
                    if (t.m) sell60 += usd;
                    else buy60 += usd;
                }
                if (t.T >= t300 && usd >= WHALE_PRINT_MIN_USD) {
                    wp.count++;
                    wp.totalUsd += usd;
                    if (usd > wp.maxUsd) wp.maxUsd = usd;
                    if (t.m) wp.sellUsd += usd;
                    else wp.buyUsd += usd;
                }
            }
            const cvdUsd60s = agg.length > 0 ? Math.round(buy60 - sell60) : null;
            const whalePrint5m = wp.count > 0 ? {
                count: wp.count,
                totalUsd: Math.round(wp.totalUsd),
                maxUsd: Math.round(wp.maxUsd),
                buyUsd: Math.round(wp.buyUsd),
                sellUsd: Math.round(wp.sellUsd)
            } : null;
            // v12.2 TASK-52: when the fapi taker-ratio series is absent but a REAL
            // tape exists (bridge), the net-buy % of volume is measured from that
            // same tape — window-capped at 10min (a 1000-trade slice spanning hours
            // on an illiquid symbol is a stale read, not a flow read).
            const winStart = agg.length > 0 ? agg[0].T : 0;
            let buyWin = 0;
            let sellWin = 0;
            for (const t of agg){
                const usd = t.p * t.q;
                if (t.m) sellWin += usd;
                else buyWin += usd;
            }
            const cvdFromTape = agg.length > 0 && buyWin + sellWin > 0 && winStart > 0 && Date.now() - winStart <= 600_000 ? (buyWin - sellWin) / (buyWin + sellWin) * 100 : null;
            const cvdNetPctOfVol = takerMean !== null ? (takerMean - 1) * 100 : cvdFromTape; // % of taker volume net buys
            const metrics = {
                oiDelta10m: oiDelta10m === null ? null : Number(oiDelta10m.toFixed(3)),
                oiDelta1h: oiDelta1h === null ? null : Number(oiDelta1h.toFixed(3)),
                oiValueUsd,
                cvdNetBase: null,
                cvdNetPctOfVol: cvdNetPctOfVol === null ? null : Number(cvdNetPctOfVol.toFixed(3)),
                takerRatio,
                takerMean,
                crowdLongShort,
                crowdLongPct,
                topLongShort: topLongShort === null ? null : Number(topLongShort.toFixed(3)),
                funding8h: funding8h === null ? null : Number(funding8h.toFixed(4)),
                cvdUsd60s,
                whalePrint5m
            };
            const blind = flowCoverageOf(metrics) === 0;
            flowCache.set(symbol, {
                at: Date.now(),
                metrics,
                blind
            });
            flowSrcMap.set(symbol, flowSrc);
            // history ring (fresh samples only)
            if (metrics.oiDelta1h !== null) {
                const ring = flowHistory.get(symbol) ?? [];
                ring.push({
                    at: Date.now(),
                    oiDelta1h: metrics.oiDelta1h
                });
                if (ring.length > HISTORY_CAP) ring.shift();
                flowHistory.set(symbol, ring);
            }
            return metrics;
        } catch  {
            return null;
        } finally{
            flowInFlight.delete(symbol);
        }
    })();
    flowInFlight.set(symbol, p);
    return p;
}
async function ensureFlow(symbols, concurrency = 3) {
    const queue = [
        ...symbols
    ];
    const workers = Array.from({
        length: Math.min(concurrency, queue.length)
    }, async ()=>{
        while(queue.length > 0){
            const s = queue.shift();
            if (s) await fetchFlowMetrics(s);
        }
    });
    await Promise.all(workers);
}
function getFlowHistory(symbol) {
    return flowHistory.get(symbol) ?? [];
}
function fmtUsdShort(v) {
    if (v >= 1e9) return `$${(v / 1e9).toFixed(2)}B`;
    if (v >= 1e6) return `$${(v / 1e6).toFixed(1)}M`;
    return `$${(v / 1e3).toFixed(0)}K`;
}
function detectLiquiditySweep(candles, direction) {
    if (!candles || candles.length < 26) return {
        swept: false,
        supportive: false,
        detail: ""
    };
    const c = candles[candles.length - 1];
    const prior = candles.slice(candles.length - 25, candles.length - 1);
    const swingHigh = Math.max(...prior.map((k)=>k.high));
    const swingLow = Math.min(...prior.map((k)=>k.low));
    const range = c.high - c.low;
    if (range <= 0) return {
        swept: false,
        supportive: false,
        detail: ""
    };
    if (c.high > swingHigh && c.close < swingHigh && (c.high - c.close) / range >= 0.5) {
        const detail = `SMC sweep: bar traded ${((c.high - swingHigh) / swingHigh * 100).toFixed(2)}% above the 24-bar swing high then closed back inside (${Math.round((c.high - c.close) / range * 100)}% rejection wick) — buy-side liquidity grabbed`;
        return {
            swept: true,
            supportive: direction === "SHORT",
            detail: supportive_(detail, direction === "SHORT")
        };
    }
    if (c.low < swingLow && c.close > swingLow && (c.close - c.low) / range >= 0.5) {
        const detail = `SMC sweep: bar pierced ${((swingLow - c.low) / swingLow * 100).toFixed(2)}% below the 24-bar swing low then closed back inside (${Math.round((c.close - c.low) / range * 100)}% rejection wick) — sell-side liquidity grabbed`;
        return {
            swept: true,
            supportive: direction === "LONG",
            detail: supportive_(detail, direction === "LONG")
        };
    }
    return {
        swept: false,
        supportive: false,
        detail: ""
    };
}
function supportive_(detail, ok) {
    return ok ? `${detail}, supports the candidate direction` : detail;
}
async function scoreFlow(symbol, direction, price1hAgoPct) {
    const m = await fetchFlowMetrics(symbol);
    if (!m) {
        return {
            verdict: "UNAVAILABLE",
            score: 0,
            reasons: [
                "flow metrics unavailable — no numbers invented"
            ],
            metrics: {
                oiDelta10m: null,
                oiDelta1h: null,
                oiValueUsd: null,
                cvdNetBase: null,
                cvdNetPctOfVol: null,
                takerRatio: null,
                takerMean: null,
                crowdLongShort: null,
                crowdLongPct: null,
                topLongShort: null,
                funding8h: null,
                cvdUsd60s: null,
                whalePrint5m: null
            },
            oiWeight: 1,
            calibrated: false,
            coverage: 0,
            blind: true
        };
    }
    const coverage = flowCoverageOf(m);
    const dir = direction === "LONG" ? 1 : -1;
    const reasons = [];
    // v12.1 Task-48 ② — HONEST NO-DATA: a fetch that completed with every
    // decision metric null (fapi ban window / budget shed) is BLINDNESS, not a
    // neutral book. The 48h census showed 70% of deploys rode this state while
    // the card read "FLOW-NEUTRAL". Blind flow never votes (score 0) but now
    // carries the NO-DATA verdict so cards, journals and gates can tell the
    // difference. (Gate on blindness = EngineSetting "flow-gate", default
    // tag-only: 10d ledger blind +$204.20 WR 57.1% vs sighted +$7.11 WR 52.8% —
    // blocking the blind cohort would have CUT +$204 of net.)
    if (coverage === 0) {
        return {
            verdict: "NO-DATA",
            score: 0,
            reasons: [
                "flow-blind — every decision metric null (fapi-gate starvation/ban window); no numbers invented, no neutral read claimed"
            ],
            metrics: m,
            oiWeight: 1,
            calibrated: true,
            coverage: 0,
            blind: true
        };
    }
    // v12.2 TASK-52 — honest sourcing: when the bundle rode the bridge, say so
    // on the card/journal instead of silently mixing venues.
    const bridgeSrc = getFlowSource(symbol);
    if (bridgeSrc && bridgeSrc !== "BINANCE") {
        reasons.push(`flow source: ${bridgeSrc} bridge (fapi starved — flow numbers measured on the bridge venue, not Binance)`);
    }
    let raw = 0;
    // 1. CVD imbalance ±9
    if (m.cvdNetPctOfVol !== null) {
        const aligned = m.cvdNetPctOfVol * dir;
        const v = Math.max(-9, Math.min(9, aligned * 1.8));
        raw += v;
        const usdCtx = m.cvdUsd60s !== null ? ` (${m.cvdUsd60s >= 0 ? "+" : ""}$${(m.cvdUsd60s / 1000).toFixed(0)}K net taker USD/60s)` : "";
        reasons.push(`taker CVD ${m.cvdNetPctOfVol >= 0 ? "+" : ""}${m.cvdNetPctOfVol.toFixed(2)}% of taker volume ${aligned > 1 ? "agrees" : aligned < -1 ? "opposes" : "is neutral"}${usdCtx}`);
    }
    // 7. WHALE PRINTS ±5 (v6.7 SMC package): single fills ≥$250K near the entry
    // are the visible footprint of size players — aligned prints confirm, prints
    // against the thesis are distribution risk.
    if (m.whalePrint5m && m.whalePrint5m.totalUsd >= 400_000) {
        const whaleSide = m.whalePrint5m.buyUsd >= m.whalePrint5m.sellUsd ? 1 : -1;
        const aligned = whaleSide * dir;
        const desc = `${m.whalePrint5m.count} fill(s) ≥$250K totaling $${(m.whalePrint5m.totalUsd / 1000).toFixed(0)}K in 5m (max $${(m.whalePrint5m.maxUsd / 1000).toFixed(0)}K, ${m.whalePrint5m.buyUsd >= m.whalePrint5m.sellUsd ? "buy" : "sell"}-side dominant)`;
        if (aligned > 0) {
            raw += 5;
            reasons.push(`WHALE PRINTS ${desc} — pressing WITH the ${direction.toLowerCase()} thesis (smart-money participation)`);
        } else {
            raw -= 5;
            reasons.push(`WHALE PRINTS ${desc} — pressing AGAINST the ${direction.toLowerCase()} thesis (distribution risk)`);
        }
    }
    // 2. OI × price matrix ±7
    if (m.oiDelta1h !== null && price1hAgoPct !== null) {
        const priceDir = price1hAgoPct * dir; // >0: price moving in candidate's favor
        const oiUp = m.oiDelta1h > 0;
        if (priceDir > 0 && oiUp) {
            raw += 7;
            reasons.push(`new positions conviction — price ${price1hAgoPct >= 0 ? "+" : ""}${price1hAgoPct.toFixed(2)}%/1h with OI ${m.oiDelta1h >= 0 ? "+" : ""}${m.oiDelta1h.toFixed(2)}%/1h (fresh ${direction.toLowerCase()}s pressing)`);
        } else if (priceDir > 0 && !oiUp) {
            raw += 2;
            reasons.push(`short-covering style move — OI unwinding ${m.oiDelta1h.toFixed(2)}%/1h while price drifts favorably`);
        } else if (priceDir < 0 && oiUp) {
            raw -= 7;
            reasons.push(`opposing new positions — OI ${m.oiDelta1h.toFixed(2)}%/1h building against the ${direction.toLowerCase()} thesis`);
        } else {
            raw -= 2;
            reasons.push(`capitulation washout pattern — OI and price both unwinding`);
        }
    }
    // 3. REAL liquidation cascade (R16) — exhaustion logic ±3
    const liq = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["liquidationPressure"])(symbol);
    if (liq) {
        if (liq.usd10m >= 400_000) {
            const sideWrecked = direction === "LONG" ? liq.longsUsd10m : liq.shortsUsd10m;
            if (sideWrecked > liq.usd10m * 0.6) {
                raw += 3;
                reasons.push(`REAL liquidation cascade: ${fmtUsdShort(liq.usd10m)} wrecked in 10m — ${direction === "LONG" ? "longs" : "shorts"} flushed (forceOrder), exhaustion tailwind`);
            } else {
                raw -= 1;
                reasons.push(`cascade ${fmtUsdShort(liq.usd10m)} in 10m hit the opposing side — momentum risk`);
            }
        } else {
            reasons.push(`no material liquidation cascade (${fmtUsdShort(liq.usd10m)} in 10m)`);
        }
    }
    // 4. Funding contrarian ±5
    if (m.funding8h !== null) {
        if (m.funding8h > 0.05) {
            const v = dir > 0 ? -5 : 5;
            raw += v;
            reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — crowded longs pay, contrarian edge`);
        } else if (m.funding8h < -0.05) {
            const v = dir > 0 ? 5 : -5;
            raw += v;
            reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — shorts pay, squeeze fuel for longs`);
        } else reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — neutral carry`);
    }
    // 5. Crowd positioning ±4
    if (m.crowdLongShort !== null) {
        if (m.crowdLongShort > 2.2) {
            raw += dir > 0 ? -4 : 4;
            reasons.push(`retail crowd ${m.crowdLongShort.toFixed(2)}:1 long — fade risk on longs`);
        } else if (m.crowdLongShort < 0.5) {
            raw += dir > 0 ? 4 : -4;
            reasons.push(`retail crowd ${m.crowdLongShort.toFixed(2)}:1 (heavy shorts) — contrarian tailwind for longs`);
        }
    }
    // 5b. TOP-TRADER positioning ±4 (v6.7 SMC): the top-20% cohort's POSITION
    // sizing — where size actually sits. Extremes fade; a top-vs-retail DIVERGENCE
    // (smart money leaning where the crowd is not) adds a +2 alignment bonus.
    if (m.topLongShort !== null) {
        if (m.topLongShort > 2) {
            raw += dir > 0 ? -4 : 4;
            reasons.push(`top traders ${m.topLongShort.toFixed(2)}:1 net-LONG by position size — crowded smart-money side, fade risk on longs`);
        } else if (m.topLongShort < 0.5) {
            raw += dir > 0 ? 4 : -4;
            reasons.push(`top traders ${m.topLongShort.toFixed(2)}:1 net-SHORT by position size — crowded smart-money side, tailwind against longs`);
        }
        if (m.crowdLongShort !== null && (m.crowdLongShort > 1.5 && m.topLongShort < 0.8 || m.crowdLongShort < 0.7 && m.topLongShort > 1.5)) {
            const smartSide = m.topLongShort > 1 ? 1 : -1;
            raw += smartSide === dir ? 2 : -2;
            reasons.push(`top-vs-retail divergence: crowd ${m.crowdLongShort.toFixed(2)}:1 vs top traders ${m.topLongShort.toFixed(2)}:1 — size sits with the ${smartSide === 1 ? "longs" : "shorts"}`);
        }
    }
    // 6. Taker acceleration ±5
    if (m.takerRatio !== null && m.takerMean !== null) {
        const accel = m.takerRatio - m.takerMean;
        const aligned = accel * dir;
        if (Math.abs(aligned) > 0.06) {
            raw += Math.max(-5, Math.min(5, aligned * 40));
            reasons.push(`taker buy/sell ${m.takerRatio.toFixed(3)} vs mean ${m.takerMean.toFixed(3)} — ${aligned > 0 ? "accelerating in favor" : "decelerating"}`);
        }
    }
    // OI-notional weighting (v4.5): deep books trusted more
    const oiWeight = m.oiValueUsd ? Math.max(0.5, Math.min(1.2, Math.sqrt(m.oiValueUsd / 50_000_000))) : 1;
    let score = Math.round(Math.max(-25, Math.min(25, raw * oiWeight)));
    if (Math.abs(oiWeight - 1) >= 0.15) reasons.push(`flow weighted ×${oiWeight.toFixed(2)} by OI notional ${fmtUsdShort(m.oiValueUsd ?? 0)} — deep-book flow trusted`);
    // ── v12.9 SECOND-PLANE CONSENSUS (AUDIT-NX3046-20261023, operator mandate
    // «باید از تمام صرافی‌ها مخصوصاً BINANCE تیکت گرفته بشه»; v14.0 Binance-only) ──
    // The bundle rode ONE plane's tape; nothing ever asked a SECOND plane
    // whether the tape agrees. NX-3046: a single-plane JCT tape showed CVD
    // +18.5% OPPOSING the short and OI unwinding — the bundle still rode
    // neutral, and no second plane was consulted. Now: the primary plane's
    // 15m-window (4×5m-bar) direction is compared against the INDEPENDENT
    // Binance plane (fapi-tape → SPOT-MIRROR cross-check; SPOT-MIRROR-tape →
    // gated fapi cross-check). Sign-opposed moves diverging >1.5% clamp
    // conviction to ±6 (below the ±8 CONFIRMS/CONFLICTS line) — cross-plane
    // conflict can never confirm a deploy. 60s per-symbol caches + in-flight
    // dedupe keep the hot path cheap; any fetch failure fails OPEN (consensus
    // simply does not run, no numbers invented). Symbols the second plane
    // cannot price (second rung null) are handled by the engine-side
    // SINGLE-VENUE deploy block.
    const consensusSrc = bridgeSrc ?? null;
    if (consensusSrc) {
        try {
            const pri = await cachedConsensusVal(`PRI5M|${symbol}`, 60_000, async ()=>{
                const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeKlines"])(symbol, "5m", 4).catch(()=>null);
                if (!r || r.rows.length < 4) return null;
                const o = r.rows[0].open, c = r.rows[r.rows.length - 1].close;
                return {
                    move: o > 0 && c > 0 ? (c - o) / o * 100 : null,
                    source: r.source
                };
            });
            const priMove = pri?.move ?? null;
            let secondName = null;
            let secondMove = null;
            // v14.0 — the second-plane cross-check is Binance-only: the plane the
            // primary did NOT ride (fapi primary → SPOT-MIRROR ladder check;
            // SPOT-MIRROR primary → gated fapi check, honest null when banned).
            if (consensusSrc === "BINANCE") {
                secondName = "BINANCE-SPOT";
                secondMove = await cachedConsensusVal(`SPOT5M|${symbol}`, 60_000, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spot5mMove"])(symbol));
            } else if (consensusSrc === "SPOT-MIRROR" || consensusSrc === "MIXED") {
                secondName = "BINANCE-FAPI";
                secondMove = await cachedConsensusVal(`FAPI5M|${symbol}`, 60_000, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapi5mMove"])(symbol));
            }
            if (priMove !== null && secondName && secondMove !== null) {
                const disagree = Math.sign(priMove) !== Math.sign(secondMove) && Math.abs(priMove - secondMove) > 1.5;
                if (disagree) {
                    const cr = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCoreRevert"])();
                    if (!cr.enabled) score = Math.max(-6, Math.min(6, score));
                    reasons.push(`MULTI-VENUE DISAGREE: primary ${consensusSrc} 15m-window ${priMove >= 0 ? "+" : ""}${priMove.toFixed(2)}% vs ${secondName} ${secondMove >= 0 ? "+" : ""}${secondMove.toFixed(2)}% — cross-venue tapes conflict${cr.enabled ? " · CORE-REVERT advisory: clamp lifted, telemetry only (v12.7 doctrine)" : ", conviction clamped ±6, cannot CONFIRM (operator mandate: confirmation from all venues, especially Binance — v12.9)"}`);
                } else if (Math.sign(priMove) === Math.sign(secondMove) && Math.abs(priMove - secondMove) <= 1.5) {
                    reasons.push(`MULTI-VENUE AGREE: primary ${consensusSrc} ${priMove >= 0 ? "+" : ""}${priMove.toFixed(2)}% ≈ ${secondName} ${secondMove >= 0 ? "+" : ""}${secondMove.toFixed(2)}% over 15m — cross-venue tape concordant (v12.9)`);
                }
            }
        } catch  {
        /* fail-open — consensus is telemetry, never a wedging gate */ }
    }
    // ── v12.8 SURROGATE-FLOW CAP (AUDIT-20261023, operator mandate «اصلاح
    // پیشنهادی را کامل و مهندسی اجرا کن») ──
    // Forensics NX-3014 (BTWUSDT 03:13Z): the flow bundle read "CONFIRMS +10"
    // while its source was the SPOT-MIRROR bridge (fapi banned) on a symbol whose
    // BINANCE quote was null and whose cross-venue dislocation ran 90-105bps —
    // the price collapsed −4.5% within 48s of deploy (SL −61.2% in 103s). A
    // surrogate venue's tape is REAL tape, but it is the WRONG venue's tape for
    // a Binance-doctrine engine on dislocated micro-caps: it must not be allowed
    // to CONFIRM a deploy. Cap: when the feeding source is not BINANCE, flow
    // conviction is clamped to ±6 — below the ±8 CONFIRMS/CONFLICTS line, so a
    // surrogate bundle can never confirm NOR fully veto; it can still feed the
    // flowVetoScore ≤−4 soft veto (score −5/−6 survives the clamp) and rides as
    // honest telemetry. BINANCE-sourced bundles are untouched.
    //
    // ── v13.3 SURROGATE-FLOW DEMOTE (ch.7 item ①-ب, operator mandate trace
    // 1a1a8ea4186c6571 «پیشنهادات باقی مانده مهندسی را کامل اجرا کن») ──
    // NX-3247 anatomy (engineering report ch.4-1): with fapi starved, the flow
    // verdict was sourced «SPOT-MIRROR bridge» and read CONFLICTS −9 against a
    // REAL Binance-futures buy flow the operator could see — the engine decided
    // with a surrogate's eyes at the exact top. While the fapi plane is starving
    // (global ban window live OR ≥2 egress IPs banned — fapiBanActivity()), a
    // non-BINANCE bundle is demoted to INFORMATIONAL-ONLY: score contribution 0,
    // verdict NEUTRAL, reason carries the demote tag. This branch runs BEFORE the
    // core-revert advisory check — CORE-REVERT restores the v12.7 core, it was
    // never an authorization for surrogate verdict-making during famine. When
    // fapi recovers, the historical v12.8 cap semantics resume unchanged.
    if (bridgeSrc && bridgeSrc !== "BINANCE") {
        const famine = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapiBanActivity"])().active; // v13.3 ch.7-ب — honest fapi-plane health
        if (famine) {
            score = 0;
            reasons.push(`SURROGATE-FLOW DEMOTE (ch.7-ب): fapi starved + source ${bridgeSrc} → flow bundle is INFORMATIONAL-ONLY this evaluation (score contribution 0, verdict NEUTRAL; NX-3247 CONFLICTS-9-from-mirror forensics — the engine does not decide on a surrogate's eyes while the real perp plane is starved)`);
        } else {
            const crSurrogate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCoreRevert"])();
            if (!crSurrogate.enabled) score = Math.max(-6, Math.min(6, score));
            reasons.push(`SURROGATE-FLOW CAP: source ${bridgeSrc} ≠ BINANCE${crSurrogate.enabled ? " · CORE-REVERT advisory: clamp lifted, surrogate tape rides as telemetry (v12.7 doctrine — the +12/+8/cap stack was the no-Binance drought engine)" : " — conviction clamped ±6, surrogate flow cannot CONFIRM a deploy (NX-3014 48s-collapse forensics, v12.8)"}`);
        }
    }
    const verdict = score >= 8 ? "CONFIRMS" : score <= -8 ? "CONFLICTS" : "NEUTRAL";
    return {
        verdict,
        score,
        reasons,
        metrics: m,
        oiWeight: Number(oiWeight.toFixed(2)),
        calibrated: true,
        coverage,
        blind: false,
        source: bridgeSrc ?? undefined
    };
}
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_MILESTONE_STEPS",
    ()=>RAWCAL_MILESTONE_STEPS,
    "RAWCAL_TELEMETRY_FILE",
    ()=>RAWCAL_TELEMETRY_FILE,
    "checkRawcalMilestones",
    ()=>checkRawcalMilestones,
    "checkRawcalStallAlarm",
    ()=>checkRawcalStallAlarm,
    "computeRawcalPace",
    ()=>computeRawcalPace,
    "milestoneView",
    ()=>milestoneView,
    "recentBlocks",
    ()=>recentBlocks,
    "recordRawcalSnapshot",
    ()=>recordRawcalSnapshot
]);
// ── v9.2 RAW-CAL PACE MONITOR — engineering observability for the capture run ──
// Operator mandate 2026-09-13: «پایش ریتم صدور RAW-CAL و رشد کتاب EPOCH-2 به
// سمت ۱۰۰. رو کامل و مهندسی انجام بده» — monitor the RAW-CAL issuance rhythm
// and the growth of the EPOCH-2 book toward the 100-settled calibration bar.
//
// THREE PERSISTED INSTRUMENTS:
//  1) SNAPSHOT JOURNAL — .data/rawcal-telemetry.jsonl, one row every ~10min
//     (self-throttled; force on state jumps): {t, issued, issuedTotal,
//     settledE2, openRaw, settledRaw, winsRaw, note?} — the book-growth curve
//     the UI sparkline and rate math read. Trimmed to the last 4000 rows.
//  2) PACE ENGINE — rolling rates from the journal + the DB ledger:
//     issue rate/h (3h + since-armed), settle rate/h (3h + 6h), observed mean
//     spacing between raw issues (DB createdAt diffs), ETA to the 100 bar at
//     the current settle rate, pipeline projection (open raw records that will
//     still settle), mean book settle-time, and stall detection.
//  3) MILESTONE LEDGER — idempotent audited events at 50/60/70/80/90/95/100
//     (EngineSetting "rawcal.milestones"); Telegram only for 90/95/100 (the
//     100 announcement itself stays with the auto-lift in raw-cal.ts).
//
// STALL SEMANTICS (honest, rail-aware):
//  · issue stall  = armed && openRaw < maxOpen && now − lastIssueAt >
//    max(45min, 3 × spacingMin) — issuance SHOULD have produced a record.
//  · settle stall = openRaw > 0 && no EPOCH-2 settle in the last 3h.
//  Neither fires when the open-cap rail is the legitimate blocker.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const RAWCAL_TELEMETRY_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-telemetry.jsonl");
const MILESTONES_KEY = "rawcal.milestones";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const RAWCAL_MILESTONE_STEPS = [
    50,
    60,
    70,
    80,
    90,
    95,
    100
];
const TELEGRAM_MILESTONES = new Set([
    90,
    95,
    100
]);
const MAX_JOURNAL_ROWS = 4000;
// ── memo caches (pulse-safe; these run on hot paths) ──
let lastSnapshotAt = 0;
let paceCache = null;
const PACE_TTL_MS = 30_000;
async function readJournal() {
    try {
        const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(RAWCAL_TELEMETRY_FILE, "utf8");
        const rows = [];
        for (const line of txt.split("\n")){
            const s = line.trim();
            if (!s) continue;
            try {
                rows.push(JSON.parse(s));
            } catch  {
            /* skip torn line */ }
        }
        return rows.slice(-MAX_JOURNAL_ROWS);
    } catch  {
        return [];
    }
}
async function appendJournal(row) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(RAWCAL_TELEMETRY_FILE), {
            recursive: true
        });
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(RAWCAL_TELEMETRY_FILE, JSON.stringify(row) + "\n", "utf8");
        // opportunistic trim (cheap: only when the file grows past 2× the cap)
        try {
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(RAWCAL_TELEMETRY_FILE);
            if (st.size > MAX_JOURNAL_ROWS * 180) {
                const rows = await readJournal();
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(RAWCAL_TELEMETRY_FILE, rows.slice(-MAX_JOURNAL_ROWS).map((r)=>JSON.stringify(r)).join("\n") + "\n", "utf8");
            }
        } catch  {
        /* trim best-effort */ }
    } catch (e) {
        console.error("[rawcal-telemetry] journal append failed", e);
    }
}
async function recordRawcalSnapshot(note, force = false) {
    const now = Date.now();
    if (!force && now - lastSnapshotAt < 10 * 60_000) return null;
    lastSnapshotAt = now;
    try {
        const [settledE2, openRaw, totalRaw, settledRaw, winsRaw] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: {
                        in: SETTLED_STATUSES
                    },
                    tags: {
                        contains: "EPOCH-2"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: [
                            "ACTIVE",
                            "TP1",
                            "TP2"
                        ]
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: SETTLED_STATUSES
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    reachedTp: {
                        gte: 1
                    }
                }
            })
        ]);
        const snap = {
            t: new Date(now).toISOString(),
            issued: 0,
            issuedTotal: totalRaw,
            settledE2,
            openRaw,
            settledRaw,
            winsRaw,
            ...note ? {
                note: note.slice(0, 80)
            } : {}
        };
        // issued-this-run: cheap read of the state key (no import cycle — raw-cal
        // imports telemetry, not vice versa)
        try {
            const s = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "rawcal.state"
                }
            });
            if (s) snap.issued = JSON.parse(s.value).issued ?? 0;
        } catch  {
        /* optional field */ }
        await appendJournal(snap);
        paceCache = null; // fresh data → invalidate pace memo
        return snap;
    } catch (e) {
        console.error("[rawcal-telemetry] snapshot failed", e);
        return null;
    }
}
async function computeRawcalPace(blocks) {
    if (paceCache && Date.now() - paceCache.at < PACE_TTL_MS && !blocks) return paceCache.data;
    const state = await getRawcalStateSafe();
    const now = Date.now();
    const [settledE2, openRaw, openE2, maxOpen] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        Promise.resolve(state.maxOpen)
    ]);
    const target = state.target;
    // issuance ledger (raw rows from the DB itself — ground truth)
    const rawRows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            createdAt: true
        },
        orderBy: {
            createdAt: "asc"
        }
    });
    const issueTimes = rawRows.map((r)=>r.createdAt.getTime());
    const h3 = now - 3 * 3600_000;
    const issues3h = issueTimes.filter((t)=>t >= h3).length;
    const armMs = state.armedAt ? new Date(state.armedAt).getTime() : null;
    const issuesSinceArm = armMs ? issueTimes.filter((t)=>t >= armMs).length : 0;
    const armHours = armMs ? Math.max(1 / 60, (now - armMs) / 3600_000) : null;
    const diffs = issueTimes.slice(1).map((t, i)=>t - issueTimes[i]);
    const meanDiff = diffs.length ? diffs.reduce((a, b)=>a + b, 0) / diffs.length : null;
    // book-growth ledger (EPOCH-2 settles with closedAt)
    const settles = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            },
            closedAt: {
                not: null
            }
        },
        select: {
            closedAt: true,
            createdAt: true
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const settleTimes = settles.map((r)=>r.closedAt.getTime()).reverse(); // asc
    const settles3h = settleTimes.filter((t)=>t >= h3).length;
    const settles6h = settleTimes.filter((t)=>t >= now - 6 * 3600_000).length;
    const recent20 = settles.slice(0, 20);
    const meanSettleMin = recent20.length ? recent20.reduce((a, r)=>a + (r.closedAt.getTime() - r.createdAt.getTime()), 0) / recent20.length / 60_000 : null;
    const [settledRaw, winsRaw] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: SETTLED_STATUSES
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                reachedTp: {
                    gte: 1
                }
            }
        })
    ]);
    const settleRate3h = settles3h / 3;
    const needed = Math.max(0, target - settledE2);
    const etaHours = needed === 0 ? 0 : settleRate3h > 0 ? needed / settleRate3h : null;
    // v9.2.1 steady-state projection — raw cadence ∩ settle-throughput cap.
    // throughputCap = maxOpen concurrent records / mean settle hours; the real
    // fill window is needed / min(issueCadence, throughputCap). Only computed
    // when meanSettleMin is known (honest — no invented throughput).
    const issueSinceArmRateRaw = armHours ? issuesSinceArm / armHours : 0;
    const throughputCapPerH = meanSettleMin !== null && meanSettleMin > 0 ? maxOpen / (meanSettleMin / 60) : null;
    const steadyRatePerH = throughputCapPerH !== null ? Math.min(issueSinceArmRateRaw, throughputCapPerH) : null;
    const etaSteadyHours = needed === 0 ? 0 : steadyRatePerH !== null && steadyRatePerH > 0 ? needed / steadyRatePerH : null;
    // stalls (rail-aware — see header)
    const issueStallMin = state.armed && openRaw < maxOpen && state.lastIssueAt ? Math.max(0, (now - new Date(state.lastIssueAt).getTime()) / 60_000) : null;
    const issueStallActive = issueStallMin !== null && issueStallMin > Math.max(45, 3 * state.spacingMin);
    const lastSettleAt = settleTimes.length ? settleTimes[settleTimes.length - 1] : null;
    const settleStallMin = openRaw > 0 && lastSettleAt ? Math.max(0, (now - lastSettleAt) / 60_000) : null;
    const settleStallActive = settleStallMin !== null && settleStallMin > 180;
    // cadence grade — honest banding of the ISSUE rhythm while armed.
    // v9.2.1 arm-age-aware: inside the first 3h after arming the 3h window still
    // contains pre-RAW-CAL filtered flow (rate lag) → grade on the since-arm
    // cadence instead; afterwards both windows agree and 3h is used.
    const issueRate3hPerH = issues3h / 3;
    let cadenceGrade = "OFF";
    if (state.armed) {
        const baseRate = armHours !== null && armHours < 3 ? issueSinceArmRateRaw : issueRate3hPerH;
        const effRate = issueStallActive ? 0 : baseRate;
        cadenceGrade = effRate >= 3 ? "A" : effRate >= 1.5 ? "B" : effRate >= 0.5 ? "C" : "D";
    }
    // sparkline from the journal (downsample to ≤48 points)
    // v9.4.2 NaN guard: journal gap rows can carry non-finite settledE2 — skip
    // them here so the client never receives NaN chart values.
    const journal = await readJournal();
    const series = journal.length > 1 ? journal : journal.length === 1 ? [
        {
            t: new Date(now).toISOString(),
            settledE2
        }
    ] : [];
    const step = Math.max(1, Math.ceil(series.length / 48));
    const sparkline = [];
    for(let i = 0; i < series.length; i += step){
        const v = series[i].settledE2;
        if (!Number.isFinite(v)) continue;
        sparkline.push({
            t: series[i].t,
            v
        });
    }
    if (sparkline.length && Number.isFinite(settledE2) && sparkline[sparkline.length - 1].v !== settledE2) sparkline.push({
        t: new Date(now).toISOString(),
        v: settledE2
    });
    const lastBlockNote = blocks && blocks.length ? blocks[blocks.length - 1].note : null;
    const pace = {
        armed: state.armed,
        armedAt: state.armedAt,
        settledE2,
        needed,
        target,
        issueRate3hPerH: round2(issueRate3hPerH),
        issueRateSinceArmPerH: armHours ? round2(issuesSinceArm / armHours) : 0,
        observedSpacingMin: {
            mean: meanDiff !== null ? round2(meanDiff / 60_000) : null,
            min: diffs.length ? round2(Math.min(...diffs) / 60_000) : null,
            max: diffs.length ? round2(Math.max(...diffs) / 60_000) : null,
            samples: diffs.length
        },
        lastIssueAt: state.lastIssueAt,
        lastIssueSerial: state.lastIssueSerial,
        openRaw,
        openE2,
        maxOpen,
        spacingMin: state.spacingMin,
        settleRate3hPerH: round2(settleRate3h),
        settleRate6hPerH: round2(settles6h / 6),
        meanSettleMin: meanSettleMin !== null ? Math.round(meanSettleMin) : null,
        winsRaw,
        settledRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        etaHours: etaHours !== null ? round2(etaHours) : null,
        etaAt: etaHours !== null ? new Date(now + etaHours * 3600_000).toISOString() : null,
        steadyRatePerH: steadyRatePerH !== null ? round2(steadyRatePerH) : null,
        etaSteadyHours: etaSteadyHours !== null ? round2(etaSteadyHours) : null,
        etaSteadyAt: etaSteadyHours !== null ? new Date(now + etaSteadyHours * 3600_000).toISOString() : null,
        pipelineProjection: settledE2 + openE2,
        cadenceGrade,
        stalls: {
            issueStallMin: issueStallActive ? Math.round(issueStallMin) : null,
            settleStallMin: settleStallActive ? Math.round(settleStallMin) : null,
            lastBlockNote
        },
        sparkline,
        journalRows: journal.length
    };
    if (!blocks) paceCache = {
        at: Date.now(),
        data: pace
    };
    return pace;
}
async function getRawcalStateSafe() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return await getRawCalState();
    } catch  {
        return {
            armed: false,
            armedAt: null,
            lastIssueAt: null,
            lastIssueSerial: null,
            target: 100,
            spacingMin: 12,
            maxOpen: 8
        };
    }
}
function round2(n) {
    return Math.round(n * 100) / 100;
}
// ── MILESTONE LEDGER ──
async function readMilestones() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: MILESTONES_KEY
            }
        });
        if (!row) return {
            fired: {}
        };
        return JSON.parse(row.value);
    } catch  {
        return {
            fired: {}
        };
    }
}
async function checkRawcalMilestones() {
    const settledE2 = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    }).catch(()=>0);
    const m = await readMilestones();
    const firedNow = [];
    for (const step of RAWCAL_MILESTONE_STEPS){
        const key = String(step);
        if (settledE2 < step || m.fired[key]) continue;
        const at = new Date().toISOString();
        m.fired[key] = at;
        firedNow.push({
            step,
            at
        });
        const isBar = step === 100;
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", `RAW-CAL MILESTONE ${step}/${100} — EPOCH-2 book at ${settledE2} settled${isBar ? " — calibration bar REACHED, capture mode hands back to central-intelligence command (new calibration)" : ` · ${100 - settledE2} records remain to the AI CALIBRATION bar`}`).catch(()=>undefined);
        if (TELEGRAM_MILESTONES.has(step) && !(isBar && stateHasAutoLift())) {
            const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
            void sendDirect(`📈 <b>RAW-CAL MILESTONE ${step}/100</b>\nEPOCH-2 book: <b>${settledE2}/100</b> settled${isBar ? " — AI CALIBRATION lift imminent" : ` · ${100 - settledE2} to go`}\n${progressBar(settledE2)}`).catch(()=>undefined);
        }
    }
    if (firedNow.length) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: MILESTONES_KEY
            },
            create: {
                key: MILESTONES_KEY,
                value: JSON.stringify(m)
            },
            update: {
                value: JSON.stringify(m)
            }
        }).catch(()=>undefined);
    }
    return firedNow;
}
async function stateHasAutoLift() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return !!(await getRawCalState()).autoLiftAt;
    } catch  {
        return false;
    }
}
function progressBar(n) {
    const filled = Math.round(Math.min(100, n) / 100 * 20);
    return "▰".repeat(filled) + "▱".repeat(20 - filled);
}
async function milestoneView() {
    const [m, settledE2] = await Promise.all([
        readMilestones(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }).catch(()=>0)
    ]);
    return {
        steps: RAWCAL_MILESTONE_STEPS.map((step)=>({
                step,
                fired: !!m.fired[String(step)],
                at: m.fired[String(step)] ?? null,
                pending: settledE2 < step
            })),
        settledE2
    };
}
async function recentBlocks(n = 12) {
    try {
        const { getRawCalBlocks } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return getRawCalBlocks(n);
    } catch  {
        return [];
    }
}
// ── v9.2.1 STALL ALARM — push the rhythm break, don't just display it ──
// Tick hook (idempotent, 2h cooldown per stall type). Fires when the armed
// issuer SHOULD have produced (issue stall) or the in-flight pipeline SHOULD
// have settled (settle stall) and didn't. Process-death is covered by the P0
// watchdog + keep-alive crons; this alarm covers "alive but rhythm broken".
const STALL_ALERT_KEY = "rawcal.stallAlerts";
const STALL_COOLDOWN_MS = 2 * 3600_000;
async function checkRawcalStallAlarm() {
    try {
        const pace = await computeRawcalPace().catch(()=>null);
        if (!pace || !pace.armed) return false;
        const issues = [];
        if (pace.stalls.issueStallMin) issues.push(`issue stall — no raw record for ${pace.stalls.issueStallMin}min while armed and open ${pace.openRaw}/${pace.maxOpen}`);
        if (pace.stalls.settleStallMin) issues.push(`settle stall — no EPOCH-2 settle for ${pace.stalls.settleStallMin}min with ${pace.openRaw} raw in flight`);
        if (!issues.length) return false;
        let fired = {};
        try {
            const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: STALL_ALERT_KEY
                }
            });
            if (row) fired = JSON.parse(row.value).fired ?? {};
        } catch  {
        /* fresh ledger */ }
        const now = Date.now();
        const send = [];
        for (const it of issues){
            const k = it.startsWith("issue") ? "issue" : "settle";
            const last = fired[k] ? new Date(fired[k]).getTime() : 0;
            if (now - last > STALL_COOLDOWN_MS) {
                fired[k] = new Date(now).toISOString();
                send.push(it);
            }
        }
        if (!send.length) return false;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: STALL_ALERT_KEY
            },
            create: {
                key: STALL_ALERT_KEY,
                value: JSON.stringify({
                    fired
                })
            },
            update: {
                value: JSON.stringify({
                    fired
                })
            }
        }).catch(()=>undefined);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL PACE ALARM — ${send.join(" · ")} · book ${pace.settledE2}/${pace.target} · cadence ${pace.cadenceGrade}`).catch(()=>undefined);
        const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
        void sendDirect(`⏱ <b>RAW-CAL PACE ALARM</b>\n${send.map((s)=>`• ${s}`).join("\n")}\n📊 Book: <b>${pace.settledE2}/${pace.target}</b> settled · cadence ${pace.cadenceGrade} · open raw ${pace.openRaw}/${pace.maxOpen}`).catch(()=>undefined);
        return true;
    } catch  {
        return false;
    }
}
}),
"[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeRawcalQuality",
    ()=>computeRawcalQuality,
    "r6GateLine",
    ()=>r6GateLine,
    "readPersistedQuality",
    ()=>readPersistedQuality,
    "recordRawcalQuality",
    ()=>recordRawcalQuality
]);
// ── v9.3 RAW-CAL SAMPLE QUALITY LAB — data-health gate for the R6 recalibration ──
// Operator mandate 2026-09-13: «پس از تسویه اولین RAW-CALها (~1-2h) میتوانیم
// کیفیت نمونه‌های خام را هم بررسی کنیم تا کالیبراسیون R6 روی داده سالم بنشیند»
// — after the first RAW-CALs settle, review the quality of the raw samples so
// the R6 calibration rests on HEALTHY data.
//
// WHAT IT MEASURES (every RAW-CAL-tagged ledger row, 100% from the DB):
//  · CAPTURE INTEGRITY (0-30): deploy audit snapshots preserved — factorsJson
//    (confluence votes, 12) / flowJson (order-flow, 9) / mtfJson (multi-TF
//    board, 9). R6 attributes outcomes to factors; a row born without its
//    snapshots can never be attributed, so absence is scored, not forgiven.
//  · PLAN COMPLETENESS (0-20): entry/stop/TP ladder present and
//    direction-consistent, RR > 0, TTL sane — a malformed plan is a malformed
//    sample no matter how it settles.
//  · OUTCOME INFORMATIVENESS (0-30): TP1/TP2/TP3 or SL = fully informative
//    (price proved or disproved the plan — losses are the most instructive
//    rows); EXPIRED with a TP touch = partially informative; EXPIRED with no
//    touch = time-censored (low information); manual CLOSED = censored.
//  · REPRESENTATIVENESS (0-20): spacing ≥ the anti-flood rail (burst-cluster
//    rows are correlated and would inflate calibration confidence), hold time
//    inside the TTL envelope, extension abuse flagged.
// Composite 0-100 → HEALTHY ≥75 · REVIEW 50-74 · CENSORED <50 (PENDING while
// the row is still open).
//
// COHORT HEALTH → R6 GATE: healthy% of the settled raw cohort vs the 85%
// health floor, informative ratio, symbol concentration, side balance,
// snapshot completeness — verdict GREEN / AMBER / RED (WARMING before the
// first settles) with explicit blockers. The gate ADVISES the R6 lift and the
// central intelligence (engine memory + governor context); it NEVER edits the
// calibration math itself (no post-hoc tampering — honest instrumentation).
//
// PERSISTENCE: EngineSetting "rawcal.quality" (compact digest, cross-process)
// + QUALITY rows appended to .data/rawcal-telemetry.jsonl (10min throttle,
// forced the moment the settled-raw count moves — the settle curve of the
// QUALITY of the book, not just its size).
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)");
;
;
;
;
const QUALITY_KEY = "rawcal.quality";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const OPEN_STATUSES = [
    "ACTIVE",
    "TP1",
    "TP2"
];
const HEALTH_FLOOR = 85; // R6 health floor — healthy% of the settled raw cohort
const MAX_JOURNAL_ROWS = 4000;
// ── v10.9 POST-FILTER COHORT (SUPERVISOR proposal 22:55Z, operator-approved
// 2026-09-15 «دستورات سوپروایزر را کامل و مهندسی انجام بده») — before/after
// split around the decisive-excursion filter go-live (first live skip TAOUSDT
// 11:31:27Z, worklog OP-V106-ROOTCAUSE-20260915T1134Z). The blended window is
// dominated by the legacy expired-no-touch stock, so the filter's true effect
// on outcome informativeness is measured on its OWN cohort. Censoring-aware
// pre/post design (gov.uk before-after guidance; Prinja 2010, Turkson 2021).
const FILTER_ERA_START_MS = Date.parse("2026-09-15T11:30:00.000Z");
// ── v10.9.2 EXPIRY-CAUSE ATTRIBUTION (SUPERVISOR proposal, operator-approved
// via bridge 2026-09-16T11:18Z «دستورات سوپروایزر را تایید می کنم») — the gate
// verdict is hostage to expired-no-touch censoring (informative 37.7% blended):
// R6 cannot attribute outcomes when a trade never reaches TP1 or SL. Each
// EXPIRED-no-touch row is now split by its MAX FAVORABLE EXCURSION in R units
// (mfeR = (maxPnlPercent/leverage) / stopDistancePct — existing journal fields,
// zero new capture): WRONG-SIDE (mfeR < 0.25 — price never followed the plan;
// entry direction/timing problem, NOT a TTL problem) vs NO-FOLLOW (mfeR ≥ 0.6 —
// meaningful follow that stalled before TP1; barrier/TP geometry too far for
// realized excursion) vs MIXED (in between). The gate can now NAME the dominant
// expiry cause, and the VOL-BARRIER mult/cap knobs get a direct feedback signal
// (no-follow dominance → tighten barrier; wrong-side dominance → entry filter
// problem). Reporting-layer only — scoring, scan and issue logic untouched.
const EXP_WRONG_SIDE_R = 0.25; // below: never followed — wrong side / late entry
const EXP_NO_FOLLOW_R = 0.6; // above: followed then stalled — geometry too far
// ── v10.9.1 EPOCH-WINDOWED GATE VERDICT (SUPERVISOR proposal, operator blanket-
// approve 2026-09-16T09:03Z «تمام اقدامات و پیشنهادات SUPERVISOR را تایید
// می‌کنم — کامل و مهندسی انجام بده») — the gate verdict is computed on the
// POST-FILTER EPOCH WINDOW, not the blended all-time cohort. The blended
// window is dominated by legacy expired-no-touch stock (metric regime-bias:
// 37.7% blended vs 56% post-filter informative at approval time), so the
// all-time ratio can never turn GREEN even when the CURRENT engine regime is
// decisively healthier. GREEN now requires the epoch window to prove itself:
// window informative ≥50% AND window settled n≥20. Structural integrity
// (snapshots) stays whole-cohort — a row born without snapshots is era-
// independent damage. The healthy-floor check rides the window too (AMBER,
// not RED). VERDICT-ONLY change: scoring, cohort measurement, scan/issue
// logic all untouched — the digest still reports the blended ratios for the
// whole book (honest instrumentation), only the VERDICT anchor moved.
const GATE_WINDOW_MIN_N = 20; // settled rows the window needs before GREEN is reachable
const GATE_WINDOW_FORMING = 3; // below this the window is WARMING, not judged
const GATE_WINDOW_INFORMATIVE = 50; // GREEN bar for the window informative ratio
const GATE_WINDOW_WARN_N = 8; // window small-sample guard for the informative blocker
// ── memo cache (runs on hot paths) ──
let qualityCache = null;
const QUALITY_TTL_MS = 30_000;
let lastJournalAt = 0;
let lastSeenSettled = -1;
function safeParse(json) {
    if (!json || !json.trim()) return false;
    try {
        const v = JSON.parse(json);
        return v !== null && (typeof v !== "object" || Array.isArray(v) ? v.length > 0 : Object.keys(v).length > 0);
    } catch  {
        return false;
    }
}
function round1(n) {
    return Math.round(n * 10) / 10;
}
function pct(part, whole) {
    return whole > 0 ? round1(part / whole * 100) : null;
}
/** Score ONE raw ledger row against the four quality dimensions. */ function scoreSample(row, prevCreatedAt, spacingMin) {
    const flags = [];
    const settled = SETTLED_STATUSES.includes(row.status);
    const open = OPEN_STATUSES.includes(row.status);
    // ── A) capture integrity — the deploy audit snapshots R6 will attribute to (0-30)
    let integrity = 0;
    if (safeParse(row.factorsJson)) integrity += 12;
    else flags.push("no-factors");
    if (safeParse(row.flowJson)) integrity += 9;
    else flags.push("no-flow");
    if (safeParse(row.mtfJson)) integrity += 9;
    else flags.push("no-mtf");
    // ── B) plan completeness — entry/stop/ladder coherent (0-20)
    let plan = 0;
    if (row.entryPrice > 0) plan += 2;
    if (row.stopLoss > 0) plan += 3;
    else flags.push("no-stop");
    if (row.tp1 > 0 && row.tp2 > 0 && row.tp3 > 0) plan += 3;
    else flags.push("ladder-short");
    const long = row.direction === "LONG";
    const ladderOk = long ? row.tp1 > row.entryPrice && row.stopLoss < row.entryPrice : row.direction === "SHORT" ? row.tp1 < row.entryPrice && row.stopLoss > row.entryPrice : false;
    if (ladderOk) plan += 6;
    else flags.push("ladder-inconsistent");
    if (row.riskReward > 0) plan += 2;
    if (row.ttlMinutes > 0 && row.expiresAt.getTime() > row.createdAt.getTime()) plan += 4;
    else flags.push("ttl-bad");
    // ── C) outcome informativeness — what did the settle actually teach (0-30)
    let outcome = 0;
    if (settled) {
        if ([
            "TP1",
            "TP2",
            "TP3"
        ].includes(row.status)) outcome = 30;
        else if (row.status === "SL") outcome = 30;
        else if (row.status === "EXPIRED") {
            if (row.reachedTp >= 1) outcome = 20;
            else {
                outcome = 8;
                flags.push("expired-no-touch"); // time-censored — weakest calibration row
                // v10.9.2 expiry-cause attribution — MFE in R units names WHY it censored
                const slPct = row.entryPrice > 0 ? Math.abs(row.stopLoss - row.entryPrice) / row.entryPrice * 100 : 0;
                if (slPct > 0 && row.leverage > 0) {
                    const mfeR = row.maxPnlPercent / row.leverage / slPct;
                    if (mfeR < EXP_WRONG_SIDE_R) flags.push("expired-wrong-side");
                    else if (mfeR >= EXP_NO_FOLLOW_R) flags.push("expired-no-follow");
                } // slPct/leverage degenerate → cause unknown, censoring flag alone stands
            }
        } else if (row.status === "CLOSED") {
            outcome = 10;
            flags.push("manual-close");
        }
    } else if (!open) {
        flags.push("status-odd");
    }
    // ── D) representativeness — spacing rail + TTL envelope (0-20)
    let timing = 0;
    let spacingOk = null;
    if (prevCreatedAt) {
        const gapMin = (row.createdAt.getTime() - prevCreatedAt.getTime()) / 60_000;
        spacingOk = gapMin >= spacingMin * 0.98;
        if (spacingOk) timing += 10;
        else {
            timing += 4;
            flags.push("cluster-spawn");
        }
    } else {
        timing += 10; // first record of the cohort — no spacing to violate
    }
    if (settled && row.closedAt) {
        const envelope = row.ttlMinutes * (1 + 0.25 * row.ttlExtensions) + 5;
        const holdMin = (row.closedAt.getTime() - row.createdAt.getTime()) / 60_000;
        if (holdMin <= envelope) timing += 10;
        else flags.push("hold-overrun");
        if (row.ttlExtensions >= 3) flags.push(`ttl-ext×${row.ttlExtensions}`);
    } else if (!settled) {
        timing += 10; // hold envelope not yet measurable — neutral until settle
    }
    const score = Math.round(integrity + plan + outcome + timing);
    const cls = open ? "PENDING" : score >= 75 ? "HEALTHY" : score >= 50 ? "REVIEW" : "CENSORED";
    return {
        serial: row.serial,
        symbol: row.symbol,
        direction: row.direction,
        strategy: row.strategy,
        status: row.status,
        settled,
        pnlPercent: round1(row.pnlPercent),
        holdMin: row.closedAt ? Math.round((row.closedAt.getTime() - row.createdAt.getTime()) / 60_000) : null,
        score,
        cls,
        flags,
        spacingOk
    };
}
async function computeRawcalQuality() {
    if (qualityCache && Date.now() - qualityCache.at < QUALITY_TTL_MS) return qualityCache.data;
    let spacingMin = 12;
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        spacingMin = (await getRawCalState()).spacingMin;
    } catch  {
    /* default rail */ }
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            symbol: true,
            direction: true,
            strategy: true,
            status: true,
            reachedTp: true,
            pnlPercent: true,
            ttlMinutes: true,
            ttlExtensions: true,
            entryPrice: true,
            tp1: true,
            tp2: true,
            tp3: true,
            stopLoss: true,
            riskReward: true,
            leverage: true,
            maxPnlPercent: true,
            expiresAt: true,
            createdAt: true,
            closedAt: true,
            factorsJson: true,
            flowJson: true,
            mtfJson: true
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 200
    });
    const asc = [
        ...rows
    ].reverse(); // asc for spacing diffs
    const scored = asc.map((r, i)=>scoreSample(r, i > 0 ? asc[i - 1].createdAt : null, spacingMin));
    const settledSamples = scored.filter((s)=>s.settled);
    const settledRaw = settledSamples.length;
    const openRaw = scored.filter((s)=>!s.settled).length;
    const healthy = settledSamples.filter((s)=>s.cls === "HEALTHY").length;
    const review = settledSamples.filter((s)=>s.cls === "REVIEW").length;
    const censored = settledSamples.filter((s)=>s.cls === "CENSORED").length;
    const healthyPct = pct(healthy, settledRaw);
    // informative = fully readable outcome: TP/SL proved the plan, or EXPIRED
    // after a TP touch (partially readable). EXPIRED-no-touch / CLOSED excluded.
    const informativePct = pct(settledSamples.filter((s)=>[
            "TP1",
            "TP2",
            "TP3",
            "SL"
        ].includes(s.status) || s.status === "EXPIRED" && !s.flags.includes("expired-no-touch")).length, settledRaw);
    const expiredNoTouch = settledSamples.filter((s)=>s.flags.includes("expired-no-touch")).length;
    const expiryCauses = {
        wrongSide: expiredNoTouch ? settledSamples.filter((s)=>s.flags.includes("expired-wrong-side")).length : 0,
        noFollow: expiredNoTouch ? settledSamples.filter((s)=>s.flags.includes("expired-no-follow")).length : 0,
        mixed: 0
    };
    expiryCauses.mixed = Math.max(0, expiredNoTouch - expiryCauses.wrongSide - expiryCauses.noFollow);
    // ── post-filter cohort — reuses the cohort-consistent scores (spacing vs true
    // predecessor) by index alignment with `asc`, not a re-scored sub-list.
    const postScored = asc.map((r, i)=>r.createdAt.getTime() >= FILTER_ERA_START_MS ? scored[i] : null).filter((s)=>s !== null);
    const postSettled = postScored.filter((s)=>s.settled);
    const postInformativePct = pct(postSettled.filter((s)=>[
            "TP1",
            "TP2",
            "TP3",
            "SL"
        ].includes(s.status) || s.status === "EXPIRED" && !s.flags.includes("expired-no-touch")).length, postSettled.length);
    const postExpiryRatePct = pct(postSettled.filter((s)=>s.flags.includes("expired-no-touch")).length, postSettled.length);
    const postFilterCohort = {
        since: new Date(FILTER_ERA_START_MS).toISOString(),
        n: postScored.length,
        settled: postSettled.length,
        informativePct: postInformativePct,
        expiryRatePct: postExpiryRatePct
    };
    const snapshotOk = scored.filter((s)=>!s.flags.includes("no-factors") && !s.flags.includes("no-flow") && !s.flags.includes("no-mtf")).length;
    const snapshotPct = pct(snapshotOk, scored.length);
    const symAcc = new Map();
    let longs = 0;
    for (const s of settledSamples){
        symAcc.set(s.symbol, (symAcc.get(s.symbol) ?? 0) + 1);
        if (s.direction === "LONG") longs++;
    }
    const symbols = symAcc.size;
    const topSymbolShare = symbols ? Math.max(...symAcc.values()) / settledRaw * 100 : null;
    const longPct = pct(longs, settledRaw);
    const shortPct = longPct !== null ? round1(100 - longPct) : null;
    const holds = settledSamples.map((s)=>s.holdMin).filter((h)=>h !== null);
    const meanAbsPnl = settledRaw ? round1(settledSamples.reduce((a, s)=>a + Math.abs(s.pnlPercent), 0) / settledRaw) : null;
    const meanHoldMin = holds.length ? Math.round(holds.reduce((a, b)=>a + b, 0) / holds.length) : null;
    const clusterCount = scored.filter((s)=>s.flags.includes("cluster-spawn")).length;
    // ── warnings (priority-ordered, sample-size-guarded — no noise at n=1) ──
    const warnings = [];
    if (settledRaw >= 3 && informativePct !== null && informativePct < 70) warnings.push(`informative ratio ${informativePct}% < 70% — EXPIRED censoring weakens R6 factor attribution`);
    if (settledRaw >= 5 && topSymbolShare !== null && topSymbolShare > 40) warnings.push(`symbol concentration ${round1(topSymbolShare)}% in one market — R6 may overfit`);
    if (settledRaw >= 5 && (longPct === null || shortPct === null || Math.max(longPct, shortPct ?? 0) > 75)) warnings.push(`side imbalance ${longPct ?? "—"}L/${shortPct ?? "—"}S — thin counter-direction evidence`);
    if (scored.length >= 2 && snapshotPct !== null && snapshotPct < 80) warnings.push(`deploy snapshots complete on ${snapshotPct}% of the cohort — factor attribution degraded`);
    if (clusterCount >= 2) warnings.push(`${clusterCount} records issued inside the ${spacingMin}min rail — burst cluster, correlated samples`);
    if (settledRaw >= 3 && healthyPct !== null && healthyPct < HEALTH_FLOOR) warnings.push(`healthy ${healthyPct}% below the ${HEALTH_FLOOR}% R6 floor`);
    // ── R6 gate verdict — v10.9.1 EPOCH-WINDOWED ──
    // Blocker 1 (structural, whole-cohort): snapshot integrity — era-independent.
    // Blocker 2 (regime, epoch window): window informative ratio below the GREEN
    // bar, only judged once the window carries enough settled rows (≥20) to be
    // statistically meaningful; below the warn-n the window is guarded, not
    // punished (small-sample informative dips are noise, not censoring).
    const blockers = [];
    const winSettled = postSettled.length;
    const winHealthyPct = pct(postSettled.filter((s)=>s.cls === "HEALTHY").length, winSettled);
    if (scored.length >= 2 && snapshotPct !== null && snapshotPct < 50) blockers.push(`snapshots complete on only ${snapshotPct}%`);
    if (winSettled >= GATE_WINDOW_WARN_N && postInformativePct !== null && postInformativePct < GATE_WINDOW_INFORMATIVE) blockers.push(`epoch-window informative ${postInformativePct}% < 50% (n=${winSettled}) — censoring regime`);
    const verdict = settledRaw === 0 || winSettled < GATE_WINDOW_FORMING ? "WARMING" // honest: the window has nothing meaningful to grade yet
     : blockers.length > 0 ? "RED" : winSettled < GATE_WINDOW_MIN_N || winHealthyPct !== null && winHealthyPct < HEALTH_FLOOR ? "AMBER" // window formed but short of the GREEN bar or the health floor
     : "GREEN";
    // UI samples view: settled cohort first (newest first), then in-flight
    const desc = [
        ...scored
    ].reverse();
    const samples = [
        ...desc.filter((s)=>s.settled),
        ...desc.filter((s)=>!s.settled)
    ].slice(0, 12);
    const digest = {
        at: new Date().toISOString(),
        issuedTotal: scored.length,
        openRaw,
        settledRaw,
        healthy,
        review,
        censored,
        healthyPct,
        informativePct,
        expiredNoTouch,
        expiryCauses,
        snapshotPct,
        symbols,
        topSymbolShare: topSymbolShare !== null ? round1(topSymbolShare) : null,
        longPct,
        shortPct,
        meanAbsPnl,
        meanHoldMin,
        clusterCount,
        warnings: warnings.slice(0, 5),
        gate: {
            verdict,
            healthFloor: HEALTH_FLOOR,
            blockers,
            window: {
                since: postFilterCohort.since,
                settled: winSettled,
                healthyPct: winHealthyPct,
                informativePct: postInformativePct
            }
        },
        postFilterCohort,
        samples
    };
    qualityCache = {
        at: Date.now(),
        data: digest
    };
    return digest;
}
function r6GateLine(d) {
    const w = d.gate.window;
    const base = `R6 DATA HEALTH (v10.9.1 epoch-windowed gate — verdict anchors the post-filter window, blended ratios reported for the whole book): raw cohort ${d.settledRaw} settled/${d.issuedTotal} issued · blended healthy ${d.healthyPct ?? "—"}% (floor ${d.gate.healthFloor}) · blended informative ${d.informativePct ?? "—"}% · snapshots ${d.snapshotPct ?? "—"}% · GATE ${d.gate.verdict}` + (w ? ` — window n=${w.settled} informative ${w.informativePct ?? "—"}% healthy ${w.healthyPct ?? "—"}%` : "") + (d.gate.verdict === "WARMING" ? " (window still forming — grading starts at the first window settles)" : "") + (d.gate.blockers.length ? ` · blockers: ${d.gate.blockers.join("; ")}` : "");
    const causes = d.expiryCauses && d.expiryCauses.wrongSide + d.expiryCauses.noFollow + d.expiryCauses.mixed > 0 ? ` · expiry causes: wrong-side ${d.expiryCauses.wrongSide} / no-follow ${d.expiryCauses.noFollow} / mixed ${d.expiryCauses.mixed} (of ${d.expiredNoTouch} no-touch)` : "";
    const post = d.postFilterCohort && d.postFilterCohort.n > 0 ? ` · post-filter cohort n=${d.postFilterCohort.n} (settled ${d.postFilterCohort.settled}) informative ${d.postFilterCohort.informativePct ?? "—"}% expiry ${d.postFilterCohort.expiryRatePct ?? "—"}%` : "";
    return base + causes + post + (d.warnings.length ? ` — watch: ${d.warnings[0]}` : " — no issues");
}
/** Compact digest for EngineSetting persistence (no samples array). */ function compact(d) {
    const { samples: _samples, ...rest } = d;
    void _samples;
    return rest;
}
async function recordRawcalQuality() {
    try {
        const digest = await computeRawcalQuality();
        const changed = digest.settledRaw !== lastSeenSettled;
        if (!changed && Date.now() - lastJournalAt < 10 * 60_000) return null;
        lastJournalAt = Date.now();
        lastSeenSettled = digest.settledRaw;
        const c = compact(digest);
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: QUALITY_KEY
            },
            create: {
                key: QUALITY_KEY,
                value: JSON.stringify(c)
            },
            update: {
                value: JSON.stringify(c)
            }
        }).catch(()=>undefined);
        try {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"]), {
                recursive: true
            });
            const row = {
                kind: "QUALITY",
                t: digest.at,
                issued: digest.issuedTotal,
                settled: digest.settledRaw,
                healthyPct: digest.healthyPct,
                informativePct: digest.informativePct,
                snapshotPct: digest.snapshotPct,
                gate: digest.gate.verdict,
                warns: digest.warnings.length
            };
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], JSON.stringify(row) + "\n", "utf8");
            // opportunistic trim (same policy as the pace journal)
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"]).catch(()=>null);
            if (st && st.size > MAX_JOURNAL_ROWS * 180) {
                const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], "utf8").catch(()=>"");
                const lines = txt.split("\n").filter(Boolean).slice(-MAX_JOURNAL_ROWS);
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], lines.join("\n") + "\n", "utf8").catch(()=>undefined);
            }
        } catch  {
        /* journal best-effort */ }
        return digest;
    } catch (e) {
        console.error("[rawcal-quality] record failed", e);
        return null;
    }
}
async function readPersistedQuality() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: QUALITY_KEY
            }
        });
        if (!row) return null;
        return JSON.parse(row.value);
    } catch  {
        return null;
    }
}
}),
"[project]/src/lib/calibration.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeCalibration",
    ()=>computeCalibration,
    "ensureCalibrationFrozen",
    ()=>ensureCalibrationFrozen,
    "getCalibration",
    ()=>getCalibration,
    "getEffectiveWeights",
    ()=>getEffectiveWeights,
    "refreshCalibration",
    ()=>refreshCalibration
]);
// ── FlowRadar Neo factor-weight calibration (server-only) ──
// v6.3 PROFIT-FIRST CALIBRATION (operator mandate: «کالیبراتور با معیار سود،
// نه تعداد برد»): factor weights are driven by NET PNL expectancy, not raw
// win rate. A factor that wins 44% of the time but bleeds -13%/trade on its
// losers is a LIABILITY (measured: BREAKOUT cohort) — raw WR could not see
// that; expectancy can. Per factor (strong votes only, n≥10 floor):
//
//   expectancy_f = Σ pnlPercent / n          (avg %/trade attributed)
//   profitFactor_f = Σ wins$ / |Σ losses$|   (gross wins ÷ gross losses)
//   weight_f = clamp(1 + expectancy/15 + 0.15·tanh(PF−1), 0.70, 1.30)
//
// Monotone in profit: +4.5%/trade ≈ +0.3 weight, 0%/trade ≈ 1.0, losers sink.
// Calibration goes ACTIVE at ≥30 settled signals, otherwise OBSERVING.
//
// v10.16 R6 QUALITY GATE (audit 4-f): the R6 freeze lift no longer fires on the
// n-count alone — the rawcal sample-quality gate must co-approve (verdict GREEN
// or blended informative ≥ 50%). Rationale: the lift re-fits factor weights on
// the EPOCH-2 book whose recent majority is RAW-CAL capture rows; when the
// raw cohort is censored (informative 43.4% AMBER live), the re-fit optimizes
// against time-censored outcomes. rawcal-quality.ts explicitly never edits the
// calibration math — so the CONDITIONING lives here, at the single decision
// point. No other calibration math is touched.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$quality$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)");
;
;
const KEY = "calibration";
const ACTIVE_AT = 30;
const N_FLOOR = 10;
const MOVING_FACTORS = [
    "EMA STACK",
    "MACD MOMENTUM",
    "RSI POSITION",
    "RANGE BREAKOUT",
    "BOLLINGER EXTREME",
    "VOLUME CONFIRM"
];
/** %/trade of expectancy that maps to a full ±0.3 weight swing */ const EXPECTANCY_SCALE = 15;
/** weight ceiling/floor (matches the deploy-scan clamp in getEffectiveWeights) */ const W_MIN = 0.7;
const W_MAX = 1.3;
// ── v8.4 R3+R6 CALIBRATION FREEZE (module-performance audit 2026-09-11) ──
// Evidence: confidence calibration ran INVERTED (conf-80 bucket avgPnl −14.6%
// vs conf-70 −6.1%; 75%+ basket −$10.10) and the weights floored at 0.70 on
// negative-expectancy factors with n=35 — Wilson-LB far too thin to move on.
// R3: weights are FROZEN at a one-time recalibration over EPOCH-2-only rows.
// R6: no weight may move again until the epoch-2 book reaches minN settled
// samples (100) — then the freeze auto-lifts and normal calibration resumes.
const FROZEN_KEY = "calibration.frozen";
/** v10.16 — audit trail key for lift checks blocked by the rawcal quality gate. */ const R6_LIFT_BLOCKED_KEY = "calibration.r6.liftBlocked";
/** v10.16 — the blended informative share that co-approves the R6 lift
 * (alongside gate verdict GREEN). Matches the rawcal gate's GREEN informative bar. */ const R6_INFORMATIVE_FLOOR = 50;
const FREEZE_MIN_N = 100; // R6 gate — Wilson-LB width ∝ 1/√n; 100 ≈ ±10% at 50%
const FREEZE_EPOCH_TAG = "EPOCH-2";
async function readFreeze() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: FROZEN_KEY
            }
        });
        return row ? JSON.parse(row.value) : null;
    } catch  {
        return null;
    }
}
async function writeFreeze(state) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: FROZEN_KEY
        },
        create: {
            key: FROZEN_KEY,
            value: JSON.stringify(state)
        },
        update: {
            value: JSON.stringify(state)
        }
    });
}
async function ensureCalibrationFrozen() {
    const existing = await readFreeze();
    if (existing) return existing;
    const epoch2 = await computeCalibration(true);
    const state = {
        frozen: true,
        reason: `R3 audit 2026-09-11: calibration INVERTED (conf-80 bucket −14.6%/trade vs conf-70 −6.1%) with n=35 — weights recalibrated on ${epoch2.settled} EPOCH-2 settled rows and frozen (R6: no movement until n≥${FREEZE_MIN_N})`,
        minN: FREEZE_MIN_N,
        epoch: FREEZE_EPOCH_TAG,
        frozenAt: new Date().toISOString(),
        frozenSettled: epoch2.settled
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify({
                ...epoch2,
                updatedAt: new Date().toISOString()
            })
        },
        update: {
            key: KEY,
            value: JSON.stringify({
                ...epoch2,
                updatedAt: new Date().toISOString()
            })
        }
    });
    hot = null; // drop the hot cache so the frozen book is what deploys read
    await writeFreeze(state);
    return state;
}
async function computeCalibration(epoch2Only = false) {
    const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            pnlPercent: true,
            reachedTp: true,
            marginUsd: true,
            factorsJson: true,
            tags: true
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 300
    });
    // v8.4 R3: the frozen book must reflect the CURRENT ledger epoch only —
    // pre-reset rows (different sizing/fee regime) would poison the weights.
    const epochRows = epoch2Only ? settled.filter((s)=>(s.tags ?? "").includes("EPOCH-2")) : settled;
    // accumulate per-factor strong-vote PNL ledgers
    const acc = new Map();
    for (const f of MOVING_FACTORS)acc.set(f, {
        n: 0,
        wins: 0,
        sumPct: 0,
        gains: 0,
        losses: 0,
        sumUsd: 0
    });
    for (const s of epochRows){
        if (!s.factorsJson) continue;
        let votes = [];
        try {
            votes = JSON.parse(s.factorsJson);
        } catch  {
            continue;
        }
        for (const v of votes){
            const cell = acc.get(v.factor);
            if (!cell || Math.abs(v.vote) < 8) continue; // strong votes only
            cell.n++;
            cell.sumPct += s.pnlPercent;
            cell.sumUsd += s.marginUsd * s.pnlPercent / 100;
            if (s.pnlPercent >= 0) cell.gains += s.pnlPercent;
            else cell.losses += Math.abs(s.pnlPercent);
            // v5.4 TP-proven win kept for the transparency column only
            if (s.pnlPercent > 0 || s.reachedTp >= 1) cell.wins++;
        }
    }
    const rows = [];
    const weights = {};
    for (const f of MOVING_FACTORS){
        const cell = acc.get(f);
        if (cell.n < N_FLOOR) continue;
        const expectancy = cell.sumPct / cell.n;
        const pf = cell.losses > 0 ? Math.min(9.9, cell.gains / cell.losses) : 9.9;
        const raw = 1 + expectancy / EXPECTANCY_SCALE + 0.15 * Math.tanh(pf - 1);
        const w = Math.min(W_MAX, Math.max(W_MIN, raw));
        weights[f] = Number(w.toFixed(3));
        rows.push({
            factor: f,
            weight: weights[f],
            n: cell.n,
            expectancy: Number(expectancy.toFixed(2)),
            netPct: Number(cell.sumPct.toFixed(1)),
            profitFactor: Number(pf.toFixed(2)),
            winRate: Number((cell.wins / cell.n * 100).toFixed(1)),
            avgPct: Number(expectancy.toFixed(2)),
            pnlUsd: Number(cell.sumUsd.toFixed(2))
        });
    }
    let updatedAt = null;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) {
            const prev = JSON.parse(row.value);
            updatedAt = prev.updatedAt ?? null;
        }
    } catch  {
    /* ignore */ }
    return {
        status: (epoch2Only ? epochRows : settled).length >= ACTIVE_AT ? "ACTIVE" : "OBSERVING",
        settled: (epoch2Only ? epochRows : settled).length,
        target: ACTIVE_AT,
        criterion: "NET-PNL-EXPECTANCY",
        weights,
        rows,
        updatedAt
    };
}
async function refreshCalibration() {
    const freeze = await ensureCalibrationFrozen();
    const epoch2Settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    });
    if (freeze.frozen && epoch2Settled < freeze.minN) {
        const state = await computeCalibration(true); // display-only
        // v8.4.1 G3 (operator mandate): surface the freeze honestly — the card must
        // not read "OBSERVING 28/30" while weights are locked with a n≥100 lift bar.
        state.status = "FROZEN";
        state.settled = epoch2Settled;
        state.target = freeze.minN;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY
            },
            create: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            },
            update: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            }
        });
        return {
            state,
            auditLine: tickFreezeLine++ % 10 === 0 ? `CALIBRATION FROZEN (R3/R6): weights locked at epoch-2 recalibration (${freeze.frozenSettled} settled) — no movement until n≥${freeze.minN} (now ${epoch2Settled}). Learned/advisor weight writes are ignored while frozen.` : null
        };
    }
    if (freeze.frozen && epoch2Settled >= freeze.minN) {
        // ── v10.16 R6 QUALITY GATE — the n-count alone must not unfreeze. The lift
        // re-fits weights on the ledger; when the RAW-CAL sample quality is AMBER/RED
        // (censored book), the re-fit would learn from censoring, not edge. Require
        // gate GREEN OR blended informative ≥ 50% IN ADDITION to the n-bar.
        // Fail-closed: if the quality digest is unavailable, the freeze HOLDS
        // (an unverifiable book is not a healthy book).
        let quality = null;
        try {
            quality = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$quality$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["computeRawcalQuality"])(); // 30s-memoized, cheap at this cadence (~3.5min)
        } catch  {
            quality = null;
        }
        const qStatus = quality?.gate.verdict ?? "UNAVAILABLE";
        const qInformative = quality?.informativePct ?? null;
        const qualityOk = quality !== null && (quality.gate.verdict === "GREEN" || (quality.informativePct ?? -1) >= R6_INFORMATIVE_FLOOR);
        if (!qualityOk) {
            const blocked = {
                at: new Date().toISOString(),
                informativePct: qInformative,
                status: qStatus,
                epoch2Settled
            };
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: R6_LIFT_BLOCKED_KEY
                },
                create: {
                    key: R6_LIFT_BLOCKED_KEY,
                    value: JSON.stringify(blocked)
                },
                update: {
                    value: JSON.stringify(blocked)
                }
            }).catch(()=>undefined);
            const state = await computeCalibration(true); // display-only — weights stay frozen
            state.status = "FROZEN";
            state.settled = epoch2Settled;
            state.target = freeze.minN;
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: KEY
                },
                create: {
                    key: KEY,
                    value: JSON.stringify({
                        ...state,
                        updatedAt: new Date().toISOString()
                    })
                },
                update: {
                    key: KEY,
                    value: JSON.stringify({
                        ...state,
                        updatedAt: new Date().toISOString()
                    })
                }
            });
            if (r6BlockWarn++ % 10 === 0) {
                console.warn(`[calibration] R6 lift BLOCKED by rawcal quality gate — status ${qStatus}, informative ${qInformative ?? "n/a"}% (need GREEN or ≥${R6_INFORMATIVE_FLOOR}%), epoch2Settled ${epoch2Settled} ≥ n-bar ${freeze.minN}. Weights stay frozen — no re-fit on a censored book (v10.16).`);
            }
            return {
                state,
                auditLine: tickFreezeLine++ % 10 === 0 ? `CALIBRATION STILL FROZEN (R3/R6 + v10.16 quality gate): n-bar reached (${epoch2Settled} ≥ ${freeze.minN}) but rawcal sample gate ${qStatus} (blended informative ${qInformative ?? "n/a"}% < ${R6_INFORMATIVE_FLOOR}% or not GREEN) — no weight re-fit on a censored book until the gate co-approves.` : null
            };
        }
        await writeFreeze({
            ...freeze,
            frozen: false,
            reason: `${freeze.reason} → R6 LIFT: epoch-2 book reached n=${epoch2Settled} ≥ ${freeze.minN} with rawcal quality co-approval (gate ${qStatus}, informative ${qInformative}%) — calibration unfrozen`
        });
        const state = await computeCalibration();
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY
            },
            create: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            },
            update: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            }
        });
        return {
            state,
            auditLine: `R6 CALIBRATION LIFT: epoch-2 book reached n=${epoch2Settled} ≥ ${freeze.minN} — profit-first weight calibration RESUMES (was frozen since ${freeze.frozenAt}).`
        };
    }
    const state = await computeCalibration();
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify({
                ...state,
                updatedAt: new Date().toISOString()
            })
        },
        update: {
            key: KEY,
            value: JSON.stringify({
                ...state,
                updatedAt: new Date().toISOString()
            })
        }
    });
    const auditLine = state.status === "ACTIVE" && state.rows.length > 0 ? `AI CALIBRATION (net-PNL criterion): weights from ${state.settled} settled — ${state.rows.map((r)=>`${r.factor} ×${r.weight.toFixed(2)} (exp ${r.expectancy >= 0 ? "+" : ""}${r.expectancy}%/trade, PF ${r.profitFactor}, n=${r.n})`).join(" · ")}` : null;
    return {
        state,
        auditLine
    };
}
let tickFreezeLine = 0; // rate-limit the frozen audit line inside the 60-tick calibration hook
let r6BlockWarn = 0; // v10.16 — rate-limit the quality-blocked console.warn (~1 line / 35min at the 60-tick cadence)
/** Cached read for hot paths (deploy scan). Falls back to compute on miss. */ let hot = null;
async function getCalibration() {
    if (hot && Date.now() - hot.at < 60_000) return hot.state;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) {
            const state = JSON.parse(row.value);
            hot = {
                at: Date.now(),
                state
            };
            return state;
        }
    } catch  {
    /* ignore */ }
    const state = await computeCalibration();
    hot = {
        at: Date.now(),
        state
    };
    return state;
}
async function getEffectiveWeights() {
    const cal = await getCalibration();
    const weights = {
        ...cal.weights
    };
    let source = Object.keys(weights).length ? "calibration" : "none";
    // v8.4 R6: while frozen, learned autotune adoption is ignored — the whole
    // point of the freeze is that n=35 evidence must not steer live scoring.
    if (source === "calibration" && (await readFreeze())?.frozen) {
        return {
            weights,
            source: "frozen"
        };
    }
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "backtest.autotune"
            }
        });
        if (row) {
            const at = JSON.parse(row.value);
            if (at.adopted && at.adoptedWeights) {
                for (const [f, w] of Object.entries(at.adoptedWeights)){
                    const base = weights[f] ?? 1;
                    weights[f] = Number(Math.min(1.3, Math.max(0.7, base * w)).toFixed(3));
                }
                source = Object.keys(cal.weights).length ? "calibration×autotune" : "autotune";
            }
        }
    } catch  {
    /* ignore */ }
    return {
        weights,
        source
    };
}
}),
"[project]/src/lib/backtest.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAutotune",
    ()=>getAutotune,
    "getBacktest",
    ()=>getBacktest,
    "getBacktestBundle",
    ()=>getBacktestBundle,
    "getLearnerAutoState",
    ()=>getLearnerAutoState,
    "getRuns",
    ()=>getRuns,
    "isAutotuneRunning",
    ()=>isAutotuneRunning,
    "learnedGateAllows",
    ()=>learnedGateAllows,
    "maybeAutoLearner",
    ()=>maybeAutoLearner,
    "runAutotune",
    ()=>runAutotune,
    "runBacktest",
    ()=>runBacktest,
    "simulate",
    ()=>simulate
]);
// ── FlowRadar Neo replayed-history performance learner (v5.0, server-only) ──
// FORCES the engine to learn from PAST data instead of staying static:
//   1. REPLAY  — real Binance klines candle-by-candle through the exact
//      confluence+gate scorer with the real deployment ladder + fee NET math.
//   2. AUTO-TUNE — coordinate sweep over factor weights around the current
//      baseline; adopts the best combo ONLY when it genuinely improves the
//      objective (Wilson-LB + expectancy) — otherwise the baseline stands.
//   3. LEARNING PROGRESS — every run is appended to a persistent runs ring so
//      the operator can watch WR/expectancy/Wilson-LB evolve run over run.
//   4. SCHEDULER — re-runs itself every LEARNER_AUTO_H (default 6h), so the
//      learned mean keeps moving as new history accrues.
// Its verdicts feed the LEARNED GATE that decides when live auto-signals start.
//
// ── v10.16 PARITY FIX ────────────────────────────────────────────────────
// Settlement mirrors engine.ts resolveSignals (engine.ts:439-662): tranche
// 50/30/20 (LADDER_TRANCHES, accounting.ts:47) banked at RUNG prices, BE-trail
// at TP1 (stop := entry, engine.ts:493), +1R trail at TP2 (stop := tp1 rung,
// engine.ts:489), TP3 runner priced at the deploy-time tp3 RUNG — never the old
// 2.6R-on-full-margin projection (engine.ts:597) — SL-first ordering per candle
// (engine.ts:467/474), a single feeBreakdown NET pass on the full notional with
// the tranche-weighted move (engine.ts:607, accounting.ts:49-57), the mid-ladder
// BE arm (engine.ts:508-514) and early time-exit (engine.ts:515-541) evaluated
// at the candle close, and OPEN-SYMBOL DEDUP replacing the fabricated 24h
// per-symbol cooldown (engine.ts:989+1004 — live dedups open symbols only).
// Remaining known delta: dynamic TTL-extension gate not simulated (fixed TTL =
// conservative; live gate at engine.ts:541-562).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indicators.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accounting.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$calibration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/calibration.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
;
;
;
;
;
;
const INTERVAL = "15m";
const CANDLES = 500; // ~5.2 days per symbol
const WARMUP = 60;
const BASE_STEP = 2; // baseline evaluates every 2nd candle (30min grid)
const SWEEP_STEP = 4; // sweeps use a coarser grid (60min) for speed
const TTL_MIN = {
    "AI-SCALP": 75,
    BREAKOUT: 120,
    MOMENTUM: 150,
    "MEAN-REVERT": 90,
    "AI-SWING": 240
};
const KEY_BT = "backtest";
const KEY_RUNS = "backtest.runs";
const KEY_AT = "backtest.autotune";
// ── kline cache: every sweep reuses ONE fetch per symbol ──────
const klineCache = new Map();
const KLINE_TTL = 10 * 60_000;
async function primeKlines(symbols) {
    const ok = [];
    for (const s of symbols){
        const hit = klineCache.get(s);
        if (hit && Date.now() - hit.at < KLINE_TTL) {
            ok.push(s);
            continue;
        }
        try {
            const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(s, INTERVAL, CANDLES);
            klineCache.set(s, {
                at: Date.now(),
                candles
            });
            ok.push(s);
        } catch  {
        /* skip symbol this run */ }
    }
    return ok;
}
function wilsonLowerBound(wins, n, z = 1.96) {
    if (n === 0) return 0;
    const p = wins / n;
    const denom = 1 + z * z / n;
    const centre = p + z * z / (2 * n);
    const margin = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n));
    return Math.max(0, (centre - margin) / denom) * 100;
}
/** learner objective: Wilson-LB dominates, expectancy breaks ties, small-n disqualified. */ function objectiveOf(res) {
    if (res.n < 12) return -999;
    return res.wilsonLB + Math.max(-15, Math.min(20, res.avgNetPct * 10));
}
function simulate(candles, entryIdx, dir, entry, sl, tp1, tp2, tp3, ttlCandles, ctx) {
    const isLong = dir === "LONG";
    const slDist = Math.abs(entry - sl) / entry;
    const lev = Math.round(Math.min(20, Math.max(5, 60 / Math.max(0.7, slDist * 100)))); // mirror engine leverage pick
    const rGross = slDist * 100 * lev; // 1R in levered %-on-margin — engine.ts:533 (rAnchor = initialStopLoss = deploy stop `sl`)
    const moveAtPct = (px)=>(px - entry) / entry * (isLong ? 1 : -1) * 100; // UNLEVERED — engine.ts:584
    const ttlMinutes = ttlCandles * 15;
    let stop = sl; // EFFECTIVE (trailed) stop — v5.4 semantics: trailed stops are real (engine.ts:461, 477-481)
    let reachedTp = 0; // TP-PROVEN ledger (engine.ts:469-472)
    let beBank = null; // v11.2 BE-BANK — parity with the live ledger (engine.ts resolveSignals)
    // ── v6.6 TRANCHE-AWARE NET ACCOUNTING (arithmetic copied verbatim from engine.ts:569-607) ──
    function finalize(outcome, exitIdx, mark) {
        let finalMovePct;
        // v11.2 BE-BANK tranche — parity with engine.ts settlement: the banked leg
        // exits at its arm mark, the ladder weights scale by 1−frac so tranches
        // still sum to 1. Legacy rows (never banked) keep the exact old math.
        const remain = beBank ? 1 - beBank.frac : 1;
        if (reachedTp >= 1) {
            // TRANCHES FIRST — 50%/30% already left the book at their RUNG prices while
            // the trade was open; the runner leg exits by final status: TP3 → tp3 rung
            // (a deploy-time price stop moves can never touch) · SL → EFFECTIVE (trailed)
            // stop · EXPIRED → closing mark (engine.ts:592-601).
            const runnerMove = outcome === "TP3" ? moveAtPct(tp3) : outcome === "SL" ? moveAtPct(stop) : moveAtPct(mark);
            const tranches = [];
            if (beBank) tranches.push({
                weight: beBank.frac,
                movePct: beBank.movePct
            });
            tranches.push({
                weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp1 * remain,
                movePct: moveAtPct(tp1)
            });
            if (reachedTp >= 2) tranches.push({
                weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp2 * remain,
                movePct: moveAtPct(tp2)
            });
            tranches.push({
                weight: (1 - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp1 - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp2) * remain,
                movePct: runnerMove
            });
            finalMovePct = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ladderWeightedMove"])(tranches);
        } else if (beBank) {
            // BE-banked, no rung — bank leg @ arm mark + remainder at the real exit
            // (SL → the post-arm stop at entry · EXPIRED → the closing mark).
            finalMovePct = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ladderWeightedMove"])([
                {
                    weight: beBank.frac,
                    movePct: beBank.movePct
                },
                {
                    weight: remain,
                    movePct: outcome === "SL" ? moveAtPct(stop) : moveAtPct(mark)
                }
            ]);
        } else if (outcome === "SL") {
            finalMovePct = moveAtPct(stop); // effective (trailed) stop is the real exit — nothing was banked (engine.ts:602-603)
        } else {
            finalMovePct = moveAtPct(mark); // EXPIRED without a banked rung — mark on full margin (engine.ts:604-605)
        }
        return {
            outcome,
            movePct: finalMovePct,
            lev,
            heldMin: (exitIdx - entryIdx) * 15,
            reachedTp,
            exitIdx
        };
    }
    for(let j = entryIdx + 1; j < candles.length && j <= entryIdx + ttlCandles; j++){
        const c = candles[j];
        const heldMin = (j - entryIdx) * 15;
        // ① SL FIRST — live evaluates hitSl before every TP branch in the same tick
        // (engine.ts:467 + 474). Within one 15m candle the intracandle order is
        // unknowable; the mandated conservative reading stops the trade first.
        // The runner (plus any unbanked margin) exits at the EFFECTIVE stop, which
        // may already be BE/+1R after trails (engine.ts:479, 597, 603).
        if (isLong ? c.low <= stop : c.high >= stop) return finalize("SL", j, stop);
        // ② TP ladder — banks price at RUNG levels exactly like the live ledger
        // (engine.ts:598-600). A tp3 touch geometrically implies tp1+tp2 were touched
        // (same-side extremes), so reachedTp=3 prices all three legs below.
        if (isLong ? c.high >= tp3 : c.low <= tp3) {
            reachedTp = 3;
            return finalize("TP3", j, tp3); // runner exits at the tp3 RUNG — engine.ts:597
        }
        if (isLong ? c.high >= tp2 : c.low <= tp2) {
            reachedTp = 2; // TP1 leg banked earlier or same candle — both legs priced in finalize
            stop = tp1; // v5.4: trail to the TP1 RUNG = the announced +1R lock (engine.ts:489; tp1 = entry ± 1×risk, engine.ts:1515)
        } else if (isLong ? c.high >= tp1 : c.low <= tp1) {
            reachedTp = 1;
            stop = entry; // v5.4: breakeven trail enforced at TP1 (engine.ts:493)
        }
        // ③ mid-ladder BE arm / ④ early time-exit — only while UNBANKED (live
        // requires s.status === "ACTIVE", engine.ts:508 + 527). Mark-based checks
        // evaluate at the candle CLOSE — the coarse-grained analogue of the live
        // 3.5s tick. Live orders these as one else-if chain per tick (508 → 515).
        if (reachedTp === 0) {
            const closeMovePct = moveAtPct(c.close);
            const stillUntrailed = isLong ? stop < entry : stop > entry; // engine.ts:509
            if (stillUntrailed && (ctx.gate.beArmRMult > 0 && slDist * 100 > 0 && closeMovePct >= ctx.gate.beArmRMult * slDist * 100 || ctx.gate.beArmMovePct > 0 && closeMovePct >= ctx.gate.beArmMovePct || ctx.gate.beTrailPct > 0 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(ctx.margin, lev, closeMovePct, heldMin).netPct >= ctx.gate.beTrailPct)) {
                // v11.2 STRUCTURAL R-ARM + BE-BANK (engine.ts:699-738): primary trigger
                // = the trade's own risk geometry (price ≥ beArmRMult × slDist), the
                // absolute-price arm stays as the wide-stop ceiling, the legacy NET arm
                // stays governor-available. The bank tranche is captured at the arm
                // CLOSE mark (candle-close analogue of the live 3.5s tick mark).
                stop = entry;
                if (ctx.gate.beBankFrac > 0) beBank = {
                    frac: ctx.gate.beBankFrac,
                    movePct: closeMovePct
                };
            } else if (ctx.gate.earlyExitGuard > 0 && heldMin >= ctx.gate.earlyExitFrac * ttlMinutes) {
                // v8.4 R2/R7 EARLY TIME-EXIT (engine.ts:515-541): an unbanked trade after
                // earlyExitFrac of TTL closes at the mark when ADVERSE (NET ≤ −earlyExitR × 1R)
                // or STALLED (|gross| ≤ 0.15R) — booked EXPIRED, not ridden to −1R.
                const fb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(ctx.margin, lev, closeMovePct, heldMin);
                const adverse = ctx.gate.earlyExitR > 0 && fb.netPct <= -(ctx.gate.earlyExitR * rGross);
                const stalled = Math.abs(closeMovePct * lev) <= 0.15 * rGross;
                if (adverse || stalled) return finalize("EXPIRED", j, c.close);
            }
        }
    }
    // ⑤ TTL expiry — auto-close at the closing mark (engine.ts:541-567 + 597/605).
    // KNOWN DELTA: the live DYNAMIC EXPIRY GATE (TTL extensions, engine.ts:541-562)
    // is not simulated — fixed TTL is the conservative bound.
    const endIdx = Math.min(candles.length - 1, entryIdx + ttlCandles);
    return finalize("EXPIRED", endIdx, candles[endIdx].close);
}
async function runBacktest(opts = {}) {
    const t0 = Date.now();
    const persist = opts.persist !== false;
    const step = opts.step ?? BASE_STEP;
    const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
    const cal = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$calibration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["computeCalibration"])();
    const assets = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
        orderBy: {
            volume24h: "desc"
        },
        take: 12
    });
    const wanted = (opts.symbolsOverride?.length ? opts.symbolsOverride : assets.map((a)=>a.symbol)).slice(0, 12);
    const symbols = await primeKlines(wanted);
    const weights = opts.weights ?? (Object.keys(cal.weights).length ? cal.weights : null);
    const minScore = Math.max(15, Math.min(65, gate.minScore + (opts.minScoreAdj ?? 0)));
    const trades = [];
    let candidatesEvaluated = 0;
    let equity = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ACCOUNT_START_USD"];
    const equityCurve = [
        {
            i: 0,
            equity
        }
    ];
    const factorAcc = new Map();
    let candlesPerSymbol = 0;
    let spanHours = 0;
    for (const symbol of symbols){
        const candles = klineCache.get(symbol)?.candles;
        if (!candles || candles.length < WARMUP + 30) continue;
        candlesPerSymbol = candles.length;
        spanHours = Math.max(spanHours, (candles[candles.length - 1].openTime - candles[0].openTime) / 3600_000);
        // v10.16: open-symbol dedup window for THIS symbol (per-symbol scope, like the
        // live openSymbols set — engine.ts:989)
        let openUntilIdx = -1;
        for(let i = WARMUP; i < candles.length - 5; i += step){
            const c = candles[i];
            // v10.16 OPEN-SYMBOL DEDUP (parity — engine.ts:989 openSymbols fetch +
            // :1004 `if (openSymbols.has(asset.symbol)) return false`, applied at the
            // scan pool BEFORE scoring): a candidate is skipped while its symbol already
            // carries an open simulated position. The previous 24h per-symbol cooldown
            // was FABRICATED — the live engine has no such rule — and it throttled the
            // replay sample ~24× per symbol.
            if (i <= openUntilIdx) continue;
            const snap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["buildSnapshot"])(symbol, candles.slice(0, i + 1));
            if (!snap) continue;
            const conf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["scoreConfluence"])(snap, weights ?? undefined);
            candidatesEvaluated++;
            if (Math.abs(conf.score) < minScore) continue;
            // simulate the ladder
            const isLong = conf.direction === "LONG";
            const entry = c.close;
            const slDistPct = Math.min(4.5, Math.max(0.7, 1.5 * snap.atrPct)) / 100;
            const sl = entry * (isLong ? 1 - slDistPct : 1 + slDistPct);
            const risk = Math.abs(entry - sl);
            const tp1 = isLong ? entry + risk : entry - risk;
            const tp2 = isLong ? entry + risk * 1.8 : entry - risk * 1.8;
            const tp3 = isLong ? entry + risk * 2.6 : entry - risk * 2.6;
            const ttlCandles = Math.round((TTL_MIN[conf.strategy] ?? 120) / 15);
            // margin sized BEFORE the walk — the live mid-trade BE-arm reads the real
            // position margin for its NET check (engine.ts:456 + :510)
            const margin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["confidenceMargin"])(conf.confidence, equity, equity * 0.9);
            const sim = simulate(candles, i, conf.direction, entry, sl, tp1, tp2, tp3, ttlCandles, {
                margin,
                gate
            });
            // v10.16: the symbol stays dedup-blocked until the simulated position resolves
            openUntilIdx = sim.exitIdx;
            // fee-aware NET on a running $100 equity account — ONE feeBreakdown pass on
            // the FULL notional with the tranche-weighted move (engine.ts:607; the three
            // exit fills sum to one position, so commission/swap totals are unchanged —
            // accounting.ts:49-57). sim.movePct = UNLEVERED weighted move.
            const lev = sim.lev;
            const fb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(margin, lev, sim.movePct, sim.heldMin);
            equity += fb.netUsd;
            equityCurve.push({
                i: trades.length + 1,
                equity: Number(equity.toFixed(2))
            });
            // win stays NET-based (exported stat semantics unchanged); with tranche
            // accounting a TP1-banked round-trip now nets ≈ +0.5R−fees like live. Note:
            // live regime telemetry additionally counts any reachedTp≥1 close as a win
            // (engine.ts:615) — the backtest WR deliberately keeps its NET definition.
            const win = fb.netPct > 0;
            for (const v of conf.votes){
                if (Math.abs(v.vote) < 8) continue;
                const cell = factorAcc.get(v.factor) ?? {
                    wins: 0,
                    n: 0
                };
                cell.n++;
                if (win) cell.wins++;
                factorAcc.set(v.factor, cell);
            }
            trades.push({
                symbol,
                openedAt: c.openTime,
                direction: conf.direction,
                score: conf.score,
                strategy: conf.strategy,
                confidence: conf.confidence,
                outcome: sim.outcome,
                grossPct: Number((sim.movePct * sim.lev).toFixed(2)),
                netPct: Number(fb.netPct.toFixed(2)),
                netUsd: Number(fb.netUsd.toFixed(3)),
                heldMin: sim.heldMin,
                votes: conf.votes.map((v)=>({
                        factor: v.factor,
                        vote: v.vote
                    }))
            });
        // v10.16: NO per-symbol cooldown — live re-deploys as soon as the symbol has
        // no open position (engine.ts:1004 dedups OPEN symbols only).
        }
    }
    const n = trades.length;
    const wins = trades.filter((t)=>t.netPct > 0).length;
    const losses = n - wins;
    const winRate = n ? wins / n * 100 : 0;
    const avgNetPct = n ? trades.reduce((a, t)=>a + t.netPct, 0) / n : 0;
    const expectancyR = n ? trades.reduce((a, t)=>a + t.netPct / 100, 0) / n : 0;
    const wilsonLB = wilsonLowerBound(wins, n);
    const stratAcc = new Map();
    for (const t of trades){
        const cell = stratAcc.get(t.strategy) ?? {
            n: 0,
            wins: 0,
            net: 0
        };
        cell.n++;
        if (t.netPct > 0) cell.wins++;
        cell.net += t.netPct;
        stratAcc.set(t.strategy, cell);
    }
    const factorLessons = [
        ...factorAcc.entries()
    ].filter(([, c])=>c.n >= 5).map(([factor, c])=>({
            factor,
            n: c.n,
            winRate: Number((c.wins / c.n * 100).toFixed(1))
        })).sort((a, b)=>b.winRate - a.winRate);
    const byStrategy = [
        ...stratAcc.entries()
    ].map(([strategy, c])=>({
            strategy,
            c0: c.n,
            c1: c.wins,
            c2: Number((c.net / c.n).toFixed(2))
        })).sort((a, b)=>b.c0 - a.c0).map(({ strategy, c0, c1, c2 })=>({
            strategy,
            n: c0,
            wins: c1,
            avgNetPct: c2
        }));
    const verdict = n === 0 ? `NO QUALIFYING SETUPS in the replayed window — minScore ${minScore} too strict for this volatility regime` : wilsonLB >= 45 && avgNetPct > 0 ? `LEARNED EDGE CONFIRMED — WR ${winRate.toFixed(0)}% (Wilson-LB ${wilsonLB.toFixed(0)}%) · expectancy ${avgNetPct.toFixed(2)}%/trade NET — live auto-deployment UNLOCKED by the learned gate` : wilsonLB >= 40 ? `MARGINAL — WR ${winRate.toFixed(0)}% (LB ${wilsonLB.toFixed(0)}%), expectancy ${avgNetPct.toFixed(2)}%/trade — auto-deploy stays gated, keep observing` : `NO LEARNED EDGE — WR ${winRate.toFixed(0)}% (LB ${wilsonLB.toFixed(0)}%), expectancy ${avgNetPct.toFixed(2)}%/trade NET — live auto-deployment stays SUPPRESSED until recalibration`;
    const objective = objectiveOf({
        n,
        wilsonLB,
        avgNetPct
    });
    const result = {
        ranAt: new Date().toISOString(),
        engine: "FLOWRADAR-NEO v5.1 BACKTEST & LEARNER",
        label: opts.label ?? (persist ? "REPLAY" : "sweep"),
        symbolsScanned: symbols,
        candlesPerSymbol,
        spanHours: Number(spanHours.toFixed(1)),
        candidatesEvaluated,
        n,
        wins,
        losses,
        winRate: Number(winRate.toFixed(1)),
        wilsonLB: Number(wilsonLB.toFixed(1)),
        avgNetPct: Number(avgNetPct.toFixed(2)),
        expectancyR: Number(expectancyR.toFixed(3)),
        totalNetUsd: Number((equity - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ACCOUNT_START_USD"]).toFixed(2)),
        equityEnd: Number(equity.toFixed(2)),
        byStrategy,
        factorLessons,
        equityCurve: equityCurve.slice(-64),
        trades: persist ? trades.slice(-24).reverse() : [],
        verdict,
        calibration: {
            status: cal.status,
            settled: cal.settled,
            target: cal.target
        },
        weightsUsed: weights ? Object.fromEntries(Object.entries(weights).map(([k, v])=>[
                k,
                Number(v.toFixed(3))
            ])) : null,
        minScoreAdj: opts.minScoreAdj ?? 0,
        objective: Number(objective.toFixed(1))
    };
    if (persist) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_BT
            },
            create: {
                key: KEY_BT,
                value: JSON.stringify(result)
            },
            update: {
                value: JSON.stringify(result)
            }
        });
        const runs = await getRuns();
        runs.unshift({
            ranAt: result.ranAt,
            label: result.label,
            n,
            winRate: result.winRate,
            wilsonLB: result.wilsonLB,
            avgNetPct: result.avgNetPct,
            equityEnd: result.equityEnd,
            objective: result.objective,
            adopted: null
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_RUNS
            },
            create: {
                key: KEY_RUNS,
                value: JSON.stringify(runs.slice(0, 14))
            },
            update: {
                value: JSON.stringify(runs.slice(0, 14))
            }
        });
    }
    console.log(`[backtest] v5.1 ${result.label} done in ${Date.now() - t0}ms — ${n} sim trades from ${candidatesEvaluated} candidates (step=${step}, minScore=${minScore}) · objective ${result.objective}`);
    return result;
}
// ── AUTO-TUNE: coordinate sweep that can actually IMPROVE the engine ──
const TUNED_FACTORS = [
    "EMA STACK",
    "MACD MOMENTUM",
    "RANGE BREAKOUT",
    "RSI POSITION"
];
const SWEEP_VALUES = [
    0.75,
    0.9,
    1.1,
    1.25
];
const ADOPT_MARGIN = 3; // best must beat baseline objective by ≥3
let autotuneInFlight = false;
function isAutotuneRunning() {
    return autotuneInFlight;
}
async function runAutotune() {
    if (autotuneInFlight) throw new Error("auto-tune already running");
    autotuneInFlight = true;
    try {
        // baseline on the full grid with current effective weights
        const baseline = await runBacktest({
            label: "AUTO-TUNE BASELINE",
            persist: true
        });
        const baseWeights = baseline.weightsUsed ?? {};
        const baseObj = objectiveOf(baseline);
        let best = null;
        let bestCombo = null;
        let trials = 0;
        for (const factor of TUNED_FACTORS){
            for (const val of SWEEP_VALUES){
                // skip combos that equal the untouched baseline weight (1.0 excluded by grid)
                const combo = {
                    ...baseWeights,
                    [factor]: val
                };
                const res = await runBacktest({
                    label: `SWEEP ${factor}×${val}`,
                    weights: combo,
                    step: SWEEP_STEP,
                    persist: false
                });
                trials++;
                if (!best || objectiveOf(res) > objectiveOf(best)) {
                    best = res;
                    bestCombo = combo;
                }
            }
        }
        const bestObj = best ? objectiveOf(best) : -999;
        const delta = Number((bestObj - baseObj).toFixed(1));
        const adopt = best !== null && bestObj >= baseObj + ADOPT_MARGIN && best.n >= baseline.n * 0.8;
        let at = await getAutotune();
        if (!at) {
            at = {
                adoptedAt: null,
                adoptedWeights: null,
                baselineObjective: baseObj,
                bestObjective: bestObj,
                bestCombo: null,
                trials,
                adopted: false,
                lastRunAt: new Date().toISOString(),
                history: []
            };
        }
        at.baselineObjective = Number(baseObj.toFixed(1));
        at.bestObjective = Number(bestObj.toFixed(1));
        at.bestCombo = adopt ? Object.fromEntries(Object.entries(bestCombo).map(([k, v])=>[
                k,
                Number(v.toFixed(3))
            ])) : at.bestCombo;
        at.trials = trials;
        at.adopted = adopt;
        at.lastRunAt = new Date().toISOString();
        if (adopt) at.adoptedAt = at.lastRunAt;
        if (adopt && bestCombo) at.adoptedWeights = Object.fromEntries(Object.entries(bestCombo).map(([k, v])=>[
                k,
                Number(v.toFixed(3))
            ]));
        at.history.unshift({
            at: at.lastRunAt,
            adopted: adopt,
            baseline: at.baselineObjective,
            best: at.bestObjective,
            delta,
            summary: adopt ? `ADOPTED — ${TUNED_FACTORS.filter((f)=>at.adoptedWeights?.[f] !== undefined && at.adoptedWeights[f] !== baseWeights[f]).map((f)=>`${f}×${at.adoptedWeights[f].toFixed(2)}`).join(" ")} — objective ${baseObj.toFixed(1)}→${bestObj.toFixed(1)}` : `NO ADOPTION — best sweep objective ${bestObj.toFixed(1)} < baseline ${baseObj.toFixed(1)} + ${ADOPT_MARGIN} margin; baseline stands`
        });
        at.history = at.history.slice(0, 8);
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_AT
            },
            create: {
                key: KEY_AT,
                value: JSON.stringify(at)
            },
            update: {
                value: JSON.stringify(at)
            }
        });
        // mark the adopted flag on the newest runs rows
        const runs = await getRuns();
        if (runs[0]) runs[0].adopted = adopt;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_RUNS
            },
            create: {
                key: KEY_RUNS,
                value: JSON.stringify(runs.slice(0, 14))
            },
            update: {
                value: JSON.stringify(runs.slice(0, 14))
            }
        });
        console.log(`[backtest:autotune] trials=${trials} baseline=${baseObj.toFixed(1)} best=${bestObj.toFixed(1)} adopted=${adopt}`);
        return {
            baseline,
            best,
            adopted: adopt,
            trials,
            delta
        };
    } finally{
        autotuneInFlight = false;
    }
}
async function getAutotune() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY_AT
            }
        });
        return row ? JSON.parse(row.value) : null;
    } catch  {
        return null;
    }
}
async function getRuns() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY_RUNS
            }
        });
        return row ? JSON.parse(row.value) : [];
    } catch  {
        return [];
    }
}
async function getBacktestBundle() {
    const [result, runs, autotune] = await Promise.all([
        getBacktest(),
        getRuns(),
        getAutotune()
    ]);
    return {
        result,
        runs,
        autotune
    };
}
async function getBacktest() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY_BT
            }
        });
        return row ? JSON.parse(row.value) : null;
    } catch  {
        return null;
    }
}
// ── SCHEDULER: the learner re-runs itself so the mean never goes stale ──
// v6.0 FULL AUTONOMY: the scheduler is ALWAYS ON — the pre-v6 manual
// enable/disable toggle (`setLearnerAuto`) was removed with the operator
// mandate «هیچ حالت دستی برای یادگیری و استقرار نباید باشه». Only the cadence
// (intervalHours) is configurable, and the stored config can never disable it.
const AUTO_KEY = "learner.auto";
const KEY_BASELINE = "learner.baseline"; // v8.4.1 G2 — frozen-mode baseline replay clock
let autoInFlight = false;
let autoLastAt = 0;
const AUTO_MIN_INTERVAL_MS = 60_000; // DB guard between checks
async function getAutoCfg() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: AUTO_KEY
            }
        });
        if (row) {
            const v = JSON.parse(row.value);
            // enabled is FORCED true — a stale persisted pause can never freeze learning
            return {
                enabled: true,
                intervalHours: Math.min(24, Math.max(1, Number(v.intervalHours) || 6))
            };
        }
    } catch  {
    /* defaults */ }
    return {
        enabled: true,
        intervalHours: 6
    };
}
async function getLearnerAutoState() {
    const cfg = await getAutoCfg();
    const at = await getAutotune();
    const last = at?.lastRunAt ?? null;
    const next = last ? new Date(new Date(last).getTime() + cfg.intervalHours * 3600_000).toISOString() : null;
    return {
        ...cfg,
        lastRunAt: last,
        nextRunAt: next,
        running: autoInFlight
    };
}
async function maybeAutoLearner() {
    if (autoInFlight) return;
    if (Date.now() - autoLastAt < AUTO_MIN_INTERVAL_MS) return;
    autoLastAt = Date.now();
    const cfg = await getAutoCfg();
    if (!cfg.enabled) return;
    const at = await getAutotune();
    if (at?.lastRunAt && Date.now() - new Date(at.lastRunAt).getTime() < cfg.intervalHours * 3600_000) return;
    autoInFlight = true;
    void (async ()=>{
        try {
            // v9.0 LIFECYCLE LEARNING (operator request 2026-09-12): TTL-extension,
            // BE-trail and afterlife outcomes are now measured + persisted on every
            // learner cadence — the evidence the governor/advisor read. Self-throttled
            // inside the module (5h floor); failure never blocks the learner.
            void __turbopack_context__.A("[project]/src/lib/lifecycle-learning.ts [app-route] (ecmascript, async loader)").then((m)=>m.recordLifecycleLearning()).catch((e)=>console.error("[lifecycle-learning]", e));
            // v8.4 R6 + v8.4.1 G2 (operator mandate 2026-09-11): while the calibration
            // freeze is ON, autotune ADOPTION stays pointless — getEffectiveWeights
            // ignores adopted weights until the epoch-2 book reaches n≥100. BUT the
            // baseline backtest REPLAY must keep running: learnedGateAllows() consumes
            // it as the second gate-evidence path, and a stale replay froze that path
            // shut too (the deadlock). Decoupled: frozen → baseline replay refreshes
            // on its own 6h clock (KEY_BASELINE), sweep+adoption stay suspended.
            const frozen = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "calibration.frozen"
                }
            }).then((r)=>r ? JSON.parse(r.value).frozen : false).catch(()=>false);
            if (frozen) {
                const lastBase = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                    where: {
                        key: KEY_BASELINE
                    }
                }).then((r)=>r ? JSON.parse(r.value).at : null).catch(()=>null);
                if (lastBase && Date.now() - new Date(lastBase).getTime() < cfg.intervalHours * 3600_000) return;
                const baseline = await runBacktest({
                    label: "AUTO-BASELINE (FROZEN)",
                    persist: true
                });
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                    where: {
                        key: KEY_BASELINE
                    },
                    create: {
                        key: KEY_BASELINE,
                        value: JSON.stringify({
                            at: new Date().toISOString()
                        })
                    },
                    update: {
                        value: JSON.stringify({
                            at: new Date().toISOString()
                        })
                    }
                });
                await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, null, "ENGINE", "info", `AUTO-LEARNER (frozen, R6/G2): baseline replay refreshed — ${baseline.n} sim trades, objective ${baseline.objective}, WR ${baseline.winRate}% (LB ${baseline.wilsonLB?.toFixed(0) ?? "--"}%) — sweep + weight adoption stay SUSPENDED until n≥100; gate evidence stays live.`));
                return;
            }
            const { baseline, adopted, delta } = await runAutotune();
            await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, null, "ENGINE", "ai", `AUTO-LEARNER (6h cycle): replay ${baseline.n} sim trades — objective ${baseline.objective}; auto-tune ${adopted ? `ADOPTED improved weights (Δ+${delta})` : `kept baseline (best sweep Δ${delta >= 0 ? "+" : ""}${delta})`} — learned mean refreshed`));
        } catch (err) {
            console.error("[auto-learner]", err);
        } finally{
            autoInFlight = false;
        }
    })();
}
/** Learned gate: does past performance justify live auto-deployment?
 * v8.4.1 G1 (operator mandate 2026-09-11 «اقدامات بعدی رو کامل و مهندسی انجام بده»):
 * realized WR is now measured over the CURRENT ledger epoch (EPOCH-2 tags) with
 * a ROLLING window of the last 30 settles. The old cumulative all-time book
 * mixed pre-audit geometry (WR poison) into the gate and — combined with the
 * R6 freeze skipping autotune sweeps — deadlocked auto-deployment forever
 * (no deploys → WR can never rise → no deploys). The gate must judge the NEW
 * engine on the NEW book; old rows roll OUT of the window as new ones land. */ const LEARNED_GATE_WINDOW = 30;
const SETTLED_IN = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
async function learnedGateAllows() {
    const bt = await getBacktest();
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    ...SETTLED_IN
                ]
            },
            tags: {
                contains: "EPOCH-2"
            }
        },
        orderBy: {
            createdAt: "desc"
        },
        take: LEARNED_GATE_WINDOW,
        select: {
            pnlPercent: true
        }
    });
    const settled = rows.length;
    const wins = rows.filter((r)=>r.pnlPercent > 0).length;
    const realizedWr = settled >= 1 ? wins / settled * 100 : 0;
    if (settled >= 8 && realizedWr >= 25) return {
        allowed: true,
        reason: `realized WR ${realizedWr.toFixed(0)}% over ${settled} EPOCH-2 settles (rolling window ${LEARNED_GATE_WINDOW}) — above 25% floor`
    };
    if (bt && bt.n >= 20 && bt.wilsonLB >= 45 && bt.avgNetPct > 0) return {
        allowed: true,
        reason: `backtest learner: WR ${bt.winRate}% (Wilson-LB ${bt.wilsonLB}%, n=${bt.n}) — learned edge confirmed`
    };
    if (settled < 8 && (!bt || bt.n < 20)) return {
        allowed: false,
        reason: `insufficient evidence — ${settled}/8 EPOCH-2 settles, ${bt?.n ?? 0}/20 backtest trades`
    };
    return {
        allowed: false,
        reason: `learned performance below threshold — realized WR ${realizedWr.toFixed(0)}% (${settled} EPOCH-2 rolling), backtest LB ${bt?.wilsonLB.toFixed(0) ?? "--"}%`
    };
}
}),
"[project]/src/lib/regime.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "btcSpilloverThrAdj",
    ()=>btcSpilloverThrAdj,
    "bumpRegimeTelemetry",
    ()=>bumpRegimeTelemetry,
    "classifyRegime",
    ()=>classifyRegime,
    "getRegimeCached",
    ()=>getRegimeCached,
    "getRegimeSummary",
    ()=>getRegimeSummary,
    "getRegimeTelemetry",
    ()=>getRegimeTelemetry,
    "peekRegime",
    ()=>peekRegime,
    "regimeRuling",
    ()=>regimeRuling,
    "regimeTagOf",
    ()=>regimeTagOf
]);
// ── FlowRadar Neo market-regime classifier (server-only, v6.3) ──
// Layer-0 filter for the trigger hierarchy: every candidate is priced by the
// regime it lives in. TREND regimes punish counter-trend entries, CHOP punishes
// breakout chasing, VOLATILE cuts size and widens stops.
// Pure candle math — no invented data: everything derives from real klines.
//
// ── v6.3 REGIME FILTER HARDENING (operator mandate #2) ──
// Grounds: live ledger showed 94% of deploys landed in CHOP (WR 41%, net −$)
// while TREND deploys won 83% — the old soft penalties (−7 score, ×0.8 size)
// did not actually keep the engine out of rotational chop. Changes:
//   · RegimeRuling gains thrAdj — a per-candidate MIN_SCORE threshold
//     adjustment. MIN_SCORE stops being one flat number: the EFFECTIVE
//     threshold = gate.minScore + thrAdj (+ BTC spillover at guard L2).
//   · regimeGuard levels (governor-owned knob):
//       L0 — legacy soft penalties only
//       L1 — HARD VETO: BREAKOUT/MOMENTUM in strong chop (strength ≥ 0.6);
//            heavy threshold surcharge (+10) in moderate chop
//       L2 — full guard: + BTC-spillover counter-trend surcharge (engine
//            applies btcSpilloverThrAdj) + MEAN-REVERT veto in VOLATILE
//   · Per-regime outcome telemetry (n/wins/net $) persisted so the governor
//     reads a REGIME LEDGER each cycle and tunes regimeGuard from evidence.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indicators.ts [app-route] (ecmascript)");
;
;
const memo = new Map();
const MEMO_TTL = 90_000;
function percentileRank(series, v) {
    if (series.length < 5) return 0.5;
    const below = series.filter((x)=>x <= v).length;
    return below / series.length;
}
function classifyRegime(candles) {
    if (candles.length < 80) return null;
    const closes = candles.map((c)=>c.close);
    const price = closes[closes.length - 1];
    const e9 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ema"])(closes, 9);
    const e21 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ema"])(closes, 21);
    const emaSpreadPct = (e9[e9.length - 1] - e21[e21.length - 1]) / e21[e21.length - 1] * 100;
    const a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["atr"])(candles);
    const atrPct = a > 0 ? a / price * 100 : 0.5;
    const trendPct = a === 0 ? 0 : emaSpreadPct / a * 100;
    // realized-vol percentile: current ATR% vs trailing 80-candle rolling ATR%
    const volSeries = [];
    for(let i = Math.max(15, candles.length - 80); i < candles.length; i++){
        const seg = candles.slice(Math.max(0, i - 14), i + 1);
        const av = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["atr"])(seg);
        volSeries.push(av / seg[seg.length - 1].close * 100);
    }
    const volPctile = percentileRank(volSeries, atrPct);
    // directional efficiency over last 24 completed candles (Kaufman-style)
    const win = candles.slice(-25, -1);
    const net = Math.abs(win[win.length - 1].close - win[0].open);
    const path = win.reduce((s, c)=>s + Math.abs(c.close - c.open) + Math.abs(c.high - c.low), 0) / 2;
    const efficiency = path === 0 ? 0 : Math.min(1, net / path);
    let regime;
    let note;
    if (volPctile >= 0.88 && Math.abs(trendPct) < 2.2) {
        regime = "VOLATILE";
        note = `ATR% ${atrPct.toFixed(2)} at ${Math.round(volPctile * 100)}th pctile — expansion regime, size cut`;
    } else if (Math.abs(trendPct) >= 1.1 && efficiency >= 0.33) {
        regime = trendPct > 0 ? "TREND_UP" : "TREND_DOWN";
        note = `EMA spread ${emaSpreadPct.toFixed(2)}% = ${Math.abs(trendPct).toFixed(1)}×ATR with ${(efficiency * 100).toFixed(0)}% path efficiency — ${trendPct > 0 ? "markup" : "markdown"} trend`;
    } else {
        regime = "CHOP";
        note = `path efficiency ${(efficiency * 100).toFixed(0)}% below threshold — rotational chop, breakouts decay`;
    }
    const strength = regime === "VOLATILE" ? Math.min(1, (volPctile - 0.7) / 0.3) : Math.min(1, Math.abs(trendPct) / 2.6) * 0.6 + efficiency * 0.4;
    const label = regime === "TREND_UP" ? "TREND ▲" : regime === "TREND_DOWN" ? "TREND ▼" : regime === "CHOP" ? "CHOP ∿" : "VOLATILE ⚡";
    return {
        regime,
        strength: Number(strength.toFixed(2)),
        atrPct: Number(atrPct.toFixed(2)),
        trendPct: Number(trendPct.toFixed(2)),
        volPctile: Number(volPctile.toFixed(2)),
        efficiency: Number(efficiency.toFixed(2)),
        label,
        note
    };
}
function getRegimeCached(symbol, candles) {
    if (!candles || candles.length < 80) return null;
    const hit = memo.get(symbol);
    if (hit && Date.now() - hit.at < MEMO_TTL) return hit.regime;
    const r = classifyRegime(candles);
    if (r) memo.set(symbol, {
        at: Date.now(),
        regime: r
    });
    return r;
}
function peekRegime(symbol) {
    const hit = memo.get(symbol);
    return hit && Date.now() - hit.at < MEMO_TTL * 4 ? hit.regime : null;
}
function regimeRuling(regime, direction, strategy, guard = 1) {
    if (!regime) return {
        ok: true,
        sizeMult: 1,
        slMult: 1,
        scoreAdj: 0,
        thrAdj: 0,
        tag: "REGIME-UNKNOWN"
    };
    const long = direction === "LONG";
    if (regime.regime === "TREND_UP") {
        if (!long && strategy === "MEAN-REVERT") return {
            ok: false,
            reason: `TREND ▲ (${regime.note}) — counter-trend short mean-revert vetoed`,
            sizeMult: 0,
            slMult: 1,
            scoreAdj: 0,
            thrAdj: 0,
            tag: "REGIME-TREND-UP"
        };
        if (!long) return {
            ok: true,
            sizeMult: 0.75,
            slMult: 1.1,
            scoreAdj: -6,
            thrAdj: 8,
            reason: "short against markup trend — penalized (+8 threshold)",
            tag: "REGIME-TREND-UP"
        };
        return {
            ok: true,
            sizeMult: 1,
            slMult: 1,
            scoreAdj: 4,
            thrAdj: -5,
            reason: "with-trend long in markup (−5 threshold: trend alignment admits more)",
            tag: "REGIME-TREND-UP"
        };
    }
    if (regime.regime === "TREND_DOWN") {
        if (long && strategy === "MEAN-REVERT") return {
            ok: false,
            reason: `TREND ▼ (${regime.note}) — counter-trend long mean-revert vetoed`,
            sizeMult: 0,
            slMult: 1,
            scoreAdj: 0,
            thrAdj: 0,
            tag: "REGIME-TREND-DOWN"
        };
        if (long) return {
            ok: true,
            sizeMult: 0.75,
            slMult: 1.1,
            scoreAdj: -6,
            thrAdj: 8,
            reason: "long against markdown trend — penalized (+8 threshold)",
            tag: "REGIME-TREND-DOWN"
        };
        return {
            ok: true,
            sizeMult: 1,
            slMult: 1,
            scoreAdj: 4,
            thrAdj: -5,
            reason: "with-trend short in markdown (−5 threshold: trend alignment admits more)",
            tag: "REGIME-TREND-DOWN"
        };
    }
    if (regime.regime === "CHOP") {
        // ── v9.3 STRONGER CHOP LADDER (operator mandate — «فیلتر قوی‌تر CHOP») ──
        // REGIME LEDGER evidence: 197 of 218 EPOCH-2 closes carried REGIME-CHOP at
        // WR 25.9% / −$29.98 — the old ladder (veto only BREAKOUT/MOMENTUM in
        // strong chop) let the other strategies bleed freely. New guard-governed
        // ladder: L1 vetoes ALL breakout/momentum in ANY chop and taxes every
        // other strategy hard in strong chop; L2 vetoes everything in chop.
        // (v9.4 amendment below: L2 is now the ASYMMETRIC activation — SHORT
        // admitted through the tax ladder, LONG stays vetoed, ledger-cited.)
        //
        // ── v9.4 ASYMMETRIC CHOP LADDER (EQ-100 operator mandate 2026-10-13:
        // «ممیزی کامل … رژیم CHOP را فعال کن») — the blanket L2 chop stop was an
        // over-fit to the AGGREGATE ledger (CHOP cell n=2011 WR 34% net −$16.12).
        // Deep direction-split forensics of the same ledger (EQ-100 audit,
        // 1795 settled REGIME-CHOP rows): the damage is entirely LONG-side while
        // the SHORT book EARNED in every window, including under the CURRENT
        // guard stack (shortGuard=1 HTF-align + QUAD-SHORT + STRATW, FLAT-10):
        //   LONG  book: −$123.69 all-time (n=1031) · −$111.22 Oct · −$108.09 W41+42
        //   SHORT book:  +$37.42 all-time (n=621)  ·  +$37.67 Oct ·  +$40.49 W41+42
        //     AI-SWING|SHORT  +$36.89 W41+42 (n=105, WR 41%)
        //     MEAN-REVERT|SHORT +$12.04 W41+42 (n=51, WR 56.9% — doctrinal rotation fit)
        //   Structural driver: 86% of CHOP rows never touch TP1 (1537/1795
        //   reachedTp=0) — LONGs round-trip via EXPIRED fees + deep −1R stops,
        //   while counter-rotation shorts monetize the decay.
        // L2 is therefore RE-OPENED asymmetrically: LONG vetoed (evidence-ledger),
        // SHORT admitted through the L1 tax ladder (strong chop ×0.7/+10thr,
        // moderate ×0.85/+6thr) — FLAT-10 keeps every margin at exactly $10, the
        // size multipliers remain TAG-ONLY audit metadata. BREAKOUT/MOMENTUM keep
        // their unconditional hard veto (0/9, −$2.58 in chop).
        const strongChop = regime.strength >= 0.6;
        // ── v11.6 CHOP FINAL ACTIVATION (EQ-100 re-audit 2026-10-14, full 2411-row
        // ledger restored from GitHub d7cef8d) ── the asymmetric verdict is
        // CONFIRMED on the complete book:
        //   CHOP all-time: LONG −$959.39 (n=1100, WR 33.3%) · SHORT +$1171.84
        //   (n=812, WR 36.3%). Anatomy: TP1-touch LONG 18.7% vs SHORT 20.3%;
        //   expired-drift LONG −2.95% vs SHORT +0.70%; avgLoss −9.61 vs avgWin
        //   +18.5 — rotational decay bleeds longs and monetizes shorts.
        //   Recent-14d CHOP SHORT cells: AI-SWING +$657.31 (n=266, WR 41.4%) ·
        //   MEAN-REVERT +$416.88 (n=141, WR 43.3%) — the admitted SHORT tax ladder
        //   IS the data-driven CHOP activation and stays live (post-ladder cohort
        //   Oct-13: 5/5 SHORT, 3 wins, +$82.64; post-recovery signals #2410/2411
        //   deployed SHORT in CHOP).
        // NEW CELL FLIP (v11.6): AI-SCALP|CHOP is deep-negative BOTH sides in the
        // recent window (14d: LONG −$245.63 n=146 WR 24% · SHORT −$169.39 n=102
        // WR 19.6%; all-time it was +$31.48 WR 33.3% — the cell decayed through
        // it) and the L1 tax does not save it. AI-SCALP therefore joins
        // BREAKOUT/MOMENTUM in the unconditional CHOP hard-veto. This is the
        // STRUCTURAL half of the fix; the TEMPORAL half is the EQ-97 STRAT-PAUSE
        // switch engaged on AI-SCALP book-wide (non-CHOP cells also bleed) — the
        // veto survives any pause-lift until the cell re-earns its way out.
        if (strategy === "BREAKOUT" || strategy === "MOMENTUM" || strategy === "AI-SCALP") {
            // v6.3 evidence: BREAKOUT in chop bled −$28 at WR 28% — a soft −7 penalty
            // did not keep the engine out. v9.3: guard L1+ hard-vetoes ANY chop
            // (strong or moderate); guard 0 still vetoes the strong-chop extreme.
            // v9.4 ledger re-check: 9 settled chop rows, 0 wins, −$2.58 — veto stands.
            // v11.6: AI-SCALP joins (ledger: scalp decay −$169/−$245 recent-14d, WR
            // 19.6%/24% — above).
            const vetoFamily = strategy === "AI-SCALP" ? "scalp VETOED in chop (v11.6 cell-flip: AI-SCALP −$169.39 SHORT / −$245.63 LONG recent-14d, WR 19.6%/24% — tax ladder cannot save a decayed cell)" : "breakout/momentum VETOED in chop";
            if (guard >= 1 || strongChop) {
                return {
                    ok: false,
                    reason: `CHOP (${regime.note}) — ${vetoFamily} (guard L${guard}, strength ${regime.strength.toFixed(2)}${strongChop ? ", strong" : ""}; ledger 197/218 closes CHOP −$29.98)`,
                    sizeMult: 0,
                    slMult: 1,
                    scoreAdj: 0,
                    thrAdj: 0,
                    tag: "REGIME-CHOP"
                };
            }
            return {
                ok: true,
                sizeMult: 0.7,
                slMult: 1,
                scoreAdj: -7,
                thrAdj: 8,
                reason: `CHOP (${regime.note}) — ${strategy === "AI-SCALP" ? "scalp" : "breakout/momentum"} decays, +8 threshold + size cut ×0.7 (guard L0 moderate-chop residual)`,
                tag: "REGIME-CHOP"
            };
        }
        // v9.4 ASYMMETRIC GUARD L1+ — the EQ-100 activation. NOTE: the asymmetry
        // must hold at L1 TOO, not only at L2: the W41+42 LONG bleed (−$108.09)
        // accrued UNDER L1-style taxation — the tax does not save the LONG book.
        // Live correction: the AI governor auto-softened L2→L1 minutes after the
        // v9.4 deploy (its knob, legal) which would have re-opened the condemned
        // cohort — so the LONG veto is pinned to guard ≥ 1; guard 0 (explicit
        // legacy softening) is the only path that re-opens CHOP LONGs.
        if (guard >= 1) {
            if (long) {
                return {
                    ok: false,
                    reason: `CHOP (${regime.note}) — LONG vetoed in chop at guard L${guard} (EQ-100 ledger: LONG −$111.22 Oct / −$108.09 W41+42, TP1-touch only 14% — rotational decay, strength ${regime.strength.toFixed(2)})`,
                    sizeMult: 0,
                    slMult: 1,
                    scoreAdj: 0,
                    thrAdj: 0,
                    tag: "REGIME-CHOP"
                };
            }
            // v13.4-operator — CHOP SHORT OPENED (operator mandate trace 1a1ae0a3a58bd421, 2026-11-05): the EQ-100 ledger itself crowns CHOP SHORT the winning cohort (+$40.49 W41+42, MR|S WR 56.9%) while the +10/+6 threshold tax was the clean-window suppressor behind the issuance drought. Threshold+conviction tax REMOVED; the size haircut (×0.7/×0.85) is KEPT as residual risk discipline. LONG veto and the BREAKOUT/MOMENTUM/AI-SCALP hard vetoes are UNTOUCHED (protective walls stay).
            return strongChop ? {
                ok: true,
                sizeMult: 0.7,
                slMult: 1,
                scoreAdj: 0,
                thrAdj: 0,
                reason: `CHOP strong (${regime.note}) — SHORT OPENED in chop per operator mandate (EQ-100: CHOP SHORT +$40.49 W41+42, MR|S WR 56.9%): base threshold, size ×0.7 kept`,
                tag: "REGIME-CHOP"
            } : {
                ok: true,
                sizeMult: 0.85,
                slMult: 1,
                scoreAdj: 0,
                thrAdj: 0,
                reason: `CHOP (${regime.note}) — SHORT OPENED in chop per operator mandate (EQ-100: CHOP SHORT +$40.49 W41+42, AI-SWING|S +$36.89 WR41%): base threshold, size ×0.85 kept`,
                tag: "REGIME-CHOP"
            };
        }
        // guard 0 — legacy soft ladder (explicit operator softening only)
        if (strongChop) {
            return {
                ok: true,
                sizeMult: 0.7,
                slMult: 1,
                scoreAdj: -6,
                thrAdj: 10,
                reason: `CHOP strong (${regime.note}) — rotational decay taxes all strategies: +10 threshold, size ×0.7, conviction −6`,
                tag: "REGIME-CHOP"
            };
        }
        return {
            ok: true,
            sizeMult: 0.85,
            slMult: 1,
            scoreAdj: 0,
            thrAdj: 2,
            reason: `rotational regime — mean-revert favored (+2 threshold) (guard L0 legacy soft path)`,
            tag: "REGIME-CHOP"
        };
    }
    // VOLATILE — v6.3: expansion regimes tax EVERY entry (unpredictable wick risk);
    // at guard L2 mean-revert is also vetoed (catching knives in vol spikes).
    if (guard >= 2 && strategy === "MEAN-REVERT") {
        return {
            ok: false,
            reason: `VOLATILE (${regime.note}) — mean-revert vetoed in vol expansion (guard L2 — no knife-catching)`,
            sizeMult: 0,
            slMult: 1.3,
            scoreAdj: 0,
            thrAdj: 0,
            tag: "REGIME-VOLATILE"
        };
    }
    return {
        ok: true,
        sizeMult: 0.6,
        slMult: 1.3,
        scoreAdj: 0,
        thrAdj: 6,
        reason: `VOLATILE (${regime.note}) — margin ×0.6, stops ×1.3, +6 threshold`,
        tag: "REGIME-VOLATILE"
    };
}
function btcSpilloverThrAdj(btcRegime, symbol, direction) {
    if (!btcRegime || symbol === "BTCUSDT" || symbol === "ETHUSDT") return {
        adj: 0,
        reason: null
    };
    if (btcRegime.regime === "TREND_DOWN" && direction === "LONG") return {
        adj: 5,
        reason: `BTC TREND ▼ spillover (+5 threshold on counter-BTC long)`
    };
    if (btcRegime.regime === "TREND_UP" && direction === "SHORT") return {
        adj: 5,
        reason: `BTC TREND ▲ spillover (+5 threshold on counter-BTC short)`
    };
    return {
        adj: 0,
        reason: null
    };
}
// ── v6.3 REGIME OUTCOME TELEMETRY — per-regime realized ledger ──
// resolveSignals bumps this on every close (tag parsed from signal tags); the
// governor reads it as the REGIME LEDGER and tunes regimeGuard from evidence.
const REGIME_TELEMETRY_KEY = "regime.telemetry";
function regimeTagOf(tags) {
    if (!tags) return null;
    const t = tags.split(",").find((x)=>x.startsWith("REGIME-"));
    return t ? t.replace("REGIME-", "") : null;
}
async function bumpRegimeTelemetry(tag, win, pnlUsd) {
    let tel = {};
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: REGIME_TELEMETRY_KEY
            }
        });
        if (row) tel = JSON.parse(row.value);
    } catch  {
    /* fresh */ }
    const cell = tel[tag] ?? {
        n: 0,
        wins: 0,
        pnlUsd: 0
    };
    cell.n += 1;
    if (win) cell.wins += 1;
    cell.pnlUsd = Number((cell.pnlUsd + pnlUsd).toFixed(2));
    tel[tag] = cell;
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: REGIME_TELEMETRY_KEY
        },
        create: {
            key: REGIME_TELEMETRY_KEY,
            value: JSON.stringify(tel)
        },
        update: {
            value: JSON.stringify(tel)
        }
    });
}
async function getRegimeTelemetry() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: REGIME_TELEMETRY_KEY
            }
        });
        if (row) return JSON.parse(row.value);
    } catch  {
    /* fresh */ }
    return {};
}
function getRegimeSummary() {
    const out = [];
    for (const [sym, hit] of memo){
        if (Date.now() - hit.at < MEMO_TTL * 4) {
            out.push({
                symbol: sym,
                regime: hit.regime.regime,
                label: hit.regime.label,
                strength: hit.regime.strength
            });
        }
    }
    return out.sort((a, b)=>b.strength - a.strength).slice(0, 12);
}
}),
"[project]/src/lib/macro.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getMacroSnapshot",
    ()=>getMacroSnapshot,
    "macroHealth",
    ()=>macroHealth,
    "peekMacro",
    ()=>peekMacro
]);
// ── FlowRadar Neo v6.2 macro layer — key-less Fear & Greed feed ─────────
// Architecture review P2 remediation: L4_MACRO was a PERMANENT OBSERVER
// ("no key-less measurable source — never fabricated"). There IS a key-less,
// free, measurable macro sentiment source: the Crypto Fear & Greed Index
// (alternative.me, no API key, aggregated from volatility/momentum/social/
// dominance/trend across the market). This module fetches it on a 30min
// cache with honest degradation: any failure returns null and the trigger
// bus keeps its previous honest "OBSERVING" declaration instead of inventing
// data. Extremes become measurable L4 context triggers (contrarian side).
const FNG_URL = "https://api.alternative.me/fng/?limit=1";
const CACHE_TTL_MS = 30 * 60_000;
const FETCH_TIMEOUT_MS = 6000;
let cache = null;
let inflight = null;
let lastError = null;
async function fetchFng() {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), FETCH_TIMEOUT_MS);
    try {
        const res = await fetch(FNG_URL, {
            signal: ctrl.signal,
            cache: "no-store"
        });
        if (!res.ok) {
            lastError = `HTTP ${res.status}`;
            return null;
        }
        const json = await res.json();
        const row = json.data?.[0];
        const value = Number(row?.value);
        if (!Number.isFinite(value) || value < 0 || value > 100) {
            lastError = "malformed payload";
            return null;
        }
        lastError = null;
        return {
            value,
            classification: row?.value_classification ?? "Unknown",
            fetchedAt: Date.now()
        };
    } catch (e) {
        lastError = e instanceof Error ? e.name : "network error";
        return null;
    } finally{
        clearTimeout(timer);
    }
}
async function getMacroSnapshot() {
    if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) return cache;
    if (!inflight) {
        inflight = fetchFng().then((snap)=>{
            if (snap) cache = snap;
            return snap;
        }).finally(()=>{
            inflight = null;
        });
    }
    return inflight;
}
function peekMacro() {
    return cache;
}
function macroHealth() {
    if (!cache) return {
        hasData: false,
        value: null,
        classification: null,
        ageMin: null,
        lastError
    };
    return {
        hasData: true,
        value: cache.value,
        classification: cache.classification,
        ageMin: Math.round((Date.now() - cache.fetchedAt) / 60_000),
        lastError: null
    };
}
}),
"[project]/src/lib/oi-funding.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getOiFundBoard",
    ()=>getOiFundBoard,
    "maybeOiFundScan",
    ()=>maybeOiFundScan,
    "peekOiFund",
    ()=>peekOiFund
]);
// ── FlowRadar Neo v8.1 OI / FUNDING BOARD (P1 liq-deepening, server-only) ──
// Operator mandate 2026-09-08: «طبق نظر مهندسی P1 و P2 رو کامل اجرا کن».
//
// What P1 adds on top of the existing reactive L3 cascade layer:
//   · a PERSISTENT derivatives board covering the tracked domain with OI deltas
//     across three horizons (15m / 1h / 4h) + funding carry + OI notional —
//     flow.ts only computes a 1h delta on demand with no board.
//   · the raw material the predictive L3-PRE layer needs: "positions still
//     piling in near a liquidation cluster" is a cascade BEFORE it happens.
//
// Cadence & budget (mirrors flow-scanner doctrine): rotating batch of 6
// symbols per call, ≥60s between calls → ~12 REST calls/min worst case on top
// of the flow scanner's ~24. Board persisted as ONE EngineSetting row
// (race-free by construction), in-memory map bounded at 64 symbols.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)");
;
;
;
const BOARD_KEY = "oifund.board";
const BATCH = 6;
const MIN_INTERVAL_MS = 60_000;
const BOARD_CAP = 64;
// ── bounded cache + in-flight dedupe (flow-scanner pattern) ──
const board = new Map();
let boardLoaded = false;
let scanCursor = 0;
let lastScanAt = 0;
let scanInFlight = false;
async function loadBoard() {
    if (boardLoaded) return;
    boardLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: BOARD_KEY
            }
        });
        if (row) {
            const parsed = JSON.parse(row.value);
            for (const r of parsed.rows ?? [])board.set(r.symbol, r);
        }
    } catch  {
    /* cold start — the scanner repopulates within ~10min */ }
}
async function persistBoard() {
    const rows = [
        ...board.values()
    ].sort((a, b)=>(b.oiUsd ?? 0) - (a.oiUsd ?? 0)).slice(0, BOARD_CAP);
    const value = JSON.stringify({
        at: Date.now(),
        rows
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: BOARD_KEY
        },
        create: {
            key: BOARD_KEY,
            value
        },
        update: {
            value
        }
    });
}
// v10.24 Task 34-a: fapi REST goes through the central fapi-gate (telemetry
// lane — a shedded rotation returns nulls and the board keeps its previous
// rows; the op-audit-20260908 carry-over semantics still apply downstream).
async function fapi(path, timeoutMs = 6000) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "telemetry",
        timeoutMs
    });
}
async function scanSymbol(symbol, prem, prev) {
    // v12.2 TASK-52 — OI LADDER: fapi openInterestHist (perp-native; v14.0 — the
    // only rung; on a fapi ban the scan honestly returns null, no invented rows).
    const histB = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeOiHist"])(symbol, "15m", 17).catch(()=>null);
    if (!histB || histB.rows.length < 4) return null; // honest — no invented rows
    const hist = histB.rows.map((r)=>({
            sumOpenInterest: String(r.sumOpenInterest),
            sumOpenInterestValue: String(r.sumOpenInterestValue ?? 0),
            timestamp: r.timestamp
        }));
    const oi = hist.map((h)=>Number(h.sumOpenInterest));
    const cur = oi[oi.length - 1];
    const pct = (barsBack)=>{
        const ref = oi[oi.length - 1 - barsBack];
        return ref !== undefined && ref > 0 ? Number(((cur - ref) / ref * 100).toFixed(2)) : null;
    };
    // z-score of the last 1h change vs its own distribution across the window
    let oiZ1h = null;
    const d1h = pct(4);
    if (d1h !== null && oi.length >= 10) {
        const deltas = [];
        for(let i = 4; i < oi.length; i++){
            const ref = oi[i - 4];
            if (ref > 0) deltas.push((oi[i] - ref) / ref * 100);
        }
        if (deltas.length >= 5) {
            const mean = deltas.reduce((a, b)=>a + b, 0) / deltas.length;
            const std = Math.sqrt(deltas.reduce((a, b)=>a + (b - mean) * (b - mean), 0) / deltas.length);
            if (std > 0) oiZ1h = Number(((d1h - mean) / std).toFixed(2));
        }
    }
    const oiUsdRow = Number(hist[hist.length - 1]?.sumOpenInterestValue ?? 0) || null;
    let oiUsd = oiUsdRow;
    if (!oiUsd) {
        // v14.0 — notional fallback from the Binance composite ticker leg (fapi
        // openInterest × markPrice); null honestly when the fapi plane is banned.
        oiUsd = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerRow"])(symbol).catch(()=>null))?.openInterestValue ?? null;
    }
    // op-audit-20260908: when the batch premiumIndex call missed (transient fapi
    // weight pressure), CARRY OVER the previous funding fields instead of
    // overwriting good data with nulls — funding changes every 8h, staleness of
    // one rotation is harmless, data loss was not.
    return {
        symbol,
        at: Date.now(),
        markPrice: prem ? Number(prem.markPrice) || null : prev?.markPrice ?? null,
        funding8h: prem ? Number((Number(prem.lastFundingRate) * 100).toFixed(4)) : prev?.funding8h ?? null,
        nextFundingAt: prem ? Number(prem.nextFundingTime) || null : prev?.nextFundingAt ?? null,
        oiBase: cur,
        oiUsd: oiUsd ? Number((oiUsd / 1e6).toFixed(2)) : null,
        oiDelta15m: pct(1),
        oiDelta1h: d1h,
        oiDelta4h: pct(16),
        oiZ1h,
        src: histB.source
    };
}
async function maybeOiFundScan(symbols) {
    await loadBoard();
    if (scanInFlight || symbols.length === 0) return;
    if (Date.now() - lastScanAt < MIN_INTERVAL_MS) return;
    scanInFlight = true;
    lastScanAt = Date.now();
    try {
        const batch = [];
        for(let i = 0; i < Math.min(BATCH, symbols.length); i++)batch.push(symbols[(scanCursor + i) % symbols.length]);
        scanCursor = (scanCursor + batch.length) % symbols.length;
        // op-audit-20260908: ONE batched premiumIndex call (no symbol param → ALL
        // markers, weight ~10) replaces 6 per-symbol calls per rotation — funding
        // coverage climbs 6/33 → full domain in one pass AND the per-second fapi
        // weight bursts that tripped -1003 endpoint bans disappear.
        // v12.2 TASK-52 (v14.0 rewrite): when the fapi batch starves, the Binance
        // composite ticker leg feeds the whole rotation instead — the board
        // carries funding only when the fapi plane priced it (spot rows keep
        // funding honestly null, so the carry-over guard below stays truthful).
        const premRows = await fapi(`/fapi/v1/premiumIndex`).catch(()=>null);
        let premMap = new Map();
        for (const p of premRows ?? [])if (p?.symbol) premMap.set(p.symbol, p);
        if (premMap.size === 0) {
            const tickers = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerMap"])().catch(()=>null);
            if (tickers && tickers.size > 0) {
                console.log(`[oi-funding] fapi premiumIndex starved — Binance composite ticker board (${tickers.size} symbols, v14.0)`);
                for (const symbol of batch){
                    const t = tickers.get(symbol);
                    if (t && t.fundingRate !== null) {
                        premMap.set(symbol, {
                            lastFundingRate: String(t.fundingRate),
                            markPrice: String(t.markPrice ?? t.lastPrice),
                            nextFundingTime: t.nextFundingTime ?? 0
                        });
                    }
                }
            }
        }
        for (const symbol of batch){
            const prev = board.get(symbol) ?? null;
            const row = await scanSymbol(symbol, premMap.get(symbol) ?? null, prev).catch(()=>null);
            if (row) board.set(symbol, row);
        }
        await persistBoard();
    } finally{
        scanInFlight = false;
    }
}
function peekOiFund(symbol) {
    const r = board.get(symbol);
    if (!r || Date.now() - r.at > 20 * 60_000) return null;
    return r;
}
async function getOiFundBoard() {
    await loadBoard();
    const rows = [
        ...board.values()
    ].sort((a, b)=>(b.oiUsd ?? 0) - (a.oiUsd ?? 0));
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows: rows.slice(0, 48).map((r)=>({
                ...r,
                oiUsdM: r.oiUsd
            }))
    };
}
}),
"[project]/src/lib/liq-heatmap.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLiqHeat",
    ()=>getLiqHeat,
    "getLiqHeatBoard",
    ()=>getLiqHeatBoard,
    "peekLiqHeat",
    ()=>peekLiqHeat
]);
// ── FlowRadar Neo v8.1 LIQUIDATION HEATMAP (P1 liq-deepening, server-only) ──
// Operator mandate 2026-09-08: «طبق نظر مهندسی P1 و P2 رو کامل اجرا کن».
//
// HONESTY CONTRACT: no exchange publishes leveraged-position maps. This module
// computes the standard volume-mapped ESTIMATE used by Coinglass-class tools:
// recent traded volume is bucketed by price, each bucket is projected through
// the popular leverage tiers (liq price = entry × (1 ∓ 1/lev)), and the
// projected mass is scaled by the symbol's REAL open-interest notional from
// the oi-funding board. Every surface that renders it must keep the
// "ESTIMATE" label — the module refuses to emit numbers when its inputs
// (klines, OI) are missing rather than inventing them.
//
// Semantics (the doctrine that drives the engine hooks):
//   · clusters BELOW price  = long liquidations  — flush fuel: price falling
//     into them tends to ACCELERATE down (magnet for an open/new LONG).
//   · clusters ABOVE price  = short liquidations — squeeze fuel: rallies into
//     them tend to ACCELERATE up (magnet for an open/new SHORT).
//
// Memory law: per-symbol result cache TTL 180s, map bounded at 64 symbols
// (evict-oldest), klines reused from the flow scanner cache when fresh —
// zero extra kline fetches on the hot path.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)"); // v12.3 TASK-52 — kline ladder · v14.0 Binance-only
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$oi$2d$funding$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/oi-funding.ts [app-route] (ecmascript)");
;
;
;
const LEV_TIERS = [
    {
        lev: 10,
        weight: 0.40
    },
    {
        lev: 25,
        weight: 0.35
    },
    {
        lev: 50,
        weight: 0.25
    }
];
const BAND_PCT = 8; // map ±8% around price
const BUCKETS = 24;
const CLUSTER_MIN_SHARE = 0.06; // a bucket needs ≥6% of mapped mass to be "significant"
const CACHE_TTL = 180_000;
const CACHE_CAP = 64;
const heatCache = new Map();
const heatInFlight = new Map();
function evictOldest() {
    if (heatCache.size <= CACHE_CAP) return;
    const oldest = [
        ...heatCache.entries()
    ].sort((a, b)=>a[1].at - b[1].at)[0];
    if (oldest) heatCache.delete(oldest[0]);
}
// v10.24 Task 34-a: klines fetch went through the central fapi-gate.
// v12.3 TASK-52: SPOT-MIRROR is rung 1 (separate rate/ban pool — heat mass is
// volume×price math, venue-agnostic); fapi gate is rung 2. v14.0 Binance-only:
// the heatmap degrades honestly to null when both rungs fail.
async function fetchKlines15m(symbol) {
    const spot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotMirrorKlines"])(symbol, "15m", 96).catch(()=>null);
    if (spot && spot.length > 0) {
        return spot.map((k)=>({
                openTime: k.openTime,
                open: k.open,
                high: k.high,
                low: k.low,
                close: k.close,
                volume: k.volume
            }));
    }
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=15m&limit=96`, {
        priority: "telemetry",
        timeoutMs: 6500
    }).catch(()=>null);
    if (raw && raw.length > 0) {
        return raw.map((k)=>({
                openTime: Number(k[0]),
                open: Number(k[1]),
                high: Number(k[2]),
                low: Number(k[3]),
                close: Number(k[4]),
                volume: Number(k[5])
            }));
    }
    return null;
}
/** Compute the estimated heatmap for one symbol. Returns null when inputs are missing. */ async function computeHeat(symbol, klines) {
    if (!klines || klines.length < 24) return null;
    const candles = klines.slice(0, -1); // closed bars only
    const price = candles[candles.length - 1].close;
    if (!(price > 0)) return null;
    const oiRow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$oi$2d$funding$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekOiFund"])(symbol);
    const oiUsdM = oiRow?.oiUsd ?? null;
    // volume mass per price bucket across the ±8% band (vwap-ish weighting by recency)
    const lo = price * (1 - BAND_PCT / 100);
    const hi = price * (1 + BAND_PCT / 100);
    const step = (hi - lo) / BUCKETS;
    const mass = new Float64Array(BUCKETS);
    const recent = candles.slice(-64); // last 16h of 15m bars
    let bandVol = 0;
    for(let i = 0; i < recent.length; i++){
        const c = recent[i];
        const mid = (c.high + c.low + c.close) / 3;
        if (mid < lo || mid > hi) continue;
        const idx = Math.min(BUCKETS - 1, Math.max(0, Math.floor((mid - lo) / step)));
        mass[idx] += c.volume * (0.5 + i / recent.length * 0.5); // linear recency weight
        bandVol += c.volume;
    }
    if (bandVol <= 0) return null;
    // project each bucket's mass through the leverage tiers, BOTH directions:
    //   bucket price treated as entry → long liq price = entry×(1−1/lev),
    //   short liq price = entry×(1+1/lev); the liq price lands in another bucket.
    const below = new Float64Array(BUCKETS); // long-liq mass per bucket
    const above = new Float64Array(BUCKETS); // short-liq mass per bucket
    const scale = oiUsdM !== null && oiUsdM > 0 ? oiUsdM / bandVol : 1; // $M per unit volume (unscaled → unitless proxy)
    for(let i = 0; i < BUCKETS; i++){
        if (mass[i] <= 0) continue;
        const entry = lo + step * (i + 0.5);
        for (const { lev, weight } of LEV_TIERS){
            const liqLong = entry * (1 - 1 / lev);
            const liqShort = entry * (1 + 1 / lev);
            const w = mass[i] * weight;
            const li = Math.floor((liqLong - lo) / step);
            if (li >= 0 && li < BUCKETS) below[li] += w;
            const si = Math.floor((liqShort - lo) / step);
            if (si >= 0 && si < BUCKETS) above[si] += w;
        }
    }
    // scale is $M per unit base volume (oiUsdM / bandVol) — v is in base units,
    // so v×scale is ALREADY $M. Bug fix 2026-09-08: the previous /1e6 here was a
    // double division (the 1e6 conversion already happened in `scale`) which
    // collapsed every cluster to $0.0M on the board.
    const toUsdM = (v)=>Number((v * scale).toFixed(2));
    const sumBelow = below.reduce((a, b)=>a + b, 0);
    const sumAbove = above.reduce((a, b)=>a + b, 0);
    const total = sumBelow + sumAbove;
    if (total <= 0) return null;
    const clusters = [];
    const push = (i, v, side)=>{
        const share = v / total;
        if (share < CLUSTER_MIN_SHARE) return;
        const p = lo + step * (i + 0.5);
        clusters.push({
            side,
            price: Number(p.toFixed(p > 100 ? 2 : 6)),
            distPct: Number(((p - price) / price * 100).toFixed(2)),
            estUsdM: toUsdM(v),
            sharePct: Number((share * 100).toFixed(1))
        });
    };
    for(let i = 0; i < BUCKETS; i++){
        if (below[i] > 0) push(i, below[i], "LONGS_BELOW");
        if (above[i] > 0) push(i, above[i], "SHORTS_ABOVE");
    }
    clusters.sort((a, b)=>Math.abs(a.distPct) - Math.abs(b.distPct));
    const nearestBelow = clusters.find((c)=>c.side === "LONGS_BELOW") ?? null;
    const nearestAbove = clusters.find((c)=>c.side === "SHORTS_ABOVE") ?? null;
    return {
        symbol,
        at: Date.now(),
        price: Number(price.toFixed(price > 100 ? 2 : 6)),
        oiUsdM,
        oiScaled: oiUsdM !== null && oiUsdM > 0,
        totalBelowUsdM: toUsdM(sumBelow),
        totalAboveUsdM: toUsdM(sumAbove),
        clusters: clusters.slice(0, 12),
        nearestBelow,
        nearestAbove
    };
}
async function loadKlines(symbol) {
    // reuse the flow scanner's fresh 15m cache when available (no extra fetch)
    try {
        const m = await __turbopack_context__.A("[project]/src/lib/flow-scanner.ts [app-route] (ecmascript, async loader)");
        const cached = m.peekFlowKlines(symbol, "15m");
        if (cached && cached.length >= 24) return cached;
    } catch  {
    /* fall through to own fetch */ }
    return fetchKlines15m(symbol);
}
async function getLiqHeat(symbol) {
    const hit = heatCache.get(symbol);
    if (hit && Date.now() - hit.at < CACHE_TTL) return hit.v;
    const existing = heatInFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        const klines = await loadKlines(symbol).catch(()=>null);
        const v = await computeHeat(symbol, klines).catch(()=>null);
        heatCache.set(symbol, {
            at: Date.now(),
            v
        });
        evictOldest();
        return v;
    })();
    heatInFlight.set(symbol, p);
    try {
        return await p;
    } finally{
        heatInFlight.delete(symbol);
    }
}
function peekLiqHeat(symbol) {
    const hit = heatCache.get(symbol);
    if (!hit || !hit.v || Date.now() - hit.at > CACHE_TTL) return null;
    return hit.v;
}
async function getLiqHeatBoard(limit = 10) {
    const { getOiFundBoard } = await __turbopack_context__.A("[project]/src/lib/oi-funding.ts [app-route] (ecmascript, async loader)");
    const board = await getOiFundBoard();
    const symbols = board.rows.slice(0, limit).map((r)=>r.symbol);
    const rows = [];
    for (const s of symbols){
        const h = await getLiqHeat(s).catch(()=>null);
        if (h) rows.push(h);
    }
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows
    };
}
}),
"[project]/src/lib/vol-forecast.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getKlines15m",
    ()=>getKlines15m,
    "getVolBoard",
    ()=>getVolBoard,
    "getVolForecast",
    ()=>getVolForecast,
    "peekVolForecast",
    ()=>peekVolForecast,
    "volGeometry",
    ()=>volGeometry
]);
// ── FlowRadar Neo v8.1 VOLATILITY FORECAST (P2, server-only) ─────────────
// Operator mandate 2026-09-08: «طبق نظر مهندسی P1 و P2 رو کامل اجرا کن».
//
// Model — deterministic, measured only, closed bars only:
//   · EWMA(λ=0.94) on 15m log returns (RiskMetrics recursion) → ewmaBarPct
//     scaled by √4 to the 1h horizon → ewma1hPct
//   · HAR-lite realized blend over the 6h window → har6hPct
//   · ATR%(14) on 15m bars → atr15mPct (shared with the liq-heat reach band)
//   · regime = ewma1hPct vs the symbol's OWN trailing distribution (percentile
//     rank over the last 96 bars, 8-bar steps) — self-referential, honest:
//     LOW <p20 · NORMAL · ELEVATED <p80 · EXTREME ≥p80
//
// Geometry contract consumed by engine.ts deploy path (volGeometry):
//   LOW      → stop ×0.90, RR +0.1  (dead tape: tighter stop, closer targets)
//   NORMAL   → ×1.00, ±0            (unchanged — tag omitted)
//   ELEVATED → stop ×1.05, RR −0.1  (room without paying the far rung)
//   EXTREME  → stop ×1.15, RR −0.2  (eruption tape: wider stop, trimmed targets)
// Cohort tags VOL-REGIME-{LOW|ELEVATED|EXTREME} feed the A/B ledger.
//
// Memory bounds: k15 cache ≤64 symbols × 97 bars (TTL 120s, in-flight dedupe),
// forecast cache ≤64 rows. No unbounded state, no invented numbers.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)"); // v12.3 TASK-52 — kline ladder · v14.0 Binance-only
;
;
;
const CACHE_TTL = 90_000; // recompute at most ~1/min per symbol
const PEEK_TTL = 10 * 60_000; // hot-path read guard — stale rows never gate
const BOARD_KEY = "volforecast.board";
const BOARD_TTL = 30 * 60_000; // persisted board feeds the API on cold boot
// ── geometry table (doctrine in the header) ──
const GEOMETRY = {
    LOW: {
        slMult: 0.9,
        rrAdj: 0.1
    },
    NORMAL: {
        slMult: 1.0,
        rrAdj: 0
    },
    ELEVATED: {
        slMult: 1.05,
        rrAdj: -0.1
    },
    EXTREME: {
        slMult: 1.15,
        rrAdj: -0.2
    }
};
function volGeometry(v) {
    if (!v) return {
        slMult: 1,
        rrAdj: 0,
        tag: null,
        note: null
    };
    if (v.regime === "NORMAL") return {
        slMult: 1,
        rrAdj: 0,
        tag: null,
        note: null
    };
    const g = GEOMETRY[v.regime];
    const tag = `VOL-REGIME-${v.regime}`;
    const note = v.regime === "LOW" ? `regime LOW (self-pct ${v.percentile}, EWMA 1h ${v.ewma1hPct.toFixed(2)}%) → stop ×0.9, targets +0.1R — dead tape, tighten` : v.regime === "ELEVATED" ? `regime ELEVATED (self-pct ${v.percentile}, EWMA 1h ${v.ewma1hPct.toFixed(2)}%) → stop ×1.05, targets −0.1R — hot tape, breathe but trim` : `regime EXTREME (self-pct ${v.percentile}, EWMA 1h ${v.ewma1hPct.toFixed(2)}%) → stop ×1.15, targets −0.2R — eruption tape, survive first`;
    return {
        slMult: g.slMult,
        rrAdj: g.rrAdj,
        tag,
        note
    };
}
const k15Cache = new Map();
const k15InFlight = new Map();
async function getKlines15m(symbol) {
    const hit = k15Cache.get(symbol);
    if (hit && Date.now() - hit.at < 120_000) return hit.candles;
    const existing = k15InFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            // v10.24 Task 34-a: klines through the central fapi-gate (telemetry lane
            // — the deploy path's volGeometry(null) is fail-open NORMAL).
            // v12.3 TASK-52: SPOT-MIRROR is rung 1 (separate rate/ban pool — the
            // vol-geometry is price-path math, venue-agnostic at bps level); fapi
            // gate is rung 2. v14.0: Binance-only — both miss → honest null.
            const spot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotMirrorKlines"])(symbol, "15m", 97);
            let candles = null;
            if (spot && spot.length > 0) {
                candles = spot.map((k)=>({
                        openTime: k.openTime,
                        open: k.open,
                        high: k.high,
                        low: k.low,
                        close: k.close
                    }));
            } else {
                const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=15m&limit=97`, {
                    priority: "telemetry",
                    timeoutMs: 6500
                });
                candles = raw ? raw.map((k)=>({
                        openTime: Number(k[0]),
                        open: Number(k[1]),
                        high: Number(k[2]),
                        low: Number(k[3]),
                        close: Number(k[4])
                    })) : null;
            }
            if (!candles) return null;
            k15Cache.set(symbol, {
                at: Date.now(),
                candles
            });
            if (k15Cache.size > 64) {
                const oldest = [
                    ...k15Cache.entries()
                ].sort((a, b)=>a[1].at - b[1].at)[0];
                if (oldest) k15Cache.delete(oldest[0]);
            }
            return candles;
        } catch  {
            return null;
        } finally{
            k15InFlight.delete(symbol);
        }
    })();
    k15InFlight.set(symbol, p);
    return p;
}
// ── core math (closed bars only — the possibly-unclosed last bar is dropped) ──
function computeForecast(symbol, raw) {
    const candles = raw ? raw.slice(0, -1) : null;
    if (!candles || candles.length < 60) return null;
    const rets = [];
    for(let i = 1; i < candles.length; i++){
        const p0 = candles[i - 1].close;
        const p1 = candles[i].close;
        if (p0 > 0 && p1 > 0) rets.push(Math.log(p1 / p0));
    }
    if (rets.length < 55) return null;
    // EWMA variance (λ=0.94), RiskMetrics recursion
    const lambda = 0.94;
    let ewmaVar = rets[0] * rets[0];
    for(let i = 1; i < rets.length; i++)ewmaVar = lambda * ewmaVar + (1 - lambda) * rets[i] * rets[i];
    const ewmaBarPct = Math.sqrt(ewmaVar) * 100;
    const ewma1hPct = ewmaBarPct * 2; // √4 bars per hour
    // HAR-lite: realized-vol blend over the 6h window (24 bars) vs 24h (96)
    const rv = (n)=>{
        const w = rets.slice(-n);
        if (w.length < Math.min(20, n)) return null;
        const mean = w.reduce((a, b)=>a + b, 0) / w.length;
        return Math.sqrt(w.reduce((a, b)=>a + (b - mean) * (b - mean), 0) / w.length) * 100;
    };
    const rv6h = rv(24);
    const rv1d = rv(96);
    const parts = [
        rv6h,
        rv1d
    ].filter((v)=>v !== null);
    if (parts.length === 0) return null;
    const har6hPct = parts.length === 2 ? 0.6 * rv6h + 0.4 * rv1d : parts[0];
    // ATR%(14) true range on 15m bars
    let atrSum = 0;
    for(let i = candles.length - 14; i < candles.length; i++){
        const c = candles[i];
        const p = candles[i - 1];
        atrSum += Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
    }
    const atr15mPct = atrSum / 14 / candles[candles.length - 1].close * 100;
    // trailing EWMA-1h distribution for the self-percentile rank (96 bars, 8-bar steps)
    const trail = [];
    for(let start = Math.max(0, rets.length - 96); start <= rets.length - 24; start += 8){
        const w = rets.slice(start, start + 24);
        if (w.length < 20) continue;
        let v = w[0] * w[0];
        for(let i = 1; i < w.length; i++)v = lambda * v + (1 - lambda) * w[i] * w[i];
        trail.push(Math.sqrt(v) * 100 * 2);
    }
    const percentile = trail.length >= 6 ? Math.round(trail.filter((v)=>v <= ewma1hPct).length / trail.length * 100) : 50;
    const regime = percentile < 20 ? "LOW" : percentile < 55 ? "NORMAL" : percentile < 80 ? "ELEVATED" : "EXTREME";
    return {
        symbol,
        at: Date.now(),
        ewmaBarPct: Number(ewmaBarPct.toFixed(3)),
        ewma1hPct: Number(ewma1hPct.toFixed(3)),
        har6hPct: Number(har6hPct.toFixed(3)),
        regime,
        percentile,
        atr15mPct: Number(atr15mPct.toFixed(3))
    };
}
// ── caches ──
const forecastCache = new Map();
const inFlight = new Map();
let boardLoaded = false;
async function loadBoard() {
    if (boardLoaded) return;
    boardLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: BOARD_KEY
            }
        });
        if (!row) return;
        const parsed = JSON.parse(row.value);
        if (Date.now() - parsed.at > BOARD_TTL) return;
        for (const r of parsed.rows ?? [])forecastCache.set(r.symbol, {
            at: r.at,
            v: r
        });
    } catch  {
    /* cold start — warms on demand */ }
}
async function persistBoard() {
    try {
        const rows = [
            ...forecastCache.values()
        ].map((e)=>e.v).slice(0, 48);
        const value = JSON.stringify({
            at: Date.now(),
            rows
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: BOARD_KEY
            },
            create: {
                key: BOARD_KEY,
                value
            },
            update: {
                value
            }
        });
    } catch  {
    /* best-effort */ }
}
async function getVolForecast(symbol) {
    await loadBoard();
    const hit = forecastCache.get(symbol);
    if (hit && Date.now() - hit.at < CACHE_TTL) return hit.v;
    const existing = inFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            const candles = await getKlines15m(symbol);
            const v = computeForecast(symbol, candles);
            if (v) {
                forecastCache.set(symbol, {
                    at: Date.now(),
                    v
                });
                await persistBoard();
            }
            return v;
        } finally{
            inFlight.delete(symbol);
        }
    })();
    inFlight.set(symbol, p);
    return p;
}
function peekVolForecast(symbol) {
    const hit = forecastCache.get(symbol);
    if (!hit) return null;
    if (Date.now() - hit.at > PEEK_TTL) return null;
    return hit.v;
}
const SEVERITY = {
    EXTREME: 0,
    ELEVATED: 1,
    NORMAL: 2,
    LOW: 3
};
async function getVolBoard(symbols, take = 12) {
    await loadBoard();
    let computed = 0;
    for (const s of symbols){
        if (computed >= take) break;
        const hit = forecastCache.get(s);
        if (hit && Date.now() - hit.at < CACHE_TTL) continue;
        const v = await getVolForecast(s).catch(()=>null);
        if (v) computed++;
    }
    const rows = [
        ...forecastCache.values()
    ].map((e)=>e.v).sort((a, b)=>SEVERITY[a.regime] - SEVERITY[b.regime] || Math.abs(b.percentile - 50) - Math.abs(a.percentile - 50));
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows: rows.slice(0, 24)
    };
}
}),
"[project]/src/lib/triggers.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LAYER_LABEL",
    ()=>LAYER_LABEL,
    "canTriggerSpawn",
    ()=>canTriggerSpawn,
    "getTriggerBusSummary",
    ()=>getTriggerBusSummary,
    "isCounterCascadeSuppressed",
    ()=>isCounterCascadeSuppressed,
    "isCrowdCut",
    ()=>isCrowdCut,
    "markTriggerSpawn",
    ()=>markTriggerSpawn,
    "runTriggerCycle",
    ()=>runTriggerCycle,
    "scanSymbolTriggers",
    ()=>scanSymbolTriggers
]);
// ── FlowRadar Neo trigger hierarchy + event-driven bus (server-only, v5.0) ──
// Replaces "scan every 15 minutes" with REACTION: the fastest movers (taker
// sweeps, book imbalance) are millisecond-to-second phenomena — a periodic scan
// always arrives late. The bus measures the trigger-hierarchy layers on real
// exchange data and, when a trigger fires WITH fuel confirmed, hands the engine
// an immediate candidate (which still passes EVERY deployment gate).
//
// Layer  1   AGGRESSIVE TAKER SWEEP   — aggTrades same-side burst (seconds)
// Layer  1.5 ORDER-BOOK IMBALANCE     — depth top-band OBI, spoof-guarded (seconds)
// Layer  2   LIQUIDITY VACUUM / WALL  — ±2% depth map gaps & clusters (seconds-minutes)
// Layer  3   LIQUIDATION CASCADE      — REAL forceOrder stream + OI (minutes)
// Layer  3.5 LEVERAGE CROWDING        — funding extreme + OI z-jump (hours)
// Layer  4   MACRO FLOWS              — v6.2: key-less measurable source found
//            (Crypto Fear & Greed Index, alternative.me — no API key). Extreme
//            readings fire contrarian context triggers; unreachable source
//            keeps the honest OBSERVING declaration, never fabricated.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)"); // v14.2 — live ban probe backs the SURROGATE-FLOW hard gate
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)"); // v12.3 TASK-52 — tape/depth ladders
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/regime.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$macro$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/macro.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liq$2d$heatmap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liq-heatmap.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$oi$2d$funding$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/oi-funding.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$vol$2d$forecast$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/vol-forecast.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const LAYER_LABEL = {
    L1_TAKER_SWEEP: "L1 · TAKER SWEEP",
    L15_OBI_IMBALANCE: "L1.5 · OBI",
    L2_VACUUM: "L2 · VACUUM",
    L3_LIQ_CASCADE: "L3 · LIQ CASCADE",
    L3P_LIQ_PRE: "L3P · LIQ PRE",
    L35_CROWD_JUMP: "L3.5 · CROWDING",
    L4_MACRO: "L4 · MACRO"
};
const RING_CAP = 40;
const PERSIST_KEY = "triggerbus";
const SPAWN_COOLDOWN_MS = 8 * 60_000; // max 1 trigger-spawned deploy / 8min
const COUNTER_CASCADE_SUPPRESS_MS = 10 * 60_000;
const CROWD_CUT_MS = 30 * 60_000;
const gState = globalThis;
const S = gState.__nexusTriggerState ?? {
    counts: {
        L1_TAKER_SWEEP: 0,
        L15_OBI_IMBALANCE: 0,
        L2_VACUUM: 0,
        L3_LIQ_CASCADE: 0,
        L3P_LIQ_PRE: 0,
        L35_CROWD_JUMP: 0,
        L4_MACRO: 0
    },
    ring: [],
    lastCycleAt: null,
    lastSpawnAt: 0
};
gState.__nexusTriggerState = S;
const { counts, ring } = S; // shared references — mutations flow through S
let cursor = 0;
let rotationSize = 40;
let cycleInFlight = false;
let macroAnnounced = false;
const cascadeUntil = new Map(); // counter-cascade suppression
const crowdCutUntil = new Map(); // size-cut windows
const lastOBI = new Map(); // spoof guard
const lastTriggerAt = new Map(); // per-symbol+layer cooldown
const measCache = new Map();
const MEAS_TTL = 35_000;
// ── measurement primitives (all real endpoints, cached) ────────
// v10.24 Task 34-a: through the central fapi-gate, CRITICAL lane — the
// reaction layer rides ahead of the telemetry scanners when the weight
// budget tightens (one 250ms negative retry, then an honest null).
async function fapi(path, timeoutMs = 5500) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "critical",
        timeoutMs
    });
}
/** L1 — aggressive taker sweep over the last 60s of real aggTrades. */ async function measureTakerSweep(symbol) {
    const ck = `agg:${symbol}`;
    const hit = measCache.get(ck);
    if (hit && Date.now() - hit.at < MEAS_TTL) return hit.v;
    // v12.3 TASK-52: fapi aggTrades (w20) is rung 1 — during fapi starvation the
    // sweep survives on the bridge ladder (fapi → SPOT-MIRROR, honest plane tag).
    let trades = await fapi(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`);
    if (!trades || trades.length < 10) {
        const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeTape"])(symbol).catch(()=>null);
        if (b && b.trades.length >= 10) trades = b.trades.map((t)=>({
                p: t.price,
                q: t.qty,
                T: t.time,
                m: t.isBuyerMaker
            }));
    }
    if (!trades || trades.length < 10) {
        measCache.set(ck, {
            at: Date.now(),
            v: null
        });
        return null;
    }
    const cutoff = Date.now() - 60_000;
    let buyUsd = 0;
    let sellUsd = 0;
    for (const t of trades){
        if (t.T < cutoff) continue;
        const usd = t.p * t.q;
        if (t.m) sellUsd += usd;
        else buyUsd += usd;
    }
    const total = buyUsd + sellUsd;
    const dominant = Math.max(buyUsd, sellUsd);
    const res = {
        buyUsd: Math.round(buyUsd),
        sellUsd: Math.round(sellUsd),
        sweepSide: total >= 250_000 && dominant >= 250_000 && dominant >= total * 0.62 ? buyUsd > sellUsd ? "LONG" : "SHORT" : null,
        sweepUsd: Math.round(dominant),
        dominance: total > 0 ? dominant / total : 0
    };
    measCache.set(ck, {
        at: Date.now(),
        v: res
    });
    return res;
}
/** L1.5 + L2 — order-book imbalance + ±2% vacuum/wall map from one depth snapshot. */ async function measureDepth(symbol) {
    const ck = `depth:${symbol}`;
    const hit = measCache.get(ck);
    if (hit && Date.now() - hit.at < MEAS_TTL) return hit.v;
    // v12.3 TASK-52 (v14.0): depth rides the ladder — fapi (w5) → SPOT-MIRROR book →
    // SPOT-MIRROR book; OBI/vacuum math is venue-shape-agnostic (bids DESC / asks ASC).
    const d = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeDepth"])(symbol, 500);
    if (!d || d.bids.length === 0 || d.asks.length === 0) {
        measCache.set(ck, {
            at: Date.now(),
            v: null
        });
        return null;
    }
    const bids = d.bids.map(([p, q])=>({
            price: p,
            qty: q
        }));
    const asks = d.asks.map(([p, q])=>({
            price: p,
            qty: q
        }));
    const mid = (bids[0].price + asks[0].price) / 2;
    // OBI over the top ±0.5% band
    let bidNot = 0;
    let askNot = 0;
    for (const b of bids)if (b.price >= mid * 0.995) bidNot += b.price * b.qty;
    else break;
    for (const a of asks)if (a.price <= mid * 1.005) askNot += a.price * a.qty;
    else break;
    const obi = askNot > 0 ? bidNot / askNot : 1;
    // ±2% map: find the widest liquidity gap (vacuum) and the biggest single wall
    const band = 0.02;
    const buckets = 40;
    const bucketUsd = new Array(buckets).fill(0);
    const push = (price, qty)=>{
        const dev = (price - mid) / mid;
        if (Math.abs(dev) > band) return;
        const idx = Math.min(buckets - 1, Math.max(0, Math.floor((dev + band) / (2 * band) * buckets)));
        bucketUsd[idx] += price * qty;
    };
    for (const b of bids)push(b.price, b.qty);
    for (const a of asks)push(a.price, a.qty);
    const nonZero = bucketUsd.filter((v)=>v > 0);
    const median = nonZero.length ? [
        ...nonZero
    ].sort((a, b)=>a - b)[Math.floor(nonZero.length / 2)] : 0;
    let vacuum = null;
    if (median > 0) {
        let bestStart = -1;
        let bestLen = 0;
        let curStart = -1;
        for(let i = 0; i < buckets; i++){
            const empty = bucketUsd[i] < median * 0.15;
            if (empty && curStart < 0) curStart = i;
            if ((!empty || i === buckets - 1) && curStart >= 0) {
                const len = (empty ? i + 1 : i) - curStart;
                if (len > bestLen) {
                    bestLen = len;
                    bestStart = curStart;
                }
                curStart = -1;
            }
        }
        if (bestLen >= 4) {
            const midIdx = bestStart + bestLen / 2;
            const devMid = midIdx / buckets * 2 * band - band;
            const edgeDev = bestStart / buckets * 2 * band - band;
            vacuum = {
                side: devMid >= 0 ? "ABOVE" : "BELOW",
                widthPct: Number((bestLen / buckets * 2 * band * 100).toFixed(2)),
                edgeDistPct: Number((Math.abs(edgeDev) * 100).toFixed(2))
            };
        }
    }
    // wall: biggest single level within ±2%
    let wall = null;
    for (const b of bids){
        const usd = b.price * b.qty;
        if (!wall || usd > wall.usd) wall = {
            side: "BID",
            priceDistPct: Number(((mid - b.price) / mid * 100).toFixed(2)),
            usd: Math.round(usd)
        };
    }
    for (const a of asks){
        const usd = a.price * a.qty;
        if (!wall || usd > wall.usd) wall = {
            side: "ASK",
            priceDistPct: Number(((a.price - mid) / mid * 100).toFixed(2)),
            usd: Math.round(usd)
        };
    }
    const res = {
        mid: Number(mid.toFixed(mid > 100 ? 2 : 6)),
        obi: Number(obi.toFixed(3)),
        vacuum,
        wall
    };
    measCache.set(ck, {
        at: Date.now(),
        v: res
    });
    return res;
}
// ── trigger firing ──────────────────────────────────────────────
// v9.3: fire() stamps the event-instant mid price so the engine's ANTI-LATE-
// ENTRY guard can measure how far price ran between the TRIGGER and the deploy.
//
// v14.2 SURROGATE-FLOW HARD GATE (operator order «توصیه‌ها را کامل و مهندسی
// انجام بده», trace 1a1a15fb6bc0bd75 — audit rec #2 «قانون سخت: بدون deploy
// EVENT-TRIGGER با منبع جریان سورگت», NX-3247 forensics fc143950) ───────────
// NX-3247 was born EVENT-TRIGGER while its flow evidence was SPOT-MIRROR
// surrogate (fapi starved): the trigger plane measured the RIGHT microstructure
// (bridge tape/depth) but the deploy evaluation consumed CONFLICTS −9 flow
// measured on the WRONG venue, and the record spawned straight into the top of
// a markup leg. Law from this audit: an ACTED trigger (spawn-eligible, L1/L2)
// is downgraded to fuel (acted=false) whenever the symbol's flow bundle source
// is not BINANCE (SPOT-MIRROR / MIXED). The event stays in the ring with an
// honest block note (ring is persisted → fully auditable), the engine's
// actionable picker (requires acted) can never select it, and NO engine.ts
// change is needed. When flow is BINANCE or unknown (null — deploy-path gates
// own that case), the gate is a no-op.
function fire(layer, symbol, side, strength, detail, acted = false, price) {
    let actedFinal = acted;
    let detailFinal = detail;
    if (actedFinal && symbol) {
        // v14.2 hardening: the bundle tag can lag reality by up to one flow sweep
        // (~19min over the 48-perp domain) — a ban that started minutes ago would
        // still read a fresh "BINANCE" tag. The LIVE fapiBanActivity() probe
        // closes that gap: while a global window is live or the pool is in
        // distress (≥2 named IPs banned), spawn-eligible triggers stand down
        // regardless of the tag. Both probes fail-safe: tag unknown + no ban →
        // deploy-path gates own the residual case (SURROGATE-BREAKOUT / SURR-CAP).
        const src = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFlowSource"])(symbol);
        const surrogate = src !== null && src !== "BINANCE";
        const ban = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapiBanActivity"])();
        if (surrogate || ban.active) {
            const why = ban.active ? `fapi ban ACTIVE (${ban.reason})` : `flow plane ${src} ≠ BINANCE (fapi starved)`;
            actedFinal = false;
            detailFinal += ` — SURROGATE-FLOW BLOCK: EVENT-TRIGGER spawn denied (${why}; hard rule «no EVENT-TRIGGER deploy on surrogate flow», NX-3247 forensics)`;
        }
    }
    const ev = {
        at: Date.now(),
        layer,
        symbol,
        side,
        strength: Number(strength.toFixed(2)),
        detail: detailFinal,
        acted: actedFinal,
        regime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekRegime"])(symbol)?.label ?? null,
        price: typeof price === "number" && Number.isFinite(price) && price > 0 ? price : null
    };
    ring.unshift(ev);
    if (ring.length > RING_CAP) ring.pop();
    counts[layer]++;
    lastTriggerAt.set(`${layer}:${symbol}`, ev.at);
    void persist();
    return ev;
}
function cooled(layer, symbol, ms = 4 * 60_000) {
    const t = lastTriggerAt.get(`${layer}:${symbol}`);
    return !t || Date.now() - t > ms;
}
function isCounterCascadeSuppressed(symbol) {
    const t = cascadeUntil.get(symbol);
    return !!t && Date.now() < t;
}
function isCrowdCut(symbol) {
    const t = crowdCutUntil.get(symbol);
    return !!t && Date.now() < t;
}
async function persist() {
    if (!restoreOk) return; // TASK-40: never overwrite an unrestored (possibly good) row with cold state
    try {
        const value = JSON.stringify({
            counts: S.counts,
            last: S.ring.slice(0, RING_CAP),
            lastCycleAt: S.lastCycleAt,
            lastSpawnAt: S.lastSpawnAt
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: PERSIST_KEY
            },
            create: {
                key: PERSIST_KEY,
                value
            },
            update: {
                value
            }
        });
    } catch  {
    /* non-fatal */ }
}
/** Restore counters/ring after a dev-server restart.
 * TASK-40 hardening: a TRANSIENT DB error no longer latches the restore —
 * failed restores retry on the next cycle and persist() stays denied until
 * this succeeds. Counters merge MAX (they are monotonic), the ring merges
 * deduped by at|layer|symbol: a double-restore or a racing generation can
 * never move the visible numbers backwards. */ let restoreOk = false;
async function restore() {
    if (restoreOk) return;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: PERSIST_KEY
            }
        });
        if (!row) {
            restoreOk = true; // confirmed fresh — first persist may create the row
            return;
        }
        const v = JSON.parse(row.value);
        // layer-set evolution guard + MAX-merge — a layer added after the persist
        // was written would otherwise sit at undefined and NaN on the first ++
        for (const k of Object.keys(S.counts)){
            const disk = Number(v.counts?.[k] ?? 0);
            S.counts[k] = Math.max(S.counts[k] ?? 0, Number.isFinite(disk) ? disk : 0);
        }
        const seen = new Set(S.ring.map((e)=>`${e?.at}|${e?.layer}|${e?.symbol}`));
        for (const e of (v.last ?? []).slice(0, RING_CAP)){
            if (!e || typeof e.at !== "number") continue;
            const k = `${e.at}|${e.layer}|${e.symbol}`;
            if (seen.has(k)) continue;
            seen.add(k);
            S.ring.push(e);
        }
        S.ring.sort((a, b)=>b.at - a.at);
        if (S.ring.length > RING_CAP) S.ring.length = RING_CAP;
        if (typeof v.lastCycleAt === "number") S.lastCycleAt = Math.max(S.lastCycleAt ?? 0, v.lastCycleAt);
        S.lastSpawnAt = Math.max(S.lastSpawnAt, v.lastSpawnAt ?? 0);
        restoreOk = true;
    } catch  {
    /* transient DB hiccup — NOT latched; next cycle retries; persist stays denied */ }
}
async function scanSymbolTriggers(symbol) {
    const fired = [];
    const depth = await measureDepth(symbol);
    if (!depth) return fired;
    const px = depth.mid; // v9.3 — event-instant reference price for every layer below
    // L1.5 — persistent OBI extreme (spoof guard: needs 2 consecutive extreme reads)
    // v6.7 FIX (dead-layer root cause): the guard window was 90s, but the bus
    // rotates 3 symbols/cycle over a ≤64-symbol domain — each symbol is re-scanned
    // every ~10-20min, so `prev.at` was ALWAYS older than 90s and L15 could never
    // fire (count stuck at 0 since launch). A spoofed wall must now survive one
    // full rotation (~10-20min of real depth) — a STRICTER guard, not a looser one.
    const prev = lastOBI.get(symbol);
    lastOBI.set(symbol, {
        at: Date.now(),
        obi: depth.obi
    });
    if (cooled("L15_OBI_IMBALANCE", symbol) && prev && Date.now() - prev.at < 30 * 60_000) {
        const extreme = depth.obi >= 2.5 || depth.obi <= 0.4;
        const sameDir = Math.sign(depth.obi - 1) === Math.sign(prev.obi - 1);
        if (extreme && sameDir) {
            const side = depth.obi > 1 ? "LONG" : "SHORT";
            fired.push(fire("L15_OBI_IMBALANCE", symbol, side, Math.min(1, Math.abs(depth.obi - 1) / 1.5), `book imbalance ${depth.obi.toFixed(2)}× (bid/ask notional, ±0.5% band) held across 2 snapshots — ${side === "LONG" ? "bids" : "asks"} stacked`, false, px));
        }
    }
    // L1 — taker sweep, with OBI alignment check (the money combo)
    const sweep = await measureTakerSweep(symbol);
    if (sweep && sweep.sweepSide && cooled("L1_TAKER_SWEEP", symbol)) {
        const obiAligned = sweep.sweepSide === "LONG" ? depth.obi >= 1.3 : depth.obi <= 0.77;
        if (obiAligned) {
            const strength = Math.min(1, (sweep.dominance - 0.62) / 0.38 * 0.5 + Math.min(1, sweep.sweepUsd / 1_500_000) * 0.5);
            const ev = fire("L1_TAKER_SWEEP", symbol, sweep.sweepSide, strength, `aggressive ${sweep.sweepSide === "LONG" ? "buy" : "sell"} sweep $${(sweep.sweepUsd / 1000).toFixed(0)}K/60s (${Math.round(sweep.dominance * 100)}% dominant) + OBI ${depth.obi.toFixed(2)} aligned — liquidity consumed toward the thin side`, true, px);
            fired.push(ev);
        } else {
            fired.push(fire("L1_TAKER_SWEEP", symbol, sweep.sweepSide, strength0(sweep.dominance), `sweep $${(sweep.sweepUsd / 1000).toFixed(0)}K/60s but OBI ${depth.obi.toFixed(2)} NOT aligned — recorded as fuel, no spawn`, false, px));
        }
    }
    // L2 — vacuum edge within reach (fuel for the move INTO the gap)
    if (depth.vacuum && cooled("L2_VACUUM", symbol)) {
        const v = depth.vacuum;
        if (v.edgeDistPct <= 0.35 && v.widthPct >= 0.4) {
            const side = v.side === "ABOVE" ? "LONG" : "SHORT";
            const sweptIntoIt = sweep && sweep.sweepSide === side;
            fired.push(fire("L2_VACUUM", symbol, side, Math.min(1, v.widthPct / 1.2), `liquidity vacuum ${v.widthPct}% wide ${v.side.toLowerCase()} mid (edge ${v.edgeDistPct}% away) — ${sweptIntoIt ? "sweep already filling it: momentum fuel with open path" : "air pocket ahead; sweep into it accelerates"}`, !!sweptIntoIt, px));
        }
    }
    // wall opposite the vacuum path is reported inside detail when relevant (wall data feeds flow display)
    // L3 — REAL liquidation cascade (forceOrder stream) + anti-cascade veto window
    const snap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getLiquidationSnapshot"])();
    if (snap && snap.status.connected && !snap.status.dataStalled && cooled("L3_LIQ_CASCADE", symbol)) {
        const row = snap.bySymbol[symbol];
        if (row && row.usd10m >= 1_500_000) {
            const dom = Math.max(row.longsUsd10m, row.shortsUsd10m) / Math.max(1, row.usd10m);
            if (dom >= 0.6) {
                const wreckedSide = row.longsUsd10m > row.shortsUsd10m ? "LONG" : "SHORT";
                cascadeUntil.set(symbol, Date.now() + COUNTER_CASCADE_SUPPRESS_MS);
                fired.push(fire("L3_LIQ_CASCADE", symbol, wreckedSide === "LONG" ? "SHORT" : "LONG", Math.min(1, row.usd10m / 5_000_000), `cascade: $${(row.usd10m / 1e6).toFixed(2)}M ${wreckedSide.toLowerCase()}s liquidated in 10m (${Math.round(dom * 100)}% one-sided) — counter-cascade entries suppressed 10min; exhaustion setup armed`, false, px));
            }
        }
    }
    // L3P — v8.1 P1 PREDICTIVE PRE-CASCADE (engineering opinion, operator-approved):
    // L3 only reacts once a cascade is ALREADY flowing through the forceOrder
    // stream. This layer watches the LIQUIDATION HEATMAP estimate + the OI board:
    // price drifting within reach of a dense cluster WHILE positions are still
    // piling in (OI Δ1h ≥ +1% or OI z ≥ +1) is the cascade BEFORE it happens —
    // the magnet warning. Zero extra fetches: both caches are warm from the
    // tick rotation. Telemetry fuel (acted=false) — deploys still pass the gates.
    if (cooled("L3P_LIQ_PRE", symbol, 8 * 60_000)) {
        const heat = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liq$2d$heatmap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekLiqHeat"])(symbol);
        const oif = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$oi$2d$funding$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekOiFund"])(symbol);
        if (heat && oif) {
            const nearest = heat.nearestBelow && heat.nearestAbove ? Math.abs(heat.nearestBelow.distPct) <= Math.abs(heat.nearestAbove.distPct) ? heat.nearestBelow : heat.nearestAbove : heat.nearestBelow ?? heat.nearestAbove;
            const volRow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$vol$2d$forecast$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekVolForecast"])(symbol);
            const reachPct = Math.max(0.35, (volRow?.atr15mPct ?? 1) * 0.35); // 0.35×ATR band, 0.35% floor
            const oiPiling = oif.oiDelta1h !== null && oif.oiDelta1h >= 1 || oif.oiZ1h !== null && oif.oiZ1h >= 1;
            if (nearest && Math.abs(nearest.distPct) <= reachPct && oiPiling) {
                const cascadeSide = nearest.side === "LONGS_BELOW" ? "SHORT" : "LONG";
                fired.push(fire("L3P_LIQ_PRE", symbol, cascadeSide, Math.min(1, nearest.sharePct / 25), `PRE-CASCADE: est. ${nearest.estUsdM}${heat.oiScaled ? "M OI-scaled" : "M (unscaled est.)"} ${nearest.side === "LONGS_BELOW" ? "long" : "short"} liq cluster ${Math.abs(nearest.distPct).toFixed(2)}% ${nearest.distPct < 0 ? "below" : "above"} price (reach ${reachPct.toFixed(2)}%) + OI ${oif.oiDelta1h !== null ? `${oif.oiDelta1h >= 0 ? "+" : ""}${oif.oiDelta1h.toFixed(2)}%/1h` : `z ${oif.oiZ1h}`} still piling — cascade magnet armed ${cascadeSide === "SHORT" ? "down" : "up"}`, false, px));
            }
        }
    }
    // L3.5 — leverage crowding: funding extreme + OI acceleration
    if (cooled("L35_CROWD_JUMP", symbol)) {
        const m = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFlowMetrics"])(symbol);
        if (m && m.funding8h !== null && m.oiDelta1h !== null) {
            const hist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFlowHistory"])(symbol);
            const mean = hist.length >= 5 ? hist.reduce((a, h)=>a + h.oiDelta1h, 0) / hist.length : 0;
            const jump = m.oiDelta1h >= Math.max(1.5, mean * 2 + 1);
            if (Math.abs(m.funding8h) >= 0.06 && jump) {
                crowdCutUntil.set(symbol, Date.now() + CROWD_CUT_MS);
                const side = m.funding8h > 0 ? "SHORT" : "LONG"; // crowded side gets punished
                fired.push(fire("L35_CROWD_JUMP", symbol, side, Math.min(1, Math.abs(m.funding8h) / 0.15), `leverage crowded: funding ${m.funding8h.toFixed(4)}%/8h + OI ${m.oiDelta1h >= 0 ? "+" : ""}${m.oiDelta1h.toFixed(2)}%/1h (≥2× recent mean) — same-direction size cut 30min`, false, px));
            }
        }
    }
    // L4 — macro flows (v6.2): the key-less Fear & Greed feed gives the layer a
    // REAL measurable source. Extremes (≤20 EXTREME FEAR / ≥80 EXTREME GREED)
    // fire a contrarian context trigger — recorded as fuel, never an auto-spawn
    // (macro context informs, the deployment gates still decide). While the
    // source is unreachable the honest OBSERVING declaration remains.
    if (cooled("L4_MACRO", "MACRO")) {
        const macro = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$macro$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getMacroSnapshot"])();
        if (macro && (macro.value <= 20 || macro.value >= 80)) {
            const extremeFear = macro.value <= 20;
            fired.push(fire("L4_MACRO", "MACRO", extremeFear ? "LONG" : "SHORT", Math.min(1, Math.abs(macro.value - 50) / 50), `macro sentiment extreme: Fear & Greed ${macro.value}/100 (${macro.classification}) — contrarian ${extremeFear ? "LONG" : "SHORT"} context fuel (source: alternative.me, key-less, 30min cache)`));
        } else if (!macro && !macroAnnounced && fired.length === 0) {
            macroAnnounced = true;
            counts.L4_MACRO++; // count the honest declaration itself
            fired.push(fire("L4_MACRO", "—", "NEUTRAL", 0, "macro layer — Fear & Greed feed unreachable, no key-less measurable source right now: layer stays OBSERVING, never fabricated"));
        }
    }
    return fired;
}
function strength0(d) {
    return Number(Math.min(1, Math.max(0, (d - 0.62) / 0.38)).toFixed(2));
}
// ── bus cycle: rotate the FULL scan domain, 3 per cycle (v5.1: domain up to 64) ──
// v5.2 WEDGE ARMOR: a cycle is wrapped in a hard timeout — a single hung probe
// (socket that never settles, DB write lock) previously wedged `cycleInFlight`
// forever and silently killed the whole event-driven layer (observed live:
// counts frozen at 0, lastCycleAt null while regimes kept refreshing). Now the
// bus can stall at most one cycle, then self-heals with an audited error.
const CYCLE_TIMEOUT_MS = 60_000;
const SYMBOL_TIMEOUT_MS = 15_000;
function withTimeout(p, ms, label) {
    return new Promise((resolve, reject)=>{
        const t = setTimeout(()=>reject(new Error(`${label} timeout ${ms}ms`)), ms);
        p.then((v)=>{
            clearTimeout(t);
            resolve(v);
        }).catch((e)=>{
            clearTimeout(t);
            reject(e);
        });
    });
}
let cyclesStarted = 0;
let cyclesCompleted = 0;
let lastCycleMs = null;
let lastCycleError = null;
async function runTriggerCycleInner(symbols) {
    await restore();
    rotationSize = Math.max(6, Math.min(64, symbols.length));
    const batch = [
        symbols[cursor % symbols.length],
        symbols[(cursor + 1) % symbols.length],
        symbols[(cursor + 2) % symbols.length]
    ].filter(Boolean);
    cursor = (cursor + 3) % symbols.length;
    for (const s of batch){
        await withTimeout(scanSymbolTriggers(s), SYMBOL_TIMEOUT_MS, `trigger scan ${s}`);
    }
    S.lastCycleAt = Date.now();
}
async function runTriggerCycle(symbols) {
    if (cycleInFlight || symbols.length === 0) return;
    cycleInFlight = true;
    cyclesStarted++;
    const t0 = Date.now();
    try {
        await withTimeout(runTriggerCycleInner(symbols), CYCLE_TIMEOUT_MS, "trigger cycle");
        cyclesCompleted++;
        lastCycleMs = Date.now() - t0;
        lastCycleError = null;
    } catch (err) {
        lastCycleError = String(err);
        console.error("[trigger-bus] cycle failed:", err);
    } finally{
        cycleInFlight = false;
    }
}
function canTriggerSpawn() {
    return Date.now() - S.lastSpawnAt > SPAWN_COOLDOWN_MS;
}
function markTriggerSpawn() {
    S.lastSpawnAt = Date.now();
    void persist();
}
function getTriggerBusSummary() {
    // TASK-40: kick the restore on the READ path too — a fresh process used to
    // report zero counts until the first bus cycle ran (a seconds-wide window
    // that reads exactly like "the data was wiped again"). The kick is
    // fire-and-forget; the first poll may still be cold, the next one (≤5s) is
    // already MAX-merged from EngineSetting.
    void restore();
    return {
        counts: {
            ...S.counts
        },
        last: S.ring.slice(0, 12),
        rotation: cursor,
        rotationSize,
        lastCycleAt: S.lastCycleAt,
        lastSpawnAt: S.lastSpawnAt || null,
        suppressed: [
            ...cascadeUntil.entries()
        ].filter(([, t])=>Date.now() < t).map(([s])=>s),
        crowdCut: [
            ...crowdCutUntil.entries()
        ].filter(([, t])=>Date.now() < t).map(([s])=>s),
        macroNote: (()=>{
            const m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$macro$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekMacro"])();
            return m ? `L4 macro: Fear & Greed ${m.value}/100 (${m.classification}) — key-less source live, 30min cache` : "L4 macro flows: Fear & Greed feed not yet reachable — OBSERVING, never fabricated";
        })(),
        cyclesStarted,
        cyclesCompleted,
        cycleInFlight,
        lastCycleMs,
        lastCycleError
    };
}
// TASK-40: module-load self-restore — every Turbopack per-route module instance
// pulls its persisted counters/ring the moment it is imported, so even the
// FIRST dashboard poll after a restart/recompile serves real state (the
// getTriggerBusSummary read-path kick is the second line of defense).
void restore().catch(()=>undefined);
}),
"[project]/src/lib/supervisor.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSupervisorState",
    ()=>getSupervisorState,
    "getSupervisorStatePersisted",
    ()=>getSupervisorStatePersisted,
    "maybeSupervise",
    ()=>maybeSupervise,
    "noteGroundingAudit",
    ()=>noteGroundingAudit,
    "noteLlmAuthFailure",
    ()=>noteLlmAuthFailure,
    "noteLlmOutcome",
    ()=>noteLlmOutcome,
    "noteSimulationHit",
    ()=>noteSimulationHit
]);
// ── FlowRadar Neo AI SUPERVISOR (server-only, v6.0) ──
// A watchdog skill ABOVE the governor that watches the whole organism —
// feed health, flow coverage, signal flood/drought, learner staleness,
// LLM link — and performs only SAFE, clamped remediation:
//   · never invents data, never widens risk unilaterally
//   · every check produces an audited ENGINE event when it fires
//   · drought/flood respond by NUDGING the governor (which has its own
//     evidence gate + anti-lockup relief), never by editing gates directly.
//
// ── v6.0 NEW STANDING TASK — VERACITY WATCHDOG ─────────────────────
// Operator mandate (Persian): «هیچ توهم و شبیه سازی انجام نشه» — the
// supervisor now OWNS two extra enforcement layers:
//   A) ANTI-HALLUCINATION (grounding audit) — EVERY structured LLM output
//      (analyst chat, card briefs, governor decisions, deep-learn lessons,
//      symbol scans) is cross-checked number-by-number against the measured
//      bundle it was grounded on (src/lib/veracity.ts). Cited numbers that do
//      not exist in the telemetry are hallucination fingerprints: counted,
//      audited as findings, and (for analyst chat) annotated with an honesty
//      footnote the operator sees.
//   B) ANTI-SIMULATION (fake-pipeline guard) — hunts the patterns where the
//      stack could silently fake intelligence: deployments continuing while
//      the market feed is blind, long heuristic streaks pretending to be
//      model output, and mock/placeholder language inside LLM responses.
//      Heuristics are ALWAYS honestly labeled — the guard makes staying
//      honest a monitored invariant, not a hope.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/backtest.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/triggers.ts [app-route] (ecmascript)");
;
;
;
;
;
;
// NOTE: ai is imported DYNAMICALLY (same reason as governor): the engine data
// plane must survive an AI-bridge syntax/runtime failure — invalidateZai is
// resolved lazily inside resetLlmClient().
// NOTE: governor is imported DYNAMICALLY below — a static import would create
// an engine → supervisor → governor → engine cycle.
const CHECK_EVERY_TICKS = 30; // ~2min at the 4s heartbeat
const RING_CAP = 12;
const LLM_RING_CAP = 16;
const PERSIST_KEY = "supervisor";
const state = {
    lastCheckAt: null,
    checks: 0,
    findings: [],
    llmAuthFails: 0,
    nudgesIssued: 0,
    audits: 0,
    hallucinationFlags: 0,
    simulationFlags: 0,
    llmRing: [],
    auditsAtLastPass: 0,
    hallucFlagsAtLastPass: 0,
    lastHeurAlarmAt: null
};
// v5.2/v6.0: state is PERSISTED in EngineSetting — the AI SUPERVISE / VERACITY
// cards must read true counters even though dev-mode module graphs (and
// restarts) hold MULTIPLE module instances (one per route). Every write does a
// read-max-merge-write sync so instances never clobber each other's counters.
async function syncState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: PERSIST_KEY
            }
        });
        const cur = row ? JSON.parse(row.value) : {};
        // findings + llmRing: union-merge by key, newest first (both instances keep their entries)
        const curFindings = cur.findings ?? [];
        const findingKeys = new Set(curFindings.map((f)=>`${f.at}|${f.kind}|${f.message.slice(0, 48)}`));
        const mergedFindings = [
            ...state.findings.filter((f)=>!findingKeys.has(`${f.at}|${f.kind}|${f.message.slice(0, 48)}`)),
            ...curFindings
        ].sort((a, b)=>a.at < b.at ? 1 : -1).slice(0, RING_CAP);
        const curRing = cur.llmRing ?? [];
        const ringKeys = new Set(curRing.map((r)=>`${r.at}|${r.source}|${r.outcome}`));
        const mergedRing = [
            ...state.llmRing.filter((r)=>!ringKeys.has(`${r.at}|${r.source}|${r.outcome}`)),
            ...curRing
        ].sort((a, b)=>a.at < b.at ? 1 : -1).slice(0, LLM_RING_CAP);
        const merged = {
            lastCheckAt: [
                state.lastCheckAt,
                cur.lastCheckAt
            ].sort().pop() ?? null,
            checks: Math.max(state.checks, cur.checks ?? 0),
            findings: mergedFindings,
            llmAuthFails: Math.max(state.llmAuthFails, cur.llmAuthFails ?? 0),
            nudgesIssued: Math.max(state.nudgesIssued, cur.nudgesIssued ?? 0),
            audits: Math.max(state.audits, cur.audits ?? 0),
            hallucinationFlags: Math.max(state.hallucinationFlags, cur.hallucinationFlags ?? 0),
            simulationFlags: Math.max(state.simulationFlags, cur.simulationFlags ?? 0),
            llmRing: mergedRing,
            auditsAtLastPass: Math.max(state.auditsAtLastPass, cur.auditsAtLastPass ?? 0),
            hallucFlagsAtLastPass: Math.max(state.hallucFlagsAtLastPass, cur.hallucFlagsAtLastPass ?? 0),
            // v8.4.1 FIX — was `cur.lastHeurAlarmAt ?? state.lastHeurAlarmAt`: the stale
            // persisted value always won, so the just-set alarm timestamp was reverted
            // on every sync and the heuristic-streak alarm fired EVERY tick (~5min spam).
            // Max-merge by timestamp (same pattern as lastCheckAt) keeps the newest.
            lastHeurAlarmAt: [
                state.lastHeurAlarmAt,
                cur.lastHeurAlarmAt
            ].filter(Boolean).sort().pop() ?? null
        };
        // adopt the merged truth back into THIS instance so it stays current
        Object.assign(state, merged);
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: PERSIST_KEY
            },
            create: {
                key: PERSIST_KEY,
                value: JSON.stringify(merged)
            },
            update: {
                value: JSON.stringify(merged)
            }
        });
    } catch  {
    /* non-fatal */ }
}
function getSupervisorState() {
    return {
        ...state,
        enabled: true,
        intervalTicks: CHECK_EVERY_TICKS,
        veracity: true
    };
}
async function getSupervisorStatePersisted() {
    await syncState();
    return {
        ...state,
        enabled: true,
        intervalTicks: CHECK_EVERY_TICKS,
        veracity: true
    };
}
function noteLlmAuthFailure() {
    state.llmAuthFails++;
    const f = {
        at: new Date().toISOString(),
        kind: "LLM",
        severity: "warn",
        message: `LLM auth failure #${state.llmAuthFails} — neural link degraded, stack running on heuristics`,
        action: "forced .z-ai-config reload + client re-create"
    };
    push(f);
    void resetLlmClient(); // supervisor remediation: hard-reset the SDK client
    void syncState();
}
function noteLlmOutcome(source, outcome, detail) {
    state.llmRing = [
        {
            at: new Date().toISOString(),
            source,
            outcome,
            detail: detail?.slice(0, 160)
        },
        ...state.llmRing
    ].slice(0, LLM_RING_CAP);
    void syncState(); // cross-instance: persist immediately so every route sees the ring
}
function noteGroundingAudit(source, audit) {
    state.audits++;
    if (audit.verdict === "VIOLATION") {
        state.hallucinationFlags++;
        push({
            at: new Date().toISOString(),
            kind: "HALLUCINATION",
            severity: "warn",
            message: `${source} cited ${audit.unmatched.length} numbers absent from its live telemetry [${audit.unmatched.slice(0, 5).join(", ")}]${audit.markers.length ? ` · markers: ${audit.markers.slice(0, 3).join(", ")}` : ""} (${audit.cited} numbers checked)`,
            action: "response annotated with an honesty footnote + recorded — agent is re-grounded on fresh telemetry every cycle"
        });
    }
    void syncState(); // cross-instance: persist immediately
}
function noteSimulationHit(message, action) {
    state.simulationFlags++;
    push({
        at: new Date().toISOString(),
        kind: "SIMULATION",
        severity: "warn",
        message,
        action
    });
    void syncState();
}
async function resetLlmClient() {
    try {
        const m = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)");
        m.invalidateZai();
    } catch  {
    /* bridge broken — nothing to reset; engine keeps running on heuristics */ }
}
function push(f) {
    state.findings = [
        f,
        ...state.findings
    ].slice(0, RING_CAP);
    void __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.create({
        data: {
            signalId: null,
            symbol: null,
            type: "ENGINE",
            level: f.severity === "warn" ? "warn" : "info",
            message: `AI SUPERVISOR [${f.kind}]: ${f.message} → ${f.action}`
        }
    }).catch(()=>undefined);
}
let checking = false;
async function maybeSupervise() {
    if (checking) return;
    checking = true;
    try {
        await syncState();
        state.checks++;
        state.lastCheckAt = new Date().toISOString();
        // 1) MARKET FEED — consecutive failures climbing?
        const feed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFeedStatus"])();
        if (feed.consecutiveFailures >= 5) {
            push({
                at: state.lastCheckAt,
                kind: "FEED",
                severity: "warn",
                message: `market feed ${feed.consecutiveFailures} consecutive failures (source ${feed.source})`,
                action: "alerting operator — feed client auto-retries internally"
            });
        }
        // 2) FLOW COVERAGE — the scan domain went blind?
        const flow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFlowStatus"])();
        const bus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTriggerBusSummary"])();
        if (flow.covered === 0 && bus.lastCycleAt !== null && Date.now() - bus.lastCycleAt > 3 * 60_000) {
            push({
                at: state.lastCheckAt,
                kind: "FLOW",
                severity: "warn",
                message: "flow coverage dropped to 0 symbols while the trigger bus is supposedly cycling",
                action: "flow probes retry with backoff; engine keeps scanning"
            });
        }
        // 3) SIGNAL DROUGHT — engine locked itself again? (double-guard on top of the governor's relief valve)
        const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
        const since3h = new Date(Date.now() - 3 * 3600_000);
        const [recent3h, lastDeploy] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    createdAt: {
                        gte: since3h
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findFirst({
                orderBy: {
                    createdAt: "desc"
                },
                select: {
                    createdAt: true
                }
            })
        ]);
        const hoursSince = lastDeploy ? (Date.now() - lastDeploy.createdAt.getTime()) / 3600_000 : null;
        if (recent3h === 0 && hoursSince !== null && hoursSince > 3 && gate.minScore > 30) {
            state.nudgesIssued++;
            push({
                at: state.lastCheckAt,
                kind: "DROUGHT",
                severity: "warn",
                message: `signal drought: 0 deploys in 3h (last ${hoursSince.toFixed(1)}h ago) with MIN_SCORE ${gate.minScore}`,
                action: `governor cycle nudged (nudge #${state.nudgesIssued}) — evidence gate + relief valve handle the rest`
            });
            void __turbopack_context__.A("[project]/src/lib/governor.ts [app-route] (ecmascript, async loader)").then((m)=>m.runGovernorCycle("supervisor")).catch(()=>undefined);
        }
        // 4) SIGNAL FLOOD — quality collapse from over-loosening?
        const since15m = new Date(Date.now() - 15 * 60_000);
        const flood = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                createdAt: {
                    gte: since15m
                }
            }
        });
        if (flood > 6) {
            push({
                at: state.lastCheckAt,
                kind: "FLOOD",
                severity: "warn",
                message: `deployment flood: ${flood} signals in 15min — realized WR may dilute the learner`,
                action: "alerting operator; gate tightening stays with the governor's evidence rule"
            });
        }
        // 5) LEARNER STALENESS — memory rotting?
        const [bt, learner] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getBacktest"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getLearnerAutoState"])()
        ]);
        if (!bt && learner.enabled) {
            push({
                at: state.lastCheckAt,
                kind: "LEARNER",
                severity: "info",
                message: "no backtest replay stored yet while the auto-learner is enabled",
                action: "learner will fire on its next scheduled window"
            });
        } else if (bt && Date.now() - new Date(bt.ranAt).getTime() > 24 * 3600_000) {
            push({
                at: state.lastCheckAt,
                kind: "LEARNER",
                severity: "warn",
                message: `backtest evidence stale (>24h, ran ${bt.ranAt.slice(0, 16)}Z)`,
                action: "learner scheduler will refresh on next window; governor may force-run"
            });
        }
        // ── 6) VERACITY RATE — hallucination share over the watchdog window (v6.0) ──
        const auditsWin = state.audits - state.auditsAtLastPass;
        const flagsWin = state.hallucinationFlags - state.hallucFlagsAtLastPass;
        if (auditsWin >= 4 && flagsWin / auditsWin > 0.25) {
            push({
                at: state.lastCheckAt,
                kind: "HALLUCINATION",
                severity: "warn",
                message: `grounding-audit violation rate ${(flagsWin / auditsWin * 100).toFixed(0)}% over the last ${auditsWin} audited LLM outputs (${flagsWin} violations)`,
                action: "honesty footnotes are annotating affected replies; every violation is logged with its unmatched numbers"
            });
        }
        state.auditsAtLastPass = state.audits;
        state.hallucFlagsAtLastPass = state.hallucinationFlags;
        // ── 7) ANTI-SIMULATION GUARD — fake-pipeline patterns (v6.0) ──
        // 7a. deployments while the market feed is blind = possible stale-data pipeline
        const deploys30m = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                createdAt: {
                    gte: new Date(Date.now() - 30 * 60_000)
                }
            }
        });
        if (feed.consecutiveFailures >= 5 && deploys30m > 0) {
            noteSimulationHit(`${deploys30m} deployment(s) in the last 30min while the market feed has ${feed.consecutiveFailures} consecutive failures — verify the pipeline is not running on stale data`, "deploy grounding re-verified against cached klines; feed client auto-retrying; if feed stays blind the learned gates starve deploys naturally");
        }
        // 7b. heuristic streak — the stack must never PRETEND to be a model
        const last5 = state.llmRing.slice(0, 5);
        if (last5.length === 5 && last5.every((r)=>r.outcome !== "MODEL")) {
            const sinceAlarm = state.lastHeurAlarmAt ? Date.now() - new Date(state.lastHeurAlarmAt).getTime() : Infinity;
            if (sinceAlarm > 60 * 60_000) {
                state.lastHeurAlarmAt = new Date().toISOString();
                push({
                    at: state.lastCheckAt,
                    kind: "SIMULATION",
                    severity: "info",
                    message: `last ${last5.length} LLM calls produced no MODEL output (${last5[0].source} most recent) — stack is running on honestly-labeled heuristics, no simulation present`,
                    action: "watching for neural-link recovery; supervisor keeps every output labeled HEURISTIC until the model returns"
                });
            }
        }
        // 7c. a MODEL outcome recorded while auth failures were escalating would be
        // a mislabel — check: any MODEL in the ring whose timestamp precedes the
        // newest auth failure recovery is fine; flag only ERROR→MODEL within 60s
        // with no intervening reset (impossible by construction, but audited here).
        const [newest, afterErr] = state.llmRing;
        if (newest?.outcome === "MODEL" && afterErr?.outcome === "ERROR" && new Date(newest.at).getTime() - new Date(afterErr.at).getTime() < 60_000) {
            noteSimulationHit(`MODEL-labeled output from ${newest.source} arrived <60s after an ERROR outcome — possible label inconsistency`, "veracity ring keeps both records; auth retry path is the expected benign cause, flagged for the audit trail");
        }
        await syncState();
    } catch (err) {
        console.error("[supervisor]", err);
    } finally{
        checking = false;
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__16112ec8._.js.map