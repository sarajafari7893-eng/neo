module.exports = [
"[project]/src/lib/db.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/src/lib/rawcal-telemetry.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_MILESTONE_STEPS",
    ()=>RAWCAL_MILESTONE_STEPS,
    "RAWCAL_TELEMETRY_FILE",
    ()=>RAWCAL_TELEMETRY_FILE,
    "checkRawcalMilestones",
    ()=>checkRawcalMilestones,
    "checkRawcalStallAlarm",
    ()=>checkRawcalStallAlarm,
    "computeRawcalPace",
    ()=>computeRawcalPace,
    "milestoneView",
    ()=>milestoneView,
    "recentBlocks",
    ()=>recentBlocks,
    "recordRawcalSnapshot",
    ()=>recordRawcalSnapshot
]);
// ── v9.2 RAW-CAL PACE MONITOR — engineering observability for the capture run ──
// Operator mandate 2026-09-13: «پایش ریتم صدور RAW-CAL و رشد کتاب EPOCH-2 به
// سمت ۱۰۰. رو کامل و مهندسی انجام بده» — monitor the RAW-CAL issuance rhythm
// and the growth of the EPOCH-2 book toward the 100-settled calibration bar.
//
// THREE PERSISTED INSTRUMENTS:
//  1) SNAPSHOT JOURNAL — .data/rawcal-telemetry.jsonl, one row every ~10min
//     (self-throttled; force on state jumps): {t, issued, issuedTotal,
//     settledE2, openRaw, settledRaw, winsRaw, note?} — the book-growth curve
//     the UI sparkline and rate math read. Trimmed to the last 4000 rows.
//  2) PACE ENGINE — rolling rates from the journal + the DB ledger:
//     issue rate/h (3h + since-armed), settle rate/h (3h + 6h), observed mean
//     spacing between raw issues (DB createdAt diffs), ETA to the 100 bar at
//     the current settle rate, pipeline projection (open raw records that will
//     still settle), mean book settle-time, and stall detection.
//  3) MILESTONE LEDGER — idempotent audited events at 50/60/70/80/90/95/100
//     (EngineSetting "rawcal.milestones"); Telegram only for 90/95/100 (the
//     100 announcement itself stays with the auto-lift in raw-cal.ts).
//
// STALL SEMANTICS (honest, rail-aware):
//  · issue stall  = armed && openRaw < maxOpen && now − lastIssueAt >
//    max(45min, 3 × spacingMin) — issuance SHOULD have produced a record.
//  · settle stall = openRaw > 0 && no EPOCH-2 settle in the last 3h.
//  Neither fires when the open-cap rail is the legitimate blocker.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
;
;
;
const RAWCAL_TELEMETRY_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-telemetry.jsonl");
const MILESTONES_KEY = "rawcal.milestones";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const RAWCAL_MILESTONE_STEPS = [
    50,
    60,
    70,
    80,
    90,
    95,
    100
];
const TELEGRAM_MILESTONES = new Set([
    90,
    95,
    100
]);
const MAX_JOURNAL_ROWS = 4000;
// ── memo caches (pulse-safe; these run on hot paths) ──
let lastSnapshotAt = 0;
let paceCache = null;
const PACE_TTL_MS = 30_000;
async function readJournal() {
    try {
        const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(RAWCAL_TELEMETRY_FILE, "utf8");
        const rows = [];
        for (const line of txt.split("\n")){
            const s = line.trim();
            if (!s) continue;
            try {
                rows.push(JSON.parse(s));
            } catch  {
            /* skip torn line */ }
        }
        return rows.slice(-MAX_JOURNAL_ROWS);
    } catch  {
        return [];
    }
}
async function appendJournal(row) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(RAWCAL_TELEMETRY_FILE), {
            recursive: true
        });
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(RAWCAL_TELEMETRY_FILE, JSON.stringify(row) + "\n", "utf8");
        // opportunistic trim (cheap: only when the file grows past 2× the cap)
        try {
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(RAWCAL_TELEMETRY_FILE);
            if (st.size > MAX_JOURNAL_ROWS * 180) {
                const rows = await readJournal();
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(RAWCAL_TELEMETRY_FILE, rows.slice(-MAX_JOURNAL_ROWS).map((r)=>JSON.stringify(r)).join("\n") + "\n", "utf8");
            }
        } catch  {
        /* trim best-effort */ }
    } catch (e) {
        console.error("[rawcal-telemetry] journal append failed", e);
    }
}
async function recordRawcalSnapshot(note, force = false) {
    const now = Date.now();
    if (!force && now - lastSnapshotAt < 10 * 60_000) return null;
    lastSnapshotAt = now;
    try {
        const [settledE2, openRaw, totalRaw, settledRaw, winsRaw] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: {
                        in: SETTLED_STATUSES
                    },
                    tags: {
                        contains: "EPOCH-2"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: [
                            "ACTIVE",
                            "TP1",
                            "TP2"
                        ]
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: SETTLED_STATUSES
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    reachedTp: {
                        gte: 1
                    }
                }
            })
        ]);
        const snap = {
            t: new Date(now).toISOString(),
            issued: 0,
            issuedTotal: totalRaw,
            settledE2,
            openRaw,
            settledRaw,
            winsRaw,
            ...note ? {
                note: note.slice(0, 80)
            } : {}
        };
        // issued-this-run: cheap read of the state key (no import cycle — raw-cal
        // imports telemetry, not vice versa)
        try {
            const s = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "rawcal.state"
                }
            });
            if (s) snap.issued = JSON.parse(s.value).issued ?? 0;
        } catch  {
        /* optional field */ }
        await appendJournal(snap);
        paceCache = null; // fresh data → invalidate pace memo
        return snap;
    } catch (e) {
        console.error("[rawcal-telemetry] snapshot failed", e);
        return null;
    }
}
async function computeRawcalPace(blocks) {
    if (paceCache && Date.now() - paceCache.at < PACE_TTL_MS && !blocks) return paceCache.data;
    const state = await getRawcalStateSafe();
    const now = Date.now();
    const [settledE2, openRaw, openE2, maxOpen] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        Promise.resolve(state.maxOpen)
    ]);
    const target = state.target;
    // issuance ledger (raw rows from the DB itself — ground truth)
    const rawRows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            createdAt: true
        },
        orderBy: {
            createdAt: "asc"
        }
    });
    const issueTimes = rawRows.map((r)=>r.createdAt.getTime());
    const h3 = now - 3 * 3600_000;
    const issues3h = issueTimes.filter((t)=>t >= h3).length;
    const armMs = state.armedAt ? new Date(state.armedAt).getTime() : null;
    const issuesSinceArm = armMs ? issueTimes.filter((t)=>t >= armMs).length : 0;
    const armHours = armMs ? Math.max(1 / 60, (now - armMs) / 3600_000) : null;
    const diffs = issueTimes.slice(1).map((t, i)=>t - issueTimes[i]);
    const meanDiff = diffs.length ? diffs.reduce((a, b)=>a + b, 0) / diffs.length : null;
    // book-growth ledger (EPOCH-2 settles with closedAt)
    const settles = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            },
            closedAt: {
                not: null
            }
        },
        select: {
            closedAt: true,
            createdAt: true
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const settleTimes = settles.map((r)=>r.closedAt.getTime()).reverse(); // asc
    const settles3h = settleTimes.filter((t)=>t >= h3).length;
    const settles6h = settleTimes.filter((t)=>t >= now - 6 * 3600_000).length;
    const recent20 = settles.slice(0, 20);
    const meanSettleMin = recent20.length ? recent20.reduce((a, r)=>a + (r.closedAt.getTime() - r.createdAt.getTime()), 0) / recent20.length / 60_000 : null;
    const [settledRaw, winsRaw] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: SETTLED_STATUSES
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                reachedTp: {
                    gte: 1
                }
            }
        })
    ]);
    const settleRate3h = settles3h / 3;
    const needed = Math.max(0, target - settledE2);
    const etaHours = needed === 0 ? 0 : settleRate3h > 0 ? needed / settleRate3h : null;
    // v9.2.1 steady-state projection — raw cadence ∩ settle-throughput cap.
    // throughputCap = maxOpen concurrent records / mean settle hours; the real
    // fill window is needed / min(issueCadence, throughputCap). Only computed
    // when meanSettleMin is known (honest — no invented throughput).
    const issueSinceArmRateRaw = armHours ? issuesSinceArm / armHours : 0;
    const throughputCapPerH = meanSettleMin !== null && meanSettleMin > 0 ? maxOpen / (meanSettleMin / 60) : null;
    const steadyRatePerH = throughputCapPerH !== null ? Math.min(issueSinceArmRateRaw, throughputCapPerH) : null;
    const etaSteadyHours = needed === 0 ? 0 : steadyRatePerH !== null && steadyRatePerH > 0 ? needed / steadyRatePerH : null;
    // stalls (rail-aware — see header)
    const issueStallMin = state.armed && openRaw < maxOpen && state.lastIssueAt ? Math.max(0, (now - new Date(state.lastIssueAt).getTime()) / 60_000) : null;
    const issueStallActive = issueStallMin !== null && issueStallMin > Math.max(45, 3 * state.spacingMin);
    const lastSettleAt = settleTimes.length ? settleTimes[settleTimes.length - 1] : null;
    const settleStallMin = openRaw > 0 && lastSettleAt ? Math.max(0, (now - lastSettleAt) / 60_000) : null;
    const settleStallActive = settleStallMin !== null && settleStallMin > 180;
    // cadence grade — honest banding of the ISSUE rhythm while armed.
    // v9.2.1 arm-age-aware: inside the first 3h after arming the 3h window still
    // contains pre-RAW-CAL filtered flow (rate lag) → grade on the since-arm
    // cadence instead; afterwards both windows agree and 3h is used.
    const issueRate3hPerH = issues3h / 3;
    let cadenceGrade = "OFF";
    if (state.armed) {
        const baseRate = armHours !== null && armHours < 3 ? issueSinceArmRateRaw : issueRate3hPerH;
        const effRate = issueStallActive ? 0 : baseRate;
        cadenceGrade = effRate >= 3 ? "A" : effRate >= 1.5 ? "B" : effRate >= 0.5 ? "C" : "D";
    }
    // sparkline from the journal (downsample to ≤48 points)
    // v9.4.2 NaN guard: journal gap rows can carry non-finite settledE2 — skip
    // them here so the client never receives NaN chart values.
    const journal = await readJournal();
    const series = journal.length > 1 ? journal : journal.length === 1 ? [
        {
            t: new Date(now).toISOString(),
            settledE2
        }
    ] : [];
    const step = Math.max(1, Math.ceil(series.length / 48));
    const sparkline = [];
    for(let i = 0; i < series.length; i += step){
        const v = series[i].settledE2;
        if (!Number.isFinite(v)) continue;
        sparkline.push({
            t: series[i].t,
            v
        });
    }
    if (sparkline.length && Number.isFinite(settledE2) && sparkline[sparkline.length - 1].v !== settledE2) sparkline.push({
        t: new Date(now).toISOString(),
        v: settledE2
    });
    const lastBlockNote = blocks && blocks.length ? blocks[blocks.length - 1].note : null;
    const pace = {
        armed: state.armed,
        armedAt: state.armedAt,
        settledE2,
        needed,
        target,
        issueRate3hPerH: round2(issueRate3hPerH),
        issueRateSinceArmPerH: armHours ? round2(issuesSinceArm / armHours) : 0,
        observedSpacingMin: {
            mean: meanDiff !== null ? round2(meanDiff / 60_000) : null,
            min: diffs.length ? round2(Math.min(...diffs) / 60_000) : null,
            max: diffs.length ? round2(Math.max(...diffs) / 60_000) : null,
            samples: diffs.length
        },
        lastIssueAt: state.lastIssueAt,
        lastIssueSerial: state.lastIssueSerial,
        openRaw,
        openE2,
        maxOpen,
        spacingMin: state.spacingMin,
        settleRate3hPerH: round2(settleRate3h),
        settleRate6hPerH: round2(settles6h / 6),
        meanSettleMin: meanSettleMin !== null ? Math.round(meanSettleMin) : null,
        winsRaw,
        settledRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        etaHours: etaHours !== null ? round2(etaHours) : null,
        etaAt: etaHours !== null ? new Date(now + etaHours * 3600_000).toISOString() : null,
        steadyRatePerH: steadyRatePerH !== null ? round2(steadyRatePerH) : null,
        etaSteadyHours: etaSteadyHours !== null ? round2(etaSteadyHours) : null,
        etaSteadyAt: etaSteadyHours !== null ? new Date(now + etaSteadyHours * 3600_000).toISOString() : null,
        pipelineProjection: settledE2 + openE2,
        cadenceGrade,
        stalls: {
            issueStallMin: issueStallActive ? Math.round(issueStallMin) : null,
            settleStallMin: settleStallActive ? Math.round(settleStallMin) : null,
            lastBlockNote
        },
        sparkline,
        journalRows: journal.length
    };
    if (!blocks) paceCache = {
        at: Date.now(),
        data: pace
    };
    return pace;
}
async function getRawcalStateSafe() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript, async loader)");
        return await getRawCalState();
    } catch  {
        return {
            armed: false,
            armedAt: null,
            lastIssueAt: null,
            lastIssueSerial: null,
            target: 100,
            spacingMin: 12,
            maxOpen: 8
        };
    }
}
function round2(n) {
    return Math.round(n * 100) / 100;
}
// ── MILESTONE LEDGER ──
async function readMilestones() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: MILESTONES_KEY
            }
        });
        if (!row) return {
            fired: {}
        };
        return JSON.parse(row.value);
    } catch  {
        return {
            fired: {}
        };
    }
}
async function checkRawcalMilestones() {
    const settledE2 = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    }).catch(()=>0);
    const m = await readMilestones();
    const firedNow = [];
    for (const step of RAWCAL_MILESTONE_STEPS){
        const key = String(step);
        if (settledE2 < step || m.fired[key]) continue;
        const at = new Date().toISOString();
        m.fired[key] = at;
        firedNow.push({
            step,
            at
        });
        const isBar = step === 100;
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", `RAW-CAL MILESTONE ${step}/${100} — EPOCH-2 book at ${settledE2} settled${isBar ? " — calibration bar REACHED, capture mode hands back to central-intelligence command (new calibration)" : ` · ${100 - settledE2} records remain to the AI CALIBRATION bar`}`).catch(()=>undefined);
        if (TELEGRAM_MILESTONES.has(step) && !(isBar && stateHasAutoLift())) {
            const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [instrumentation] (ecmascript, async loader)");
            void sendDirect(`📈 <b>RAW-CAL MILESTONE ${step}/100</b>\nEPOCH-2 book: <b>${settledE2}/100</b> settled${isBar ? " — AI CALIBRATION lift imminent" : ` · ${100 - settledE2} to go`}\n${progressBar(settledE2)}`).catch(()=>undefined);
        }
    }
    if (firedNow.length) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: MILESTONES_KEY
            },
            create: {
                key: MILESTONES_KEY,
                value: JSON.stringify(m)
            },
            update: {
                value: JSON.stringify(m)
            }
        }).catch(()=>undefined);
    }
    return firedNow;
}
async function stateHasAutoLift() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript, async loader)");
        return !!(await getRawCalState()).autoLiftAt;
    } catch  {
        return false;
    }
}
function progressBar(n) {
    const filled = Math.round(Math.min(100, n) / 100 * 20);
    return "▰".repeat(filled) + "▱".repeat(20 - filled);
}
async function milestoneView() {
    const [m, settledE2] = await Promise.all([
        readMilestones(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }).catch(()=>0)
    ]);
    return {
        steps: RAWCAL_MILESTONE_STEPS.map((step)=>({
                step,
                fired: !!m.fired[String(step)],
                at: m.fired[String(step)] ?? null,
                pending: settledE2 < step
            })),
        settledE2
    };
}
async function recentBlocks(n = 12) {
    try {
        const { getRawCalBlocks } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript, async loader)");
        return getRawCalBlocks(n);
    } catch  {
        return [];
    }
}
// ── v9.2.1 STALL ALARM — push the rhythm break, don't just display it ──
// Tick hook (idempotent, 2h cooldown per stall type). Fires when the armed
// issuer SHOULD have produced (issue stall) or the in-flight pipeline SHOULD
// have settled (settle stall) and didn't. Process-death is covered by the P0
// watchdog + keep-alive crons; this alarm covers "alive but rhythm broken".
const STALL_ALERT_KEY = "rawcal.stallAlerts";
const STALL_COOLDOWN_MS = 2 * 3600_000;
async function checkRawcalStallAlarm() {
    try {
        const pace = await computeRawcalPace().catch(()=>null);
        if (!pace || !pace.armed) return false;
        const issues = [];
        if (pace.stalls.issueStallMin) issues.push(`issue stall — no raw record for ${pace.stalls.issueStallMin}min while armed and open ${pace.openRaw}/${pace.maxOpen}`);
        if (pace.stalls.settleStallMin) issues.push(`settle stall — no EPOCH-2 settle for ${pace.stalls.settleStallMin}min with ${pace.openRaw} raw in flight`);
        if (!issues.length) return false;
        let fired = {};
        try {
            const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: STALL_ALERT_KEY
                }
            });
            if (row) fired = JSON.parse(row.value).fired ?? {};
        } catch  {
        /* fresh ledger */ }
        const now = Date.now();
        const send = [];
        for (const it of issues){
            const k = it.startsWith("issue") ? "issue" : "settle";
            const last = fired[k] ? new Date(fired[k]).getTime() : 0;
            if (now - last > STALL_COOLDOWN_MS) {
                fired[k] = new Date(now).toISOString();
                send.push(it);
            }
        }
        if (!send.length) return false;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: STALL_ALERT_KEY
            },
            create: {
                key: STALL_ALERT_KEY,
                value: JSON.stringify({
                    fired
                })
            },
            update: {
                value: JSON.stringify({
                    fired
                })
            }
        }).catch(()=>undefined);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL PACE ALARM — ${send.join(" · ")} · book ${pace.settledE2}/${pace.target} · cadence ${pace.cadenceGrade}`).catch(()=>undefined);
        const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [instrumentation] (ecmascript, async loader)");
        void sendDirect(`⏱ <b>RAW-CAL PACE ALARM</b>\n${send.map((s)=>`• ${s}`).join("\n")}\n📊 Book: <b>${pace.settledE2}/${pace.target}</b> settled · cadence ${pace.cadenceGrade} · open raw ${pace.openRaw}/${pace.maxOpen}`).catch(()=>undefined);
        return true;
    } catch  {
        return false;
    }
}
}),
"[project]/src/lib/rawcal-heartbeat.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "touchRawcalHeartbeat",
    ()=>touchRawcalHeartbeat
]);
// ── v10.20 RAW-CAL RUN HEARTBEAT (engine-native) ───────────────────────────
// M4 mission finding SENTINEL-20260921-M4 #6: the RAWCAL run heartbeat
// (.data/rawcal-run-heartbeat.txt) was historically written by an external
// 2h cron that died 2026-09-19T11:33Z — the sentinel kept reading a stale
// "heartbeatAgeH" for a system that was in fact alive-but-idle (disarmed by
// design at target). This module makes the ENGINE itself the heartbeat
// writer: maybeRawCalDeploy() runs every 10 ticks (always alive while Next
// runs), so the heartbeat now reflects the true run-loop state:
//   · ARMED  — capture mode issuing (state carries issued/target)
//   · IDLE   — disarmed by policy (the honest "alive, not dead" signal)
//   · ISSUE  — a raw record was just issued (state change → always written)
//   · ARMED/…— arm/disarm transitions (always written)
// Format stays sentinel-compatible: each line begins with the minute-precision
// UTC stamp the sentinel parses (`YYYY-MM-DDTHHMMZ`), state detail follows.
// Failure contract: best-effort telemetry — never throws, never blocks a tick.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const HB_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-run-heartbeat.txt");
const SAME_STATE_THROTTLE_MS = 30 * 60_000; // idle/armed steady-state: 1 line / 30min
const MAX_LINES = 200; // bounded file — ~4 days of steady-state history
let lastState = "";
let lastWriteAt = 0;
let chain = Promise.resolve(); // serialize read-modify-write
const p2 = (n)=>String(n).padStart(2, "0");
function stamp(d) {
    return `${d.getUTCFullYear()}-${p2(d.getUTCMonth() + 1)}-${p2(d.getUTCDate())}T${p2(d.getUTCHours())}${p2(d.getUTCMinutes())}Z`;
}
async function writeHeartbeat(state) {
    const now = Date.now();
    const line = `${stamp(new Date(now))} ${state}`;
    if (line === lastState && now - lastWriteAt < SAME_STATE_THROTTLE_MS) return; // steady-state throttle
    const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(HB_FILE, "utf8").catch(()=>"");
    const lines = txt.trim().split("\n").filter(Boolean);
    lines.push(line);
    const keep = lines.slice(-MAX_LINES).join("\n") + "\n";
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(HB_FILE), {
        recursive: true
    });
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(HB_FILE, keep, "utf8");
    lastState = line;
    lastWriteAt = now;
}
function touchRawcalHeartbeat(state) {
    const trimmed = state.slice(0, 110);
    chain = chain.then(()=>writeHeartbeat(trimmed)).catch(()=>undefined); // telemetry is best-effort — never block the caller
}
}),
"[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "configureFapiGate",
    ()=>configureFapiGate,
    "effectiveBudgetPer60s",
    ()=>effectiveBudgetPer60s,
    "fapiBanActivity",
    ()=>fapiBanActivity,
    "fapiBanRemainingMs",
    ()=>fapiBanRemainingMs,
    "fapiEgressStatus",
    ()=>fapiEgressStatus,
    "fapiGateStats",
    ()=>fapiGateStats,
    "gateFetch",
    ()=>gateFetch,
    "isUnknownScopeKey",
    ()=>isUnknownScopeKey,
    "sampleEgressIp",
    ()=>sampleEgressIp
]);
// ── NEXUS//SIGNALS FAPI GATE (server-only, v10.24 — Task 34-a) ──────────────
// Process-wide WEIGHT-BASED token bucket for Binance USDT-M futures REST
// (fapi.binance.com). WHY: 9+ modules in the Next.js process each did their own
// uncoordinated fetch() to the same host and the trade mini-service added
// ~1800 weight/min on top → Binance answered with HTTP 418 IP-bans carrying
// stacked multi-hour "banned until <ms>" windows. This gate is the single
// choke-point every futures-REST call in THIS process must pass:
//
//   · WEIGHT BUDGET — rolling-60s sliding window, default 1100 weight/min
//     (fapi real limit is 2400/min per IP; ~2× headroom absorbs drift between
//     weight estimates and the ungated mini-service until Task 34-b).
//   · LANES — "critical" (engine price feed, trigger measurements) executes
//     immediately when tokens exist, with ONE small negative retry after
//     250ms when momentarily empty; "telemetry" (every rotating scanner/
//     sampler/board) is DROPPED (returns null) when tokens are missing —
//     no unbounded queues, no storm amplification. All callers are
//     null-tolerant by contract.
//   · GLOBAL BAN AWARENESS (refined for the multi-IP egress pool — measured
//     2026-09-26: the sandbox egress rotates across several IPs and Binance's
//     418 body NAMES the banned one: «IP(47.57.x.x) banned until <ms>», with
//     different pool IPs banned in different windows):
//       – 418/429 body naming an IP → PER-IP ban record (capped now+35min),
//         the request's weight is REFUNDED (ban responses carry no weight
//         cost) and the call RETRIES (≤2, 120ms apart) — the pool usually
//         rotates onto a clean IP, so one unlucky draw never starves the app.
//       – ALL retries land on banned IPs → one unlucky draw too many: arm a
//         SHORT 60s global block, and only when that happens 3 times IN A ROW
//         (no successful call between) treat the pool as saturated and arm the
//         full zero-network window min(worst ban end, now+35min). A single
//         clean 2xx resets the streak — self-healing probes.
//       – 418/429 body WITHOUT a parseable IP (unknown scope — the classic
//         single-IP case): arm the global zero-network window immediately —
//         "banned until X" → min(X, now+35min); unparseable 418 → 10min;
//         unparseable 429 → 2min.
//       – While the global window is live, gateFetch returns null INSTANTLY —
//         zero network calls, so a live ban can never be extended by us.
//   · SINGLE-FLIGHT — one shared request per (host,path) while in flight and
//     for a 2s result window, so multiple modules asking the same endpoint
//     inside one tick share one weight spend.
//   · HOST AWARENESS — default host fapi.binance.com, optional alt host
//     (fapi1) for the market-feed availability ladder; bans/weight are
//     per-IP so both hosts share the SAME budget and ban state.
//
// NEVER THROWS: gateFetch returns parsed JSON or null on any failure.
// State lives on globalThis so Turbopack's dev module-graph duplication
// (route graph vs engine graph) still shares ONE process-wide bucket.
//
// SPOT (api.binance.com) and mirror-plane hosts (v14.0 Binance-only) must
// NOT pass through here — futures fapi host only.
//
// ── v12.0 EGRESS/IP MANAGER (Task 44-②, operator order «مدیریت egress/IP
// برای رفع بن fapi») ──────────────────────────────────────────────────────────
// Measured 2026-10-18: the sandbox egress is a rotating NAT pool and Binance
// bans POOL IPs with LONG windows (three named IPs banned until 10-18 19:47Z /
// 22:37Z / 10-19 13:26Z — each plain request is a lottery draw). Three new
// weapons:
//   1. EGRESS SAMPLER — api.ipify.org probe (3.5s timeout, 120s cache,
//      single-flight, never throws) tells us WHICH pool IP a draw exited from.
//   2. ROTATION-AWARE EARLY PROBE — while a global ban window is live, ONE
//      critical-lane call per 120s may bypass the silence IF the sampled IP is
//      clean: the moment the pool rotates, the window LIFTS instantly instead
//      of waiting out the 35min cap. A failed probe costs nothing (banned
//      responses carry no weight) and keeps the window armed.
//   3. BAN-LEDGER PERSISTENCE — named-IP ban records survive process
//      restarts (.data/fapi-gate/bans.json, 30s debounced) so a recycle no
//      longer re-learns the minefield by burning fresh probes.
//
// v10.25 (Task 41, operator order «بایننس ای پی را بلاک نکرده باشد و قابل
// جایگزینی باشد»): the host is env-swappable WITHOUT a code change — if fapi
// is ever hard-blocked (451/region/grey-list, not just a timed 418), set
// NEXUS_FAPI_HOST in .env to a reachable futures-mirror and restart the app.
// Default stays the canonical host. Downstream replaceability ladder is
// already layered: fapi-gate (this) → SPOT-MIRROR aggTrade WS → spot REST
// klines/price fallback → Binance-only liq lanes (v14.0).
//
// ── v14.2 BAN-AWARE RECOVERY PACER (operator order «توصیه‌ها را کامل و مهندسی
// انجام بده», trace 1a1a15fb6bc0bd75 — audit rec #3 «throttle REST بن-آگاه»,
// NX-3247 forensics fc143950) ───────────────────────────────────────────────
// WHY: the old budget was FLAT — the instant a ban window expired the full
// 1100 weight/min came back at once, every starved scanner refilled its
// rotation in the same minute, and the pool re-saturated into a fresh 418
// spiral (measured 10-19: 11:58Z→12:34Z→13:09Z pause spiral). The pacer:
//   · RECOVERY RAMP — for 10min after a global ban window ends, the effective
//     budget ramps 25%→100% linearly. Early recovery minutes carry the
//     CRITICAL lane first (engine price feed / triggers), telemetry scanners
//     stretch back out gradually instead of stampeding.
//   · POOL-DISTRESS CAP — while ≥2 named egress IPs sit inside live ban
//     windows (the 10-18 measurement: 3 named IPs banned simultaneously),
//     the effective budget is capped at 50% — fewer lottery draws, less ban
//     pressure, named-IP evidence stays intel-shaped.
// CRITICAL lane keeps its negative retry; the floor (200/min) is the same
// clamp configureFapiGate enforces, so the pacer can never zero the plane.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
;
const FAPI_HOST = process.env.NEXUS_FAPI_HOST?.trim().replace(/\/+$/, "") || "https://fapi.binance.com";
const DEFAULT_TIMEOUT_MS = 6500;
const WINDOW_MS = 60_000;
const DEFAULT_BUDGET = 1100; // real fapi limit 2400/min per IP — headroom by design
const BAN_CAP_MS = 35 * 60_000; // never record a ban window longer than 35min even if Binance claims hours
// v12.6.1 — mixed-pool era: an UNPARSEABLE 418 is evidence of ONE banned draw,
// not a pool-wide ban (measured 2026-10-20 19:32Z: boot's first draw 418'd
// unparseable while 6/10 fresh connections succeeded — the old 10min arm
// locked the whole app out of a majority-clean pool). 2min + the streak
// escalation ladder covers true saturation.
const BAN_418_DEFAULT_MS = 2 * 60_000; // unparseable 418 → short backoff (was 10min — pool-starvation lesson)
const BAN_429_DEFAULT_MS = 2 * 60_000; // unparseable 429 → short warning backoff
const CRITICAL_RETRY_MS = 250; // the "small negative retry" for the critical lane
const SF_RESULT_MS = 2_000; // single-flight result sharing window
const SF_MAP_CAP = 512;
const SPEND_CAP = 4096; // defensive cap on window entries (~worst-case small-weight bursts)
const BAN_RETRIES = 3; // extra attempts after a named-IP ban (pool rotation)
// v12.6.2 ESCALATING RETRY CADENCE: the NAT egress mapping rotates over ~30s
// (measured 2026-10-20 19:41Z: keep-alive 6×418 → 30s later 6×200), so three
// retries 120ms apart shared ONE doomed mapping. Spacing the retries across
// it (120ms → 2s → 8s) lets draws 2-4 land on a rotated mapping — higher
// per-call success, fewer 60s short blocks. Worst added latency ~10s on a
// banned stretch; the ladder still escalates to the 60s block on failure.
const BAN_RETRY_DELAYS_MS = [
    120,
    2_000,
    8_000
];
const POOL_BLOCK_SHORT_MS = 60_000; // all-retries-banned → short block, let the pool rotate
const POOL_STREAK_FOR_LONG_BLOCK = 3; // consecutive all-banned calls ⇒ pool saturated
const IP_BAN_MAP_CAP = 16;
// ── v12.0 egress manager constants ──
const EGRESS_SAMPLE_TTL_MS = 120_000; // ipify cache — one draw sample per 2min
const EGRESS_TIMEOUT_MS = 3_500;
const PROBE_COOLDOWN_MS = 120_000; // one early-probe attempt per 2min while a window is live
const BAN_PERSIST_DIR = `${process.cwd()}/.data/fapi-gate`;
const BAN_PERSIST_PATH = `${BAN_PERSIST_DIR}/bans.json`;
const BAN_PERSIST_DEBOUNCE_MS = 30_000;
// v14.2 ban-aware recovery pacer
const PACER_RECOVERY_MS = 10 * 60_000; // post-ban ramp window (25%→100%)
const PACER_RAMP_FLOOR = 0.25; // budget fraction at the first recovery minute
const PACER_DISTRESS_CAP = 0.5; // budget cap while ≥2 named IPs are banned live
const PACER_MIN_BUDGET = 200; // same clamp floor as configureFapiGate
// globalThis singleton — survives Turbopack dev module-graph duplication
const g = globalThis;
const state = g.__nexusFapiGate ?? (g.__nexusFapiGate = {
    budgetPer60s: DEFAULT_BUDGET,
    banUntil: 0,
    spend: [],
    windowSum: 0,
    inflight: new Map(),
    ipBans: new Map(),
    recentBanEvents: [],
    allBanStreak: 0,
    aimdFactor: 1,
    lastBanEventAt: 0,
    lastAimdRecoverAt: 0,
    sampledIp: null,
    sampledAt: 0,
    lastBannedIp: null,
    lastProbeAt: 0,
    stats: {
        attempted: 0,
        allowed: 0,
        droppedBudget: 0,
        droppedBan: 0,
        lastBanUntil: 0,
        singleFlightShared: 0,
        retriesAfterBan: 0,
        probesIssued: 0,
        probeLifts: 0,
        effectiveBudgetPer60s: DEFAULT_BUDGET
    }
});
function isUnknownScopeKey(key) {
    return !/^\d{1,3}(\.\d{1,3}){3}$/.test(key); // anything that is not an IPv4 literal ("_pool", hostnames…)
}
try {
    const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
    const nowMs = Date.now();
    let unknownMax = 0;
    let named = 0;
    for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
        if (typeof until !== "number" || until <= nowMs) continue;
        if (isUnknownScopeKey(key)) {
            if (until > unknownMax) unknownMax = until;
        } else {
            state.ipBans.set(key, until);
            named++;
        }
    }
    if (unknownMax > state.banUntil) {
        state.banUntil = unknownMax;
        console.log(`[fapi-gate] v12.6 restored UNKNOWN-SCOPE pool ban from disk — silence armed until ${new Date(unknownMax).toISOString()}`);
    }
    if (state.ipBans.size > 0) {
        // v12.6: named-IP records are INTEL only — no global arm at boot. The
        // first gateFetch takes the lottery draw; a banned draw retries around
        // the named IP (pool rotation) exactly like any other 418.
        console.log(`[fapi-gate] v12.6 restored ${named} named-IP ban record(s) as intel (no global arm — majority-clean pool policy)`);
    }
} catch  {}
let banPersistTimer = null;
function persistBans() {
    if (banPersistTimer) return;
    banPersistTimer = setTimeout(()=>{
        banPersistTimer = null;
        try {
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"])(BAN_PERSIST_DIR, {
                recursive: true
            });
            const nowMs = Date.now();
            const ipBans = {};
            // v12.1 TASK-49 — READ-MERGE-WRITE: mini-services write their own 418
            // discoveries (incl. "_pool" unknown-scope markers with REAL ends) to
            // this same file. Blindly overwriting with state-only data DELETED a
            // 15:20Z pool ban mid-storm (2026-10-19) — never shorten/lose foreign
            // entries: merge disk first, then overlay ours, keep live only.
            try {
                const disk = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
                for (const [ip, until] of Object.entries(disk?.ipBans ?? {})){
                    if (typeof until === "number" && until > nowMs) ipBans[ip] = until;
                }
            } catch  {
            /* no ledger yet */ }
            for (const [ip, until] of state.ipBans)if (until > nowMs) ipBans[ip] = Math.max(ipBans[ip] ?? 0, until);
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["writeFileSync"])(BAN_PERSIST_PATH, JSON.stringify({
                savedAt: new Date().toISOString(),
                ipBans
            }, null, 1));
        } catch  {}
    }, BAN_PERSIST_DEBOUNCE_MS);
}
// ── v12.0 egress IP sampler (which pool IP did this draw exit from?) ──
let egressInflight = null;
async function sampleEgressIp() {
    if (state.sampledIp && Date.now() - state.sampledAt < EGRESS_SAMPLE_TTL_MS) return state.sampledIp;
    if (egressInflight) return egressInflight;
    egressInflight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const t = setTimeout(()=>ctrl.abort(), EGRESS_TIMEOUT_MS);
            const res = await fetch("https://api.ipify.org?format=json", {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(t);
            if (!res.ok) return null;
            const j = await res.json();
            const ip = typeof j.ip === "string" && j.ip ? j.ip : null;
            if (ip) {
                state.sampledIp = ip;
                state.sampledAt = Date.now();
            }
            return ip;
        } catch  {
            return null; // sampler down — never blocks the gate (fail-open)
        } finally{
            egressInflight = null;
        }
    })();
    return egressInflight;
}
function fapiEgressStatus() {
    const now = Date.now();
    const bannedIps = [];
    for (const [ip, until] of state.ipBans)if (until > now) bannedIps.push({
        ip,
        until,
        remainingMs: until - now
    });
    bannedIps.sort((a, b)=>b.until - a.until);
    return {
        banUntil: state.banUntil,
        banRemainingMs: Math.max(0, state.banUntil - now),
        sampledIp: state.sampledIp,
        sampledAt: state.sampledAt || null,
        lastBannedIp: state.lastBannedIp,
        bannedIps,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        lastProbeAt: state.lastProbeAt
    };
}
function configureFapiGate(opts) {
    if (opts?.budgetPer60s !== undefined) {
        const b = Math.max(200, Math.min(2300, Math.round(opts.budgetPer60s)));
        state.budgetPer60s = b;
    }
}
function fapiBanRemainingMs() {
    return Math.max(0, state.banUntil - Date.now());
}
function fapiBanActivity() {
    const now = Date.now();
    const globalRemainingMs = Math.max(0, state.banUntil - now);
    const namedLiveIps = namedLiveBanCount(now);
    if (globalRemainingMs > 0) {
        return {
            active: true,
            reason: `fapi GLOBAL ban window live — ${Math.round(globalRemainingMs / 1000)}s left`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    if (namedLiveIps >= 2) {
        return {
            active: true,
            reason: `fapi pool distress — ${namedLiveIps} named egress IPs inside live ban windows`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    return {
        active: false,
        reason: null,
        globalRemainingMs,
        namedLiveIps,
        effectiveBudgetPer60s: effectiveBudgetPer60s()
    };
}
function fapiGateStats() {
    const now = Date.now();
    pruneWindow(now);
    let bannedIps = 0;
    for (const [, until] of state.ipBans)if (until > now) bannedIps++;
    return {
        attempted: state.stats.attempted,
        allowed: state.stats.allowed,
        droppedBudget: state.stats.droppedBudget,
        droppedBan: state.stats.droppedBan,
        lastBanUntil: state.stats.lastBanUntil,
        budgetPer60s: state.budgetPer60s,
        usedLast60s: state.windowSum,
        singleFlightShared: state.stats.singleFlightShared,
        banRemainingMs: fapiBanRemainingMs(),
        bannedPoolIps: bannedIps,
        retriesAfterBan: state.stats.retriesAfterBan,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        effectiveBudgetPer60s: effectiveBudgetPer60s(),
        aimdFactor: Number(state.aimdFactor.toFixed(3))
    };
}
// ── weight table (Binance USDT-M futures documented weights) ────────────────
// klines ~2 (limit≤100) · depth 2-5-10 by limit · aggTrades 20 · trades 20 ·
// ticker/24hr 1 per-symbol / 40 full-universe · premiumIndex 1 per-symbol /
// 10 all-markers · futures/data/* 1 (openInterestHist, L/S ratios, basis…) ·
// exchangeInfo 1 · ping/time 1 · unknown default 5 (conservative).
function resolveWeight(path) {
    const qIdx = path.indexOf("?");
    const ep = (qIdx === -1 ? path : path.slice(0, qIdx)).replace(/^\//, "").replace(/\/+$/, "");
    const query = qIdx === -1 ? "" : path.slice(qIdx + 1);
    const limit = ()=>{
        const m = /[?&]limit=(\d+)/.exec(query);
        return m ? Number(m[1]) : null;
    };
    switch(ep){
        case "fapi/v1/ping":
        case "fapi/v1/time":
        case "fapi/v1/exchangeInfo":
            return 1;
        case "fapi/v1/klines":
            {
                const l = limit() ?? 500;
                return l <= 100 ? 2 : l <= 499 ? 5 : 10;
            }
        case "fapi/v1/depth":
            {
                const l = limit() ?? 100;
                return l <= 100 ? 2 : l <= 500 ? 5 : 10;
            }
        case "fapi/v1/aggTrades":
        case "fapi/v1/trades":
            return 20;
        case "fapi/v1/ticker/24hr":
            return /[?&]symbol=/.test(query) ? 1 : 40;
        case "fapi/v1/premiumIndex":
            return /[?&]symbol=/.test(query) ? 1 : 10;
        default:
            if (ep.startsWith("futures/data/")) return 1; // openInterestHist / L-S ratios / basis family
            return 5; // unknown → conservative default (covers fapi/v1/fundingRate etc.)
    }
}
function pruneWindow(now) {
    const cutoff = now - WINDOW_MS;
    while(state.spend.length > 0 && state.spend[0].at <= cutoff){
        const e = state.spend.shift();
        state.windowSum -= e.w;
    }
    if (state.spend.length > SPEND_CAP) {
        // defensive: drop the oldest half rather than grow unbounded
        const keep = state.spend.slice(Math.floor(state.spend.length / 2));
        let sum = 0;
        for (const e of keep)sum += e.w;
        state.spend = keep;
        state.windowSum = sum;
    }
}
/** Reserve `weight` from the rolling window. Returns the spend entry (for refunds) or null. */ // ── v14.2 BAN-AWARE RECOVERY PACER ────────────────────────────────────────
// The ONLY budget the rolling window spends against. A flat budget after a
// ban ended = instant re-saturation stampede (the 10-19 spiral); the pacer
// gives the pool a 10min ramp and caps telemetry while the pool shows live
// distress. Global-window minutes are NOT handled here (gateFetch drops
// everything while the window is live) — the pacer shapes the BEFORE
// (distress) and AFTER (recovery) of each ban episode.
function namedLiveBanCount(now) {
    let n = 0;
    for (const [, until] of state.ipBans)if (until > now) n++;
    return n;
}
// ── v14.3 ROLLING-CYCLE AIMD PACER (chapter-7 item ② «backoff واقعی», operator
// mandate trace 1a1a8ea4186c6571) — the missing third leg of the v14.2 pacer.
// Measured failure mode (engineering report NX3247+LIVE): the 3-IP egress pool
// rides a ROLLING ~20min ban cycle — bans expire, the full budget floods back
// instantly (named-IP bans never armed the global window ⇒ no ramp), the pool
// re-saturates in the same minute and re-bans. Fix: an AIMD shed factor that
// DECREASES multiplicatively on every named-IP ban event (×0.7, floor 0.25) and
// recovers ADDITIVELY during clean minutes (+0.05/min, cap 1.0). Sustained ban
// churn ⇒ progressively quieter pool without any operator tuning; a genuinely
// healthy pool heals back to full budget in ~15 clean minutes.
const AIMD_DROP = 0.7;
const AIMD_FLOOR = 0.25;
const AIMD_RECOVER_PER_MIN = 0.05;
function recoverAimd(now) {
    if (state.aimdFactor >= 1) {
        state.lastAimdRecoverAt = now;
        return;
    }
    if (state.lastBanEventAt === 0) return;
    const anchor = Math.max(state.lastAimdRecoverAt, state.lastBanEventAt);
    const cleanMin = Math.floor((now - anchor) / 60_000);
    if (cleanMin <= 0) return;
    state.aimdFactor = Math.min(1, state.aimdFactor + cleanMin * AIMD_RECOVER_PER_MIN);
    state.lastAimdRecoverAt = now;
}
function noteAimdBanEvent(now) {
    recoverAimd(now);
    state.aimdFactor = Math.max(AIMD_FLOOR, state.aimdFactor * AIMD_DROP);
    state.lastBanEventAt = now;
    state.lastAimdRecoverAt = now;
}
function effectiveBudgetPer60s() {
    const now = Date.now();
    let factor = 1;
    recoverAimd(now); // v14.3 — additive clean-minute recovery before clamping
    factor = Math.min(factor, state.aimdFactor);
    // POOL DISTRESS — ≥2 named egress IPs inside live ban windows: cap telemetry.
    if (namedLiveBanCount(now) >= 2) factor = Math.min(factor, PACER_DISTRESS_CAP);
    // RECOVERY RAMP — 10min linear 25%→100% after the last global window ends.
    if (state.banUntil > 0) {
        const sinceBan = now - state.banUntil;
        if (sinceBan >= 0 && sinceBan < PACER_RECOVERY_MS) {
            factor = Math.min(factor, PACER_RAMP_FLOOR + (1 - PACER_RAMP_FLOOR) * (sinceBan / PACER_RECOVERY_MS));
        }
    }
    return Math.max(PACER_MIN_BUDGET, Math.round(state.budgetPer60s * factor));
}
function takeWeight(weight) {
    const now = Date.now();
    pruneWindow(now);
    if (state.windowSum + weight > effectiveBudgetPer60s()) return null;
    const entry = {
        at: now,
        w: weight
    };
    state.spend.push(entry);
    state.windowSum += weight;
    return entry;
}
/** 418/429 responses carry no weight cost — give the reservation back. */ function refundWeight(entry) {
    if (!entry) return;
    const idx = state.spend.indexOf(entry);
    if (idx === -1) return; // already pruned out of the window (its cost is gone too)
    state.spend.splice(idx, 1);
    state.windowSum -= entry.w;
}
function armGlobalBan(until) {
    if (until > state.banUntil) {
        state.banUntil = until;
        state.stats.lastBanUntil = until;
    }
}
/** Record a 418/429 body. Returns { ip, until } when the body NAMES the banned egress IP. */ function noteBanBody(status, body) {
    const now = Date.now();
    const named = /IP\(([\d.]+)\)\s*banned until (\d+)/i.exec(body);
    if (named) {
        const ip = named[1];
        // v12.1 TASK-49: the LEDGER carries Binance's REAL end (sanity-capped 24h) —
        // the cosmetic +35min cap only applies to the global silence window below.
        // Capping the ledger made the early probe fire at a fake expiry and the
        // resulting 418 contact re-escalated the real ban (11:58→12:34→13:09 spiral).
        const realUntil = Math.min(Number(named[2]), now + 24 * 60_000);
        const until = Math.min(realUntil, now + BAN_CAP_MS);
        state.ipBans.set(ip, realUntil);
        state.lastBannedIp = ip;
        persistBans(); // v12.0 — named-IP ban ledger survives restarts (30s debounce)
        if (state.ipBans.size > IP_BAN_MAP_CAP) {
            // evict the soonest-expiring record
            let oldestKey = null;
            let oldestVal = Infinity;
            for (const [k, v] of state.ipBans)if (v < oldestVal) {
                oldestVal = v;
                oldestKey = k;
            }
            if (oldestKey) state.ipBans.delete(oldestKey);
        }
        state.recentBanEvents.push({
            at: now,
            ip
        });
        if (state.recentBanEvents.length > 64) state.recentBanEvents.splice(0, state.recentBanEvents.length - 64);
        noteAimdBanEvent(now); // v14.3 — every named-IP ban deepens the rolling-cycle shed
        return {
            ip,
            until
        };
    }
    const untilMatch = /banned until (\d+)/i.exec(body);
    if (untilMatch) {
        armGlobalBan(Math.min(Number(untilMatch[1]), now + BAN_CAP_MS)); // unknown scope — assume it's us
        return null;
    }
    // unparseable body — conservative defaults (taxonomy precedent for 418)
    armGlobalBan(now + (status === 429 ? BAN_429_DEFAULT_MS : BAN_418_DEFAULT_MS));
    return null;
}
/** Every retry landed on a (named) banned IP — escalate the global silence window. */ function escalatePoolBlock(worstNamedUntil) {
    const now = Date.now();
    state.allBanStreak++;
    if (state.allBanStreak >= POOL_STREAK_FOR_LONG_BLOCK) {
        // repeated independent evidence — the egress pool is saturated: full
        // zero-network window, capped at 35min, then a fresh probe self-heals.
        armGlobalBan(Math.min(worstNamedUntil, now + BAN_CAP_MS));
        state.allBanStreak = 0;
    } else {
        armGlobalBan(now + POOL_BLOCK_SHORT_MS);
    }
}
function pruneInflight(now) {
    for (const [k, e] of state.inflight){
        if (e.settled && now - e.startedAt >= SF_RESULT_MS) state.inflight.delete(k);
    }
}
function delay(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}
/**
 * THE gate body. Resolves parsed JSON, or null on: live IP ban, weight-budget
 * shed, HTTP failure, timeout, or parse error. Never throws, never queues.
 */ async function executeGated(path, opts) {
    const lane = opts?.priority ?? "telemetry";
    const weight = Math.max(1, Math.round(opts?.weight ?? resolveWeight(path)));
    const timeoutMs = opts?.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    let entry = takeWeight(weight);
    if (!entry) {
        if (lane !== "critical") {
            state.stats.droppedBudget++;
            return null; // telemetry: drop instead of queueing a storm
        }
        await delay(CRITICAL_RETRY_MS); // one small negative retry
        entry = takeWeight(weight);
        if (!entry) {
            state.stats.droppedBudget++;
            return null;
        }
    }
    const host = opts?.host ?? FAPI_HOST;
    let attempt = 0;
    while(true){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        let res;
        try {
            // v12.6.1 CONNECTION-RECYCLE (measured 2026-10-20 19:41Z, bun runtime):
            // a keep-alive fetch POOLS one TCP flow ⇒ ONE egress IP for its whole
            // life — a pinned-banned connection turned 231 gate calls into 0 allowed
            // while 6/10 fresh connections succeeded. `Connection: close` = a fresh
            // NAT lottery draw per request; the TLS cost (~60ms) is trivial next to
            // the starvation it prevents.
            res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store",
                headers: {
                    Connection: "close"
                }
            });
        } catch  {
            return null; // timeout/abort/network — weight may have been consumed, keep the reservation
        } finally{
            clearTimeout(timer);
        }
        if (res.ok) {
            const text = await res.text().catch(()=>"");
            if (!text) return null; // empty 200 — nothing to invent
            state.stats.allowed++;
            state.allBanStreak = 0; // a clean 2xx proves the pool still serves us
            try {
                return JSON.parse(text);
            } catch  {
                return null;
            }
        }
        if (res.status === 418 || res.status === 429) {
            const body = await res.text().catch(()=>"");
            refundWeight(entry); // banned responses carry no weight cost
            entry = null;
            const named = noteBanBody(res.status, body);
            if (opts?.singleProbe) return null; // v12.0 early probe — single attempt, window stays armed
            if (!named) return null; // unknown-scope ban — global zero-network window already armed
            if (attempt >= BAN_RETRIES) {
                escalatePoolBlock(named.until);
                return null;
            }
            attempt++;
            state.stats.retriesAfterBan++;
            await delay(BAN_RETRY_DELAYS_MS[Math.min(attempt - 1, BAN_RETRY_DELAYS_MS.length - 1)]); // span the NAT rotation window
            entry = takeWeight(weight);
            if (!entry) {
                state.stats.droppedBudget++;
                return null;
            }
            continue;
        }
        return null; // other non-ok status — honest null, no retry
    }
}
/** v12.1 TASK-49 — a recorded ban counts ONLY while its real end is in the future. */ function isIpBanned(ip, now) {
    if (!ip) return false;
    return (state.ipBans.get(ip) ?? 0) > now;
}
// v12.1 TASK-49 — SHARED LEDGER REFRESH: trade-service / price-ws write their
// own 418 discoveries (with REAL ends) to the same bans.json. Merge live disk
// entries into state every 30s (extend-only). v12.6 scope split: UNKNOWN-SCOPE
// entries extend the global silence (pool-suspect evidence); NAMED-IP entries
// merge into ipBans as intel only — a majority-clean pool must not be
// blacked out because one pool member drew a ban.
let lastLedgerCheckAt = 0;
function refreshLedgerOnce() {
    const nowMs = Date.now();
    lastLedgerCheckAt = nowMs;
    try {
        const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
        let unknownMax = 0;
        for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
            if (typeof until !== "number" || until <= nowMs) continue;
            if (isUnknownScopeKey(key)) {
                if (until > unknownMax) unknownMax = until;
                continue;
            }
            if (until > (state.ipBans.get(key) ?? 0)) state.ipBans.set(key, until);
        }
        // unknown-scope knowledge extends the global silence window (extend-only)
        if (unknownMax > state.banUntil) {
            state.banUntil = unknownMax;
            console.log(`[fapi-gate] v12.6 ledger refresh — UNKNOWN-SCOPE pool ban extends silence until ${new Date(unknownMax).toISOString()}`);
        }
    } catch  {
    /* ledger gone/unreadable — keep in-memory state */ }
}
try {
    const refresh = setInterval(refreshLedgerOnce, 30_000);
    if (typeof refresh.unref === "function") refresh.unref();
} catch  {
/* non-blocking env — skip refresh */ }
async function gateFetch(path, opts) {
    state.stats.attempted++;
    const now = Date.now();
    // v12.1 TASK-49 — LAZY LEDGER GUARD: the instant our global window expires,
    // re-check the shared ledger (throttled to one disk read / 15s) BEFORE any
    // network call — closes the poke-gap where the window died but the refresh
    // interval hadn't fired yet. While the pool is ledger-banned, zero pokes.
    if (now >= state.banUntil && now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
    if (now < state.banUntil) state.stats.droppedBan++; // ledger re-armed the window — shed instantly
    // GLOBAL BAN AWARENESS — while a global ban window is live, zero network calls
    // …except the v12.0 ROTATION-AWARE EARLY PROBE: one critical-lane attempt per
    // PROBE_COOLDOWN_MS when the sampled egress IP is clean — the pool rotates,
    // so the window can be LIFTED the moment a clean draw appears instead of
    // waiting out the full 35min cap. A failed probe keeps the window armed.
    if (now < state.banUntil) {
        state.stats.droppedBan++;
        const canProbe = (opts?.priority ?? "telemetry") === "critical" && now - state.lastProbeAt >= PROBE_COOLDOWN_MS;
        if (!canProbe) return null;
        // v12.1 TASK-49 — LEDGER FRESHNESS BEFORE PROBE: state may hold a cosmetic
        // cap while the disk carries a longer REAL end another process discovered.
        // A probe fired on stale state pokes a still-banned pool and re-escalates.
        // Re-read the ledger (15s throttle) and re-arm BEFORE the probe decision.
        if (now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
        if (now < state.banUntil) return null; // ledger extended the silence — no probe
        state.lastProbeAt = now;
        const ip = await sampleEgressIp();
        // v12.1 TASK-49: expiry-aware check — a recorded ban whose real end passed
        // no longer blocks the probe (the old .has() kept ghost entries armed).
        if (!ip || isIpBanned(ip, now)) return null; // sampled draw is banned/unknown — stay silent
        state.stats.probesIssued++;
        const probeResult = await executeGated(path, {
            ...opts,
            singleProbe: true
        });
        if (probeResult !== null) {
            state.banUntil = 0; // clean draw proved the pool rotated — lift instantly
            state.allBanStreak = 0;
            state.stats.probeLifts++;
            console.log(`[fapi-gate] v12.0 ban window LIFTED early — egress rotated to clean IP ${ip}`);
        }
        return probeResult;
    }
    // SINGLE-FLIGHT per (host,path): share the request while it is in flight and
    // for a 2s result window — concurrent module askers pay the weight once.
    const key = `${opts?.host ?? FAPI_HOST}${path}`;
    const existing = state.inflight.get(key);
    if (existing) {
        const age = now - existing.startedAt;
        if (!existing.settled || age < SF_RESULT_MS) {
            state.stats.singleFlightShared++;
            return existing.promise;
        }
        state.inflight.delete(key);
    }
    if (state.inflight.size >= SF_MAP_CAP) pruneInflight(now);
    const promise = executeGated(path, opts);
    const entry = {
        startedAt: now,
        settled: false,
        promise
    };
    state.inflight.set(key, entry);
    void promise.catch(()=>null) // executeGated never rejects — belt & suspenders
    .finally(()=>{
        entry.settled = true;
    });
    return promise;
}
}),
"[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_KEY",
    ()=>RAWCAL_KEY,
    "RAWCAL_TARGET",
    ()=>RAWCAL_TARGET,
    "armRawCal",
    ()=>armRawCal,
    "captureBookRegimeSplit",
    ()=>captureBookRegimeSplit,
    "clampManualBatch",
    ()=>clampManualBatch,
    "disarmRawCal",
    ()=>disarmRawCal,
    "epoch2SettledCount",
    ()=>epoch2SettledCount,
    "getRawCalBlocks",
    ()=>getRawCalBlocks,
    "getRawCalState",
    ()=>getRawCalState,
    "getV146Guard",
    ()=>getV146Guard,
    "maybeRawCalDeploy",
    ()=>maybeRawCalDeploy,
    "rawCalStatus",
    ()=>rawCalStatus
]);
// ── v9.1 RAW-CAL — UNFILTERED CALIBRATION CAPTURE MODE (operator mandate) ──
// Operator order 2026-09-13: «یک دستور اجرای صدور سیگنال بدون فیلتر و فقط
// ثبت داده و پیگیری و جورنال سازی برای ارسال به ENGINE MEMORY تا سریعتر به
// حد 100 سیگنال برای AI CALIBRATION برسد، سپس این دستور لغو و تمام عملکرد
// فیلتر و ردیابی با دستور هوش مرکزی و کالیبراسون جدید انجام بشه»
//
// WHAT IT DOES (exactly the operator's words, engineered honestly):
//  · ARMED → the engine issues RAW-CAL signals with the quality filters
//    bypassed (threshold/memory/strategy/short/learned/flow/shadow-veto —
//    engine.ts deploySignal opts.calCapture). Every record keeps its REAL
//    confluence votes + strategy + flow snapshot so the R6 recalibration at
//    n≥100 attributes outcomes to actual factors, not noise.
//  · ONLY data capture: records enter the normal ledger → tracked → settled
//    → journaled exactly like every other signal (same TTL, TP ladder,
//    trailing, afterlife) — nothing is faked, nothing is skipped.
//  · ENGINE MEMORY: state + issued-cohort stats are injected into
//    buildEngineMemory() (ai-memory.ts) so the central intelligence sees the
//    raw cohort as ground truth, and the governor context carries the mode.
//  · AUTO-CANCEL: when the EPOCH-2 settled book reaches the target (100),
//    the mode disarms ITSELF, fires the audited RAW-CAL LIFT event, forces
//    refreshCalibration() (the R6 freeze lifts at n≥100 — new calibration
//    under central-intelligence command), and announces on Telegram.
//  · The operator can DISARM any time (dashboard button / /api/rawcal POST).
//
// ANTI-FLOOD RAILS (protect the ledger, not the filter):
//  · spacingMin (default 12min) between raw issues
//  · maxOpen (default 8) concurrent open RAW-CAL records
//  · the scan's own honesty rails stay HARD inside deploySignal (feed-fresh
//    guard + sim-price ban) — calibration rows are never born from stale
//    or invented prices.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-telemetry.ts [instrumentation] (ecmascript)"); // v9.2 pace monitor (no cycle: telemetry imports raw-cal only dynamically)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-heartbeat.ts [instrumentation] (ecmascript)"); // v10.20 engine-native run heartbeat (sentinel-compatible)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)"); // v14.2 — ban-aware issuer suspension (audit rec #1)
;
;
;
;
const RAWCAL_KEY = "rawcal.state";
const RAWCAL_TARGET = 100; // the R6 calibration-lift bar (calibration.ts)
// v10.6.1 spacing 12→10 (operator APPROVE 2026-09-18, proposal #3 of msg 3435):
// tightens the anti-flood floor so evidence windows fill faster without
// loosening honesty rails (open-cap + scan rails unchanged).
const DEFAULT_SPACING_MIN = 10;
const DEFAULT_MAX_OPEN = 8;
// EQ-99 (operator: «ماژول RAW-CAL چرا بطور دستی فعال نمی شود؟» 2026-10-13):
// a POST-graduation manual re-arm used to be AUTO-LIFTED within 10 ticks —
// the tick's graduation tripwire (settledN ≥ target + arms complete) has no
// concept of "the operator deliberately re-armed". Fix: a manual re-arm after
// graduation is a NEW CAPTURE CAMPAIGN — the book target moves ahead of the
// settled count by this batch so the tripwire stays dormant until the fresh
// evidence settles. 300 = the R6 refresh basis (calibration.ts recalibration
// window); operator-overridable via the API (clamped 50..2000).
const MANUAL_CAPTURE_BATCH_DEFAULT = 300;
function clampManualBatch(v) {
    const n = typeof v === "number" ? Math.floor(v) : NaN;
    if (!Number.isFinite(n)) return MANUAL_CAPTURE_BATCH_DEFAULT;
    return Math.min(2000, Math.max(50, n));
}
const DEFAULT_STATE = {
    armed: false,
    armedAt: null,
    armedBy: "",
    disarmReason: null,
    disarmedAt: null,
    issued: 0,
    issuedTotal: 0,
    lastIssueAt: null,
    lastIssueSerial: null,
    target: RAWCAL_TARGET,
    spacingMin: DEFAULT_SPACING_MIN,
    maxOpen: DEFAULT_MAX_OPEN,
    autoLiftAt: null
};
async function getRawCalState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: RAWCAL_KEY
            }
        });
        if (!row) return {
            ...DEFAULT_STATE
        };
        const raw = {
            ...DEFAULT_STATE,
            ...JSON.parse(row.value)
        };
        // TASK-49 NAN-PROOF — a historic write escaped `target: settledN + NaN` into
        // JSON (NaN serializes to null), which made `settledN >= null` ALWAYS true
        // and pinned the arms-coupled extension branch on every pass. Sanitize on
        // read: any non-finite spacing/maxOpen/target heals to a sane value here,
        // so the loop can never be wedged by one bad write again.
        const num = (v, dflt)=>typeof v === "number" && Number.isFinite(v) && v > 0 ? v : dflt;
        return {
            ...raw,
            spacingMin: num(raw.spacingMin, DEFAULT_SPACING_MIN),
            maxOpen: num(raw.maxOpen, DEFAULT_MAX_OPEN),
            target: num(raw.target, RAWCAL_TARGET)
        };
    } catch  {
        return {
            ...DEFAULT_STATE
        };
    }
}
// ── v9.2 ISSUANCE-BLOCK RING (observability) — why the issuer last paused ──
// maybeRawCalDeploy returns a note on every non-issue pass; the ring keeps the
// recent ones so the pace monitor can show WHY cadence paused (spacing rail,
// open cap, scan-no-candidate, feed-stale…). Duplicate identical notes inside
// 5min refresh the timestamp instead of stacking.
const blockRing = [];
function noteRawCalBlock(note) {
    const last = blockRing[blockRing.length - 1];
    if (last && last.note === note && Date.now() - last.t < 5 * 60_000) {
        last.t = Date.now();
        return;
    }
    blockRing.push({
        t: Date.now(),
        note: note.slice(0, 90)
    });
    if (blockRing.length > 40) blockRing.shift();
}
function getRawCalBlocks(n = 12) {
    return blockRing.slice(-n);
}
async function writeState(state) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: RAWCAL_KEY
        },
        create: {
            key: RAWCAL_KEY,
            value: JSON.stringify(state)
        },
        update: {
            value: JSON.stringify(state)
        }
    });
}
async function epoch2SettledCount() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    });
}
async function armRawCal(by = "OPERATOR", batch) {
    const cur = await getRawCalState();
    if (cur.armed) return cur;
    const settledN = await epoch2SettledCount();
    // EQ-99 POST-GRADUATION RE-ARM CAMPAIGN — if the graduation tripwire condition
    // already holds (settledN ≥ target && arms complete), a plain re-arm would be
    // auto-lifted by the very next tick (line-proven 2026-10-13: settled 2376 ≥
    // target 2348 → tick calls disarmRawCal(auto) unconditionally). An operator
    // re-arm AFTER graduation is therefore a NEW CAPTURE CAMPAIGN: the target
    // moves settledN+batch so the auto-lift fires only when the FRESH batch has
    // settled — the operator's command sticks and the lift still re-runs the
    // R6 calibration over the grown book, unchanged.
    const campaign = settledN >= cur.target;
    const campaignTarget = campaign ? settledN + clampManualBatch(batch) : cur.target;
    const state = {
        ...cur,
        armed: true,
        armedAt: new Date().toISOString(),
        armedBy: by,
        disarmReason: null,
        disarmedAt: null,
        issued: 0,
        autoLiftAt: null,
        ...campaign ? {
            target: campaignTarget,
            manualCampaign: true,
            retargetNote: `EQ-99 OPERATOR RE-ARM CAMPAIGN (${by}): graduation condition already held (${settledN} settled ≥ ${cur.target}) — a plain re-arm would be auto-lifted within 10 ticks. Book target moved +${campaignTarget - settledN} → ${campaignTarget} so this campaign captures FRESH evidence and the organic auto-lift + R6 recalibration fires at the new bar`
        } : {
            manualCampaign: false
        }
    };
    await writeState(state);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ARMED by ${by.slice(0, 70)}${campaign ? ` (re-campaign → target ${campaignTarget})` : ""}`); // v10.20 — transition write (throttle bypassed on state change)
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
    await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL CAPTURE MODE ARMED (${by}) — signal issuance now runs WITHOUT quality filters: every scan's best candidate is issued as a tagged RAW-CAL record (data capture + tracking + journaling only), feeding the engine-memory book toward the AI CALIBRATION bar (${settledN}/${state.target} EPOCH-2 settled)${campaign ? ` — EQ-99 RE-CAMPAIGN: graduation bar was already met, so this re-arm opens a FRESH capture batch (+${state.target - settledN}); auto-lift + R6 recalibration fires at the new bar` : ""}. Anti-flood rails: ≥${state.spacingMin}min spacing, ≤${state.maxOpen} open raw records. The mode AUTO-CANCELS at ${state.target} settled and hands back to central-intelligence command with the new calibration.`);
    const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [instrumentation] (ecmascript, async loader)");
    void sendDirect(`🧪 <b>RAW-CAL CAPTURE MODE ARMED</b>${campaign ? " — RE-CAMPAIGN" : ""}\nUnfiltered signal issuance is now ON — every scan's best flow is recorded as a RAW-CAL signal (tracked + journaled, no quality filters).\n📊 Progress: <b>${settledN}/${state.target}</b> EPOCH-2 settled → AI CALIBRATION lift${campaign ? ` (fresh batch +${state.target - settledN})` : ""}\n🛡 Rails: ≥${state.spacingMin}min spacing · ≤${state.maxOpen} open · auto-cancel at ${state.target}`).catch(()=>undefined);
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])("ARMED", true).catch(()=>undefined);
    return state;
}
async function disarmRawCal(reason, auto = false) {
    const cur = await getRawCalState();
    if (!cur.armed && !auto) return cur;
    const settledN = await epoch2SettledCount();
    const state = {
        ...cur,
        armed: false,
        disarmReason: reason,
        disarmedAt: new Date().toISOString(),
        ...auto ? {
            autoLiftAt: new Date().toISOString()
        } : {}
    };
    await writeState(state);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`IDLE ${auto ? "AUTO-LIFT" : "disarmed"} — ${reason.slice(0, 60)}`); // v10.20 — transition write
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
    await fireEvent(null, null, "ENGINE", "ai", `${auto ? "RAW-CAL LIFT — CAPTURE MODE AUTO-CANCELED" : "RAW-CAL CAPTURE MODE DISARMED"} (${reason}) — EPOCH-2 book ${settledN}/${cur.target} settled. All filtering, tracking and sizing return to CENTRAL-INTELLIGENCE command (governor + advisor + AI core) under the NEW calibration${settledN >= cur.target ? " — R6 freeze lifts at n≥100 and profit-first weights recalibrate over the full book including the RAW-CAL cohort" : ""}.`);
    const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [instrumentation] (ecmascript, async loader)");
    void sendDirect(`${auto ? "🎓 <b>RAW-CAL LIFT — CAPTURE COMPLETE</b>" : "⏹ <b>RAW-CAL MODE DISARMED</b>"}\n${reason}\n📊 EPOCH-2 book: <b>${settledN}/${cur.target}</b> settled${settledN >= cur.target ? " — AI CALIBRATION recalibrates over the full book (R6 lift)" : ""}\nFiltered operation returned to central-intelligence command.`).catch(()=>undefined);
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])(auto ? "AUTO-LIFT" : "DISARMED", true).catch(()=>undefined);
    return state;
}
// ── v14.6 WINNER-LANE AUTO-ABORT GUARD ──────────────────────────────────────
// The honest rail behind the v14.6 reopen: FAPI-DEG-W rows are accounted
// separately, and the moment ≥20 of them settle with avg net ≤ −$0.10 the
// v14.5 protected stand-down re-arms ITSELF (persisted in rawcal.v146) — no
// operator vigilance required, the bleed cannot restart silently.
const V146_KEY = "rawcal.v146";
const V146_DEFAULT = {
    suspended: false,
    reason: null,
    at: null,
    cohortN: 0,
    cohortAvgNet: null,
    checkedAt: null
};
async function readV146Row() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: V146_KEY
            }
        });
        if (!row) return {
            ...V146_DEFAULT
        };
        return {
            ...V146_DEFAULT,
            ...JSON.parse(row.value)
        };
    } catch  {
        return {
            ...V146_DEFAULT
        };
    }
}
async function getV146Guard() {
    const st = await readV146Row();
    st.checkedAt = new Date().toISOString();
    try {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                tags: {
                    contains: "FAPI-DEG-W"
                },
                status: {
                    in: [
                        "TP1",
                        "TP2",
                        "TP3",
                        "SL",
                        "EXPIRED",
                        "CLOSED"
                    ]
                }
            },
            select: {
                marginUsd: true,
                pnlPercent: true
            }
        });
        let net = 0;
        for (const r of rows)net += r.marginUsd * r.pnlPercent / 100;
        st.cohortN = rows.length;
        st.cohortAvgNet = rows.length ? Number((net / rows.length).toFixed(3)) : null;
        if (!st.suspended && rows.length >= 20 && st.cohortAvgNet !== null && st.cohortAvgNet <= -0.1) {
            st.suspended = true;
            st.reason = `AUTO-ABORT: FAPI-DEG-W cohort n=${rows.length} avg net $${st.cohortAvgNet}/row ≤ −$0.10 — winner-lane degraded capture re-suspended (v14.5 semantics)`;
            st.at = st.checkedAt;
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: V146_KEY
                },
                create: {
                    key: V146_KEY,
                    value: JSON.stringify(st)
                },
                update: {
                    value: JSON.stringify(st)
                }
            });
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
            void fireEvent(null, null, "ENGINE", "warn", `RAW-CAL v14.6 AUTO-ABORT: FAPI-DEG-W winner-lane cohort n=${rows.length} settled, avg net $${st.cohortAvgNet}/row ≤ −$0.10 — degraded-winner capture SUSPENDED, v14.5 protected stand-down re-armed.`).catch(()=>undefined);
        }
    } catch  {
    // fail-open: guard probe errors never block the issuer (rows stay tagged)
    }
    return st;
}
async function maybeRawCalDeploy() {
    const state = await getRawCalState();
    // v10.20 — engine-native run heartbeat: the tick proves the run loop is ALIVE
    // every 10 ticks (idle/armed steady-state throttled to 1 line / 30min inside).
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(state.armed ? `ARMED issued=${state.issued}/${state.issuedTotal} target=${state.target}` : `IDLE disarmed by policy (target ${state.target})`);
    if (!state.armed) {
        noteRawCalBlock("not armed");
        return {
            issued: false,
            note: "not armed"
        };
    }
    // 0) v14.6 WINNER-LANE DEGRADED CAPTURE (operator order 2026-11-11 trace
    //    1a1ca1b0320831a9 «…بررسی ممیزی از عملکرد سیگنالهای برنده و استفاده و باز
    //    گذاشتن ویژگی های شاخص برای گیت و تایید سیگنال…») — SUPERSEDES the v14.5
    //    hard stand-down. ─────────────
    //    WHY the flip back (evidence, ops-audit-1111):
    //    · v14.5's premise ("bans are intermittent ~24-min windows") DIED —
    //      ban.active held ~100% of the wall clock for 14h+ (rolling named-IP
    //      renewals on the external 3-IP egress pool; heartbeat 08:57→10:15Z all
    //      protected; scan-no-candidate events ceased 20:41Z; stall alert 08:36Z),
    //      so the stand-down became the exact total-issuance freeze it replaced.
    //    · The scoring lane is HEALTHY during bans: 2,788 candidates PASSed in
    //      24h — 100% SHORT, AI-SWING-dominated — exactly the proven winner
    //      cohort (CHOP|AI-SWING|SHORT n=230 · WR 30.4% · +$49.56/14d; CHOP
    //      all-time +$125.26). The wall sits ONLY in this ban check.
    //    · The v14.5 FAPI-DEG loss cohort (−$0.20/row) was accumulated 11-06→11-10
    //      while AI-SCALP + MEAN-REVERT were OPEN and CHOP-LONGs flowed — those
    //      cohorts are now BLOCKED UPSTREAM (strat-pause 11-10, regimeGuard L1,
    //      memory gate), so a ban-window row today is a different, winner-shaped
    //      cohort. The WS tape is LIVE during bans (feed failures=0, futws fresh
    //      43 rows) — only the flow bundle is demoted (blind flow,
    //      INFORMATIONAL-ONLY, historically non-negative).
    //    · GUARDRAIL (the honest part): rows carry FAPI-DEG + FAPI-DEG-W tags for
    //      separate cohort accounting, and an AUTO-ABORT re-arms the v14.5
    //      stand-down by itself once ≥20 FAPI-DEG-W rows settle with avg net
    //      ≤ −$0.10 (persisted rawcal.v146) — the drought ends, the bleed cannot
    //      restart silently. Reversible by writing rawcal.v146 {suspended:false}.
    const ban = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fapiBanActivity"])();
    if (ban.active) {
        const v146 = await getV146Guard();
        if (v146.suspended) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`OPEN (protected) — v14.6 auto-abort live: winner-lane degraded capture suspended (${(v146.reason ?? "winner cohort bled").slice(0, 70)})`);
            noteRawCalBlock(`v14.6 auto-abort — ${(v146.reason ?? "winner cohort bled").slice(0, 80)}`);
            return {
                issued: false,
                note: "v14.6 winner-lane auto-abort"
            };
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`OPEN (degraded-winner) — fapi ban active (${ban.reason?.slice(0, 50)}): capture continues on WS-live tape, tagged FAPI-DEG-W (auto-abort armed: n≥20 & avg ≤ −$0.10) — operator order 2026-11-11 «باز گذاشتن ویژگی های شاخص»`);
    }
    // 1) progress check FIRST — Task 34-2 ARMS-COUPLED AUTO-CANCEL (2026-09-26
    //    operator mandate: «RAW-CAL باید AI CALIBRATION BAR را تا زمان کامل شدن
    //    بازوهای Shadow veto فعال باشد و PACE MONITOR بر این اساس تنظیم شود»):
    //    the book target alone no longer lifts the capture. When the target is
    //    reached but the shadow-veto REAL evidence arms are still incomplete,
    //    the mode AUTO-EXTENDS its target by the arm deficit (audited retarget,
    //    EVID-BUDGET pattern) instead of disarming — the calibration book keeps
    //    growing while the veto evidence window stays open. Only when BOTH the
    //    book target is met AND the arms are complete (paper-veto waived in
    //    shadow mode — it structurally cannot fill) does the auto-lift fire.
    const settledN = await epoch2SettledCount();
    if (settledN >= state.target) {
        const sv = await __turbopack_context__.A("[project]/src/lib/shadow-veto.ts [instrumentation] (ecmascript, async loader)");
        const cfg = await sv.getShadowVetoConfig();
        // v11.5 hotfix (tsc-caught latent bug): shadowArmsCompletion is ASYNC —
        // the missing await made `completion` a Promise whose fields are all
        // undefined, so `!completion.allComplete` was ALWAYS true: the lift path
        // could never fire and the target auto-extended forever. Dormant only
        // because the mode is currently disarmed.
        const completion = await sv.shadowArmsCompletion(cfg.mode);
        if (!completion.allComplete) {
            // TASK-49 — NaN-proof: a stale compiled module (Turbopack chunk from the
            // pre-Task-34-2 snapshot) once returned a completion WITHOUT
            // note/pendingDeficit → Math.max(undefined)=NaN → target NaN → JSON null
            // → this branch pinned forever (repeating "[raw-cal] slice of undefined").
            // Guard every unknown now.
            const deficit = Number.isFinite(completion.pendingDeficit) ? completion.pendingDeficit : 10;
            const extension = Math.max(deficit, 10);
            const note = completion.note ?? "arms probe shape mismatch — treated as incomplete";
            const nextTarget = Number.isFinite(settledN + extension) ? settledN + extension : state.target + extension;
            const next = {
                ...state,
                target: nextTarget,
                retargetNote: `ARMS-COUPLED EXTENSION (operator mandate 2026-09-26 «تا زمان کامل شدن بازوهای Shadow veto فعال باشد»): book target ${state.target} reached but shadow-veto real arms incomplete (${note}) — target auto-extended +${extension} to ${nextTarget} so the capture keeps feeding evidence; PACE MONITOR tracks arm completion`
            };
            await writeState(next);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ARM-EXTEND target ${state.target}→${next.target} (${note.slice(0, 80)})`);
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
            await fireEvent(null, null, "ENGINE", "info", `RAW-CAL: book target reached (${settledN}) but shadow-veto arms incomplete — capture AUTO-EXTENDED +${extension} (target → ${next.target}). Arms: ${(completion.arms ?? []).map((a)=>`${a.id} ${a.n}/${a.target}${a.waived ? " (waived)" : ""}`).join(" · ")}`);
            return {
                issued: false,
                note: `arms-coupled extension → target ${next.target}`
            };
        }
        await disarmRawCal(`target reached + shadow-veto arms complete — ${settledN} EPOCH-2 settled ≥ ${state.target}`, true);
        const { refreshCalibration } = await __turbopack_context__.A("[project]/src/lib/calibration.ts [instrumentation] (ecmascript, async loader)");
        const { state: cal, auditLine } = await refreshCalibration();
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", auditLine ?? `AI CALIBRATION post-RAW-CAL: status ${cal.status} over ${cal.settled} settled — ${cal.rows.length} moving factors ${cal.rows.map((r)=>`${r.factor} ×${r.weight.toFixed(2)}`).join(" · ")}`);
        return {
            issued: false,
            note: `auto-lifted at ${settledN} (arms complete)`
        };
    }
    // 2) spacing rail
    if (state.lastIssueAt && Date.now() - new Date(state.lastIssueAt).getTime() < state.spacingMin * 60_000) {
        noteRawCalBlock(`spacing rail — next window ≥ ${state.spacingMin}min`);
        return {
            issued: false,
            note: "spacing"
        };
    }
    // 3) open-records rail (RAW-CAL cohort only)
    const openRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "ACTIVE",
                    "TP1",
                    "TP2"
                ]
            }
        }
    });
    if (openRaw >= state.maxOpen) {
        noteRawCalBlock(`open-cap rail — ${openRaw}/${state.maxOpen} raw records in flight`);
        return {
            issued: false,
            note: `open cap ${openRaw}/${state.maxOpen}`
        };
    }
    // 4) issue the capture record through the engine scan (honesty rails stay
    //    hard inside deploySignal: feed-fresh guard + sim-price ban)
    //    v14.6 — during a live fapi ban the row is tagged FAPI-DEG (cohort
    //    continuity) + FAPI-DEG-W (winner-lane window, auto-abort accounting).
    const { deploySignal } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
    const res = await deploySignal(undefined, undefined, {
        calCapture: true,
        triggerTag: "RAW-CAL",
        ...ban.active ? {
            extraTags: [
                "FAPI-DEG",
                "FAPI-DEG-W"
            ]
        } : {}
    });
    if (!res.signal) {
        // rate-limit the "scan found nothing" chatter — one event / 30min
        noteRawCalBlock(`scan-no-candidate — ${res.error?.slice(0, 60) ?? "no setup"}`);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
        const recent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signalEvent.count({
            where: {
                type: "ENGINE",
                level: "info",
                message: {
                    contains: "RAW-CAL: scan found no live candidate"
                },
                createdAt: {
                    gte: new Date(Date.now() - 30 * 60_000)
                }
            }
        }).catch(()=>1);
        if (!recent) await fireEvent(null, null, "ENGINE", "info", `RAW-CAL: scan found no live candidate this window — ${res.error?.slice(0, 120) ?? "no setup"}`);
        return {
            issued: false,
            note: res.error?.slice(0, 80)
        };
    }
    // 5) journal the issue + update state
    const next = {
        ...state,
        issued: state.issued + 1,
        issuedTotal: state.issuedTotal + 1,
        lastIssueAt: new Date().toISOString(),
        lastIssueSerial: res.signal.serial
    };
    await writeState(next);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ISSUE NX-${String(res.signal.serial).padStart(4, "0")} raw open ${openRaw + 1}/${state.maxOpen}`); // v10.20 — always written (state change)
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])(`ISSUE NX-${String(res.signal.serial).padStart(4, "0")}`, true).catch(()=>undefined); // v9.2 — instant book-curve reaction
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)");
    const milestone = next.issued % 5 === 0 || settledN + 1 >= state.target;
    await fireEvent(null, res.signal.symbol, "ENGINE", milestone ? "ai" : "info", `RAW-CAL ISSUE #${next.issued} → NX-${String(res.signal.serial).padStart(4, "0")} ${res.signal.direction} ${res.signal.symbol} @ ${res.signal.entryPrice} (${res.signal.strategy}, score ${res.signal.confidence}%) — unfiltered capture record, tracked + journaled to ENGINE MEMORY · EPOCH-2 book ${settledN + 1}/${state.target} settled · open raw ${openRaw + 1}/${state.maxOpen}${settledN + 1 >= state.target ? " — TARGET REACHED, mode auto-cancels next tick" : ""}`);
    return {
        issued: true,
        serial: res.signal.serial
    };
}
// ── v11.5 CAPTURE-BOOK REGIME GAUGE (operator question 2026-10-12: «آیا
// رژیم‌سنجی قبل از اعتماد به کتاب کپچر اضافه شده؟») ──
// Two-part engineering answer, both auditable:
//   1) AT ISSUE TIME — the LAYER-0 regime ruling (regimeRuling, engine.ts
//      evaluate()) is NOT bypassed by calCapture: a candidate standing in a
//      vetoed regime (BREAKOUT/MOMENTUM in chop at guard L1, counter-trend
//      mean-revert in trends) never becomes a capture row. Every issued row
//      then carries its REGIME-* tag for life.
//   2) BEFORE TRUSTING THE BOOK — the settled capture book is split BY REGIME
//      (n / WR / net $) so the operator and the AI core trust capture-derived
//      conclusions per regime, not book-wide (a CHOP-heavy book must never be
//      read as a trend verdict). Surfaced on /api/rawcal + RawCalCard.
const REGIME_LABELS = {
    "TREND-UP": "TREND ▲",
    "TREND-DOWN": "TREND ▼",
    CHOP: "CHOP ∿",
    VOLATILE: "VOLATILE ⚡",
    UNKNOWN: "UNKNOWN"
};
async function captureBookRegimeSplit() {
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            tags: true,
            status: true,
            reachedTp: true,
            marginUsd: true,
            pnlPercent: true
        }
    });
    const map = new Map();
    for (const r of rows){
        const tag = r.tags?.split(",").find((t)=>t.startsWith("REGIME-"))?.replace("REGIME-", "") ?? "UNKNOWN";
        const cell = map.get(tag) ?? {
            n: 0,
            wins: 0,
            net: 0
        };
        cell.n += 1;
        if (r.reachedTp >= 1 || r.status === "TP1" || r.status === "TP2" || r.status === "TP3") cell.wins += 1;
        cell.net += r.marginUsd * r.pnlPercent / 100;
        map.set(tag, cell);
    }
    return [
        ...map.entries()
    ].map(([regime, c])=>({
            regime,
            label: REGIME_LABELS[regime] ?? regime,
            n: c.n,
            wins: c.wins,
            winRatePct: c.n ? Number((c.wins / c.n * 100).toFixed(1)) : 0,
            netUsd: Number(c.net.toFixed(2))
        })).sort((a, b)=>b.n - a.n);
}
async function rawCalStatus() {
    const state = await getRawCalState();
    const [settledN, openRaw, totalRaw] = await Promise.all([
        epoch2SettledCount(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }).catch(()=>0),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                }
            }
        }).catch(()=>0)
    ]);
    const settledRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        }
    }).catch(()=>0);
    const winsRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            reachedTp: {
                gte: 1
            }
        }
    }).catch(()=>0);
    // Task 34-2 — ARMS-COUPLED PACE: the AI CALIBRATION bar now reports the
    // shadow-veto arm completion it is geared to (operator mandate 2026-09-26);
    // fail-soft: any probe error keeps the block null instead of breaking status.
    const armsCompletion = await __turbopack_context__.A("[project]/src/lib/shadow-veto.ts [instrumentation] (ecmascript, async loader)").then(async (m)=>m.shadowArmsCompletion((await m.getShadowVetoConfig()).mode)).catch(()=>null);
    // v11.5 capture-book regime gauge (operator question: رژیم‌سنجی قبل از اعتماد)
    const regimeSplit = await captureBookRegimeSplit().catch(()=>[]);
    // v14.6 winner-lane auto-abort guard (observability on /api/rawcal)
    const v146 = await getV146Guard().catch(()=>null);
    return {
        ...state,
        settledN,
        needed: Math.max(0, state.target - settledN),
        openRaw,
        issuedTotal: totalRaw,
        settledRaw,
        winsRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        spacingMin: state.spacingMin,
        maxOpen: state.maxOpen,
        armsCompletion,
        regimeSplit,
        v146
    };
}
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client-2c3a283f134fdcb6", () => require("@prisma/client-2c3a283f134fdcb6"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ba7bb8ea._.js.map