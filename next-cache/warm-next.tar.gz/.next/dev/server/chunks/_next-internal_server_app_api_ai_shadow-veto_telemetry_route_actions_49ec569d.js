module.exports = [
"[project]/.next-internal/server/app/api/ai/shadow-veto/telemetry/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_ai_shadow-veto_telemetry_route_actions_49ec569d.js.map