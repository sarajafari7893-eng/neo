module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reducer",
    ()=>reducer,
    "toast",
    ()=>toast,
    "useToast",
    ()=>useToast
]);
// Inspired by react-hot-toast library
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
const TOAST_LIMIT = 1;
const TOAST_REMOVE_DELAY = 1000000;
const actionTypes = {
    ADD_TOAST: "ADD_TOAST",
    UPDATE_TOAST: "UPDATE_TOAST",
    DISMISS_TOAST: "DISMISS_TOAST",
    REMOVE_TOAST: "REMOVE_TOAST"
};
let count = 0;
function genId() {
    count = (count + 1) % Number.MAX_SAFE_INTEGER;
    return count.toString();
}
const toastTimeouts = new Map();
const addToRemoveQueue = (toastId)=>{
    if (toastTimeouts.has(toastId)) {
        return;
    }
    const timeout = setTimeout(()=>{
        toastTimeouts.delete(toastId);
        dispatch({
            type: "REMOVE_TOAST",
            toastId: toastId
        });
    }, TOAST_REMOVE_DELAY);
    toastTimeouts.set(toastId, timeout);
};
const reducer = (state, action)=>{
    switch(action.type){
        case "ADD_TOAST":
            return {
                ...state,
                toasts: [
                    action.toast,
                    ...state.toasts
                ].slice(0, TOAST_LIMIT)
            };
        case "UPDATE_TOAST":
            return {
                ...state,
                toasts: state.toasts.map((t)=>t.id === action.toast.id ? {
                        ...t,
                        ...action.toast
                    } : t)
            };
        case "DISMISS_TOAST":
            {
                const { toastId } = action;
                // ! Side effects ! - This could be extracted into a dismissToast() action,
                // but I'll keep it here for simplicity
                if (toastId) {
                    addToRemoveQueue(toastId);
                } else {
                    state.toasts.forEach((toast)=>{
                        addToRemoveQueue(toast.id);
                    });
                }
                return {
                    ...state,
                    toasts: state.toasts.map((t)=>t.id === toastId || toastId === undefined ? {
                            ...t,
                            open: false
                        } : t)
                };
            }
        case "REMOVE_TOAST":
            if (action.toastId === undefined) {
                return {
                    ...state,
                    toasts: []
                };
            }
            return {
                ...state,
                toasts: state.toasts.filter((t)=>t.id !== action.toastId)
            };
    }
};
const listeners = [];
let memoryState = {
    toasts: []
};
function dispatch(action) {
    memoryState = reducer(memoryState, action);
    listeners.forEach((listener)=>{
        listener(memoryState);
    });
}
function toast({ ...props }) {
    const id = genId();
    const update = (props)=>dispatch({
            type: "UPDATE_TOAST",
            toast: {
                ...props,
                id
            }
        });
    const dismiss = ()=>dispatch({
            type: "DISMISS_TOAST",
            toastId: id
        });
    dispatch({
        type: "ADD_TOAST",
        toast: {
            ...props,
            id,
            open: true,
            onOpenChange: (open)=>{
                if (!open) dismiss();
            }
        }
    });
    return {
        id: id,
        dismiss,
        update
    };
}
function useToast() {
    const [state, setState] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](memoryState);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        listeners.push(setState);
        return ()=>{
            const index = listeners.indexOf(setState);
            if (index > -1) {
                listeners.splice(index, 1);
            }
        };
    }, [
        state
    ]);
    return {
        ...state,
        toast,
        dismiss: (toastId)=>dispatch({
                type: "DISMISS_TOAST",
                toastId
            })
    };
}
;
}),
"[project]/src/lib/utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}),
"[project]/src/components/ui/toast.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toast",
    ()=>Toast,
    "ToastAction",
    ()=>ToastAction,
    "ToastClose",
    ()=>ToastClose,
    "ToastDescription",
    ()=>ToastDescription,
    "ToastProvider",
    ()=>ToastProvider,
    "ToastTitle",
    ()=>ToastTitle,
    "ToastViewport",
    ()=>ToastViewport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-toast/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
const ToastProvider = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Provider"];
const ToastViewport = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 16,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
ToastViewport.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"].displayName;
const toastVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("group pointer-events-auto relative flex w-full items-center justify-between space-x-2 overflow-hidden rounded-md border p-4 pr-6 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full", {
    variants: {
        variant: {
            default: "border bg-background text-foreground",
            destructive: "destructive group border-destructive bg-destructive text-destructive-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
const Toast = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, variant, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(toastVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
});
Toast.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"].displayName;
const ToastAction = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Action"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium transition-colors hover:bg-secondary focus:outline-none focus:ring-1 focus:ring-ring disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 62,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
ToastAction.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Action"].displayName;
const ToastClose = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("absolute right-1 top-1 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-1 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600", className),
        "toast-close": "",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/toast.tsx",
            lineNumber: 86,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 77,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
ToastClose.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"].displayName;
const ToastTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-sm font-semibold [&+div]:text-xs", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 95,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
ToastTitle.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"].displayName;
const ToastDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-sm opacity-90", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 107,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
ToastDescription.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"].displayName;
;
}),
"[project]/src/components/ui/toaster.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toaster",
    ()=>Toaster
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/toast.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
function Toaster() {
    const { toasts } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastProvider"], {
        children: [
            toasts.map(function({ id, title, description, action, ...props }) {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Toast"], {
                    ...props,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-1",
                            children: [
                                title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastTitle"], {
                                    children: title
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/toaster.tsx",
                                    lineNumber: 22,
                                    columnNumber: 25
                                }, this),
                                description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastDescription"], {
                                    children: description
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/toaster.tsx",
                                    lineNumber: 24,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ui/toaster.tsx",
                            lineNumber: 21,
                            columnNumber: 13
                        }, this),
                        action,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastClose"], {}, void 0, false, {
                            fileName: "[project]/src/components/ui/toaster.tsx",
                            lineNumber: 28,
                            columnNumber: 13
                        }, this)
                    ]
                }, id, true, {
                    fileName: "[project]/src/components/ui/toaster.tsx",
                    lineNumber: 20,
                    columnNumber: 11
                }, this);
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastViewport"], {}, void 0, false, {
                fileName: "[project]/src/components/ui/toaster.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/toaster.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/ui/sonner.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toaster",
    ()=>Toaster
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
const Toaster = ({ ...props })=>{
    const { theme = "system" } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTheme"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Toaster"], {
        theme: theme,
        className: "toaster group",
        style: {
            "--normal-bg": "var(--popover)",
            "--normal-text": "var(--popover-foreground)",
            "--normal-border": "var(--border)"
        },
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/sonner.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
;
}),
"[project]/src/lib/accent.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo accent system ──
// 5 operator-selectable accent identities. Each accent drives the whole
// neon chrome via CSS custom properties:
//   --neon / --neon-dim  → solid hex (borders, glows, text)
//   --neon-rgb           → space-separated channels for rgb(var(--neon-rgb) / a)
// SVG attributes & Recharts props can't resolve var(), so hex is also
// exposed through the useNeon() hook (chart-theme.ts).
__turbopack_context__.s([
    "ACCENTS",
    ()=>ACCENTS,
    "ACCENT_ORDER",
    ()=>ACCENT_ORDER,
    "DEFAULT_ACCENT",
    ()=>DEFAULT_ACCENT,
    "accentDef",
    ()=>accentDef,
    "nextAccent",
    ()=>nextAccent
]);
const ACCENTS = {
    mint: {
        id: "mint",
        label: "MINT",
        hex: "#00ffa3",
        dim: "#00c47c",
        rgb: "0 255 163"
    },
    cyan: {
        id: "cyan",
        label: "CYAN",
        hex: "#45f0df",
        dim: "#1fbfae",
        rgb: "69 240 223"
    },
    violet: {
        id: "violet",
        label: "VIOLET",
        hex: "#b26bff",
        dim: "#8f42e0",
        rgb: "178 107 255"
    },
    magenta: {
        id: "magenta",
        label: "MAGENTA",
        hex: "#ff4ecd",
        dim: "#d435a8",
        rgb: "255 78 205"
    },
    amber: {
        id: "amber",
        label: "AMBER",
        hex: "#ffb347",
        dim: "#e0942a",
        rgb: "255 179 71"
    }
};
const ACCENT_ORDER = [
    "mint",
    "cyan",
    "violet",
    "magenta",
    "amber"
];
const DEFAULT_ACCENT = "mint";
function nextAccent(current) {
    const idx = ACCENT_ORDER.indexOf(current ?? DEFAULT_ACCENT);
    return ACCENT_ORDER[(idx + 1) % ACCENT_ORDER.length] ?? DEFAULT_ACCENT;
}
function accentDef(id) {
    return ACCENTS[id ?? DEFAULT_ACCENT] ?? ACCENTS[DEFAULT_ACCENT];
}
}),
"[project]/src/store/alerts.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FILTER_PRESET_CAP",
    ()=>FILTER_PRESET_CAP,
    "HEAT_HISTORY_CAP",
    ()=>HEAT_HISTORY_CAP,
    "HEAT_TIMELINE_CAP",
    ()=>HEAT_TIMELINE_CAP,
    "useAlerts",
    ()=>useAlerts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accent.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
const HEAT_HISTORY_CAP = 120;
const HEAT_TIMELINE_CAP = 240;
const FILTER_PRESET_CAP = 8;
const useAlerts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["persist"])((set)=>({
        watchlist: [],
        toggleWatch: (symbol)=>set((s)=>({
                    watchlist: s.watchlist.includes(symbol) ? s.watchlist.filter((w)=>w !== symbol) : [
                        ...s.watchlist,
                        symbol
                    ].slice(0, 12)
                })),
        removeWatch: (symbol)=>set((s)=>({
                    watchlist: s.watchlist.filter((w)=>w !== symbol)
                })),
        alertsMuted: false,
        setAlertsMuted: (alertsMuted)=>set({
                alertsMuted
            }),
        soundEnabled: false,
        setSoundEnabled: (soundEnabled)=>set({
                soundEnabled
            }),
        soundVolume: 0.5,
        setSoundVolume: (soundVolume)=>set({
                soundVolume: Math.max(0, Math.min(1, soundVolume))
            }),
        accent: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_ACCENT"],
        setAccent: (accent)=>set({
                accent
            }),
        lastSeenEventAt: 0,
        setLastSeenEventAt: (lastSeenEventAt)=>set({
                lastSeenEventAt
            }),
        watchOnly: false,
        setWatchOnly: (watchOnly)=>set({
                watchOnly
            }),
        heatHistory: [],
        pushHeatSample: (v)=>set((s)=>({
                    heatHistory: [
                        ...s.heatHistory,
                        Math.max(0, Math.min(100, v))
                    ].slice(-HEAT_HISTORY_CAP)
                })),
        heatTimeline: [],
        pushHeatTimeline: (sample)=>set((s)=>({
                    heatTimeline: [
                        ...s.heatTimeline,
                        sample
                    ].slice(-HEAT_TIMELINE_CAP)
                })),
        clearHeatTimeline: ()=>set({
                heatTimeline: []
            }),
        ttlWarnEnabled: true,
        setTtlWarnEnabled: (ttlWarnEnabled)=>set({
                ttlWarnEnabled
            }),
        sortMode: "NEWEST",
        setSortMode: (sortMode)=>set({
                sortMode
            }),
        csvFields: [
            "CORE",
            "LEVELS",
            "RISK",
            "META",
            "DATES",
            "JOURNAL"
        ],
        toggleCsvField: (id)=>set((s)=>({
                    csvFields: s.csvFields.includes(id) ? s.csvFields.filter((f)=>f !== id) : [
                        ...s.csvFields,
                        id
                    ]
                })),
        setCsvFields: (csvFields)=>set({
                csvFields
            }),
        filterPresets: [],
        addFilterPreset: (name, filters)=>set((s)=>{
                const clean = name.trim().slice(0, 24);
                if (!clean || s.filterPresets.length >= FILTER_PRESET_CAP) return s;
                const preset = {
                    id: `fp-${Date.now().toString(36)}`,
                    name: clean,
                    createdAt: Date.now(),
                    filters: {
                        ...filters
                    }
                };
                return {
                    filterPresets: [
                        ...s.filterPresets,
                        preset
                    ]
                };
            }),
        removeFilterPreset: (id)=>set((s)=>({
                    filterPresets: s.filterPresets.filter((p)=>p.id !== id)
                })),
        viewMode: "GRID",
        setViewMode: (viewMode)=>set({
                viewMode
            })
    }), {
    name: "nexus-alerts",
    version: 8,
    migrate: (persisted, version)=>{
        const p = persisted ?? {};
        if (version < 2) {
            // v1 → v2: introduce soundVolume + accent defaults
            p.soundVolume = typeof p.soundVolume === "number" ? p.soundVolume : 0.5;
            p.accent = p.accent ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_ACCENT"];
        }
        if (version < 3) {
            // v2 → v3: rolling heat trend (empty until the desk samples a tick)
            p.heatHistory = Array.isArray(p.heatHistory) ? p.heatHistory : [];
        }
        if (version < 4) {
            // v3 → v4: timestamped heat timeline + watchlist-only filter
            p.heatTimeline = Array.isArray(p.heatTimeline) ? p.heatTimeline : [];
            p.watchOnly = typeof p.watchOnly === "boolean" ? p.watchOnly : false;
        }
        if (version < 5) {
            // v4 → v5: TTL warn-tier preference + signals sort persistence
            p.ttlWarnEnabled = typeof p.ttlWarnEnabled === "boolean" ? p.ttlWarnEnabled : true;
            p.sortMode = typeof p.sortMode === "string" ? p.sortMode : "NEWEST";
        }
        if (version < 6) {
            // v5 → v6: signals-CSV column-group selection (default: all groups)
            const ALL = [
                "CORE",
                "LEVELS",
                "RISK",
                "META",
                "DATES",
                "JOURNAL"
            ];
            p.csvFields = Array.isArray(p.csvFields) ? p.csvFields.filter((f)=>ALL.includes(f)) : ALL;
        }
        if (version < 7) {
            // v6 → v7: named signals-filter presets
            p.filterPresets = Array.isArray(p.filterPresets) ? p.filterPresets.filter((x)=>!!x && typeof x === "object" && !!x.id && !!x.name && !!x.filters).slice(0, FILTER_PRESET_CAP) : [];
        }
        if (version < 8) {
            // v7 → v8: signal-matrix view mode (cards grid | dense table)
            p.viewMode = p.viewMode === "TABLE" ? "TABLE" : "GRID";
        }
        return p;
    }
}));
}),
"[project]/src/lib/sounds.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "playConfirmChirp",
    ()=>playConfirmChirp,
    "playEventSound",
    ()=>playEventSound,
    "playTtlUrgency",
    ()=>playTtlUrgency,
    "playTtlWarning",
    ()=>playTtlWarning,
    "primeAudio",
    ()=>primeAudio,
    "setMasterVolume",
    ()=>setMasterVolume
]);
// ── FlowRadar Neo event sound engine (client-safe, zero assets) ──
// Tiny WebAudio synthesizer: every engine event gets a distinct voice.
// Context is created lazily and primed by a user gesture (sound toggle).
let ctx = null;
let master = null;
/** Operator volume 0..1 (persisted in nexus-alerts). Master gain = vol × 0.32. */ let volume = 0.5;
function setMasterVolume(v) {
    volume = Math.max(0, Math.min(1, v));
    if (master) master.gain.value = volume * 0.32;
}
function ensureCtx() {
    if ("TURBOPACK compile-time truthy", 1) return null;
    //TURBOPACK unreachable
    ;
    const AC = undefined;
}
function primeAudio() {
    const c = ensureCtx();
    if (!c || c.state !== "running") return;
    // 40ms silent buffer — marks the context as "gesture unlocked" on Safari.
    const buf = c.createBuffer(1, Math.ceil(c.sampleRate * 0.04), c.sampleRate);
    const src = c.createBufferSource();
    src.buffer = buf;
    src.connect(master);
    src.start();
}
function tone({ freq, dur = 0.09, delay = 0, type = "sine", vol = 1, slideTo }) {
    const c = ctx;
    const m = master;
    if (!c || !m || c.state !== "running") return;
    const t0 = c.currentTime + delay;
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), t0 + dur);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain);
    gain.connect(m);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
}
function playEventSound(eventType) {
    if (!ctx || ctx.state !== "running") return;
    switch(eventType){
        case "CREATED":
            // violet double-blip: deployment chirp
            tone({
                freq: 620,
                type: "square",
                vol: 0.5,
                dur: 0.06
            });
            tone({
                freq: 880,
                type: "square",
                vol: 0.5,
                dur: 0.08,
                delay: 0.08
            });
            break;
        case "TP1":
            tone({
                freq: 740,
                vol: 0.6,
                dur: 0.09
            });
            tone({
                freq: 988,
                vol: 0.6,
                dur: 0.12,
                delay: 0.09
            });
            break;
        case "TP2":
            tone({
                freq: 830,
                vol: 0.6,
                dur: 0.09
            });
            tone({
                freq: 1108,
                vol: 0.6,
                dur: 0.12,
                delay: 0.09
            });
            break;
        case "TP3":
            // full-target arpeggio
            tone({
                freq: 659,
                vol: 0.55,
                dur: 0.08
            });
            tone({
                freq: 830,
                vol: 0.55,
                dur: 0.08,
                delay: 0.08
            });
            tone({
                freq: 1174,
                vol: 0.6,
                dur: 0.16,
                delay: 0.16
            });
            break;
        case "SL":
            // descending stop-out buzz
            tone({
                freq: 240,
                slideTo: 96,
                type: "sawtooth",
                vol: 0.5,
                dur: 0.22
            });
            break;
        case "TTL_EXPIRED":
            tone({
                freq: 440,
                vol: 0.4,
                dur: 0.07
            });
            tone({
                freq: 440,
                vol: 0.35,
                dur: 0.07,
                delay: 0.12
            });
            break;
        case "TTL_EXTENDED":
            // v6.1.1: rising gate-grant blip — the mirror of the expiry double-beep
            tone({
                freq: 523,
                vol: 0.4,
                dur: 0.07
            });
            tone({
                freq: 784,
                vol: 0.4,
                dur: 0.1,
                delay: 0.09
            });
            break;
        case "AFTERLIFE":
            // v6.1: soft cyan follow-up blip — post-expiry TP/SL report
            tone({
                freq: 520,
                vol: 0.35,
                dur: 0.06
            });
            tone({
                freq: 780,
                vol: 0.4,
                dur: 0.09,
                delay: 0.08
            });
            break;
        default:
            break;
    }
}
function playConfirmChirp() {
    if (!ensureCtx()) return;
    tone({
        freq: 523,
        vol: 0.5,
        dur: 0.06
    });
    tone({
        freq: 1046,
        vol: 0.5,
        dur: 0.1,
        delay: 0.07
    });
}
function playTtlUrgency() {
    if (!ctx || ctx.state !== "running") return;
    tone({
        freq: 784,
        type: "triangle",
        vol: 0.55,
        dur: 0.07
    });
    tone({
        freq: 784,
        type: "triangle",
        vol: 0.5,
        dur: 0.07,
        delay: 0.11
    });
    tone({
        freq: 1040,
        type: "triangle",
        vol: 0.6,
        dur: 0.14,
        delay: 0.22
    });
}
function playTtlWarning() {
    if (!ctx || ctx.state !== "running") return;
    tone({
        freq: 520,
        type: "sine",
        vol: 0.45,
        dur: 0.08
    });
    tone({
        freq: 520,
        type: "sine",
        vol: 0.38,
        dur: 0.1,
        delay: 0.16
    });
}
}),
"[project]/src/components/fx/SystemBridge.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SystemBridge",
    ()=>SystemBridge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/alerts.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accent.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sounds.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function SystemBridge() {
    const accent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAlerts"])((s)=>s.accent);
    const soundVolume = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAlerts"])((s)=>s.soundVolume);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const def = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["accentDef"])(accent);
        document.documentElement.dataset.accent = def.id;
    }, [
        accent
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setMasterVolume"])(soundVolume);
    }, [
        soundVolume
    ]);
    return null;
}
}),
"[project]/src/hooks/usePulse.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clockDriftMs",
    ()=>clockDriftMs,
    "serverNow",
    ()=>serverNow,
    "syncServerClock",
    ()=>syncServerClock,
    "useDeviceNow",
    ()=>useDeviceNow,
    "useMounted",
    ()=>useMounted,
    "useNow",
    ()=>useNow,
    "usePulse",
    ()=>usePulse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
/* ── server-anchored clock (dashboard clock-drift fix, 2026-09-07) ──
 * TTL countdowns and relative ages were computed from the CLIENT clock;
 * any skew between the operator's device and the engine host shifted every
 * TTL/age by that amount. Each pulse payload carries the engine's epoch-ms
 * `ts`; we keep an EMA-smoothed offset and useNow()/serverNow() return the
 * server-anchored time. Hydration stays safe: server snapshot = 0. */ let clockOffsetMs = 0;
let clockSamples = 0;
const clockListeners = new Set();
function serverNow() {
    return Date.now() + clockOffsetMs;
}
function syncServerClock(serverTs, receivedAtMs = Date.now()) {
    if (serverTs == null || !Number.isFinite(serverTs) || serverTs <= 0) return;
    const raw = serverTs - receivedAtMs;
    if (Math.abs(raw) > 5 * 60_000) return; // wild outlier → bad payload, ignore
    clockOffsetMs = clockSamples === 0 ? raw : Math.round(clockOffsetMs * 0.8 + raw * 0.2);
    clockSamples += 1;
    for (const l of clockListeners)l();
}
function clockDriftMs() {
    return clockOffsetMs;
}
function usePulse(pollMs = 5000) {
    const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "pulse"
        ],
        queryFn: async ()=>{
            const res = await fetch("/api/pulse", {
                cache: "no-store"
            });
            if (!res.ok) throw new Error(`pulse ${res.status}`);
            const json = await res.json();
            syncServerClock(json?.ts);
            return json;
        },
        refetchInterval: (query)=>query.state.error ? Math.min(2000, pollMs) : pollMs,
        refetchIntervalInBackground: true,
        placeholderData: (prev)=>prev,
        retry: 3,
        retryDelay: (attempt)=>Math.min(500 * 2 ** attempt, 4000)
    });
    const ageMs = q.dataUpdatedAt > 0 ? Date.now() - q.dataUpdatedAt : Infinity;
    const stale = ageMs > pollMs * 3;
    const recovering = (q.isError || ageMs > pollMs * 1.5) && !stale;
    return {
        data: q.data,
        isError: q.isError,
        error: q.error,
        stale,
        recovering,
        updatedAt: q.dataUpdatedAt
    };
}
function useNow(intervalMs = 1000) {
    const subscribe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((cb)=>{
        const id = setInterval(cb, intervalMs);
        clockListeners.add(cb);
        return ()=>{
            clearInterval(id);
            clockListeners.delete(cb);
        };
    }, [
        intervalMs
    ]);
    const getSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>Math.floor(serverNow() / 1000) * 1000, []);
    const getServerSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>0, []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribe, getSnapshot, getServerSnapshot);
}
function useDeviceNow(intervalMs = 1000) {
    const subscribe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((cb)=>{
        const id = setInterval(cb, intervalMs);
        return ()=>clearInterval(id);
    }, [
        intervalMs
    ]);
    const getSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>Math.floor(Date.now() / 1000) * 1000, []);
    const getServerSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>0, []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribe, getSnapshot, getServerSnapshot);
}
function useMounted() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSyncExternalStore"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>()=>{}, []), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>true, []), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>false, []));
}
}),
"[project]/src/store/ui.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useUi",
    ()=>useUi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
"use client";
;
const useUi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set)=>({
        view: "dashboard",
        setView: (view)=>set({
                view
            }),
        activeSymbol: null,
        setActiveSymbol: (activeSymbol)=>set({
                activeSymbol
            }),
        paletteOpen: false,
        setPaletteOpen: (paletteOpen)=>set({
                paletteOpen
            }),
        calcOpen: false,
        setCalcOpen: (calcOpen)=>set({
                calcOpen
            }),
        spotlightSymbol: null,
        setSpotlightSymbol: (spotlightSymbol)=>set({
                spotlightSymbol
            }),
        shortcutsOpen: false,
        setShortcutsOpen: (shortcutsOpen)=>set({
                shortcutsOpen
            }),
        analyticsExportAt: 0,
        requestAnalyticsExport: ()=>set({
                analyticsExportAt: Date.now()
            }),
        analyticsCsvAt: 0,
        requestAnalyticsCsv: ()=>set({
                analyticsCsvAt: Date.now()
            }),
        operatorLogJumpAt: 0,
        requestOperatorLog: ()=>set({
                operatorLogJumpAt: Date.now()
            }),
        openSignalId: null,
        setOpenSignal: (openSignalId)=>set({
                openSignalId
            }),
        signalAutoScanSerial: null,
        setSignalAutoScanSerial: (signalAutoScanSerial)=>set({
                signalAutoScanSerial
            })
    }));
}),
"[project]/src/lib/brand.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo — canonical brand + version registry ──────────────────────
// Operator mandate 2026-09-15: rename the program to «FlowRadar Neo» across ALL
// components (dashboard theme respected) and surface the LATEST project version
// in the UI. Every branding surface (header, footer, metadata, Telegram copy,
// posters) imports from this single module so the name/version can never drift.
__turbopack_context__.s([
    "APP_ENGINE_LINE",
    ()=>APP_ENGINE_LINE,
    "APP_NAME",
    ()=>APP_NAME,
    "APP_OG_TITLE",
    ()=>APP_OG_TITLE,
    "APP_STAGE",
    ()=>APP_STAGE,
    "APP_TAGLINE",
    ()=>APP_TAGLINE,
    "APP_TITLE",
    ()=>APP_TITLE,
    "APP_VERSION",
    ()=>APP_VERSION,
    "APP_VERSION_LABEL",
    ()=>APP_VERSION_LABEL,
    "BRAND_TERMINAL",
    ()=>BRAND_TERMINAL
]);
const APP_NAME = "FlowRadar Neo";
const BRAND_TERMINAL = {
    head: "FLOWRADAR",
    sep: "//",
    tail: "NEO"
};
const APP_VERSION = "10.0.0";
const APP_VERSION_LABEL = `v${APP_VERSION}`;
const APP_STAGE = "NEO";
const APP_TAGLINE = `AI TRADING COMMAND ${APP_VERSION_LABEL} — FULL AUTONOMY`;
const APP_ENGINE_LINE = `FLOWRADAR-NEO ${APP_VERSION_LABEL} — AUTONOMOUS`;
const APP_TITLE = `${APP_NAME} — AI Trading Command Terminal`;
const APP_OG_TITLE = `${BRAND_TERMINAL.head}${BRAND_TERMINAL.sep}${BRAND_TERMINAL.tail}`;
}),
"[project]/src/lib/format.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo formatting helpers (client-safe) ──
__turbopack_context__.s([
    "STATUS_META",
    ()=>STATUS_META,
    "distPct",
    ()=>distPct,
    "fmtClock",
    ()=>fmtClock,
    "fmtClockLocal",
    ()=>fmtClockLocal,
    "fmtCompact",
    ()=>fmtCompact,
    "fmtCountdown",
    ()=>fmtCountdown,
    "fmtPct",
    ()=>fmtPct,
    "fmtPrice",
    ()=>fmtPrice,
    "fmtUsd",
    ()=>fmtUsd,
    "levelProgress",
    ()=>levelProgress,
    "localTzLabel",
    ()=>localTzLabel,
    "localTzName",
    ()=>localTzName,
    "signalBrief",
    ()=>signalBrief,
    "timeAgo",
    ()=>timeAgo,
    "ttlRemainingMs",
    ()=>ttlRemainingMs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/brand.ts [app-ssr] (ecmascript)");
;
function fmtPrice(p) {
    if (p >= 1000) return p.toLocaleString("en-US", {
        maximumFractionDigits: 0
    });
    if (p >= 10) return p.toFixed(2);
    if (p >= 1) return p.toFixed(3);
    return p.toFixed(4);
}
function fmtUsd(v, compact = true) {
    const abs = Math.abs(v);
    const sign = v < 0 ? "-" : "";
    if (compact) {
        if (abs >= 1_000_000_000) return `${sign}$${(abs / 1_000_000_000).toFixed(2)}B`;
        if (abs >= 1_000_000) return `${sign}$${(abs / 1_000_000).toFixed(2)}M`;
        if (abs >= 1_000) return `${sign}$${(abs / 1_000).toFixed(1)}K`;
    }
    return `${sign}$${abs.toFixed(2)}`;
}
function fmtPct(v, withSign = true) {
    const sign = withSign && v > 0 ? "+" : "";
    return `${sign}${v.toFixed(2)}%`;
}
function fmtCompact(n) {
    if (Math.abs(n) >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
    if (Math.abs(n) >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
    return n.toFixed(0);
}
function fmtCountdown(iso, now) {
    const diff = Math.max(0, new Date(iso).getTime() - now);
    const h = Math.floor(diff / 3_600_000);
    const m = Math.floor(diff % 3_600_000 / 60_000);
    const s = Math.floor(diff % 60_000 / 1000);
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function ttlRemainingMs(iso, now) {
    return Math.max(0, new Date(iso).getTime() - now);
}
function timeAgo(iso, now) {
    const diff = now - new Date(iso).getTime();
    const m = Math.floor(diff / 60_000);
    if (m < 1) return "now";
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.floor(h / 24)}d ago`;
}
function fmtClock(ts) {
    if (!ts || ts <= 0) return "--:--:--";
    return new Date(ts).toLocaleTimeString("en-GB", {
        hour12: false,
        timeZone: "UTC"
    });
}
function fmtClockLocal(ts) {
    if (!ts || ts <= 0) return "--:--:--";
    return new Date(ts).toLocaleTimeString("en-GB", {
        hour12: false
    });
}
function localTzLabel() {
    const min = -new Date().getTimezoneOffset();
    const sign = min >= 0 ? "+" : "−";
    const abs = Math.abs(min);
    const hh = String(Math.floor(abs / 60)).padStart(2, "0");
    const mm = String(abs % 60).padStart(2, "0");
    return `GMT${sign}${hh}:${mm}`;
}
function localTzName() {
    try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone || localTzLabel();
    } catch  {
        return localTzLabel();
    }
}
function levelProgress(price, entry, stopLoss, tp3) {
    if (entry === stopLoss || entry === tp3) return 0.5;
    const t = (price - stopLoss) / (tp3 - stopLoss);
    return Math.min(1, Math.max(0, t));
}
function distPct(from, to) {
    return (to - from) / from * 100;
}
const STATUS_META = {
    ACTIVE: {
        label: "LIVE",
        tone: "live"
    },
    TP1: {
        label: "TP1 HIT",
        tone: "win"
    },
    TP2: {
        label: "TP2 HIT",
        tone: "win"
    },
    TP3: {
        label: "TP3 FULL",
        tone: "win"
    },
    SL: {
        label: "SL HIT",
        tone: "loss"
    },
    EXPIRED: {
        label: "TTL END",
        tone: "warn"
    },
    CLOSED: {
        label: "CLOSED",
        tone: "muted"
    }
};
function signalBrief(s, price) {
    const meta = STATUS_META[s.status] ?? {
        label: s.status
    };
    const lines = [
        `◆ ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["APP_NAME"]} — ${s.symbol} ${s.direction}`,
        `STRATEGY   ${s.strategy} · ${s.timeframe} · ${s.engine}`,
        `STATUS     ${meta.label} · CONF ${Math.round(s.confidence)}% · R:R 1:${s.riskReward.toFixed(1)}`,
        `ENTRY      ${fmtPrice(s.entryPrice)}  (zone ${fmtPrice(s.entryZoneLow)}–${fmtPrice(s.entryZoneHigh)})`,
        `TP1 / TP2 / TP3   ${fmtPrice(s.tp1)} / ${fmtPrice(s.tp2)} / ${fmtPrice(s.tp3)}`,
        `STOP-LOSS  ${fmtPrice(s.stopLoss)}`,
        `SIZE       ${s.leverage}× lev · margin ${fmtUsd(s.marginUsd, false)} · notional ${fmtUsd(s.marginUsd * s.leverage)}`,
        `TTL        ${s.ttlMinutes}m · expires ${new Date(s.expiresAt).toISOString().slice(11, 16)}Z`
    ];
    if (typeof price === "number" && price > 0) lines.push(`MARKET     ${fmtPrice(price)} now`);
    if (s.operatorNotes?.trim()) {
        lines.push(`JOURNAL    ${s.operatorNotes.trim().replace(/\s+/g, " ").slice(0, 160)}${s.operatorNotes.trim().length > 160 ? "…" : ""}`);
    }
    lines.push(`SIG-${s.id.slice(-4).toUpperCase()} · ${s.tags.map((t)=>`#${t}`).join(" ")}`);
    return lines.join("\n");
}
}),
"[project]/src/components/analytics/chart-theme.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AMBER",
    ()=>AMBER,
    "AXIS_LINE_STROKE",
    ()=>AXIS_LINE_STROKE,
    "AXIS_TICK",
    ()=>AXIS_TICK,
    "CYAN",
    ()=>CYAN,
    "DANGER",
    ()=>DANGER,
    "EquityTooltip",
    ()=>EquityTooltip,
    "GRID_STROKE",
    ()=>GRID_STROKE,
    "MAGENTA",
    ()=>MAGENTA,
    "MUTED_LINE",
    ()=>MUTED_LINE,
    "NEON",
    ()=>NEON,
    "NEON_PALETTE",
    ()=>NEON_PALETTE,
    "NexusTooltip",
    ()=>NexusTooltip,
    "VIOLET",
    ()=>VIOLET,
    "useChartPalette",
    ()=>useChartPalette,
    "useNeon",
    ()=>useNeon
]);
// ── FlowRadar Neo — shared Recharts theme constants & glass tooltip ──
// Palette is restricted to the neon set + ink tones. Never blue/indigo.
// NOTE: SVG/Recharts props can't resolve CSS vars — chart series that should
// follow the operator accent use the useNeon() hook (hex) instead of var().
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accent.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/alerts.ts [app-ssr] (ecmascript)");
;
;
;
const NEON_PALETTE = [
    "#00ffa3",
    "#b26bff",
    "#ff4ecd",
    "#ffb347",
    "#45f0df",
    "#ff4d5e"
];
const NEON = NEON_PALETTE[0];
const VIOLET = NEON_PALETTE[1];
const MAGENTA = NEON_PALETTE[2];
const AMBER = NEON_PALETTE[3];
const CYAN = NEON_PALETTE[4];
const DANGER = NEON_PALETTE[5];
function useNeon() {
    const accent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAlerts"])((s)=>s.accent);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["accentDef"])(accent).hex;
}
const CHART_PALETTES = {
    mint: {
        primary: "#00ffa3",
        secondary: "#b26bff",
        tertiary: "#ffb347",
        quaternary: "#45f0df",
        opposing: "#ff4ecd"
    },
    cyan: {
        primary: "#45f0df",
        secondary: "#b26bff",
        tertiary: "#ffb347",
        quaternary: "#00ffa3",
        opposing: "#ff4ecd"
    },
    violet: {
        primary: "#b26bff",
        secondary: "#ff4ecd",
        tertiary: "#ffb347",
        quaternary: "#45f0df",
        opposing: "#45f0df"
    },
    magenta: {
        primary: "#ff4ecd",
        secondary: "#b26bff",
        tertiary: "#ffb347",
        quaternary: "#45f0df",
        opposing: "#b26bff"
    },
    amber: {
        primary: "#ffb347",
        secondary: "#b26bff",
        tertiary: "#ff4ecd",
        quaternary: "#45f0df",
        opposing: "#b26bff"
    }
};
function useChartPalette() {
    const accent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAlerts"])((s)=>s.accent);
    return CHART_PALETTES[accent] ?? CHART_PALETTES.mint;
}
const AXIS_TICK = {
    fill: "#5c6f66",
    fontSize: 10,
    fontFamily: "var(--font-terminal)"
};
const GRID_STROKE = "rgba(159,180,171,0.08)";
const AXIS_LINE_STROKE = "rgba(159,180,171,0.12)";
const MUTED_LINE = "rgba(159,180,171,0.25)";
function formatEntry(value, prefix, unit) {
    if (typeof value === "number") {
        const sign = value < 0 ? "-" : "";
        const body = Math.abs(value).toLocaleString("en-US", {
            maximumFractionDigits: 2
        });
        return `${sign}${prefix ?? ""}${body}${unit ?? ""}`;
    }
    return `${prefix ?? ""}${value}${unit ?? ""}`;
}
function NexusTooltip({ active, payload, label, unit, prefix, units, prefixes }) {
    if (!active || !payload || payload.length === 0) return null;
    const rows = payload.map((entry, i)=>{
        const resolvedUnit = units?.[String(entry.dataKey)] ?? unit;
        const resolvedPrefix = prefixes?.[String(entry.dataKey)] ?? prefix;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("div", {
            key: `row-${i}`,
            className: "mt-0.5 flex items-center gap-2 whitespace-nowrap"
        }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
            key: "dot",
            className: "inline-block h-2 w-2 shrink-0 rounded-full",
            style: {
                background: entry.color ?? NEON,
                boxShadow: `0 0 6px ${entry.color ?? NEON}`
            }
        }), entry.name !== undefined && entry.name !== null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
            key: "name",
            className: "text-ink-2"
        }, String(entry.name).toUpperCase()) : null, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
            key: "value",
            className: "ml-auto font-bold text-ink"
        }, formatEntry(entry.value ?? 0, resolvedPrefix, resolvedUnit)));
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("div", {
        className: "rounded-lg border border-[rgb(var(--neon-rgb)/0.2)] bg-[rgba(8,12,16,0.95)] px-3 py-2 font-terminal text-xs shadow backdrop-blur"
    }, label !== undefined && label !== null && label !== "" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("div", {
        key: "label",
        className: "label-tech"
    }, String(label).toUpperCase()) : null, ...rows);
}
function EquityTooltip({ active, payload, label }) {
    if (!active || !payload || payload.length === 0) return null;
    const d = payload[0]?.payload;
    if (!d) return null;
    const cumPos = d.cum >= 0;
    const dayPos = d.daily >= 0;
    const fmt = (v)=>`${v < 0 ? "−" : "+"}$${Math.abs(v).toLocaleString("en-US", {
            maximumFractionDigits: 0
        })}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("div", {
        className: "min-w-[150px] rounded-lg border border-[rgb(var(--neon-rgb)/0.22)] bg-[rgba(8,12,16,0.96)] px-3 py-2 font-terminal text-xs shadow-[0_8px_28px_-10px_rgba(0,0,0,0.9)] backdrop-blur"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("div", {
        key: "head",
        className: "flex items-center justify-between gap-3"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
        key: "d",
        className: "label-tech"
    }, String(label ?? d.label).toUpperCase()), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
        key: "dot",
        className: "h-1.5 w-1.5 rounded-full",
        style: {
            background: NEON,
            boxShadow: `0 0 8px ${NEON}`
        }
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("div", {
        key: "cum",
        className: "mt-1.5 flex items-baseline justify-between gap-4 whitespace-nowrap"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
        key: "k",
        className: "text-ink-2"
    }, "CUM EQUITY"), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
        key: "v",
        className: `font-bold tabular-nums ${cumPos ? "text-neon" : "text-danger-neon"}`,
        style: {
            textShadow: cumPos ? `0 0 10px ${NEON}66` : "0 0 10px rgba(255,77,94,0.4)"
        }
    }, fmt(d.cum))), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("div", {
        key: "day",
        className: "mt-0.5 flex items-baseline justify-between gap-4 whitespace-nowrap"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
        key: "k",
        className: "text-ink-2"
    }, "DAY PNL"), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("span", {
        key: "v",
        className: `font-bold tabular-nums ${dayPos ? "text-neon" : "text-danger-neon"}`
    }, fmt(d.daily))));
}
}),
"[project]/src/components/shared/primitives.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BentoCard",
    ()=>BentoCard,
    "ConfidenceBar",
    ()=>ConfidenceBar,
    "CountdownRing",
    ()=>CountdownRing,
    "LiveDot",
    ()=>LiveDot,
    "NeonBadge",
    ()=>NeonBadge,
    "SectionHeader",
    ()=>SectionHeader,
    "Sparkline",
    ()=>Sparkline,
    "StatChip",
    ()=>StatChip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2f$chart$2d$theme$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/analytics/chart-theme.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function BentoCard({ children, className, tone = "neon", corners = false, delay = 0, onClick, ariaLabel }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            opacity: 0,
            y: 22
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            duration: 0.55,
            delay,
            ease: [
                0.22,
                1,
                0.36,
                1
            ]
        },
        onClick: onClick,
        role: onClick ? "button" : undefined,
        tabIndex: onClick ? 0 : undefined,
        "aria-label": ariaLabel,
        onKeyDown: onClick ? (e)=>{
            if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onClick();
            }
        } : undefined,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bento p-4 sm:p-5", onClick && "cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[rgb(var(--neon-rgb)/0.55)] focus-visible:ring-offset-0", tone === "violet" && "bento-violet", tone === "magenta" && "bento-magenta", corners && "hud-corners", className),
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
/* ── Neon badge ─────────────────────────────────────────── */ const badgeTones = {
    neon: "border-[rgb(var(--neon-rgb)/0.35)] text-neon bg-[rgb(var(--neon-rgb)/0.08)]",
    violet: "border-[rgba(178,107,255,0.4)] text-violet-neon bg-[rgba(178,107,255,0.08)]",
    magenta: "border-[rgba(255,78,205,0.4)] text-magenta-neon bg-[rgba(255,78,205,0.08)]",
    amber: "border-[rgba(255,179,71,0.4)] text-amber-neon bg-[rgba(255,179,71,0.08)]",
    danger: "border-[rgba(255,77,94,0.4)] text-danger-neon bg-[rgba(255,77,94,0.08)]",
    cyan: "border-[rgba(69,240,223,0.4)] text-cyan-neon bg-[rgba(69,240,223,0.08)]",
    muted: "border-[rgba(159,180,171,0.25)] text-ink-2 bg-[rgba(159,180,171,0.06)]"
};
function NeonBadge({ children, tone = "neon", className, glow = false, title }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        title: title,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center gap-1 rounded-md border px-2 py-0.5 font-terminal text-[10px] font-semibold uppercase tracking-[0.14em] whitespace-nowrap", badgeTones[tone], glow && "shadow-[0_0_14px_-2px_currentColor]", className),
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this);
}
function LiveDot({ tone = "neon", className }) {
    const c = {
        neon: "bg-neon",
        danger: "bg-danger-neon",
        amber: "bg-amber-neon",
        violet: "bg-violet-neon"
    }[tone];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("inline-block h-2 w-2 rounded-full anim-pulse-dot", c, className)
    }, void 0, false, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 104,
        columnNumber: 10
    }, this);
}
function SectionHeader({ index, title, subtitle, right }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-4 flex flex-wrap items-end justify-between gap-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-terminal text-[11px] font-bold text-neon/70",
                                children: [
                                    "[",
                                    index,
                                    "]"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/shared/primitives.tsx",
                                lineNumber: 123,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "font-terminal text-lg font-bold uppercase tracking-[0.14em] text-foreground sm:text-xl",
                                children: title
                            }, void 0, false, {
                                fileName: "[project]/src/components/shared/primitives.tsx",
                                lineNumber: 124,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-1.5 h-px w-40 overflow-hidden bg-white/8 sm:w-56",
                        "aria-hidden": true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-full w-1/2 bg-gradient-to-r from-transparent via-neon to-transparent",
                            style: {
                                animation: "beam-slide 3.2s ease-in-out infinite"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/shared/primitives.tsx",
                            lineNumber: 130,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 129,
                        columnNumber: 9
                    }, this),
                    subtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1.5 text-xs text-ink-2 sm:text-[13px]",
                        children: subtitle
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 135,
                        columnNumber: 22
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 121,
                columnNumber: 7
            }, this),
            right
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 120,
        columnNumber: 5
    }, this);
}
function Sparkline({ data, width = 120, height = 36, tone = "neon", fill = true, strokeWidth = 1.5, className }) {
    const accentHex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2f$chart$2d$theme$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useNeon"])(); // "neon" tone follows the operator accent
    if (!data || data.length < 2) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: width,
        height: height,
        className: className
    }, void 0, false, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 161,
        columnNumber: 40
    }, this);
    const colors = {
        neon: accentHex,
        danger: "#ff4d5e",
        violet: "#b26bff",
        cyan: "#45f0df"
    };
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    const stepX = width / (data.length - 1);
    const pts = data.map((v, i)=>[
            i * stepX,
            height - 3 - (v - min) / range * (height - 6)
        ]);
    const line = pts.map((p, i)=>`${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
    const area = `${line} L${width},${height} L0,${height} Z`;
    const color = colors[tone];
    const id = `spark-${tone}-${data.length}-${Math.round(min * 100)}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: width,
        height: height,
        viewBox: `0 0 ${width} ${height}`,
        className: className,
        "aria-hidden": true,
        children: [
            fill && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                            id: id,
                            x1: "0",
                            y1: "0",
                            x2: "0",
                            y2: "1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                    offset: "0%",
                                    stopColor: color,
                                    stopOpacity: "0.28"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/shared/primitives.tsx",
                                    lineNumber: 183,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                    offset: "100%",
                                    stopColor: color,
                                    stopOpacity: "0"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/shared/primitives.tsx",
                                    lineNumber: 184,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/shared/primitives.tsx",
                            lineNumber: 182,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 181,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: area,
                        fill: `url(#${id})`
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 187,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: line,
                fill: "none",
                stroke: color,
                strokeWidth: strokeWidth,
                strokeLinejoin: "round",
                strokeLinecap: "round"
            }, void 0, false, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 190,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: pts[pts.length - 1][0],
                cy: pts[pts.length - 1][1],
                r: "2",
                fill: color,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("animate", {
                    attributeName: "opacity",
                    values: "1;0.3;1",
                    dur: "1.6s",
                    repeatCount: "indefinite"
                }, void 0, false, {
                    fileName: "[project]/src/components/shared/primitives.tsx",
                    lineNumber: 192,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 191,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 178,
        columnNumber: 5
    }, this);
}
function ConfidenceBar({ value, className }) {
    const tone = value >= 85 ? "bg-neon" : value >= 70 ? "bg-cyan-neon" : value >= 55 ? "bg-amber-neon" : "bg-danger-neon";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-2", className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-1.5 flex-1 overflow-hidden rounded-full bg-white/5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("h-full rounded-full", tone),
                    initial: {
                        width: 0
                    },
                    animate: {
                        width: `${value}%`
                    },
                    transition: {
                        duration: 0.9,
                        ease: [
                            0.22,
                            1,
                            0.36,
                            1
                        ]
                    },
                    style: {
                        boxShadow: "0 0 8px currentColor"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/shared/primitives.tsx",
                    lineNumber: 204,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 203,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "font-terminal text-[11px] font-bold text-ink-2",
                children: [
                    value,
                    "%"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 212,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 202,
        columnNumber: 5
    }, this);
}
function StatChip({ label, value, tone = "neon", className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("rounded-lg border bg-white/[0.02] px-3 py-2", badgeTones[tone].split(" ")[0], className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "label-tech",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 231,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("mt-0.5 font-terminal text-sm font-bold", badgeTones[tone].split(" ")[1]),
                children: value
            }, void 0, false, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 232,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 230,
        columnNumber: 5
    }, this);
}
function CountdownRing({ progress, label, sub, size = 64, tone, urgent = false, ariaLabel }) {
    const r = (size - 8) / 2;
    const circ = 2 * Math.PI * r;
    const accentHex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2f$chart$2d$theme$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useNeon"])(); // neon tone follows the operator accent
    const t = tone ?? (progress > 0.5 ? "neon" : progress > 0.2 ? "amber" : "danger");
    const color = {
        neon: accentHex,
        amber: "#ffb347",
        danger: "#ff4d5e",
        cyan: "#45f0df",
        muted: "#9fb4ab"
    }[t];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("relative inline-flex items-center justify-center", urgent && "anim-pulse-glow"),
        style: {
            width: size,
            height: size
        },
        role: "timer",
        "aria-label": ariaLabel ?? `Time remaining ${label}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: size,
                height: size,
                className: "-rotate-90",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: size / 2,
                        cy: size / 2,
                        r: r,
                        stroke: "rgba(255,255,255,0.07)",
                        strokeWidth: "3.5",
                        fill: "none"
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 269,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: size / 2,
                        cy: size / 2,
                        r: r,
                        stroke: color,
                        strokeWidth: "3.5",
                        fill: "none",
                        strokeLinecap: "round",
                        strokeDasharray: circ,
                        strokeDashoffset: circ * (1 - Math.max(0, Math.min(1, progress))),
                        style: {
                            transition: "stroke-dashoffset 0.9s linear",
                            filter: `drop-shadow(0 0 5px ${color})`
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 270,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 268,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-terminal font-bold tabular-nums leading-none",
                        style: {
                            color,
                            fontSize: size * 0.24
                        },
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 284,
                        columnNumber: 9
                    }, this),
                    sub && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "label-tech mt-0.5",
                        style: {
                            fontSize: size * 0.13
                        },
                        children: sub
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/primitives.tsx",
                        lineNumber: 287,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/shared/primitives.tsx",
                lineNumber: 283,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/shared/primitives.tsx",
        lineNumber: 262,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/shared/LevelChart.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LevelChart",
    ()=>LevelChart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2f$chart$2d$theme$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/analytics/chart-theme.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
function LevelChart({ signal, history, width = 560, height = 190, livePrice }) {
    const accentHex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2f$chart$2d$theme$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useNeon"])(); // TP2/TP3 lines follow the operator accent
    // v5.4 LIVE TAIL — splice the live pulse price onto the end of the fetched
    // series so the line + dot ride every pulse instead of freezing on stale
    // history while the next 24h snapshot refetch is pending.
    const series = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const pts = [
            ...history
        ];
        if (livePrice && Number.isFinite(livePrice)) {
            const last = pts.length ? pts[pts.length - 1] : null;
            const eps = livePrice > 100 ? 0.02 : livePrice > 1 ? 0.0005 : 0.00002;
            if (!last || Math.abs(last.price - livePrice) > eps) {
                pts.push({
                    t: last ? new Date(Date.now()).toISOString() : new Date(Date.now() - 60_000).toISOString(),
                    price: livePrice
                });
            }
        }
        return pts;
    }, [
        history,
        livePrice
    ]);
    const chart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const prices = series.map((h)=>h.price);
        const levels = [
            signal.entryPrice,
            signal.tp1,
            signal.tp2,
            signal.tp3,
            signal.stopLoss
        ];
        if (livePrice) levels.push(livePrice);
        const all = [
            ...prices,
            ...levels
        ].filter((n)=>Number.isFinite(n));
        if (all.length < 2) return null;
        let min = Math.min(...all);
        let max = Math.max(...all);
        const pad = (max - min) * 0.08 || max * 0.01;
        min -= pad;
        max += pad;
        const padL = 8;
        const padR = 62; // right gutter for level labels
        const padT = 10;
        const padB = 16;
        const iw = width - padL - padR;
        const ih = height - padT - padB;
        const y = (p)=>padT + ih - (p - min) / (max - min) * ih;
        const x = (i, n)=>padL + i / Math.max(1, n - 1) * iw;
        const linePts = series.map((h, i)=>[
                x(i, series.length),
                y(h.price)
            ]);
        const line = linePts.map((p, i)=>`${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
        const areaPath = series.length ? `${line} L${linePts[linePts.length - 1][0].toFixed(1)},${(padT + ih).toFixed(1)} L${padL},${(padT + ih).toFixed(1)} Z` : "";
        const isLong = signal.direction === "LONG";
        const zoneTop = y(isLong ? signal.tp3 : signal.entryPrice);
        const zoneBottom = y(isLong ? signal.entryPrice : signal.tp3);
        const riskTop = y(isLong ? signal.entryPrice : signal.stopLoss);
        const riskBottom = y(isLong ? signal.stopLoss : signal.entryPrice);
        const levelMeta = [
            {
                label: "TP3",
                price: signal.tp3,
                color: accentHex,
                dash: "3 4"
            },
            {
                label: "TP2",
                price: signal.tp2,
                color: accentHex,
                dash: "3 4"
            },
            {
                label: "TP1",
                price: signal.tp1,
                color: "#45f0df",
                dash: "3 4"
            },
            {
                label: "ENTRY",
                price: signal.entryPrice,
                color: "#e8f5ef",
                dash: "6 4"
            },
            {
                label: "SL",
                price: signal.stopLoss,
                color: "#ff4d5e",
                dash: "3 4"
            }
        ].filter((l)=>l.price >= min && l.price <= max);
        return {
            x,
            y,
            line,
            areaPath,
            min,
            max,
            padL,
            padR,
            padT,
            ih,
            iw,
            height,
            width,
            zoneTop,
            zoneBottom,
            riskTop,
            riskBottom,
            levelMeta
        };
    }, [
        series,
        signal,
        livePrice,
        width,
        height,
        accentHex
    ]);
    if (!chart || series.length < 2) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex h-[190px] items-center justify-center rounded-lg border border-white/5 bg-white/[0.015]",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "label-tech",
                children: "COLLECTING PRICE HISTORY…"
            }, void 0, false, {
                fileName: "[project]/src/components/shared/LevelChart.tsx",
                lineNumber: 96,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/shared/LevelChart.tsx",
            lineNumber: 95,
            columnNumber: 7
        }, this);
    }
    const last = series[series.length - 1];
    const lastY = chart.y(last.price);
    const lastX = chart.x(series.length - 1, series.length);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: "100%",
                viewBox: `0 0 ${chart.width} ${chart.height}`,
                className: "block",
                role: "img",
                "aria-label": `${signal.symbol} price history with TP/SL levels`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                            id: "lvl-area",
                            x1: "0",
                            y1: "0",
                            x2: "0",
                            y2: "1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                    offset: "0%",
                                    stopColor: "#45f0df",
                                    stopOpacity: "0.22"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/shared/LevelChart.tsx",
                                    lineNumber: 110,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                    offset: "100%",
                                    stopColor: "#45f0df",
                                    stopOpacity: "0"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/shared/LevelChart.tsx",
                                    lineNumber: 111,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/shared/LevelChart.tsx",
                            lineNumber: 109,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/LevelChart.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        x: chart.padL,
                        y: Math.min(chart.zoneTop, chart.zoneBottom),
                        width: chart.iw,
                        height: Math.abs(chart.zoneBottom - chart.zoneTop),
                        fill: "rgb(var(--neon-rgb)/0.07)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/LevelChart.tsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        x: chart.padL,
                        y: Math.min(chart.riskTop, chart.riskBottom),
                        width: chart.iw,
                        height: Math.abs(chart.riskBottom - chart.riskTop),
                        fill: "rgba(255,77,94,0.07)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/LevelChart.tsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: chart.areaPath,
                        fill: "url(#lvl-area)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/LevelChart.tsx",
                        lineNumber: 133,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: chart.line,
                        fill: "none",
                        stroke: "#45f0df",
                        strokeWidth: "1.8",
                        strokeLinejoin: "round",
                        strokeLinecap: "round"
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/LevelChart.tsx",
                        lineNumber: 134,
                        columnNumber: 9
                    }, this),
                    chart.levelMeta.map((l)=>{
                        const ly = chart.y(l.price);
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                    x1: chart.padL,
                                    y1: ly,
                                    x2: chart.padL + chart.iw,
                                    y2: ly,
                                    stroke: l.color,
                                    strokeOpacity: "0.55",
                                    strokeWidth: "1",
                                    strokeDasharray: l.dash
                                }, void 0, false, {
                                    fileName: "[project]/src/components/shared/LevelChart.tsx",
                                    lineNumber: 141,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                                    x: chart.padL + chart.iw + 6,
                                    y: ly + 3.5,
                                    fill: l.color,
                                    fontSize: "9",
                                    fontFamily: "var(--font-terminal)",
                                    letterSpacing: "1",
                                    children: [
                                        l.label,
                                        " ",
                                        l.price >= 100 ? l.price.toFixed(0) : l.price.toFixed(l.price >= 1 ? 2 : 4)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/shared/LevelChart.tsx",
                                    lineNumber: 142,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, l.label, true, {
                            fileName: "[project]/src/components/shared/LevelChart.tsx",
                            lineNumber: 140,
                            columnNumber: 13
                        }, this);
                    }),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: lastX,
                        cy: lastY,
                        r: "3.2",
                        fill: "#45f0df",
                        stroke: "#05070a",
                        strokeWidth: "1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("animate", {
                            attributeName: "opacity",
                            values: "1;0.35;1",
                            dur: "1.4s",
                            repeatCount: "indefinite"
                        }, void 0, false, {
                            fileName: "[project]/src/components/shared/LevelChart.tsx",
                            lineNumber: 151,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/shared/LevelChart.tsx",
                        lineNumber: 150,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/shared/LevelChart.tsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pointer-events-none absolute right-0 rounded border border-[rgba(69,240,223,0.4)] bg-[rgba(69,240,223,0.08)] px-1.5 py-0.5 font-terminal text-[10px] font-bold text-cyan-neon",
                style: {
                    top: Math.max(0, Math.min(chart.height - 22, lastY - 10))
                },
                children: last.price >= 1000 ? last.price.toFixed(0) : last.price.toFixed(last.price >= 1 ? 2 : 4)
            }, void 0, false, {
                fileName: "[project]/src/components/shared/LevelChart.tsx",
                lineNumber: 156,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/shared/LevelChart.tsx",
        lineNumber: 106,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
            destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
;
}),
"[project]/src/components/ui/dialog.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Dialog",
    ()=>Dialog,
    "DialogClose",
    ()=>DialogClose,
    "DialogContent",
    ()=>DialogContent,
    "DialogDescription",
    ()=>DialogDescription,
    "DialogFooter",
    ()=>DialogFooter,
    "DialogHeader",
    ()=>DialogHeader,
    "DialogOverlay",
    ()=>DialogOverlay,
    "DialogPortal",
    ()=>DialogPortal,
    "DialogTitle",
    ()=>DialogTitle,
    "DialogTrigger",
    ()=>DialogTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-dialog/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as XIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function Dialog({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "dialog",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 12,
        columnNumber: 10
    }, this);
}
function DialogTrigger({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "dialog-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 18,
        columnNumber: 10
    }, this);
}
function DialogPortal({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"], {
        "data-slot": "dialog-portal",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 24,
        columnNumber: 10
    }, this);
}
function DialogClose({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"], {
        "data-slot": "dialog-close",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 30,
        columnNumber: 10
    }, this);
}
function DialogOverlay({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Overlay"], {
        "data-slot": "dialog-overlay",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
function DialogContent({ className, children, showCloseButton = true, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogPortal, {
        "data-slot": "dialog-portal",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogOverlay, {}, void 0, false, {
                fileName: "[project]/src/components/ui/dialog.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
                "data-slot": "dialog-content",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg", className),
                ...props,
                children: [
                    children,
                    showCloseButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"], {
                        "data-slot": "dialog-close",
                        className: "ring-offset-background focus:ring-ring data-[state=open]:bg-accent data-[state=open]:text-muted-foreground absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__["XIcon"], {}, void 0, false, {
                                fileName: "[project]/src/components/ui/dialog.tsx",
                                lineNumber: 74,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "sr-only",
                                children: "Close"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/dialog.tsx",
                                lineNumber: 75,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/dialog.tsx",
                        lineNumber: 70,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/dialog.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
function DialogHeader({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "dialog-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-2 text-center sm:text-left", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 85,
        columnNumber: 5
    }, this);
}
function DialogFooter({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "dialog-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 95,
        columnNumber: 5
    }, this);
}
function DialogTitle({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"], {
        "data-slot": "dialog-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-lg leading-none font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 111,
        columnNumber: 5
    }, this);
}
function DialogDescription({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"], {
        "data-slot": "dialog-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 124,
        columnNumber: 5
    }, this);
}
;
}),
"[project]/src/components/ui/skeleton.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Skeleton",
    ()=>Skeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
function Skeleton({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "skeleton",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-accent animate-pulse rounded-md", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/skeleton.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
;
}),
"[project]/src/components/signals/SignalDetailDialog.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SignalDetailDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html$2d$to$2d$image$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/html-to-image/es/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Brain$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/brain.js [app-ssr] (ecmascript) <export default as Brain>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-column.js [app-ssr] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-ssr] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$copy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Copy$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/copy.js [app-ssr] (ecmascript) <export default as Copy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cpu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cpu$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/cpu.js [app-ssr] (ecmascript) <export default as Cpu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ghost$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Ghost$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/ghost.js [app-ssr] (ecmascript) <export default as Ghost>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Hash$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/hash.js [app-ssr] (ecmascript) <export default as Hash>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ImageDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/image-down.js [app-ssr] (ecmascript) <export default as ImageDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Link2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/link-2.js [app-ssr] (ecmascript) <export default as Link2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/notebook-pen.js [app-ssr] (ecmascript) <export default as NotebookPen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-ssr] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/save.js [app-ssr] (ecmascript) <export default as Save>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-ssr] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/tag.js [app-ssr] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$telescope$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Telescope$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/telescope.js [app-ssr] (ecmascript) <export default as Telescope>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$waves$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Waves$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/waves.js [app-ssr] (ecmascript) <export default as Waves>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/ui.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/format.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$LevelChart$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/LevelChart.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/dialog.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/skeleton.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/usePulse.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const OPEN_STATUSES = new Set([
    "ACTIVE",
    "TP1",
    "TP2"
]);
/** TP resolution cascade rank — TP3 implies TP1+TP2 hit. */ const STATUS_RANK = {
    ACTIVE: 0,
    TP1: 1,
    TP2: 2,
    TP3: 3,
    SL: 0,
    EXPIRED: 0,
    CLOSED: 0
};
const TONE_TO_BADGE = {
    live: "neon",
    win: "cyan",
    loss: "danger",
    warn: "amber",
    muted: "muted"
};
/** Timeline event type → badge tone (CREATED=violet, TP*=neon, SL=danger, TTL_EXPIRED=amber, TTL_EXTENDED=cyan, CLOSED=muted). */ function eventTone(e) {
    if (e.type.startsWith("TP")) return "neon";
    if (e.type === "SL") return "danger";
    if (e.type === "TTL_EXPIRED") return "amber";
    if (e.type === "TTL_EXTENDED") return "cyan";
    if (e.type === "BE_TRAIL") return "cyan";
    if (e.type === "CLOSED") return "muted";
    return "violet";
}
function eventDot(e) {
    return ({
        neon: "bg-neon shadow-[0_0_8px_rgb(var(--neon-rgb)/0.8)]",
        danger: "bg-danger-neon shadow-[0_0_8px_rgba(255,77,94,0.8)]",
        amber: "bg-amber-neon shadow-[0_0_8px_rgba(255,179,71,0.8)]",
        violet: "bg-violet-neon shadow-[0_0_8px_rgba(178,107,255,0.8)]",
        muted: "bg-ink-3",
        magenta: "bg-magenta-neon"
    })[eventTone(e)];
}
/* ── Operator journal ─────────────────────────────────────── */ const NOTES_MAX = 2000;
/**
 * Strategy-aware journal prompt seeds — tap to append a reflection
 * scaffold to the draft. Families mirror the engine's strategy ids.
 */ function journalPrompts(strategy) {
    const s = strategy.toUpperCase();
    if (s.includes("BREAKOUT") || s.includes("RANGE-BREAK")) {
        return [
            "Trigger quality (close + volume):",
            "Failed-breakout plan:",
            "Re-entry trigger:"
        ];
    }
    if (s.includes("MEAN-REVERT") || s.includes("RANGE")) {
        return [
            "Range boundaries respected?",
            "Reversion trigger (wick/flow):",
            "Invalidation beyond range:"
        ];
    }
    if (s.includes("SWING") || s.includes("TREND")) {
        return [
            "Trend structure read:",
            "Pullback depth & timing:",
            "Swing management plan:"
        ];
    }
    if (s.includes("MOMENTUM") || s.includes("SCALP")) {
        return [
            "Momentum source (CVD/funding):",
            "Execution slippage:",
            "Exit discipline:"
        ];
    }
    return [
        "Thesis:",
        "Execution quality:",
        "Lesson:"
    ];
}
/**
 * OperatorJournal — persisted free-text trade notes (PATCH action NOTES).
 * Draft buffer with dirty tracking, ⌘/Ctrl+Enter save, char budget,
 * accent focus ring + "UPDATED x AGO" stamp. Available for open AND
 * resolved deployments (post-trade journaling).
 */ function OperatorJournal({ sid, signal, onSaved }) {
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    const now = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useNow"])(15_000);
    const serverNotes = signal.operatorNotes ?? "";
    const [draft, setDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(serverNotes);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [justSaved, setJustSaved] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const dirty = draft !== serverNotes;
    const overBudget = draft.length > NOTES_MAX;
    const areaRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    /* re-sync the draft when a different signal is opened */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setDraft(serverNotes);
        setJustSaved(false);
    }, [
        sid,
        serverNotes
    ]);
    const save = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (saving || overBudget || !dirty && !justSaved) return;
        setSaving(true);
        try {
            const res = await fetch(`/api/signals/${sid}`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    action: "NOTES",
                    notes: draft
                })
            });
            if (!res.ok) throw new Error(`notes ${res.status}`);
            setJustSaved(true);
            setTimeout(()=>setJustSaved(false), 1800);
            toast({
                title: draft.trim() ? "JOURNAL SAVED" : "JOURNAL CLEARED",
                description: `${signal.symbol} operator note ${draft.trim() ? "stored" : "wiped"} — synced to engine record.`
            });
            onSaved();
        } catch  {
            toast({
                title: "SAVE FAILED",
                description: `Could not persist the ${signal.symbol} note — retry in a moment.`,
                variant: "destructive"
            });
        } finally{
            setSaving(false);
        }
    }, [
        saving,
        overBudget,
        dirty,
        justSaved,
        draft,
        sid,
        signal.symbol,
        toast,
        onSaved
    ]);
    /* ⌘/Ctrl+Enter saves from anywhere inside the textarea */ const onKeyDown = (e)=>{
        if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
            e.preventDefault();
            save();
        }
    };
    const updatedAgo = signal.notesUpdatedAt && now !== 0 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["timeAgo"])(signal.notesUpdatedAt, now).toUpperCase() : null;
    /* tap-to-seed a prompt scaffold at the end of the draft */ const appendPrompt = (p)=>{
        setDraft((d)=>{
            const base = d.length ? d.endsWith("\n") ? d : `${d}\n` : "";
            return `${base}${p} `.slice(0, NOTES_MAX + 200);
        });
        requestAnimationFrame(()=>{
            const el = areaRef.current;
            if (el) {
                el.focus();
                el.setSelectionRange(el.value.length, el.value.length);
            }
        });
    };
    const prompts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>journalPrompts(signal.strategy), [
        signal.strategy
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-lg border border-[rgba(69,240,223,0.16)] bg-[rgba(69,240,223,0.03)] p-3.5 transition-colors focus-within:border-[rgba(69,240,223,0.35)]",
        "aria-label": "Operator journal",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__["NotebookPen"], {
                        className: "h-4 w-4 text-cyan-neon",
                        "aria-hidden": true
                    }, void 0, false, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 195,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-terminal text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-neon",
                        children: "OPERATOR JOURNAL"
                    }, void 0, false, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 196,
                        columnNumber: 9
                    }, this),
                    updatedAgo && !dirty && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "label-tech ml-auto text-ink-3",
                        children: [
                            "UPDATED ",
                            updatedAgo,
                            " AGO"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 200,
                        columnNumber: 11
                    }, this),
                    dirty && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-auto inline-flex items-center gap-1.5 font-terminal text-[9px] font-bold tracking-[0.18em] text-amber-neon",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "h-1.5 w-1.5 rounded-full bg-amber-neon anim-pulse-dot",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 204,
                                columnNumber: 13
                            }, this),
                            "UNSAVED"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 203,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 194,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                ref: areaRef,
                value: draft,
                onChange: (e)=>setDraft(e.target.value.slice(0, NOTES_MAX + 200)),
                onKeyDown: onKeyDown,
                rows: 3,
                maxLength: NOTES_MAX + 200,
                "aria-label": `Journal notes for ${signal.symbol} ${signal.direction}`,
                placeholder: serverNotes ? "" : "Log your read here — thesis, execution quality, emotions, lessons… (⌘↵ to save)",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("mt-2.5 w-full resize-y rounded-md border border-white/8 bg-[rgba(5,8,10,0.55)] px-3 py-2.5", "font-terminal text-xs leading-relaxed text-ink placeholder:text-ink-3/70", "outline-none transition-colors", "focus:border-[rgba(69,240,223,0.4)] focus:shadow-[0_0_0_1px_rgba(69,240,223,0.25),0_0_18px_-6px_rgba(69,240,223,0.5)]", overBudget && "border-[rgba(255,77,94,0.5)]")
            }, void 0, false, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 210,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 flex flex-wrap items-center gap-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "label-tech text-ink-3",
                        children: "PROMPTS"
                    }, void 0, false, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 234,
                        columnNumber: 9
                    }, this),
                    prompts.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            tabIndex: overBudget ? -1 : 0,
                            disabled: overBudget,
                            onClick: ()=>appendPrompt(p),
                            title: `Append “${p}” to the note`,
                            className: "inline-flex max-w-full items-center gap-1 rounded-md border border-[rgba(69,240,223,0.2)] bg-[rgba(69,240,223,0.05)] px-2 py-1 font-terminal text-[9px] font-semibold tracking-[0.1em] text-cyan-neon/90 transition-all hover:border-[rgba(69,240,223,0.45)] hover:bg-[rgba(69,240,223,0.12)] hover:text-cyan-neon focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[rgba(69,240,223,0.6)] disabled:cursor-not-allowed disabled:opacity-40",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                    size: 9,
                                    strokeWidth: 2.5,
                                    "aria-hidden": true,
                                    className: "shrink-0"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 245,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "truncate uppercase",
                                    children: p.replace(/:$/, "")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 246,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, p, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 236,
                            columnNumber: 11
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 233,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 flex items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("font-terminal text-[9px] tabular-nums tracking-[0.14em]", overBudget ? "text-danger-neon" : draft.length > NOTES_MAX * 0.85 ? "text-amber-neon" : "text-ink-3"),
                        "aria-live": "polite",
                        children: [
                            draft.length,
                            "/",
                            NOTES_MAX,
                            overBudget ? " — TRIM TO SAVE" : ""
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 252,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            dirty && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setDraft(serverNotes),
                                className: "rounded-md border border-white/10 px-2.5 py-1.5 font-terminal text-[10px] font-semibold tracking-[0.14em] text-ink-3 transition-colors hover:border-white/20 hover:text-ink-2",
                                children: "DISCARD"
                            }, void 0, false, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 264,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: save,
                                disabled: saving || overBudget || !dirty && !justSaved,
                                "aria-label": draft.trim() ? "Save journal note" : "Clear journal note",
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 font-terminal text-[10px] font-bold uppercase tracking-[0.16em] transition-all", "disabled:cursor-not-allowed disabled:opacity-45", justSaved ? "border-[rgb(var(--neon-rgb)/0.5)] bg-[rgb(var(--neon-rgb)/0.1)] text-neon" : "border-[rgba(69,240,223,0.35)] bg-[rgba(69,240,223,0.07)] text-cyan-neon hover:bg-[rgba(69,240,223,0.15)] hover:shadow-[0_0_14px_-4px_rgba(69,240,223,0.8)]"),
                                children: [
                                    saving ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                        className: "h-3.5 w-3.5 animate-spin",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 286,
                                        columnNumber: 15
                                    }, this) : justSaved ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                        className: "h-3.5 w-3.5",
                                        strokeWidth: 2.5,
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 288,
                                        columnNumber: 15
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__["Save"], {
                                        className: "h-3.5 w-3.5",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 290,
                                        columnNumber: 15
                                    }, this),
                                    justSaved ? "SAVED" : draft.trim() ? "SAVE NOTE" : "CLEAR"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 272,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 262,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 251,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
        lineNumber: 190,
        columnNumber: 5
    }, this);
}
/* ── Operator tags ────────────────────────────────────── */ const TAGS_MAX = 8;
const TAG_LEN_MAX = 28;
/** Client mirror of the server tag normalizer — uppercase kebab tokens. */ function normalizeTagToken(raw) {
    return raw.trim().replace(/^#+/, "").toUpperCase().replace(/\s+/g, "-").replace(/[^A-Z0-9-]/g, "").replace(/-{2,}/g, "-").replace(/^-+|-+$/g, "").slice(0, TAG_LEN_MAX);
}
/**
 * TagsEditor — operator tag curation (PATCH action TAGS). Chip ✕ remove,
 * input+Enter add with live normalization preview, popular-tag suggestions
 * harvested from the live signal pool, cap 8 with budget counter, ⌘↵ save.
 * Persists to the engine record → drives card chips, search and CSV exports.
 */ function TagsEditor({ sid, signal, onSaved }) {
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    const { data: pulse } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePulse"])(5000);
    const serverTags = signal.tags ?? [];
    const [draft, setDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(serverTags);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [justSaved, setJustSaved] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const dirty = draft.join(",") !== serverTags.join(",");
    const full = draft.length >= TAGS_MAX;
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    /* re-sync when a different signal is opened */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setDraft(signal.tags ?? []);
        setInput("");
        setJustSaved(false);
    }, [
        sid
    ]);
    /* popular tag pool from live signals (freq-ordered, excludes current draft) */ const suggestions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const counts = new Map();
        for (const s of pulse?.signals ?? []){
            for (const t of s.tags ?? [])counts.set(t, (counts.get(t) ?? 0) + 1);
        }
        return [
            ...counts.entries()
        ].sort((a, b)=>b[1] - a[1]).map(([t])=>t).filter((t)=>!draft.includes(t)).slice(0, 6);
    }, [
        pulse,
        draft
    ]);
    const addToken = (raw)=>{
        const token = normalizeTagToken(raw);
        if (!token || full) return;
        if (!draft.includes(token)) setDraft((d)=>[
                ...d,
                token
            ].slice(0, TAGS_MAX));
        setInput("");
    };
    const save = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (saving || !dirty) return;
        setSaving(true);
        try {
            const res = await fetch(`/api/signals/${sid}`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    action: "TAGS",
                    tags: draft
                })
            });
            if (!res.ok) throw new Error(`tags ${res.status}`);
            setJustSaved(true);
            setTimeout(()=>setJustSaved(false), 1800);
            toast({
                title: "TAGS UPDATED",
                description: `${signal.symbol} now carries ${draft.length} tag${draft.length === 1 ? "" : "s"} — search + CSV synced.`
            });
            onSaved();
        } catch  {
            toast({
                title: "TAG SAVE FAILED",
                description: `Could not persist ${signal.symbol} tags — retry in a moment.`,
                variant: "destructive"
            });
        } finally{
            setSaving(false);
        }
    }, [
        saving,
        dirty,
        draft,
        sid,
        signal.symbol,
        toast,
        onSaved
    ]);
    const onKeyDown = (e)=>{
        if (e.key === "Enter") {
            e.preventDefault();
            addToken(input);
        } else if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
            e.preventDefault();
            save();
        } else if (e.key === "Backspace" && !input && draft.length) {
            setDraft((d)=>d.slice(0, -1));
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-lg border border-[rgba(69,240,223,0.16)] bg-[rgba(69,240,223,0.03)] p-3.5 transition-colors focus-within:border-[rgba(69,240,223,0.35)]",
        "aria-label": "Signal tags editor",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                        className: "h-4 w-4 text-cyan-neon",
                        "aria-hidden": true
                    }, void 0, false, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 408,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-terminal text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-neon",
                        children: "OPERATOR TAGS"
                    }, void 0, false, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 409,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("ml-auto font-terminal text-[9px] tabular-nums tracking-[0.14em]", full ? "text-amber-neon" : "text-ink-3"),
                        "aria-live": "polite",
                        children: [
                            draft.length,
                            "/",
                            TAGS_MAX
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 412,
                        columnNumber: 9
                    }, this),
                    dirty && !justSaved && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "inline-flex items-center gap-1.5 font-terminal text-[9px] font-bold tracking-[0.18em] text-amber-neon",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "h-1.5 w-1.5 rounded-full bg-amber-neon anim-pulse-dot",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 423,
                                columnNumber: 13
                            }, this),
                            "UNSAVED"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 422,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 407,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2.5 flex min-h-[42px] w-full flex-wrap items-center gap-1.5 rounded-md border border-white/8 bg-[rgba(5,8,10,0.55)] px-2.5 py-2 transition-colors focus-within:border-[rgba(69,240,223,0.4)] focus-within:shadow-[0_0_0_1px_rgba(69,240,223,0.25),0_0_18px_-6px_rgba(69,240,223,0.5)]",
                onClick: ()=>inputRef.current?.focus(),
                children: [
                    draft.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "group inline-flex items-center gap-1 rounded border border-[rgba(69,240,223,0.3)] bg-[rgba(69,240,223,0.07)] py-0.5 pl-2 pr-1 font-terminal text-[10px] font-bold uppercase tracking-[0.1em] text-cyan-neon",
                            children: [
                                "#",
                                t,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>setDraft((d)=>d.filter((x)=>x !== t)),
                                    "aria-label": `Remove tag ${t}`,
                                    className: "flex h-4 w-4 items-center justify-center rounded-sm text-cyan-neon/60 transition-colors hover:bg-white/10 hover:text-danger-neon focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[rgba(69,240,223,0.6)]",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                        size: 10,
                                        strokeWidth: 3,
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 446,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 440,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, t, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 435,
                            columnNumber: 11
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative flex min-w-[120px] flex-1 items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Hash$3e$__["Hash"], {
                                className: "pointer-events-none absolute left-1 h-3 w-3 text-ink-3",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 451,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                ref: inputRef,
                                value: input,
                                onChange: (e)=>setInput(e.target.value.slice(0, TAG_LEN_MAX + 8)),
                                onKeyDown: onKeyDown,
                                disabled: full,
                                maxLength: TAG_LEN_MAX + 8,
                                "aria-label": "Add a tag",
                                placeholder: full ? "TAG LIMIT REACHED" : draft.length ? "ADD TAG…" : "ADD FIRST TAG… (↵)",
                                className: "w-full bg-transparent pl-4.5 font-terminal text-xs uppercase text-ink outline-none placeholder:text-ink-3/70 disabled:cursor-not-allowed"
                            }, void 0, false, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 452,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 450,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 430,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 flex flex-wrap items-center gap-1.5",
                children: [
                    suggestions.length > 0 && !full && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech inline-flex items-center gap-1 text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Hash$3e$__["Hash"], {
                                        size: 9,
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 471,
                                        columnNumber: 15
                                    }, this),
                                    " POPULAR"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 470,
                                columnNumber: 13
                            }, this),
                            suggestions.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>addToken(t),
                                    "aria-label": `Add tag ${t}`,
                                    className: "glass-soft inline-flex items-center gap-0.5 rounded px-2 py-1 font-terminal text-[9px] font-bold uppercase tracking-[0.1em] text-ink-2 transition-all hover:border-[rgba(69,240,223,0.4)] hover:text-cyan-neon hover:shadow-[0_0_10px_-2px_rgba(69,240,223,0.5)] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[rgba(69,240,223,0.6)]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                            size: 9,
                                            "aria-hidden": true
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 481,
                                            columnNumber: 17
                                        }, this),
                                        "#",
                                        t
                                    ]
                                }, t, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 474,
                                    columnNumber: 15
                                }, this))
                        ]
                    }, void 0, true),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "ml-auto flex items-center gap-2",
                        children: [
                            dirty && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setDraft(serverTags);
                                    setInput("");
                                },
                                className: "rounded-md border border-white/10 px-2.5 py-1.5 font-terminal text-[10px] font-semibold tracking-[0.14em] text-ink-3 transition-colors hover:border-white/20 hover:text-ink-2",
                                children: "DISCARD"
                            }, void 0, false, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 488,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: save,
                                disabled: saving || !dirty,
                                "aria-label": "Save signal tags",
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 font-terminal text-[10px] font-bold uppercase tracking-[0.16em] transition-all", "disabled:cursor-not-allowed disabled:opacity-45", justSaved ? "border-[rgb(var(--neon-rgb)/0.5)] bg-[rgb(var(--neon-rgb)/0.1)] text-neon" : "border-[rgba(69,240,223,0.35)] bg-[rgba(69,240,223,0.07)] text-cyan-neon hover:bg-[rgba(69,240,223,0.15)] hover:shadow-[0_0_14px_-4px_rgba(69,240,223,0.8)]"),
                                children: [
                                    saving ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                        className: "h-3.5 w-3.5 animate-spin",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 513,
                                        columnNumber: 15
                                    }, this) : justSaved ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                        className: "h-3.5 w-3.5",
                                        strokeWidth: 2.5,
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 515,
                                        columnNumber: 15
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__["Save"], {
                                        className: "h-3.5 w-3.5",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 517,
                                        columnNumber: 15
                                    }, this),
                                    justSaved ? "SAVED" : "SAVE TAGS"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                lineNumber: 499,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 486,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 467,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
        lineNumber: 403,
        columnNumber: 5
    }, this);
}
function SignalDetailDialog({ signal, open, onOpenChange }) {
    const qc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    const setSpotlightSymbol = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useUi"])((s)=>s.setSpotlightSymbol);
    const { data: pulse } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePulse"])(5000);
    const now = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useNow"])(1000);
    const [copied, setCopied] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [shared, setShared] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [exportingPng, setExportingPng] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const captureRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    /* ── PNG snapshot of the whole detail card ────────────────
     the scroll body is temporarily expanded (max-h/overflow released)
     so the capture spans the FULL card, not just the visible viewport */ async function handleExportPng() {
        const node = captureRef.current;
        if (!node || exportingPng) return;
        setExportingPng(true);
        const prevMax = node.style.maxHeight;
        const prevOv = node.style.overflowY;
        node.style.maxHeight = "none";
        node.style.overflowY = "visible";
        try {
            if (document.fonts?.ready) await document.fonts.ready;
            const dataUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html$2d$to$2d$image$2f$es$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toPng"])(node, {
                pixelRatio: 2,
                backgroundColor: "#070b0e",
                style: {
                    borderRadius: "12px"
                },
                filter: (n)=>!(n instanceof HTMLElement && (n.dataset?.exportIgnore === "true" || n.dataset?.slot === "dialog-close"))
            });
            const d = new Date();
            const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}-${String(d.getHours()).padStart(2, "0")}${String(d.getMinutes()).padStart(2, "0")}`;
            const a = document.createElement("a");
            a.download = `flowradar-signal-${(sig?.symbol ?? "detail").toLowerCase()}-${stamp}.png`;
            a.href = dataUrl;
            a.click();
            toast({
                title: "SIGNAL SNAPSHOT SAVED",
                description: `${sig?.symbol ?? "Signal"} detail card exported as a PNG brief.`
            });
        } catch  {
            toast({
                title: "EXPORT FAILED",
                description: "Could not rasterize the detail card — try again.",
                variant: "destructive"
            });
        } finally{
            node.style.maxHeight = prevMax;
            node.style.overflowY = prevOv;
            setExportingPng(false);
        }
    }
    /* copy a shareable plaintext brief (also available on the card footer) */ async function handleCopy() {
        if (!sig) return;
        try {
            await navigator.clipboard.writeText((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signalBrief"])(sig, livePrice));
            setCopied(true);
            setTimeout(()=>setCopied(false), 1600);
            toast({
                title: "SIGNAL COPIED",
                description: `${sig.symbol} ${sig.direction} brief on the clipboard — paste anywhere.`
            });
        } catch  {
            toast({
                title: "COPY BLOCKED",
                description: "Clipboard access denied by the browser.",
                variant: "destructive"
            });
        }
    }
    /* copy a deep-link URL that reopens this exact deployment (#signal=<id>) */ async function handleShare() {
        if (!sig) return;
        const url = `${window.location.origin}${window.location.pathname}#signal=${sig.id}`;
        try {
            await navigator.clipboard.writeText(url);
            setShared(true);
            setTimeout(()=>setShared(false), 1600);
            toast({
                title: "SHARE LINK COPIED",
                description: `${sig.symbol} deep-link on the clipboard — pasting it reopens this card.`
            });
        } catch  {
            toast({
                title: "COPY BLOCKED",
                description: "Clipboard access denied by the browser.",
                variant: "destructive"
            });
        }
    }
    const sid = signal?.id ?? null;
    /* ── fetch full detail (signal + timeline) when open ───── */ const { data: detail, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "signal-detail",
            sid
        ],
        queryFn: async ()=>{
            if (!sid) throw new Error("no signal id");
            const res = await fetch(`/api/signals/${sid}`, {
                cache: "no-store"
            });
            if (!res.ok) throw new Error(`detail ${res.status}`);
            return await res.json();
        },
        enabled: open && !!sid
    });
    const sig = detail?.signal ?? signal;
    const timeline = detail?.timeline ?? [];
    /* live price from pulse market map */ const livePrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>pulse?.market.find((m)=>m.symbol === sig?.symbol)?.price, [
        pulse,
        sig?.symbol
    ]);
    /* ── AI SIGNAL BRIEF (R17) — serial-grounded per-card scan ── */ const signalAutoScanSerial = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useUi"])((s)=>s.signalAutoScanSerial);
    const setSignalAutoScanSerial = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useUi"])((s)=>s.setSignalAutoScanSerial);
    const [brief, setBrief] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [briefLoading, setBriefLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const scannedSerialRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const runBrief = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (serial)=>{
        setBriefLoading(true);
        setBrief(null);
        try {
            const res = await fetch("/api/ai/signal-scan", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    serial
                })
            });
            if (!res.ok) throw new Error(`scan ${res.status}`);
            setBrief(await res.json());
        } catch  {
            toast({
                title: "AI SCAN FAILED",
                description: "Could not reach the scan core — retry in a moment.",
                variant: "destructive"
            });
        } finally{
            setBriefLoading(false);
        }
    }, [
        toast
    ]);
    /* auto-run when opened via a card's AI SCAN button */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!open || !signalAutoScanSerial) return;
        if (scannedSerialRef.current === signalAutoScanSerial) {
            setSignalAutoScanSerial(null);
            return;
        }
        scannedSerialRef.current = signalAutoScanSerial;
        void runBrief(signalAutoScanSerial);
        setSignalAutoScanSerial(null);
    }, [
        open,
        signalAutoScanSerial,
        runBrief,
        setSignalAutoScanSerial
    ]);
    /* ── price history for the TP/SL overlay chart ─────────── */ const { data: historyData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "price-history",
            sig?.symbol
        ],
        queryFn: async ()=>{
            const res = await fetch(`/api/market/history?symbol=${sig?.symbol}&hours=24`, {
                cache: "no-store"
            });
            if (!res.ok) throw new Error(`history ${res.status}`);
            return await res.json();
        },
        enabled: open && !!sig?.symbol,
        staleTime: 60_000,
        refetchInterval: 60_000
    });
    /* ── v6.0 TOTAL AUTONOMY: manual close removed ───────────
     Exits are engine-managed (TP1/TP2/TP3 ladder, stop, TTL). No operator
     lifecycle control — the AI SUPERVISOR enforces the no-manual mandate. */ if (!sig) return null;
    const long = sig.direction === "LONG";
    const cur = livePrice ?? sig.entryPrice;
    const isOpen = !sig.closedAt && OPEN_STATUSES.has(sig.status);
    const statusMeta = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["STATUS_META"][sig.status] ?? {
        label: sig.status,
        tone: "muted"
    };
    const statusBadgeTone = TONE_TO_BADGE[statusMeta.tone] ?? "muted";
    const rank = STATUS_RANK[sig.status] ?? 0;
    const crossTp = (level)=>long ? cur >= level : cur <= level;
    const tpHit = (n, level)=>rank >= n || isOpen && crossTp(level);
    const slStopped = sig.status === "SL" || isOpen && (long ? cur <= sig.stopLoss : cur >= sig.stopLoss);
    const ttlTotalMs = Math.max(1, sig.ttlMinutes * 60_000);
    const remaining = now === 0 ? ttlTotalMs : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ttlRemainingMs"])(sig.expiresAt, now);
    const ttlProgress = Math.max(0, Math.min(1, remaining / ttlTotalMs));
    const ttlCd = now === 0 ? "--:--:--" : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtCountdown"])(sig.expiresAt, now);
    /* signed est. PnL% at a level (direction-adjusted distance × leverage) */ const estPnl = (level)=>{
        const raw = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["distPct"])(sig.entryPrice, level);
        return (long ? raw : -raw) * sig.leverage;
    };
    const expiresClock = now === 0 ? "--:--" : new Date(sig.expiresAt).toLocaleTimeString("en-GB", {
        hour: "2-digit",
        minute: "2-digit"
    });
    const createdLabel = now === 0 ? "--" : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["timeAgo"])(sig.createdAt, now);
    const keyValues = [
        {
            label: "SERIAL",
            value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-violet-neon",
                children: [
                    "NX-",
                    String(sig.serial ?? 0).padStart(4, "0")
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 742,
                columnNumber: 31
            }, this)
        },
        {
            label: "ENTRY PRICE",
            value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-ink",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtPrice"])(sig.entryPrice)
            }, void 0, false, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 743,
                columnNumber: 36
            }, this)
        },
        {
            label: "ENTRY ZONE",
            value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-ink-2",
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtPrice"])(sig.entryZoneLow),
                    "–",
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtPrice"])(sig.entryZoneHigh)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 747,
                columnNumber: 9
            }, this)
        },
        {
            label: "CURRENT PRICE",
            value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex items-center gap-1.5 text-neon",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                        lineNumber: 756,
                        columnNumber: 11
                    }, this),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtPrice"])(cur)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 755,
                columnNumber: 9
            }, this)
        },
        // v13.3 live-execution truth (NX-3217 forensics): when the bridge intent
        // exists, show the exchange-side numbers; ledger anchor stays labeled.
        ...sig.liveIntent ? [
            {
                label: "LEVERAGE",
                value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-amber-neon",
                    children: [
                        "×",
                        sig.liveIntent.leverage,
                        " LIVE",
                        sig.liveIntent.leverage !== sig.leverage ? ` (ledger ×${sig.leverage})` : ""
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 765,
                    columnNumber: 39
                }, this)
            },
            {
                label: "MARGIN (LIVE)",
                value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-neon",
                    title: "fixed-margin mandate — bridge execution truth",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtUsd"])(sig.liveIntent.marginUsdt, false)
                }, void 0, false, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 766,
                    columnNumber: 44
                }, this)
            },
            {
                label: "MARGIN (LEDGER)",
                value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-ink-2",
                    title: "FLAT-10 sizing anchor stored on the signal row",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtUsd"])(sig.marginUsd, false)
                }, void 0, false, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 767,
                    columnNumber: 46
                }, this)
            },
            {
                label: "POSITION SIZE (LIVE)",
                value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-ink",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtUsd"])(sig.liveIntent.notionalUsdt)
                }, void 0, false, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 768,
                    columnNumber: 51
                }, this)
            }
        ] : [
            {
                label: "LEVERAGE",
                value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-amber-neon",
                    children: [
                        "×",
                        sig.leverage
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 771,
                    columnNumber: 39
                }, this)
            },
            {
                label: "MARGIN",
                value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-ink-2",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtUsd"])(sig.marginUsd, false)
                }, void 0, false, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 772,
                    columnNumber: 37
                }, this)
            },
            {
                label: "POSITION SIZE",
                value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-ink",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtUsd"])(sig.marginUsd * sig.leverage)
                }, void 0, false, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 773,
                    columnNumber: 44
                }, this)
            }
        ],
        {
            label: "RISK : REWARD",
            value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-cyan-neon",
                children: [
                    "1 : ",
                    sig.riskReward.toFixed(1)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 775,
                columnNumber: 38
            }, this)
        },
        {
            label: "FEES (COMM + SWAP)",
            value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-ink-2",
                title: "taker 0.05%×2 round-trip + funding 0.01%/8h pro-rated — realized when resolved",
                children: [
                    "$",
                    (sig.feeUsd + sig.swapUsd).toFixed(3)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 779,
                columnNumber: 9
            }, this)
        },
        {
            label: "CREATED",
            value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-ink-2",
                children: createdLabel
            }, void 0, false, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 784,
                columnNumber: 32
            }, this)
        },
        {
            label: "EXPIRES",
            value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-amber-neon",
                children: expiresClock
            }, void 0, false, {
                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                lineNumber: 785,
                columnNumber: 32
            }, this)
        }
    ];
    const levels = [
        {
            key: "tp1",
            label: "TP1",
            price: sig.tp1,
            hit: tpHit(1, sig.tp1),
            hitLabel: "HIT"
        },
        {
            key: "tp2",
            label: "TP2",
            price: sig.tp2,
            hit: tpHit(2, sig.tp2),
            hitLabel: "HIT"
        },
        {
            key: "tp3",
            label: "TP3",
            price: sig.tp3,
            hit: tpHit(3, sig.tp3),
            hitLabel: "HIT"
        },
        {
            key: "sl",
            label: "STOP-LOSS",
            price: sig.stopLoss,
            hit: slStopped,
            danger: true,
            hitLabel: "STOPPED"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Dialog"], {
        open: open,
        onOpenChange: onOpenChange,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "max-h-[92vh] gap-0 overflow-hidden rounded-xl border-[rgb(var(--neon-rgb)/0.18)] bg-[rgba(7,11,14,0.96)] p-0 backdrop-blur-2xl sm:max-w-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogDescription"], {
                    className: "sr-only",
                    children: [
                        "Full deployment detail for ",
                        sig.symbol,
                        " ",
                        sig.direction,
                        " signal: levels, TTL, AI analysis and event timeline."
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 814,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    ref: captureRef,
                    className: "max-h-[70vh] overflow-y-auto p-5 sm:p-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap items-center gap-2 pr-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                    asChild: true,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setSpotlightSymbol(sig.symbol),
                                        "aria-label": `Open ${sig.symbol} market spotlight`,
                                        className: "group inline-flex items-center gap-1.5 rounded font-terminal text-xl font-bold uppercase tracking-[0.12em] text-ink outline-none transition-colors hover:text-neon focus-visible:ring-1 focus-visible:ring-[rgb(var(--neon-rgb)/0.6)] focus-visible:text-neon",
                                        children: [
                                            sig.symbol,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$telescope$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Telescope$3e$__["Telescope"], {
                                                size: 15,
                                                "aria-hidden": true,
                                                className: "text-ink-3 transition-all duration-300 group-hover:-translate-y-px group-hover:text-neon group-hover:drop-shadow-[0_0_6px_rgb(var(--neon-rgb)/0.8)]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                lineNumber: 829,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                        lineNumber: 822,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 821,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                    tone: long ? "neon" : "magenta",
                                    glow: true,
                                    children: sig.direction
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 836,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                    tone: statusBadgeTone,
                                    glow: statusMeta.tone === "live",
                                    children: statusMeta.label
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 839,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                    tone: "violet",
                                    children: sig.strategy
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 842,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                    tone: "cyan",
                                    children: sig.timeframe
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 843,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 820,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-1.5 flex items-center gap-1.5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cpu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cpu$3e$__["Cpu"], {
                                    className: "h-3 w-3 text-ink-3"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 846,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "label-tech",
                                    children: [
                                        "ENGINE // ",
                                        sig.engine
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 847,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "label-tech ml-auto hidden items-center gap-1 text-ink-3 sm:flex",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$telescope$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Telescope$3e$__["Telescope"], {
                                            size: 9,
                                            "aria-hidden": true
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 849,
                                            columnNumber: 15
                                        }, this),
                                        " TAP SYMBOL FOR SPOTLIGHT"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 848,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 845,
                            columnNumber: 11
                        }, this),
                        isLoading ? /* ── Loading skeleton ── */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-5 space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
                                    children: Array.from({
                                        length: 6
                                    }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Skeleton"], {
                                            className: "h-14 rounded-lg bg-white/[0.05]"
                                        }, i, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 858,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 856,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Skeleton"], {
                                    className: "h-36 rounded-lg bg-white/[0.05]"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 861,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Skeleton"], {
                                    className: "h-24 rounded-lg bg-white/[0.05]"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 862,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Skeleton"], {
                                    className: "h-40 rounded-lg bg-white/[0.05]"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 863,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 855,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-5 space-y-5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
                                    children: [
                                        keyValues.map((kv)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "glass-soft rounded-lg px-3 py-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "label-tech",
                                                        children: kv.label
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                        lineNumber: 871,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mt-1 font-terminal text-sm font-bold tabular-nums",
                                                        children: kv.value
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                        lineNumber: 872,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, kv.label, true, {
                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                lineNumber: 870,
                                                columnNumber: 19
                                            }, this)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "glass-soft col-span-2 flex items-center justify-between gap-3 rounded-lg px-3 py-2 sm:col-span-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "label-tech",
                                                            children: "TTL"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 878,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mt-1 font-terminal text-sm font-bold tabular-nums text-amber-neon",
                                                            children: [
                                                                sig.ttlMinutes,
                                                                "M · ",
                                                                isOpen ? ttlCd : "RESOLVED"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 879,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 877,
                                                    columnNumber: 19
                                                }, this),
                                                isOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CountdownRing"], {
                                                    size: 44,
                                                    progress: ttlProgress,
                                                    label: now === 0 ? "--:--" : ttlCd.slice(3),
                                                    sub: "TTL"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 884,
                                                    columnNumber: 21
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CountdownRing"], {
                                                    size: 44,
                                                    progress: rank >= 1 ? 1 : 0,
                                                    label: rank >= 1 ? sig.status : sig.status === "SL" ? "STOP" : sig.status === "EXPIRED" ? "0:00" : "END",
                                                    sub: rank >= 1 ? "HIT" : sig.status === "SL" ? "OUT" : sig.status === "EXPIRED" ? "TTL END" : "CLOSED",
                                                    tone: rank >= 1 ? "cyan" : sig.status === "SL" ? "danger" : sig.status === "EXPIRED" ? "amber" : "muted",
                                                    ariaLabel: `Deployment resolved — ${sig.status}`
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 886,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 876,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 868,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "label-tech mb-1.5 flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "// PRICE ACTION × LEVELS — 24H"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 901,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-cyan-neon/60",
                                                    children: sig.symbol
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 902,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 900,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "glass-soft rounded-lg p-2",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$LevelChart$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LevelChart"], {
                                                signal: sig,
                                                history: historyData?.series ?? [],
                                                livePrice: livePrice
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                lineNumber: 905,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 904,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 899,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "label-tech mb-1.5",
                                            children: "// LEVELS"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 911,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "glass-soft overflow-hidden rounded-lg",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid grid-cols-[4.5rem_1fr_4.25rem_5rem_2rem] items-center gap-2 border-b border-white/5 px-3 py-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "label-tech",
                                                            children: "LEVEL"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 914,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "label-tech text-right",
                                                            children: "PRICE"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 915,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "label-tech text-right",
                                                            children: "DIST"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 916,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "label-tech text-right",
                                                            children: "EST PNL"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 917,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {}, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 918,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 913,
                                                    columnNumber: 19
                                                }, this),
                                                levels.map((lv)=>{
                                                    const tone = lv.danger ? "danger" : "neon";
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("grid grid-cols-[4.5rem_1fr_4.25rem_5rem_2rem] items-center gap-2 border-b border-white/5 px-3 py-2 last:border-0", lv.hit && (lv.danger ? "bg-[rgba(255,77,94,0.06)]" : "bg-[rgb(var(--neon-rgb)/0.05)]")),
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("font-terminal text-[10px] font-bold uppercase tracking-[0.14em]", lv.hit ? lv.danger ? "text-danger-neon" : "text-neon" : "text-ink-2"),
                                                                children: lv.label
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                lineNumber: 930,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-right font-terminal text-xs font-bold tabular-nums text-ink",
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtPrice"])(lv.price)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                lineNumber: 938,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-right font-terminal text-[10px] tabular-nums text-ink-3",
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtPct"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["distPct"])(sig.entryPrice, lv.price))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                lineNumber: 941,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-right font-terminal text-[10px] font-bold tabular-nums", estPnl(lv.price) >= 0 ? "text-neon" : "text-danger-neon"),
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtPct"])(estPnl(lv.price))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                lineNumber: 944,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "flex items-center justify-center",
                                                                children: lv.hit ? lv.danger ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                    className: "h-3.5 w-3.5 text-danger-neon",
                                                                    strokeWidth: 3
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 955,
                                                                    columnNumber: 31
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                                    className: "h-3.5 w-3.5 text-neon",
                                                                    strokeWidth: 3
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 957,
                                                                    columnNumber: 31
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("h-1.5 w-1.5 rounded-full", lv.danger ? "bg-danger-neon/40" : "bg-neon/30")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 960,
                                                                    columnNumber: 29
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                lineNumber: 952,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "sr-only",
                                                                children: lv.hit ? lv.hitLabel : "pending"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                lineNumber: 964,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, lv.key, true, {
                                                        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                        lineNumber: 923,
                                                        columnNumber: 23
                                                    }, this);
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 912,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-1 font-terminal text-[9px] tracking-[0.1em] text-ink-3",
                                            children: [
                                                "EST PNL = DIRECTION-ADJUSTED DISTANCE × LEVERAGE · STOP RISK ≈ -",
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtUsd"])(sig.marginUsd * (Math.abs(sig.entryPrice - sig.stopLoss) / sig.entryPrice) * sig.leverage)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 969,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 910,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "rounded-lg border border-[rgba(69,240,223,0.25)] bg-[rgba(69,240,223,0.05)] p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-wrap items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                                                    className: "h-4 w-4 text-cyan-neon"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 979,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-terminal text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-neon",
                                                    children: [
                                                        "AI SIGNAL BRIEF — ",
                                                        `NX-${String(sig.serial ?? 0).padStart(4, "0")}`
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 980,
                                                    columnNumber: 19
                                                }, this),
                                                brief && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                    tone: brief.brief.action === "HOLD" ? "cyan" : brief.brief.action === "CLOSE" ? "danger" : "amber",
                                                    className: "ml-auto",
                                                    children: [
                                                        brief.brief.action,
                                                        " · ",
                                                        Math.round(brief.brief.conviction),
                                                        "%"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 984,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: ()=>void runBrief(sig.serial ?? 0),
                                                    disabled: briefLoading || !sig.serial,
                                                    className: "flex min-h-9 items-center gap-1.5 rounded border border-[rgba(69,240,223,0.35)] px-2.5 font-terminal text-[10px] font-bold tracking-[0.14em] text-cyan-neon transition-colors hover:bg-[rgba(69,240,223,0.1)] disabled:opacity-40",
                                                    "aria-label": "Re-run AI scan of this card",
                                                    children: [
                                                        briefLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                            className: "size-3 animate-spin",
                                                            "aria-hidden": true
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 995,
                                                            columnNumber: 37
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                                                            className: "size-3",
                                                            "aria-hidden": true
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 995,
                                                            columnNumber: 95
                                                        }, this),
                                                        briefLoading ? "SCANNING…" : brief ? "RE-SCAN" : "SCAN NOW"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 988,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 978,
                                            columnNumber: 17
                                        }, this),
                                        briefLoading && !brief && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-3 font-terminal text-[11px] text-ink-3",
                                            children: "scanning THIS card — live NET PnL, factor votes at deploy, fresh flow re-measure…"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 999,
                                            columnNumber: 44
                                        }, this),
                                        brief && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4",
                                                    children: [
                                                        {
                                                            label: "NET PNL",
                                                            value: `${brief.measured.netPnlPercent >= 0 ? "+" : ""}${brief.measured.netPnlPercent.toFixed(2)}%`,
                                                            cls: brief.measured.netPnlPercent >= 0 ? "text-neon" : "text-danger-neon"
                                                        },
                                                        {
                                                            label: "FEES NOW",
                                                            value: `$${brief.measured.feesUsd.toFixed(3)}`,
                                                            cls: "text-ink-2"
                                                        },
                                                        {
                                                            label: "FLOW NOW",
                                                            value: `${brief.flowNow.verdict} ${brief.flowNow.score >= 0 ? "+" : ""}${brief.flowNow.score}`,
                                                            cls: brief.flowNow.score >= 8 ? "text-neon" : brief.flowNow.score <= -8 ? "text-danger-neon" : "text-amber-neon"
                                                        },
                                                        {
                                                            label: "TTL LEFT",
                                                            value: `${brief.measured.ttlMinutesRemaining}M`,
                                                            cls: "text-amber-neon"
                                                        }
                                                    ].map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "rounded border border-white/8 bg-white/[0.02] px-2.5 py-1.5",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "label-tech text-[9px]",
                                                                    children: c.label
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 1010,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("mt-0.5 font-terminal text-xs font-bold tabular-nums", c.cls),
                                                                    children: c.value
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 1011,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, c.label, true, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1009,
                                                            columnNumber: 25
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1002,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "mt-3 whitespace-pre-wrap text-sm leading-relaxed text-ink-2",
                                                    children: brief.brief.summary
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1015,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-2 flex items-start gap-2 rounded border border-[rgba(255,179,71,0.3)] bg-[rgba(255,179,71,0.06)] px-2.5 py-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ghost$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Ghost$3e$__["Ghost"], {
                                                            className: "mt-0.5 size-3.5 shrink-0 text-amber-neon",
                                                            "aria-hidden": true
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1017,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs leading-relaxed text-amber-neon/90",
                                                            children: brief.brief.risk
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1018,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1016,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "mt-2 font-terminal text-[9px] tracking-[0.12em] text-ink-3",
                                                    children: [
                                                        brief.brief.label === "HEURISTIC" ? "HEURISTIC FALLBACK — MODEL UNAVAILABLE · " : "MODEL GROUNDED · ",
                                                        "SCANNED ",
                                                        new Date(brief.scannedAt).toISOString().slice(11, 19),
                                                        "Z · EVERY NUMBER MEASURED"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1020,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 977,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "rounded-lg border border-[rgba(178,107,255,0.25)] bg-[rgba(178,107,255,0.06)] p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Brain$3e$__["Brain"], {
                                                    className: "h-4 w-4 text-violet-neon"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1031,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-terminal text-[10px] font-bold uppercase tracking-[0.22em] text-violet-neon",
                                                    children: "FLOWRADAR-NEO AI ANALYSIS"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1032,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1030,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-2 text-sm leading-relaxed text-ink-2",
                                            children: sig.analysis
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1036,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "label-tech mb-1",
                                                    children: "CONFIDENCE"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1038,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConfidenceBar"], {
                                                    value: sig.confidence
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1039,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1037,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1029,
                                    columnNumber: 15
                                }, this),
                                sig.flow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "rounded-lg border border-[rgba(69,240,223,0.25)] bg-[rgba(69,240,223,0.04)] p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-wrap items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$waves$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Waves$3e$__["Waves"], {
                                                    className: "h-4 w-4 text-cyan-neon"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1047,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-terminal text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-neon",
                                                    children: "ORDER-FLOW CONFIRMATION"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1048,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                    tone: sig.flow.verdict === "CONFIRMS" ? "neon" : sig.flow.verdict === "CONFLICTS" ? "danger" : "amber",
                                                    className: "ml-auto",
                                                    children: [
                                                        sig.flow.verdict,
                                                        " ",
                                                        sig.flow.score >= 0 ? "+" : "",
                                                        sig.flow.score,
                                                        "/25"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1049,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1046,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4",
                                            children: [
                                                {
                                                    label: "OI Δ1H",
                                                    v: sig.flow.metrics.oiDelta1h,
                                                    fmt: (x)=>`${x >= 0 ? "+" : ""}${x.toFixed(2)}%`,
                                                    tip: "open-interest change over 1h at deploy"
                                                },
                                                {
                                                    label: "OI Δ10M",
                                                    v: sig.flow.metrics.oiDelta10m,
                                                    fmt: (x)=>`${x >= 0 ? "+" : ""}${x.toFixed(2)}%`,
                                                    tip: "open-interest change over 10m at deploy"
                                                },
                                                {
                                                    label: "CVD NET",
                                                    v: sig.flow.metrics.cvdNetPctOfVol,
                                                    fmt: (x)=>`${x >= 0 ? "+" : ""}${x.toFixed(2)}%`,
                                                    tip: "taker buy−sell net as % of taker volume"
                                                },
                                                {
                                                    label: "TAKER B/S",
                                                    v: sig.flow.metrics.takerRatio,
                                                    fmt: (x)=>x.toFixed(3),
                                                    tip: "last taker long/short ratio vs mean"
                                                },
                                                {
                                                    label: "CROWD L/S",
                                                    v: sig.flow.metrics.crowdLongShort,
                                                    fmt: (x)=>`${x.toFixed(2)}:1`,
                                                    tip: "global account long/short (retail crowd)"
                                                },
                                                {
                                                    label: "FUNDING /8H",
                                                    v: sig.flow.metrics.funding8h,
                                                    fmt: (x)=>`${x >= 0 ? "+" : ""}${x.toFixed(4)}%`,
                                                    tip: "predicted funding rate per 8h"
                                                },
                                                {
                                                    label: "OI NOTIONAL",
                                                    v: sig.flow.metrics.oiValueUsd,
                                                    fmt: (x)=>x >= 1e9 ? `$${(x / 1e9).toFixed(2)}B` : `$${(x / 1e6).toFixed(1)}M`,
                                                    tip: "open interest value in USD"
                                                },
                                                {
                                                    label: "FLOW WEIGHT",
                                                    v: sig.flow.oiWeight,
                                                    fmt: (x)=>`×${x.toFixed(2)}`,
                                                    tip: "OI-notional weighting applied to the flow score (v4.5)"
                                                }
                                            ].map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "rounded border border-white/8 bg-white/[0.02] px-2.5 py-1.5",
                                                    title: c.tip,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "label-tech text-[9px]",
                                                            children: c.label
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1065,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("mt-0.5 font-terminal text-xs font-bold tabular-nums", c.v === null || c.v === undefined ? "text-ink-3" : "text-ink"),
                                                            children: c.v === null || c.v === undefined ? "—" : c.fmt(c.v)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1066,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, c.label, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1064,
                                                    columnNumber: 23
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1053,
                                            columnNumber: 19
                                        }, this),
                                        sig.flow.reasons.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "mt-3 space-y-1",
                                            children: sig.flow.reasons.slice(0, 4).map((r, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "flex items-start gap-1.5 font-terminal text-[10px] leading-relaxed text-ink-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-cyan-neon",
                                                            children: "▸"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1074,
                                                            columnNumber: 27
                                                        }, this),
                                                        " ",
                                                        r
                                                    ]
                                                }, i, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1073,
                                                    columnNumber: 25
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1071,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-2 font-terminal text-[9px] tracking-[0.12em] text-ink-3",
                                            children: "MEASURED FROM BINANCE USDT-M FUTURES · SNAPSHOT AT DEPLOY · PRICE-MOVING FLOWS ONLY"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1079,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1045,
                                    columnNumber: 17
                                }, this),
                                sig.factors && sig.factors.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "rounded-lg border border-white/8 bg-white/[0.02] p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                                                    className: "h-4 w-4 text-violet-neon"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1087,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-terminal text-[10px] font-bold uppercase tracking-[0.22em] text-violet-neon",
                                                    children: "FACTOR VOTES AT DEPLOY"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1088,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                    tone: "muted",
                                                    className: "ml-auto",
                                                    children: [
                                                        sig.factors.length,
                                                        " FACTORS"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1089,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1086,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-3 space-y-1.5",
                                            children: sig.factors.map((f)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    title: f.detail,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "w-28 shrink-0 truncate font-terminal text-[10px] uppercase tracking-[0.1em] text-ink-2",
                                                            children: f.factor
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1094,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative h-1.5 min-w-0 flex-1 rounded-full bg-white/5",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "absolute left-1/2 top-0 h-full w-px bg-white/15",
                                                                    "aria-hidden": true
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 1096,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("absolute top-0 h-full rounded-full", f.vote >= 0 ? "bg-neon" : "bg-danger-neon"),
                                                                    style: {
                                                                        left: f.vote >= 0 ? "50%" : `${50 - Math.min(50, Math.abs(f.vote) / 25 * 50)}%`,
                                                                        width: `${Math.min(50, Math.abs(f.vote) / 25 * 50)}%`,
                                                                        boxShadow: "0 0 6px currentColor"
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 1097,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1095,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("w-12 shrink-0 text-right font-terminal text-[10px] font-bold tabular-nums", f.vote > 0 ? "text-neon" : f.vote < 0 ? "text-danger-neon" : "text-ink-3"),
                                                            children: [
                                                                f.vote > 0 ? "+" : "",
                                                                f.vote.toFixed(1)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1106,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, f.factor, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1093,
                                                    columnNumber: 23
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1091,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-2 font-terminal text-[9px] tracking-[0.12em] text-ink-3",
                                            children: "RAW VOTES PRESERVED FOR AUDIT · CALIBRATED WEIGHTS (v4.8) SCALE THESE AT SCAN TIME"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1112,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1085,
                                    columnNumber: 17
                                }, this),
                                sig.status === "EXPIRED" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "flex flex-wrap items-center gap-2 rounded-lg border border-[rgba(255,179,71,0.3)] bg-[rgba(255,179,71,0.05)] px-3.5 py-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ghost$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Ghost$3e$__["Ghost"], {
                                            className: "size-4 text-amber-neon",
                                            "aria-hidden": true
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1119,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "min-w-0 flex-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "label-tech",
                                                    children: "EXPIRED LIFECYCLE — 48H AFTERLIFE TRACKING"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1121,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "mt-1 font-terminal text-[10px] leading-relaxed text-ink-3",
                                                    children: [
                                                        "Position auto-closed at TTL mark (",
                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fmtPct"])(sig.pnlPercent),
                                                        " NET)",
                                                        (sig.ttlExtensions ?? 0) > 0 ? ` after ${sig.ttlExtensions} dynamic expiry-gate extension${sig.ttlExtensions === 1 ? "" : "s"} (TTL ${sig.ttlMinutes}m base)` : ` · TTL ${sig.ttlMinutes}m`,
                                                        ". Post-expiry follow-up: ",
                                                        sig.afterlife === "TRACKING" ? "still tracking — watching for TP/SL re-tests within 48h" : sig.afterlife === "FLAT" ? "48h window closed without a re-test" : (sig.afterlife ?? "TRACKING").replace("_", " ") + " confirmed",
                                                        ". Post-expiry best excursion ",
                                                        sig.maxPostPnlPercent >= 0 ? "+" : "",
                                                        sig.maxPostPnlPercent.toFixed(1),
                                                        "% levered — feeds TTL calibration."
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1122,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1120,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1118,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(TagsEditor, {
                                    sid: sig.id,
                                    signal: sig,
                                    onSaved: ()=>{
                                        void qc.invalidateQueries({
                                            queryKey: [
                                                "signal-detail",
                                                sid
                                            ]
                                        });
                                        void qc.invalidateQueries({
                                            queryKey: [
                                                "pulse"
                                            ]
                                        });
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1130,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(OperatorJournal, {
                                    sid: sig.id,
                                    signal: sig,
                                    onSaved: ()=>{
                                        void qc.invalidateQueries({
                                            queryKey: [
                                                "signal-detail",
                                                sid
                                            ]
                                        });
                                        void qc.invalidateQueries({
                                            queryKey: [
                                                "pulse"
                                            ]
                                        });
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1140,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "label-tech mb-2",
                                            children: "// EVENT TIMELINE"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1151,
                                            columnNumber: 17
                                        }, this),
                                        timeline.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "font-terminal text-xs text-ink-3",
                                            children: "NO EVENTS RECORDED"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1153,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                            className: "space-y-3 border-l border-[rgb(var(--neon-rgb)/0.14)] pl-4",
                                            children: timeline.map((e)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("absolute -left-[21px] top-1 h-2 w-2 rounded-full", eventDot(e))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1158,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex flex-wrap items-center gap-1.5",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                                    tone: eventTone(e),
                                                                    children: e.type
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 1160,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "font-terminal text-[10px] tabular-nums text-ink-3",
                                                                    children: new Date(e.createdAt).toLocaleTimeString("en-GB", {
                                                                        hour12: false
                                                                    })
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                                    lineNumber: 1161,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1159,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "mt-0.5 text-xs leading-relaxed text-ink-2",
                                                            children: e.message
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                            lineNumber: 1165,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, e.id, true, {
                                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                                    lineNumber: 1157,
                                                    columnNumber: 23
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                            lineNumber: 1155,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1150,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 866,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 818,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap items-center justify-end gap-2 border-t border-[rgb(var(--neon-rgb)/0.12)] bg-[rgba(5,8,10,0.6)] p-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                            type: "button",
                            variant: "outline",
                            onClick: handleShare,
                            "aria-label": "Copy share link for this signal",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("h-11 border-white/10 bg-transparent font-terminal text-[11px] font-semibold tracking-[0.16em] text-ink-2 transition-all hover:border-[rgba(178,107,255,0.45)] hover:bg-[rgba(178,107,255,0.08)] hover:text-violet-neon", shared && "border-[rgba(178,107,255,0.5)] text-violet-neon"),
                            children: [
                                shared ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                    className: "h-4 w-4",
                                    strokeWidth: 2.5
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1187,
                                    columnNumber: 23
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Link2$3e$__["Link2"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1187,
                                    columnNumber: 73
                                }, this),
                                shared ? "LINKED" : "SHARE"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 1177,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                            type: "button",
                            variant: "outline",
                            onClick: handleCopy,
                            "aria-label": "Copy signal brief to clipboard",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("h-11 border-white/10 bg-transparent font-terminal text-[11px] font-semibold tracking-[0.16em] text-ink-2 transition-all hover:border-[rgba(69,240,223,0.4)] hover:bg-[rgba(69,240,223,0.08)] hover:text-cyan-neon", copied && "border-[rgba(69,240,223,0.5)] text-cyan-neon"),
                            children: [
                                copied ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                    className: "h-4 w-4",
                                    strokeWidth: 2.5
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1200,
                                    columnNumber: 23
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$copy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Copy$3e$__["Copy"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1200,
                                    columnNumber: 73
                                }, this),
                                copied ? "COPIED" : "COPY BRIEF"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 1190,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                            type: "button",
                            variant: "outline",
                            onClick: handleExportPng,
                            disabled: exportingPng,
                            "aria-label": "Export signal detail card as PNG",
                            className: "h-11 border-white/10 bg-transparent font-terminal text-[11px] font-semibold tracking-[0.16em] text-ink-2 transition-all hover:border-[rgb(var(--neon-rgb)/0.4)] hover:bg-[rgb(var(--neon-rgb)/0.08)] hover:text-neon",
                            children: [
                                exportingPng ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                    className: "h-4 w-4 animate-spin"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1211,
                                    columnNumber: 29
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ImageDown$3e$__["ImageDown"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                                    lineNumber: 1211,
                                    columnNumber: 76
                                }, this),
                                exportingPng ? "CAPTURING…" : "PNG"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 1203,
                            columnNumber: 11
                        }, this),
                        isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "mr-auto font-terminal text-[10px] tracking-[0.16em] text-ink-3",
                            children: "EXITS ENGINE-MANAGED — TP LADDER · STOP · TTL (TOTAL AUTONOMY)"
                        }, void 0, false, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 1215,
                            columnNumber: 13
                        }, this),
                        !isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "mr-auto font-terminal text-[10px] tracking-[0.16em] text-ink-3",
                            children: "DEPLOYMENT RESOLVED — BRIEF STILL SHAREABLE"
                        }, void 0, false, {
                            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                            lineNumber: 1220,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
                    lineNumber: 1176,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
            lineNumber: 811,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/signals/SignalDetailDialog.tsx",
        lineNumber: 810,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/shared/SignalDetailHost.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SignalDetailHost",
    ()=>SignalDetailHost
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/usePulse.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$signals$2f$SignalDetailDialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/signals/SignalDetailDialog.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/ui.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function SignalDetailHost() {
    const openSignalId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useUi"])((s)=>s.openSignalId);
    const setOpenSignal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useUi"])((s)=>s.setOpenSignal);
    const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePulse"])(5000);
    /* ── hash → dialog (mount + hashchange) ── */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const consume = ()=>{
            const m = /^#signal=([A-Za-z0-9_-]+)$/.exec(window.location.hash);
            if (m?.[1]) __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useUi"].getState().setOpenSignal(m[1]);
        };
        consume();
        window.addEventListener("hashchange", consume);
        return ()=>window.removeEventListener("hashchange", consume);
    }, []);
    /* ── dialog close → strip the hash (replaceState, no scroll jump) ── */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (openSignalId === null && window.location.hash.startsWith("#signal=")) {
            history.replaceState(null, "", window.location.pathname + window.location.search);
        }
    }, [
        openSignalId
    ]);
    const signal = openSignalId ? (data?.signals ?? []).find((s)=>s.id === openSignalId) ?? null : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$signals$2f$SignalDetailDialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        signal: signal,
        open: openSignalId !== null,
        onOpenChange: (v)=>{
            if (!v) setOpenSignal(null);
        }
    }, void 0, false, {
        fileName: "[project]/src/components/shared/SignalDetailHost.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/providers.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Providers",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$fx$2f$SystemBridge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/fx/SystemBridge.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$SignalDetailHost$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/SignalDetailHost.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
function Providers({ children }) {
    const [client] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QueryClient"]({
            defaultOptions: {
                queries: {
                    // 2026-09-17 operator audit fix: was `false` — a tab backgrounded
                    // during the 06:26Z sandbox rollback kept serving the pre-rollback
                    // snapshot after refocusing (modules looked frozen / "not live").
                    // With `true` + staleTime 3s, focus re-pulls anything older than
                    // 3s, so returning to the tab always resyncs against the engine.
                    refetchOnWindowFocus: true,
                    staleTime: 3000,
                    // v10.1 stability pass: absorb transient blips instead of surfacing
                    // them — 2 retries with fast exponential backoff (0.5s → 4s cap).
                    retry: 2,
                    retryDelay: (attempt)=>Math.min(500 * 2 ** attempt, 4000)
                }
            }
        }));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: client,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SessionProvider"], {
            refetchOnWindowFocus: false,
            refetchInterval: 60_000,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$fx$2f$SystemBridge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemBridge"], {}, void 0, false, {
                    fileName: "[project]/src/components/providers.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this),
                children,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$SignalDetailHost$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SignalDetailHost"], {}, void 0, false, {
                    fileName: "[project]/src/components/providers.tsx",
                    lineNumber: 43,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/providers.tsx",
            lineNumber: 40,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/providers.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__536b1be2._.js.map