module.exports = [
"[project]/src/lib/telegram-bridge.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_b4d88fd2._.js",
  "server/chunks/[root-of-the-server]__b946f830._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/telegram-bridge.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/env-guard.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ca57ae5a._.js",
  "server/chunks/[root-of-the-server]__13003af5._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/env-guard.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/daily-scheduler.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__4dee1106._.js",
  "server/chunks/src_lib_daily-scheduler_ts_02cfbd1a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/daily-scheduler.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/volCause.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__79fbb3a2._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/volCause.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/futures-snapshot-settle.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__796c4db8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/futures-snapshot-settle.ts [instrumentation] (ecmascript)");
    });
});
}),
];