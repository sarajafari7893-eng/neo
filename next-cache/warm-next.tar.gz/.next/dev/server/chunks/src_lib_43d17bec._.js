module.exports = [
"[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_f504f283._.js",
  "server/chunks/[root-of-the-server]__362ab5f2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/raw-cal.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/lifecycle-learning.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_lifecycle-learning_ts_fe0da598._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/lifecycle-learning.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/flow-scanner.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_f41b448e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/flow-scanner.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/oi-funding.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_34489f4f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/oi-funding.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/governor.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_ed44f790._.js",
  "server/chunks/src_lib_engine_ts_0bd90ac0._.js",
  "server/chunks/src_lib_a30c5598._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__2da5f06a._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/governor.ts [app-route] (ecmascript)");
    });
});
}),
];