module.exports = [
"[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_d2d68b55._.js",
  "server/chunks/[root-of-the-server]__ba7bb8ea._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ebed90ed._.js",
  "server/chunks/src_lib_engine_ts_a868ea96._.js",
  "server/chunks/src_lib_99e156e4._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__8d16f881._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/engine.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/notify.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__657bae63._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/notify.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/lifecycle-learning.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_engine_ts_807dd0f4._.js",
  "server/chunks/[root-of-the-server]__8e506e26._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/lifecycle-learning.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/flow-scanner.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_engine_ts_807dd0f4._.js",
  "server/chunks/src_lib_8ba8a62b._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/flow-scanner.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/oi-funding.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__fb6c5005._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/oi-funding.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/ai.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/_451efd7a._.js",
  "server/chunks/[root-of-the-server]__ea2bf620._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/ai.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/governor.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__dc938cc7._.js",
  "server/chunks/src_lib_engine_ts_a868ea96._.js",
  "server/chunks/src_lib_104a2e9e._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__087147ff._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/governor.ts [instrumentation] (ecmascript)");
    });
});
}),
];