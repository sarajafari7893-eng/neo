module.exports = [
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_MILESTONE_STEPS",
    ()=>RAWCAL_MILESTONE_STEPS,
    "RAWCAL_TELEMETRY_FILE",
    ()=>RAWCAL_TELEMETRY_FILE,
    "checkRawcalMilestones",
    ()=>checkRawcalMilestones,
    "checkRawcalStallAlarm",
    ()=>checkRawcalStallAlarm,
    "computeRawcalPace",
    ()=>computeRawcalPace,
    "milestoneView",
    ()=>milestoneView,
    "recentBlocks",
    ()=>recentBlocks,
    "recordRawcalSnapshot",
    ()=>recordRawcalSnapshot
]);
// ── v9.2 RAW-CAL PACE MONITOR — engineering observability for the capture run ──
// Operator mandate 2026-09-13: «پایش ریتم صدور RAW-CAL و رشد کتاب EPOCH-2 به
// سمت ۱۰۰. رو کامل و مهندسی انجام بده» — monitor the RAW-CAL issuance rhythm
// and the growth of the EPOCH-2 book toward the 100-settled calibration bar.
//
// THREE PERSISTED INSTRUMENTS:
//  1) SNAPSHOT JOURNAL — .data/rawcal-telemetry.jsonl, one row every ~10min
//     (self-throttled; force on state jumps): {t, issued, issuedTotal,
//     settledE2, openRaw, settledRaw, winsRaw, note?} — the book-growth curve
//     the UI sparkline and rate math read. Trimmed to the last 4000 rows.
//  2) PACE ENGINE — rolling rates from the journal + the DB ledger:
//     issue rate/h (3h + since-armed), settle rate/h (3h + 6h), observed mean
//     spacing between raw issues (DB createdAt diffs), ETA to the 100 bar at
//     the current settle rate, pipeline projection (open raw records that will
//     still settle), mean book settle-time, and stall detection.
//  3) MILESTONE LEDGER — idempotent audited events at 50/60/70/80/90/95/100
//     (EngineSetting "rawcal.milestones"); Telegram only for 90/95/100 (the
//     100 announcement itself stays with the auto-lift in raw-cal.ts).
//
// STALL SEMANTICS (honest, rail-aware):
//  · issue stall  = armed && openRaw < maxOpen && now − lastIssueAt >
//    max(45min, 3 × spacingMin) — issuance SHOULD have produced a record.
//  · settle stall = openRaw > 0 && no EPOCH-2 settle in the last 3h.
//  Neither fires when the open-cap rail is the legitimate blocker.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const RAWCAL_TELEMETRY_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-telemetry.jsonl");
const MILESTONES_KEY = "rawcal.milestones";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const RAWCAL_MILESTONE_STEPS = [
    50,
    60,
    70,
    80,
    90,
    95,
    100
];
const TELEGRAM_MILESTONES = new Set([
    90,
    95,
    100
]);
const MAX_JOURNAL_ROWS = 4000;
// ── memo caches (pulse-safe; these run on hot paths) ──
let lastSnapshotAt = 0;
let paceCache = null;
const PACE_TTL_MS = 30_000;
async function readJournal() {
    try {
        const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(RAWCAL_TELEMETRY_FILE, "utf8");
        const rows = [];
        for (const line of txt.split("\n")){
            const s = line.trim();
            if (!s) continue;
            try {
                rows.push(JSON.parse(s));
            } catch  {
            /* skip torn line */ }
        }
        return rows.slice(-MAX_JOURNAL_ROWS);
    } catch  {
        return [];
    }
}
async function appendJournal(row) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(RAWCAL_TELEMETRY_FILE), {
            recursive: true
        });
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(RAWCAL_TELEMETRY_FILE, JSON.stringify(row) + "\n", "utf8");
        // opportunistic trim (cheap: only when the file grows past 2× the cap)
        try {
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(RAWCAL_TELEMETRY_FILE);
            if (st.size > MAX_JOURNAL_ROWS * 180) {
                const rows = await readJournal();
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(RAWCAL_TELEMETRY_FILE, rows.slice(-MAX_JOURNAL_ROWS).map((r)=>JSON.stringify(r)).join("\n") + "\n", "utf8");
            }
        } catch  {
        /* trim best-effort */ }
    } catch (e) {
        console.error("[rawcal-telemetry] journal append failed", e);
    }
}
async function recordRawcalSnapshot(note, force = false) {
    const now = Date.now();
    if (!force && now - lastSnapshotAt < 10 * 60_000) return null;
    lastSnapshotAt = now;
    try {
        const [settledE2, openRaw, totalRaw, settledRaw, winsRaw] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: {
                        in: SETTLED_STATUSES
                    },
                    tags: {
                        contains: "EPOCH-2"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: [
                            "ACTIVE",
                            "TP1",
                            "TP2"
                        ]
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: SETTLED_STATUSES
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    reachedTp: {
                        gte: 1
                    }
                }
            })
        ]);
        const snap = {
            t: new Date(now).toISOString(),
            issued: 0,
            issuedTotal: totalRaw,
            settledE2,
            openRaw,
            settledRaw,
            winsRaw,
            ...note ? {
                note: note.slice(0, 80)
            } : {}
        };
        // issued-this-run: cheap read of the state key (no import cycle — raw-cal
        // imports telemetry, not vice versa)
        try {
            const s = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "rawcal.state"
                }
            });
            if (s) snap.issued = JSON.parse(s.value).issued ?? 0;
        } catch  {
        /* optional field */ }
        await appendJournal(snap);
        paceCache = null; // fresh data → invalidate pace memo
        return snap;
    } catch (e) {
        console.error("[rawcal-telemetry] snapshot failed", e);
        return null;
    }
}
async function computeRawcalPace(blocks) {
    if (paceCache && Date.now() - paceCache.at < PACE_TTL_MS && !blocks) return paceCache.data;
    const state = await getRawcalStateSafe();
    const now = Date.now();
    const [settledE2, openRaw, openE2, maxOpen] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        Promise.resolve(state.maxOpen)
    ]);
    const target = state.target;
    // issuance ledger (raw rows from the DB itself — ground truth)
    const rawRows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            createdAt: true
        },
        orderBy: {
            createdAt: "asc"
        }
    });
    const issueTimes = rawRows.map((r)=>r.createdAt.getTime());
    const h3 = now - 3 * 3600_000;
    const issues3h = issueTimes.filter((t)=>t >= h3).length;
    const armMs = state.armedAt ? new Date(state.armedAt).getTime() : null;
    const issuesSinceArm = armMs ? issueTimes.filter((t)=>t >= armMs).length : 0;
    const armHours = armMs ? Math.max(1 / 60, (now - armMs) / 3600_000) : null;
    const diffs = issueTimes.slice(1).map((t, i)=>t - issueTimes[i]);
    const meanDiff = diffs.length ? diffs.reduce((a, b)=>a + b, 0) / diffs.length : null;
    // book-growth ledger (EPOCH-2 settles with closedAt)
    const settles = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            },
            closedAt: {
                not: null
            }
        },
        select: {
            closedAt: true,
            createdAt: true
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const settleTimes = settles.map((r)=>r.closedAt.getTime()).reverse(); // asc
    const settles3h = settleTimes.filter((t)=>t >= h3).length;
    const settles6h = settleTimes.filter((t)=>t >= now - 6 * 3600_000).length;
    const recent20 = settles.slice(0, 20);
    const meanSettleMin = recent20.length ? recent20.reduce((a, r)=>a + (r.closedAt.getTime() - r.createdAt.getTime()), 0) / recent20.length / 60_000 : null;
    const [settledRaw, winsRaw] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: SETTLED_STATUSES
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                reachedTp: {
                    gte: 1
                }
            }
        })
    ]);
    const settleRate3h = settles3h / 3;
    const needed = Math.max(0, target - settledE2);
    const etaHours = needed === 0 ? 0 : settleRate3h > 0 ? needed / settleRate3h : null;
    // v9.2.1 steady-state projection — raw cadence ∩ settle-throughput cap.
    // throughputCap = maxOpen concurrent records / mean settle hours; the real
    // fill window is needed / min(issueCadence, throughputCap). Only computed
    // when meanSettleMin is known (honest — no invented throughput).
    const issueSinceArmRateRaw = armHours ? issuesSinceArm / armHours : 0;
    const throughputCapPerH = meanSettleMin !== null && meanSettleMin > 0 ? maxOpen / (meanSettleMin / 60) : null;
    const steadyRatePerH = throughputCapPerH !== null ? Math.min(issueSinceArmRateRaw, throughputCapPerH) : null;
    const etaSteadyHours = needed === 0 ? 0 : steadyRatePerH !== null && steadyRatePerH > 0 ? needed / steadyRatePerH : null;
    // stalls (rail-aware — see header)
    const issueStallMin = state.armed && openRaw < maxOpen && state.lastIssueAt ? Math.max(0, (now - new Date(state.lastIssueAt).getTime()) / 60_000) : null;
    const issueStallActive = issueStallMin !== null && issueStallMin > Math.max(45, 3 * state.spacingMin);
    const lastSettleAt = settleTimes.length ? settleTimes[settleTimes.length - 1] : null;
    const settleStallMin = openRaw > 0 && lastSettleAt ? Math.max(0, (now - lastSettleAt) / 60_000) : null;
    const settleStallActive = settleStallMin !== null && settleStallMin > 180;
    // cadence grade — honest banding of the ISSUE rhythm while armed.
    // v9.2.1 arm-age-aware: inside the first 3h after arming the 3h window still
    // contains pre-RAW-CAL filtered flow (rate lag) → grade on the since-arm
    // cadence instead; afterwards both windows agree and 3h is used.
    const issueRate3hPerH = issues3h / 3;
    let cadenceGrade = "OFF";
    if (state.armed) {
        const baseRate = armHours !== null && armHours < 3 ? issueSinceArmRateRaw : issueRate3hPerH;
        const effRate = issueStallActive ? 0 : baseRate;
        cadenceGrade = effRate >= 3 ? "A" : effRate >= 1.5 ? "B" : effRate >= 0.5 ? "C" : "D";
    }
    // sparkline from the journal (downsample to ≤48 points)
    // v9.4.2 NaN guard: journal gap rows can carry non-finite settledE2 — skip
    // them here so the client never receives NaN chart values.
    const journal = await readJournal();
    const series = journal.length > 1 ? journal : journal.length === 1 ? [
        {
            t: new Date(now).toISOString(),
            settledE2
        }
    ] : [];
    const step = Math.max(1, Math.ceil(series.length / 48));
    const sparkline = [];
    for(let i = 0; i < series.length; i += step){
        const v = series[i].settledE2;
        if (!Number.isFinite(v)) continue;
        sparkline.push({
            t: series[i].t,
            v
        });
    }
    if (sparkline.length && Number.isFinite(settledE2) && sparkline[sparkline.length - 1].v !== settledE2) sparkline.push({
        t: new Date(now).toISOString(),
        v: settledE2
    });
    const lastBlockNote = blocks && blocks.length ? blocks[blocks.length - 1].note : null;
    const pace = {
        armed: state.armed,
        armedAt: state.armedAt,
        settledE2,
        needed,
        target,
        issueRate3hPerH: round2(issueRate3hPerH),
        issueRateSinceArmPerH: armHours ? round2(issuesSinceArm / armHours) : 0,
        observedSpacingMin: {
            mean: meanDiff !== null ? round2(meanDiff / 60_000) : null,
            min: diffs.length ? round2(Math.min(...diffs) / 60_000) : null,
            max: diffs.length ? round2(Math.max(...diffs) / 60_000) : null,
            samples: diffs.length
        },
        lastIssueAt: state.lastIssueAt,
        lastIssueSerial: state.lastIssueSerial,
        openRaw,
        openE2,
        maxOpen,
        spacingMin: state.spacingMin,
        settleRate3hPerH: round2(settleRate3h),
        settleRate6hPerH: round2(settles6h / 6),
        meanSettleMin: meanSettleMin !== null ? Math.round(meanSettleMin) : null,
        winsRaw,
        settledRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        etaHours: etaHours !== null ? round2(etaHours) : null,
        etaAt: etaHours !== null ? new Date(now + etaHours * 3600_000).toISOString() : null,
        steadyRatePerH: steadyRatePerH !== null ? round2(steadyRatePerH) : null,
        etaSteadyHours: etaSteadyHours !== null ? round2(etaSteadyHours) : null,
        etaSteadyAt: etaSteadyHours !== null ? new Date(now + etaSteadyHours * 3600_000).toISOString() : null,
        pipelineProjection: settledE2 + openE2,
        cadenceGrade,
        stalls: {
            issueStallMin: issueStallActive ? Math.round(issueStallMin) : null,
            settleStallMin: settleStallActive ? Math.round(settleStallMin) : null,
            lastBlockNote
        },
        sparkline,
        journalRows: journal.length
    };
    if (!blocks) paceCache = {
        at: Date.now(),
        data: pace
    };
    return pace;
}
async function getRawcalStateSafe() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return await getRawCalState();
    } catch  {
        return {
            armed: false,
            armedAt: null,
            lastIssueAt: null,
            lastIssueSerial: null,
            target: 100,
            spacingMin: 12,
            maxOpen: 8
        };
    }
}
function round2(n) {
    return Math.round(n * 100) / 100;
}
// ── MILESTONE LEDGER ──
async function readMilestones() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: MILESTONES_KEY
            }
        });
        if (!row) return {
            fired: {}
        };
        return JSON.parse(row.value);
    } catch  {
        return {
            fired: {}
        };
    }
}
async function checkRawcalMilestones() {
    const settledE2 = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    }).catch(()=>0);
    const m = await readMilestones();
    const firedNow = [];
    for (const step of RAWCAL_MILESTONE_STEPS){
        const key = String(step);
        if (settledE2 < step || m.fired[key]) continue;
        const at = new Date().toISOString();
        m.fired[key] = at;
        firedNow.push({
            step,
            at
        });
        const isBar = step === 100;
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", `RAW-CAL MILESTONE ${step}/${100} — EPOCH-2 book at ${settledE2} settled${isBar ? " — calibration bar REACHED, capture mode hands back to central-intelligence command (new calibration)" : ` · ${100 - settledE2} records remain to the AI CALIBRATION bar`}`).catch(()=>undefined);
        if (TELEGRAM_MILESTONES.has(step) && !(isBar && stateHasAutoLift())) {
            const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
            void sendDirect(`📈 <b>RAW-CAL MILESTONE ${step}/100</b>\nEPOCH-2 book: <b>${settledE2}/100</b> settled${isBar ? " — AI CALIBRATION lift imminent" : ` · ${100 - settledE2} to go`}\n${progressBar(settledE2)}`).catch(()=>undefined);
        }
    }
    if (firedNow.length) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: MILESTONES_KEY
            },
            create: {
                key: MILESTONES_KEY,
                value: JSON.stringify(m)
            },
            update: {
                value: JSON.stringify(m)
            }
        }).catch(()=>undefined);
    }
    return firedNow;
}
async function stateHasAutoLift() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return !!(await getRawCalState()).autoLiftAt;
    } catch  {
        return false;
    }
}
function progressBar(n) {
    const filled = Math.round(Math.min(100, n) / 100 * 20);
    return "▰".repeat(filled) + "▱".repeat(20 - filled);
}
async function milestoneView() {
    const [m, settledE2] = await Promise.all([
        readMilestones(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }).catch(()=>0)
    ]);
    return {
        steps: RAWCAL_MILESTONE_STEPS.map((step)=>({
                step,
                fired: !!m.fired[String(step)],
                at: m.fired[String(step)] ?? null,
                pending: settledE2 < step
            })),
        settledE2
    };
}
async function recentBlocks(n = 12) {
    try {
        const { getRawCalBlocks } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return getRawCalBlocks(n);
    } catch  {
        return [];
    }
}
// ── v9.2.1 STALL ALARM — push the rhythm break, don't just display it ──
// Tick hook (idempotent, 2h cooldown per stall type). Fires when the armed
// issuer SHOULD have produced (issue stall) or the in-flight pipeline SHOULD
// have settled (settle stall) and didn't. Process-death is covered by the P0
// watchdog + keep-alive crons; this alarm covers "alive but rhythm broken".
const STALL_ALERT_KEY = "rawcal.stallAlerts";
const STALL_COOLDOWN_MS = 2 * 3600_000;
async function checkRawcalStallAlarm() {
    try {
        const pace = await computeRawcalPace().catch(()=>null);
        if (!pace || !pace.armed) return false;
        const issues = [];
        if (pace.stalls.issueStallMin) issues.push(`issue stall — no raw record for ${pace.stalls.issueStallMin}min while armed and open ${pace.openRaw}/${pace.maxOpen}`);
        if (pace.stalls.settleStallMin) issues.push(`settle stall — no EPOCH-2 settle for ${pace.stalls.settleStallMin}min with ${pace.openRaw} raw in flight`);
        if (!issues.length) return false;
        let fired = {};
        try {
            const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: STALL_ALERT_KEY
                }
            });
            if (row) fired = JSON.parse(row.value).fired ?? {};
        } catch  {
        /* fresh ledger */ }
        const now = Date.now();
        const send = [];
        for (const it of issues){
            const k = it.startsWith("issue") ? "issue" : "settle";
            const last = fired[k] ? new Date(fired[k]).getTime() : 0;
            if (now - last > STALL_COOLDOWN_MS) {
                fired[k] = new Date(now).toISOString();
                send.push(it);
            }
        }
        if (!send.length) return false;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: STALL_ALERT_KEY
            },
            create: {
                key: STALL_ALERT_KEY,
                value: JSON.stringify({
                    fired
                })
            },
            update: {
                value: JSON.stringify({
                    fired
                })
            }
        }).catch(()=>undefined);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL PACE ALARM — ${send.join(" · ")} · book ${pace.settledE2}/${pace.target} · cadence ${pace.cadenceGrade}`).catch(()=>undefined);
        const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
        void sendDirect(`⏱ <b>RAW-CAL PACE ALARM</b>\n${send.map((s)=>`• ${s}`).join("\n")}\n📊 Book: <b>${pace.settledE2}/${pace.target}</b> settled · cadence ${pace.cadenceGrade} · open raw ${pace.openRaw}/${pace.maxOpen}`).catch(()=>undefined);
        return true;
    } catch  {
        return false;
    }
}
}),
"[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeRawcalQuality",
    ()=>computeRawcalQuality,
    "r6GateLine",
    ()=>r6GateLine,
    "readPersistedQuality",
    ()=>readPersistedQuality,
    "recordRawcalQuality",
    ()=>recordRawcalQuality
]);
// ── v9.3 RAW-CAL SAMPLE QUALITY LAB — data-health gate for the R6 recalibration ──
// Operator mandate 2026-09-13: «پس از تسویه اولین RAW-CALها (~1-2h) میتوانیم
// کیفیت نمونه‌های خام را هم بررسی کنیم تا کالیبراسیون R6 روی داده سالم بنشیند»
// — after the first RAW-CALs settle, review the quality of the raw samples so
// the R6 calibration rests on HEALTHY data.
//
// WHAT IT MEASURES (every RAW-CAL-tagged ledger row, 100% from the DB):
//  · CAPTURE INTEGRITY (0-30): deploy audit snapshots preserved — factorsJson
//    (confluence votes, 12) / flowJson (order-flow, 9) / mtfJson (multi-TF
//    board, 9). R6 attributes outcomes to factors; a row born without its
//    snapshots can never be attributed, so absence is scored, not forgiven.
//  · PLAN COMPLETENESS (0-20): entry/stop/TP ladder present and
//    direction-consistent, RR > 0, TTL sane — a malformed plan is a malformed
//    sample no matter how it settles.
//  · OUTCOME INFORMATIVENESS (0-30): TP1/TP2/TP3 or SL = fully informative
//    (price proved or disproved the plan — losses are the most instructive
//    rows); EXPIRED with a TP touch = partially informative; EXPIRED with no
//    touch = time-censored (low information); manual CLOSED = censored.
//  · REPRESENTATIVENESS (0-20): spacing ≥ the anti-flood rail (burst-cluster
//    rows are correlated and would inflate calibration confidence), hold time
//    inside the TTL envelope, extension abuse flagged.
// Composite 0-100 → HEALTHY ≥75 · REVIEW 50-74 · CENSORED <50 (PENDING while
// the row is still open).
//
// COHORT HEALTH → R6 GATE: healthy% of the settled raw cohort vs the 85%
// health floor, informative ratio, symbol concentration, side balance,
// snapshot completeness — verdict GREEN / AMBER / RED (WARMING before the
// first settles) with explicit blockers. The gate ADVISES the R6 lift and the
// central intelligence (engine memory + governor context); it NEVER edits the
// calibration math itself (no post-hoc tampering — honest instrumentation).
//
// PERSISTENCE: EngineSetting "rawcal.quality" (compact digest, cross-process)
// + QUALITY rows appended to .data/rawcal-telemetry.jsonl (10min throttle,
// forced the moment the settled-raw count moves — the settle curve of the
// QUALITY of the book, not just its size).
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)");
;
;
;
;
const QUALITY_KEY = "rawcal.quality";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const OPEN_STATUSES = [
    "ACTIVE",
    "TP1",
    "TP2"
];
const HEALTH_FLOOR = 85; // R6 health floor — healthy% of the settled raw cohort
const MAX_JOURNAL_ROWS = 4000;
// ── v10.9 POST-FILTER COHORT (SUPERVISOR proposal 22:55Z, operator-approved
// 2026-09-15 «دستورات سوپروایزر را کامل و مهندسی انجام بده») — before/after
// split around the decisive-excursion filter go-live (first live skip TAOUSDT
// 11:31:27Z, worklog OP-V106-ROOTCAUSE-20260915T1134Z). The blended window is
// dominated by the legacy expired-no-touch stock, so the filter's true effect
// on outcome informativeness is measured on its OWN cohort. Censoring-aware
// pre/post design (gov.uk before-after guidance; Prinja 2010, Turkson 2021).
const FILTER_ERA_START_MS = Date.parse("2026-09-15T11:30:00.000Z");
// ── v10.9.2 EXPIRY-CAUSE ATTRIBUTION (SUPERVISOR proposal, operator-approved
// via bridge 2026-09-16T11:18Z «دستورات سوپروایزر را تایید می کنم») — the gate
// verdict is hostage to expired-no-touch censoring (informative 37.7% blended):
// R6 cannot attribute outcomes when a trade never reaches TP1 or SL. Each
// EXPIRED-no-touch row is now split by its MAX FAVORABLE EXCURSION in R units
// (mfeR = (maxPnlPercent/leverage) / stopDistancePct — existing journal fields,
// zero new capture): WRONG-SIDE (mfeR < 0.25 — price never followed the plan;
// entry direction/timing problem, NOT a TTL problem) vs NO-FOLLOW (mfeR ≥ 0.6 —
// meaningful follow that stalled before TP1; barrier/TP geometry too far for
// realized excursion) vs MIXED (in between). The gate can now NAME the dominant
// expiry cause, and the VOL-BARRIER mult/cap knobs get a direct feedback signal
// (no-follow dominance → tighten barrier; wrong-side dominance → entry filter
// problem). Reporting-layer only — scoring, scan and issue logic untouched.
const EXP_WRONG_SIDE_R = 0.25; // below: never followed — wrong side / late entry
const EXP_NO_FOLLOW_R = 0.6; // above: followed then stalled — geometry too far
// ── v10.9.1 EPOCH-WINDOWED GATE VERDICT (SUPERVISOR proposal, operator blanket-
// approve 2026-09-16T09:03Z «تمام اقدامات و پیشنهادات SUPERVISOR را تایید
// می‌کنم — کامل و مهندسی انجام بده») — the gate verdict is computed on the
// POST-FILTER EPOCH WINDOW, not the blended all-time cohort. The blended
// window is dominated by legacy expired-no-touch stock (metric regime-bias:
// 37.7% blended vs 56% post-filter informative at approval time), so the
// all-time ratio can never turn GREEN even when the CURRENT engine regime is
// decisively healthier. GREEN now requires the epoch window to prove itself:
// window informative ≥50% AND window settled n≥20. Structural integrity
// (snapshots) stays whole-cohort — a row born without snapshots is era-
// independent damage. The healthy-floor check rides the window too (AMBER,
// not RED). VERDICT-ONLY change: scoring, cohort measurement, scan/issue
// logic all untouched — the digest still reports the blended ratios for the
// whole book (honest instrumentation), only the VERDICT anchor moved.
const GATE_WINDOW_MIN_N = 20; // settled rows the window needs before GREEN is reachable
const GATE_WINDOW_FORMING = 3; // below this the window is WARMING, not judged
const GATE_WINDOW_INFORMATIVE = 50; // GREEN bar for the window informative ratio
const GATE_WINDOW_WARN_N = 8; // window small-sample guard for the informative blocker
// ── memo cache (runs on hot paths) ──
let qualityCache = null;
const QUALITY_TTL_MS = 30_000;
let lastJournalAt = 0;
let lastSeenSettled = -1;
function safeParse(json) {
    if (!json || !json.trim()) return false;
    try {
        const v = JSON.parse(json);
        return v !== null && (typeof v !== "object" || Array.isArray(v) ? v.length > 0 : Object.keys(v).length > 0);
    } catch  {
        return false;
    }
}
function round1(n) {
    return Math.round(n * 10) / 10;
}
function pct(part, whole) {
    return whole > 0 ? round1(part / whole * 100) : null;
}
/** Score ONE raw ledger row against the four quality dimensions. */ function scoreSample(row, prevCreatedAt, spacingMin) {
    const flags = [];
    const settled = SETTLED_STATUSES.includes(row.status);
    const open = OPEN_STATUSES.includes(row.status);
    // ── A) capture integrity — the deploy audit snapshots R6 will attribute to (0-30)
    let integrity = 0;
    if (safeParse(row.factorsJson)) integrity += 12;
    else flags.push("no-factors");
    if (safeParse(row.flowJson)) integrity += 9;
    else flags.push("no-flow");
    if (safeParse(row.mtfJson)) integrity += 9;
    else flags.push("no-mtf");
    // ── B) plan completeness — entry/stop/ladder coherent (0-20)
    let plan = 0;
    if (row.entryPrice > 0) plan += 2;
    if (row.stopLoss > 0) plan += 3;
    else flags.push("no-stop");
    if (row.tp1 > 0 && row.tp2 > 0 && row.tp3 > 0) plan += 3;
    else flags.push("ladder-short");
    const long = row.direction === "LONG";
    const ladderOk = long ? row.tp1 > row.entryPrice && row.stopLoss < row.entryPrice : row.direction === "SHORT" ? row.tp1 < row.entryPrice && row.stopLoss > row.entryPrice : false;
    if (ladderOk) plan += 6;
    else flags.push("ladder-inconsistent");
    if (row.riskReward > 0) plan += 2;
    if (row.ttlMinutes > 0 && row.expiresAt.getTime() > row.createdAt.getTime()) plan += 4;
    else flags.push("ttl-bad");
    // ── C) outcome informativeness — what did the settle actually teach (0-30)
    let outcome = 0;
    if (settled) {
        if ([
            "TP1",
            "TP2",
            "TP3"
        ].includes(row.status)) outcome = 30;
        else if (row.status === "SL") outcome = 30;
        else if (row.status === "EXPIRED") {
            if (row.reachedTp >= 1) outcome = 20;
            else {
                outcome = 8;
                flags.push("expired-no-touch"); // time-censored — weakest calibration row
                // v10.9.2 expiry-cause attribution — MFE in R units names WHY it censored
                const slPct = row.entryPrice > 0 ? Math.abs(row.stopLoss - row.entryPrice) / row.entryPrice * 100 : 0;
                if (slPct > 0 && row.leverage > 0) {
                    const mfeR = row.maxPnlPercent / row.leverage / slPct;
                    if (mfeR < EXP_WRONG_SIDE_R) flags.push("expired-wrong-side");
                    else if (mfeR >= EXP_NO_FOLLOW_R) flags.push("expired-no-follow");
                } // slPct/leverage degenerate → cause unknown, censoring flag alone stands
            }
        } else if (row.status === "CLOSED") {
            outcome = 10;
            flags.push("manual-close");
        }
    } else if (!open) {
        flags.push("status-odd");
    }
    // ── D) representativeness — spacing rail + TTL envelope (0-20)
    let timing = 0;
    let spacingOk = null;
    if (prevCreatedAt) {
        const gapMin = (row.createdAt.getTime() - prevCreatedAt.getTime()) / 60_000;
        spacingOk = gapMin >= spacingMin * 0.98;
        if (spacingOk) timing += 10;
        else {
            timing += 4;
            flags.push("cluster-spawn");
        }
    } else {
        timing += 10; // first record of the cohort — no spacing to violate
    }
    if (settled && row.closedAt) {
        const envelope = row.ttlMinutes * (1 + 0.25 * row.ttlExtensions) + 5;
        const holdMin = (row.closedAt.getTime() - row.createdAt.getTime()) / 60_000;
        if (holdMin <= envelope) timing += 10;
        else flags.push("hold-overrun");
        if (row.ttlExtensions >= 3) flags.push(`ttl-ext×${row.ttlExtensions}`);
    } else if (!settled) {
        timing += 10; // hold envelope not yet measurable — neutral until settle
    }
    const score = Math.round(integrity + plan + outcome + timing);
    const cls = open ? "PENDING" : score >= 75 ? "HEALTHY" : score >= 50 ? "REVIEW" : "CENSORED";
    return {
        serial: row.serial,
        symbol: row.symbol,
        direction: row.direction,
        strategy: row.strategy,
        status: row.status,
        settled,
        pnlPercent: round1(row.pnlPercent),
        holdMin: row.closedAt ? Math.round((row.closedAt.getTime() - row.createdAt.getTime()) / 60_000) : null,
        score,
        cls,
        flags,
        spacingOk
    };
}
async function computeRawcalQuality() {
    if (qualityCache && Date.now() - qualityCache.at < QUALITY_TTL_MS) return qualityCache.data;
    let spacingMin = 12;
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        spacingMin = (await getRawCalState()).spacingMin;
    } catch  {
    /* default rail */ }
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            symbol: true,
            direction: true,
            strategy: true,
            status: true,
            reachedTp: true,
            pnlPercent: true,
            ttlMinutes: true,
            ttlExtensions: true,
            entryPrice: true,
            tp1: true,
            tp2: true,
            tp3: true,
            stopLoss: true,
            riskReward: true,
            leverage: true,
            maxPnlPercent: true,
            expiresAt: true,
            createdAt: true,
            closedAt: true,
            factorsJson: true,
            flowJson: true,
            mtfJson: true
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 200
    });
    const asc = [
        ...rows
    ].reverse(); // asc for spacing diffs
    const scored = asc.map((r, i)=>scoreSample(r, i > 0 ? asc[i - 1].createdAt : null, spacingMin));
    const settledSamples = scored.filter((s)=>s.settled);
    const settledRaw = settledSamples.length;
    const openRaw = scored.filter((s)=>!s.settled).length;
    const healthy = settledSamples.filter((s)=>s.cls === "HEALTHY").length;
    const review = settledSamples.filter((s)=>s.cls === "REVIEW").length;
    const censored = settledSamples.filter((s)=>s.cls === "CENSORED").length;
    const healthyPct = pct(healthy, settledRaw);
    // informative = fully readable outcome: TP/SL proved the plan, or EXPIRED
    // after a TP touch (partially readable). EXPIRED-no-touch / CLOSED excluded.
    const informativePct = pct(settledSamples.filter((s)=>[
            "TP1",
            "TP2",
            "TP3",
            "SL"
        ].includes(s.status) || s.status === "EXPIRED" && !s.flags.includes("expired-no-touch")).length, settledRaw);
    const expiredNoTouch = settledSamples.filter((s)=>s.flags.includes("expired-no-touch")).length;
    const expiryCauses = {
        wrongSide: expiredNoTouch ? settledSamples.filter((s)=>s.flags.includes("expired-wrong-side")).length : 0,
        noFollow: expiredNoTouch ? settledSamples.filter((s)=>s.flags.includes("expired-no-follow")).length : 0,
        mixed: 0
    };
    expiryCauses.mixed = Math.max(0, expiredNoTouch - expiryCauses.wrongSide - expiryCauses.noFollow);
    // ── post-filter cohort — reuses the cohort-consistent scores (spacing vs true
    // predecessor) by index alignment with `asc`, not a re-scored sub-list.
    const postScored = asc.map((r, i)=>r.createdAt.getTime() >= FILTER_ERA_START_MS ? scored[i] : null).filter((s)=>s !== null);
    const postSettled = postScored.filter((s)=>s.settled);
    const postInformativePct = pct(postSettled.filter((s)=>[
            "TP1",
            "TP2",
            "TP3",
            "SL"
        ].includes(s.status) || s.status === "EXPIRED" && !s.flags.includes("expired-no-touch")).length, postSettled.length);
    const postExpiryRatePct = pct(postSettled.filter((s)=>s.flags.includes("expired-no-touch")).length, postSettled.length);
    const postFilterCohort = {
        since: new Date(FILTER_ERA_START_MS).toISOString(),
        n: postScored.length,
        settled: postSettled.length,
        informativePct: postInformativePct,
        expiryRatePct: postExpiryRatePct
    };
    const snapshotOk = scored.filter((s)=>!s.flags.includes("no-factors") && !s.flags.includes("no-flow") && !s.flags.includes("no-mtf")).length;
    const snapshotPct = pct(snapshotOk, scored.length);
    const symAcc = new Map();
    let longs = 0;
    for (const s of settledSamples){
        symAcc.set(s.symbol, (symAcc.get(s.symbol) ?? 0) + 1);
        if (s.direction === "LONG") longs++;
    }
    const symbols = symAcc.size;
    const topSymbolShare = symbols ? Math.max(...symAcc.values()) / settledRaw * 100 : null;
    const longPct = pct(longs, settledRaw);
    const shortPct = longPct !== null ? round1(100 - longPct) : null;
    const holds = settledSamples.map((s)=>s.holdMin).filter((h)=>h !== null);
    const meanAbsPnl = settledRaw ? round1(settledSamples.reduce((a, s)=>a + Math.abs(s.pnlPercent), 0) / settledRaw) : null;
    const meanHoldMin = holds.length ? Math.round(holds.reduce((a, b)=>a + b, 0) / holds.length) : null;
    const clusterCount = scored.filter((s)=>s.flags.includes("cluster-spawn")).length;
    // ── warnings (priority-ordered, sample-size-guarded — no noise at n=1) ──
    const warnings = [];
    if (settledRaw >= 3 && informativePct !== null && informativePct < 70) warnings.push(`informative ratio ${informativePct}% < 70% — EXPIRED censoring weakens R6 factor attribution`);
    if (settledRaw >= 5 && topSymbolShare !== null && topSymbolShare > 40) warnings.push(`symbol concentration ${round1(topSymbolShare)}% in one market — R6 may overfit`);
    if (settledRaw >= 5 && (longPct === null || shortPct === null || Math.max(longPct, shortPct ?? 0) > 75)) warnings.push(`side imbalance ${longPct ?? "—"}L/${shortPct ?? "—"}S — thin counter-direction evidence`);
    if (scored.length >= 2 && snapshotPct !== null && snapshotPct < 80) warnings.push(`deploy snapshots complete on ${snapshotPct}% of the cohort — factor attribution degraded`);
    if (clusterCount >= 2) warnings.push(`${clusterCount} records issued inside the ${spacingMin}min rail — burst cluster, correlated samples`);
    if (settledRaw >= 3 && healthyPct !== null && healthyPct < HEALTH_FLOOR) warnings.push(`healthy ${healthyPct}% below the ${HEALTH_FLOOR}% R6 floor`);
    // ── R6 gate verdict — v10.9.1 EPOCH-WINDOWED ──
    // Blocker 1 (structural, whole-cohort): snapshot integrity — era-independent.
    // Blocker 2 (regime, epoch window): window informative ratio below the GREEN
    // bar, only judged once the window carries enough settled rows (≥20) to be
    // statistically meaningful; below the warn-n the window is guarded, not
    // punished (small-sample informative dips are noise, not censoring).
    const blockers = [];
    const winSettled = postSettled.length;
    const winHealthyPct = pct(postSettled.filter((s)=>s.cls === "HEALTHY").length, winSettled);
    if (scored.length >= 2 && snapshotPct !== null && snapshotPct < 50) blockers.push(`snapshots complete on only ${snapshotPct}%`);
    if (winSettled >= GATE_WINDOW_WARN_N && postInformativePct !== null && postInformativePct < GATE_WINDOW_INFORMATIVE) blockers.push(`epoch-window informative ${postInformativePct}% < 50% (n=${winSettled}) — censoring regime`);
    const verdict = settledRaw === 0 || winSettled < GATE_WINDOW_FORMING ? "WARMING" // honest: the window has nothing meaningful to grade yet
     : blockers.length > 0 ? "RED" : winSettled < GATE_WINDOW_MIN_N || winHealthyPct !== null && winHealthyPct < HEALTH_FLOOR ? "AMBER" // window formed but short of the GREEN bar or the health floor
     : "GREEN";
    // UI samples view: settled cohort first (newest first), then in-flight
    const desc = [
        ...scored
    ].reverse();
    const samples = [
        ...desc.filter((s)=>s.settled),
        ...desc.filter((s)=>!s.settled)
    ].slice(0, 12);
    const digest = {
        at: new Date().toISOString(),
        issuedTotal: scored.length,
        openRaw,
        settledRaw,
        healthy,
        review,
        censored,
        healthyPct,
        informativePct,
        expiredNoTouch,
        expiryCauses,
        snapshotPct,
        symbols,
        topSymbolShare: topSymbolShare !== null ? round1(topSymbolShare) : null,
        longPct,
        shortPct,
        meanAbsPnl,
        meanHoldMin,
        clusterCount,
        warnings: warnings.slice(0, 5),
        gate: {
            verdict,
            healthFloor: HEALTH_FLOOR,
            blockers,
            window: {
                since: postFilterCohort.since,
                settled: winSettled,
                healthyPct: winHealthyPct,
                informativePct: postInformativePct
            }
        },
        postFilterCohort,
        samples
    };
    qualityCache = {
        at: Date.now(),
        data: digest
    };
    return digest;
}
function r6GateLine(d) {
    const w = d.gate.window;
    const base = `R6 DATA HEALTH (v10.9.1 epoch-windowed gate — verdict anchors the post-filter window, blended ratios reported for the whole book): raw cohort ${d.settledRaw} settled/${d.issuedTotal} issued · blended healthy ${d.healthyPct ?? "—"}% (floor ${d.gate.healthFloor}) · blended informative ${d.informativePct ?? "—"}% · snapshots ${d.snapshotPct ?? "—"}% · GATE ${d.gate.verdict}` + (w ? ` — window n=${w.settled} informative ${w.informativePct ?? "—"}% healthy ${w.healthyPct ?? "—"}%` : "") + (d.gate.verdict === "WARMING" ? " (window still forming — grading starts at the first window settles)" : "") + (d.gate.blockers.length ? ` · blockers: ${d.gate.blockers.join("; ")}` : "");
    const causes = d.expiryCauses && d.expiryCauses.wrongSide + d.expiryCauses.noFollow + d.expiryCauses.mixed > 0 ? ` · expiry causes: wrong-side ${d.expiryCauses.wrongSide} / no-follow ${d.expiryCauses.noFollow} / mixed ${d.expiryCauses.mixed} (of ${d.expiredNoTouch} no-touch)` : "";
    const post = d.postFilterCohort && d.postFilterCohort.n > 0 ? ` · post-filter cohort n=${d.postFilterCohort.n} (settled ${d.postFilterCohort.settled}) informative ${d.postFilterCohort.informativePct ?? "—"}% expiry ${d.postFilterCohort.expiryRatePct ?? "—"}%` : "";
    return base + causes + post + (d.warnings.length ? ` — watch: ${d.warnings[0]}` : " — no issues");
}
/** Compact digest for EngineSetting persistence (no samples array). */ function compact(d) {
    const { samples: _samples, ...rest } = d;
    void _samples;
    return rest;
}
async function recordRawcalQuality() {
    try {
        const digest = await computeRawcalQuality();
        const changed = digest.settledRaw !== lastSeenSettled;
        if (!changed && Date.now() - lastJournalAt < 10 * 60_000) return null;
        lastJournalAt = Date.now();
        lastSeenSettled = digest.settledRaw;
        const c = compact(digest);
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: QUALITY_KEY
            },
            create: {
                key: QUALITY_KEY,
                value: JSON.stringify(c)
            },
            update: {
                value: JSON.stringify(c)
            }
        }).catch(()=>undefined);
        try {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"]), {
                recursive: true
            });
            const row = {
                kind: "QUALITY",
                t: digest.at,
                issued: digest.issuedTotal,
                settled: digest.settledRaw,
                healthyPct: digest.healthyPct,
                informativePct: digest.informativePct,
                snapshotPct: digest.snapshotPct,
                gate: digest.gate.verdict,
                warns: digest.warnings.length
            };
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], JSON.stringify(row) + "\n", "utf8");
            // opportunistic trim (same policy as the pace journal)
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"]).catch(()=>null);
            if (st && st.size > MAX_JOURNAL_ROWS * 180) {
                const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], "utf8").catch(()=>"");
                const lines = txt.split("\n").filter(Boolean).slice(-MAX_JOURNAL_ROWS);
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], lines.join("\n") + "\n", "utf8").catch(()=>undefined);
            }
        } catch  {
        /* journal best-effort */ }
        return digest;
    } catch (e) {
        console.error("[rawcal-quality] record failed", e);
        return null;
    }
}
async function readPersistedQuality() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: QUALITY_KEY
            }
        });
        if (!row) return null;
        return JSON.parse(row.value);
    } catch  {
        return null;
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ddb0ecae._.js.map