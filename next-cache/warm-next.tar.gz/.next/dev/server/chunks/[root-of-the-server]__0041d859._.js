module.exports = [
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[project]/src/lib/persist-guard.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BOOT_ID",
    ()=>BOOT_ID,
    "persistGuardOk",
    ()=>persistGuardOk,
    "persistWatermark",
    ()=>persistWatermark,
    "serializePersist",
    ()=>serializePersist
]);
// ── v10.6.1 PERSIST GUARD — serialize queue + monotonic watermark ────────────
// Operator APPROVE 2026-09-18 (proposal #4 / supervisor proposal-5a): fix the
// dev split-brain class where a stale module generation (or a second dev
// process) rewrites state files from an in-memory snapshot and clobbers newer
// records written by the live instance — the root cause of the paperSettled
// loss risk, the SV "frozen last-known arms" symptom and the recurring
// write-lock degradation windows (HTTP:000 on SV/advisor/terminal).
//
// TWO PRIMITIVES, both process-local + cross-process aware:
//  · serializePersist(scope, fn) — single-flight queue: writers for one scope
//    chain after each other instead of interleaving rename/rewrite windows.
//  · persistWatermark(scope) / persistGuardOk(scope) — a monotonic watermark
//    {bootId, seq, ts} in a sidecar file. Before a DESTRUCTIVE state rewrite
//    (rotation / compact / rename), the caller checks the sidecar: if another
//    boot rotated more recently than this process's last observed watermark,
//    this process must resync (re-stat) instead of blindly renaming — which is
//    exactly the stale-instance counter-divergence bug.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:crypto [external] (node:crypto, cjs)");
;
;
;
const BOOT_ID = `${Date.now().toString(36)}-${(0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["randomBytes"])(4).toString("hex")}`;
const queues = new Map();
const seqs = new Map();
const lastSeen = new Map();
function serializePersist(scope, fn) {
    const prev = queues.get(scope) ?? Promise.resolve();
    const next = prev.then(fn, fn); // run regardless of predecessor outcome
    queues.set(scope, next.catch(()=>undefined));
    return next;
}
function watermarkPath(scope) {
    return __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", `persist-wm-${scope}.json`);
}
function nextSeq(scope) {
    const s = (seqs.get(scope) ?? 0) + 1;
    seqs.set(scope, s);
    return s;
}
async function persistWatermark(scope) {
    const mark = {
        bootId: BOOT_ID,
        seq: nextSeq(scope),
        ts: Date.now()
    };
    lastSeen.set(scope, mark);
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["writeFile"])(watermarkPath(scope), JSON.stringify(mark), "utf8");
    } catch  {
    /* guard must never break the writer */ }
    return mark;
}
async function persistGuardOk(scope) {
    try {
        const raw = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(watermarkPath(scope), "utf8");
        const disk = JSON.parse(raw);
        if (!disk || typeof disk.ts !== "number") return true;
        const seen = lastSeen.get(scope);
        // Foreign boot wrote after our last observed mark → we are stale.
        if (disk.bootId !== BOOT_ID && (!seen || disk.ts > seen.ts)) return false;
        return true;
    } catch  {
        return true; // no watermark yet — first writer wins
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0041d859._.js.map