module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/node:fs [external] (node:fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs", () => require("node:fs"));

module.exports = mod;
}),
"[project]/src/lib/db.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[project]/src/app/api/healthz/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const dynamic = "force-dynamic";
function memAvailableMB() {
    try {
        const m = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])("/proc/meminfo", "utf8").match(/^MemAvailable:\s+(\d+) kB/m);
        return m ? Math.round(parseInt(m[1], 10) / 1024) : null;
    } catch  {
        return null;
    }
}
// ── TASK-51 LINEAGE (operator mandate RESET-0929: «نمی‌توانی بخوانی») ──────
// After any platform reset the operator must be able to READ the system's
// continuity at a glance: when this generation booted, which commit is
// running, and where the signal ledger stands (serial continuity = data
// survived). Fail-open on every read — lineage is metadata, never a gate.
function gitHeadSha() {
    try {
        const head = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])("/home/z/my-project/.git/HEAD", "utf8").trim();
        const m = head.match(/^ref:\s+(.+)$/);
        if (!m) return head.slice(0, 7) || null;
        const refPath = `/home/z/my-project/.git/${m[1]}`;
        if (!(0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["existsSync"])(refPath)) return null;
        const sha = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(refPath, "utf8").trim();
        return sha.slice(0, 7) || null;
    } catch  {
        return null;
    }
}
async function ledgerLineage() {
    try {
        const [agg, oldest] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.aggregate({
                _max: {
                    serial: true
                },
                _count: {
                    _all: true
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findFirst({
                orderBy: {
                    createdAt: "asc"
                },
                select: {
                    createdAt: true
                }
            })
        ]);
        return {
            maxSerial: agg._max.serial ?? null,
            total: agg._count._all ?? null,
            oldestAt: oldest?.createdAt?.toISOString() ?? null
        };
    } catch  {
        return {
            maxSerial: null,
            total: null,
            oldestAt: null
        };
    }
}
/**
 * CONVERGENCE 2026-09-09 (OP-P0-WD-0909 × OP-P0-WD-V3): the bun p0-watchdog
 * service (:3020) is the single P0 healing authority. This endpoint mirrors
 * its liveness (lock.json pid) + app-healing state (state.json) so operators
 * and external monitors get one-glance truth. Fail-open on missing files.
 */ function p0WatchdogStatus() {
    const out = {
        running: false,
        pid: null,
        appMode: null,
        appFails: null,
        pausedUntil: null,
        authority: "bun p0-watchdog :3020 (OP-P0-WD-0909)"
    };
    try {
        const lockf = "/home/z/my-project/.data/p0-watchdog/lock.json";
        if ((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["existsSync"])(lockf)) {
            const m = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(lockf, "utf8").match(/"pid":\s*(\d+)/);
            const pid = m ? parseInt(m[1], 10) : NaN;
            if (Number.isFinite(pid) && pid > 0) {
                try {
                    process.kill(pid, 0); // liveness probe only
                    out.running = true;
                    out.pid = pid;
                } catch  {
                    out.running = false;
                }
            }
        }
        const st = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])("/home/z/my-project/.data/p0-watchdog/state.json", "utf8"));
        out.pausedUntil = typeof st.pausedUntil === "number" ? st.pausedUntil : null;
        out.appMode = typeof st.services?.app?.mode === "string" ? st.services.app.mode : null;
        out.appFails = typeof st.services?.app?.fails === "number" ? st.services.app.fails : null;
    } catch  {
    // fail-open: a status endpoint must never 500 over missing state files
    }
    return out;
}
function layer2Status() {
    const out = {
        running: false,
        pid: null
    };
    try {
        const pidf = "/home/z/my-project/.data/watchdog/pid";
        if ((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["existsSync"])(pidf)) {
            const pid = parseInt((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(pidf, "utf8").trim(), 10);
            if (Number.isFinite(pid) && pid > 0) {
                try {
                    process.kill(pid, 0);
                    out.running = true;
                    out.pid = pid;
                } catch  {
                    out.running = false;
                }
            }
        }
    } catch  {
    // fail-open
    }
    return out;
}
async function GET() {
    const mem = process.memoryUsage();
    const ledger = await ledgerLineage();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        ok: true,
        ts: Date.now(),
        uptimeSec: Math.round(process.uptime()),
        bootAt: new Date(Date.now() - process.uptime() * 1000).toISOString(),
        gitSha: gitHeadSha(),
        lineage: {
            ledgerMaxSerial: ledger.maxSerial,
            ledgerTotal: ledger.total,
            ledgerOldestAt: ledger.oldestAt
        },
        rssMB: Math.round(mem.rss / 1048576),
        heapUsedMB: Math.round(mem.heapUsed / 1048576),
        heapTotalMB: Math.round(mem.heapTotal / 1048576),
        memAvailableMB: memAvailableMB(),
        ramShed: (()=>{
            // RAM-SHED-20261024 governor telemetry — the in-app lane that
            // pre-empts kernel OOM-kill with a controlled warm-cache recycle.
            const st = globalThis.__nexusRamShed;
            return st ? {
                ver: st.ver,
                recycles: st.recycles,
                sheds: st.sheds,
                lastRecycleAt: st.lastRecycleAt || null,
                lastShedAt: st.lastShedAt || null
            } : null;
        })(),
        watchdogLayer1: p0WatchdogStatus(),
        watchdogLayer2: layer2Status()
    }, {
        headers: {
            "Cache-Control": "no-store"
        }
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__95767b9f._.js.map