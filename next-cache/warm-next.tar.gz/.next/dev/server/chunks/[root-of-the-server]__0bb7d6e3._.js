module.exports = [
"[externals]/node:process [external] (node:process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:process", () => require("node:process"));

module.exports = mod;
}),
"[externals]/node:fs [external] (node:fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs", () => require("node:fs"));

module.exports = mod;
}),
"[project]/src/instrumentation.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo v8.3 server instrumentation ──────────────────────────────
// Runs once per server process boot (Node.js runtime only). This is where the
// Telegram communication bridge long-poller is started — the main app process
// is kept alive by the keep-alive cron (job 354312), so hosting the poller
// here avoids yet another separate mini-service process to babysit.
__turbopack_context__.s([
    "register",
    ()=>register
]);
async function register() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    // ── v12.12 undici TLS-teardown guard (SENTINEL-M0M2-20261024) ─────────────
    // 59× `uncaughtException: AssertionError false==true` from
    // node:internal/deps/undici (Parser.finish / TLSSocket.onHttpSocketEnd):
    // a peer closes the TLS connection mid-response and undici's parser races
    // its own assertion during cleanup. The response is already dead — the
    // assertion carries ZERO recovery value, but an unguarded path can take the
    // whole server down. Swallow ONLY this exact signature (throttled log),
    // let every other uncaughtException fall through to Next's own handler.
    try {
        let undiciSwallowed = 0;
        let lastUndiciLogAt = 0;
        process.on("uncaughtException", (err)=>{
            const isUndiciAssert = err instanceof Error && err.name === "AssertionError" && /undici/.test(err.stack ?? "");
            if (!isUndiciAssert) return; // not ours — existing handlers own it
            undiciSwallowed++;
            const now = Date.now();
            if (now - lastUndiciLogAt >= 60_000) {
                lastUndiciLogAt = now;
                console.warn(`[instrumentation] undici TLS-teardown assertion swallowed ×${undiciSwallowed} — process kept alive (v12.12)`);
            }
        });
    } catch  {
    /* guard must never break boot */ }
    try {
        const bridge = await __turbopack_context__.A("[project]/src/lib/telegram-bridge.ts [instrumentation] (ecmascript, async loader)");
        bridge.startBridgePoller();
    } catch (err) {
        console.error("[instrumentation] telegram-bridge bootstrap failed", err);
    }
    // ── v13.1 RAM-SHED governor (RAM-SHED-20261024) ───────────────────────────
    // Box: 4GB / NO swap. 2026-10-24 16:29→16:59Z: FIVE kernel OOM-kills of
    // next-server in 30 minutes (dmesg anon-rss 2.03-2.35GB), two of them
    // triggered by `git pack-objects` during routine commits and one by
    // tokio/caddy. All soft caps ALREADY exist (V8 768MB via dev-up v9.2
    // envelope, turbopack native 384MiB via next.config EQ-98) yet dev-mode
    // residue (module graph, postcss worker 447MB, GC lag) keeps ramping RSS
    // until the kernel shoots — and the kernel kill is the WORST possible
    // recycle: random timing, takes down whoever invoked the oom-killer, and
    // races mem-guard's own ladder.
    // Doctrine: a CONTROLLED self-recycle while the .next cache is warm (5s
    // gap; heal chain p0-watchdog :3020 → dev-up probe-gated spawn, proven
    // dozens of times today) beats a random kernel kill every time. This
    // governor ONLY acts earlier than the kernel — it never kills a healthy
    // process: every threshold requires sustained pressure AND (for the
    // primary lane) a real MemAvailable squeeze. Boot grace 300s — never
    // interfere with warm hydration.
    try {
        const g = globalThis;
        g.__nexusRamShed ??= {
            ver: "ram-shed v13.1",
            lastShedAt: 0,
            lastRecycleAt: 0,
            recycles: 0,
            sheds: 0,
            rssMB: 0,
            availMB: 0
        };
        const BOOT_AT = Date.now();
        const GRACE_MS = 300_000; // 5min boot grace
        const TICK_MS = 15_000;
        const highStart = {
            a: 0,
            b: 0
        }; // sustained-pressure streak clocks (ms)
        let lastHeartbeat = 0;
        // v13.3 P2 (trace 1a193604acd890f9): namespace-import node:process and use
        // nodeProc.* — Turbopack's Edge-Runtime static analyzer flagged the GLOBAL
        // process.exit/memoryUsage member-access (≈200 chronic dev.log warning
        // lines per compile) even though this whole block is nodejs-guarded.
        // Same object, same semantics — only the analyzer's view changes.
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const nodeProc = __turbopack_context__.r("[externals]/node:process [external] (node:process, cjs)");
        const availMB = ()=>{
            try {
                // eslint-disable-next-line @typescript-eslint/no-require-imports
                const m = __turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)").readFileSync("/proc/meminfo", "utf8");
                const hit = m.match(/^MemAvailable:\s+(\d+) kB/m);
                return hit ? Math.round(parseInt(hit[1], 10) / 1024) : 9999;
            } catch  {
                return 9999;
            }
        };
        const timer = setInterval(()=>{
            try {
                const st = g.__nexusRamShed;
                if (Date.now() - BOOT_AT < GRACE_MS) return;
                st.rssMB = Math.round(nodeProc.memoryUsage().rss / 1048576);
                st.availMB = availMB();
                const now = Date.now();
                // telemetry heartbeat every 5min — always visible in dev.log
                if (now - lastHeartbeat >= 300_000) {
                    lastHeartbeat = now;
                    console.log(`[ram-shed] heartbeat rss=${st.rssMB}MB avail=${st.availMB}MB recycles=${st.recycles} sheds=${st.sheds}`);
                }
                // LANE 1 — soft shed: trim discretionary caches before pressure builds
                if ((st.availMB < 420 || st.rssMB > 1800) && typeof g.__nexusShed === "function" && now - st.lastShedAt >= 60_000) {
                    const freed = g.__nexusShed();
                    st.lastShedAt = now;
                    st.sheds += 1;
                    console.warn(`[ram-shed] shed#${st.sheds} freed=${freed} cache entries rss=${st.rssMB}MB avail=${st.availMB}MB`);
                }
                // LANE 2 — controlled self-recycle (pre-empting the kernel OOM-killer):
                //   A) rss>2100 sustained 90s AND avail<330 — the pre-kill profile
                //      (all five dmesg kills today landed at avail 89-244); tuned to
                //      sit BETWEEN mem-guard's deep-valley recycle (avail<300×6) and
                //      the kernel trigger — no lane duplication, no treadmill.
                //   B) rss>2300 sustained 120s regardless of avail — hard plateau;
                //      mem-guard only sees this shape WITH avail<300, this lane adds
                //      the RSS-only backstop the guard cannot fire on its own.
                //   C) avail<120 single tick (kernel-imminent; mem-guard acts at <130
                //      but races are lethal — exit first, heal chain brings us back).
                const laneA = st.rssMB > 2100 && st.availMB < 330;
                const laneB = st.rssMB > 2300;
                const laneC = st.availMB < 120;
                // streak clocks reset the moment their lane pressure clears (hysteresis)
                if (!laneA) highStart.a = 0;
                if (!laneB) highStart.b = 0;
                if (laneA && highStart.a === 0) highStart.a = now;
                if (laneB && highStart.b === 0) highStart.b = now;
                if (laneA && now - highStart.a >= 90_000) {
                    st.lastRecycleAt = now;
                    st.recycles += 1;
                    console.error(`[ram-shed] SELF-RECYCLE#${st.recycles} lane=A rss=${st.rssMB}MB avail=${st.availMB}MB held=90s — controlled exit, warm-cache heal expected ≤45s (RAM-SHED-20261024)`);
                    nodeProc.exit(0);
                }
                if (laneB && now - highStart.b >= 120_000) {
                    st.lastRecycleAt = now;
                    st.recycles += 1;
                    console.error(`[ram-shed] SELF-RECYCLE#${st.recycles} lane=B rss=${st.rssMB}MB held=120s — hard plateau, controlled exit (RAM-SHED-20261024)`);
                    nodeProc.exit(0);
                }
                if (laneC) {
                    st.lastRecycleAt = now;
                    st.recycles += 1;
                    console.error(`[ram-shed] SELF-RECYCLE#${st.recycles} lane=C avail=${st.availMB}MB single-tick — kernel-imminent, controlled exit (RAM-SHED-20261024)`);
                    nodeProc.exit(0);
                }
            } catch  {
            /* the governor must never crash the process it guards */ }
        }, TICK_MS);
        timer.unref?.();
    } catch  {
    /* governor must never break boot */ }
    // 2026-09-21 resilience rails — boot-time belt-and-braces alongside the
    // pulse wiring (the pulse is the primary driver; these catch the case of a
    // booted-but-never-pulsed process). Both internally throttled + fail-soft.
    try {
        const guard = await __turbopack_context__.A("[project]/src/lib/env-guard.ts [instrumentation] (ecmascript, async loader)");
        const scheduler = await __turbopack_context__.A("[project]/src/lib/daily-scheduler.ts [instrumentation] (ecmascript, async loader)");
        setTimeout(()=>{
            void guard.maybeEnsureEnv().catch(()=>undefined);
            void scheduler.maybeRunScheduledReports().catch(()=>undefined);
            setInterval(()=>{
                void guard.maybeEnsureEnv().catch(()=>undefined);
                void scheduler.maybeRunScheduledReports().catch(()=>undefined);
            }, 5 * 60_000);
        }, 20_000).unref?.();
    } catch  {
    /* rails must never break boot */ }
    // ── P0-b FWD-SETTLE cadence (FWD-SETTLE-20261025) ──────────────────────────
    // Server-side revival of the dead forward-return settle loop. Until now
    // VolCauseEvent settlement only ran when a dashboard client happened to poll
    // /api/vol-cause (the VolCauseCard was unmounted by the sensor-bus dormant
    // consolidation ~09-19 → loop dead for a month), and FuturesSnapshot
    // settlement head-of-line blocked on unfetchable sparse-era rows. This
    // cadence is SEPARATE from the ram-shed governor above (that block and its
    // globalThis state stay untouched): every 15 minutes it settles pending
    // VolCauseEvent fwd2h/6h + FuturesSnapshot fwd15m/1h/4h, then refreshes the
    // volcause.study learning row. Turbopack can re-run instrumentation on
    // HMR/boot → double-registration is guarded by a globalThis flag.
    try {
        const g = globalThis;
        if (!g.__nexusFwdSettle) {
            g.__nexusFwdSettle = {
                ver: "fwd-settle v1.0 (P0-b)",
                startedAt: Date.now(),
                runs: 0,
                lastRunAt: 0,
                lastSettled: 0,
                lastError: null
            };
            const st = g.__nexusFwdSettle;
            const HEARTBEAT_DIR = ".data/settle-loop";
            const heartbeat = (line)=>{
                try {
                    // eslint-disable-next-line @typescript-eslint/no-require-imports
                    const fs = __turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)");
                    fs.mkdirSync(HEARTBEAT_DIR, {
                        recursive: true
                    });
                    fs.appendFileSync(`${HEARTBEAT_DIR}/heartbeat.txt`, `${line}\n`);
                } catch  {
                /* telemetry must never break the cadence */ }
            };
            const runOnce = async ()=>{
                const at = new Date().toISOString();
                let vc = 0;
                let fs = 0;
                let fail = 0;
                let err = null;
                try {
                    const volCause = await __turbopack_context__.A("[project]/src/lib/volCause.ts [instrumentation] (ecmascript, async loader)");
                    vc = await volCause.settlePendingVolCauses().catch(()=>0);
                } catch (e) {
                    err = e instanceof Error ? e.message : String(e);
                }
                try {
                    const settle = await __turbopack_context__.A("[project]/src/lib/futures-snapshot-settle.ts [instrumentation] (ecmascript, async loader)");
                    const r = await settle.settlePendingFuturesSnapshots();
                    fs = r.settled;
                    fail = r.failed;
                    if (r.floorAdvanced) console.warn("[fwd-settle] skip-floor advanced — whole batch unresolvable, queue unblocked");
                } catch (e) {
                    err = e instanceof Error ? e.message : String(e);
                }
                try {
                    const volCause = await __turbopack_context__.A("[project]/src/lib/volCause.ts [instrumentation] (ecmascript, async loader)");
                    void volCause.learnVolCauses().catch(()=>undefined); // refresh the learning row after settlement
                } catch  {
                /* learning is best-effort */ }
                st.runs++;
                st.lastRunAt = Date.now();
                st.lastSettled = vc + fs;
                st.lastError = err;
                const line = `${at} volCause=${vc} futures=${fs} failed=${fail}${err ? ` error=${err}` : ""}`;
                console.log(`[fwd-settle] cadence#${st.runs} ${line}`);
                heartbeat(line);
            };
            // first pass ~90s after boot (stay out of the warm-hydration window),
            // then a steady 15-minute cadence — both unref'd so they never hold the
            // process open, both fully try/catch-wrapped inside runOnce.
            setTimeout(()=>{
                void runOnce().catch(()=>undefined);
            }, 90_000).unref?.();
            setInterval(()=>{
                void runOnce().catch(()=>undefined);
            }, 15 * 60_000).unref?.();
            console.log("[fwd-settle] cadence registered (15min, first run +90s) — P0-b FWD-SETTLE-20261025");
        }
    } catch  {
    /* cadence must never break boot */ }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0bb7d6e3._.js.map