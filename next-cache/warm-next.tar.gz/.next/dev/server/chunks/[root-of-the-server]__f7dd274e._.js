module.exports = [
"[project]/src/lib/flow-scanner.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_engine_ts_807dd0f4._.js",
  "server/chunks/src_lib_8ba8a62b._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/flow-scanner.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/oi-funding.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__fb6c5005._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/oi-funding.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_d2d68b55._.js",
  "server/chunks/[root-of-the-server]__ba7bb8ea._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/raw-cal.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ebed90ed._.js",
  "server/chunks/src_lib_engine_ts_a868ea96._.js",
  "server/chunks/src_lib_99e156e4._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__8d16f881._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/engine.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/notify.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__657bae63._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/notify.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/lifecycle-learning.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_engine_ts_807dd0f4._.js",
  "server/chunks/[root-of-the-server]__8e506e26._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/lifecycle-learning.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/shadow-veto.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__92ea5ce4._.js",
  "server/chunks/[root-of-the-server]__448f0d4e._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/shadow-veto.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/calibration.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_7e3fb435._.js",
  "server/chunks/[root-of-the-server]__d5cdc743._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/calibration.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/tp3-lab.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__6488a181._.js",
  "server/chunks/[root-of-the-server]__e1fd84c6._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/tp3-lab.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/persist-guard.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__87f635a4._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/persist-guard.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/ai.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/_451efd7a._.js",
  "server/chunks/[root-of-the-server]__ea2bf620._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/ai.ts [instrumentation] (ecmascript)");
    });
});
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[externals]_node:fs_promises_ef82023e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
    });
});
}),
"[project]/src/lib/governor.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__dc938cc7._.js",
  "server/chunks/src_lib_engine_ts_a868ea96._.js",
  "server/chunks/src_lib_104a2e9e._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__087147ff._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/governor.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/supervisor.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_bd2c2b1f._.js",
  "server/chunks/[root-of-the-server]__f29d6ab9._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/supervisor.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/advisor.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ebed90ed._.js",
  "server/chunks/src_lib_engine_ts_a868ea96._.js",
  "server/chunks/src_lib_26ed6c07._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__8d16f881._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/advisor.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/shadow-modules.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ebed90ed._.js",
  "server/chunks/src_lib_engine_ts_a868ea96._.js",
  "server/chunks/src_lib_44264a04._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__8d16f881._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/shadow-modules.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/stableflow.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__5b3a6535._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/stableflow.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/futures-taxonomy.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__a358f258._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/futures-taxonomy.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/verdict.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__6488a181._.js",
  "server/chunks/[root-of-the-server]__ea4c1ab6._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/verdict.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/pump-performance.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__187ea105._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/pump-performance.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/rawcal-quality.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_7e3fb435._.js",
  "server/chunks/[root-of-the-server]__2ef4da8a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/rawcal-quality.ts [instrumentation] (ecmascript)");
    });
});
}),
];