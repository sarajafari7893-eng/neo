module.exports = [
"[project]/src/lib/gate-journal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "gateJournalForCore",
    ()=>gateJournalForCore,
    "gateJournalHealth",
    ()=>gateJournalHealth,
    "gateJournalReady",
    ()=>gateJournalReady,
    "gateJournalRefresh",
    ()=>gateJournalRefresh,
    "gateLive",
    ()=>gateLive,
    "gateRecentBlocks",
    ()=>gateRecentBlocks,
    "gateRecentDeploys",
    ()=>gateRecentDeploys,
    "gateStats",
    ()=>gateStats,
    "recordGateBlock",
    ()=>recordGateBlock,
    "recordGateDeploy",
    ()=>recordGateDeploy,
    "recordGateSamples",
    ()=>recordGateSamples
]);
// ── FlowRadar Neo GATE JOURNAL + GAUGE ENGINE (server-only, v8.2) ──
// Operator mandate (2026-09-08): «یک موتور گیج اضافه کن تا بصورت زنده داده
// هایی که به مرز تایید یا رد شدن سیگنال میرسند را نشان دهد و جورنال را به
// هسته مرکزی برای یادگیری عمیق از دلایل ارسال کند».
//
// Every deploy-signal() threshold verdict is journaled here with its FULL
// reason payload: the signed confluence votes (confirm vs oppose), every
// threshold modifier (regime / BTC-spill / chase / MTF-board / liq-heat),
// the effective threshold it faced, and the distance-to-gate. Hard gate
// blocks (memory/strategy/learned/flow/onset-retest/risk-cluster) and
// actual deployments are recorded too — so the boundary band between
// CONFIRM and REJECT becomes a measurable, learnable dataset instead of
// a one-line 409 error.
//
// Storage: in-memory rings (fast, capped) + append-only JSONL
// (.data/gate-journal.jsonl) so history survives dev recompiles and
// restarts, and the central AI core can be fed the exact same records.
// No SQLite writes — the single-writer discipline stays untouched.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
;
;
// ── storage ───────────────────────────────────────────────────
const SAMPLE_CAP = 8000;
const BLOCK_CAP = 800;
const DEPLOY_CAP = 300;
const BOUNDARY_DEDUP_MS = 60_000; // per symbol|direction — boundary state persists tick after tick
const REJECT_DEDUP_MS = 150_000;
const PASS_DEDUP_MS = 60_000; // PASS verdicts change slowly too — keep the ring dense with boundary data
const BLOCK_DEDUP_MS = 120_000;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "gate-journal.jsonl");
const FILE_MAX_BYTES = 8 * 1024 * 1024;
const samples = [];
const blocks = [];
const deploys = [];
const lastAccepted = new Map();
let persisted = 0;
let hydrating = null;
// v8.2.1 SPLIT-BRAIN COUNTERMEASURE — Turbopack dev compiles one module
// instance PER ROUTE: the engine tick's instance writes the JSONL while a
// freshly-compiled read route starts with EMPTY rings and (before this fix)
// never hydrated, because hydration was only triggered from write paths.
// readPos tracks how many bytes of the JSONL this instance has already
// ingested, so reads can TAIL the file incrementally no matter which
// instance is doing the writing (including our own — persist() advances
// readPos so records we wrote ourselves are never re-ingested).
let readPos = 0;
let hydratedAt = 0; // epoch ms of the last successful hydrate/refresh — 0 = cold rings
let refreshing = null;
let lastRefreshAt = 0;
const REFRESH_MIN_INTERVAL_MS = 10_000;
const REFRESH_MAX_BITE = 512 * 1024; // bounded bite per refresh
const seenSerials = new Set(); // deploy serials ingested (hydrate + refresh) — cross-instance deploy dedupe
async function hydrate() {
    if (hydrating) return hydrating;
    hydrating = (async ()=>{
        try {
            const buf = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(FILE, "utf8").catch(()=>"");
            if (!buf) return;
            const lines = buf.split("\n").filter(Boolean);
            const tail = lines.slice(-6000); // bounded restore
            for (const line of tail){
                try {
                    const rec = JSON.parse(line);
                    if (rec.k === "s" && samples.length < SAMPLE_CAP) samples.push(rec.v);
                    else if (rec.k === "b" && blocks.length < BLOCK_CAP) blocks.push(rec.v);
                    else if (rec.k === "d" && deploys.length < DEPLOY_CAP) deploys.push(rec.v);
                } catch  {
                /* skip torn line */ }
            }
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            persisted = st?.size ?? 0;
            // the whole file has been consumed (tail kept) — mark the read position
            readPos = st?.size ?? 0;
            hydratedAt = Date.now();
            // prime the dedup map from the hydrated history so a freshly-compiled
            // instance does not instantly re-accept everything another instance
            // journaled seconds ago (dedup continuity across instance swaps)
            for (const s of samples){
                const key = `${s.symbol}|${s.direction}|${s.band}`;
                const prev = lastAccepted.get(key) ?? 0;
                if (s.at > prev) lastAccepted.set(key, s.at);
            }
            for (const b of blocks){
                const key = `${b.gate}|${b.symbol ?? "*"}`;
                const prev = lastAccepted.get(key) ?? 0;
                if (b.at > prev) lastAccepted.set(key, b.at);
            }
            for (const d of deploys)if (d.serial > 0) seenSerials.add(d.serial);
            if ((st?.size ?? 0) > FILE_MAX_BYTES) {
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
                persisted = 0; // (was a stale-size bug: rotation must reset the counter)
                readPos = 0;
            }
        } catch  {
        /* fresh start — journaling must never break the engine */ }
    })();
    return hydrating;
}
async function persist(rec) {
    try {
        const line = JSON.stringify(rec) + "\n";
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(FILE, line, "utf8");
        persisted += line.length;
        readPos += line.length; // our own bytes are already in the rings — never re-ingest
        if (persisted > FILE_MAX_BYTES) {
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
            persisted = 0;
            readPos = 0;
        }
    } catch  {
    /* non-fatal */ }
}
async function gateJournalReady() {
    await hydrate();
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
            recursive: true
        });
    } catch  {
    /* exists */ }
}
async function gateJournalRefresh(maxAgeMs = REFRESH_MIN_INTERVAL_MS) {
    if (Date.now() - lastRefreshAt < maxAgeMs) return;
    if (refreshing) return refreshing;
    refreshing = (async ()=>{
        try {
            // VERDICT-CORE audit 2026-11-05 — COLD-GENERATION READ FIX: hydrate() only
            // ran on WRITE paths, so a freshly-compiled read generation started with
            // readPos=0 and tailed the file's OLDEST bytes (11-03 history) — 12h-window
            // stats came back EMPTY and the core wrote "journal is empty" (observed live
            // on cycle #1412's first POST). Hydrate cold generations here (once, single-
            // flight, readPos=file-size) so the first refresh already sees the freshest
            // 6000-line history. Warm generations (hydratedAt>0) are untouched — re-running
            // hydrate on them would re-push tail records into the rings.
            if (hydratedAt === 0) await hydrate();
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            if (!st) return;
            if (st.size < readPos) readPos = 0; // rotated — restart the tail on the fresh file
            if (st.size === readPos) return;
            const len = Math.min(st.size - readPos, REFRESH_MAX_BITE);
            const fh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(FILE, "r").catch(()=>null);
            if (!fh) return;
            try {
                const buf = Buffer.alloc(len);
                const { bytesRead } = await fh.read(buf, 0, len, readPos);
                let text = buf.toString("utf8", 0, bytesRead);
                const lastNl = text.lastIndexOf("\n");
                if (lastNl === -1) return; // partial line at the tail — wait for the writer
                text = text.slice(0, lastNl + 1); // only consume COMPLETE lines
                readPos += Buffer.byteLength(text, "utf8");
                for (const line of text.split("\n")){
                    if (!line) continue;
                    try {
                        const rec = JSON.parse(line);
                        if (rec.k === "s") {
                            const s = rec.v;
                            // v8.2.1 ingest discipline — a SECOND module instance may write the
                            // same verdict; apply the exact same dedup rule as recordGateSamples
                            // so rings/stats stay honest no matter the writer
                            const key = `${s.symbol}|${s.direction}|${s.band}`;
                            const interval = s.band === "BOUNDARY" ? BOUNDARY_DEDUP_MS : s.band === "REJECT" ? REJECT_DEDUP_MS : PASS_DEDUP_MS;
                            const last = lastAccepted.get(key) ?? 0;
                            if (interval && s.at - last < interval) continue;
                            lastAccepted.set(key, s.at);
                            samples.push(s);
                            if (samples.length > SAMPLE_CAP) samples.splice(0, samples.length - SAMPLE_CAP);
                        } else if (rec.k === "b") {
                            const b = rec.v;
                            const key = `${b.gate}|${b.symbol ?? "*"}`;
                            if (b.at - (lastAccepted.get(key) ?? 0) < BLOCK_DEDUP_MS) continue;
                            lastAccepted.set(key, b.at);
                            blocks.push(b);
                            if (blocks.length > BLOCK_CAP) blocks.splice(0, blocks.length - BLOCK_CAP);
                        } else if (rec.k === "d") {
                            const d = rec.v;
                            if (d.serial > 0 && seenSerials.has(d.serial)) continue; // duplicate deploy from another instance
                            if (d.serial > 0) seenSerials.add(d.serial);
                            deploys.push(d);
                            if (deploys.length > DEPLOY_CAP) deploys.splice(0, deploys.length - DEPLOY_CAP);
                        }
                    } catch  {
                    /* torn line */ }
                }
                hydratedAt = Date.now();
            } finally{
                await fh.close().catch(()=>undefined);
            }
        } catch  {
        /* non-fatal — reads must never break */ } finally{
            lastRefreshAt = Date.now();
        }
    })().finally(()=>{
        refreshing = null;
    });
    return refreshing;
}
// ── recording ─────────────────────────────────────────────────
function bandOf(gap, passed) {
    if (passed) return "PASS";
    return gap >= -8 ? "BOUNDARY" : "REJECT";
}
async function recordGateSamples(batch) {
    if (batch.length === 0) return;
    await hydrate();
    const now = Date.now();
    let bestGap = Infinity;
    let bestIdx = -1;
    const enriched = batch.map((b, i)=>{
        const gap = Math.abs(b.score) - b.effMin;
        if (Math.abs(gap) < bestGap) {
            bestGap = Math.abs(gap);
            bestIdx = i;
        }
        return {
            ...b,
            at: now,
            gap,
            band: bandOf(gap, b.passed)
        };
    });
    for(let i = 0; i < enriched.length; i++){
        const s = enriched[i];
        const key = `${s.symbol}|${s.direction}|${s.band}`;
        const interval = s.band === "BOUNDARY" ? BOUNDARY_DEDUP_MS : s.band === "REJECT" ? REJECT_DEDUP_MS : PASS_DEDUP_MS;
        const last = lastAccepted.get(key) ?? 0;
        if (interval && now - last < interval) continue;
        lastAccepted.set(key, now);
        const rec = {
            at: s.at,
            symbol: s.symbol,
            direction: s.direction,
            strategy: s.strategy,
            score: s.score,
            effMin: s.effMin,
            baseMin: s.baseMin,
            gap: s.gap,
            band: s.band,
            thr: s.thr,
            confirms: s.confirms,
            opposes: s.opposes,
            notes: s.notes,
            source: s.source,
            best: i === bestIdx
        };
        samples.push(rec);
        if (samples.length > SAMPLE_CAP) samples.splice(0, samples.length - SAMPLE_CAP);
        void persist({
            k: "s",
            v: rec
        });
    }
}
async function recordGateBlock(b) {
    await hydrate();
    const now = Date.now();
    const key = `${b.gate}|${b.symbol ?? "*"}`;
    if (now - (lastAccepted.get(key) ?? 0) < BLOCK_DEDUP_MS) return;
    lastAccepted.set(key, now);
    const rec = {
        ...b,
        at: now
    };
    blocks.push(rec);
    if (blocks.length > BLOCK_CAP) blocks.splice(0, blocks.length - BLOCK_CAP);
    void persist({
        k: "b",
        v: rec
    });
}
async function recordGateDeploy(d) {
    await hydrate();
    const rec = {
        ...d,
        at: Date.now()
    };
    deploys.push(rec);
    if (deploys.length > DEPLOY_CAP) deploys.splice(0, deploys.length - DEPLOY_CAP);
    void persist({
        k: "d",
        v: rec
    });
}
function gateLive(limit = 16) {
    const latest = new Map();
    for (const s of samples)latest.set(`${s.symbol}|${s.direction}`, s); // rings are append-ordered
    const rank = (b)=>b === "BOUNDARY" ? 0 : b === "PASS" ? 1 : 2;
    return [
        ...latest.values()
    ].sort((a, b)=>rank(a.band) - rank(b.band) || Math.abs(a.gap) - Math.abs(b.gap)).slice(0, limit);
}
function gateStats(windowHours = 6) {
    const since = Date.now() - windowHours * 3600_000;
    const win = samples.filter((s)=>s.at >= since);
    const byBand = {
        PASS: 0,
        BOUNDARY: 0,
        REJECT: 0
    };
    for (const s of win)byBand[s.band]++;
    const agg = (list, pick)=>{
        const m = new Map();
        for (const s of list)for (const f of pick(s)){
            const e = m.get(f.factor) ?? {
                n: 0,
                sum: 0,
                last: null
            };
            e.n++;
            e.sum += f.vote;
            if (f.detail) e.last = f.detail;
            m.set(f.factor, e);
        }
        return m;
    };
    const toAgg = (m)=>[
            ...m.entries()
        ].map(([factor, e])=>({
                factor,
                count: e.n,
                avgVote: Number((e.sum / e.n).toFixed(2)),
                lastDetail: e.last
            })).sort((a, b)=>b.count - a.count);
    const confirmAgg = toAgg(agg(win, (s)=>s.confirms));
    const opposeAgg = toAgg(agg(win, (s)=>s.opposes));
    const thrNames = [
        "regime",
        "spill",
        "chase",
        "mtf",
        "liq",
        "lesson"
    ];
    const thrModifiers = thrNames.map((name)=>{
        const vals = win.map((s)=>s.thr[name]).filter((v)=>v !== undefined && v !== 0);
        return {
            name,
            count: vals.length,
            avg: vals.length ? Number((vals.reduce((a, b)=>a + b, 0) / vals.length).toFixed(2)) : 0
        };
    }).filter((t)=>t.count > 0);
    const blockMap = new Map();
    for (const b of blocks){
        if (b.at < since) continue;
        const e = blockMap.get(b.gate) ?? {
            count: 0,
            lastReason: b.reason
        };
        e.count++;
        e.lastReason = b.reason;
        blockMap.set(b.gate, e);
    }
    const deploysWin = deploys.filter((d)=>d.at >= since);
    const boundaryN = byBand.BOUNDARY;
    return {
        windowHours,
        samples: win.length,
        byBand,
        boundary: boundaryN > 0 ? {
            avgGap: Number((win.filter((s)=>s.band === "BOUNDARY").reduce((a, s)=>a + s.gap, 0) / boundaryN).toFixed(2)),
            worstGap: Math.max(...win.filter((s)=>s.band === "BOUNDARY").map((s)=>s.gap)),
            sharePct: Number((boundaryN / Math.max(1, win.length) * 100).toFixed(1))
        } : null,
        confirmReasons: confirmAgg.slice(0, 6),
        opposeReasons: opposeAgg.slice(0, 6),
        thrModifiers,
        blocks: [
            ...blockMap.entries()
        ].map(([gate, e])=>({
                gate,
                count: e.count,
                lastReason: e.lastReason
            })).sort((a, b)=>b.count - a.count),
        deploys: deploysWin.length,
        avgDeployScore: deploysWin.length ? Number((deploysWin.reduce((a, d)=>a + Math.abs(d.score), 0) / deploysWin.length).toFixed(1)) : null,
        blocksRingSize: blocks.length,
        blocksRingSaturated: blocks.length >= BLOCK_CAP
    };
}
function gateRecentBlocks(limit = 8) {
    return blocks.slice(-limit).reverse();
}
function gateRecentDeploys(limit = 6) {
    return deploys.slice(-limit).reverse();
}
function gateJournalHealth() {
    return {
        samples: samples.length,
        blocks: blocks.length,
        deploys: deploys.length,
        fileKB: Math.round(persisted / 1024),
        hydratedAt
    };
}
async function gateJournalForCore(windowHours = 12, maxBoundary = 8) {
    await gateJournalReady(); // hydrate cold generations BEFORE tailing (audit 2026-11-05: read-path emptiness fix)
    await gateJournalRefresh(0); // grounding consumers always see fresh rings
    const stats = gateStats(windowHours);
    const nearGate = samples.filter((s)=>s.at >= Date.now() - windowHours * 3600_000 && s.band === "BOUNDARY").sort((a, b)=>b.at - a.at).slice(0, maxBoundary);
    const boundaryFiles = nearGate.map((s)=>{
        const conf = s.confirms.map((f)=>`${f.factor}${f.vote >= 0 ? "+" : ""}${f.vote}`).join(",") || "n/a";
        const opp = s.opposes.map((f)=>`${f.factor}${f.vote >= 0 ? "+" : ""}${f.vote}`).join(",") || "n/a";
        const thr = Object.entries(s.thr).filter(([, v])=>v !== 0).map(([k, v])=>`${k}${v > 0 ? "+" : ""}${v}`).join(" ") || "none";
        return `${new Date(s.at).toISOString()} ${s.symbol} ${s.direction} ${s.strategy} score ${s.score.toFixed(1)} vs eff ${s.effMin} (gap ${s.gap >= 0 ? "+" : ""}${s.gap.toFixed(1)}) · thr mods: ${thr} · confirms: ${conf} · opposes: ${opp}`;
    });
    const blockFiles = gateRecentBlocks(6).map((b)=>`${new Date(b.at).toISOString()} ${b.gate}${b.symbol ? ` ${b.symbol}` : ""} — ${b.reason.slice(0, 140)}`);
    const topConfirm = stats.confirmReasons[0];
    const topOppose = stats.opposeReasons[0];
    const narrative = [
        `${stats.samples} threshold verdicts in ${windowHours}h: ${stats.byBand.PASS} passed, ${stats.byBand.BOUNDARY} landed in the boundary band (gap −8..0, ${stats.boundary?.sharePct ?? 0}% of evaluations, avg gap ${stats.boundary?.avgGap ?? "n/a"}), ${stats.byBand.REJECT} rejected outright.`,
        `Dominant confirm factor: ${topConfirm ? `${topConfirm.factor} (×${topConfirm.count}, avg ${topConfirm.avgVote})` : "n/a"}. Dominant oppose factor: ${topOppose ? `${topOppose.factor} (×${topOppose.count}, avg ${topOppose.avgVote})` : "n/a"}.`,
        `Threshold modifiers live: ${stats.thrModifiers.map((t)=>`${t.name}×${t.count} avg ${t.avg >= 0 ? "+" : ""}${t.avg}`).join(" · ") || "none"}.`,
        `Hard blocks: ${stats.blocks.map((b)=>`${b.gate}×${b.count}`).join(" · ") || "none"}.${stats.blocksRingSaturated ? ` [BLOCK-RING SATURATED at ${stats.blocksRingSize} — these counts are the newest ~${stats.blocksRingSize} accepted records only (≈60-90min of churn), NOT the full ${windowHours}h census; single-key gates (MEMORY) are dedup-compressed while multi-symbol gates (REGIME) fan out — treat as recent-churn snapshot]` : ""} Deployed: ${stats.deploys}${stats.avgDeployScore !== null ? ` (avg |score| ${stats.avgDeployScore})` : ""}.`
    ].join(" ");
    return {
        narrative,
        stats,
        boundaryFiles,
        blockFiles,
        boundarySamples: nearGate
    };
}
}),
"[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fourpackNarrative",
    ()=>fourpackNarrative,
    "fourpackRefresh",
    ()=>fourpackRefresh,
    "getFourPackDoc",
    ()=>getFourPackDoc,
    "getFourPackTail",
    ()=>getFourPackTail,
    "recordFourPack",
    ()=>recordFourPack
]);
// ── FlowRadar Neo v10.8 — FOUR-PACK GOVERNANCE JOURNAL (server-only) ────────
// Operator mandate (2026-09-15/16): the GOVERNOR MODULES FOUR-PACK (R1
// RISK-GOVERNOR · R2 TIME-GOVERNOR · R5 UI-CANARY · R6 SENIOR-REVIEW) keeps
// its verdicts as small in-memory rings buried inside each module's own
// EngineSetting blob. This module gives the pack ONE retrievable, auditable
// JSON journal doctrine — the same discipline the gate-journal (v8.2) and
// sv-telemetry (v10.2) already follow:
//   · append-only JSONL  .data/fourpack-journal.jsonl  (6MB rotate → .old)
//   · atomic latest-file .data/fourpack-latest.json    (tmp→rename)
//   · in-memory ring (fast reads) + tail-ingest hydration so Turbopack's
//     per-route module split-brain never shows a stale journal.
// Supervision verdict (delivered to operator): the four modules are
// deterministic, shadow-first, clamped and audited — they do NOT need a new
// autonomous agent/central-intelligence control loop on top. What they needed
// is THIS: a machine-readable doctrine file the central AI core (verdict-core
// / tp3-lab grounding) and the operator (download) can both study.
//
// Dependency-free (node:fs only) — the module writers call recordFourPack();
// read routes call fourpackRefresh() then getFourPackTail()/getFourPackDoc().
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
;
;
const RING_CAP = 600;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "fourpack-journal.jsonl");
const FILE_MAX_BYTES = 6 * 1024 * 1024;
const LATEST = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "fourpack-latest.json");
const ring = [];
let persisted = 0;
let readPos = 0;
let hydratedAt = 0;
let hydrating = null;
let refreshing = null;
let lastRefreshAt = 0;
const REFRESH_MIN_INTERVAL_MS = 10_000;
const REFRESH_MAX_BITE = 256 * 1024;
const MODULES = [
    "r1-risk-governor",
    "r2-time-governor",
    "r5-ui-canary",
    "r6-senior-review",
    "ops-supervisor",
    "mode"
];
async function hydrate() {
    if (hydrating) return hydrating;
    hydrating = (async ()=>{
        try {
            const buf = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(FILE, "utf8").catch(()=>"");
            if (buf) {
                const lines = buf.split("\n").filter(Boolean);
                for (const line of lines.slice(-RING_CAP)){
                    try {
                        const rec = JSON.parse(line);
                        if (rec?.v?.at && ring.length < RING_CAP) ring.push(rec.v);
                    } catch  {
                    /* torn line */ }
                }
            }
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            persisted = st?.size ?? 0;
            readPos = st?.size ?? 0;
            hydratedAt = Date.now();
            if ((st?.size ?? 0) > FILE_MAX_BYTES) {
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
                persisted = 0;
                readPos = 0;
            }
        } catch  {
        /* fresh start — journaling must never break the engine */ }
    })();
    return hydrating;
}
async function fourpackRefresh(maxAgeMs = REFRESH_MIN_INTERVAL_MS) {
    await hydrate();
    if (Date.now() - lastRefreshAt < maxAgeMs) return;
    if (refreshing) return refreshing;
    refreshing = (async ()=>{
        try {
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            if (!st) return;
            if (st.size < readPos) readPos = 0; // rotated
            if (st.size === readPos) return;
            const len = Math.min(st.size - readPos, REFRESH_MAX_BITE);
            const fh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(FILE, "r").catch(()=>null);
            if (!fh) return;
            try {
                const buf = Buffer.alloc(len);
                const { bytesRead } = await fh.read(buf, 0, len, readPos);
                let text = buf.toString("utf8", 0, bytesRead);
                const lastNl = text.lastIndexOf("\n");
                if (lastNl === -1) return;
                text = text.slice(0, lastNl + 1);
                readPos += Buffer.byteLength(text, "utf8");
                for (const line of text.split("\n")){
                    if (!line) continue;
                    try {
                        const rec = JSON.parse(line);
                        if (rec?.v?.at) {
                            ring.push(rec.v);
                            if (ring.length > RING_CAP) ring.splice(0, ring.length - RING_CAP);
                        }
                    } catch  {
                    /* torn line */ }
                }
                hydratedAt = Date.now();
            } finally{
                await fh.close().catch(()=>undefined);
            }
        } catch  {
        /* non-fatal */ } finally{
            lastRefreshAt = Date.now();
        }
    })().finally(()=>{
        refreshing = null;
    });
    return refreshing;
}
function health() {
    const counts = {};
    const lastAt = {};
    for (const m of MODULES){
        counts[m] = 0;
        lastAt[m] = 0;
    }
    for (const e of ring){
        counts[e.module] = (counts[e.module] ?? 0) + 1;
        if (e.at > (lastAt[e.module] ?? 0)) lastAt[e.module] = e.at;
    }
    return {
        counts,
        lastAt,
        fileBytes: persisted,
        rotated: false
    };
}
async function writeLatest() {
    try {
        const last = {};
        for (const m of MODULES){
            const evs = ring.filter((e)=>e.module === m);
            last[m] = evs.length ? evs[evs.length - 1] : null;
        }
        const doc = {
            schemaVersion: 1,
            at: Date.now(),
            health: health(),
            last
        };
        const tmp = `${LATEST}.tmp`;
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["writeFile"])(tmp, JSON.stringify(doc), "utf8");
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(tmp, LATEST).catch(async ()=>{
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(LATEST, "").catch(()=>undefined);
        });
    } catch  {
    /* non-fatal */ }
}
async function recordFourPack(module, kind, line, data, verdict) {
    try {
        await hydrate();
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
            recursive: true
        }).catch(()=>undefined);
        const ev = {
            at: Date.now(),
            module,
            kind,
            verdict: verdict ?? null,
            line: line.slice(0, 400),
            data
        };
        ring.push(ev);
        if (ring.length > RING_CAP) ring.splice(0, ring.length - RING_CAP);
        const rec = JSON.stringify({
            k: module,
            v: ev
        }) + "\n";
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(FILE, rec, "utf8");
        persisted += rec.length;
        readPos += rec.length; // our own bytes — never re-ingest
        if (persisted > FILE_MAX_BYTES) {
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
            persisted = 0;
            readPos = 0;
        }
        void writeLatest();
    } catch  {
    /* journaling must never break a governor cycle */ }
}
async function getFourPackTail(limit = 60) {
    await fourpackRefresh();
    return ring.slice(-limit).reverse();
}
async function getFourPackDoc(limit = 500) {
    await fourpackRefresh();
    return {
        schemaVersion: 1,
        generatedAt: new Date().toISOString(),
        health: health(),
        events: ring.slice(-limit).reverse()
    };
}
async function fourpackNarrative() {
    await fourpackRefresh();
    if (!ring.length) return "FOUR-PACK: journal empty — governor modules have not cycled yet this boot.";
    const parts = [];
    for (const m of [
        "r1-risk-governor",
        "r2-time-governor",
        "r5-ui-canary",
        "r6-senior-review"
    ]){
        const last = [
            ...ring
        ].reverse().find((e)=>e.module === m);
        if (last) {
            const ago = Math.round((Date.now() - last.at) / 60_000);
            parts.push(`${m}:${last.kind}${last.verdict ? `=${last.verdict}` : ""} (${ago}m ago) ${last.line}`);
        } else {
            parts.push(`${m}: no journal event yet`);
        }
    }
    return `FOUR-PACK JOURNAL (${ring.length} events): ${parts.join(" | ")}`;
}
}),
"[project]/src/lib/verdict.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVerdictCoreState",
    ()=>getVerdictCoreState,
    "maybeAutoVerdictLearn",
    ()=>maybeAutoVerdictLearn,
    "runVerdictLearn",
    ()=>runVerdictLearn
]);
// ── FlowRadar Neo v8.2 VERDICT-CORE (server-only) ──
// Operator mandate 2026-09-08: «...و جورنال را به هسته مرکزی برای یادگیری
// عمیق از دلایل ارسال کند، از این طریق هم موتور و هم من میتوانیم دقیقا کدام
// دلایل رد و تایید بر چه اساس است و وضعیت را بررسی کنیم.»
//
// Division of labour (converged with the parallel review loop):
//   · lib/gate-journal.ts — the CAPTURE surface: every threshold verdict,
//     hard gate block and deployment journaled (memory rings + JSONL).
//   · THIS module — the LEARNING surface: the central AI core cadence that
//     studies the journal (gateJournalForCore + shadowVetoForCore grounding),
//     derives grounded findings via the LLM research desk (aiVerdictLearn),
//     and persists the state consumed by /api/gauge (GateGaugeDTO.core) and
//     the analyst grounding. Honesty contract: only measured numbers enter
//     the bundle; since SHADOW-VETO Phase 0 (2026-09-09) the fence is
//     outcome-tracked — real linkage for hair-thin passes, clearly-labeled
//     PAPER outcomes for fence rejects.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-journal.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sv-telemetry.ts [app-route] (ecmascript)"); // v10.2 — the core studies its own feed wiring
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — the core studies the GOVERNOR FOUR-PACK journal
;
;
;
;
;
// ── DETERMINISTIC LESSON VERIFIER (VERDICT-CORE audit 2026-11-05, operator mandate)
// The LLM lesson-writer was caught twice in cycle #1410: a fabricated quantifier
// ("8/8 PUMPUSDT" — actual 1/8) and a category error (symbols called strategies).
// Contract: every numeric claim a lesson makes is re-checked against the SAME
// measured rows the model studied; failures are ANNOTATED (never silently
// rewritten) and confidence is capped (مصوبه (ج)). Fail-open — verification
// must never break the learning cycle.
const VERIFIER_SYMBOL_RE = /\b([A-Z0-9]{3,12}USDT)\b/g;
// "8/8 PUMPUSDT" AND the compressed form "8/8 boundary rejects (ZECUSDT, PUMPUSDT)"
// (cycle #1411 showed the model bridges the quantifier to the symbol with prose)
const VERIFIER_QUANT_RE = /(\d{1,3})\s*\/\s*(\d{1,3})(?:[^\n]{0,40}?)([A-Z0-9]{3,12}USDT)/g;
// census forms: "703 REGIME" (cycle #1410) AND "REGIME violations (684/800)" (cycle #1411)
const VERIFIER_BLOCK_RE = /(\d{2,7})\s+(REGIME|MEMORY|STRATEGY|LEARNED|FLOW|DECISIVE|ONSET-RETEST|RISK-CLUSTER)\b/g;
const VERIFIER_BLOCK_FRAC_RE = /\b(REGIME|MEMORY|STRATEGY|LEARNED|FLOW|DECISIVE|ONSET-RETEST|RISK-CLUSTER)\b[^.\n]{0,30}?(\d{2,7})\s*\/\s*\d{2,7}/g;
function verifyLessonFinding(finding, ctx) {
    try {
        const text = `${finding.pattern} ${finding.evidence ?? ""}`;
        const notes = [];
        let corrected = false;
        // ① quantifier check — "N/M SYMBOL" vs the boundary files actually studied
        for (const m of text.matchAll(new RegExp(VERIFIER_QUANT_RE.source, "g"))){
            const sym = m[3];
            const claimed = Number(m[1]);
            const actual = ctx.boundarySamples.filter((s)=>s.symbol === sym).length;
            if (actual < claimed) {
                corrected = true;
                notes.push(`QUANTIFIER-MISMATCH ${sym}: claimed ${m[1]}/${m[2]}, the boundary files studied contain ${actual}`);
            }
        }
        // ② hard-block census check — block counts vs a saturated ring snapshot
        //    (both word orders: "703 REGIME" and "REGIME violations (684/800)")
        const censusA = [
            ...text.matchAll(new RegExp(VERIFIER_BLOCK_RE.source, "g"))
        ].filter((m)=>Number(m[1]) >= 50).map((m)=>m[2]);
        const censusB = [
            ...text.matchAll(new RegExp(VERIFIER_BLOCK_FRAC_RE.source, "g"))
        ].filter((m)=>Number(m[2]) >= 50).map((m)=>m[1]);
        const citesBlockCensus = censusA.length > 0 || censusB.length > 0; // only census-scale numbers, not "1/7 flagged"
        if (citesBlockCensus && ctx.stats.blocksRingSaturated) {
            corrected = true;
            const gates = [
                ...new Set([
                    ...censusA,
                    ...censusB
                ])
            ].join(", ");
            notes.push(`RING-SNAPSHOT ${gates ? `(${gates}) ` : ""}block counts here are the newest ~${ctx.stats.blocksRingSize ?? 800} accepted records (≈60-90min churn), not the ${ctx.stats.windowHours}h census`);
        }
        // symbol-presence sanity: a lesson naming a symbol absent from the studied rows
        for (const m of text.matchAll(new RegExp(VERIFIER_SYMBOL_RE.source, "g"))){
            const sym = m[1];
            const inBoundary = ctx.boundarySamples.some((s)=>s.symbol === sym);
            const inBlocks = ctx.stats.blocks.some((b)=>(b.gate === "REGIME" || b.gate === "MEMORY") && b.count > 0); // weak proxy — block lastReason not per-symbol here
            if (!inBoundary && !inBlocks && ctx.boundarySamples.length > 0) {
                corrected = true;
                notes.push(`SYMBOL-UNVERIFIED ${sym}: not present in the boundary files studied this cycle`);
                break; // one flag per finding is enough
            }
        }
        let confidence = Math.round(finding.confidence);
        if (corrected) {
            confidence = Math.min(confidence, 70); // (ج) cap for corrected lessons
        } else if (new RegExp(VERIFIER_QUANT_RE.source).test(text) || [
            ...text.matchAll(new RegExp(VERIFIER_BLOCK_RE.source, "g"))
        ].some((m)=>Number(m[1]) >= 50) || [
            ...text.matchAll(new RegExp(VERIFIER_BLOCK_FRAC_RE.source, "g"))
        ].some((m)=>Number(m[2]) >= 50)) {
            confidence = Math.min(confidence, 90); // (ج) cap for verified numeric lessons
        }
        const evidence = notes.length ? `${finding.evidence ?? finding.pattern} [VERIFIER: ${notes.join("; ")}]` : finding.evidence;
        return {
            evidence,
            confidence,
            corrected
        };
    } catch  {
        // fail-open — never break the cycle on verifier bugs
        return {
            evidence: finding.evidence,
            confidence: Math.round(finding.confidence),
            corrected: false
        };
    }
}
const STATE_KEY = "verdictcore.state";
const LAST_RUN_KEY = "verdictcore.lastRun";
const AUTO_INTERVAL_MS = 30 * 60_000;
const MIN_SAMPLES = 5; // below this the journal is too thin for a cycle
const LESSON_CAP = 6;
const EMPTY_STATE = {
    runs: 0,
    lastRunAt: null,
    lastAnswer: null,
    lessons: []
};
async function getVerdictCoreState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: STATE_KEY
            }
        });
        if (!row) return EMPTY_STATE;
        const parsed = JSON.parse(row.value);
        return {
            runs: Number(parsed.runs) || 0,
            lastRunAt: parsed.lastRunAt ?? null,
            lastAnswer: parsed.lastAnswer ?? null,
            lessons: Array.isArray(parsed.lessons) ? parsed.lessons.slice(0, LESSON_CAP) : []
        };
    } catch  {
        return EMPTY_STATE;
    }
}
async function saveState(state) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: STATE_KEY
        },
        create: {
            key: STATE_KEY,
            value: JSON.stringify(state)
        },
        update: {
            value: JSON.stringify(state)
        }
    });
}
async function runVerdictLearn(windowHours = 12) {
    const journal = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateJournalForCore"])(windowHours, 10);
    const stats = journal.stats;
    if (stats.samples === 0) {
        const prev = await getVerdictCoreState();
        const state = {
            ...prev,
            lastAnswer: `Gate journal is empty for the last ${windowHours}h — no threshold verdicts to study yet. The gauge accrues rows automatically (real deploy evaluations + the shadow sweep).`
        };
        await saveState(state);
        return state;
    }
    // The grounding bundle — ONLY measured numbers (gate-journal guarantees it)
    // v8.2 SHADOW-VETO Phase 0: the fence is now OUTCOME-TRACKED (real linkage
    // for hair-thin passes, honest paper ledger for fence rejects) — the doctrine
    // line and the arms bundle below replace the old OBSERVING-only contract.
    const shadow = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["shadowVetoForCore"])(6).catch(()=>({
            narrative: "SHADOW-VETO: unavailable this cycle.",
            verdictFiles: []
        }));
    // v10.2 SV-TELEMETRY — arm feed wiring narrative (best-effort, never blocks)
    const svTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["svTelemetryNarrative"])().catch(()=>"SV-TELEMETRY: unavailable this cycle.");
    // v10.8 FOUR-PACK journal — governance module verdicts (R1 risk / R2 time / R5 canary / R6 senior-review)
    const fpTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fourpackNarrative"])().catch(()=>"FOUR-PACK: unavailable this cycle.");
    const grounding = [
        `VERDICT-CORE STUDY WINDOW: last ${windowHours}h of the engine's own deploy-gate journal.`,
        journal.narrative,
        "BOUNDARY CASE FILES (candidates that stood exactly on the confirm/reject border):",
        ...journal.boundaryFiles.length ? journal.boundaryFiles : [
            "(none in window)"
        ],
        "HARD GATE BLOCKS:",
        ...journal.blockFiles.length ? journal.blockFiles : [
            "(none in window)"
        ],
        "SHADOW-VETO EVIDENCE (AI-core Phase 0 — your own veto-only second opinion at the fence, outcome-tracked):",
        shadow.narrative,
        ...shadow.verdictFiles.length ? shadow.verdictFiles : [
            "(no adjudications yet)"
        ],
        svTel,
        fpTel,
        "DOCTRINE: veto-only, fail-open, revocable. Real outcomes = settled trades; fence-reject outcomes = PAPER trades with base geometry (directional-edge evidence, never presented as real PnL). Promotion to live veto power requires ≥30 settled per arm + Wilson-LB separation — never claim it before the arms say so."
    ].join("\n");
    // Adapt the journal stats to the research-desk contract (aiVerdictLearn)
    const adapted = {
        total: stats.samples,
        rejectedScore: stats.byBand.REJECT,
        deployed: stats.deploys,
        boundary: stats.byBand.BOUNDARY,
        avgMarginRejected: stats.boundary?.avgGap ?? null,
        topRejectDrivers: stats.opposeReasons.map((r)=>({
                code: r.factor,
                n: r.count
            })),
        topConfirmDrivers: stats.confirmReasons.map((r)=>({
                code: r.factor,
                n: r.count
            }))
    };
    // aiVerdictLearn never throws — it degrades to a deterministic heuristic read
    const { aiVerdictLearn } = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)");
    const res = await aiVerdictLearn(grounding, adapted);
    // DETERMINISTIC VERIFICATION — every finding's numeric claims re-checked
    // against the rows the model actually studied (audit 2026-11-05, مصوبه ب/ج)
    const verifierCtx = {
        boundarySamples: journal.boundarySamples.map((s)=>({
                symbol: s.symbol,
                direction: s.direction
            })),
        stats: {
            windowHours: stats.windowHours,
            blocks: stats.blocks.map((b)=>({
                    gate: b.gate,
                    count: b.count
                })),
            blocksRingSaturated: stats.blocksRingSaturated,
            blocksRingSize: stats.blocksRingSize
        }
    };
    const verified = res.findings.map((f)=>verifyLessonFinding(f, verifierCtx));
    const correctedCount = verified.filter((v)=>v.corrected).length;
    const prev = await getVerdictCoreState();
    // HISTORY HEALING — persisted lessons from earlier cycles keep their original
    // unverified text (e.g. #1410's "8/8 PUMPUSDT" sat at confidence 100). Re-verify
    // every stored lesson that does not already carry a verifier tag; annotate + cap
    // when it fails against the CURRENT studied rows. Verified-clean history is
    // left untouched (no silent downgrades).
    const healedPrev = prev.lessons.map((l)=>{
        if ((l.evidence ?? l.pattern).includes("[VERIFIER:")) return l;
        const v = verifyLessonFinding({
            pattern: l.pattern,
            evidence: l.evidence,
            confidence: l.confidence
        }, verifierCtx);
        if (!v.corrected) return l;
        return {
            ...l,
            confidence: Math.min(l.confidence, v.confidence),
            evidence: v.evidence ?? l.evidence
        };
    });
    const healedCount = healedPrev.filter((l, i)=>l !== prev.lessons[i]).length;
    const nowIso = new Date().toISOString();
    const lessons = res.findings.map((f, i)=>({
            at: nowIso,
            scope: "GATE-JOURNAL",
            pattern: f.evidence ? `${f.pattern} — ev: ${f.evidence}` : f.pattern,
            action: f.action,
            label: res.label,
            confidence: verified[i]?.confidence ?? Math.round(f.confidence),
            evidence: verified[i]?.evidence ?? f.evidence
        }));
    const state = {
        runs: prev.runs + 1,
        lastRunAt: nowIso,
        lastAnswer: correctedCount > 0 ? `${res.digest} [VERIFIER: ${correctedCount} lesson(s) annotated/corrected against the studied rows this cycle]` : res.digest,
        lessons: [
            ...lessons,
            ...healedPrev
        ].slice(0, LESSON_CAP)
    };
    await saveState(state);
    // audit line in the engine stream (dynamic import — engine imports this module)
    await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, null, "ENGINE", "ai", `VERDICT-CORE cycle #${state.runs} (${res.label}) — studied ${stats.samples} gate verdicts (${stats.byBand.BOUNDARY} boundary · ${stats.byBand.REJECT} rejects · ${stats.deploys} deploys) — top reject driver ${adapted.topRejectDrivers[0]?.code ?? "n/a"}, top confirm driver ${adapted.topConfirmDrivers[0]?.code ?? "n/a"} — verifier: ${correctedCount}/${res.findings.length} findings + ${healedCount} history lessons annotated — lessons persisted to the central core`)).catch(()=>undefined);
    return state;
}
async function maybeAutoVerdictLearn() {
    try {
        const lastRow = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: LAST_RUN_KEY
            }
        });
        const last = lastRow ? new Date(lastRow.value).getTime() : 0;
        if (Date.now() - last < AUTO_INTERVAL_MS) return;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: LAST_RUN_KEY
            },
            create: {
                key: LAST_RUN_KEY,
                value: new Date().toISOString()
            },
            update: {
                value: new Date().toISOString()
            }
        });
        // journal too thin → skip the LLM burn, retry next cadence
        const probe = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateJournalForCore"])(12, 1);
        if (probe.stats.samples < MIN_SAMPLES) return;
        await runVerdictLearn(12);
    } catch (e) {
        console.error("[verdict-core]", e);
    }
}
}),
];

//# sourceMappingURL=src_lib_769f43d4._.js.map