module.exports = [
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_MILESTONE_STEPS",
    ()=>RAWCAL_MILESTONE_STEPS,
    "RAWCAL_TELEMETRY_FILE",
    ()=>RAWCAL_TELEMETRY_FILE,
    "checkRawcalMilestones",
    ()=>checkRawcalMilestones,
    "checkRawcalStallAlarm",
    ()=>checkRawcalStallAlarm,
    "computeRawcalPace",
    ()=>computeRawcalPace,
    "milestoneView",
    ()=>milestoneView,
    "recentBlocks",
    ()=>recentBlocks,
    "recordRawcalSnapshot",
    ()=>recordRawcalSnapshot
]);
// ── v9.2 RAW-CAL PACE MONITOR — engineering observability for the capture run ──
// Operator mandate 2026-09-13: «پایش ریتم صدور RAW-CAL و رشد کتاب EPOCH-2 به
// سمت ۱۰۰. رو کامل و مهندسی انجام بده» — monitor the RAW-CAL issuance rhythm
// and the growth of the EPOCH-2 book toward the 100-settled calibration bar.
//
// THREE PERSISTED INSTRUMENTS:
//  1) SNAPSHOT JOURNAL — .data/rawcal-telemetry.jsonl, one row every ~10min
//     (self-throttled; force on state jumps): {t, issued, issuedTotal,
//     settledE2, openRaw, settledRaw, winsRaw, note?} — the book-growth curve
//     the UI sparkline and rate math read. Trimmed to the last 4000 rows.
//  2) PACE ENGINE — rolling rates from the journal + the DB ledger:
//     issue rate/h (3h + since-armed), settle rate/h (3h + 6h), observed mean
//     spacing between raw issues (DB createdAt diffs), ETA to the 100 bar at
//     the current settle rate, pipeline projection (open raw records that will
//     still settle), mean book settle-time, and stall detection.
//  3) MILESTONE LEDGER — idempotent audited events at 50/60/70/80/90/95/100
//     (EngineSetting "rawcal.milestones"); Telegram only for 90/95/100 (the
//     100 announcement itself stays with the auto-lift in raw-cal.ts).
//
// STALL SEMANTICS (honest, rail-aware):
//  · issue stall  = armed && openRaw < maxOpen && now − lastIssueAt >
//    max(45min, 3 × spacingMin) — issuance SHOULD have produced a record.
//  · settle stall = openRaw > 0 && no EPOCH-2 settle in the last 3h.
//  Neither fires when the open-cap rail is the legitimate blocker.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const RAWCAL_TELEMETRY_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-telemetry.jsonl");
const MILESTONES_KEY = "rawcal.milestones";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const RAWCAL_MILESTONE_STEPS = [
    50,
    60,
    70,
    80,
    90,
    95,
    100
];
const TELEGRAM_MILESTONES = new Set([
    90,
    95,
    100
]);
const MAX_JOURNAL_ROWS = 4000;
// ── memo caches (pulse-safe; these run on hot paths) ──
let lastSnapshotAt = 0;
let paceCache = null;
const PACE_TTL_MS = 30_000;
async function readJournal() {
    try {
        const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(RAWCAL_TELEMETRY_FILE, "utf8");
        const rows = [];
        for (const line of txt.split("\n")){
            const s = line.trim();
            if (!s) continue;
            try {
                rows.push(JSON.parse(s));
            } catch  {
            /* skip torn line */ }
        }
        return rows.slice(-MAX_JOURNAL_ROWS);
    } catch  {
        return [];
    }
}
async function appendJournal(row) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(RAWCAL_TELEMETRY_FILE), {
            recursive: true
        });
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(RAWCAL_TELEMETRY_FILE, JSON.stringify(row) + "\n", "utf8");
        // opportunistic trim (cheap: only when the file grows past 2× the cap)
        try {
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(RAWCAL_TELEMETRY_FILE);
            if (st.size > MAX_JOURNAL_ROWS * 180) {
                const rows = await readJournal();
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(RAWCAL_TELEMETRY_FILE, rows.slice(-MAX_JOURNAL_ROWS).map((r)=>JSON.stringify(r)).join("\n") + "\n", "utf8");
            }
        } catch  {
        /* trim best-effort */ }
    } catch (e) {
        console.error("[rawcal-telemetry] journal append failed", e);
    }
}
async function recordRawcalSnapshot(note, force = false) {
    const now = Date.now();
    if (!force && now - lastSnapshotAt < 10 * 60_000) return null;
    lastSnapshotAt = now;
    try {
        const [settledE2, openRaw, totalRaw, settledRaw, winsRaw] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: {
                        in: SETTLED_STATUSES
                    },
                    tags: {
                        contains: "EPOCH-2"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: [
                            "ACTIVE",
                            "TP1",
                            "TP2"
                        ]
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: SETTLED_STATUSES
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    reachedTp: {
                        gte: 1
                    }
                }
            })
        ]);
        const snap = {
            t: new Date(now).toISOString(),
            issued: 0,
            issuedTotal: totalRaw,
            settledE2,
            openRaw,
            settledRaw,
            winsRaw,
            ...note ? {
                note: note.slice(0, 80)
            } : {}
        };
        // issued-this-run: cheap read of the state key (no import cycle — raw-cal
        // imports telemetry, not vice versa)
        try {
            const s = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "rawcal.state"
                }
            });
            if (s) snap.issued = JSON.parse(s.value).issued ?? 0;
        } catch  {
        /* optional field */ }
        await appendJournal(snap);
        paceCache = null; // fresh data → invalidate pace memo
        return snap;
    } catch (e) {
        console.error("[rawcal-telemetry] snapshot failed", e);
        return null;
    }
}
async function computeRawcalPace(blocks) {
    if (paceCache && Date.now() - paceCache.at < PACE_TTL_MS && !blocks) return paceCache.data;
    const state = await getRawcalStateSafe();
    const now = Date.now();
    const [settledE2, openRaw, openE2, maxOpen] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        Promise.resolve(state.maxOpen)
    ]);
    const target = state.target;
    // issuance ledger (raw rows from the DB itself — ground truth)
    const rawRows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            createdAt: true
        },
        orderBy: {
            createdAt: "asc"
        }
    });
    const issueTimes = rawRows.map((r)=>r.createdAt.getTime());
    const h3 = now - 3 * 3600_000;
    const issues3h = issueTimes.filter((t)=>t >= h3).length;
    const armMs = state.armedAt ? new Date(state.armedAt).getTime() : null;
    const issuesSinceArm = armMs ? issueTimes.filter((t)=>t >= armMs).length : 0;
    const armHours = armMs ? Math.max(1 / 60, (now - armMs) / 3600_000) : null;
    const diffs = issueTimes.slice(1).map((t, i)=>t - issueTimes[i]);
    const meanDiff = diffs.length ? diffs.reduce((a, b)=>a + b, 0) / diffs.length : null;
    // book-growth ledger (EPOCH-2 settles with closedAt)
    const settles = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            },
            closedAt: {
                not: null
            }
        },
        select: {
            closedAt: true,
            createdAt: true
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const settleTimes = settles.map((r)=>r.closedAt.getTime()).reverse(); // asc
    const settles3h = settleTimes.filter((t)=>t >= h3).length;
    const settles6h = settleTimes.filter((t)=>t >= now - 6 * 3600_000).length;
    const recent20 = settles.slice(0, 20);
    const meanSettleMin = recent20.length ? recent20.reduce((a, r)=>a + (r.closedAt.getTime() - r.createdAt.getTime()), 0) / recent20.length / 60_000 : null;
    const [settledRaw, winsRaw] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: SETTLED_STATUSES
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                reachedTp: {
                    gte: 1
                }
            }
        })
    ]);
    const settleRate3h = settles3h / 3;
    const needed = Math.max(0, target - settledE2);
    const etaHours = needed === 0 ? 0 : settleRate3h > 0 ? needed / settleRate3h : null;
    // v9.2.1 steady-state projection — raw cadence ∩ settle-throughput cap.
    // throughputCap = maxOpen concurrent records / mean settle hours; the real
    // fill window is needed / min(issueCadence, throughputCap). Only computed
    // when meanSettleMin is known (honest — no invented throughput).
    const issueSinceArmRateRaw = armHours ? issuesSinceArm / armHours : 0;
    const throughputCapPerH = meanSettleMin !== null && meanSettleMin > 0 ? maxOpen / (meanSettleMin / 60) : null;
    const steadyRatePerH = throughputCapPerH !== null ? Math.min(issueSinceArmRateRaw, throughputCapPerH) : null;
    const etaSteadyHours = needed === 0 ? 0 : steadyRatePerH !== null && steadyRatePerH > 0 ? needed / steadyRatePerH : null;
    // stalls (rail-aware — see header)
    const issueStallMin = state.armed && openRaw < maxOpen && state.lastIssueAt ? Math.max(0, (now - new Date(state.lastIssueAt).getTime()) / 60_000) : null;
    const issueStallActive = issueStallMin !== null && issueStallMin > Math.max(45, 3 * state.spacingMin);
    const lastSettleAt = settleTimes.length ? settleTimes[settleTimes.length - 1] : null;
    const settleStallMin = openRaw > 0 && lastSettleAt ? Math.max(0, (now - lastSettleAt) / 60_000) : null;
    const settleStallActive = settleStallMin !== null && settleStallMin > 180;
    // cadence grade — honest banding of the ISSUE rhythm while armed.
    // v9.2.1 arm-age-aware: inside the first 3h after arming the 3h window still
    // contains pre-RAW-CAL filtered flow (rate lag) → grade on the since-arm
    // cadence instead; afterwards both windows agree and 3h is used.
    const issueRate3hPerH = issues3h / 3;
    let cadenceGrade = "OFF";
    if (state.armed) {
        const baseRate = armHours !== null && armHours < 3 ? issueSinceArmRateRaw : issueRate3hPerH;
        const effRate = issueStallActive ? 0 : baseRate;
        cadenceGrade = effRate >= 3 ? "A" : effRate >= 1.5 ? "B" : effRate >= 0.5 ? "C" : "D";
    }
    // sparkline from the journal (downsample to ≤48 points)
    // v9.4.2 NaN guard: journal gap rows can carry non-finite settledE2 — skip
    // them here so the client never receives NaN chart values.
    const journal = await readJournal();
    const series = journal.length > 1 ? journal : journal.length === 1 ? [
        {
            t: new Date(now).toISOString(),
            settledE2
        }
    ] : [];
    const step = Math.max(1, Math.ceil(series.length / 48));
    const sparkline = [];
    for(let i = 0; i < series.length; i += step){
        const v = series[i].settledE2;
        if (!Number.isFinite(v)) continue;
        sparkline.push({
            t: series[i].t,
            v
        });
    }
    if (sparkline.length && Number.isFinite(settledE2) && sparkline[sparkline.length - 1].v !== settledE2) sparkline.push({
        t: new Date(now).toISOString(),
        v: settledE2
    });
    const lastBlockNote = blocks && blocks.length ? blocks[blocks.length - 1].note : null;
    const pace = {
        armed: state.armed,
        armedAt: state.armedAt,
        settledE2,
        needed,
        target,
        issueRate3hPerH: round2(issueRate3hPerH),
        issueRateSinceArmPerH: armHours ? round2(issuesSinceArm / armHours) : 0,
        observedSpacingMin: {
            mean: meanDiff !== null ? round2(meanDiff / 60_000) : null,
            min: diffs.length ? round2(Math.min(...diffs) / 60_000) : null,
            max: diffs.length ? round2(Math.max(...diffs) / 60_000) : null,
            samples: diffs.length
        },
        lastIssueAt: state.lastIssueAt,
        lastIssueSerial: state.lastIssueSerial,
        openRaw,
        openE2,
        maxOpen,
        spacingMin: state.spacingMin,
        settleRate3hPerH: round2(settleRate3h),
        settleRate6hPerH: round2(settles6h / 6),
        meanSettleMin: meanSettleMin !== null ? Math.round(meanSettleMin) : null,
        winsRaw,
        settledRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        etaHours: etaHours !== null ? round2(etaHours) : null,
        etaAt: etaHours !== null ? new Date(now + etaHours * 3600_000).toISOString() : null,
        steadyRatePerH: steadyRatePerH !== null ? round2(steadyRatePerH) : null,
        etaSteadyHours: etaSteadyHours !== null ? round2(etaSteadyHours) : null,
        etaSteadyAt: etaSteadyHours !== null ? new Date(now + etaSteadyHours * 3600_000).toISOString() : null,
        pipelineProjection: settledE2 + openE2,
        cadenceGrade,
        stalls: {
            issueStallMin: issueStallActive ? Math.round(issueStallMin) : null,
            settleStallMin: settleStallActive ? Math.round(settleStallMin) : null,
            lastBlockNote
        },
        sparkline,
        journalRows: journal.length
    };
    if (!blocks) paceCache = {
        at: Date.now(),
        data: pace
    };
    return pace;
}
async function getRawcalStateSafe() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return await getRawCalState();
    } catch  {
        return {
            armed: false,
            armedAt: null,
            lastIssueAt: null,
            lastIssueSerial: null,
            target: 100,
            spacingMin: 12,
            maxOpen: 8
        };
    }
}
function round2(n) {
    return Math.round(n * 100) / 100;
}
// ── MILESTONE LEDGER ──
async function readMilestones() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: MILESTONES_KEY
            }
        });
        if (!row) return {
            fired: {}
        };
        return JSON.parse(row.value);
    } catch  {
        return {
            fired: {}
        };
    }
}
async function checkRawcalMilestones() {
    const settledE2 = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    }).catch(()=>0);
    const m = await readMilestones();
    const firedNow = [];
    for (const step of RAWCAL_MILESTONE_STEPS){
        const key = String(step);
        if (settledE2 < step || m.fired[key]) continue;
        const at = new Date().toISOString();
        m.fired[key] = at;
        firedNow.push({
            step,
            at
        });
        const isBar = step === 100;
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", `RAW-CAL MILESTONE ${step}/${100} — EPOCH-2 book at ${settledE2} settled${isBar ? " — calibration bar REACHED, capture mode hands back to central-intelligence command (new calibration)" : ` · ${100 - settledE2} records remain to the AI CALIBRATION bar`}`).catch(()=>undefined);
        if (TELEGRAM_MILESTONES.has(step) && !(isBar && stateHasAutoLift())) {
            const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
            void sendDirect(`📈 <b>RAW-CAL MILESTONE ${step}/100</b>\nEPOCH-2 book: <b>${settledE2}/100</b> settled${isBar ? " — AI CALIBRATION lift imminent" : ` · ${100 - settledE2} to go`}\n${progressBar(settledE2)}`).catch(()=>undefined);
        }
    }
    if (firedNow.length) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: MILESTONES_KEY
            },
            create: {
                key: MILESTONES_KEY,
                value: JSON.stringify(m)
            },
            update: {
                value: JSON.stringify(m)
            }
        }).catch(()=>undefined);
    }
    return firedNow;
}
async function stateHasAutoLift() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return !!(await getRawCalState()).autoLiftAt;
    } catch  {
        return false;
    }
}
function progressBar(n) {
    const filled = Math.round(Math.min(100, n) / 100 * 20);
    return "▰".repeat(filled) + "▱".repeat(20 - filled);
}
async function milestoneView() {
    const [m, settledE2] = await Promise.all([
        readMilestones(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }).catch(()=>0)
    ]);
    return {
        steps: RAWCAL_MILESTONE_STEPS.map((step)=>({
                step,
                fired: !!m.fired[String(step)],
                at: m.fired[String(step)] ?? null,
                pending: settledE2 < step
            })),
        settledE2
    };
}
async function recentBlocks(n = 12) {
    try {
        const { getRawCalBlocks } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return getRawCalBlocks(n);
    } catch  {
        return [];
    }
}
// ── v9.2.1 STALL ALARM — push the rhythm break, don't just display it ──
// Tick hook (idempotent, 2h cooldown per stall type). Fires when the armed
// issuer SHOULD have produced (issue stall) or the in-flight pipeline SHOULD
// have settled (settle stall) and didn't. Process-death is covered by the P0
// watchdog + keep-alive crons; this alarm covers "alive but rhythm broken".
const STALL_ALERT_KEY = "rawcal.stallAlerts";
const STALL_COOLDOWN_MS = 2 * 3600_000;
async function checkRawcalStallAlarm() {
    try {
        const pace = await computeRawcalPace().catch(()=>null);
        if (!pace || !pace.armed) return false;
        const issues = [];
        if (pace.stalls.issueStallMin) issues.push(`issue stall — no raw record for ${pace.stalls.issueStallMin}min while armed and open ${pace.openRaw}/${pace.maxOpen}`);
        if (pace.stalls.settleStallMin) issues.push(`settle stall — no EPOCH-2 settle for ${pace.stalls.settleStallMin}min with ${pace.openRaw} raw in flight`);
        if (!issues.length) return false;
        let fired = {};
        try {
            const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: STALL_ALERT_KEY
                }
            });
            if (row) fired = JSON.parse(row.value).fired ?? {};
        } catch  {
        /* fresh ledger */ }
        const now = Date.now();
        const send = [];
        for (const it of issues){
            const k = it.startsWith("issue") ? "issue" : "settle";
            const last = fired[k] ? new Date(fired[k]).getTime() : 0;
            if (now - last > STALL_COOLDOWN_MS) {
                fired[k] = new Date(now).toISOString();
                send.push(it);
            }
        }
        if (!send.length) return false;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: STALL_ALERT_KEY
            },
            create: {
                key: STALL_ALERT_KEY,
                value: JSON.stringify({
                    fired
                })
            },
            update: {
                value: JSON.stringify({
                    fired
                })
            }
        }).catch(()=>undefined);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL PACE ALARM — ${send.join(" · ")} · book ${pace.settledE2}/${pace.target} · cadence ${pace.cadenceGrade}`).catch(()=>undefined);
        const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
        void sendDirect(`⏱ <b>RAW-CAL PACE ALARM</b>\n${send.map((s)=>`• ${s}`).join("\n")}\n📊 Book: <b>${pace.settledE2}/${pace.target}</b> settled · cadence ${pace.cadenceGrade} · open raw ${pace.openRaw}/${pace.maxOpen}`).catch(()=>undefined);
        return true;
    } catch  {
        return false;
    }
}
}),
"[project]/src/lib/rawcal-heartbeat.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "touchRawcalHeartbeat",
    ()=>touchRawcalHeartbeat
]);
// ── v10.20 RAW-CAL RUN HEARTBEAT (engine-native) ───────────────────────────
// M4 mission finding SENTINEL-20260921-M4 #6: the RAWCAL run heartbeat
// (.data/rawcal-run-heartbeat.txt) was historically written by an external
// 2h cron that died 2026-09-19T11:33Z — the sentinel kept reading a stale
// "heartbeatAgeH" for a system that was in fact alive-but-idle (disarmed by
// design at target). This module makes the ENGINE itself the heartbeat
// writer: maybeRawCalDeploy() runs every 10 ticks (always alive while Next
// runs), so the heartbeat now reflects the true run-loop state:
//   · ARMED  — capture mode issuing (state carries issued/target)
//   · IDLE   — disarmed by policy (the honest "alive, not dead" signal)
//   · ISSUE  — a raw record was just issued (state change → always written)
//   · ARMED/…— arm/disarm transitions (always written)
// Format stays sentinel-compatible: each line begins with the minute-precision
// UTC stamp the sentinel parses (`YYYY-MM-DDTHHMMZ`), state detail follows.
// Failure contract: best-effort telemetry — never throws, never blocks a tick.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const HB_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-run-heartbeat.txt");
const SAME_STATE_THROTTLE_MS = 30 * 60_000; // idle/armed steady-state: 1 line / 30min
const MAX_LINES = 200; // bounded file — ~4 days of steady-state history
let lastState = "";
let lastWriteAt = 0;
let chain = Promise.resolve(); // serialize read-modify-write
const p2 = (n)=>String(n).padStart(2, "0");
function stamp(d) {
    return `${d.getUTCFullYear()}-${p2(d.getUTCMonth() + 1)}-${p2(d.getUTCDate())}T${p2(d.getUTCHours())}${p2(d.getUTCMinutes())}Z`;
}
async function writeHeartbeat(state) {
    const now = Date.now();
    const line = `${stamp(new Date(now))} ${state}`;
    if (line === lastState && now - lastWriteAt < SAME_STATE_THROTTLE_MS) return; // steady-state throttle
    const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(HB_FILE, "utf8").catch(()=>"");
    const lines = txt.trim().split("\n").filter(Boolean);
    lines.push(line);
    const keep = lines.slice(-MAX_LINES).join("\n") + "\n";
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(HB_FILE), {
        recursive: true
    });
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(HB_FILE, keep, "utf8");
    lastState = line;
    lastWriteAt = now;
}
function touchRawcalHeartbeat(state) {
    const trimmed = state.slice(0, 110);
    chain = chain.then(()=>writeHeartbeat(trimmed)).catch(()=>undefined); // telemetry is best-effort — never block the caller
}
}),
"[project]/src/lib/raw-cal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_KEY",
    ()=>RAWCAL_KEY,
    "RAWCAL_TARGET",
    ()=>RAWCAL_TARGET,
    "armRawCal",
    ()=>armRawCal,
    "captureBookRegimeSplit",
    ()=>captureBookRegimeSplit,
    "clampManualBatch",
    ()=>clampManualBatch,
    "disarmRawCal",
    ()=>disarmRawCal,
    "epoch2SettledCount",
    ()=>epoch2SettledCount,
    "getRawCalBlocks",
    ()=>getRawCalBlocks,
    "getRawCalState",
    ()=>getRawCalState,
    "getV146Guard",
    ()=>getV146Guard,
    "maybeRawCalDeploy",
    ()=>maybeRawCalDeploy,
    "rawCalStatus",
    ()=>rawCalStatus
]);
// ── v9.1 RAW-CAL — UNFILTERED CALIBRATION CAPTURE MODE (operator mandate) ──
// Operator order 2026-09-13: «یک دستور اجرای صدور سیگنال بدون فیلتر و فقط
// ثبت داده و پیگیری و جورنال سازی برای ارسال به ENGINE MEMORY تا سریعتر به
// حد 100 سیگنال برای AI CALIBRATION برسد، سپس این دستور لغو و تمام عملکرد
// فیلتر و ردیابی با دستور هوش مرکزی و کالیبراسون جدید انجام بشه»
//
// WHAT IT DOES (exactly the operator's words, engineered honestly):
//  · ARMED → the engine issues RAW-CAL signals with the quality filters
//    bypassed (threshold/memory/strategy/short/learned/flow/shadow-veto —
//    engine.ts deploySignal opts.calCapture). Every record keeps its REAL
//    confluence votes + strategy + flow snapshot so the R6 recalibration at
//    n≥100 attributes outcomes to actual factors, not noise.
//  · ONLY data capture: records enter the normal ledger → tracked → settled
//    → journaled exactly like every other signal (same TTL, TP ladder,
//    trailing, afterlife) — nothing is faked, nothing is skipped.
//  · ENGINE MEMORY: state + issued-cohort stats are injected into
//    buildEngineMemory() (ai-memory.ts) so the central intelligence sees the
//    raw cohort as ground truth, and the governor context carries the mode.
//  · AUTO-CANCEL: when the EPOCH-2 settled book reaches the target (100),
//    the mode disarms ITSELF, fires the audited RAW-CAL LIFT event, forces
//    refreshCalibration() (the R6 freeze lifts at n≥100 — new calibration
//    under central-intelligence command), and announces on Telegram.
//  · The operator can DISARM any time (dashboard button / /api/rawcal POST).
//
// ANTI-FLOOD RAILS (protect the ledger, not the filter):
//  · spacingMin (default 12min) between raw issues
//  · maxOpen (default 8) concurrent open RAW-CAL records
//  · the scan's own honesty rails stay HARD inside deploySignal (feed-fresh
//    guard + sim-price ban) — calibration rows are never born from stale
//    or invented prices.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)"); // v9.2 pace monitor (no cycle: telemetry imports raw-cal only dynamically)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-heartbeat.ts [app-route] (ecmascript)"); // v10.20 engine-native run heartbeat (sentinel-compatible)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)"); // v14.2 — ban-aware issuer suspension (audit rec #1)
;
;
;
;
const RAWCAL_KEY = "rawcal.state";
const RAWCAL_TARGET = 100; // the R6 calibration-lift bar (calibration.ts)
// v10.6.1 spacing 12→10 (operator APPROVE 2026-09-18, proposal #3 of msg 3435):
// tightens the anti-flood floor so evidence windows fill faster without
// loosening honesty rails (open-cap + scan rails unchanged).
const DEFAULT_SPACING_MIN = 10;
const DEFAULT_MAX_OPEN = 8;
// EQ-99 (operator: «ماژول RAW-CAL چرا بطور دستی فعال نمی شود؟» 2026-10-13):
// a POST-graduation manual re-arm used to be AUTO-LIFTED within 10 ticks —
// the tick's graduation tripwire (settledN ≥ target + arms complete) has no
// concept of "the operator deliberately re-armed". Fix: a manual re-arm after
// graduation is a NEW CAPTURE CAMPAIGN — the book target moves ahead of the
// settled count by this batch so the tripwire stays dormant until the fresh
// evidence settles. 300 = the R6 refresh basis (calibration.ts recalibration
// window); operator-overridable via the API (clamped 50..2000).
const MANUAL_CAPTURE_BATCH_DEFAULT = 300;
function clampManualBatch(v) {
    const n = typeof v === "number" ? Math.floor(v) : NaN;
    if (!Number.isFinite(n)) return MANUAL_CAPTURE_BATCH_DEFAULT;
    return Math.min(2000, Math.max(50, n));
}
const DEFAULT_STATE = {
    armed: false,
    armedAt: null,
    armedBy: "",
    disarmReason: null,
    disarmedAt: null,
    issued: 0,
    issuedTotal: 0,
    lastIssueAt: null,
    lastIssueSerial: null,
    target: RAWCAL_TARGET,
    spacingMin: DEFAULT_SPACING_MIN,
    maxOpen: DEFAULT_MAX_OPEN,
    autoLiftAt: null
};
async function getRawCalState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: RAWCAL_KEY
            }
        });
        if (!row) return {
            ...DEFAULT_STATE
        };
        const raw = {
            ...DEFAULT_STATE,
            ...JSON.parse(row.value)
        };
        // TASK-49 NAN-PROOF — a historic write escaped `target: settledN + NaN` into
        // JSON (NaN serializes to null), which made `settledN >= null` ALWAYS true
        // and pinned the arms-coupled extension branch on every pass. Sanitize on
        // read: any non-finite spacing/maxOpen/target heals to a sane value here,
        // so the loop can never be wedged by one bad write again.
        const num = (v, dflt)=>typeof v === "number" && Number.isFinite(v) && v > 0 ? v : dflt;
        return {
            ...raw,
            spacingMin: num(raw.spacingMin, DEFAULT_SPACING_MIN),
            maxOpen: num(raw.maxOpen, DEFAULT_MAX_OPEN),
            target: num(raw.target, RAWCAL_TARGET)
        };
    } catch  {
        return {
            ...DEFAULT_STATE
        };
    }
}
// ── v9.2 ISSUANCE-BLOCK RING (observability) — why the issuer last paused ──
// maybeRawCalDeploy returns a note on every non-issue pass; the ring keeps the
// recent ones so the pace monitor can show WHY cadence paused (spacing rail,
// open cap, scan-no-candidate, feed-stale…). Duplicate identical notes inside
// 5min refresh the timestamp instead of stacking.
const blockRing = [];
function noteRawCalBlock(note) {
    const last = blockRing[blockRing.length - 1];
    if (last && last.note === note && Date.now() - last.t < 5 * 60_000) {
        last.t = Date.now();
        return;
    }
    blockRing.push({
        t: Date.now(),
        note: note.slice(0, 90)
    });
    if (blockRing.length > 40) blockRing.shift();
}
function getRawCalBlocks(n = 12) {
    return blockRing.slice(-n);
}
async function writeState(state) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: RAWCAL_KEY
        },
        create: {
            key: RAWCAL_KEY,
            value: JSON.stringify(state)
        },
        update: {
            value: JSON.stringify(state)
        }
    });
}
async function epoch2SettledCount() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    });
}
async function armRawCal(by = "OPERATOR", batch) {
    const cur = await getRawCalState();
    if (cur.armed) return cur;
    const settledN = await epoch2SettledCount();
    // EQ-99 POST-GRADUATION RE-ARM CAMPAIGN — if the graduation tripwire condition
    // already holds (settledN ≥ target && arms complete), a plain re-arm would be
    // auto-lifted by the very next tick (line-proven 2026-10-13: settled 2376 ≥
    // target 2348 → tick calls disarmRawCal(auto) unconditionally). An operator
    // re-arm AFTER graduation is therefore a NEW CAPTURE CAMPAIGN: the target
    // moves settledN+batch so the auto-lift fires only when the FRESH batch has
    // settled — the operator's command sticks and the lift still re-runs the
    // R6 calibration over the grown book, unchanged.
    const campaign = settledN >= cur.target;
    const campaignTarget = campaign ? settledN + clampManualBatch(batch) : cur.target;
    const state = {
        ...cur,
        armed: true,
        armedAt: new Date().toISOString(),
        armedBy: by,
        disarmReason: null,
        disarmedAt: null,
        issued: 0,
        autoLiftAt: null,
        ...campaign ? {
            target: campaignTarget,
            manualCampaign: true,
            retargetNote: `EQ-99 OPERATOR RE-ARM CAMPAIGN (${by}): graduation condition already held (${settledN} settled ≥ ${cur.target}) — a plain re-arm would be auto-lifted within 10 ticks. Book target moved +${campaignTarget - settledN} → ${campaignTarget} so this campaign captures FRESH evidence and the organic auto-lift + R6 recalibration fires at the new bar`
        } : {
            manualCampaign: false
        }
    };
    await writeState(state);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ARMED by ${by.slice(0, 70)}${campaign ? ` (re-campaign → target ${campaignTarget})` : ""}`); // v10.20 — transition write (throttle bypassed on state change)
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL CAPTURE MODE ARMED (${by}) — signal issuance now runs WITHOUT quality filters: every scan's best candidate is issued as a tagged RAW-CAL record (data capture + tracking + journaling only), feeding the engine-memory book toward the AI CALIBRATION bar (${settledN}/${state.target} EPOCH-2 settled)${campaign ? ` — EQ-99 RE-CAMPAIGN: graduation bar was already met, so this re-arm opens a FRESH capture batch (+${state.target - settledN}); auto-lift + R6 recalibration fires at the new bar` : ""}. Anti-flood rails: ≥${state.spacingMin}min spacing, ≤${state.maxOpen} open raw records. The mode AUTO-CANCELS at ${state.target} settled and hands back to central-intelligence command with the new calibration.`);
    const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
    void sendDirect(`🧪 <b>RAW-CAL CAPTURE MODE ARMED</b>${campaign ? " — RE-CAMPAIGN" : ""}\nUnfiltered signal issuance is now ON — every scan's best flow is recorded as a RAW-CAL signal (tracked + journaled, no quality filters).\n📊 Progress: <b>${settledN}/${state.target}</b> EPOCH-2 settled → AI CALIBRATION lift${campaign ? ` (fresh batch +${state.target - settledN})` : ""}\n🛡 Rails: ≥${state.spacingMin}min spacing · ≤${state.maxOpen} open · auto-cancel at ${state.target}`).catch(()=>undefined);
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])("ARMED", true).catch(()=>undefined);
    return state;
}
async function disarmRawCal(reason, auto = false) {
    const cur = await getRawCalState();
    if (!cur.armed && !auto) return cur;
    const settledN = await epoch2SettledCount();
    const state = {
        ...cur,
        armed: false,
        disarmReason: reason,
        disarmedAt: new Date().toISOString(),
        ...auto ? {
            autoLiftAt: new Date().toISOString()
        } : {}
    };
    await writeState(state);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`IDLE ${auto ? "AUTO-LIFT" : "disarmed"} — ${reason.slice(0, 60)}`); // v10.20 — transition write
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    await fireEvent(null, null, "ENGINE", "ai", `${auto ? "RAW-CAL LIFT — CAPTURE MODE AUTO-CANCELED" : "RAW-CAL CAPTURE MODE DISARMED"} (${reason}) — EPOCH-2 book ${settledN}/${cur.target} settled. All filtering, tracking and sizing return to CENTRAL-INTELLIGENCE command (governor + advisor + AI core) under the NEW calibration${settledN >= cur.target ? " — R6 freeze lifts at n≥100 and profit-first weights recalibrate over the full book including the RAW-CAL cohort" : ""}.`);
    const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
    void sendDirect(`${auto ? "🎓 <b>RAW-CAL LIFT — CAPTURE COMPLETE</b>" : "⏹ <b>RAW-CAL MODE DISARMED</b>"}\n${reason}\n📊 EPOCH-2 book: <b>${settledN}/${cur.target}</b> settled${settledN >= cur.target ? " — AI CALIBRATION recalibrates over the full book (R6 lift)" : ""}\nFiltered operation returned to central-intelligence command.`).catch(()=>undefined);
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])(auto ? "AUTO-LIFT" : "DISARMED", true).catch(()=>undefined);
    return state;
}
// ── v14.6 WINNER-LANE AUTO-ABORT GUARD ──────────────────────────────────────
// The honest rail behind the v14.6 reopen: FAPI-DEG-W rows are accounted
// separately, and the moment ≥20 of them settle with avg net ≤ −$0.10 the
// v14.5 protected stand-down re-arms ITSELF (persisted in rawcal.v146) — no
// operator vigilance required, the bleed cannot restart silently.
const V146_KEY = "rawcal.v146";
const V146_DEFAULT = {
    suspended: false,
    reason: null,
    at: null,
    cohortN: 0,
    cohortAvgNet: null,
    checkedAt: null
};
async function readV146Row() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: V146_KEY
            }
        });
        if (!row) return {
            ...V146_DEFAULT
        };
        return {
            ...V146_DEFAULT,
            ...JSON.parse(row.value)
        };
    } catch  {
        return {
            ...V146_DEFAULT
        };
    }
}
async function getV146Guard() {
    const st = await readV146Row();
    st.checkedAt = new Date().toISOString();
    try {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                tags: {
                    contains: "FAPI-DEG-W"
                },
                status: {
                    in: [
                        "TP1",
                        "TP2",
                        "TP3",
                        "SL",
                        "EXPIRED",
                        "CLOSED"
                    ]
                }
            },
            select: {
                marginUsd: true,
                pnlPercent: true
            }
        });
        let net = 0;
        for (const r of rows)net += r.marginUsd * r.pnlPercent / 100;
        st.cohortN = rows.length;
        st.cohortAvgNet = rows.length ? Number((net / rows.length).toFixed(3)) : null;
        if (!st.suspended && rows.length >= 20 && st.cohortAvgNet !== null && st.cohortAvgNet <= -0.1) {
            st.suspended = true;
            st.reason = `AUTO-ABORT: FAPI-DEG-W cohort n=${rows.length} avg net $${st.cohortAvgNet}/row ≤ −$0.10 — winner-lane degraded capture re-suspended (v14.5 semantics)`;
            st.at = st.checkedAt;
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: V146_KEY
                },
                create: {
                    key: V146_KEY,
                    value: JSON.stringify(st)
                },
                update: {
                    value: JSON.stringify(st)
                }
            });
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
            void fireEvent(null, null, "ENGINE", "warn", `RAW-CAL v14.6 AUTO-ABORT: FAPI-DEG-W winner-lane cohort n=${rows.length} settled, avg net $${st.cohortAvgNet}/row ≤ −$0.10 — degraded-winner capture SUSPENDED, v14.5 protected stand-down re-armed.`).catch(()=>undefined);
        }
    } catch  {
    // fail-open: guard probe errors never block the issuer (rows stay tagged)
    }
    return st;
}
async function maybeRawCalDeploy() {
    const state = await getRawCalState();
    // v10.20 — engine-native run heartbeat: the tick proves the run loop is ALIVE
    // every 10 ticks (idle/armed steady-state throttled to 1 line / 30min inside).
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(state.armed ? `ARMED issued=${state.issued}/${state.issuedTotal} target=${state.target}` : `IDLE disarmed by policy (target ${state.target})`);
    if (!state.armed) {
        noteRawCalBlock("not armed");
        return {
            issued: false,
            note: "not armed"
        };
    }
    // 0) v14.6 WINNER-LANE DEGRADED CAPTURE (operator order 2026-11-11 trace
    //    1a1ca1b0320831a9 «…بررسی ممیزی از عملکرد سیگنالهای برنده و استفاده و باز
    //    گذاشتن ویژگی های شاخص برای گیت و تایید سیگنال…») — SUPERSEDES the v14.5
    //    hard stand-down. ─────────────
    //    WHY the flip back (evidence, ops-audit-1111):
    //    · v14.5's premise ("bans are intermittent ~24-min windows") DIED —
    //      ban.active held ~100% of the wall clock for 14h+ (rolling named-IP
    //      renewals on the external 3-IP egress pool; heartbeat 08:57→10:15Z all
    //      protected; scan-no-candidate events ceased 20:41Z; stall alert 08:36Z),
    //      so the stand-down became the exact total-issuance freeze it replaced.
    //    · The scoring lane is HEALTHY during bans: 2,788 candidates PASSed in
    //      24h — 100% SHORT, AI-SWING-dominated — exactly the proven winner
    //      cohort (CHOP|AI-SWING|SHORT n=230 · WR 30.4% · +$49.56/14d; CHOP
    //      all-time +$125.26). The wall sits ONLY in this ban check.
    //    · The v14.5 FAPI-DEG loss cohort (−$0.20/row) was accumulated 11-06→11-10
    //      while AI-SCALP + MEAN-REVERT were OPEN and CHOP-LONGs flowed — those
    //      cohorts are now BLOCKED UPSTREAM (strat-pause 11-10, regimeGuard L1,
    //      memory gate), so a ban-window row today is a different, winner-shaped
    //      cohort. The WS tape is LIVE during bans (feed failures=0, futws fresh
    //      43 rows) — only the flow bundle is demoted (blind flow,
    //      INFORMATIONAL-ONLY, historically non-negative).
    //    · GUARDRAIL (the honest part): rows carry FAPI-DEG + FAPI-DEG-W tags for
    //      separate cohort accounting, and an AUTO-ABORT re-arms the v14.5
    //      stand-down by itself once ≥20 FAPI-DEG-W rows settle with avg net
    //      ≤ −$0.10 (persisted rawcal.v146) — the drought ends, the bleed cannot
    //      restart silently. Reversible by writing rawcal.v146 {suspended:false}.
    const ban = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapiBanActivity"])();
    if (ban.active) {
        const v146 = await getV146Guard();
        if (v146.suspended) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`OPEN (protected) — v14.6 auto-abort live: winner-lane degraded capture suspended (${(v146.reason ?? "winner cohort bled").slice(0, 70)})`);
            noteRawCalBlock(`v14.6 auto-abort — ${(v146.reason ?? "winner cohort bled").slice(0, 80)}`);
            return {
                issued: false,
                note: "v14.6 winner-lane auto-abort"
            };
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`OPEN (degraded-winner) — fapi ban active (${ban.reason?.slice(0, 50)}): capture continues on WS-live tape, tagged FAPI-DEG-W (auto-abort armed: n≥20 & avg ≤ −$0.10) — operator order 2026-11-11 «باز گذاشتن ویژگی های شاخص»`);
    }
    // 1) progress check FIRST — Task 34-2 ARMS-COUPLED AUTO-CANCEL (2026-09-26
    //    operator mandate: «RAW-CAL باید AI CALIBRATION BAR را تا زمان کامل شدن
    //    بازوهای Shadow veto فعال باشد و PACE MONITOR بر این اساس تنظیم شود»):
    //    the book target alone no longer lifts the capture. When the target is
    //    reached but the shadow-veto REAL evidence arms are still incomplete,
    //    the mode AUTO-EXTENDS its target by the arm deficit (audited retarget,
    //    EVID-BUDGET pattern) instead of disarming — the calibration book keeps
    //    growing while the veto evidence window stays open. Only when BOTH the
    //    book target is met AND the arms are complete (paper-veto waived in
    //    shadow mode — it structurally cannot fill) does the auto-lift fire.
    const settledN = await epoch2SettledCount();
    if (settledN >= state.target) {
        const sv = await __turbopack_context__.A("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript, async loader)");
        const cfg = await sv.getShadowVetoConfig();
        // v11.5 hotfix (tsc-caught latent bug): shadowArmsCompletion is ASYNC —
        // the missing await made `completion` a Promise whose fields are all
        // undefined, so `!completion.allComplete` was ALWAYS true: the lift path
        // could never fire and the target auto-extended forever. Dormant only
        // because the mode is currently disarmed.
        const completion = await sv.shadowArmsCompletion(cfg.mode);
        if (!completion.allComplete) {
            // TASK-49 — NaN-proof: a stale compiled module (Turbopack chunk from the
            // pre-Task-34-2 snapshot) once returned a completion WITHOUT
            // note/pendingDeficit → Math.max(undefined)=NaN → target NaN → JSON null
            // → this branch pinned forever (repeating "[raw-cal] slice of undefined").
            // Guard every unknown now.
            const deficit = Number.isFinite(completion.pendingDeficit) ? completion.pendingDeficit : 10;
            const extension = Math.max(deficit, 10);
            const note = completion.note ?? "arms probe shape mismatch — treated as incomplete";
            const nextTarget = Number.isFinite(settledN + extension) ? settledN + extension : state.target + extension;
            const next = {
                ...state,
                target: nextTarget,
                retargetNote: `ARMS-COUPLED EXTENSION (operator mandate 2026-09-26 «تا زمان کامل شدن بازوهای Shadow veto فعال باشد»): book target ${state.target} reached but shadow-veto real arms incomplete (${note}) — target auto-extended +${extension} to ${nextTarget} so the capture keeps feeding evidence; PACE MONITOR tracks arm completion`
            };
            await writeState(next);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ARM-EXTEND target ${state.target}→${next.target} (${note.slice(0, 80)})`);
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
            await fireEvent(null, null, "ENGINE", "info", `RAW-CAL: book target reached (${settledN}) but shadow-veto arms incomplete — capture AUTO-EXTENDED +${extension} (target → ${next.target}). Arms: ${(completion.arms ?? []).map((a)=>`${a.id} ${a.n}/${a.target}${a.waived ? " (waived)" : ""}`).join(" · ")}`);
            return {
                issued: false,
                note: `arms-coupled extension → target ${next.target}`
            };
        }
        await disarmRawCal(`target reached + shadow-veto arms complete — ${settledN} EPOCH-2 settled ≥ ${state.target}`, true);
        const { refreshCalibration } = await __turbopack_context__.A("[project]/src/lib/calibration.ts [app-route] (ecmascript, async loader)");
        const { state: cal, auditLine } = await refreshCalibration();
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", auditLine ?? `AI CALIBRATION post-RAW-CAL: status ${cal.status} over ${cal.settled} settled — ${cal.rows.length} moving factors ${cal.rows.map((r)=>`${r.factor} ×${r.weight.toFixed(2)}`).join(" · ")}`);
        return {
            issued: false,
            note: `auto-lifted at ${settledN} (arms complete)`
        };
    }
    // 2) spacing rail
    if (state.lastIssueAt && Date.now() - new Date(state.lastIssueAt).getTime() < state.spacingMin * 60_000) {
        noteRawCalBlock(`spacing rail — next window ≥ ${state.spacingMin}min`);
        return {
            issued: false,
            note: "spacing"
        };
    }
    // 3) open-records rail (RAW-CAL cohort only)
    const openRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "ACTIVE",
                    "TP1",
                    "TP2"
                ]
            }
        }
    });
    if (openRaw >= state.maxOpen) {
        noteRawCalBlock(`open-cap rail — ${openRaw}/${state.maxOpen} raw records in flight`);
        return {
            issued: false,
            note: `open cap ${openRaw}/${state.maxOpen}`
        };
    }
    // 4) issue the capture record through the engine scan (honesty rails stay
    //    hard inside deploySignal: feed-fresh guard + sim-price ban)
    //    v14.6 — during a live fapi ban the row is tagged FAPI-DEG (cohort
    //    continuity) + FAPI-DEG-W (winner-lane window, auto-abort accounting).
    const { deploySignal } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    const res = await deploySignal(undefined, undefined, {
        calCapture: true,
        triggerTag: "RAW-CAL",
        ...ban.active ? {
            extraTags: [
                "FAPI-DEG",
                "FAPI-DEG-W"
            ]
        } : {}
    });
    if (!res.signal) {
        // rate-limit the "scan found nothing" chatter — one event / 30min
        noteRawCalBlock(`scan-no-candidate — ${res.error?.slice(0, 60) ?? "no setup"}`);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        const recent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.count({
            where: {
                type: "ENGINE",
                level: "info",
                message: {
                    contains: "RAW-CAL: scan found no live candidate"
                },
                createdAt: {
                    gte: new Date(Date.now() - 30 * 60_000)
                }
            }
        }).catch(()=>1);
        if (!recent) await fireEvent(null, null, "ENGINE", "info", `RAW-CAL: scan found no live candidate this window — ${res.error?.slice(0, 120) ?? "no setup"}`);
        return {
            issued: false,
            note: res.error?.slice(0, 80)
        };
    }
    // 5) journal the issue + update state
    const next = {
        ...state,
        issued: state.issued + 1,
        issuedTotal: state.issuedTotal + 1,
        lastIssueAt: new Date().toISOString(),
        lastIssueSerial: res.signal.serial
    };
    await writeState(next);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ISSUE NX-${String(res.signal.serial).padStart(4, "0")} raw open ${openRaw + 1}/${state.maxOpen}`); // v10.20 — always written (state change)
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])(`ISSUE NX-${String(res.signal.serial).padStart(4, "0")}`, true).catch(()=>undefined); // v9.2 — instant book-curve reaction
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    const milestone = next.issued % 5 === 0 || settledN + 1 >= state.target;
    await fireEvent(null, res.signal.symbol, "ENGINE", milestone ? "ai" : "info", `RAW-CAL ISSUE #${next.issued} → NX-${String(res.signal.serial).padStart(4, "0")} ${res.signal.direction} ${res.signal.symbol} @ ${res.signal.entryPrice} (${res.signal.strategy}, score ${res.signal.confidence}%) — unfiltered capture record, tracked + journaled to ENGINE MEMORY · EPOCH-2 book ${settledN + 1}/${state.target} settled · open raw ${openRaw + 1}/${state.maxOpen}${settledN + 1 >= state.target ? " — TARGET REACHED, mode auto-cancels next tick" : ""}`);
    return {
        issued: true,
        serial: res.signal.serial
    };
}
// ── v11.5 CAPTURE-BOOK REGIME GAUGE (operator question 2026-10-12: «آیا
// رژیم‌سنجی قبل از اعتماد به کتاب کپچر اضافه شده؟») ──
// Two-part engineering answer, both auditable:
//   1) AT ISSUE TIME — the LAYER-0 regime ruling (regimeRuling, engine.ts
//      evaluate()) is NOT bypassed by calCapture: a candidate standing in a
//      vetoed regime (BREAKOUT/MOMENTUM in chop at guard L1, counter-trend
//      mean-revert in trends) never becomes a capture row. Every issued row
//      then carries its REGIME-* tag for life.
//   2) BEFORE TRUSTING THE BOOK — the settled capture book is split BY REGIME
//      (n / WR / net $) so the operator and the AI core trust capture-derived
//      conclusions per regime, not book-wide (a CHOP-heavy book must never be
//      read as a trend verdict). Surfaced on /api/rawcal + RawCalCard.
const REGIME_LABELS = {
    "TREND-UP": "TREND ▲",
    "TREND-DOWN": "TREND ▼",
    CHOP: "CHOP ∿",
    VOLATILE: "VOLATILE ⚡",
    UNKNOWN: "UNKNOWN"
};
async function captureBookRegimeSplit() {
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            tags: true,
            status: true,
            reachedTp: true,
            marginUsd: true,
            pnlPercent: true
        }
    });
    const map = new Map();
    for (const r of rows){
        const tag = r.tags?.split(",").find((t)=>t.startsWith("REGIME-"))?.replace("REGIME-", "") ?? "UNKNOWN";
        const cell = map.get(tag) ?? {
            n: 0,
            wins: 0,
            net: 0
        };
        cell.n += 1;
        if (r.reachedTp >= 1 || r.status === "TP1" || r.status === "TP2" || r.status === "TP3") cell.wins += 1;
        cell.net += r.marginUsd * r.pnlPercent / 100;
        map.set(tag, cell);
    }
    return [
        ...map.entries()
    ].map(([regime, c])=>({
            regime,
            label: REGIME_LABELS[regime] ?? regime,
            n: c.n,
            wins: c.wins,
            winRatePct: c.n ? Number((c.wins / c.n * 100).toFixed(1)) : 0,
            netUsd: Number(c.net.toFixed(2))
        })).sort((a, b)=>b.n - a.n);
}
async function rawCalStatus() {
    const state = await getRawCalState();
    const [settledN, openRaw, totalRaw] = await Promise.all([
        epoch2SettledCount(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }).catch(()=>0),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                }
            }
        }).catch(()=>0)
    ]);
    const settledRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        }
    }).catch(()=>0);
    const winsRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            reachedTp: {
                gte: 1
            }
        }
    }).catch(()=>0);
    // Task 34-2 — ARMS-COUPLED PACE: the AI CALIBRATION bar now reports the
    // shadow-veto arm completion it is geared to (operator mandate 2026-09-26);
    // fail-soft: any probe error keeps the block null instead of breaking status.
    const armsCompletion = await __turbopack_context__.A("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript, async loader)").then(async (m)=>m.shadowArmsCompletion((await m.getShadowVetoConfig()).mode)).catch(()=>null);
    // v11.5 capture-book regime gauge (operator question: رژیم‌سنجی قبل از اعتماد)
    const regimeSplit = await captureBookRegimeSplit().catch(()=>[]);
    // v14.6 winner-lane auto-abort guard (observability on /api/rawcal)
    const v146 = await getV146Guard().catch(()=>null);
    return {
        ...state,
        settledN,
        needed: Math.max(0, state.target - settledN),
        openRaw,
        issuedTotal: totalRaw,
        settledRaw,
        winsRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        spacingMin: state.spacingMin,
        maxOpen: state.maxOpen,
        armsCompletion,
        regimeSplit,
        v146
    };
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__362ab5f2._.js.map