module.exports = [
"[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client-2c3a283f134fdcb6", () => require("@prisma/client-2c3a283f134fdcb6"));

module.exports = mod;
}),
"[externals]/sharp [external] (sharp, cjs, [project]/node_modules/sharp)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("sharp-20c6a5da84e2135f", () => require("sharp-20c6a5da84e2135f"));

module.exports = mod;
}),
];