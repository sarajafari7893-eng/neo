module.exports = [
"[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/raw-cal.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_engine_ts_a98ddc17._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/engine.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/notify.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/lifecycle-learning.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_lifecycle-learning_ts_fe0da598._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/lifecycle-learning.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/shadow-veto.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/calibration.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/calibration.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/flow-scanner.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/flow-scanner.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/oi-funding.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/oi-funding.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/tp3-lab.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_tp3-lab_ts_b51cfcdf._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/tp3-lab.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/persist-guard.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_persist-guard_ts_df2223b0._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/persist-guard.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/_865214cf._.js",
  "server/chunks/src_lib_cde37831._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/ai.ts [app-route] (ecmascript)");
    });
});
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
    });
});
}),
"[project]/src/lib/governor.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_3508cef6._.js",
  "server/chunks/src_lib_governor_ts_3d388e2f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/governor.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/supervisor.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_supervisor_ts_ceea9281._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/supervisor.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/advisor.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_advisor_ts_e1df9e4a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/advisor.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/shadow-modules.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_fc98a463._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/shadow-modules.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/stableflow.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/stableflow.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/futures-taxonomy.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_9bd533fd._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/futures-taxonomy.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/analyst-context.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_3508cef6._.js",
  "server/chunks/src_lib_b8a41ef5._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/analyst-context.ts [app-route] (ecmascript)");
    });
});
}),
"[externals]/node:child_process [external] (node:child_process, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[externals]/node:child_process [external] (node:child_process, cjs)");
    });
});
}),
"[externals]/node:util [external] (node:util, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[externals]_node:util_c428c728._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[externals]/node:util [external] (node:util, cjs)");
    });
});
}),
"[project]/src/lib/db.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/db.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/telegram-bridge.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/telegram-bridge.ts [app-route] (ecmascript)");
    });
});
}),
];