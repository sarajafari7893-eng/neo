module.exports = [
"[project]/src/lib/db.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "configureFapiGate",
    ()=>configureFapiGate,
    "effectiveBudgetPer60s",
    ()=>effectiveBudgetPer60s,
    "fapiBanActivity",
    ()=>fapiBanActivity,
    "fapiBanRemainingMs",
    ()=>fapiBanRemainingMs,
    "fapiEgressStatus",
    ()=>fapiEgressStatus,
    "fapiGateStats",
    ()=>fapiGateStats,
    "gateFetch",
    ()=>gateFetch,
    "isUnknownScopeKey",
    ()=>isUnknownScopeKey,
    "sampleEgressIp",
    ()=>sampleEgressIp
]);
// ── NEXUS//SIGNALS FAPI GATE (server-only, v10.24 — Task 34-a) ──────────────
// Process-wide WEIGHT-BASED token bucket for Binance USDT-M futures REST
// (fapi.binance.com). WHY: 9+ modules in the Next.js process each did their own
// uncoordinated fetch() to the same host and the trade mini-service added
// ~1800 weight/min on top → Binance answered with HTTP 418 IP-bans carrying
// stacked multi-hour "banned until <ms>" windows. This gate is the single
// choke-point every futures-REST call in THIS process must pass:
//
//   · WEIGHT BUDGET — rolling-60s sliding window, default 1100 weight/min
//     (fapi real limit is 2400/min per IP; ~2× headroom absorbs drift between
//     weight estimates and the ungated mini-service until Task 34-b).
//   · LANES — "critical" (engine price feed, trigger measurements) executes
//     immediately when tokens exist, with ONE small negative retry after
//     250ms when momentarily empty; "telemetry" (every rotating scanner/
//     sampler/board) is DROPPED (returns null) when tokens are missing —
//     no unbounded queues, no storm amplification. All callers are
//     null-tolerant by contract.
//   · GLOBAL BAN AWARENESS (refined for the multi-IP egress pool — measured
//     2026-09-26: the sandbox egress rotates across several IPs and Binance's
//     418 body NAMES the banned one: «IP(47.57.x.x) banned until <ms>», with
//     different pool IPs banned in different windows):
//       – 418/429 body naming an IP → PER-IP ban record (capped now+35min),
//         the request's weight is REFUNDED (ban responses carry no weight
//         cost) and the call RETRIES (≤2, 120ms apart) — the pool usually
//         rotates onto a clean IP, so one unlucky draw never starves the app.
//       – ALL retries land on banned IPs → one unlucky draw too many: arm a
//         SHORT 60s global block, and only when that happens 3 times IN A ROW
//         (no successful call between) treat the pool as saturated and arm the
//         full zero-network window min(worst ban end, now+35min). A single
//         clean 2xx resets the streak — self-healing probes.
//       – 418/429 body WITHOUT a parseable IP (unknown scope — the classic
//         single-IP case): arm the global zero-network window immediately —
//         "banned until X" → min(X, now+35min); unparseable 418 → 10min;
//         unparseable 429 → 2min.
//       – While the global window is live, gateFetch returns null INSTANTLY —
//         zero network calls, so a live ban can never be extended by us.
//   · SINGLE-FLIGHT — one shared request per (host,path) while in flight and
//     for a 2s result window, so multiple modules asking the same endpoint
//     inside one tick share one weight spend.
//   · HOST AWARENESS — default host fapi.binance.com, optional alt host
//     (fapi1) for the market-feed availability ladder; bans/weight are
//     per-IP so both hosts share the SAME budget and ban state.
//
// NEVER THROWS: gateFetch returns parsed JSON or null on any failure.
// State lives on globalThis so Turbopack's dev module-graph duplication
// (route graph vs engine graph) still shares ONE process-wide bucket.
//
// SPOT (api.binance.com) and mirror-plane hosts (v14.0 Binance-only) must
// NOT pass through here — futures fapi host only.
//
// ── v12.0 EGRESS/IP MANAGER (Task 44-②, operator order «مدیریت egress/IP
// برای رفع بن fapi») ──────────────────────────────────────────────────────────
// Measured 2026-10-18: the sandbox egress is a rotating NAT pool and Binance
// bans POOL IPs with LONG windows (three named IPs banned until 10-18 19:47Z /
// 22:37Z / 10-19 13:26Z — each plain request is a lottery draw). Three new
// weapons:
//   1. EGRESS SAMPLER — api.ipify.org probe (3.5s timeout, 120s cache,
//      single-flight, never throws) tells us WHICH pool IP a draw exited from.
//   2. ROTATION-AWARE EARLY PROBE — while a global ban window is live, ONE
//      critical-lane call per 120s may bypass the silence IF the sampled IP is
//      clean: the moment the pool rotates, the window LIFTS instantly instead
//      of waiting out the 35min cap. A failed probe costs nothing (banned
//      responses carry no weight) and keeps the window armed.
//   3. BAN-LEDGER PERSISTENCE — named-IP ban records survive process
//      restarts (.data/fapi-gate/bans.json, 30s debounced) so a recycle no
//      longer re-learns the minefield by burning fresh probes.
//
// v10.25 (Task 41, operator order «بایننس ای پی را بلاک نکرده باشد و قابل
// جایگزینی باشد»): the host is env-swappable WITHOUT a code change — if fapi
// is ever hard-blocked (451/region/grey-list, not just a timed 418), set
// NEXUS_FAPI_HOST in .env to a reachable futures-mirror and restart the app.
// Default stays the canonical host. Downstream replaceability ladder is
// already layered: fapi-gate (this) → SPOT-MIRROR aggTrade WS → spot REST
// klines/price fallback → Binance-only liq lanes (v14.0).
//
// ── v14.2 BAN-AWARE RECOVERY PACER (operator order «توصیه‌ها را کامل و مهندسی
// انجام بده», trace 1a1a15fb6bc0bd75 — audit rec #3 «throttle REST بن-آگاه»,
// NX-3247 forensics fc143950) ───────────────────────────────────────────────
// WHY: the old budget was FLAT — the instant a ban window expired the full
// 1100 weight/min came back at once, every starved scanner refilled its
// rotation in the same minute, and the pool re-saturated into a fresh 418
// spiral (measured 10-19: 11:58Z→12:34Z→13:09Z pause spiral). The pacer:
//   · RECOVERY RAMP — for 10min after a global ban window ends, the effective
//     budget ramps 25%→100% linearly. Early recovery minutes carry the
//     CRITICAL lane first (engine price feed / triggers), telemetry scanners
//     stretch back out gradually instead of stampeding.
//   · POOL-DISTRESS CAP — while ≥2 named egress IPs sit inside live ban
//     windows (the 10-18 measurement: 3 named IPs banned simultaneously),
//     the effective budget is capped at 50% — fewer lottery draws, less ban
//     pressure, named-IP evidence stays intel-shaped.
// CRITICAL lane keeps its negative retry; the floor (200/min) is the same
// clamp configureFapiGate enforces, so the pacer can never zero the plane.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
;
const FAPI_HOST = process.env.NEXUS_FAPI_HOST?.trim().replace(/\/+$/, "") || "https://fapi.binance.com";
const DEFAULT_TIMEOUT_MS = 6500;
const WINDOW_MS = 60_000;
const DEFAULT_BUDGET = 1100; // real fapi limit 2400/min per IP — headroom by design
const BAN_CAP_MS = 35 * 60_000; // never record a ban window longer than 35min even if Binance claims hours
// v12.6.1 — mixed-pool era: an UNPARSEABLE 418 is evidence of ONE banned draw,
// not a pool-wide ban (measured 2026-10-20 19:32Z: boot's first draw 418'd
// unparseable while 6/10 fresh connections succeeded — the old 10min arm
// locked the whole app out of a majority-clean pool). 2min + the streak
// escalation ladder covers true saturation.
const BAN_418_DEFAULT_MS = 2 * 60_000; // unparseable 418 → short backoff (was 10min — pool-starvation lesson)
const BAN_429_DEFAULT_MS = 2 * 60_000; // unparseable 429 → short warning backoff
const CRITICAL_RETRY_MS = 250; // the "small negative retry" for the critical lane
const SF_RESULT_MS = 2_000; // single-flight result sharing window
const SF_MAP_CAP = 512;
const SPEND_CAP = 4096; // defensive cap on window entries (~worst-case small-weight bursts)
const BAN_RETRIES = 3; // extra attempts after a named-IP ban (pool rotation)
// v12.6.2 ESCALATING RETRY CADENCE: the NAT egress mapping rotates over ~30s
// (measured 2026-10-20 19:41Z: keep-alive 6×418 → 30s later 6×200), so three
// retries 120ms apart shared ONE doomed mapping. Spacing the retries across
// it (120ms → 2s → 8s) lets draws 2-4 land on a rotated mapping — higher
// per-call success, fewer 60s short blocks. Worst added latency ~10s on a
// banned stretch; the ladder still escalates to the 60s block on failure.
const BAN_RETRY_DELAYS_MS = [
    120,
    2_000,
    8_000
];
const POOL_BLOCK_SHORT_MS = 60_000; // all-retries-banned → short block, let the pool rotate
const POOL_STREAK_FOR_LONG_BLOCK = 3; // consecutive all-banned calls ⇒ pool saturated
const IP_BAN_MAP_CAP = 16;
// ── v12.0 egress manager constants ──
const EGRESS_SAMPLE_TTL_MS = 120_000; // ipify cache — one draw sample per 2min
const EGRESS_TIMEOUT_MS = 3_500;
const PROBE_COOLDOWN_MS = 120_000; // one early-probe attempt per 2min while a window is live
const BAN_PERSIST_DIR = `${process.cwd()}/.data/fapi-gate`;
const BAN_PERSIST_PATH = `${BAN_PERSIST_DIR}/bans.json`;
const BAN_PERSIST_DEBOUNCE_MS = 30_000;
// v14.2 ban-aware recovery pacer
const PACER_RECOVERY_MS = 10 * 60_000; // post-ban ramp window (25%→100%)
const PACER_RAMP_FLOOR = 0.25; // budget fraction at the first recovery minute
const PACER_DISTRESS_CAP = 0.5; // budget cap while ≥2 named IPs are banned live
const PACER_MIN_BUDGET = 200; // same clamp floor as configureFapiGate
// globalThis singleton — survives Turbopack dev module-graph duplication
const g = globalThis;
const state = g.__nexusFapiGate ?? (g.__nexusFapiGate = {
    budgetPer60s: DEFAULT_BUDGET,
    banUntil: 0,
    spend: [],
    windowSum: 0,
    inflight: new Map(),
    ipBans: new Map(),
    recentBanEvents: [],
    allBanStreak: 0,
    aimdFactor: 1,
    lastBanEventAt: 0,
    lastAimdRecoverAt: 0,
    sampledIp: null,
    sampledAt: 0,
    lastBannedIp: null,
    lastProbeAt: 0,
    stats: {
        attempted: 0,
        allowed: 0,
        droppedBudget: 0,
        droppedBan: 0,
        lastBanUntil: 0,
        singleFlightShared: 0,
        retriesAfterBan: 0,
        probesIssued: 0,
        probeLifts: 0,
        effectiveBudgetPer60s: DEFAULT_BUDGET
    }
});
function isUnknownScopeKey(key) {
    return !/^\d{1,3}(\.\d{1,3}){3}$/.test(key); // anything that is not an IPv4 literal ("_pool", hostnames…)
}
try {
    const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
    const nowMs = Date.now();
    let unknownMax = 0;
    let named = 0;
    for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
        if (typeof until !== "number" || until <= nowMs) continue;
        if (isUnknownScopeKey(key)) {
            if (until > unknownMax) unknownMax = until;
        } else {
            state.ipBans.set(key, until);
            named++;
        }
    }
    if (unknownMax > state.banUntil) {
        state.banUntil = unknownMax;
        console.log(`[fapi-gate] v12.6 restored UNKNOWN-SCOPE pool ban from disk — silence armed until ${new Date(unknownMax).toISOString()}`);
    }
    if (state.ipBans.size > 0) {
        // v12.6: named-IP records are INTEL only — no global arm at boot. The
        // first gateFetch takes the lottery draw; a banned draw retries around
        // the named IP (pool rotation) exactly like any other 418.
        console.log(`[fapi-gate] v12.6 restored ${named} named-IP ban record(s) as intel (no global arm — majority-clean pool policy)`);
    }
} catch  {}
let banPersistTimer = null;
function persistBans() {
    if (banPersistTimer) return;
    banPersistTimer = setTimeout(()=>{
        banPersistTimer = null;
        try {
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"])(BAN_PERSIST_DIR, {
                recursive: true
            });
            const nowMs = Date.now();
            const ipBans = {};
            // v12.1 TASK-49 — READ-MERGE-WRITE: mini-services write their own 418
            // discoveries (incl. "_pool" unknown-scope markers with REAL ends) to
            // this same file. Blindly overwriting with state-only data DELETED a
            // 15:20Z pool ban mid-storm (2026-10-19) — never shorten/lose foreign
            // entries: merge disk first, then overlay ours, keep live only.
            try {
                const disk = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
                for (const [ip, until] of Object.entries(disk?.ipBans ?? {})){
                    if (typeof until === "number" && until > nowMs) ipBans[ip] = until;
                }
            } catch  {
            /* no ledger yet */ }
            for (const [ip, until] of state.ipBans)if (until > nowMs) ipBans[ip] = Math.max(ipBans[ip] ?? 0, until);
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["writeFileSync"])(BAN_PERSIST_PATH, JSON.stringify({
                savedAt: new Date().toISOString(),
                ipBans
            }, null, 1));
        } catch  {}
    }, BAN_PERSIST_DEBOUNCE_MS);
}
// ── v12.0 egress IP sampler (which pool IP did this draw exit from?) ──
let egressInflight = null;
async function sampleEgressIp() {
    if (state.sampledIp && Date.now() - state.sampledAt < EGRESS_SAMPLE_TTL_MS) return state.sampledIp;
    if (egressInflight) return egressInflight;
    egressInflight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const t = setTimeout(()=>ctrl.abort(), EGRESS_TIMEOUT_MS);
            const res = await fetch("https://api.ipify.org?format=json", {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(t);
            if (!res.ok) return null;
            const j = await res.json();
            const ip = typeof j.ip === "string" && j.ip ? j.ip : null;
            if (ip) {
                state.sampledIp = ip;
                state.sampledAt = Date.now();
            }
            return ip;
        } catch  {
            return null; // sampler down — never blocks the gate (fail-open)
        } finally{
            egressInflight = null;
        }
    })();
    return egressInflight;
}
function fapiEgressStatus() {
    const now = Date.now();
    const bannedIps = [];
    for (const [ip, until] of state.ipBans)if (until > now) bannedIps.push({
        ip,
        until,
        remainingMs: until - now
    });
    bannedIps.sort((a, b)=>b.until - a.until);
    return {
        banUntil: state.banUntil,
        banRemainingMs: Math.max(0, state.banUntil - now),
        sampledIp: state.sampledIp,
        sampledAt: state.sampledAt || null,
        lastBannedIp: state.lastBannedIp,
        bannedIps,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        lastProbeAt: state.lastProbeAt
    };
}
function configureFapiGate(opts) {
    if (opts?.budgetPer60s !== undefined) {
        const b = Math.max(200, Math.min(2300, Math.round(opts.budgetPer60s)));
        state.budgetPer60s = b;
    }
}
function fapiBanRemainingMs() {
    return Math.max(0, state.banUntil - Date.now());
}
function fapiBanActivity() {
    const now = Date.now();
    const globalRemainingMs = Math.max(0, state.banUntil - now);
    const namedLiveIps = namedLiveBanCount(now);
    if (globalRemainingMs > 0) {
        return {
            active: true,
            reason: `fapi GLOBAL ban window live — ${Math.round(globalRemainingMs / 1000)}s left`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    if (namedLiveIps >= 2) {
        return {
            active: true,
            reason: `fapi pool distress — ${namedLiveIps} named egress IPs inside live ban windows`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    return {
        active: false,
        reason: null,
        globalRemainingMs,
        namedLiveIps,
        effectiveBudgetPer60s: effectiveBudgetPer60s()
    };
}
function fapiGateStats() {
    const now = Date.now();
    pruneWindow(now);
    let bannedIps = 0;
    for (const [, until] of state.ipBans)if (until > now) bannedIps++;
    return {
        attempted: state.stats.attempted,
        allowed: state.stats.allowed,
        droppedBudget: state.stats.droppedBudget,
        droppedBan: state.stats.droppedBan,
        lastBanUntil: state.stats.lastBanUntil,
        budgetPer60s: state.budgetPer60s,
        usedLast60s: state.windowSum,
        singleFlightShared: state.stats.singleFlightShared,
        banRemainingMs: fapiBanRemainingMs(),
        bannedPoolIps: bannedIps,
        retriesAfterBan: state.stats.retriesAfterBan,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        effectiveBudgetPer60s: effectiveBudgetPer60s(),
        aimdFactor: Number(state.aimdFactor.toFixed(3))
    };
}
// ── weight table (Binance USDT-M futures documented weights) ────────────────
// klines ~2 (limit≤100) · depth 2-5-10 by limit · aggTrades 20 · trades 20 ·
// ticker/24hr 1 per-symbol / 40 full-universe · premiumIndex 1 per-symbol /
// 10 all-markers · futures/data/* 1 (openInterestHist, L/S ratios, basis…) ·
// exchangeInfo 1 · ping/time 1 · unknown default 5 (conservative).
function resolveWeight(path) {
    const qIdx = path.indexOf("?");
    const ep = (qIdx === -1 ? path : path.slice(0, qIdx)).replace(/^\//, "").replace(/\/+$/, "");
    const query = qIdx === -1 ? "" : path.slice(qIdx + 1);
    const limit = ()=>{
        const m = /[?&]limit=(\d+)/.exec(query);
        return m ? Number(m[1]) : null;
    };
    switch(ep){
        case "fapi/v1/ping":
        case "fapi/v1/time":
        case "fapi/v1/exchangeInfo":
            return 1;
        case "fapi/v1/klines":
            {
                const l = limit() ?? 500;
                return l <= 100 ? 2 : l <= 499 ? 5 : 10;
            }
        case "fapi/v1/depth":
            {
                const l = limit() ?? 100;
                return l <= 100 ? 2 : l <= 500 ? 5 : 10;
            }
        case "fapi/v1/aggTrades":
        case "fapi/v1/trades":
            return 20;
        case "fapi/v1/ticker/24hr":
            return /[?&]symbol=/.test(query) ? 1 : 40;
        case "fapi/v1/premiumIndex":
            return /[?&]symbol=/.test(query) ? 1 : 10;
        default:
            if (ep.startsWith("futures/data/")) return 1; // openInterestHist / L-S ratios / basis family
            return 5; // unknown → conservative default (covers fapi/v1/fundingRate etc.)
    }
}
function pruneWindow(now) {
    const cutoff = now - WINDOW_MS;
    while(state.spend.length > 0 && state.spend[0].at <= cutoff){
        const e = state.spend.shift();
        state.windowSum -= e.w;
    }
    if (state.spend.length > SPEND_CAP) {
        // defensive: drop the oldest half rather than grow unbounded
        const keep = state.spend.slice(Math.floor(state.spend.length / 2));
        let sum = 0;
        for (const e of keep)sum += e.w;
        state.spend = keep;
        state.windowSum = sum;
    }
}
/** Reserve `weight` from the rolling window. Returns the spend entry (for refunds) or null. */ // ── v14.2 BAN-AWARE RECOVERY PACER ────────────────────────────────────────
// The ONLY budget the rolling window spends against. A flat budget after a
// ban ended = instant re-saturation stampede (the 10-19 spiral); the pacer
// gives the pool a 10min ramp and caps telemetry while the pool shows live
// distress. Global-window minutes are NOT handled here (gateFetch drops
// everything while the window is live) — the pacer shapes the BEFORE
// (distress) and AFTER (recovery) of each ban episode.
function namedLiveBanCount(now) {
    let n = 0;
    for (const [, until] of state.ipBans)if (until > now) n++;
    return n;
}
// ── v14.3 ROLLING-CYCLE AIMD PACER (chapter-7 item ② «backoff واقعی», operator
// mandate trace 1a1a8ea4186c6571) — the missing third leg of the v14.2 pacer.
// Measured failure mode (engineering report NX3247+LIVE): the 3-IP egress pool
// rides a ROLLING ~20min ban cycle — bans expire, the full budget floods back
// instantly (named-IP bans never armed the global window ⇒ no ramp), the pool
// re-saturates in the same minute and re-bans. Fix: an AIMD shed factor that
// DECREASES multiplicatively on every named-IP ban event (×0.7, floor 0.25) and
// recovers ADDITIVELY during clean minutes (+0.05/min, cap 1.0). Sustained ban
// churn ⇒ progressively quieter pool without any operator tuning; a genuinely
// healthy pool heals back to full budget in ~15 clean minutes.
const AIMD_DROP = 0.7;
const AIMD_FLOOR = 0.25;
const AIMD_RECOVER_PER_MIN = 0.05;
function recoverAimd(now) {
    if (state.aimdFactor >= 1) {
        state.lastAimdRecoverAt = now;
        return;
    }
    if (state.lastBanEventAt === 0) return;
    const anchor = Math.max(state.lastAimdRecoverAt, state.lastBanEventAt);
    const cleanMin = Math.floor((now - anchor) / 60_000);
    if (cleanMin <= 0) return;
    state.aimdFactor = Math.min(1, state.aimdFactor + cleanMin * AIMD_RECOVER_PER_MIN);
    state.lastAimdRecoverAt = now;
}
function noteAimdBanEvent(now) {
    recoverAimd(now);
    state.aimdFactor = Math.max(AIMD_FLOOR, state.aimdFactor * AIMD_DROP);
    state.lastBanEventAt = now;
    state.lastAimdRecoverAt = now;
}
function effectiveBudgetPer60s() {
    const now = Date.now();
    let factor = 1;
    recoverAimd(now); // v14.3 — additive clean-minute recovery before clamping
    factor = Math.min(factor, state.aimdFactor);
    // POOL DISTRESS — ≥2 named egress IPs inside live ban windows: cap telemetry.
    if (namedLiveBanCount(now) >= 2) factor = Math.min(factor, PACER_DISTRESS_CAP);
    // RECOVERY RAMP — 10min linear 25%→100% after the last global window ends.
    if (state.banUntil > 0) {
        const sinceBan = now - state.banUntil;
        if (sinceBan >= 0 && sinceBan < PACER_RECOVERY_MS) {
            factor = Math.min(factor, PACER_RAMP_FLOOR + (1 - PACER_RAMP_FLOOR) * (sinceBan / PACER_RECOVERY_MS));
        }
    }
    return Math.max(PACER_MIN_BUDGET, Math.round(state.budgetPer60s * factor));
}
function takeWeight(weight) {
    const now = Date.now();
    pruneWindow(now);
    if (state.windowSum + weight > effectiveBudgetPer60s()) return null;
    const entry = {
        at: now,
        w: weight
    };
    state.spend.push(entry);
    state.windowSum += weight;
    return entry;
}
/** 418/429 responses carry no weight cost — give the reservation back. */ function refundWeight(entry) {
    if (!entry) return;
    const idx = state.spend.indexOf(entry);
    if (idx === -1) return; // already pruned out of the window (its cost is gone too)
    state.spend.splice(idx, 1);
    state.windowSum -= entry.w;
}
function armGlobalBan(until) {
    if (until > state.banUntil) {
        state.banUntil = until;
        state.stats.lastBanUntil = until;
    }
}
/** Record a 418/429 body. Returns { ip, until } when the body NAMES the banned egress IP. */ function noteBanBody(status, body) {
    const now = Date.now();
    const named = /IP\(([\d.]+)\)\s*banned until (\d+)/i.exec(body);
    if (named) {
        const ip = named[1];
        // v12.1 TASK-49: the LEDGER carries Binance's REAL end (sanity-capped 24h) —
        // the cosmetic +35min cap only applies to the global silence window below.
        // Capping the ledger made the early probe fire at a fake expiry and the
        // resulting 418 contact re-escalated the real ban (11:58→12:34→13:09 spiral).
        const realUntil = Math.min(Number(named[2]), now + 24 * 60_000);
        const until = Math.min(realUntil, now + BAN_CAP_MS);
        state.ipBans.set(ip, realUntil);
        state.lastBannedIp = ip;
        persistBans(); // v12.0 — named-IP ban ledger survives restarts (30s debounce)
        if (state.ipBans.size > IP_BAN_MAP_CAP) {
            // evict the soonest-expiring record
            let oldestKey = null;
            let oldestVal = Infinity;
            for (const [k, v] of state.ipBans)if (v < oldestVal) {
                oldestVal = v;
                oldestKey = k;
            }
            if (oldestKey) state.ipBans.delete(oldestKey);
        }
        state.recentBanEvents.push({
            at: now,
            ip
        });
        if (state.recentBanEvents.length > 64) state.recentBanEvents.splice(0, state.recentBanEvents.length - 64);
        noteAimdBanEvent(now); // v14.3 — every named-IP ban deepens the rolling-cycle shed
        return {
            ip,
            until
        };
    }
    const untilMatch = /banned until (\d+)/i.exec(body);
    if (untilMatch) {
        armGlobalBan(Math.min(Number(untilMatch[1]), now + BAN_CAP_MS)); // unknown scope — assume it's us
        return null;
    }
    // unparseable body — conservative defaults (taxonomy precedent for 418)
    armGlobalBan(now + (status === 429 ? BAN_429_DEFAULT_MS : BAN_418_DEFAULT_MS));
    return null;
}
/** Every retry landed on a (named) banned IP — escalate the global silence window. */ function escalatePoolBlock(worstNamedUntil) {
    const now = Date.now();
    state.allBanStreak++;
    if (state.allBanStreak >= POOL_STREAK_FOR_LONG_BLOCK) {
        // repeated independent evidence — the egress pool is saturated: full
        // zero-network window, capped at 35min, then a fresh probe self-heals.
        armGlobalBan(Math.min(worstNamedUntil, now + BAN_CAP_MS));
        state.allBanStreak = 0;
    } else {
        armGlobalBan(now + POOL_BLOCK_SHORT_MS);
    }
}
function pruneInflight(now) {
    for (const [k, e] of state.inflight){
        if (e.settled && now - e.startedAt >= SF_RESULT_MS) state.inflight.delete(k);
    }
}
function delay(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}
/**
 * THE gate body. Resolves parsed JSON, or null on: live IP ban, weight-budget
 * shed, HTTP failure, timeout, or parse error. Never throws, never queues.
 */ async function executeGated(path, opts) {
    const lane = opts?.priority ?? "telemetry";
    const weight = Math.max(1, Math.round(opts?.weight ?? resolveWeight(path)));
    const timeoutMs = opts?.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    let entry = takeWeight(weight);
    if (!entry) {
        if (lane !== "critical") {
            state.stats.droppedBudget++;
            return null; // telemetry: drop instead of queueing a storm
        }
        await delay(CRITICAL_RETRY_MS); // one small negative retry
        entry = takeWeight(weight);
        if (!entry) {
            state.stats.droppedBudget++;
            return null;
        }
    }
    const host = opts?.host ?? FAPI_HOST;
    let attempt = 0;
    while(true){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        let res;
        try {
            // v12.6.1 CONNECTION-RECYCLE (measured 2026-10-20 19:41Z, bun runtime):
            // a keep-alive fetch POOLS one TCP flow ⇒ ONE egress IP for its whole
            // life — a pinned-banned connection turned 231 gate calls into 0 allowed
            // while 6/10 fresh connections succeeded. `Connection: close` = a fresh
            // NAT lottery draw per request; the TLS cost (~60ms) is trivial next to
            // the starvation it prevents.
            res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store",
                headers: {
                    Connection: "close"
                }
            });
        } catch  {
            return null; // timeout/abort/network — weight may have been consumed, keep the reservation
        } finally{
            clearTimeout(timer);
        }
        if (res.ok) {
            const text = await res.text().catch(()=>"");
            if (!text) return null; // empty 200 — nothing to invent
            state.stats.allowed++;
            state.allBanStreak = 0; // a clean 2xx proves the pool still serves us
            try {
                return JSON.parse(text);
            } catch  {
                return null;
            }
        }
        if (res.status === 418 || res.status === 429) {
            const body = await res.text().catch(()=>"");
            refundWeight(entry); // banned responses carry no weight cost
            entry = null;
            const named = noteBanBody(res.status, body);
            if (opts?.singleProbe) return null; // v12.0 early probe — single attempt, window stays armed
            if (!named) return null; // unknown-scope ban — global zero-network window already armed
            if (attempt >= BAN_RETRIES) {
                escalatePoolBlock(named.until);
                return null;
            }
            attempt++;
            state.stats.retriesAfterBan++;
            await delay(BAN_RETRY_DELAYS_MS[Math.min(attempt - 1, BAN_RETRY_DELAYS_MS.length - 1)]); // span the NAT rotation window
            entry = takeWeight(weight);
            if (!entry) {
                state.stats.droppedBudget++;
                return null;
            }
            continue;
        }
        return null; // other non-ok status — honest null, no retry
    }
}
/** v12.1 TASK-49 — a recorded ban counts ONLY while its real end is in the future. */ function isIpBanned(ip, now) {
    if (!ip) return false;
    return (state.ipBans.get(ip) ?? 0) > now;
}
// v12.1 TASK-49 — SHARED LEDGER REFRESH: trade-service / price-ws write their
// own 418 discoveries (with REAL ends) to the same bans.json. Merge live disk
// entries into state every 30s (extend-only). v12.6 scope split: UNKNOWN-SCOPE
// entries extend the global silence (pool-suspect evidence); NAMED-IP entries
// merge into ipBans as intel only — a majority-clean pool must not be
// blacked out because one pool member drew a ban.
let lastLedgerCheckAt = 0;
function refreshLedgerOnce() {
    const nowMs = Date.now();
    lastLedgerCheckAt = nowMs;
    try {
        const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
        let unknownMax = 0;
        for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
            if (typeof until !== "number" || until <= nowMs) continue;
            if (isUnknownScopeKey(key)) {
                if (until > unknownMax) unknownMax = until;
                continue;
            }
            if (until > (state.ipBans.get(key) ?? 0)) state.ipBans.set(key, until);
        }
        // unknown-scope knowledge extends the global silence window (extend-only)
        if (unknownMax > state.banUntil) {
            state.banUntil = unknownMax;
            console.log(`[fapi-gate] v12.6 ledger refresh — UNKNOWN-SCOPE pool ban extends silence until ${new Date(unknownMax).toISOString()}`);
        }
    } catch  {
    /* ledger gone/unreadable — keep in-memory state */ }
}
try {
    const refresh = setInterval(refreshLedgerOnce, 30_000);
    if (typeof refresh.unref === "function") refresh.unref();
} catch  {
/* non-blocking env — skip refresh */ }
async function gateFetch(path, opts) {
    state.stats.attempted++;
    const now = Date.now();
    // v12.1 TASK-49 — LAZY LEDGER GUARD: the instant our global window expires,
    // re-check the shared ledger (throttled to one disk read / 15s) BEFORE any
    // network call — closes the poke-gap where the window died but the refresh
    // interval hadn't fired yet. While the pool is ledger-banned, zero pokes.
    if (now >= state.banUntil && now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
    if (now < state.banUntil) state.stats.droppedBan++; // ledger re-armed the window — shed instantly
    // GLOBAL BAN AWARENESS — while a global ban window is live, zero network calls
    // …except the v12.0 ROTATION-AWARE EARLY PROBE: one critical-lane attempt per
    // PROBE_COOLDOWN_MS when the sampled egress IP is clean — the pool rotates,
    // so the window can be LIFTED the moment a clean draw appears instead of
    // waiting out the full 35min cap. A failed probe keeps the window armed.
    if (now < state.banUntil) {
        state.stats.droppedBan++;
        const canProbe = (opts?.priority ?? "telemetry") === "critical" && now - state.lastProbeAt >= PROBE_COOLDOWN_MS;
        if (!canProbe) return null;
        // v12.1 TASK-49 — LEDGER FRESHNESS BEFORE PROBE: state may hold a cosmetic
        // cap while the disk carries a longer REAL end another process discovered.
        // A probe fired on stale state pokes a still-banned pool and re-escalates.
        // Re-read the ledger (15s throttle) and re-arm BEFORE the probe decision.
        if (now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
        if (now < state.banUntil) return null; // ledger extended the silence — no probe
        state.lastProbeAt = now;
        const ip = await sampleEgressIp();
        // v12.1 TASK-49: expiry-aware check — a recorded ban whose real end passed
        // no longer blocks the probe (the old .has() kept ghost entries armed).
        if (!ip || isIpBanned(ip, now)) return null; // sampled draw is banned/unknown — stay silent
        state.stats.probesIssued++;
        const probeResult = await executeGated(path, {
            ...opts,
            singleProbe: true
        });
        if (probeResult !== null) {
            state.banUntil = 0; // clean draw proved the pool rotated — lift instantly
            state.allBanStreak = 0;
            state.stats.probeLifts++;
            console.log(`[fapi-gate] v12.0 ban window LIFTED early — egress rotated to clean IP ${ip}`);
        }
        return probeResult;
    }
    // SINGLE-FLIGHT per (host,path): share the request while it is in flight and
    // for a 2s result window — concurrent module askers pay the weight once.
    const key = `${opts?.host ?? FAPI_HOST}${path}`;
    const existing = state.inflight.get(key);
    if (existing) {
        const age = now - existing.startedAt;
        if (!existing.settled || age < SF_RESULT_MS) {
            state.stats.singleFlightShared++;
            return existing.promise;
        }
        state.inflight.delete(key);
    }
    if (state.inflight.size >= SF_MAP_CAP) pruneInflight(now);
    const promise = executeGated(path, opts);
    const entry = {
        startedAt: now,
        settled: false,
        promise
    };
    state.inflight.set(key, entry);
    void promise.catch(()=>null) // executeGated never rejects — belt & suspenders
    .finally(()=>{
        entry.settled = true;
    });
    return promise;
}
}),
"[project]/src/lib/trade-flow.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getTape",
    ()=>getTape,
    "getTapeFlow",
    ()=>getTapeFlow,
    "getTapeHealth",
    ()=>getTapeHealth,
    "syncTapeWatchlist",
    ()=>syncTapeWatchlist
]);
// ── NEXUS//SIGNALS Real-Tape client (server-only) ──
// Thin, fault-tolerant client for the trade-service mini-service
// (mini-services/trade-service, port 3011) which ingests REAL Binance
// USDT-M aggregate trades (WS !aggTrade with incremental REST fallback)
// and computes per-symbol real CVD, CVD-vs-price divergence (classic +
// hidden, ZitaPlus/LuxAlgo taxonomy) and VPIN-lite.
//
// HONESTY CONTRACT: if the service is down, stalled or a symbol has no
// tape yet this returns null — the research stack then reports the factor
// as UNAVAILABLE. Nothing is ever invented here.
const TAPE_URL = process.env.TRADE_SERVICE_URL ?? "http://127.0.0.1:3011";
const FETCH_TIMEOUT_MS = 2500;
const SNAP_TTL_MS = 15_000;
const cache = new Map();
const inFlight = new Map();
async function fetchFlow(symbol) {
    const ctrl = new AbortController();
    const t = setTimeout(()=>ctrl.abort(), FETCH_TIMEOUT_MS);
    try {
        const res = await fetch(`${TAPE_URL}/flow?symbol=${encodeURIComponent(symbol)}`, {
            signal: ctrl.signal,
            cache: "no-store"
        });
        clearTimeout(t);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const snap = await res.json();
        cache.set(symbol, {
            snap,
            ts: Date.now()
        });
        return snap;
    } catch  {
        clearTimeout(t);
        return null;
    }
}
async function getTapeFlow(symbol) {
    const c = cache.get(symbol);
    if (c && Date.now() - c.ts < SNAP_TTL_MS) return c.snap;
    const running = inFlight.get(symbol);
    if (running) return running;
    const job = fetchFlow(symbol).finally(()=>{
        inFlight.delete(symbol);
    });
    inFlight.set(symbol, job);
    return job;
}
async function getTape(symbol) {
    const snap = await getTapeFlow(symbol);
    if (!snap || !snap.flow) return null;
    if (snap.dataStalled && snap.source !== "REST") return null; // frames stripped, no fallback — no numbers
    return snap.flow;
}
async function syncTapeWatchlist(symbols) {
    try {
        const ctrl = new AbortController();
        const t = setTimeout(()=>ctrl.abort(), 3000);
        const res = await fetch(`${TAPE_URL}/watch`, {
            method: "POST",
            headers: {
                "content-type": "application/json"
            },
            body: JSON.stringify({
                symbols: symbols.slice(0, 80)
            }),
            signal: ctrl.signal
        });
        clearTimeout(t);
        return res.ok;
    } catch  {
        return false;
    }
}
async function getTapeHealth() {
    try {
        const ctrl = new AbortController();
        const t = setTimeout(()=>ctrl.abort(), 2000);
        const res = await fetch(`${TAPE_URL}/health`, {
            signal: ctrl.signal,
            cache: "no-store"
        });
        clearTimeout(t);
        if (!res.ok) throw new Error("bad status");
        const h = await res.json();
        return {
            reachable: true,
            connected: h.connected,
            source: h.source ?? "UNKNOWN",
            symbols: h.symbols ?? 0,
            trades: h.trades ?? 0,
            dataStalled: h.dataStalled !== false
        };
    } catch  {
        return {
            reachable: false,
            connected: false,
            source: "OFFLINE",
            symbols: 0,
            trades: 0,
            dataStalled: true
        };
    }
}
}),
"[project]/src/lib/liquidations.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLiquidationSnapshot",
    ()=>getLiquidationSnapshot,
    "getLiquidationStatus",
    ()=>getLiquidationStatus,
    "liquidationPressure",
    ()=>liquidationPressure
]);
// ── FlowRadar Neo liquidation feed client (server-only) ──
// Reads mini-services/liq-service (:3010). Honesty contract: when the stream
// is stalled or down we return null — never a fabricated "quiet tape".
const LIQ_URL = process.env.LIQ_SERVICE_URL ?? "http://localhost:3010";
const TIMEOUT_MS = 2500;
const CACHE_TTL = 20_000;
let cache = null;
let inFlight = null;
async function getLiquidationSnapshot() {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.snap;
    if (inFlight) return inFlight;
    inFlight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${LIQ_URL}/liquidations`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (!res.ok) throw new Error(`liq ${res.status}`);
            const snap = await res.json();
            cache = {
                at: Date.now(),
                snap
            };
            return snap;
        } catch  {
            cache = {
                at: Date.now(),
                snap: null
            };
            return null;
        } finally{
            inFlight = null;
        }
    })();
    return inFlight;
}
async function getLiquidationStatus() {
    const snap = await getLiquidationSnapshot();
    if (!snap) return null;
    return {
        online: true,
        ...snap.status
    };
}
async function liquidationPressure(symbol) {
    const snap = await getLiquidationSnapshot();
    if (!snap || snap.status.dataStalled || !snap.status.connected) return null;
    const row = snap.bySymbol[symbol];
    if (!row) return {
        usd10m: 0,
        longsUsd10m: 0,
        shortsUsd10m: 0
    };
    return {
        usd10m: row.usd10m,
        longsUsd10m: row.longsUsd10m,
        shortsUsd10m: row.shortsUsd10m
    };
}
}),
"[project]/src/lib/spot-host-gate.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noteSpotHostThrottle",
    ()=>noteSpotHostThrottle,
    "spotHostReady",
    ()=>spotHostReady,
    "spotHostsReady",
    ()=>spotHostsReady,
    "spotLadderJson",
    ()=>spotLadderJson
]);
// ── NEXUS//SIGNALS spot-host gate (v13.2.1 SPOT-BAN-BACKOFF) ────────────────
// Completes the v13.2 SPOT-HOST LADDER: the ladder could DETECT a 418/429
// (fall through to the next rung) but had NO per-host backoff, so every tick
// re-poked the banned host first — wasting weight and keeping ban pressure
// alive. Live evidence 2026-10-25T00:48Z: data-api.binance.vision flapped
// 429/418 at x-mbx-used-weight-1m: 467 with retry-after: 889s while fapi
// served 200 @73ms (separate ban pools per host confirmed).
//
// Contract (read-only, zero data invention):
//   · 418 → host silent for retry-after seconds (capped 15min)
//   · 429 → soft 60s pause (retry-after respected when present)
//   · ladders ask spotHostsReady() and skip mid-ban hosts → traffic
//     auto-redistributes to the healthy rung and slides back on expiry.
//   · globalThis dedupe — Turbopack can instantiate per-route bundles; the
//     engine tick loop and /api routes MUST share one ban map (fbStats pattern).
const CAP_MS = 15 * 60_000;
const g = globalThis;
g.__nexusSpotHostGate ??= {
    bannedUntil: {}
};
const S = g.__nexusSpotHostGate;
function spotHostReady(host, now = Date.now()) {
    return (S.bannedUntil[host] ?? 0) <= now;
}
function spotHostsReady(hosts, now = Date.now()) {
    return hosts.filter((h)=>spotHostReady(h, now));
}
function noteSpotHostThrottle(host, status, headers) {
    const now = Date.now();
    let ms = status === 418 ? CAP_MS : 60_000;
    const ra = Number(headers.get("retry-after"));
    if (Number.isFinite(ra) && ra > 0) ms = Math.min(ra * 1000, CAP_MS);
    const prev = S.bannedUntil[host] ?? 0;
    if (prev < now + 1000) {
        console.warn(`[spot-host-gate] ${host} → ${status} — leg silent ${Math.round(ms / 1000)}s (weight1m=${headers.get("x-mbx-used-weight-1m") ?? "?"})`);
    }
    S.bannedUntil[host] = Math.max(prev, now + ms);
}
async function spotLadderJson(path, hosts, timeoutMs = 8000) {
    for (const host of spotHostsReady(hosts)){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        try {
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                noteSpotHostThrottle(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) continue;
            return await res.json();
        } catch  {
            continue;
        } finally{
            clearTimeout(timer);
        }
    }
    return null;
}
}),
"[project]/src/lib/futures-taxonomy.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FUTURES_ANCHORS",
    ()=>FUTURES_ANCHORS,
    "QUADRANT_META",
    ()=>QUADRANT_META,
    "binanceBackoffRemainingMs",
    ()=>binanceBackoffRemainingMs,
    "buildFuturesEdge",
    ()=>buildFuturesEdge,
    "classifyQuadrant",
    ()=>classifyQuadrant,
    "ensureBackfill",
    ()=>ensureBackfill,
    "getFuturesLive",
    ()=>getFuturesLive,
    "maybeFuturesSample",
    ()=>maybeFuturesSample,
    "settleFuturesForwards",
    ()=>settleFuturesForwards
]);
// ── v10.22 FUTURES TAXONOMY ENGINE (server-only) ────────────────────────────
// Operator mandate: «هدف از این کار جمع‌آوری داده و اطلاعات است تا با ذخیره و
// یادگیری بهترین فیلتر رو شناسایی کنیم» — the de-restriction of v10.22 exists
// to generate unbiased samples; this module is the instrument that harvests,
// STORES and LEARNS from them across the five futures-signal families:
//
//   A  Positioning      funding rate + crowd/top L/S ratios
//   B  Aggressor flow   real-tape CVD (trade-service :3011)
//   C  Forced flow      liquidations (liq-service :3010)
//   D  Structure        OI × Price four-quadrant (the operator's framework)
//   E  Cross-plane     funding/OI divergence across Binance planes (v14.0)
//
// Design doctrine:
//  · Boards get overwritten — learning needs HISTORY, so every sample is a
//    persisted FuturesSnapshot row (Prisma time-series, 30d + 100k cap).
//  · BACKFILL (one-shot, 1h grid ~14d) gives the quadrant study immediate
//    depth; stream-only families (CVD/liq/cross-exchange) stay honestly NULL
//    there. LIVE rows sample every ~5min with the full five-family read.
//  · Forward returns (15m/1h/4h, unlevered) settle lazily from the series
//    itself — no extra REST cost.
//  · The learner joins settled rows + the settled SIGNAL book into ranked
//    filter candidates; `bestFilter` is only claimed with n ≥ 20 and
//    median/mean sign agreement — otherwise it stays "COLLECTING" (honest).
//  · Nothing here touches the deploy path. Telemetry + learning only.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$trade$2d$flow$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/trade-flow.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [instrumentation] (ecmascript)");
;
;
;
;
;
const FUTURES_ANCHORS = [
    "BTCUSDT",
    "ETHUSDT"
];
const SAMPLE_INTERVAL_MS = 5 * 60_000;
const SETTLE_INTERVAL_MS = 6 * 60_000;
const PRUNE_INTERVAL_MS = 60 * 60_000;
const RETENTION_DAYS = 30;
const HARD_CAP = 100_000;
const EDGE_CACHE_TTL = 10 * 60_000;
const BACKFILL_HOURS = 336; // 14 days of 1h grid
const ATTRIBUTION_FENCE_MS = 10 * 60_000; // signal ↔ snapshot join fence
const SETTLED_TARGET = 720; // maturity bar for bestFilter claims
const QUADRANT_META = {
    Q1_FRESH_LONG: {
        label: "FRESH LONG",
        price: "UP",
        oi: "UP",
        meaning: "new long money — healthy uptrend",
        signal: "continuation"
    },
    Q2_SQUEEZE: {
        label: "SHORT SQUEEZE",
        price: "UP",
        oi: "DOWN",
        meaning: "shorts covering — no fresh money",
        signal: "fade the rally"
    },
    Q3_FRESH_SHORT: {
        label: "FRESH SHORT",
        price: "DOWN",
        oi: "UP",
        meaning: "new short money — healthy downtrend",
        signal: "continuation"
    },
    Q4_CAPITULATION: {
        label: "CAPITULATION",
        price: "DOWN",
        oi: "DOWN",
        meaning: "longs forced out — possible bottom",
        signal: "get ready"
    }
};
function classifyQuadrant(priceDelta, oiDelta) {
    if (priceDelta === null || oiDelta === null || !Number.isFinite(priceDelta) || !Number.isFinite(oiDelta)) return null;
    const pUp = priceDelta >= 0;
    const oiUp = oiDelta >= 0;
    if (pUp && oiUp) return "Q1_FRESH_LONG";
    if (pUp && !oiUp) return "Q2_SQUEEZE";
    if (!pUp && oiUp) return "Q3_FRESH_SHORT";
    return "Q4_CAPITULATION";
}
function binanceBackoffRemainingMs() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fapiBanRemainingMs"])();
}
async function fapi(path, timeoutMs = 6500) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "telemetry",
        timeoutMs
    });
}
async function jsonUrl(url, timeoutMs = 6500) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
    try {
        const res = await fetch(url, {
            signal: ctrl.signal,
            cache: "no-store"
        });
        if (!res.ok) return null;
        return await res.json();
    } catch  {
        return null;
    } finally{
        clearTimeout(timer);
    }
}
// ── Task 34-4 SPOT-MIRROR FALLBACKS (2026-09-26) ───────────────────────────
// The fapi (USDT-M) REST pool carries stacked multi-hour 418 bans while the
// SPOT api (api.binance.com) is a SEPARATE host with its own rate budget and
// kept answering 200 throughout the ban storm (measured). During fapi ban
// windows the sampler now mirrors PRICE and KLINE closes from the spot API so
// quadrant rows keep flowing; futures-only families (OI, funding, LS ratios)
// stay honestly NULL — no invented data. Spot klines share the candle shape.
// v13.2 SPOT-HOST LADDER (operator mandate trace 1a1704d407f00dad): the Binance
// public data mirror (data-api.binance.vision) is the PRIMARY spot host —
// measured 32/32 HTTP 200 p50 57ms on 2026-10-25 while api.binance.com rides
// 418 ban-storms from this shared egress. api.binance.com stays as fallback.
// v13.2.3 (trace 1a170bba02dff781): api1-4 added (200 @356-408ms probed 2026-10-25).
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp (restored 1a1849f647778885)
// v13.2.1 — per-host 418/429 backoff via the shared spot-host gate.
async function spotPrice(symbol) {
    const j = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["spotLadderJson"])(`/api/v3/ticker/price?symbol=${symbol}`, SPOT_HOSTS);
    const p = j?.price ? Number(j.price) : NaN;
    return Number.isFinite(p) && p > 0 ? p : null;
}
async function spotKlines(symbol, interval, limit) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["spotLadderJson"])(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, SPOT_HOSTS);
}
// ── v13.3.1 BYBIT-PUBLIC MIRROR (trace 1a19469b82a27fd9 — operator mandate
// «مورد ۴»: سیستم بدون مهاجرت در همین محیط باید سالم لایو کار کند) ───────────
// The sandbox egress rides shared-IP 429/418 ban-storms on Binance fapi; the
// ETH anchor lost OI/funding/LS for HOURS (10/12 rows in the last 3h had null
// OI → quadrant grid dark → operator read the module as "no live data").
// Bybit v5 public market endpoints are KEYLESS, reachable from this egress
// (probed 200 @ 2026-11-01: open-interest, tickers with funding+OI, account-
// ratio) and track the SAME USDT-perp contract. Used ONLY as a fallback when
// the Binance lane answers null — real data, no invention; every delta is
// computed WITHIN one venue's own history, so ban-edge rows never mix sources.
// Family E crossCheck stays Binance-only (v14.0 zero-foreign-venue doctrine).
const BYBIT_HOST = "https://api.bybit.com";
async function bybitJson(path, timeoutMs = 6000) {
    return jsonUrl(`${BYBIT_HOST}${path}`, timeoutMs);
}
/** OI 5m history → ASC series like Binance openInterestHist (mirror). */ async function bybitOiSeries(symbol, limit = 13) {
    const j = await bybitJson(`/v5/market/open-interest?category=linear&symbol=${symbol}&intervalTime=5min&limit=${limit}`);
    const rows = j?.result?.list;
    if (!rows || rows.length < 2) return null;
    const arr = rows.map((r)=>Number(r.openInterest)).reverse(); // bybit is DESC → asc
    return arr.every((v)=>Number.isFinite(v) && v >= 0) ? arr : null;
}
/** lastPrice + fundingRate + current OI(+USD value) in ONE call (mirror). */ async function bybitTicker(symbol) {
    const j = await bybitJson(`/v5/market/tickers?category=linear&symbol=${symbol}`);
    const t = j?.result?.list?.[0];
    if (!t) return null;
    const price = Number(t.lastPrice);
    const fr = Number(t.fundingRate);
    const oi = Number(t.openInterest);
    const oiUsd = Number(t.openInterestValue);
    return {
        price: Number.isFinite(price) && price > 0 ? price : null,
        funding8h: Number.isFinite(fr) ? Number((fr * 100).toFixed(4)) : null,
        oiBase: Number.isFinite(oi) && oi > 0 ? oi : null,
        oiUsd: Number.isFinite(oiUsd) && oiUsd > 0 ? oiUsd : null
    };
}
/** crowd L/S account ratio mirror — buyRatio/sellRatio ≈ Binance global L/S. */ async function bybitCrowdLS(symbol) {
    const j = await bybitJson(`/v5/market/account-ratio?category=linear&symbol=${symbol}&period=5min&limit=1`);
    const r = j?.result?.list?.[0];
    if (!r) return null;
    const buy = Number(r.buyRatio), sell = Number(r.sellRatio);
    return Number.isFinite(buy) && Number.isFinite(sell) && sell > 0 ? Number((buy / sell).toFixed(4)) : null;
}
// v14.0 BINANCE-ONLY CROSS-CHECK (replaces the retired cross-exchange leg) —
// settled funding (history endpoint) and the CURRENT OI (per-symbol endpoint)
// are measured against the primary premiumIndex / openInterestHist lanes:
// real Binance cross-plane divergence, zero foreign venues.
async function crossCheck(symbol) {
    const [settledRows, oiCur] = await Promise.all([
        fapi(`/fapi/v1/fundingRate?symbol=${symbol}&limit=1`),
        fapi(`/fapi/v1/openInterest?symbol=${symbol}`)
    ]);
    const s = Number(settledRows?.[0]?.fundingRate);
    const o = Number(oiCur?.openInterest);
    return {
        fundingSettled: Number.isFinite(s) && settledRows ? s * 100 : null,
        oiChk: Number.isFinite(o) && o > 0 ? o : null
    };
}
let sampleInFlight = false;
let lastSampleAt = 0;
function pct(cur, ref) {
    return ref > 0 ? Number(((cur - ref) / ref * 100).toFixed(4)) : null;
}
async function maybeFuturesSample(force = false) {
    if (sampleInFlight) return {
        symbols: [],
        skipped: true
    };
    if (!force && Date.now() - lastSampleAt < SAMPLE_INTERVAL_MS) return {
        symbols: [],
        skipped: true
    };
    sampleInFlight = true;
    lastSampleAt = Date.now();
    try {
        await ensureBackfill(); // one-shot guarded — no-op after the first pass
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$trade$2d$flow$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["syncTapeWatchlist"])([
            ...FUTURES_ANCHORS
        ]).catch(()=>undefined);
        const now = Date.now();
        const ts = new Date(Math.floor(now / 60_000) * 60_000); // minute grid — dedupe-safe
        const written = [];
        for (const symbol of FUTURES_ANCHORS){
            try {
                const [oiHistArr, prem, crowdArr, topArr, k5, prevRow, tape, liqSnap, cross] = await Promise.all([
                    fapi(`/futures/data/openInterestHist?symbol=${symbol}&period=5m&limit=13`),
                    fapi(`/fapi/v1/premiumIndex?symbol=${symbol}`),
                    fapi(`/futures/data/globalLongShortAccountRatio?symbol=${symbol}&period=5m&limit=2`),
                    fapi(`/futures/data/topLongShortPositionRatio?symbol=${symbol}&period=5m&limit=2`),
                    fapi(`/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=4`),
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findFirst({
                        where: {
                            symbol,
                            ts: {
                                gte: new Date(now - 72 * 60_000),
                                lte: new Date(now - 48 * 60_000)
                            }
                        },
                        orderBy: {
                            ts: "desc"
                        }
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$trade$2d$flow$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["getTape"])(symbol),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["getLiquidationSnapshot"])(),
                    crossCheck(symbol)
                ]);
                // Task 34-4/35 — price fallback tiers: fapi markPrice → binance spot
                // mirror → v13.3.1 bybit mirror. A fapi ban window no longer zeroes
                // the whole sample; the row keeps flowing with real fallback data.
                const bt = !prem || !oiHistArr || oiHistArr.length < 2 || !crowdArr ? await bybitTicker(symbol) : null;
                let price = prem ? Number(prem.markPrice) || null : null;
                if (price === null) price = await spotPrice(symbol);
                if (price === null) price = bt?.price ?? null; // v13.3.1 tier-3 mirror
                if (price === null) continue; // honest — no price from ANY host, no row
                let oi = oiHistArr && oiHistArr.length >= 2 ? oiHistArr.map((h)=>Number(h.sumOpenInterest)) : null;
                if (!oi) oi = await bybitOiSeries(symbol); // v13.3.1 mirror — same-contract OI history
                const oiBase = oi ? oi[oi.length - 1] : null;
                let oiUsdRaw = oiHistArr && oiHistArr.length ? Number(oiHistArr[oiHistArr.length - 1].sumOpenInterestValue) : null;
                if (oiUsdRaw === null && bt?.oiUsd) oiUsdRaw = bt.oiUsd;
                const oiDelta15m = oi && oi.length > 3 ? pct(oi[oi.length - 1], oi[oi.length - 4]) : null;
                const oiDelta1h = oi && oi.length > 12 ? pct(oi[oi.length - 1], oi[oi.length - 13]) : null;
                // price deltas: 15m from the 5m kline mini-series, 1h from our OWN row
                // (self-consistent with the stored series) — klines fallback below.
                let closes = k5 ? k5.map((k)=>Number(k[4])) : [];
                if (closes.length < 4) {
                    const k5s = await spotKlines(symbol, "5m", 4);
                    closes = k5s ? k5s.map((k)=>Number(k[4])) : [];
                }
                const priceDelta15m = closes.length >= 4 ? pct(closes[closes.length - 1], closes[0]) : null;
                let priceDelta1h = prevRow ? pct(price, prevRow.price) : null;
                if (priceDelta1h === null) {
                    let k1 = await fapi(`/fapi/v1/klines?symbol=${symbol}&interval=1h&limit=3`);
                    if (!k1) k1 = await spotKlines(symbol, "1h", 3);
                    const c1 = k1 ? k1.map((k)=>Number(k[4])) : [];
                    if (c1.length >= 3) priceDelta1h = pct(c1[c1.length - 1], c1[0]);
                }
                const liqRow = liqSnap?.bySymbol?.[symbol] ?? null;
                // v13.3.1 mirror — crowd L/S only when the Binance lane answered null
                const crowdMirror = crowdArr && crowdArr.length ? null : await bybitCrowdLS(symbol);
                const data = {
                    symbol,
                    ts,
                    source: "LIVE",
                    price,
                    oiBase,
                    oiUsdM: oiUsdRaw ? Number((oiUsdRaw / 1e6).toFixed(2)) : null,
                    priceDelta15m,
                    priceDelta1h,
                    oiDelta15m,
                    oiDelta1h,
                    quadrant15m: classifyQuadrant(priceDelta15m, oiDelta15m),
                    quadrant1h: classifyQuadrant(priceDelta1h, oiDelta1h),
                    funding8h: prem ? Number((Number(prem.lastFundingRate) * 100).toFixed(4)) : bt?.funding8h ?? null,
                    crowdLS: crowdArr && crowdArr.length ? Number(crowdArr[crowdArr.length - 1].longShortRatio) : crowdMirror,
                    topLS: topArr && topArr.length ? Number(topArr[topArr.length - 1].longShortRatio) : null,
                    takerLS: null,
                    cvd15mPct: tape ? Number(tape.cvd15mPct.toFixed(2)) : null,
                    cvd1hPct: tape ? Number(tape.cvd1hPct.toFixed(2)) : null,
                    vol15mUsd: tape ? Math.round(tape.vol15mUsd) : null,
                    liqLong10mUsd: liqRow ? Math.round(liqRow.longsUsd10m) : null,
                    liqShort10mUsd: liqRow ? Math.round(liqRow.shortsUsd10m) : null,
                    liqUsd1h: liqRow ? Math.round(liqRow.usd1h) : null,
                    fundingSettled: cross.fundingSettled,
                    oiChk: cross.oiChk
                };
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.upsert({
                    where: {
                        symbol_ts_source: {
                            symbol,
                            ts,
                            source: "LIVE"
                        }
                    },
                    create: data,
                    update: data
                });
                written.push(symbol);
            } catch (e) {
                console.error(`[futures] sample ${symbol} failed`, e);
            }
        }
        return {
            symbols: written,
            skipped: false
        };
    } finally{
        sampleInFlight = false;
    }
}
async function readBackfillState() {
    const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
        where: {
            key: "futures.backfillState"
        }
    });
    if (!row) return null;
    try {
        return JSON.parse(row.value);
    } catch  {
        return null;
    }
}
let backfillInFlight = false;
let lastBackfillAttemptAt = 0;
const BACKFILL_RETRY_MS = 10 * 60_000; // ban-aware self-heal cadence
async function ensureBackfill(force = false) {
    if (backfillInFlight) return null;
    const existing = await readBackfillState();
    const done = new Set(existing?.symbols ?? []);
    const pending = FUTURES_ANCHORS.filter((s)=>!done.has(s));
    if (existing && pending.length === 0 && !force) return existing;
    if (!force && Date.now() - lastBackfillAttemptAt < BACKFILL_RETRY_MS) return null;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fapiBanRemainingMs"])() > 0) return null; // never hammer a live IP ban (gate-shared ban clock)
    lastBackfillAttemptAt = Date.now();
    backfillInFlight = true;
    try {
        const written = [
            ...done
        ];
        let total = 0;
        let first = true;
        for (const symbol of pending){
            if (!first) await new Promise((r)=>setTimeout(r, 12_000)); // spread the burst — back-to-back symbol fetches are exactly how bans happen
            first = false;
            try {
                const n = await backfillSymbol(symbol);
                if (n > 0) {
                    written.push(symbol);
                    total += n;
                }
            } catch (e) {
                console.error(`[futures] backfill ${symbol} failed`, e);
            }
        }
        if (total === 0 && written.length === 0) return null; // resumable — a later sampler tick retries
        const state = {
            at: new Date().toISOString(),
            symbols: written,
            rows: (existing?.rows ?? 0) + total
        };
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: "futures.backfillState"
            },
            create: {
                key: "futures.backfillState",
                value: JSON.stringify(state)
            },
            update: {
                value: JSON.stringify(state)
            }
        });
        return state;
    } finally{
        backfillInFlight = false;
    }
}
async function backfillSymbol(symbol) {
    const [oiHist, klinesRaw, crowd, top, funding] = await Promise.all([
        fapi(`/futures/data/openInterestHist?symbol=${symbol}&period=1h&limit=${BACKFILL_HOURS}`),
        fapi(`/fapi/v1/klines?symbol=${symbol}&interval=1h&limit=${BACKFILL_HOURS + 1}`),
        fapi(`/futures/data/globalLongShortAccountRatio?symbol=${symbol}&period=1h&limit=${BACKFILL_HOURS}`),
        fapi(`/futures/data/topLongShortPositionRatio?symbol=${symbol}&period=1h&limit=${BACKFILL_HOURS}`),
        fapi(`/fapi/v1/fundingRate?symbol=${symbol}&limit=60`)
    ]);
    // map raw kline rows here — market-feed's fetcher throws on a ban, this
    // module fails soft instead
    const klines = (klinesRaw ?? []).map((k)=>({
            openTime: Number(k[0]),
            close: Number(k[4])
        }));
    if (!oiHist || oiHist.length < 5 || klines.length < 5) return 0;
    // grid points: use OI-hist timestamps (1h close times); kline close matches
    // the same hour (openTime + 1h). Tolerance 5min.
    const closeAt = (openTime)=>openTime + 3_600_000;
    const nearest = (arr, ts, tolMs)=>{
        let best = null;
        let bestD = Infinity;
        for (const r of arr){
            const d = Math.abs(r.ts - ts);
            if (d < bestD) {
                bestD = d;
                best = r;
            }
        }
        return bestD <= tolMs ? best : null;
    };
    const points = oiHist.map((h)=>{
        const ts = Number(h.timestamp);
        const k = nearest(klines.map((c)=>({
                ts: closeAt(c.openTime),
                close: c.close
            })), ts, 5 * 60_000);
        if (!k) return null;
        const c = nearest(crowd?.map((r)=>({
                ts: Number(r.timestamp),
                v: Number(r.longShortRatio)
            })) ?? [], ts, 5 * 60_000);
        const t = nearest(top?.map((r)=>({
                ts: Number(r.timestamp),
                v: Number(r.longShortRatio)
            })) ?? [], ts, 5 * 60_000);
        return {
            ts,
            price: k.close,
            oiBase: Number(h.sumOpenInterest),
            oiUsdM: Number(h.sumOpenInterestValue) / 1e6,
            crowdLS: c?.v ?? null,
            topLS: t?.v ?? null
        };
    }).filter((p)=>p !== null).sort((a, b)=>a.ts - b.ts);
    if (points.length < 5) return 0;
    // funding in effect at ts = latest fundingTime ≤ ts (funding history is ascending)
    const fundingAsc = (funding ?? []).map((f)=>({
            ts: Number(f.fundingTime),
            rate: Number(f.fundingRate) * 100
        })).sort((a, b)=>a.ts - b.ts);
    const rows = points.map((p, i)=>{
        const prev = i > 0 ? points[i - 1] : null;
        const priceDelta1h = prev ? pct(p.price, prev.price) : null;
        const oiDelta1h = prev ? pct(p.oiBase, prev.oiBase) : null;
        const fund = fundingAsc.length ? [
            ...fundingAsc
        ].reverse().find((f)=>f.ts <= p.ts) ?? null : null;
        return {
            symbol,
            ts: new Date(p.ts),
            source: "BACKFILL",
            price: p.price,
            oiBase: p.oiBase,
            oiUsdM: Number(p.oiUsdM.toFixed(2)),
            priceDelta15m: null,
            priceDelta1h,
            oiDelta15m: null,
            oiDelta1h,
            quadrant15m: null,
            quadrant1h: classifyQuadrant(priceDelta1h, oiDelta1h),
            funding8h: fund ? Number(fund.rate.toFixed(4)) : null,
            crowdLS: p.crowdLS,
            topLS: p.topLS,
            takerLS: null,
            cvd15mPct: null,
            cvd1hPct: null,
            vol15mUsd: null,
            liqLong10mUsd: null,
            liqShort10mUsd: null,
            liqUsd1h: null,
            fundingSettled: null,
            oiChk: null,
            fwd15mPct: null,
            // inline settlement from the series itself
            fwd1hPct: (()=>{
                const nxt = points.find((q)=>q.ts >= p.ts + 55 * 60_000 && q.ts <= p.ts + 70 * 60_000);
                return nxt ? pct(nxt.price, p.price) : null;
            })(),
            fwd4hPct: (()=>{
                const nxt = points.find((q)=>q.ts >= p.ts + 225 * 60_000 && q.ts <= p.ts + 255 * 60_000);
                return nxt ? pct(nxt.price, p.price) : null;
            })()
        };
    });
    // createMany — a LIVE sample landing on the same hour grid keeps its own
    // row (source differs in the unique key), so no overwrite of either side.
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.createMany({
        data: rows
    });
    return res.count;
}
// ── forward-return settlement + retention ──────────────────────────────────
let settleInFlight = false;
let lastSettleAt = 0;
let lastPruneAt = 0;
async function settleFuturesForwards(force = false) {
    if (settleInFlight) return {
        settled: 0,
        pruned: 0
    };
    if (!force && Date.now() - lastSettleAt < SETTLE_INTERVAL_MS) return {
        settled: 0,
        pruned: 0
    };
    settleInFlight = true;
    lastSettleAt = Date.now();
    try {
        const now = Date.now();
        let settled = 0;
        // LIVE rows older than 4h may need all three horizons; rows 15m-4h old
        // only the early ones. One query per pass, bounded 300 oldest.
        const pending = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findMany({
            where: {
                source: "LIVE",
                ts: {
                    lte: new Date(now - 15 * 60_000)
                },
                OR: [
                    {
                        fwd15mPct: null
                    },
                    {
                        fwd1hPct: null
                    },
                    {
                        fwd4hPct: null
                    }
                ]
            },
            orderBy: {
                ts: "asc"
            },
            take: 300
        });
        for (const row of pending){
            const ts = row.ts.getTime();
            const data = {};
            if (row.fwd15mPct === null) {
                const nxt = await nearestLaterPrice(row.symbol, ts, 10 * 60_000, 25 * 60_000);
                if (nxt !== null && row.price > 0) data.fwd15mPct = (nxt - row.price) / row.price * 100;
            }
            if (row.fwd1hPct === null) {
                const nxt = await nearestLaterPrice(row.symbol, ts, 55 * 60_000, 85 * 60_000);
                if (nxt !== null && row.price > 0) data.fwd1hPct = (nxt - row.price) / row.price * 100;
            }
            if (row.fwd4hPct === null && ts < now - 4 * 3_600_000 - 30 * 60_000) {
                const nxt = await nearestLaterPrice(row.symbol, ts, 225 * 60_000, 300 * 60_000);
                if (nxt !== null && row.price > 0) data.fwd4hPct = (nxt - row.price) / row.price * 100;
            }
            if (Object.keys(data).length) {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.update({
                    where: {
                        id: row.id
                    },
                    data
                });
                settled++;
            }
        }
        // retention: 30d age rule + hard cap (both cheap, hourly at most)
        let pruned = 0;
        if (Date.now() - lastPruneAt > PRUNE_INTERVAL_MS) {
            lastPruneAt = Date.now();
            const old = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.deleteMany({
                where: {
                    ts: {
                        lt: new Date(Date.now() - RETENTION_DAYS * 86_400_000)
                    }
                }
            });
            pruned += old.count;
            const total = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.count();
            if (total > HARD_CAP) {
                const excess = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findMany({
                    orderBy: {
                        ts: "asc"
                    },
                    take: total - HARD_CAP,
                    select: {
                        id: true
                    }
                });
                const del = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.deleteMany({
                    where: {
                        id: {
                            in: excess.map((r)=>r.id)
                        }
                    }
                });
                pruned += del.count;
            }
        }
        return {
            settled,
            pruned
        };
    } finally{
        settleInFlight = false;
    }
}
async function nearestLaterPrice(symbol, ts, minAheadMs, maxAheadMs) {
    const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findFirst({
        where: {
            symbol,
            ts: {
                gte: new Date(ts + minAheadMs),
                lte: new Date(ts + maxAheadMs)
            }
        },
        orderBy: {
            ts: "asc"
        },
        select: {
            price: true
        }
    });
    return row ? row.price : null;
}
let edgeCache = null;
function median(arr) {
    if (!arr.length) return 0;
    const s = [
        ...arr
    ].sort((a, b)=>a - b);
    const mid = Math.floor(s.length / 2);
    return Number((s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2).toFixed(3));
}
function pctl(arr, q) {
    if (arr.length < 10) return null; // percentile thresholds need a real distribution
    const s = [
        ...arr
    ].sort((a, b)=>a - b);
    const idx = Math.min(s.length - 1, Math.max(0, Math.floor(q * s.length)));
    return s[idx];
}
function mean(arr) {
    return arr.length ? Number((arr.reduce((a, b)=>a + b, 0) / arr.length).toFixed(3)) : 0;
}
function confidenceOf(n) {
    if (n >= 100) return "HIGH";
    if (n >= 40) return "MEDIUM";
    if (n >= 20) return "LOW";
    return "COLLECTING";
}
async function buildFuturesEdge(force = false) {
    if (!force && edgeCache && Date.now() - edgeCache.at < EDGE_CACHE_TTL) return edgeCache.value;
    const rowsRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findMany({
        select: {
            ts: true,
            price: true,
            quadrant1h: true,
            fwd1hPct: true,
            fwd4hPct: true,
            funding8h: true,
            crowdLS: true,
            topLS: true,
            cvd15mPct: true,
            liqLong10mUsd: true,
            liqShort10mUsd: true,
            fundingSettled: true,
            oiBase: true,
            oiChk: true
        },
        orderBy: {
            ts: "asc"
        },
        take: 40_000
    });
    const rows = rowsRaw.map((r)=>({
            ...r,
            ts: r.ts.getTime()
        }));
    const settled = rows.filter((r)=>r.fwd1hPct !== null);
    const baseline = mean(settled.map((r)=>r.fwd1hPct));
    // 1) QUADRANT STUDY — the empirical four-quadrant truth table
    const quadrantStudy = [];
    for (const qid of Object.keys(QUADRANT_META)){
        const sub = settled.filter((r)=>r.quadrant1h === qid);
        if (!sub.length) continue;
        const f1 = sub.map((r)=>r.fwd1hPct);
        const f4arr = sub.map((r)=>r.fwd4hPct).filter((v)=>v !== null);
        const m = mean(f1);
        const mdn = median(f1);
        quadrantStudy.push({
            quadrant: qid,
            label: QUADRANT_META[qid].label,
            n: sub.length,
            meanFwd1h: m,
            medianFwd1h: mdn,
            winPct: Number((f1.filter((v)=>v > 0).length / f1.length * 100).toFixed(1)),
            meanFwd4h: f4arr.length >= 10 ? mean(f4arr) : null,
            verdict: m > baseline ? "CONTINUES" : "FADES"
        });
    }
    // 2) FAMILY STUDY — factor extremes vs baseline (data-driven thresholds)
    const fam = [];
    const push = (filter, family, rule, subRows, thresholdNote)=>{
        // settle-safe: only rows whose forward return actually settled count
        const sub = subRows.filter((r)=>r.fwd1hPct !== null).map((r)=>r.fwd1hPct);
        if (sub.length < 5) return; // below study floor — skip silently, maturity bar reports the rest
        const m = mean(sub);
        fam.push({
            filter,
            family,
            rule,
            n: sub.length,
            meanFwd1h: m,
            medianFwd1h: median(sub),
            winPct: Number((sub.filter((v)=>v > 0).length / sub.length * 100).toFixed(1)),
            baselineMean: baseline,
            edge: Number((m - baseline).toFixed(3)),
            thresholdNote,
            confidence: confidenceOf(sub.length)
        });
    };
    const funding = rows.map((r)=>r.funding8h).filter((v)=>v !== null);
    const fHi = pctl(funding, 0.9);
    const fLo = pctl(funding, 0.1);
    if (fHi !== null) push("FUNDING_HOT", "A", `funding8h ≥ ${fHi.toFixed(4)}% (crowded longs)`, settled.filter((r)=>r.funding8h !== null && r.funding8h >= fHi), `p90 of ${funding.length} rows`);
    if (fLo !== null) push("FUNDING_COLD", "A", `funding8h ≤ ${fLo.toFixed(4)}% (crowded shorts)`, settled.filter((r)=>r.funding8h !== null && r.funding8h <= fLo), `p10 of ${funding.length} rows`);
    const crowd = rows.map((r)=>r.crowdLS).filter((v)=>v !== null);
    const cHi = pctl(crowd, 0.9);
    const cLo = pctl(crowd, 0.1);
    if (cHi !== null) push("CROWD_LONG_CROWDED", "A", `crowd L/S ≥ ${cHi.toFixed(2)}`, settled.filter((r)=>r.crowdLS !== null && r.crowdLS >= cHi), `p90 of ${crowd.length}`);
    if (cLo !== null) push("CROWD_SHORT_CROWDED", "A", `crowd L/S ≤ ${cLo.toFixed(2)}`, settled.filter((r)=>r.crowdLS !== null && r.crowdLS <= cLo), `p10 of ${crowd.length}`);
    const spreads = rows.map((r)=>r.topLS !== null && r.crowdLS !== null ? r.topLS - r.crowdLS : null).filter((v)=>v !== null);
    const sHi = pctl(spreads, 0.75);
    if (sHi !== null) push("SMART_VS_CROWD_HI", "A", `top-trader L/S − crowd L/S ≥ ${sHi.toFixed(2)}`, settled.filter((r)=>r.topLS !== null && r.crowdLS !== null && r.topLS - r.crowdLS >= sHi), `p75 of ${spreads.length}`);
    const cvd = rows.map((r)=>r.cvd15mPct).filter((v)=>v !== null);
    const cvdLo = pctl(cvd, 0.1);
    const cvdHi = pctl(cvd, 0.9);
    if (cvdLo !== null) push("CVD_SELL_FLUSH", "B", `15m CVD ≤ ${cvdLo.toFixed(1)}% of volume`, settled.filter((r)=>r.cvd15mPct !== null && r.cvd15mPct <= cvdLo), `p10 of ${cvd.length} live rows`);
    if (cvdHi !== null) push("CVD_BUY_IGNITION", "B", `15m CVD ≥ ${cvdHi.toFixed(1)}% of volume`, settled.filter((r)=>r.cvd15mPct !== null && r.cvd15mPct >= cvdHi), `p90 of ${cvd.length} live rows`);
    for (const [fid, label] of [
        [
            "LIQ_LONG_FLUSH",
            "longs liquidated 10m ≥"
        ],
        [
            "LIQ_SHORT_FLUSH",
            "shorts liquidated 10m ≥"
        ]
    ]){
        const vals = rows.map((r)=>fid === "LIQ_LONG_FLUSH" ? r.liqLong10mUsd : r.liqShort10mUsd).filter((v)=>v !== null && v > 0);
        const thr = pctl(vals, 0.9);
        if (thr !== null) {
            push(fid, "C", `${label} $${Math.round(thr).toLocaleString("en-US")}`, settled.filter((r)=>(fid === "LIQ_LONG_FLUSH" ? r.liqLong10mUsd : r.liqShort10mUsd) !== null && (fid === "LIQ_LONG_FLUSH" ? r.liqLong10mUsd : r.liqShort10mUsd) >= thr), `p90 of ${vals.length} live rows`);
        }
    }
    // v14.0 — predicted (premiumIndex) vs SETTLED (fundingRate history) funding
    // divergence: the Binance cross-plane successor of the old cross-venue rule.
    const crossSpread = rows.map((r)=>r.fundingSettled !== null && r.funding8h !== null ? Math.abs(r.funding8h - r.fundingSettled) : null).filter((v)=>v !== null);
    const xsHi = pctl(crossSpread, 0.9);
    if (xsHi !== null) push("CROSS_FUNDING_WIDE", "E", `|funding pred−settled| ≥ ${xsHi.toFixed(4)}%`, settled.filter((r)=>r.fundingSettled !== null && r.funding8h !== null && Math.abs(r.funding8h - r.fundingSettled) >= xsHi), `p90 of ${crossSpread.length} live rows`);
    fam.sort((a, b)=>Math.abs(b.edge) - Math.abs(a.edge));
    // 3) SIGNAL ATTRIBUTION — the realized book joined to the quadrant context
    const btcOldest = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findFirst({
        where: {
            symbol: "BTCUSDT",
            quadrant1h: {
                not: null
            }
        },
        orderBy: {
            ts: "asc"
        },
        select: {
            ts: true
        }
    });
    const cells = [];
    let joined = 0;
    let attributionNote = "waiting for the first settled signals inside the snapshot window";
    if (btcOldest) {
        const btcRows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findMany({
            where: {
                symbol: "BTCUSDT",
                quadrant1h: {
                    not: null
                }
            },
            orderBy: {
                ts: "asc"
            },
            select: {
                ts: true,
                quadrant1h: true
            }
        });
        const sigs = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                status: {
                    in: [
                        "SL",
                        "TP3",
                        "EXPIRED",
                        "CLOSED"
                    ]
                },
                qualityFlag: null,
                createdAt: {
                    gte: btcOldest.ts
                }
            },
            orderBy: {
                createdAt: "desc"
            },
            take: 1500,
            select: {
                direction: true,
                createdAt: true,
                pnlPercent: true
            }
        });
        const byCell = new Map();
        for (const s of sigs){
            const t = s.createdAt.getTime();
            // binary search the nearest snapshot within the ±fence
            let lo = 0;
            let hi = btcRows.length - 1;
            let best = null;
            let bestD = Infinity;
            while(lo <= hi){
                const mid = lo + hi >> 1;
                const midTs = btcRows[mid].ts.getTime();
                const d = Math.abs(midTs - t);
                if (d < bestD) {
                    bestD = d;
                    best = btcRows[mid];
                }
                if (midTs < t) lo = mid + 1;
                else hi = mid - 1;
            }
            if (best && bestD <= ATTRIBUTION_FENCE_MS) {
                joined++;
                const key = `${s.direction}|${best.quadrant1h}`;
                const arr = byCell.get(key) ?? [];
                arr.push(s.pnlPercent);
                byCell.set(key, arr);
            }
        }
        for (const [key, arr] of byCell){
            const [direction, quadrant] = key.split("|");
            cells.push({
                direction: direction,
                quadrant: quadrant,
                n: arr.length,
                avgPnl: Number(mean(arr).toFixed(2)),
                medianPnl: Number(median(arr).toFixed(2)),
                winPct: Number((arr.filter((v)=>v > 0).length / arr.length * 100).toFixed(1))
            });
        }
        cells.sort((a, b)=>a.avgPnl - b.avgPnl);
        attributionNote = joined > 0 ? `${joined} settled signals joined to the BTC quadrant context (±${ATTRIBUTION_FENCE_MS / 60_000}m fence, clean ledger)` : "no settled signals inside the snapshot window yet";
    }
    // 4) BEST FILTER — book-edge candidates outrank market-edge candidates when
    // they exist (they price the actual strategy, not the raw market).
    let bestFilter = null;
    const bookCandidates = cells.filter((c)=>c.n >= 15).map((c)=>({
            filter: `${c.direction === "LONG" ? "BLOCK LONG" : "BLOCK SHORT"} in ${c.quadrant}`,
            family: "D",
            rule: `${c.direction} signals issued in ${c.quadrant} context averaged ${c.avgPnl}% levered net (n=${c.n}, win ${c.winPct}%)`,
            edge: c.avgPnl,
            n: c.n,
            confidence: confidenceOf(c.n),
            source: "BOOK-EDGE",
            meaningful: c.avgPnl < 0
        })).filter((c)=>c.meaningful).sort((a, b)=>a.edge - b.edge);
    const marketCandidates = fam.filter((f)=>f.n >= 20 && Math.sign(f.medianFwd1h) === Math.sign(f.meanFwd1h) && f.edge !== 0).map((f)=>({
            filter: f.filter,
            family: f.family,
            rule: `${f.rule} → fwd1h ${f.edge > 0 ? "+" : ""}${f.edge}% vs baseline (n=${f.n})`,
            edge: f.edge,
            n: f.n,
            confidence: f.confidence,
            source: "MARKET-EDGE"
        }));
    const pool = [
        ...bookCandidates,
        ...marketCandidates
    ];
    if (pool.length) {
        const top = pool.sort((a, b)=>Math.abs(b.edge) - Math.abs(a.edge))[0];
        bestFilter = {
            filter: top.filter,
            family: top.family,
            rule: top.rule,
            edge: top.edge,
            n: top.n,
            confidence: top.confidence,
            source: top.source
        };
    }
    const value = {
        builtAt: new Date().toISOString(),
        rowsScanned: rows.length,
        settledRows: settled.length,
        baselineMeanFwd1h: baseline,
        quadrantStudy,
        familyStudy: fam,
        attribution: {
            cells,
            joined,
            note: attributionNote
        },
        bestFilter,
        maturity: {
            settled: settled.length,
            target: SETTLED_TARGET,
            progressPct: Math.min(100, Number((settled.length / SETTLED_TARGET * 100).toFixed(1)))
        }
    };
    edgeCache = {
        at: Date.now(),
        value
    };
    return value;
}
let liveCache = null;
async function getFuturesLive(force = false) {
    if (!force && liveCache && Date.now() - liveCache.at < 15_000) return liveCache.value;
    const [latestRows, edge, backfill, tapeHealth, liqStatus, countTotal, countLive, countBackfill, countSettled, count24h, seriesRaw] = await Promise.all([
        Promise.all(FUTURES_ANCHORS.map((s)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findFirst({
                where: {
                    symbol: s,
                    source: "LIVE"
                },
                orderBy: {
                    ts: "desc"
                }
            }))),
        buildFuturesEdge(),
        readBackfillState(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$trade$2d$flow$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["getTapeHealth"])().catch(()=>({
                reachable: false,
                connected: false,
                source: "OFFLINE",
                symbols: 0,
                trades: 0,
                dataStalled: true
            })),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["getLiquidationStatus"])().catch(()=>null),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.count(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.count({
            where: {
                source: "LIVE"
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.count({
            where: {
                source: "BACKFILL"
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.count({
            where: {
                fwd1hPct: {
                    not: null
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.count({
            where: {
                ts: {
                    gte: new Date(Date.now() - 86_400_000)
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findMany({
            where: {
                ts: {
                    gte: new Date(Date.now() - 24 * 3_600_000)
                },
                symbol: "BTCUSDT"
            },
            orderBy: {
                ts: "asc"
            },
            select: {
                ts: true,
                price: true,
                oiBase: true,
                quadrant1h: true
            }
        })
    ]);
    const stride = Math.max(1, Math.ceil(seriesRaw.length / 120));
    const points = seriesRaw.filter((_, i)=>i % stride === 0 || i === seriesRaw.length - 1).map((r)=>({
            ts: r.ts.getTime(),
            price: r.price,
            oiBase: r.oiBase,
            quadrant1h: r.quadrant1h
        }));
    const anchors = latestRows.map((row, i)=>{
        if (!row) {
            return {
                symbol: FUTURES_ANCHORS[i],
                ts: "",
                price: 0,
                oiBase: null,
                oiUsdM: null,
                priceDelta15m: null,
                priceDelta1h: null,
                oiDelta15m: null,
                oiDelta1h: null,
                quadrant15m: null,
                quadrant1h: null,
                funding8h: null,
                crowdLS: null,
                topLS: null,
                cvd15mPct: null,
                cvd1hPct: null,
                liqLong10mUsd: null,
                liqShort10mUsd: null,
                liqUsd1h: null,
                fundingSettled: null,
                oiChk: null,
                crossSpreadBps8h: null
            };
        }
        return {
            symbol: row.symbol,
            ts: row.ts.toISOString(),
            price: row.price,
            oiBase: row.oiBase,
            oiUsdM: row.oiUsdM,
            priceDelta15m: row.priceDelta15m,
            priceDelta1h: row.priceDelta1h,
            oiDelta15m: row.oiDelta15m,
            oiDelta1h: row.oiDelta1h,
            quadrant15m: row.quadrant15m,
            quadrant1h: row.quadrant1h,
            funding8h: row.funding8h,
            crowdLS: row.crowdLS,
            topLS: row.topLS,
            cvd15mPct: row.cvd15mPct,
            cvd1hPct: row.cvd1hPct,
            liqLong10mUsd: row.liqLong10mUsd,
            liqShort10mUsd: row.liqShort10mUsd,
            liqUsd1h: row.liqUsd1h,
            fundingSettled: row.fundingSettled,
            oiChk: row.oiChk,
            crossSpreadBps8h: row.fundingSettled !== null && row.funding8h !== null ? Number(((row.funding8h - row.fundingSettled) * 10_000).toFixed(1)) // bps per 8h (predicted − settled)
             : null
        };
    });
    const value = {
        at: new Date().toISOString(),
        anchors,
        series: [
            {
                symbol: "BTCUSDT",
                points
            }
        ],
        services: {
            tape: tapeHealth,
            liq: liqStatus
        },
        edge,
        backfill,
        counts: {
            total: countTotal,
            live: countLive,
            backfill: countBackfill,
            settled1h: countSettled,
            last24h: count24h
        }
    };
    liveCache = {
        at: Date.now(),
        value
    };
    return value;
}
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client-2c3a283f134fdcb6", () => require("@prisma/client-2c3a283f134fdcb6"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__a358f258._.js.map