module.exports = [
"[project]/src/lib/db.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[project]/src/lib/brand.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo — canonical brand + version registry ──────────────────────
// Operator mandate 2026-09-15: rename the program to «FlowRadar Neo» across ALL
// components (dashboard theme respected) and surface the LATEST project version
// in the UI. Every branding surface (header, footer, metadata, Telegram copy,
// posters) imports from this single module so the name/version can never drift.
__turbopack_context__.s([
    "APP_ENGINE_LINE",
    ()=>APP_ENGINE_LINE,
    "APP_NAME",
    ()=>APP_NAME,
    "APP_OG_TITLE",
    ()=>APP_OG_TITLE,
    "APP_STAGE",
    ()=>APP_STAGE,
    "APP_TAGLINE",
    ()=>APP_TAGLINE,
    "APP_TITLE",
    ()=>APP_TITLE,
    "APP_VERSION",
    ()=>APP_VERSION,
    "APP_VERSION_LABEL",
    ()=>APP_VERSION_LABEL,
    "BRAND_TERMINAL",
    ()=>BRAND_TERMINAL
]);
const APP_NAME = "FlowRadar Neo";
const BRAND_TERMINAL = {
    head: "FLOWRADAR",
    sep: "//",
    tail: "NEO"
};
const APP_VERSION = "10.0.0";
const APP_VERSION_LABEL = `v${APP_VERSION}`;
const APP_STAGE = "NEO";
const APP_TAGLINE = `AI TRADING COMMAND ${APP_VERSION_LABEL} — FULL AUTONOMY`;
const APP_ENGINE_LINE = `FLOWRADAR-NEO ${APP_VERSION_LABEL} — AUTONOMOUS`;
const APP_TITLE = `${APP_NAME} — AI Trading Command Terminal`;
const APP_OG_TITLE = `${BRAND_TERMINAL.head}${BRAND_TERMINAL.sep}${BRAND_TERMINAL.tail}`;
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[externals]/node:child_process [external] (node:child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:child_process", () => require("node:child_process"));

module.exports = mod;
}),
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[externals]/node:os [external] (node:os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:os", () => require("node:os"));

module.exports = mod;
}),
"[externals]/node:zlib [external] (node:zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:zlib", () => require("node:zlib"));

module.exports = mod;
}),
"[project]/src/lib/telegram-image.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "renderStatusBanner",
    ()=>renderStatusBanner
]);
// ── FlowRadar Neo v6.3 telegram banner renderer (server-only) ──
// Dependency-free PNG generator for signal status banners (WIN / STOP /
// EXPIRED / NEW / SHORT / TTL_EXT / FULL). Draws a dark cyber-terminal card
// with a status headline, symbol line and two detail lines using an embedded
// 5×7 bitmap font, then encodes a real PNG via node:zlib — no canvas, no
// image library, nothing invented: every byte is rendered from the numbers
// the engine measured.
// (Operator round: «استفاده از تصویرهای ضمینه شده برای سیگنالهای win ، stop ، EXPIRED»
//  + lost-window batch 2026-09-05 21:09: NEW / TTL / FULL / Short banners)
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$zlib__$5b$external$5d$__$28$node$3a$zlib$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:zlib [external] (node:zlib, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/brand.ts [instrumentation] (ecmascript)");
;
;
// classic 5×7 bitmap font (HD44780-style), one byte per row, bit4 = leftmost px
const FONT = {
    "0": [
        0x0e,
        0x11,
        0x13,
        0x15,
        0x19,
        0x11,
        0x0e
    ],
    "1": [
        0x04,
        0x0c,
        0x04,
        0x04,
        0x04,
        0x04,
        0x0e
    ],
    "2": [
        0x0e,
        0x11,
        0x01,
        0x02,
        0x04,
        0x08,
        0x1f
    ],
    "3": [
        0x1f,
        0x02,
        0x04,
        0x02,
        0x01,
        0x11,
        0x0e
    ],
    "4": [
        0x02,
        0x06,
        0x0a,
        0x12,
        0x1f,
        0x02,
        0x02
    ],
    "5": [
        0x1f,
        0x10,
        0x1e,
        0x01,
        0x01,
        0x11,
        0x0e
    ],
    "6": [
        0x06,
        0x08,
        0x10,
        0x1e,
        0x11,
        0x11,
        0x0e
    ],
    "7": [
        0x1f,
        0x01,
        0x02,
        0x04,
        0x08,
        0x08,
        0x08
    ],
    "8": [
        0x0e,
        0x11,
        0x11,
        0x0e,
        0x11,
        0x11,
        0x0e
    ],
    "9": [
        0x0e,
        0x11,
        0x11,
        0x0f,
        0x01,
        0x02,
        0x0c
    ],
    A: [
        0x0e,
        0x11,
        0x11,
        0x1f,
        0x11,
        0x11,
        0x11
    ],
    B: [
        0x1e,
        0x11,
        0x11,
        0x1e,
        0x11,
        0x11,
        0x1e
    ],
    C: [
        0x0e,
        0x11,
        0x10,
        0x10,
        0x10,
        0x11,
        0x0e
    ],
    D: [
        0x1c,
        0x12,
        0x11,
        0x11,
        0x11,
        0x12,
        0x1c
    ],
    E: [
        0x1f,
        0x10,
        0x10,
        0x1e,
        0x10,
        0x10,
        0x1f
    ],
    F: [
        0x1f,
        0x10,
        0x10,
        0x1e,
        0x10,
        0x10,
        0x10
    ],
    G: [
        0x0e,
        0x11,
        0x10,
        0x17,
        0x11,
        0x11,
        0x0f
    ],
    H: [
        0x11,
        0x11,
        0x11,
        0x1f,
        0x11,
        0x11,
        0x11
    ],
    I: [
        0x0e,
        0x04,
        0x04,
        0x04,
        0x04,
        0x04,
        0x0e
    ],
    J: [
        0x07,
        0x02,
        0x02,
        0x02,
        0x02,
        0x12,
        0x0c
    ],
    K: [
        0x11,
        0x12,
        0x14,
        0x18,
        0x14,
        0x12,
        0x11
    ],
    L: [
        0x10,
        0x10,
        0x10,
        0x10,
        0x10,
        0x10,
        0x1f
    ],
    M: [
        0x11,
        0x1b,
        0x15,
        0x15,
        0x11,
        0x11,
        0x11
    ],
    N: [
        0x11,
        0x11,
        0x19,
        0x15,
        0x13,
        0x11,
        0x11
    ],
    O: [
        0x0e,
        0x11,
        0x11,
        0x11,
        0x11,
        0x11,
        0x0e
    ],
    P: [
        0x1e,
        0x11,
        0x11,
        0x1e,
        0x10,
        0x10,
        0x10
    ],
    Q: [
        0x0e,
        0x11,
        0x11,
        0x11,
        0x15,
        0x12,
        0x0d
    ],
    R: [
        0x1e,
        0x11,
        0x11,
        0x1e,
        0x14,
        0x12,
        0x11
    ],
    S: [
        0x0f,
        0x10,
        0x10,
        0x0e,
        0x01,
        0x01,
        0x1e
    ],
    T: [
        0x1f,
        0x04,
        0x04,
        0x04,
        0x04,
        0x04,
        0x04
    ],
    U: [
        0x11,
        0x11,
        0x11,
        0x11,
        0x11,
        0x11,
        0x0e
    ],
    V: [
        0x11,
        0x11,
        0x11,
        0x11,
        0x11,
        0x0a,
        0x04
    ],
    W: [
        0x11,
        0x11,
        0x11,
        0x15,
        0x15,
        0x1b,
        0x11
    ],
    X: [
        0x11,
        0x11,
        0x0a,
        0x04,
        0x0a,
        0x11,
        0x11
    ],
    Y: [
        0x11,
        0x11,
        0x0a,
        0x04,
        0x04,
        0x04,
        0x04
    ],
    Z: [
        0x1f,
        0x01,
        0x02,
        0x04,
        0x08,
        0x10,
        0x1f
    ],
    " ": [
        0,
        0,
        0,
        0,
        0,
        0,
        0
    ],
    "+": [
        0x00,
        0x04,
        0x04,
        0x1f,
        0x04,
        0x04,
        0x00
    ],
    "-": [
        0x00,
        0x00,
        0x00,
        0x1f,
        0x00,
        0x00,
        0x00
    ],
    "%": [
        0x19,
        0x1a,
        0x02,
        0x04,
        0x08,
        0x0b,
        0x13
    ],
    ".": [
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x0c,
        0x0c
    ],
    ":": [
        0x00,
        0x0c,
        0x0c,
        0x00,
        0x0c,
        0x0c,
        0x00
    ],
    "/": [
        0x01,
        0x01,
        0x02,
        0x04,
        0x08,
        0x10,
        0x10
    ],
    "(": [
        0x02,
        0x04,
        0x08,
        0x08,
        0x08,
        0x04,
        0x02
    ],
    ")": [
        0x08,
        0x04,
        0x02,
        0x02,
        0x02,
        0x04,
        0x08
    ]
};
const BG = [
    10,
    13,
    20
]; // #0a0d14 — terminal ink
const INK = [
    232,
    240,
    236
]; // near-white
const MUTED = [
    110,
    128,
    120
]; // dim sage
const WIN = [
    0,
    255,
    163
]; // neon mint
const STOP = [
    255,
    77,
    94
]; // danger
const EXPIRED = [
    255,
    179,
    71
]; // amber
const VIOLET = [
    178,
    107,
    255
];
const AFTERLIFE = [
    219,
    96,
    255
]; // spectral magenta — EXPIRED FOLLOW-UP verdicts
const STATUS_TEXT = {
    WIN: "WIN",
    STOP: "STOPPED",
    EXPIRED: "EXPIRED",
    NEW: "NEW SIGNAL",
    SHORT: "SHORT SIGNAL",
    TTL_EXT: "TTL EXTENDED",
    FULL: "FULL TARGET",
    AFTERLIFE: "AFTERLIFE"
};
const STATUS_COLOR = {
    WIN: WIN,
    STOP: STOP,
    EXPIRED: EXPIRED,
    NEW: WIN,
    SHORT: STOP,
    TTL_EXT: VIOLET,
    FULL: WIN,
    AFTERLIFE: AFTERLIFE
};
function asciiUpper(s) {
    return s.toUpperCase().replace(/[^A-Z0-9 +\-%.:()/]/g, "");
}
function makeCanvas(w, h) {
    const px = new Uint8Array(w * h * 3);
    for(let i = 0; i < w * h; i++){
        px[i * 3] = BG[0];
        px[i * 3 + 1] = BG[1];
        px[i * 3 + 2] = BG[2];
    }
    return {
        w,
        h,
        px
    };
}
function setPx(c, x, y, [r, g, b]) {
    if (x < 0 || y < 0 || x >= c.w || y >= c.h) return;
    const i = (y * c.w + x) * 3;
    c.px[i] = r;
    c.px[i + 1] = g;
    c.px[i + 2] = b;
}
function fillRect(c, x, y, w, h, col) {
    for(let dy = 0; dy < h; dy++)for(let dx = 0; dx < w; dx++)setPx(c, x + dx, y + dy, col);
}
function textWidth(text, scale) {
    return asciiUpper(text).length * 6 * scale - scale; // 5px glyph + 1px gap
}
function drawText(c, text, x, y, scale, col) {
    const chars = asciiUpper(text);
    let cx = x;
    for (const ch of chars){
        const glyph = FONT[ch];
        if (glyph) {
            for(let row = 0; row < 7; row++){
                const bits = glyph[row];
                for(let gx = 0; gx < 5; gx++){
                    if (bits & 1 << 4 - gx) fillRect(c, cx + gx * scale, y + row * scale, scale, scale, col);
                }
            }
        }
        cx += 6 * scale;
    }
}
function drawTextCentered(c, text, y, scale, col) {
    const w = textWidth(text, scale);
    drawText(c, text, Math.max(4, Math.floor((c.w - w) / 2)), y, scale, col);
}
// ── PNG encoder (color type 2 — truecolor RGB, 8-bit, filter 0) ──
const CRC_TABLE = (()=>{
    const t = [];
    for(let n = 0; n < 256; n++){
        let c = n;
        for(let k = 0; k < 8; k++)c = c & 1 ? 0xedb88320 ^ c >>> 1 : c >>> 1;
        t[n] = c >>> 0;
    }
    return t;
})();
function crc32(buf) {
    let c = 0xffffffff;
    for (const b of buf)c = CRC_TABLE[(c ^ b) & 0xff] ^ c >>> 8;
    return (c ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const body = Buffer.concat([
        Buffer.from(type, "ascii"),
        data
    ]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(body));
    return Buffer.concat([
        len,
        body,
        crc
    ]);
}
function encodePng(c) {
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(c.w, 0);
    ihdr.writeUInt32BE(c.h, 4);
    ihdr[8] = 8; // bit depth
    ihdr[9] = 2; // color type RGB
    // raw scanlines with leading filter byte 0
    const raw = Buffer.alloc(c.h * (c.w * 3 + 1));
    for(let y = 0; y < c.h; y++){
        raw[y * (c.w * 3 + 1)] = 0;
        Buffer.from(c.px.buffer, c.px.byteOffset + y * c.w * 3, c.w * 3).copy(raw, y * (c.w * 3 + 1) + 1);
    }
    return Buffer.concat([
        Buffer.from([
            0x89,
            0x50,
            0x4e,
            0x47,
            0x0d,
            0x0a,
            0x1a,
            0x0a
        ]),
        chunk("IHDR", ihdr),
        chunk("IDAT", __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$zlib__$5b$external$5d$__$28$node$3a$zlib$2c$__cjs$29$__["default"].deflateSync(raw, {
            level: 6
        })),
        chunk("IEND", Buffer.alloc(0))
    ]);
}
function renderStatusBanner(spec) {
    const W = 640;
    const H = 360;
    const c = makeCanvas(W, H);
    const accent = STATUS_COLOR[spec.status];
    // top + bottom accent bars
    fillRect(c, 0, 0, W, 8, accent);
    fillRect(c, 0, H - 8, W, 8, accent);
    // thin rules under the headline zone
    fillRect(c, 32, 232, W - 64, 2, [
        36,
        46,
        42
    ]);
    fillRect(c, 32, 300, W - 64, 2, [
        36,
        46,
        42
    ]);
    // HUD corner ticks
    for (const [x, y] of [
        [
            16,
            20
        ],
        [
            W - 22,
            20
        ],
        [
            16,
            H - 28
        ],
        [
            W - 22,
            H - 28
        ]
    ]){
        fillRect(c, x, y, 6, 2, MUTED);
        fillRect(c, x < W / 2 ? x : x + 4, y, 2, 6, MUTED);
    }
    drawTextCentered(c, `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].head}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].sep}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].tail}`, 26, 2, MUTED);
    drawTextCentered(c, STATUS_TEXT[spec.status], 74, 9, accent);
    drawTextCentered(c, asciiUpper(spec.title), 180, 4, INK);
    if (spec.line1) drawTextCentered(c, spec.line1, 246, 3, accent);
    if (spec.line2) drawTextCentered(c, spec.line2, 276, 3, INK);
    drawTextCentered(c, asciiUpper(spec.footer ?? "FLOWRADAR-NEO LIVE ENGINE"), 320, 2, VIOLET);
    return encodePng(c);
}
}),
"[project]/src/lib/daily-skin.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo v9.4 DAILY SKIN — operator mandate 2026-09-13 ────────────
// «TELEGRAM ART SKIN باید ساخت و تولید تصویر را با 7-SKIN CYCLE ACROSS ALL
//  TELEGRAM REPORTS انجام دهد» — the skin cycle must drive REAL AI image
// generation, one visual style per day, across all Telegram reports.
//
// Operator's 7 styles (fixed order, one per Tehran day):
//   1. BLUEPRINT   2. MOVIE (cinematic)   3. CYBERPUNK   4. ANIME
//   5. POP ART     6. VECTOR              7. CLAY
//
// Each skin now carries:
//   key   → assets/telegram/skin-{key}.png — AI-generated backdrop in THIS
//           style (same subject scene, seven different renderings; produced by
//           scripts/gen-skin-art.sh, idempotent + rate-limit aware)
//   style → the style prompt fragment used by the generator (single source of
//           truth: the artwork and this table can never drift apart)
//   tune  → composite modulation so overlay text stays readable WITHOUT hue-
//           rotating the style identity (hueShift stays 0 — a hue-rotated
//           blueprint or pop-art piece would stop being one)
//   artKind → legacy art-{KIND}.png fallback while skin files generate
//
// Deterministic per-Tehran-day pick (same day → same skin everywhere: daily
// poster, report previews, dashboard badge; next Tehran midnight → next style
// in the operator's order). Zero randomness, zero I/O, edge-safe.
__turbopack_context__.s([
    "SKIN_COUNT",
    ()=>SKIN_COUNT,
    "SKIN_KEYS",
    ()=>SKIN_KEYS,
    "SKIN_KINDS",
    ()=>SKIN_KINDS,
    "SKIN_NAMES",
    ()=>SKIN_NAMES,
    "dailySkin",
    ()=>dailySkin,
    "skinBySeed",
    ()=>skinBySeed,
    "tehranDayKey",
    ()=>tehranDayKey
]);
const SKINS = [
    {
        key: "blueprint",
        name: "BLUEPRINT",
        accent: "#5fd4d0",
        deep1: "#0a1a20",
        deep2: "#060f14",
        art: "DAILY",
        tune: {
            brightness: 0.62,
            saturation: 0.8
        },
        style: "ultra-premium dark technical blueprint art, glowing cyan holographic schematic line-work on deep navy slate, layered translucent drafting sheets floating in depth, precise measurement marks and cross-section annotations, soft cyan edge-glow, subtle depth-of-field bokeh between drawing layers, elegant engineering masterpiece composition"
    },
    {
        key: "movie",
        name: "CINEMATIC",
        accent: "#ffb347",
        deep1: "#140f0a",
        deep2: "#0a0705",
        art: "WIN",
        tune: {
            brightness: 0.58,
            saturation: 0.9
        },
        style: "epic cinematic movie key art, anamorphic widescreen composition, dramatic volumetric god rays cutting through haze, strong rim lighting sculpting the subject, teal and amber color grade, shallow depth of field, high-contrast chiaroscuro lighting, luxury film-poster craft, subtle film grain"
    },
    {
        key: "cyberpunk",
        name: "CYBERPUNK",
        accent: "#ff5c4d",
        deep1: "#170a12",
        deep2: "#0b0509",
        art: "STOP",
        tune: {
            brightness: 0.72,
            saturation: 0.92
        },
        style: "futuristic neon cyberpunk megacity key art, glowing magenta and cyan neon signage, rain-slick streets with mirror reflections, volumetric fog carrying neon glow, holographic depth layers, high-contrast night atmosphere, cinematic blade-runner mood, ultra-detailed professional digital art"
    },
    {
        key: "anime",
        name: "ANIME",
        accent: "#ff6b9a",
        deep1: "#160b14",
        deep2: "#0b060a",
        art: "NEW",
        tune: {
            brightness: 0.66,
            saturation: 0.95
        },
        style: "premium japanese anime key visual, bold cel shading with crisp highlights, dynamic energy trails and speed lines, dramatic backlighting, vibrant saturated palette, studio-grade composition, sharp expressive detail, cinematic anime poster quality"
    },
    {
        key: "popart",
        name: "POP ART",
        accent: "#ffd166",
        deep1: "#1a1206",
        deep2: "#0d0904",
        art: "FULL",
        tune: {
            brightness: 0.7,
            saturation: 1.0
        },
        style: "premium retro pop-art screen print, bold black ink outlines, large crisp halftone ben-day dots, punchy flat color blocks with offset print misregistration, dramatic comic-book shading, gallery-quality warhol poster composition"
    },
    {
        key: "vector",
        name: "VECTOR",
        accent: "#3ddc97",
        deep1: "#0a1510",
        deep2: "#050c09",
        art: "EXPIRED",
        tune: {
            brightness: 0.64,
            saturation: 0.85
        },
        style: "premium minimal vector fintech key art, smooth gradient mesh shapes, elegant geometric composition with layered depth, crisp rounded edges, subtle isometric accents, sophisticated dark-mode palette with glowing mint accents, high-end poster design"
    },
    {
        key: "clay",
        name: "CLAY",
        accent: "#c0e860",
        deep1: "#121408",
        deep2: "#090b05",
        art: "SHORT",
        tune: {
            brightness: 0.68,
            saturation: 0.82
        },
        style: "premium 3D claymation diorama, soft matte plasticine textures, rounded chunky shapes, cozy pastel studio lighting with soft shadows, subtle subsurface scattering glow, high-end 3D render quality, charming handcrafted look"
    }
];
function tehranDayKey(d = new Date()) {
    return new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Tehran",
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    }).format(d);
}
/** Epoch-day index for a Tehran day key (rotation counter). */ function seedFor(dayKey) {
    const [y, m, d] = dayKey.split("-").map(Number);
    return Math.floor(Date.UTC(y, (m ?? 1) - 1, d ?? 1) / 86_400_000);
}
function build(dayKey, seed, s) {
    return {
        dayKey,
        key: s.key,
        name: s.name,
        accent: s.accent,
        deep1: s.deep1,
        deep2: s.deep2,
        artKind: s.art,
        geometry: seed % 3,
        hueShift: 0,
        tune: s.tune,
        style: s.style,
        seed
    };
}
function dailySkin(d = new Date()) {
    const dayKey = tehranDayKey(d);
    const seed = seedFor(dayKey);
    const s = SKINS[(seed % SKINS.length + SKINS.length) % SKINS.length];
    return build(dayKey, seed, s);
}
function skinBySeed(seed) {
    const s = SKINS[(seed % SKINS.length + SKINS.length) % SKINS.length];
    return build(`seed-${seed}`, seed, s);
}
const SKIN_COUNT = SKINS.length;
const SKIN_NAMES = SKINS.map((s)=>s.name);
const SKIN_KEYS = SKINS.map((s)=>s.key);
const SKIN_KINDS = [
    "LONG",
    "SHORT",
    "TP",
    "STOP",
    "EXPIRED"
];
}),
"[project]/src/lib/telegram-art.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "baseAsset",
    ()=>baseAsset,
    "kindForStatus",
    ()=>kindForStatus,
    "loadCoinLogo",
    ()=>loadCoinLogo,
    "loadSkinArt",
    ()=>loadSkinArt,
    "loadSkinKindArt",
    ()=>loadSkinKindArt,
    "renderDailyPoster",
    ()=>renderDailyPoster,
    "renderSignalBannerV2",
    ()=>renderSignalBannerV2,
    "renderWeeklyPoster",
    ()=>renderWeeklyPoster
]);
// ── FlowRadar Neo v8.1 professional telegram artwork renderer (server-only) ─
// Operator round 2026-09-09: «آیا میشه ساخت تصاویر رو ارتقا داد تا گرافیکی‌تر
// و حرفه‌ای‌تر باشه؟ مثل نماد لوگو ارزها، برای وین گاو خشمگین و برای استاپ
// خرس خشمگین». This module is the YES: sharp (already a dependency) rasterizes
// design-grade SVG templates on top of AI-generated artwork, with real
// typography (DejaVu), live per-signal data, fetched coin logos, glow filters
// and stat cards. Every number drawn comes from the REAL signal/digest rows —
// the artwork is presentation, never invention.
//
// Fallback chain (wired in notify.ts):
//   renderSignalBannerV2 (this) → operator JPG art → renderStatusBanner (pixel)
//   renderDailyPoster (this)    → DAILY.jpg        → plain text caption
var __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__ = __turbopack_context__.i("[externals]/sharp [external] (sharp, cjs, [project]/node_modules/sharp)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/brand.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$daily$2d$skin$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/daily-skin.ts [instrumentation] (ecmascript)");
;
;
;
;
;
const W = 1280;
const H = 720;
const ASSETS_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), "assets", "telegram");
const COINS_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), "assets", "coins");
// ── palette (matches the v6.3 terminal identity) ──
const INK = "#e8f0ec";
const MUTED = "#8aa094";
const DIM = "#5a6e66";
const MINT = "#00ffa3";
const DANGER = "#ff4d5e";
const AMBER = "#ffb347";
const VIOLET = "#b26bff";
const GOLD = "#ffd700";
const PANEL_BG = "rgba(10,14,22,0.62)";
const PANEL_STROKE = "rgba(138,160,148,0.22)";
const STATUS_TEXT = {
    WIN: "WIN",
    STOP: "STOPPED",
    EXPIRED: "EXPIRED",
    NEW: "NEW SIGNAL",
    SHORT: "SHORT SIGNAL",
    TTL_EXT: "TTL EXTENDED",
    FULL: "FULL TARGET",
    AFTERLIFE: "AFTERLIFE"
};
const SPECTRAL = "#DB60FF"; // spectral magenta — EXPIRED FOLLOW-UP verdicts
const STATUS_COLOR = {
    WIN: MINT,
    STOP: DANGER,
    EXPIRED: AMBER,
    NEW: MINT,
    SHORT: DANGER,
    TTL_EXT: VIOLET,
    FULL: GOLD,
    AFTERLIFE: SPECTRAL
};
function escXml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
// ── AI artwork loading (art-{KIND}.png, generated once via scripts/gen-telegram-art.sh) ──
const artCache = new Map();
async function loadArt(kind) {
    if (artCache.has(kind)) return artCache.get(kind) ?? null;
    try {
        const buf = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(ASSETS_DIR, `art-${kind}.png`));
        artCache.set(kind, buf);
        return buf;
    } catch  {
        artCache.set(kind, null);
        return null;
    }
}
// ── v9.4 SKIN-CYCLE backdrop (skin-{KEY}.png, scripts/gen-skin-art.sh) ──
// The 7-skin cycle drives REAL AI generation: one visual style per day
// (BLUEPRINT · MOVIE · CYBERPUNK · ANIME · POP ART · VECTOR · CLAY), same
// subject scene across all seven. Negative results are cached for only 60s
// so backdrops generated while the server is live are picked up on the next
// render — the report must never wait on generation, but it must not need a
// restart to start wearing the new skin either.
const SKIN_NEG_TTL = 60_000;
const skinCache = new Map();
async function loadSkinArt(key) {
    const hit = skinCache.get(key);
    if (hit && (hit.buf || Date.now() - hit.at < SKIN_NEG_TTL)) return hit.buf;
    let buf = null;
    try {
        buf = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(ASSETS_DIR, `skin-${key}.png`));
    } catch  {
        buf = null;
    }
    skinCache.set(key, {
        buf,
        at: Date.now()
    });
    return buf;
}
function kindForStatus(status) {
    switch(status){
        case "NEW":
            return "LONG";
        case "SHORT":
            return "SHORT";
        case "WIN":
        case "FULL":
            return "TP";
        case "STOP":
            return "STOP";
        case "EXPIRED":
        case "AFTERLIFE":
        case "TTL_EXT":
            return "EXPIRED";
    }
}
async function loadSkinFile(file) {
    const hit = skinCache.get(file);
    if (hit && (hit.buf || Date.now() - hit.at < SKIN_NEG_TTL)) return hit.buf;
    let buf = null;
    try {
        buf = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(ASSETS_DIR, file));
    } catch  {
        buf = null;
    }
    skinCache.set(file, {
        buf,
        at: Date.now()
    });
    return buf;
}
async function loadSkinKindArt(key, kind) {
    return await loadSkinFile(`skin-${key}-${kind}.png`) ?? await loadSkinFile(`skin-${key}.png`);
}
/** Shared composite: style backdrop + modulation tuned per skin (v9.4 — the
 * style identity is never hue-rotated; brightness/saturation keep the overlay
 * text readable). v10.21: the modulated 1280×720 backdrop is cached per art
 * file — an animation burst re-renders the SAME backdrop 14× and only the
 * overlay changes, so re-modulating every frame was 60%+ of the burst cost
 * (688ms/frame → the cache removes the resize+modulate from frames 2..14). */ const bgCache = new Map(); // art cacheKey → modulated 1280×720 bg
async function modulatedBackdrop(art, skin, cacheKey) {
    const hit = bgCache.get(cacheKey);
    if (hit) return hit;
    const bg = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(art).resize(W, H, {
        fit: "cover"
    }).modulate({
        brightness: skin.tune.brightness,
        saturation: skin.tune.saturation,
        hue: skin.hueShift
    }).toBuffer();
    if (bgCache.size >= 6) bgCache.delete(bgCache.keys().next().value);
    bgCache.set(cacheKey, bg);
    return bg;
}
async function withBackdrop(art, skin, overlay, extra = [], cacheKey = "poster") {
    const bg = await modulatedBackdrop(art, skin, cacheKey);
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(bg).composite([
        {
            input: overlay
        },
        ...extra
    ]).png({
        compressionLevel: 8
    }).toBuffer();
}
// ── coin logos: jsdelivr cryptocurrency-icons (spothq), cached on disk ──
// https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/svg/color/{base}.svg
const logoCache = new Map(); // base → rasterized 160px PNG
function baseAsset(symbol) {
    const s = symbol.toUpperCase();
    for (const quote of [
        "USDT",
        "USDC",
        "BUSD",
        "FDUSD",
        "USD"
    ]){
        if (s.endsWith(quote) && s.length > quote.length) return s.slice(0, s.length - quote.length);
    }
    return s;
}
async function loadCoinLogo(symbol) {
    const base = baseAsset(symbol);
    if (logoCache.has(base)) return logoCache.get(base) ?? null;
    let result = null;
    // 1) disk cache
    const diskPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(COINS_DIR, `${base}.svg`);
    try {
        const svg = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(diskPath);
        result = await rasterizeLogo(svg);
    } catch  {
        // 2) remote fetch (3s cap — relay is fire-and-forget, never stall the tick)
        try {
            const ctrl = new AbortController();
            const t = setTimeout(()=>ctrl.abort(), 3000);
            const res = await fetch(`https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/svg/color/${base.toLowerCase()}.svg`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(t);
            if (res.ok) {
                const svg = Buffer.from(await res.arrayBuffer());
                result = await rasterizeLogo(svg);
                if (result) {
                    await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].mkdir(COINS_DIR, {
                        recursive: true
                    }).catch(()=>undefined);
                    await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(diskPath, svg).catch(()=>undefined);
                }
            }
        } catch  {}
    }
    logoCache.set(base, result);
    return result;
}
async function rasterizeLogo(svg) {
    try {
        return await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(svg, {
            density: 300
        }).resize(160, 160).png().toBuffer();
    } catch  {
        return null;
    }
}
// ── shared SVG fragments ──
// v10.20: DejaVu Sans Mono advance ≈ 0.602em — width estimates keep the three
// footer zones collision-free (the old fixed x=W/2 center collided with the
// brand line whenever the center text ran long — seen live on WIN cards:
// «LIVE ENGINEDONEST NUMBERS…», letter-spacing was the hidden multiplier).
const MONO_EM = 0.602;
function monoW(text, size, ls = 0) {
    if (!text) return 0;
    return text.length * (size * MONO_EM + ls) - ls; // trailing letter-spacing is not drawn
}
/** v10.20 top-right timestamp chip — a dark scrim pill so the stamp stays
 * readable when the skin art behind it is bright (gold coins, neon halos). */ function tsChip(ts, baseline, size, ls = 2) {
    if (!ts) return "";
    const w = monoW(ts, size, ls) + 26;
    const h = size + 18;
    return `<rect x="${(W - 40 - w).toFixed(0)}" y="${(baseline - size - 6).toFixed(0)}" width="${w.toFixed(0)}" height="${h}" rx="10" ry="10" fill="rgba(6,9,16,0.62)" stroke="rgba(138,160,148,0.2)" stroke-width="1"/>
  <text x="${W - 40 - 13}" y="${baseline}" font-family="DejaVu Sans Mono" font-size="${size}" fill="${INK}" text-anchor="end" letter-spacing="${ls}">${escXml(ts)}</text>`;
}
function hudTicks(accent) {
    const t = 26, o = 20, len = 26, sw = 3;
    const corner = (x, y, dx, dy)=>`<path d="M ${x + dx * len} ${y} L ${x} ${y} L ${x} ${y + dy * len}" stroke="${accent}" stroke-width="${sw}" fill="none" opacity="0.85"/>`;
    return corner(o, t, 1, 1) + corner(W - o, t, -1, 1) + corner(o, H - t, 1, -1) + corner(W - o, H - t, -1, -1);
}
function footerBar(ts, center) {
    const y = H - 62;
    const left = "FLOWRADAR-NEO LIVE ENGINE";
    const L = 40 + monoW(left, 21, 2) + 30; // usable span for the center text
    const R = W - 40 - monoW(ts, 21) - 30;
    let shown = "";
    if (center) {
        shown = center;
        if (monoW(shown, 21, 2) > R - L) {
            // v10.20 auto-fit: truncate with ellipsis instead of colliding with the brand line
            while(shown.length > 4 && monoW(`${shown}…`, 21, 2) > R - L)shown = shown.slice(0, -1);
            shown = `${shown.trimEnd()}…`;
        }
    }
    const cx = Math.round((L + R) / 2);
    return `
  <rect x="0" y="${y}" width="${W}" height="62" fill="rgba(6,9,16,0.88)"/>
  <rect x="0" y="${y}" width="${W}" height="2" fill="${PANEL_STROKE}"/>
  <text x="40" y="${y + 39}" font-family="DejaVu Sans Mono" font-size="21" fill="${VIOLET}" letter-spacing="2">${left}</text>
  ${shown ? `<text x="${cx}" y="${y + 39}" font-family="DejaVu Sans Mono" font-size="21" fill="${MUTED}" text-anchor="middle" letter-spacing="2">${escXml(shown)}</text>` : ""}
  <text x="${W - 40}" y="${y + 39}" font-family="DejaVu Sans Mono" font-size="21" fill="${DIM}" text-anchor="end">${escXml(ts)}</text>`;
}
function gridPattern() {
    const lines = [];
    for(let x = 64; x < W; x += 64)lines.push(`<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="rgba(138,160,148,0.05)" stroke-width="1"/>`);
    for(let y = 64; y < H; y += 64)lines.push(`<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="rgba(138,160,148,0.05)" stroke-width="1"/>`);
    return lines.join("");
}
function defs(status, skin, pulse = 0) {
    const accent = STATUS_COLOR[status];
    const deep1 = skin?.deep1 ?? "#0b101c";
    const deep2 = skin?.deep2 ?? "#070a12";
    const haloAccent = skin?.accent ?? accent;
    const haloCx = skin ? [
        0.22,
        0.78,
        0.5
    ][skin.geometry] : 0.22;
    const haloCy = skin ? [
        0.42,
        0.35,
        0.62
    ][skin.geometry] : 0.42;
    return `<defs>
    <linearGradient id="scrim" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="rgba(6,9,16,0.94)"/>
      <stop offset="0.45" stop-color="rgba(6,9,16,0.82)"/>
      <stop offset="0.78" stop-color="rgba(6,9,16,0.30)"/>
      <stop offset="1" stop-color="rgba(6,9,16,0.12)"/>
    </linearGradient>
    <linearGradient id="topbar" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="${accent}"/>
      <stop offset="1" stop-color="${accent}" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="bgdeep" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${deep1}"/>
      <stop offset="1" stop-color="${deep2}"/>
    </linearGradient>
    <radialGradient id="bghalo" cx="${haloCx}" cy="${haloCy}" r="0.85">
      <stop offset="0" stop-color="${haloAccent}" stop-opacity="0.18"/>
      <stop offset="1" stop-color="${haloAccent}" stop-opacity="0"/>
    </radialGradient>
    <filter id="glow" x="-40%" y="-40%" width="180%" height="180%">
      <feGaussianBlur stdDeviation="${(7 + 9 * pulse).toFixed(1)}" result="b"/>
      <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <filter id="softglow" x="-40%" y="-40%" width="180%" height="180%">
      <feGaussianBlur stdDeviation="4" result="b"/>
      <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <linearGradient id="sweepbeam" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#ffffff" stop-opacity="0"/>
      <stop offset="0.5" stop-color="#ffffff" stop-opacity="0.26"/>
      <stop offset="1" stop-color="#ffffff" stop-opacity="0"/>
    </linearGradient>
  </defs>`;
}
/** v10.21 MOTION LAYER — animated-card-only elements (phase 0..1 loop).
 * v10.20 shipped a pulse so faint it read as a static GIF (operator:
 * «هیچ موشنی ندارد») — the only deltas were blur 8→13 behind the headline
 * and a 3px bar's opacity. The fix is motion you cannot miss:
 *   · sonar rings — pings expanding from the coin badge (under text)
 *   · sweep beam — a diagonal light pass crossing the whole card (over all)
 *   · headline glow — 2.5× stronger breathing (7→16 blur)
 *   · bottom traveler — a bright segment physically crossing the footer
 * Traveling elements key off `phase` (monotonic 0→1) so the loop is
 * seamless: the sweep and traveler are fully off-canvas at both ends,
 * rings fade to zero opacity before restarting. Static cards never draw
 * this layer (phase undefined). Split under/over: rings sit behind the
 * typography, the sweep + traveler must land AFTER footerBar (the footer
 * rect would otherwise cover them). */ function ringsLayer(status, phase) {
    const accent = STATUS_COLOR[status];
    const ringR = (36 + phase * 264).toFixed(0);
    const ringOp = (0.5 * (1 - phase)).toFixed(3);
    return `
  <circle cx="108" cy="214" r="${ringR}" fill="none" stroke="${accent}" stroke-width="${(1 + 2.2 * (1 - phase)).toFixed(2)}" opacity="${ringOp}"/>
  <circle cx="108" cy="214" r="${(Number(ringR) * 0.62).toFixed(0)}" fill="none" stroke="${accent}" stroke-width="1.4" opacity="${(0.3 * (1 - phase)).toFixed(3)}"/>`;
}
function shineLayer(status, phase) {
    const accent = STATUS_COLOR[status];
    // sweep beam: rotate(-14°) rect traveling left→right, 240px wide,
    // taller than the card so the rotation never exposes corners
    const sweepX = -720 + phase * (W + 1440) - 120;
    const sweep = `
  <g transform="rotate(-14 ${W / 2} ${H / 2})">
    <rect x="${sweepX.toFixed(0)}" y="-240" width="240" height="${H + 480}" fill="url(#sweepbeam)"/>
  </g>`;
    // bottom traveler: bright segment crossing the footer bar, off-canvas at both ends
    const segX = -300 + phase * (W + 600);
    const traveler = `<rect x="${segX.toFixed(0)}" y="${H - 8}" width="300" height="3" fill="${accent}" opacity="0.9"/>`;
    return `${sweep}${traveler}`;
}
function fmtLadderPrice(p) {
    return p >= 100 ? p.toFixed(2) : p.toFixed(p >= 1 ? 4 : 6);
}
function ladderStrip(l) {
    const vals = [
        l.sl,
        l.entry,
        l.tp1,
        l.tp2,
        l.tp3
    ];
    if (vals.some((v)=>!Number.isFinite(v) || v <= 0)) return "";
    // monotone guard — inverted/crossed ladders are skipped, never redrawn "fixed"
    const ok = l.direction === "LONG" ? l.sl < l.entry && l.entry < l.tp1 && l.tp1 < l.tp2 && l.tp2 < l.tp3 : l.sl > l.entry && l.entry > l.tp1 && l.tp1 > l.tp2 && l.tp2 > l.tp3;
    if (!ok) return "";
    const x0 = 76, x1 = 590, railY = 592;
    const lo = Math.min(...vals), hi = Math.max(...vals);
    const span = hi - lo || 1;
    const X = (p)=>x0 + (p - lo) / span * (x1 - x0);
    const levels = [
        {
            p: l.sl,
            name: "SL",
            col: DANGER,
            banked: false,
            kind: "sl"
        },
        {
            p: l.entry,
            name: "ENTRY",
            col: INK,
            banked: false,
            kind: "entry"
        },
        {
            p: l.tp1,
            name: "TP1",
            col: MINT,
            banked: l.reachedTp >= 1,
            kind: "tp"
        },
        {
            p: l.tp2,
            name: "TP2",
            col: MINT,
            banked: l.reachedTp >= 2,
            kind: "tp"
        },
        {
            p: l.tp3,
            name: "TP3",
            col: GOLD,
            banked: l.reachedTp >= 3,
            kind: "tp"
        }
    ];
    // label stagger — two rows keep close levels readable (mark near a rung, tight ladders)
    const sorted = [
        ...levels
    ].sort((a, b)=>X(a.p) - X(b.p));
    const rowOf = new Map();
    let lastX = -999, lastRow = 0;
    for (const lv of sorted){
        const x = X(lv.p);
        const row = x - lastX < 64 ? (lastRow + 1) % 2 : 0;
        rowOf.set(lv.name, row);
        lastX = x;
        lastRow = row;
    }
    const bankedTp = l.reachedTp >= 3 ? l.tp3 : l.reachedTp >= 2 ? l.tp2 : l.reachedTp >= 1 ? l.tp1 : null;
    const seg = (a, b, col, wdt, op)=>a === b ? "" : `<line x1="${X(Math.min(a, b)).toFixed(1)}" y1="${railY}" x2="${X(Math.max(a, b)).toFixed(1)}" y2="${railY}" stroke="${col}" stroke-width="${wdt}" opacity="${op}" stroke-linecap="round"/>`;
    const segments = seg(l.entry, l.sl, DANGER, 5, 0.3) + seg(l.entry, l.tp3, MINT, 5, 0.22) + (bankedTp !== null ? seg(l.entry, bankedTp, GOLD, 6, 0.9) : "");
    const ticks = levels.map((lv)=>{
        const x = X(lv.p);
        const xs = x.toFixed(1);
        const row = rowOf.get(lv.name) ?? 0;
        const nameY = railY - 16 - row * 16;
        const priceY = railY + 26 + row * 17;
        const mark = lv.kind === "entry" ? `<rect x="${(x - 5).toFixed(1)}" y="${railY - 5}" width="10" height="10" fill="${lv.col}" transform="rotate(45 ${xs} ${railY})" stroke="rgba(6,9,16,0.8)" stroke-width="1.5"/>` : lv.banked ? `<circle cx="${xs}" cy="${railY}" r="7" fill="${GOLD}" filter="url(#softglow)"/><path d="M ${(x - 3).toFixed(1)} ${railY} l 2.4 2.8 l 4 -5.4" stroke="#0b101c" stroke-width="1.8" fill="none" stroke-linecap="round"/>` : `<circle cx="${xs}" cy="${railY}" r="5" fill="rgba(6,9,16,0.85)" stroke="${lv.col}" stroke-width="2.2"/>`;
        return `<line x1="${xs}" y1="${railY - 9}" x2="${xs}" y2="${railY + 9}" stroke="${lv.col}" stroke-width="1.4" opacity="0.55"/>
    <text x="${xs}" y="${nameY}" font-family="DejaVu Sans Mono" font-size="14" fill="${lv.banked ? GOLD : lv.col}" text-anchor="middle" letter-spacing="1" font-weight="${lv.banked ? 700 : 400}">${lv.name}</text>
    <text x="${xs}" y="${priceY}" font-family="DejaVu Sans Mono" font-size="14.5" fill="${lv.banked ? GOLD : MUTED}" text-anchor="middle">${fmtLadderPrice(lv.p)}</text>
    ${mark}`;
    }).join("");
    return `
  <text x="40" y="552" font-family="DejaVu Sans Mono" font-size="15" fill="${MUTED}" letter-spacing="3">PRICE LADDER — BANKED IN GOLD</text>
  ${segments}
  <line x1="${x0 - 14}" y1="${railY}" x2="${x1 + 14}" y2="${railY}" stroke="rgba(138,160,148,0.3)" stroke-width="1"/>
  ${ticks}`;
}
function bannerOverlaySvg(spec, hasLogo, hasArt, skin) {
    const accent = STATUS_COLOR[spec.status];
    const pulse = spec.pulse ?? 0;
    const parts = spec.title.trim().split(/\s+/);
    const symbol = escXml(parts[0] ?? "");
    const direction = /SHORT/i.test(spec.title) ? "SHORT" : "LONG";
    const dirCol = direction === "LONG" ? MINT : DANGER;
    const dirArrow = direction === "LONG" ? "▲" : "▼";
    const base = baseAsset(symbol);
    const badgeCx = 108, badgeCy = 214, badgeR = 56;
    // data rows
    const rows = [];
    if (spec.line1) rows.push({
        text: spec.line1,
        col: accent
    });
    if (spec.line2) rows.push({
        text: spec.line2,
        col: INK
    });
    return `
  <svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    ${defs(spec.status, skin, pulse)}
    ${hasArt ? "" : proceduralBackdrop(spec.status, skin)}
    <rect x="0" y="0" width="${W}" height="${H}" fill="url(#scrim)"/>
    <rect x="0" y="0" width="${W}" height="6" fill="url(#topbar)"/>
    <rect x="0" y="${H - 8}" width="${W}" height="3" fill="${accent}" opacity="${(0.45 + 0.35 * pulse).toFixed(2)}"/>
    ${spec.phase !== undefined ? ringsLayer(spec.status, spec.phase) : ""}
    ${hudTicks(accent)}
    <text x="40" y="52" font-family="DejaVu Sans" font-size="24" font-weight="700" fill="${MUTED}" letter-spacing="7">${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].head}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].sep}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].tail}</text>
    ${tsChip(spec.ts ?? "", 52, 22)}

    <!-- coin badge -->
    <circle cx="${badgeCx}" cy="${badgeCy}" r="${badgeR + 6}" fill="rgba(6,9,16,0.65)" stroke="${PANEL_STROKE}" stroke-width="2"/>
    <circle cx="${badgeCx}" cy="${badgeCy}" r="${badgeR}" fill="rgba(255,255,255,0.04)" stroke="${accent}" stroke-width="3"/>
    ${hasLogo ? "" : `<text x="${badgeCx}" y="${badgeCy + 16}" font-family="DejaVu Sans" font-size="40" font-weight="700" fill="${INK}" text-anchor="middle">${escXml(base.slice(0, 3))}</text>`}

    <!-- symbol + direction -->
    <text x="196" y="200" font-family="DejaVu Sans" font-size="52" font-weight="700" fill="${INK}" letter-spacing="1">${symbol}</text>
    <rect x="196" y="222" rx="17" ry="17" width="168" height="34" fill="${dirCol}" opacity="0.16"/>
    <text x="212" y="247" font-family="DejaVu Sans Mono" font-size="24" font-weight="700" fill="${dirCol}" letter-spacing="3">${dirArrow} ${direction}</text>

    <!-- status headline -->
    <text x="38" y="372" font-family="DejaVu Sans" font-size="104" font-weight="700" fill="${accent}" filter="url(#glow)" letter-spacing="2">${escXml(STATUS_TEXT[spec.status])}</text>

    <!-- separator + data rows -->
    <rect x="40" y="410" width="560" height="2" fill="rgba(138,160,148,0.25)"/>
    ${rows.map((r, i)=>`<text x="40" y="${462 + i * 48}" font-family="DejaVu Sans Mono" font-size="32" fill="${r.col}" letter-spacing="1" filter="url(#softglow)">${escXml(r.text)}</text>`).join("")}

    ${spec.ladder ? ladderStrip(spec.ladder) : ""}

    ${footerBar(spec.ts ?? "", spec.footer ?? "HONEST NUMBERS FROM THE LIVE ENGINE")}
    ${spec.phase !== undefined ? shineLayer(spec.status, spec.phase) : ""}
  </svg>`;
}
function proceduralBackdrop(status, skin) {
    const accent = STATUS_COLOR[status];
    const halo = skin?.accent ?? accent;
    const gx = skin ? [
        W - 240,
        240,
        W / 2
    ][skin.geometry] : W - 240;
    const gy = skin ? [
        H / 2 - 60,
        H / 2 + 40,
        H / 2
    ][skin.geometry] : H / 2 - 60;
    return `<rect x="0" y="0" width="${W}" height="${H}" fill="url(#bgdeep)"/>
  <rect x="0" y="0" width="${W}" height="${H}" fill="url(#bghalo)"/>
  ${gridPattern()}
  <circle cx="${gx}" cy="${gy}" r="230" fill="${halo}" opacity="0.06"/>
  <circle cx="${gx}" cy="${gy}" r="150" fill="${halo}" opacity="0.06"/>`;
}
async function renderSignalBannerV2(spec) {
    const skin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$daily$2d$skin$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["dailySkin"])(); // v9.4 daily style rotation — the day's skin dresses every card
    const logo = await loadCoinLogo(spec.title.split(/\s+/)[0] ?? "");
    // AFTERLIFE reuses the EXPIRED artwork — post-expiry verdicts ARE expired
    // signals reporting back; the spectral headline + accents tell them apart.
    const legacyArt = await loadArt(spec.status === "SHORT" ? "SHORT" : spec.status === "FULL" ? "FULL" : spec.status === "AFTERLIFE" ? "EXPIRED" : spec.status);
    const kind = kindForStatus(spec.status);
    const kindArt = await loadSkinKindArt(skin.key, kind);
    const skinArt = kindArt ?? await loadSkinArt(skin.key);
    const backdrop = skinArt ?? legacyArt;
    const overlay = Buffer.from(bannerOverlaySvg(spec, Boolean(logo), Boolean(backdrop), skin));
    const composites = [
        {
            input: overlay
        }
    ];
    if (logo) composites.push({
        input: await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(logo).resize(88, 88).png().toBuffer(),
        left: 108 - 44,
        top: 214 - 44
    });
    if (backdrop) {
        if (skinArt) {
            // kind skin art primary — skin.tune modulation keeps the day's style identity readable
            // cacheKey = the exact art file behind skinArt (kind file or generic fallback)
            const cacheKey = `card:${skin.key}:${kindArt ? kind : "generic"}`;
            return withBackdrop(skinArt, skin, overlay, composites.slice(1), cacheKey);
        }
        const bg = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(legacyArt).resize(W, H, {
            fit: "cover"
        }).modulate({
            brightness: 0.78,
            saturation: 0.88,
            hue: skin.hueShift
        }).toBuffer();
        return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(bg).composite(composites).png({
            compressionLevel: 8
        }).toBuffer();
    }
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(overlay).composite(composites.slice(1)).png({
        compressionLevel: 8
    }).toBuffer();
}
// ── daily performance poster ──
function fmtUsd(v) {
    const sign = v >= 0 ? "+" : "−";
    return `${sign}$${Math.abs(v).toFixed(2)}`;
}
function statCard(x, y, w, h, label, value, col, accentBorder = false) {
    return `
  <rect x="${x}" y="${y}" width="${w}" height="${h}" rx="14" ry="14" fill="${PANEL_BG}" stroke="${accentBorder ? col : PANEL_STROKE}" stroke-width="${accentBorder ? 2 : 1}"/>
  <text x="${x + 20}" y="${y + 34}" font-family="DejaVu Sans Mono" font-size="19" fill="${MUTED}" letter-spacing="3">${escXml(label)}</text>
  <text x="${x + 20}" y="${y + 78}" font-family="DejaVu Sans" font-size="36" font-weight="700" fill="${col}">${escXml(value)}</text>`;
}
function miniStat(x, y, w, h, label, value, col) {
    return `
  <rect x="${x}" y="${y}" width="${w}" height="${h}" rx="12" ry="12" fill="${PANEL_BG}" stroke="${PANEL_STROKE}" stroke-width="1"/>
  <text x="${x + 16}" y="${y + 28}" font-family="DejaVu Sans Mono" font-size="16" fill="${MUTED}" letter-spacing="2">${escXml(label)}</text>
  <text x="${x + w - 16}" y="${y + 46}" font-family="DejaVu Sans" font-size="30" font-weight="700" fill="${col}" text-anchor="end">${escXml(value)}</text>`;
}
function winRateRing(cx, cy, r, pct) {
    const C = 2 * Math.PI * r;
    const frac = pct === null ? 0 : Math.max(0, Math.min(100, pct)) / 100;
    const col = pct === null ? MUTED : pct >= 50 ? MINT : pct >= 35 ? AMBER : DANGER;
    const label = pct === null ? "—" : `${Math.round(pct)}%`;
    return `
  <circle cx="${cx}" cy="${cy}" r="${r}" fill="rgba(10,14,22,0.55)" stroke="${PANEL_STROKE}" stroke-width="1"/>
  <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(255,255,255,0.07)" stroke-width="15"/>
  <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${col}" stroke-width="15" stroke-linecap="round"
    stroke-dasharray="${(frac * C).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 ${cx} ${cy})" filter="url(#softglow)"/>
  <text x="${cx}" y="${cy + 6}" font-family="DejaVu Sans" font-size="40" font-weight="700" fill="${col}" text-anchor="middle">${label}</text>
  <text x="${cx}" y="${cy + 34}" font-family="DejaVu Sans Mono" font-size="15" fill="${MUTED}" text-anchor="middle" letter-spacing="2">WIN RATE</text>`;
}
/** v10.20 EQUITY SPARKLINE — real 14-day realized-equity walk from the DB
 * (dailyReport.equityCurve), last point = live equity mark. Feeds the
 * top-right panel of the daily/weekly poster. */ function sparkline(curve, x, y, w, h) {
    const pts = curve.filter((v)=>Number.isFinite(v));
    if (pts.length < 2) return "";
    const lo = Math.min(...pts), hi = Math.max(...pts);
    const span = hi - lo || Math.max(1, Math.abs(hi) * 0.02);
    const px = (i)=>x + 14 + i / (pts.length - 1) * (w - 28);
    const py = (v)=>y + h - 18 - (v - lo) / span * (h - 40);
    const line = pts.map((v, i)=>`${i === 0 ? "M" : "L"} ${px(i).toFixed(1)} ${py(v).toFixed(1)}`).join(" ");
    const area = `${line} L ${px(pts.length - 1).toFixed(1)} ${(y + h - 12).toFixed(1)} L ${px(0).toFixed(1)} ${(y + h - 12).toFixed(1)} Z`;
    const up = pts[pts.length - 1] >= pts[0];
    const col = up ? MINT : DANGER;
    return `
  <path d="${area}" fill="${col}" opacity="0.10"/>
  <path d="${line}" fill="none" stroke="${col}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" filter="url(#softglow)"/>
  <circle cx="${px(pts.length - 1).toFixed(1)}" cy="${py(pts[pts.length - 1]).toFixed(1)}" r="4" fill="${col}" filter="url(#softglow)"/>`;
}
function posterOverlaySvg(spec, hasArtBackdrop, skin) {
    const d = spec.digest;
    const netCol = d.realizedUsd >= 0 ? MINT : DANGER;
    const weekly = spec.variant === "weekly";
    const trades = (d.trades ?? []).slice(0, 5);
    const maxAbs = Math.max(0.5, ...trades.map((t)=>Math.abs(t.pnl)));
    const cards = [
        [
            weekly ? "NET 7D" : "NET 24H",
            fmtUsd(d.realizedUsd),
            netCol,
            true
        ],
        [
            "EQUITY",
            `$${d.equityUsd.toFixed(2)}`,
            INK
        ],
        [
            "OPEN PNL",
            fmtUsd(d.unrealizedUsd),
            d.unrealizedUsd >= 0 ? MINT : DANGER
        ],
        [
            "FEES",
            `−$${d.feesUsd.toFixed(2)}`,
            MUTED
        ]
    ];
    const cardW = 268, gap = 24, x0 = 40;
    const cardsSvg = cards.map(([label, value, col, hero], i)=>statCard(x0 + i * (cardW + gap), 196, cardW, 118, label, value, col, Boolean(hero))).join("");
    const minis = [
        [
            "DEPLOYED",
            String(d.opened),
            INK
        ],
        [
            "CLOSED",
            String(d.closed),
            INK
        ],
        [
            "ACTIVE NOW",
            String(d.active),
            VIOLET
        ],
        [
            "WINS",
            String(d.wins),
            MINT
        ],
        [
            "STOPS",
            String(d.stops),
            DANGER
        ],
        [
            "EXPIRED",
            String(d.expired),
            AMBER
        ]
    ];
    const mw = 256, mg = 16, mx0 = 440;
    const minisSvg = minis.map(([label, value, col], i)=>{
        const cx = mx0 + i % 3 * (mw + mg);
        const cy = 360 + Math.floor(i / 3) * 86;
        return miniStat(cx, cy, mw, 72, label, value, col);
    }).join("");
    // trade bars (compact rows — must clear the footer bar at y=658)
    const barRows = trades.map((t, i)=>{
        const y = 552 + i * 21;
        const w = Math.max(6, Math.abs(t.pnl) / maxAbs * 300);
        const col = t.pnl >= 0 ? MINT : DANGER;
        const sign = t.pnl >= 0 ? "+" : "";
        return `
    <text x="440" y="${y + 14}" font-family="DejaVu Sans Mono" font-size="16" fill="${MUTED}">${escXml(t.symbol)}</text>
    <rect x="580" y="${y + 2}" width="${w.toFixed(0)}" height="14" rx="7" ry="7" fill="${col}" opacity="0.85"/>
    <text x="${(580 + w + 10).toFixed(0)}" y="${y + 14}" font-family="DejaVu Sans Mono" font-size="16" fill="${col}">${sign}${t.pnl.toFixed(1)}%</text>`;
    }).join("");
    const bestLine = d.best ? `BEST ${d.best.symbol} +${d.best.pnl.toFixed(1)}%` : "NO CLOSED TRADES YET";
    const volLine = d.volCauseCaptures > 0 ? `VOL-CAUSE ${d.volCauseCaptures}${d.topCause ? ` · ${d.topCause}` : ""}` : "";
    // v10.20 equity sparkline panel — top-right, beside the headline. Panel x=864
    // clears the auto-fit headlines (daily 60px / weekly 54px — DejaVu Bold caps
    // run ≈0.72em, measured off the live render where 64px ran under the panel).
    const curve = (d.equityCurve ?? []).filter((v)=>Number.isFinite(v));
    const sparkPanel = curve.length >= 2 ? `
  <rect x="864" y="76" width="380" height="100" rx="14" ry="14" fill="${PANEL_BG}" stroke="${PANEL_STROKE}" stroke-width="1"/>
  <text x="880" y="100" font-family="DejaVu Sans Mono" font-size="13" fill="${MUTED}" letter-spacing="2">EQUITY 14D · REALIZED + LIVE</text>
  <text x="1228" y="100" font-family="DejaVu Sans" font-size="16" font-weight="700" fill="${INK}" text-anchor="end">$${d.equityUsd.toFixed(2)}</text>
  ${sparkline(curve, 864, 76, 380, 100)}` : "";
    return `
  <svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    ${defs("WIN", skin)}
    ${hasArtBackdrop ? "" : proceduralBackdrop("WIN", skin)}
    <rect x="0" y="0" width="${W}" height="${H}" fill="rgba(6,9,16,0.90)"/>
    <rect x="0" y="0" width="${W}" height="6" fill="url(#topbar)"/>
    ${hudTicks(weekly ? VIOLET : GOLD)}
    <text x="40" y="56" font-family="DejaVu Sans" font-size="24" font-weight="700" fill="${MUTED}" letter-spacing="7">${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].head}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].sep}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].tail}</text>
    ${tsChip(spec.ts ?? "", 56, 21)}
    <text x="40" y="140" font-family="DejaVu Sans" font-size="${weekly ? 54 : 60}" font-weight="700" fill="${weekly ? VIOLET : GOLD}" filter="url(#glow)" letter-spacing="2">${weekly ? "WEEKLY PERFORMANCE" : "DAILY PERFORMANCE"}</text>
    <text x="40" y="176" font-family="DejaVu Sans Mono" font-size="22" fill="${MUTED}" letter-spacing="1">${escXml(d.windowLabel)}${skin ? `  ·  SKIN ${skin.name}` : ""}</text>
    ${sparkPanel}
    ${cardsSvg}
    ${winRateRing(230, 500, 108, d.winRatePct)}
    ${minisSvg}
    <text x="440" y="540" font-family="DejaVu Sans Mono" font-size="17" fill="${MUTED}" letter-spacing="3">CLOSED TRADES — NET %</text>
    ${barRows}
    <text x="1240" y="540" font-family="DejaVu Sans Mono" font-size="17" fill="${MINT}" text-anchor="end" letter-spacing="1">${escXml(bestLine)}</text>
    ${footerBar(spec.ts ?? "", volLine || "HONEST NUMBERS FROM THE LIVE ENGINE")}
  </svg>`;
}
async function renderDailyPoster(spec) {
    const skin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$daily$2d$skin$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["dailySkin"])();
    const art = await loadSkinArt(skin.key) ?? await loadArt("DAILY");
    const svg = Buffer.from(posterOverlaySvg(spec, Boolean(art), skin));
    if (art) return withBackdrop(art, skin, svg, [], `poster:${skin.key}`);
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(svg).png({
        compressionLevel: 8
    }).toBuffer();
}
async function renderWeeklyPoster(spec) {
    return renderDailyPoster({
        ...spec,
        variant: "weekly"
    });
}
}),
"[project]/src/lib/notify.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BANNED_RELAY_TYPES",
    ()=>BANNED_RELAY_TYPES,
    "RELAYABLE_TYPES",
    ()=>RELAYABLE_TYPES,
    "discoverChat",
    ()=>discoverChat,
    "ensureAutoDiscover",
    ()=>ensureAutoDiscover,
    "loadDailyArt",
    ()=>loadDailyArt,
    "primeRelayState",
    ()=>primeRelayState,
    "relayArmed",
    ()=>relayArmed,
    "relayHealth",
    ()=>relayHealth,
    "relaySignalEvent",
    ()=>relaySignalEvent,
    "sendAnimationDirect",
    ()=>sendAnimationDirect,
    "sendChannelTest",
    ()=>sendChannelTest,
    "sendDailyReport",
    ()=>sendDailyReport,
    "sendDirect",
    ()=>sendDirect,
    "sendPhotoDirect",
    ()=>sendPhotoDirect,
    "sendSampleCards",
    ()=>sendSampleCards
]);
// ── FlowRadar Neo v6.3 outbound relay (server-only) ───────────────────────
// TELEGRAM mirror for ALERTABLE engine events. v6.3 operator round:
// «اصلاح ساختار پیام‌های تلگرامی — چیدمان مرتب و خط به خط با ایموجی، و
// تصویر برای سیگنالهای win / stop / EXPIRED». Every relay now sends a
// STRUCTURED HTML card (tidy line-by-line, emoji-labelled fields) and the
// three outcome classes get a RENDERED BANNER IMAGE (dependency-free PNG
// from telegram-image.ts): WIN (TP1/TP2/TP3, mint), STOP (SL, danger),
// EXPIRED (TTL_EXPIRED, amber). Card fields come from the REAL signal row —
// nothing is invented; when the row is unavailable the engine message line
// is relayed verbatim as the honest fallback.
//
// Delivery remains fire-and-forget with hard timeouts so Telegram can never
// stall the engine tick; the error ring + counters feed /api/notify health.
// ── v12.0.1 TASK-46 RELAY REPAIR (operator: «پیام‌های تکراری مدام + تصاویر
// کامل نیست و در بیشتر موارد بدون تصویر») ─────────────────────────────────
// ① RAW-CAL CREATED cards carry their banner again — the v10.4 text-only
//    strip was designed when capture was an occasional mode; the whole book
//    is RAW-CAL now, so MOST cards shipped bare-text (the operator's exact
//    complaint). Photos ship for every CREATED; a 6/hour global flood valve
//    (createdPhotoBudget) stays as the anti-spam backstop.
// ② TTL_EXTENDED hourly-grant spam — the dynamic expiry gate can legitimately
//    grant up to 3× (+60m each); each grant shipped a FULL photo card → the
//    same card every hour. Grant #1 keeps the full card; grants ≥2 degrade to
//    a compact one-line text (mechanics unchanged — the relay policy changed).
// ③ Upload timeouts: photo 9s→20s, animation→25s, apiCall 4.5s→9s — multipart
//    uploads through the memory-starved process + rotating egress pool were
//    aborting → silent text fallback → «بدون تصویر». One photo retry added.
// ④ Caption safety: photo captions >1024 chars are REJECTED by Telegram (the
//    whole send fails → text fallback = another imageless card). The engine
//    message blockquote now truncates to keep the caption ≤1000.
// ── v12.9 RESTART-PROOF DELIVERY — outbox cursor over SignalEvent (trace
// 1a1ba99d0cb24dd9, operator: «توصیه‌های پیشنهادی را کامل و مهندسی اجرا کن») ──
// DIAGNOSIS 2026-11-08: the dev server recycles every ~6–14min under the RAM
// doctrine (lane-B self-recycles at RSS 2.4–2.5GB plateau + pulse-timeout
// restarts when the box is squeezed). Every recycle wipes this module's
// in-memory state and cuts in-flight fire-and-forget sends — cards mid-flight
// at process death were lost FOREVER, and the channel mirror looked dead to
// the operator even though the code path was intact (proven live on a fresh
// boot: a CREATED card reached @mytradeneo in 5s; the losses all sat inside
// restart windows). FIX — never lose a card to a process death:
//   • SignalEvent rows are the natural outbox: fireEvent writes the row
//     BEFORE relaying, so every card has a durable receipt in SQLite.
//   • A persisted cursor (EngineSetting telegram.relayCursor) + a 90s sweeper
//     re-deliver every RELAYABLE event the cursor has not confirmed — across
//     restarts, which is exactly the window the operator was losing.
//   • The cursor advances ONLY on confirmed delivery (operator send ok AND
//     channel mirror ok-or-unconfigured) → at-least-once, never silent loss.
//   • A compare-and-swap lease (telegram.relayLease, 25s TTL) keeps the
//     multiple per-route module copies of dev mode from double-sweeping; a
//     3-attempt cap stops poison events from wedging the walk (counted
//     honestly in relayHealth.replay).
//   • Non-relatable journal rows (PUMP_RADAR ban etc.) are cursor-skipped so
//     the walk can never stall on a banned type.
// Known tradeoff: a channel-mirror failure after a good operator send makes
// the sweeper re-deliver to BOTH planes (rare + transient) — at-least-once is
// the deliberate contract; per-plane dedup would re-introduce silent loss.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/brand.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:child_process [external] (node:child_process, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:crypto [external] (node:crypto, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$os__$5b$external$5d$__$28$node$3a$os$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:os [external] (node:os, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$image$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/telegram-image.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$art$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/telegram-art.ts [instrumentation] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const TOKEN = process.env.TELEGRAM_BOT_TOKEN ?? "";
const ENV_CHAT = process.env.TELEGRAM_CHAT_ID ?? "";
// v12.8 SIGNAL-CHANNEL MIRROR (operator order 2026-11-06 trace 1a1ae5194b0586d9
// «کارت سیگنال جدید باز شده هم به کانال همزمان ارسال بشه», extended trace
// 1a1ae5ccfa2fba91 «کانال چرخه‌ی کامل عمر سیگنال را نشان دهد») — EVERY relayed
// lifecycle card (CREATED birth · TP1/TP2/TP3 rungs · SL stop · TTL_EXPIRED /
// EARLY_EXIT close · TTL_EXTENDED grant · AFTERLIFE follow-up) is mirrored
// VERBATIM to this channel: same card the operator chat receives. Fire-and-
// forget, never blocks the engine or the operator send; empty/unset = mirror
// dormant. Never echo the value.
// v13.0 CHANNEL-ENV SELF-HEAL (forensic audit 2026-11-10, trace 1a1c76eb…):
// /api/notify reported signalChannel.configured=false for DAYS while manual
// scripts to the same channel succeeded — root cause: the const below bound
// process.env ONCE at module load, and the booting process had NO
// TELEGRAM_SIGNAL_CHANNEL in its environment (.env carried zero such lines).
// The target is now read DYNAMICALLY: process.env first, then a mtime-gated
// .env re-scan (≤30s cadence) so a var added/restored mid-flight self-heals
// without waiting for the next recycle. Never echo the value.
let _sigChanCache = null;
let _sigChanScanAt = 0;
let _sigChanEnvMtime = 0;
function signalChannelEnv() {
    const fromEnv = process.env.TELEGRAM_SIGNAL_CHANNEL ?? "";
    if (fromEnv) {
        _sigChanCache = fromEnv;
        _sigChanScanAt = Date.now();
        return fromEnv;
    }
    const now = Date.now();
    if (_sigChanCache !== null && now - _sigChanScanAt < 30_000) return _sigChanCache;
    _sigChanScanAt = now;
    try {
        const p = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".env");
        const st = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["statSync"])(p);
        if (st.mtimeMs !== _sigChanEnvMtime || _sigChanCache === null) {
            _sigChanEnvMtime = st.mtimeMs;
            const m = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(p, "utf8").match(/^TELEGRAM_SIGNAL_CHANNEL=(.*)$/m);
            _sigChanCache = m ? m[1].trim().replace(/^["']|["']$/g, "") : "";
        }
    } catch  {
        _sigChanCache = _sigChanCache ?? "";
    }
    return _sigChanCache;
}
const CHAT_OVERRIDE_KEY = "telegram.chatId";
const ERR_RING_CAP = 8;
const BANNED_RELAY_TYPES = new Set([
    "PUMP_RADAR"
]);
const RELAYABLE_TYPES = new Set([
    "CREATED",
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "TTL_EXPIRED",
    "TTL_EXTENDED",
    "AFTERLIFE",
    "EARLY_EXIT"
]); // v10.4: + EARLY_EXIT — v8.4 R2/R7 early time-exits are real settle outcomes (7 of the last 8 closes) and were silently dropped from the operator mirror · v10.20: PUMP_RADAR removed (operator ban)
const errRing = [];
let sentCount = 0;
let failCount = 0;
let pumpDumpBlocked = 0; // v10.20 honesty counter — banned pump/dump relays swallowed here
let lastSentAt = null;
let botId = null; // learned once via getMe
let botUsername = null;
let chatOverride = null; // EngineSetting override (wins over env)
let overrideLoaded = false;
let bootLogged = false;
let lastAutoDiscoverSkipLog = 0; // v10.16: dev.log spam throttle (was ~3.5k lines/day)
// v12.0.1 — flood valves
let createdPhotoTimes = []; // CREATED photo sends in the trailing hour
let createdPhotoBudgetSkip = 0;
// v12.7 signal-channel mirror state + its own photo flood valve (≤6/hour, same doctrine)
let chSentCount = 0;
let chFailCount = 0;
let chLastSentAt = null;
let chPhotoTimes = [];
let chLiveLogged = false;
let ttlGrantRelaySeen = new Map(); // signalId → last relayed grant number
// v12.9 outbox-cursor state (restart-proof delivery)
const RELAY_CURSOR_KEY = "telegram.relayCursor"; // EngineSetting row: {at,id,by} — last confirmed-delivered SignalEvent
const RELAY_LEASE_KEY = "telegram.relayLease"; // EngineSetting row: {owner,until} — sweeper CAS lease
const REPLAY_GRACE_MS = 10_000; // live path owns the freshest events; the sweeper only walks older ones
const REPLAY_SWEEP_MS = 90_000; // sweeper cadence
const REPLAY_MAX_BATCH = 12; // events per sweep pass
const REPLAY_MAX_ATTEMPTS = 3; // poison-event cap — never wedge the walk
const REPLAY_CATCHUP_CAP_MS = 6 * 3_600_000; // bounded catch-up after a long cursor gap
const replayInstanceId = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["randomUUID"])(); // identity for the CAS lease (per module copy)
let replayScheduled = false;
let replaySent = 0;
let replayFails = 0;
let replaySkipped = 0;
let lastReplayAt = null;
let relayCursorMirror = null; // sync-readable mirror for relayHealth
const replayAttempts = new Map(); // eventId → failed delivery attempts
function pushErr(msg) {
    errRing.unshift(`${new Date().toISOString().slice(11, 19)}Z ${msg}`);
    if (errRing.length > ERR_RING_CAP) errRing.pop();
}
function relayArmed() {
    return TOKEN.length > 0;
}
function relayHealth() {
    const chat = chatOverride ?? ENV_CHAT;
    const chan = signalChannelEnv(); // v13.0 dynamic read — health must reflect the LIVE env, not boot-time luck
    return {
        armed: relayArmed(),
        tokenValid: botId !== null ? true : null,
        botUsername,
        chatId: chat ? `${chat.slice(0, 3)}***${chat.slice(-2)}` : null,
        chatResolved: chat.length > 0 && botId !== null && chat !== String(botId),
        chatSource: chatOverride ? "discovered" : ENV_CHAT ? "env" : "none",
        sent: sentCount,
        failed: failCount,
        lastSentAt,
        lastErrors: [
            ...errRing
        ],
        pumpDumpBlocked,
        animSent,
        animFails,
        createdPhotoBudgetSkip,
        signalChannel: {
            configured: chan.length > 0,
            target: chan ? `${chan.slice(0, 1)}***${chan.slice(-4)}` : null,
            sent: chSentCount,
            failed: chFailCount,
            lastSentAt: chLastSentAt
        },
        replay: {
            cursorAt: relayCursorMirror?.at ?? null,
            sent: replaySent,
            fails: replayFails,
            skipped: replaySkipped,
            lastSweepAt: lastReplayAt
        }
    };
}
/** Load the persisted chat override (EngineSetting telegram.chatId) once.
 * op-audit-20260908: must run BEFORE the boot log — the first boot log used to
 * print "DORMANT · TELEGRAM_CHAT_ID unset" even when the chat id was already
 * persisted, because ensureAutoDiscover→getMe logged before resolveChat ever
 * loaded the override. One DB read, once per module instance. */ async function loadOverride() {
    if (overrideLoaded) return;
    overrideLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: CHAT_OVERRIDE_KEY
            }
        });
        if (row?.value) chatOverride = row.value;
    } catch  {}
}
async function ensureBotIdentity() {
    if (botId !== null || !TOKEN) return;
    await loadOverride(); // truthful boot log — persisted chat counts as resolved
    try {
        const ctrl = new AbortController();
        const t = setTimeout(()=>ctrl.abort(), 4500);
        const res = await fetch(`https://api.telegram.org/bot${TOKEN}/getMe`, {
            signal: ctrl.signal,
            cache: "no-store"
        });
        clearTimeout(t);
        const json = await res.json();
        if (json.ok && json.result) {
            botId = json.result.id;
            botUsername = json.result.username ?? null;
            if (!bootLogged) {
                bootLogged = true;
                const chat = chatOverride ?? ENV_CHAT;
                const selfRefused = chat === String(botId);
                const chan = signalChannelEnv(); // v13.0 dynamic
                console.log(`[NOTIFY] telegram relay ${selfRefused ? "ARMED (chat PENDING)" : chat ? "ARMED" : "DORMANT (no chat)"} — bot @${botUsername} (#${botId})${selfRefused ? ` · TELEGRAM_CHAT_ID equals the bot's own id — Telegram rejects bot→bot sends; waiting for discoverChat()/override` : chat ? ` · chat ${chat.slice(0, 3)}***${chat.slice(-2)}` : " · TELEGRAM_CHAT_ID unset"}${chan ? ` · signal-channel mirror → ${chan.slice(0, 1)}***${chan.slice(-4)} (full lifecycle)` : ""}`);
            }
        }
    } catch (e) {
        pushErr(`getMe failed: ${e instanceof Error ? e.message : String(e)}`);
    }
}
async function resolveChat() {
    await ensureBotIdentity();
    await loadOverride();
    const chat = chatOverride ?? ENV_CHAT;
    if (!chat || botId === null || chat === String(botId)) return null;
    return chat;
}
async function apiCall(method, body, timeoutMs = 9000) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
    try {
        const res = await fetch(`https://api.telegram.org/bot${TOKEN}/${method}`, {
            method: "POST",
            headers: {
                "content-type": "application/json"
            },
            body: JSON.stringify(body),
            signal: ctrl.signal,
            cache: "no-store"
        });
        const json = await res.json();
        return json.ok ? {
            ok: true,
            result: json.result
        } : {
            ok: false,
            error: json.description ?? `HTTP ${res.status}`
        };
    } catch (e) {
        return {
            ok: false,
            error: e instanceof Error ? e.name === "AbortError" ? `timeout ${timeoutMs}ms` : e.message : String(e)
        };
    } finally{
        clearTimeout(timer);
    }
}
/** Multipart photo upload (sendPhoto) — FormData/Blob are global in Node 18+.
 * v12.0.1: 20s (was 9s — multipart uploads through the starved process/egress
 * pool were aborting into the text fallback), + ONE retry on timeout/5xx. */ async function apiSendPhoto(chat, caption, photo, filename) {
    let last = {
        ok: false,
        error: "unsent"
    };
    for(let attempt = 0; attempt < 2; attempt++){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), 20_000);
        try {
            const isPng = filename.toLowerCase().endsWith(".png");
            const form = new FormData();
            form.append("chat_id", chat);
            form.append("caption", caption.slice(0, 1024));
            form.append("parse_mode", "HTML");
            form.append("photo", new Blob([
                new Uint8Array(photo)
            ], {
                type: isPng ? "image/png" : "image/jpeg"
            }), filename);
            const res = await fetch(`https://api.telegram.org/bot${TOKEN}/sendPhoto`, {
                method: "POST",
                body: form,
                signal: ctrl.signal,
                cache: "no-store"
            });
            const json = await res.json();
            last = json.ok ? {
                ok: true
            } : {
                ok: false,
                error: json.description ?? `HTTP ${res.status}`
            };
        } catch (e) {
            last = {
                ok: false,
                error: e instanceof Error ? e.name === "AbortError" ? "timeout 20000ms" : e.message : String(e)
            };
        } finally{
            clearTimeout(timer);
        }
        if (last.ok) return last;
        if (!(last.error ?? "").includes("timeout") && !/HTTP 5\d\d/.test(last.error ?? "")) return last; // only transient classes retry
        await new Promise((r)=>setTimeout(r, 1200));
    }
    return last;
}
function esc(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
// ── v10.21 ANIMATED OUTCOME CARDS ──────────────────────────────
// TP1/TP2/TP3 (WIN + FULL) cards ship as a 14-frame motion MP4:
// sharp renders each frame with the v10.21 motion layer (diagonal sweep beam
// + sonar pings + headline glow breathing + bottom traveler) → ffmpeg
// (image2pipe → libx264, faststart) → sendAnimation. v10.20's pulse-only
// loop was invisible after H.264 compression (operator: «هیچ موشنی ندارد»)
// — the motion layer is now impossible to miss, and crf 26→23 keeps the
// beam intact. Budget-guarded (max 8/hour + ≥45s gap) so a burst of
// outcomes can never flood the chat; every failure degrades silently to
// the static sendPhoto path. The TEXT is always the payload — the
// animation is presentation, never a blocker.
const ANIMATED_TYPES = new Set([
    "TP1",
    "TP2",
    "TP3"
]);
const ANIM_FRAMES = 14;
const ANIM_FPS = 12;
const ANIM_MAX_PER_HOUR = 8;
const ANIM_MIN_GAP_MS = 45_000;
let animTimes = [];
let animSent = 0;
let animFails = 0;
function animBudgetOk() {
    const now = Date.now();
    animTimes = animTimes.filter((t)=>now - t < 3_600_000);
    if (animTimes.length > 0 && now - animTimes[animTimes.length - 1] < ANIM_MIN_GAP_MS) return false;
    return animTimes.length < ANIM_MAX_PER_HOUR;
}
async function renderAnimFrames(spec) {
    const frames = [];
    for(let i = 0; i < ANIM_FRAMES; i++){
        const phase = i / ANIM_FRAMES;
        const pulse = 0.5 - 0.5 * Math.cos(2 * Math.PI * phase); // smooth 0→1→0 loop
        frames.push(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$art$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["renderSignalBannerV2"])({
            ...spec,
            pulse,
            phase
        }));
    }
    return frames;
}
/** 12 PNG frames in → H.264 MP4 out (≤20s hard kill). null on any failure —
 * the static photo path takes over, the alert never waits. NOTE: the MP4
 * muxer cannot write to a pipe ("does not support non seekable output") so
 * the encode lands in a transient temp file, is read back and unlinked. */ function encodeAnimMp4(frames) {
    return new Promise((resolve)=>{
        const tmpPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$os__$5b$external$5d$__$28$node$3a$os$2c$__cjs$29$__["tmpdir"])(), `nexus-anim-${process.pid}-${Date.now()}.mp4`);
        let child;
        try {
            child = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__["spawn"])("ffmpeg", [
                "-hide_banner",
                "-loglevel",
                "error",
                "-y",
                "-f",
                "image2pipe",
                "-framerate",
                String(ANIM_FPS),
                "-i",
                "-",
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "23",
                "-pix_fmt",
                "yuv420p",
                "-movflags",
                "+faststart",
                tmpPath
            ], {
                stdio: [
                    "pipe",
                    "ignore",
                    "pipe"
                ]
            });
        } catch  {
            resolve(null);
            return;
        }
        let errTail = "";
        let done = false;
        const finish = (v)=>{
            if (!done) {
                done = true;
                void __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].unlink(tmpPath).catch(()=>undefined);
                resolve(v);
            }
        };
        const killer = setTimeout(()=>{
            child.kill("SIGKILL");
            finish(null);
        }, 20_000);
        child.stderr?.on("data", (c)=>{
            errTail = (errTail + c.toString()).slice(-300);
        });
        child.on("error", ()=>{
            clearTimeout(killer);
            finish(null);
        });
        child.on("close", (code)=>{
            clearTimeout(killer);
            if (code !== 0) {
                if (errTail) console.error(`[NOTIFY] anim encode failed (code ${code}): ${errTail.trim().split("\n").pop()}`);
                finish(null);
                return;
            }
            __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(tmpPath).then((buf)=>finish(buf.length > 1024 ? buf : null)).catch(()=>finish(null));
        });
        void (async ()=>{
            try {
                for (const f of frames){
                    if (done) break;
                    if (!child.stdin.write(f)) await new Promise((r)=>child.stdin.once("drain", ()=>r()));
                }
                child.stdin.end();
            } catch  {
                child.kill("SIGKILL");
            }
        })();
    });
}
/** Multipart sendAnimation — mirrors apiSendPhoto (FormData/Blob global). */ async function apiSendAnimation(chat, caption, mp4, filename) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), 25_000); // v12.0.1: was 12s — MP4 uploads need headroom under memory pressure
    try {
        const form = new FormData();
        form.append("chat_id", chat);
        form.append("caption", caption.slice(0, 1024));
        form.append("parse_mode", "HTML");
        form.append("width", "1280");
        form.append("height", "720");
        form.append("animation", new Blob([
            new Uint8Array(mp4)
        ], {
            type: "video/mp4"
        }), filename);
        const res = await fetch(`https://api.telegram.org/bot${TOKEN}/sendAnimation`, {
            method: "POST",
            body: form,
            signal: ctrl.signal,
            cache: "no-store"
        });
        const json = await res.json();
        return json.ok ? {
            ok: true
        } : {
            ok: false,
            error: json.description ?? `HTTP ${res.status}`
        };
    } catch (e) {
        return {
            ok: false,
            error: e instanceof Error ? e.name === "AbortError" ? "timeout 25000ms" : e.message : String(e)
        };
    } finally{
        clearTimeout(timer);
    }
}
function fmtPrice(p) {
    return p >= 100 ? p.toFixed(2) : p.toFixed(p >= 1 ? 4 : 6);
}
const ART_FILES = {
    WIN: "WIN.jpg",
    STOP: "STOP.jpg",
    EXPIRED: "EXPIRED.jpg",
    NEW: "NEW.jpg",
    SHORT: "SHORT.jpg",
    TTL_EXT: "TTL.jpg",
    FULL: "FULL.jpg",
    AFTERLIFE: "AFTERLIFE.jpg"
};
const artCache = new Map();
async function loadOperatorArt(kind) {
    if (artCache.has(kind)) return artCache.get(kind) ?? null;
    try {
        const buf = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), "assets", "telegram", ART_FILES[kind]));
        artCache.set(kind, buf);
        return buf;
    } catch  {
        artCache.set(kind, null);
        return null;
    }
}
const HEADLINE = {
    CREATED: {
        emoji: "🚀",
        title: "NEW SIGNAL DEPLOYED"
    },
    TP1: {
        emoji: "💰",
        title: "TP1 HIT — 50% BOOKED"
    },
    TP2: {
        emoji: "💰💰",
        title: "TP2 HIT — 80% BOOKED"
    },
    TP3: {
        emoji: "🏆",
        title: "FULL LADDER — TP3 CAPTURED"
    },
    SL: {
        emoji: "🛑",
        title: "STOPPED OUT"
    },
    TTL_EXPIRED: {
        emoji: "⏰",
        title: "SIGNAL EXPIRED"
    },
    EARLY_EXIT: {
        emoji: "🚪",
        title: "EARLY TIME-EXIT"
    },
    TTL_EXTENDED: {
        emoji: "⏳",
        title: "TTL EXTENDED"
    },
    AFTERLIFE: {
        emoji: "🔮",
        title: "EXPIRED FOLLOW-UP"
    },
    // v9.0 PUMP/DUMP RADAR — flow tracking declarations + resolutions + unlock
    PUMP_RADAR: {
        emoji: "📡",
        title: "PUMP/DUMP RADAR"
    }
};
const BANNER_STATUS = {
    CREATED: "NEW",
    TP1: "WIN",
    TP2: "WIN",
    TP3: "FULL",
    SL: "STOP",
    TTL_EXPIRED: "EXPIRED",
    TTL_EXTENDED: "TTL_EXT",
    AFTERLIFE: "AFTERLIFE",
    EARLY_EXIT: "EXPIRED"
};
/** Tehran wall-clock stamp for artwork corners — presentation only. */ function tehranStamp() {
    return `${new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Tehran",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    }).format(new Date()).replace(",", "")} TEHRAN`;
}
/** The tidy line-by-line HTML body shared by live cards and sample proofs. */ function composeSignalText(type, sig, engineMessage) {
    const head = HEADLINE[type] ?? {
        emoji: "📡",
        title: type
    };
    const dirEmoji = sig.direction === "LONG" ? "🟢 LONG" : "🔴 SHORT";
    const serial = `NX-${String(sig.serial).padStart(4, "0")}`;
    const pnl = sig.pnlPercent ?? 0;
    const pnlLine = `${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}% NET`;
    const reached = sig.reachedTp ?? 0;
    const lines = [
        `${head.emoji} <b>${esc(head.title)}</b>`,
        `${dirEmoji} · <b>${esc(sig.symbol)}</b> · <i>${esc(sig.strategy)}${sig.timeframe ? ` (${esc(sig.timeframe)})` : ""}</i>`,
        "",
        `🎯 TP1: <code>${fmtPrice(sig.tp1)}</code>   💰 TP2: <code>${fmtPrice(sig.tp2)}</code>   🏆 TP3: <code>${fmtPrice(sig.tp3)}</code>`,
        `🛑 Stop: <code>${fmtPrice(sig.stopLoss)}</code>   📍 Entry: <code>${fmtPrice(sig.entryPrice)}</code>`,
        "",
        `⚡ Leverage: <b>${sig.leverage}x</b>   💵 Margin: <b>$${sig.marginUsd.toFixed(0)}</b>   📐 R:R <b>1:${sig.riskReward.toFixed(1)}</b>`,
        `📊 Conviction: <b>${sig.confidence}%</b>   ⏳ TTL: <b>${sig.ttlMinutes}m</b>${sig.ttlExtensions ? ` (+${sig.ttlExtensions} ext)` : ""}`
    ];
    if (type !== "CREATED") {
        lines.push(`💵 Result: <b>${pnl >= 0 ? "✅" : "❌"} ${esc(pnlLine)}</b>   🪜 Ladder: <b>${reached}/3</b>`);
    }
    lines.push("", `<blockquote>💬 ${esc(engineMessage)}</blockquote>`);
    lines.push(`<i>🤖 ${esc(serial)} · FLOWRADAR-NEO AI live engine</i>`);
    return lines.join("\n");
}
async function buildCard(type, symbol, engineMessage, signalId) {
    const head = HEADLINE[type] ?? {
        emoji: "📡",
        title: type
    };
    const sig = signalId ? await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findUnique({
        where: {
            id: signalId
        }
    }).catch(()=>null) : null;
    if (!sig) {
        // honest fallback — engine line only
        return {
            text: `${head.emoji} <b>${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["APP_NAME"]} — ${esc(head.title)}</b>\n${symbol ? `📊 <b>${esc(symbol)}</b>\n` : ""}\n<blockquote>${esc(engineMessage)}</blockquote>`
        };
    }
    const text = composeSignalText(type, sig, engineMessage);
    const banner = BANNER_STATUS[type];
    if (!banner) return {
        text
    };
    // CREATED cards are direction-aware: the red bear artwork ships for SHORT
    // deployments, the rocket/bull for LONG.
    const kind = type === "CREATED" && sig.direction === "SHORT" ? "SHORT" : banner;
    const serial = `NX-${String(sig.serial).padStart(4, "0")}`;
    const pnl = sig.pnlPercent ?? 0;
    const pnlLine = `${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}% NET`;
    const reached = sig.reachedTp ?? 0;
    const line2 = type === "SL" ? `RISK CONTAINED · LADDER ${reached}/3` : type === "TTL_EXPIRED" ? `TTL ${sig.ttlMinutes}M ELAPSED · LADDER ${reached}/3` : type === "EARLY_EXIT" ? `EARLY CUT (R2/R7) · LADDER ${reached}/3` : type === "TTL_EXTENDED" ? `+${sig.ttlExtensions} EXT · STILL LIVE` : type === "AFTERLIFE" ? `POST-EXPIRY ${(sig.afterlife ?? "TRACKING").replace(/_/g, " ")} · MFE ${(sig.maxPostPnlPercent ?? 0) >= 0 ? "+" : ""}${(sig.maxPostPnlPercent ?? 0).toFixed(1)}%` : type === "CREATED" ? `ENTRY ${fmtPrice(sig.entryPrice)} · RR 1:${sig.riskReward.toFixed(1)}` : `LADDER ${reached}/3 BANKED · RR 1:${sig.riskReward.toFixed(1)}`;
    const spec = {
        status: kind,
        title: `${sig.symbol} ${sig.direction}`,
        line1: `${serial} · ${pnlLine}`,
        line2,
        ts: tehranStamp(),
        // v10.20 PRICE LADDER — structural anatomy from the real row (SL/ENTRY/
        // TP1-3, banked rungs gold). ladderStrip self-guards: inverted/crossed
        // rows (qualityFlag INVERTED_STOP legacy) render no ladder, never a
        // redrawn "fixed" one. No live MARK on artwork — honesty doctrine.
        ladder: {
            direction: sig.direction === "SHORT" ? "SHORT" : "LONG",
            entry: sig.entryPrice,
            tp1: sig.tp1,
            tp2: sig.tp2,
            tp3: sig.tp3,
            sl: sig.stopLoss,
            reachedTp: sig.reachedTp ?? 0
        }
    };
    // v8.1: professional composite (AI art + coin logo + live data) first; the
    // operator JPG set and the pixel-font banner remain as fallbacks.
    try {
        const photo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$art$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["renderSignalBannerV2"])(spec);
        return {
            text,
            photo,
            photoName: `${kind.toLowerCase()}-${serial}.png`,
            bannerSpec: spec
        };
    } catch  {}
    const art = await loadOperatorArt(kind);
    if (art) return {
        text,
        photo: art,
        photoName: ART_FILES[kind]
    };
    return {
        text,
        photo: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$image$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["renderStatusBanner"])(spec),
        photoName: `${kind.toLowerCase()}-${serial}.png`
    };
}
// ── v12.8 SIGNAL-CHANNEL MIRROR (operator orders 2026-11-06, traces
// 1a1ae5194b0586d9 + 1a1ae5ccfa2fba91) ──
// FULL-LIFECYCLE cards ride to the public signal channel VERBATIM — the exact
// final card the operator chat received (post flood-valve/caption-compaction),
// photo banner + caption or the text fallback. Animated operator sends (TP
// MP4s) mirror as their static PNG — presentation differs, payload identical,
// and the channel never burns the animation budget. Fire-and-forget: failures
// are counted + ringed and NEVER touch the operator send or the engine hot
// path. Own photo flood valve (≤6/hour, overflow → same card as text) mirrors
// operator doctrine.
async function mirrorCardToChannel(card) {
    const chan = signalChannelEnv(); // v13.0 dynamic read — never depend on boot-time env luck
    if (!chan) return;
    let out = card;
    if (out.photo) {
        const nowH = Date.now();
        chPhotoTimes = chPhotoTimes.filter((t)=>nowH - t < 3_600_000);
        if (chPhotoTimes.length >= 6) out = {
            text: out.text
        }; // valve overflow → text, still honest
        else chPhotoTimes.push(nowH);
    }
    let r;
    if (out.photo) {
        r = await apiSendPhoto(chan, out.text, out.photo, out.photoName ?? "flowradar-signal.png");
        if (!r.ok) r = await apiCall("sendMessage", {
            chat_id: chan,
            text: out.text.slice(0, 3800),
            parse_mode: "HTML",
            disable_web_page_preview: true
        });
    } else {
        r = await apiCall("sendMessage", {
            chat_id: chan,
            text: out.text.slice(0, 3800),
            parse_mode: "HTML",
            disable_web_page_preview: true
        });
    }
    if (r.ok) {
        chSentCount++;
        chLastSentAt = Date.now();
        if (!chLiveLogged) {
            chLiveLogged = true;
            console.log(`[NOTIFY] signal-channel mirror LIVE → ${chan.slice(0, 1)}***${chan.slice(-4)} (first lifecycle card delivered)`);
        }
    } else {
        chFailCount++;
        pushErr(`channel: ${r.error}`);
        console.error(`[NOTIFY] signal-channel mirror send failed: ${r.error}`);
    }
}
async function readRelaySettingJson(key) {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key
            }
        });
        if (!row?.value) return null;
        return JSON.parse(row.value);
    } catch  {
        return null;
    }
}
/** True if cursor `a` is at-or-after `b` in the (createdAt, id) walk order. */ function cursorAtOrAfter(a, b) {
    if (a.at !== b.at) return a.at > b.at;
    return a.id >= b.id;
}
/** CAS-advance the persisted cursor to `to`. Losing a race is fine — another
 * copy advanced past us, which by walk order means the event was handled. */ async function advanceRelayCursor(to) {
    for(let i = 0; i < 3; i++){
        const cur = await readRelaySettingJson(RELAY_CURSOR_KEY);
        if (cur && cursorAtOrAfter(cur, to)) return true; // already past — another writer won
        if (!cur) {
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.create({
                    data: {
                        key: RELAY_CURSOR_KEY,
                        value: JSON.stringify(to)
                    }
                });
                relayCursorMirror = to;
                return true;
            } catch  {
            /* unique-key race → re-read and CAS on the next iteration */ }
            continue;
        }
        const r = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.updateMany({
            where: {
                key: RELAY_CURSOR_KEY,
                value: JSON.stringify(cur)
            },
            data: {
                value: JSON.stringify(to)
            }
        });
        if (r.count === 1) {
            relayCursorMirror = to;
            return true;
        }
    }
    return false;
}
function scheduleReplaySweep() {
    if (replayScheduled) return;
    replayScheduled = true;
    const first = setTimeout(()=>{
        void sweepReplayOnce().catch(()=>undefined);
    }, 8_000);
    first.unref?.();
    const timer = setInterval(()=>{
        void sweepReplayOnce().catch(()=>undefined);
    }, REPLAY_SWEEP_MS);
    timer.unref?.();
}
/** v12.9 RESTART SWEEPER — walk the SignalEvent outbox from the persisted
 * cursor and re-deliver every card the cursor has not confirmed. This is the
 * fix for the restart-window card losses the operator reported: a card whose
 * fire-and-forget send was cut by a process death still has its durable
 * journal row, so the next live copy sweeps it to the operator chat + channel
 * exactly as if it had been sent live. */ async function sweepReplayOnce() {
    if (!relayArmed()) return;
    const now = Date.now();
    // ── CAS lease: only one module copy sweeps at a time (dev mode compiles
    // several copies of this module — every one of them runs this interval). ──
    const lease = await readRelaySettingJson(RELAY_LEASE_KEY);
    if (lease && lease.until > now && lease.owner !== replayInstanceId) return;
    const leaseStr = JSON.stringify({
        owner: replayInstanceId,
        until: now + 25_000
    });
    const claimed = lease ? (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.updateMany({
        where: {
            key: RELAY_LEASE_KEY,
            value: JSON.stringify(lease)
        },
        data: {
            value: leaseStr
        }
    })).count === 1 : await (async ()=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.create({
                data: {
                    key: RELAY_LEASE_KEY,
                    value: leaseStr
                }
            });
            return true;
        } catch  {
            return false;
        }
    })();
    if (!claimed) return;
    lastReplayAt = now;
    try {
        let cur = await readRelaySettingJson(RELAY_CURSOR_KEY);
        if (!cur) {
            // first deploy: initialize at "now" — never flood the channel with
            // ancient history; from this moment every event is cursor-tracked.
            await advanceRelayCursor({
                at: now,
                id: "",
                by: "init"
            });
            return;
        }
        if (cur.at < now - REPLAY_CATCHUP_CAP_MS) {
            const floorAt = now - REPLAY_CATCHUP_CAP_MS;
            await advanceRelayCursor({
                at: floorAt,
                id: cur.id,
                by: "catchup-cap"
            });
            pushErr(`replay: cursor jumped forward to bound catch-up (${Math.round((cur.at - floorAt) / 60_000)}min skipped)`);
            cur = {
                at: floorAt,
                id: cur.id
            };
        }
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signalEvent.findMany({
            where: {
                AND: [
                    {
                        createdAt: {
                            lt: new Date(now - REPLAY_GRACE_MS)
                        }
                    },
                    {
                        OR: [
                            {
                                createdAt: {
                                    gt: new Date(cur.at)
                                }
                            },
                            ...cur.id ? [
                                {
                                    createdAt: new Date(cur.at),
                                    id: {
                                        gt: cur.id
                                    }
                                }
                            ] : []
                        ]
                    }
                ]
            },
            orderBy: [
                {
                    createdAt: "asc"
                },
                {
                    id: "asc"
                }
            ],
            take: REPLAY_MAX_BATCH,
            select: {
                id: true,
                type: true,
                symbol: true,
                message: true,
                signalId: true,
                createdAt: true
            }
        });
        for (const ev of rows){
            const curNow = {
                at: Number(ev.createdAt),
                id: ev.id,
                by: "sweep"
            };
            if (BANNED_RELAY_TYPES.has(ev.type) || !RELAYABLE_TYPES.has(ev.type)) {
                // non-relatable journal row — the cursor must still walk past it or the
                // whole outbox would stall on a banned type
                replaySkipped++;
                await advanceRelayCursor(curNow);
                continue;
            }
            const attempts = replayAttempts.get(ev.id) ?? 0;
            if (attempts >= REPLAY_MAX_ATTEMPTS) {
                replayFails++;
                replayAttempts.delete(ev.id);
                pushErr(`replay: ${ev.type} ${ev.id.slice(-6)} dropped after ${REPLAY_MAX_ATTEMPTS} failed attempts`);
                await advanceRelayCursor(curNow);
                continue;
            }
            let res;
            try {
                res = await deliverSignalEvent(ev.type, ev.symbol, ev.message, ev.signalId);
            } catch (e) {
                res = {
                    operatorOk: false,
                    channelOk: false,
                    chatPending: false
                };
                pushErr(`replay ${ev.type}: ${e instanceof Error ? e.message : String(e)}`);
            }
            if (res.operatorOk && res.channelOk) {
                replaySent++;
                replayAttempts.delete(ev.id);
                await advanceRelayCursor(curNow);
            } else if (res.chatPending) {
                break; // honest pending state — leave for the next sweep, do not burn attempts
            } else {
                replayFails++;
                replayAttempts.set(ev.id, attempts + 1);
                break; // stop the pass on first failure — strict in-order retry next sweep
            }
        }
    } finally{
    /* lease expires on its own (25s TTL) — no release write needed */ }
}
/** v12.9: the single delivery body — used by BOTH the live fire-and-forget
 * path and the restart sweeper, so a replayed card is byte-identical to the
 * live one. Returns per-plane truth so the cursor only advances on real
 * delivery (at-least-once, never silent loss). */ async function deliverSignalEvent(type, symbol, message, signalId) {
    const chat = await resolveChat();
    if (!chat) return {
        operatorOk: false,
        channelOk: false,
        chatPending: true
    }; // honest pending state — not an error, no doomed send
    // ── v12.0.1 TASK-46 relay policy ──
    // ① RAW-CAL CREATED cards ship their banner again (v10.4 text-only strip
    // removed — the whole book is capture-mode now, so MOST cards went bare).
    // Flood valve: ≤6 CREATED photo posters/hour, overflow → text + counter.
    // ② TTL_EXTENDED grant #1 → full photo card; grants ≥2 → compact one-line
    // text (the hourly-grant spam the operator reported). Mechanics unchanged.
    let rawCalTextOnly = false;
    let ttlGrantNo = 0;
    if (type === "CREATED" && signalId) {
        const sig = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findUnique({
            where: {
                id: signalId
            },
            select: {
                tags: true
            }
        }).catch(()=>null);
        if (sig?.tags?.includes("RAW-CAL")) {
            const nowH = Date.now();
            createdPhotoTimes = createdPhotoTimes.filter((t)=>nowH - t < 3_600_000);
            if (createdPhotoTimes.length >= 6) {
                rawCalTextOnly = true; // flood valve — still honest, just lighter
                createdPhotoBudgetSkip++;
            } else createdPhotoTimes.push(nowH);
        }
    }
    if (type === "TTL_EXTENDED" && signalId) {
        const sig = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signal.findUnique({
            where: {
                id: signalId
            },
            select: {
                ttlExtensions: true
            }
        }).catch(()=>null);
        ttlGrantNo = sig?.ttlExtensions ?? 0;
        const seen = ttlGrantRelaySeen.get(signalId);
        if (seen !== undefined && ttlGrantNo <= seen) return {
            operatorOk: true,
            channelOk: true,
            chatPending: false
        }; // defensive: identical grant re-fire → swallow (v12.9: counts as already-delivered for the cursor)
        ttlGrantRelaySeen.set(signalId, ttlGrantNo);
        if (ttlGrantRelaySeen.size > 64) {
            const oldest = [
                ...ttlGrantRelaySeen.entries()
            ].sort((a, b)=>a[1] - b[1])[0];
            if (oldest) ttlGrantRelaySeen.delete(oldest[0]);
        }
    }
    let card;
    try {
        card = await buildCard(type, symbol, message, signalId ?? null);
    } catch  {
        card = {
            text: `📡 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["APP_NAME"]} ${type}${symbol ? ` · ${esc(symbol)}` : ""}\n${esc(message)}`.slice(0, 3800)
        };
    }
    if (rawCalTextOnly) card = {
        text: card.text
    }; // flood-valve overflow → text (v10.4 heritage, now budget-gated)
    // TTL grant #2+: compact one-line text — the operator already got the full
    // card for grant #1; hourly identical art posters were the reported spam.
    if (type === "TTL_EXTENDED" && ttlGrantNo > 1) {
        const sym = symbol ?? "?";
        card = {
            text: `⏳ <b>TTL extended again</b> · ${esc(sym)} — grant #${ttlGrantNo} (same setup still near its rung; full card was grant #1 · dashboard shows the live mark)`
        };
    }
    // v12.0.1 caption safety: Telegram REJECTS photo captions >1024 → the whole
    // image send fails → text fallback (another imageless card). Compact the
    // blockquote to keep the caption under the cap.
    if (card.photo && card.text.length > 1000) {
        const m = card.text.match(/<blockquote>[\s\S]*?<\/blockquote>/);
        if (m) {
            const room = 1000 - (card.text.length - m[0].length);
            if (room > 40) {
                const inner = m[0].slice(12, -14);
                card = {
                    ...card,
                    text: card.text.replace(m[0], `<blockquote>💬 ${inner.slice(0, Math.max(0, room - 30))}…</blockquote>`)
                };
            } else card = {
                ...card,
                text: card.text.replace(m[0], "")
            };
        }
        if (card.text.length > 1000) card = {
            ...card,
            text: card.text.slice(0, 1000)
        };
    }
    let r = null;
    // v10.20 ANIMATED OUTCOME CARDS — TP1/TP2/TP3 first try the 12-frame
    // glow-pulse MP4 (budget-guarded); any miss degrades to the static photo.
    let animated = false;
    if (card.photo && card.bannerSpec && ANIMATED_TYPES.has(type) && animBudgetOk()) {
        try {
            const frames = await renderAnimFrames(card.bannerSpec);
            const mp4 = await encodeAnimMp4(frames);
            if (mp4) {
                const mp4Name = `${(card.photoName ?? "flowradar-signal.png").replace(/\.png$/i, "")}.mp4`;
                const a = await apiSendAnimation(chat, card.text, mp4, mp4Name);
                if (a.ok) {
                    animated = true;
                    animSent++;
                    animTimes.push(Date.now());
                    r = {
                        ok: true
                    };
                } else {
                    animFails++;
                    pushErr(`anim ${type}: ${a.error}`);
                }
            } else {
                animFails++;
            }
        } catch (e) {
            animFails++;
            pushErr(`anim ${type}: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    if (card.photo && !animated) {
        r = await apiSendPhoto(chat, card.text, card.photo, card.photoName ?? "flowradar-signal.png");
        if (!r.ok) {
            // photo failed (size/network) — retry once as plain HTML text so the
            // alert still lands; banner is presentation, the message is the payload
            r = await apiCall("sendMessage", {
                chat_id: chat,
                text: card.text.slice(0, 3800),
                parse_mode: "HTML",
                disable_web_page_preview: true
            });
        }
    } else if (!card.photo && !animated) {
        r = await apiCall("sendMessage", {
            chat_id: chat,
            text: card.text.slice(0, 3800),
            parse_mode: "HTML",
            disable_web_page_preview: true
        });
    }
    const operatorOk = !!(r && r.ok);
    if (operatorOk) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`${type}: ${r?.error ?? "?"}`);
        console.error(`[NOTIFY] telegram relay send failed (${type}): ${r?.error ?? "?"}`);
    }
    let channelOk = true;
    // v12.8 — operator order «کانال چرخه‌ی کامل عمر سیگنال را نشان دهد»:
    // mirror EVERY final card (exactly what the operator chat got) to the
    // public signal channel — birth, rungs, stop, expiry, extension, afterlife.
    // relaySignalEvent's entry gate already restricts this to RELAYABLE_TYPES;
    // NOTE: rides on the operator chat being resolvable (resolved + persisted
    // for weeks) — unresolved-chat pending state skips the mirror too, by
    // design (one health gate).
    if (signalChannelEnv()) {
        try {
            await mirrorCardToChannel(card);
        } catch (e) {
            channelOk = false;
            chFailCount++;
            pushErr(`channel: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    return {
        operatorOk,
        channelOk,
        chatPending: false
    };
}
function relaySignalEvent(type, symbol, message, signalId) {
    // v10.20 PUMP/DUMP BAN (operator mandate) — swallow banned types at the
    // choke point, count honestly, never touch Telegram with them.
    if (BANNED_RELAY_TYPES.has(type)) {
        pumpDumpBlocked++;
        return;
    }
    if (!relayArmed() || !RELAYABLE_TYPES.has(type)) return;
    scheduleReplaySweep(); // v12.9: lazily arm the outbox sweeper on first engine use
    void deliverSignalEvent(type, symbol, message, signalId ?? null).then(async (res)=>{
        if (!res.operatorOk) return; // failed live send → cursor stays → the sweeper retries in order
        try {
            // Advance past the OLDEST matching journal row still after the cursor:
            // identical re-fires create several rows, and the cursor must walk them
            // one by one — never jump over an undelivered sibling.
            const cur = await readRelaySettingJson(RELAY_CURSOR_KEY);
            const newer = cur ? {
                OR: [
                    {
                        createdAt: {
                            gt: new Date(cur.at)
                        }
                    },
                    ...cur.id ? [
                        {
                            createdAt: new Date(cur.at),
                            id: {
                                gt: cur.id
                            }
                        }
                    ] : []
                ]
            } : {};
            const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].signalEvent.findFirst({
                where: {
                    type,
                    signalId: signalId ?? null,
                    ...symbol ? {
                        symbol
                    } : {
                        symbol: null
                    },
                    message,
                    ...newer
                },
                orderBy: {
                    createdAt: "asc"
                },
                select: {
                    id: true,
                    createdAt: true
                }
            });
            if (row) await advanceRelayCursor({
                at: Number(row.createdAt),
                id: row.id,
                by: "live"
            });
        } catch  {
        /* cursor is best-effort on the live path; the sweeper is the backstop */ }
    }).catch(()=>undefined);
}
async function primeRelayState() {
    await resolveChat();
    scheduleReplaySweep(); // v12.9: route-copy priming also arms the outbox sweeper (lease prevents multi-copy double-sweep)
}
async function sendDirect(text) {
    const chat = await resolveChat();
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    if (!chat) {
        if (botId !== null && (chatOverride ?? ENV_CHAT) === String(botId)) {
            return {
                ok: false,
                error: `TELEGRAM_CHAT_ID (${ENV_CHAT}) is the bot's own id — Telegram rejects bot→bot sends. Message the bot once from your account, then run discover.`
            };
        }
        return {
            ok: false,
            error: chatOverride || ENV_CHAT ? "chat unresolved (getMe pending or override pending)" : "TELEGRAM_CHAT_ID unset and no discovered chat yet"
        };
    }
    const r = await apiCall("sendMessage", {
        chat_id: chat,
        text,
        disable_web_page_preview: true
    });
    if (r.ok) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`direct: ${r.error}`);
    }
    return {
        ok: r.ok,
        error: r.error,
        chatId: chat
    };
}
// ── v6.4 DAILY PERFORMANCE REPORT (operator request 2026-09-07) ──────────
// «هر روز ساعت 00:00 یک گزارش کوتاه و مفید از عملکرد روزانه به تلگرام
//  بفرست با این تصویر» — the DAILY.jpg artwork ships as the photo, the
// compiled 24h performance digest rides as the HTML caption. Numbers come
// from the REAL db rows (lib/dailyReport.ts); DAILY.jpg was uploaded by the
// operator and lives in assets/telegram/.
const DAILY_ART = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), "assets", "telegram", "DAILY.jpg");
let dailyArtCache;
async function loadDailyArt() {
    if (dailyArtCache !== undefined) return dailyArtCache;
    try {
        dailyArtCache = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(DAILY_ART);
    } catch  {
        dailyArtCache = null;
    }
    return dailyArtCache;
}
async function sendDailyReport(text, poster, filename = "DAILY.jpg") {
    const chat = await resolveChat();
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant",
        withPhoto: false
    };
    if (!chat) return {
        ok: false,
        error: "chat unresolved — message the bot once, then retry",
        withPhoto: false
    };
    let art = poster ?? null;
    if (!art && filename === "DAILY.jpg") art = await loadDailyArt();
    const r = art ? await apiSendPhoto(chat, text, art, filename) : await apiCall("sendMessage", {
        chat_id: chat,
        text: text.slice(0, 3800),
        parse_mode: "HTML",
        disable_web_page_preview: true
    });
    if (r.ok) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`daily: ${r.error}`);
    }
    return {
        ok: r.ok,
        error: r.error,
        withPhoto: Boolean(art)
    };
}
async function sendPhotoDirect(caption, photo, filename = "preview.jpg") {
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    const chat = await resolveChat();
    if (!chat) return {
        ok: false,
        error: "chat unresolved — message the bot once, then retry"
    };
    const r = await apiSendPhoto(chat, caption, photo, filename);
    if (r.ok) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`photo-direct: ${r.error}`);
    }
    return r;
}
async function sendAnimationDirect(caption, mp4, filename = "anim.mp4") {
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    const chat = await resolveChat();
    if (!chat) return {
        ok: false,
        error: "chat unresolved — message the bot once, then retry"
    };
    const r = await apiSendAnimation(chat, caption, mp4, filename);
    if (r.ok) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`anim-direct: ${r.error}`);
    }
    return r;
}
async function sendSampleCards() {
    const chat = await resolveChat();
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    if (!chat) return {
        ok: false,
        error: "chat unresolved — message the bot once, then retry"
    };
    const mk = (over)=>({
            id: "sample",
            createdAt: new Date(),
            updatedAt: new Date(),
            closedAt: new Date(),
            symbol: "BTCUSDT",
            direction: "LONG",
            entryPrice: 65000,
            entryZoneLow: 64948,
            entryZoneHigh: 65052,
            tp1: 66000,
            tp2: 67500,
            tp3: 69000,
            stopLoss: 64000,
            leverage: 10,
            marginUsd: 12,
            confidence: 78,
            riskReward: 2.8,
            timeframe: "1h",
            strategy: "AI-SWING",
            status: "TP2",
            analysis: "",
            tags: "high-conviction,FLOW-CONFIRM,REGIME-TREND-UP",
            engine: "SAMPLE",
            serial: 0,
            factorsJson: null,
            flowJson: null,
            ttlMinutes: 120,
            expiresAt: new Date(Date.now() + 3600_000),
            pnlPercent: 27.3,
            maxPnlPercent: 31.4,
            feeUsd: 0.11,
            swapUsd: 0.01,
            reachedTp: 2,
            ttlExtensions: 0,
            afterlife: null,
            afterlifeAt: null,
            maxPostPnlPercent: 0,
            operatorNotes: "",
            notesUpdatedAt: null,
            ...over
        });
    const samples = [
        [
            "CREATED",
            mk({
                serial: 1
            }),
            "SAMPLE — new LONG deployment detected by the live engine (card-format proof, not a live signal)"
        ],
        [
            "CREATED",
            mk({
                serial: 2,
                direction: "SHORT",
                symbol: "ETHUSDT",
                strategy: "BREAKOUT",
                timeframe: "15m",
                entryPrice: 3120,
                entryZoneLow: 3118,
                entryZoneHigh: 3122,
                tp1: 3060,
                tp2: 2990,
                tp3: 2900,
                stopLoss: 3180,
                leverage: 8,
                marginUsd: 9.5,
                confidence: 71,
                riskReward: 2.6,
                tags: "confluence,FLOW-NEUTRAL,REGIME-CHOP"
            }),
            "SAMPLE — new SHORT deployment detected by the live engine (card-format proof, not a live signal)"
        ],
        [
            "TP2",
            mk({
                serial: 3,
                pnlPercent: 27.3,
                maxPnlPercent: 31.4,
                feeUsd: 0.11,
                swapUsd: 0.01,
                reachedTp: 2
            }),
            "SAMPLE — TP2 reached — 80% booked, stop trailed to TP1 (card-format proof, not a live signal)"
        ],
        [
            "TP3",
            mk({
                serial: 4,
                symbol: "SOLUSDT",
                strategy: "AI-SWING",
                entryPrice: 184.2,
                entryZoneLow: 183.9,
                entryZoneHigh: 184.5,
                tp1: 191.2,
                tp2: 201.0,
                tp3: 214.0,
                stopLoss: 177.2,
                leverage: 6,
                marginUsd: 8.25,
                confidence: 68,
                riskReward: 3.1,
                pnlPercent: 48.9,
                maxPnlPercent: 52.1,
                reachedTp: 3,
                status: "TP3",
                closedAt: new Date()
            }),
            "SAMPLE — FULL TARGET achieved — ladder 3/3 banked (card-format proof, not a live signal)"
        ],
        [
            "SL",
            mk({
                serial: 5,
                direction: "SHORT",
                symbol: "ETHUSDT",
                strategy: "BREAKOUT",
                timeframe: "15m",
                entryPrice: 3120,
                entryZoneLow: 3118,
                entryZoneHigh: 3122,
                tp1: 3060,
                tp2: 2990,
                tp3: 2900,
                stopLoss: 3180,
                leverage: 8,
                marginUsd: 9.5,
                confidence: 71,
                riskReward: 2.6,
                pnlPercent: -29.8,
                reachedTp: 0,
                status: "SL",
                closedAt: new Date(),
                tags: "confluence,FLOW-NEUTRAL,REGIME-CHOP"
            }),
            "SAMPLE — stopped @ 3180 — risk contained (card-format proof, not a live signal)"
        ],
        [
            "TTL_EXTENDED",
            mk({
                serial: 6,
                symbol: "SOLUSDT",
                strategy: "AI-SWING",
                entryPrice: 184.2,
                entryZoneLow: 183.9,
                entryZoneHigh: 184.5,
                tp1: 191.2,
                tp2: 201.0,
                tp3: 214.0,
                stopLoss: 177.2,
                leverage: 6,
                marginUsd: 8.25,
                confidence: 68,
                riskReward: 3.1,
                ttlMinutes: 90,
                ttlExtensions: 1,
                tags: "confluence,FLOW-CONFIRM,REGIME-TREND-UP"
            }),
            "SAMPLE — TTL 90m extended +1 — expiry gate bought more room (card-format proof, not a live signal)"
        ],
        [
            "TTL_EXPIRED",
            mk({
                serial: 7,
                symbol: "SOLUSDT",
                strategy: "AI-SWING",
                entryPrice: 184.2,
                entryZoneLow: 183.9,
                entryZoneHigh: 184.5,
                tp1: 191.2,
                tp2: 201.0,
                tp3: 214.0,
                stopLoss: 177.2,
                leverage: 6,
                marginUsd: 8.25,
                confidence: 68,
                riskReward: 3.1,
                pnlPercent: 11.2,
                reachedTp: 1,
                ttlMinutes: 90,
                ttlExtensions: 1,
                status: "EXPIRED",
                closedAt: new Date(),
                tags: "confluence,FLOW-CONFIRM,REGIME-TREND-UP"
            }),
            "SAMPLE — TTL 90m +1 ext elapsed — auto-closed at mark (card-format proof, not a live signal)"
        ]
    ];
    const results = [];
    for (const [type, sig, msg] of samples){
        try {
            const text = `🧪 <b>SAMPLE — CARD FORMAT PROOF</b>\n\n${composeSignalText(type, sig, msg)}`;
            const banner = BANNER_STATUS[type];
            let r = null;
            const serial = `NX-${String(sig.serial).padStart(4, "0")}`;
            const pnl = sig.pnlPercent ?? 0;
            const photo = banner ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$art$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["renderSignalBannerV2"])({
                status: banner,
                title: `${sig.symbol} ${sig.direction}`,
                line1: `${serial} · ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}% NET`,
                line2: banner === "NEW" || banner === "SHORT" ? `ENTRY ${fmtPrice(sig.entryPrice)} · RR 1:${sig.riskReward.toFixed(1)}` : `LADDER ${sig.reachedTp}/3 · RR 1:${sig.riskReward.toFixed(1)}`,
                ts: tehranStamp(),
                // v10.20: the sample proofs exercise the price-ladder strip too
                ladder: {
                    direction: sig.direction === "SHORT" ? "SHORT" : "LONG",
                    entry: sig.entryPrice,
                    tp1: sig.tp1,
                    tp2: sig.tp2,
                    tp3: sig.tp3,
                    sl: sig.stopLoss,
                    reachedTp: sig.reachedTp ?? 0
                }
            }).catch(()=>null) : null;
            if (photo) r = await apiSendPhoto(chat, text, photo, `sample-${type.toLowerCase()}.png`);
            else {
                const art = banner ? await loadOperatorArt(banner) : null;
                if (art) r = await apiSendPhoto(chat, text, art, ART_FILES[banner]);
                else r = await apiCall("sendMessage", {
                    chat_id: chat,
                    text: text.slice(0, 3800),
                    parse_mode: "HTML",
                    disable_web_page_preview: true
                });
            }
            if (!r.ok) r = await apiCall("sendMessage", {
                chat_id: chat,
                text: text.slice(0, 3800),
                parse_mode: "HTML",
                disable_web_page_preview: true
            });
            results.push(`${type}: ${r.ok ? "OK" : r.error}`);
        } catch (e) {
            results.push(`${type}: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    const okAll = results.every((r)=>r.endsWith("OK"));
    if (okAll) {
        sentCount += samples.length;
        lastSentAt = Date.now();
    } else failCount += results.filter((r)=>!r.endsWith("OK")).length;
    return {
        ok: okAll,
        detail: results.join(" · ")
    };
}
async function sendChannelTest() {
    const chan = signalChannelEnv();
    if (!chan) return {
        ok: false,
        configured: false,
        error: "TELEGRAM_SIGNAL_CHANNEL unset — mirror dormant (self-heal re-scans .env every 30s)"
    };
    const r = await apiCall("sendMessage", {
        chat_id: chan,
        text: `🧪 <b>${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["APP_NAME"]} — SIGNAL-CHANNEL TEST</b>\n${new Date().toISOString()} — mirror plane armed; full lifecycle cards (CREATED/TP1-3/SL/TTL/AFTERLIFE) mirror here.`,
        parse_mode: "HTML",
        disable_web_page_preview: true
    });
    if (r?.ok) {
        chSentCount++;
        chLastSentAt = Date.now();
    } else {
        chFailCount++;
        pushErr(`channeltest: ${r?.error ?? "?"}`);
    }
    return {
        ok: !!r?.ok,
        configured: true,
        error: r && !r.ok ? String(r.error) : undefined
    };
}
// ── v6.2.2 AUTO-DISCOVER (operator round) ─────────────────────────────────
// The operator's credential set shipped TELEGRAM_CHAT_ID === the bot's own id
// (Telegram hard-rejects bot→bot sends), leaving the relay stuck in ARMED
// (chat PENDING) until someone runs discoverChat() at exactly the right
// moment. Instead of babysitting, this loop polls getUpdates every 30s WHILE
// the chat is unresolved; the instant the operator messages the bot once,
// the chat id is learned, persisted, confirmed back, and the loop retires.
let autoDiscoverTimer = null;
function chatResolvedNow() {
    const chat = chatOverride ?? ENV_CHAT;
    return chat.length > 0 && botId !== null && chat !== String(botId);
}
function ensureAutoDiscover() {
    if (autoDiscoverTimer || !relayArmed()) return;
    // v8.3 BRIDGE COEXISTENCE: the chat id is already persisted (EngineSetting
    // telegram.chatId) since v6.2.2 — discovery is DONE. The legacy 30s
    // getUpdates probe now 409-terminates the v8.3 bridge long-poller, so the
    // loop may only start after a DB-backed override check FAILS, and each
    // tick re-checks the override BEFORE touching getUpdates.
    void (async ()=>{
        try {
            await ensureBotIdentity();
            await loadOverride();
        } catch  {
        /* identity check is best-effort */ }
        if (chatResolvedNow()) {
            // v10.16: rate-limit this line to once per 10min — it fired on every call
            // and produced ~3.5k dev.log lines/day (audit: unbounded log growth).
            const now = Date.now();
            if (now - lastAutoDiscoverSkipLog > 600_000) {
                lastAutoDiscoverSkipLog = now;
                console.log("[NOTIFY] auto-discover SKIPPED — chat already resolved (v8.3 bridge owns getUpdates)");
            }
            return;
        }
        const timer = setInterval(()=>{
            if (chatResolvedNow()) {
                clearInterval(timer);
                autoDiscoverTimer = null;
                return;
            }
            void (async ()=>{
                try {
                    await ensureBotIdentity();
                    await loadOverride();
                } catch  {
                /* best-effort */ }
                if (chatResolvedNow()) {
                    clearInterval(timer);
                    autoDiscoverTimer = null;
                    return;
                }
                const r = await discoverChat();
                if (r && r.ok) {
                    clearInterval(timer);
                    autoDiscoverTimer = null;
                    const proof = await sendDirect(`🟢 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["APP_NAME"]} relay ARMED — operator chat discovered and persisted.\nFrom now on CREATED / TP1-3 / SL / TTL_EXPIRED / TTL_EXTENDED / AFTERLIFE events mirror here as structured cards (WIN / STOP / EXPIRED outcomes also arrive as rendered banner images).`);
                    console.log(`[NOTIFY] auto-discover complete — confirmation ${proof.ok ? "delivered" : `NOT delivered (${proof.error ?? "unknown"})`}`);
                }
            // ok:false → "no messages waiting" (benign, keep polling) or a
            // transient network error (silent retry on the next 30s pass).
            })();
        }, 30_000);
        autoDiscoverTimer = timer;
        console.log("[NOTIFY] auto-discover loop started — polling getUpdates every 30s until the operator messages the bot");
    })();
}
async function discoverChat() {
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    await ensureBotIdentity();
    const r = await apiCall("getUpdates", {
        limit: 10,
        timeout: 0
    }, 8000);
    if (!r.ok || !r.result) return {
        ok: false,
        error: r.error ?? "getUpdates returned no payload"
    };
    const withMsg = r.result.filter((u)=>u.message?.chat?.id !== undefined);
    if (withMsg.length === 0) return {
        ok: false,
        error: "no messages waiting — open the bot in Telegram, press START and send any message (e.g. «سلام»), then retry discover"
    };
    const last = withMsg[withMsg.length - 1].message;
    const chatId = String(last.chat.id);
    chatOverride = chatId;
    overrideLoaded = true;
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: CHAT_OVERRIDE_KEY
        },
        create: {
            key: CHAT_OVERRIDE_KEY,
            value: chatId
        },
        update: {
            value: chatId
        }
    });
    console.log(`[NOTIFY] telegram chat DISCOVERED — id ${chatId} (${last.chat.first_name ?? last.chat.username ?? "unknown"}), persisted to ${CHAT_OVERRIDE_KEY}; relay fully ARMED`);
    return {
        ok: true,
        chatId,
        from: last.chat.first_name ?? last.chat.username,
        text: last.text
    };
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__657bae63._.js.map