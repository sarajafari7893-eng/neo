module.exports = [
"[project]/src/lib/liquidations.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLiquidationSnapshot",
    ()=>getLiquidationSnapshot,
    "getLiquidationStatus",
    ()=>getLiquidationStatus,
    "liquidationPressure",
    ()=>liquidationPressure
]);
// ── FlowRadar Neo liquidation feed client (server-only) ──
// Reads mini-services/liq-service (:3010). Honesty contract: when the stream
// is stalled or down we return null — never a fabricated "quiet tape".
const LIQ_URL = process.env.LIQ_SERVICE_URL ?? "http://localhost:3010";
const TIMEOUT_MS = 2500;
const CACHE_TTL = 20_000;
let cache = null;
let inFlight = null;
async function getLiquidationSnapshot() {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.snap;
    if (inFlight) return inFlight;
    inFlight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${LIQ_URL}/liquidations`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (!res.ok) throw new Error(`liq ${res.status}`);
            const snap = await res.json();
            cache = {
                at: Date.now(),
                snap
            };
            return snap;
        } catch  {
            cache = {
                at: Date.now(),
                snap: null
            };
            return null;
        } finally{
            inFlight = null;
        }
    })();
    return inFlight;
}
async function getLiquidationStatus() {
    const snap = await getLiquidationSnapshot();
    if (!snap) return null;
    return {
        online: true,
        ...snap.status
    };
}
async function liquidationPressure(symbol) {
    const snap = await getLiquidationSnapshot();
    if (!snap || snap.status.dataStalled || !snap.status.connected) return null;
    const row = snap.bySymbol[symbol];
    if (!row) return {
        usd10m: 0,
        longsUsd10m: 0,
        shortsUsd10m: 0
    };
    return {
        usd10m: row.usd10m,
        longsUsd10m: row.longsUsd10m,
        shortsUsd10m: row.shortsUsd10m
    };
}
}),
"[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noteSpotHostThrottle",
    ()=>noteSpotHostThrottle,
    "spotHostReady",
    ()=>spotHostReady,
    "spotHostsReady",
    ()=>spotHostsReady,
    "spotLadderJson",
    ()=>spotLadderJson
]);
// ── NEXUS//SIGNALS spot-host gate (v13.2.1 SPOT-BAN-BACKOFF) ────────────────
// Completes the v13.2 SPOT-HOST LADDER: the ladder could DETECT a 418/429
// (fall through to the next rung) but had NO per-host backoff, so every tick
// re-poked the banned host first — wasting weight and keeping ban pressure
// alive. Live evidence 2026-10-25T00:48Z: data-api.binance.vision flapped
// 429/418 at x-mbx-used-weight-1m: 467 with retry-after: 889s while fapi
// served 200 @73ms (separate ban pools per host confirmed).
//
// Contract (read-only, zero data invention):
//   · 418 → host silent for retry-after seconds (capped 15min)
//   · 429 → soft 60s pause (retry-after respected when present)
//   · ladders ask spotHostsReady() and skip mid-ban hosts → traffic
//     auto-redistributes to the healthy rung and slides back on expiry.
//   · globalThis dedupe — Turbopack can instantiate per-route bundles; the
//     engine tick loop and /api routes MUST share one ban map (fbStats pattern).
const CAP_MS = 15 * 60_000;
const g = globalThis;
g.__nexusSpotHostGate ??= {
    bannedUntil: {}
};
const S = g.__nexusSpotHostGate;
function spotHostReady(host, now = Date.now()) {
    return (S.bannedUntil[host] ?? 0) <= now;
}
function spotHostsReady(hosts, now = Date.now()) {
    return hosts.filter((h)=>spotHostReady(h, now));
}
function noteSpotHostThrottle(host, status, headers) {
    const now = Date.now();
    let ms = status === 418 ? CAP_MS : 60_000;
    const ra = Number(headers.get("retry-after"));
    if (Number.isFinite(ra) && ra > 0) ms = Math.min(ra * 1000, CAP_MS);
    const prev = S.bannedUntil[host] ?? 0;
    if (prev < now + 1000) {
        console.warn(`[spot-host-gate] ${host} → ${status} — leg silent ${Math.round(ms / 1000)}s (weight1m=${headers.get("x-mbx-used-weight-1m") ?? "?"})`);
    }
    S.bannedUntil[host] = Math.max(prev, now + ms);
}
async function spotLadderJson(path, hosts, timeoutMs = 8000) {
    for (const host of spotHostsReady(hosts)){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        try {
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                noteSpotHostThrottle(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) continue;
            return await res.json();
        } catch  {
            continue;
        } finally{
            clearTimeout(timer);
        }
    }
    return null;
}
}),
"[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bridgeDepth",
    ()=>bridgeDepth,
    "bridgeKlines",
    ()=>bridgeKlines,
    "bridgeOiHist",
    ()=>bridgeOiHist,
    "bridgeTape",
    ()=>bridgeTape,
    "fapi5mMove",
    ()=>fapi5mMove,
    "futTickerMap",
    ()=>futTickerMap,
    "futTickerRow",
    ()=>futTickerRow,
    "spot5mMove",
    ()=>spot5mMove,
    "spotMirrorDepth",
    ()=>spotMirrorDepth,
    "spotMirrorKlines",
    ()=>spotMirrorKlines,
    "spotMirrorTape",
    ()=>spotMirrorTape
]);
// ── FlowRadar Neo FLOW BRIDGE (server-only, v14.0 BINANCE-ONLY) ──
// Operator mandate (trace 1a185042c872b4f9 — «ردپای OKX/Bybit در کجا وجود
// دارد و با بایننس جایگزین شود»): the v12.2 cross-venue bridge is retired.
// Every ladder is now BINANCE-ONLY, riding the two independent Binance REST
// planes measured live from this egress:
//
//  ① fapi plane — gated (fapi-gate, weight budget, ban ledger), perp-native.
//  ② SPOT-MIRROR plane — the v13.3 spot-host ladder (data-api.binance.vision
//     → api-gcp → api1-4 → api.binance.com) with the shared per-host 418/429
//     gate: SEPARATE ban pool from fapi, SAME kline shape (field-9 taker
//     volume intact), zero fapi weight.
//
// LADDERS (best → last): klines fapi→SPOT-MIRROR · tape fapi→SPOT-MIRROR ·
// OI history fapi (perp-native — no spot equivalent, honest null on ban) ·
// depth fapi→SPOT-MIRROR · batched tickers fapi(composite)→SPOT-MIRROR.
// HONESTY LAWS unchanged: a plane that fails degrades to null — never to
// invented data; every result carries its SOURCE so cards/journals say which
// Binance plane the number came from. crowd/top-trader L/S ratios stay
// Binance-only and honestly null. FLAT-10 engine policy untouched.
//
// Note: 1000X-style perp symbols (1000PEPEUSDT…) have no spot pair — the
// SPOT-MIRROR rung 404s on them and the ladder ends honestly (fapi rung
// serves them whenever the gate is open).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
const TIMEOUT_MS = 6500;
async function jfetch(url, init) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
    try {
        const res = await fetch(url, {
            ...init,
            signal: ctrl.signal,
            cache: "no-store"
        });
        if (!res.ok) return null;
        return await res.json();
    } catch  {
        return null;
    } finally{
        clearTimeout(timer);
    }
}
// ── klines rungs ────────────────────────────────────────────────────────
// ── v13.2 SPOT-HOST LADDER (operator mandate trace 1a1704d407f00dad —
// «از data-api.binance.vision استفاده کن؛ جریان زندهٔ لحظه‌ای باید با بایننس
// باشد»): measured live 2026-10-25 — data-api.binance.vision 32/32 HTTP 200
// p50 57ms while api.binance.com rides 418 ban-storms from this shared egress.
// v13.2.3 (trace 1a170bba02dff781): api1-4 added as mid rungs, api last.
// v14.0: this ladder is now the ONLY fallback plane (Binance-only mandate).
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
// v13.2.1 — per-host 418/429 backoff via the shared spot-host gate: a banned
// rung is SKIPPED (not re-poked every tick) and traffic slides to the healthy
// host until retry-after expires (live evidence: vision 418 @467wt/min while
// jfetch swallowed the status and kept hammering).
async function spotLadderFetch(path) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotLadderJson"])(path, SPOT_HOSTS, TIMEOUT_MS);
}
function binanceKlineRows(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5]),
            takerBuyBase: Number(k[9])
        }));
}
async function spotMirrorKlines(symbol, interval, limit) {
    const spot = await spotLadderFetch(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
    if (!spot || spot.length === 0) return null;
    return binanceKlineRows(spot);
}
async function bridgeKlines(symbol, interval, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.length > 0) return {
        rows: binanceKlineRows(raw),
        source: "BINANCE"
    };
    const spot = await spotMirrorKlines(symbol, interval, limit).catch(()=>null);
    if (spot && spot.length > 0) return {
        rows: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function spotMirrorTape(symbol) {
    const spot = await spotLadderFetch(`/api/v3/trades?symbol=${symbol}&limit=1000`);
    if (!spot || spot.length === 0) return null;
    return spot.map((t)=>({
            price: Number(t.price),
            qty: Number(t.qty),
            quoteQty: Number(t.quoteQty) || Number(t.price) * Number(t.qty),
            isBuyerMaker: t.isBuyerMaker,
            time: t.time
        }));
}
async function bridgeTape(symbol) {
    const agg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (agg && agg.length > 0) {
        return {
            trades: agg.map((t)=>({
                    price: Number(t.p),
                    qty: Number(t.q),
                    quoteQty: Number(t.p) * Number(t.q),
                    isBuyerMaker: t.m,
                    time: t.T
                })),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorTape(symbol).catch(()=>null);
    if (spot && spot.length > 0) return {
        trades: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function bridgeOiHist(symbol, period, limit) {
    const f = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/futures/data/openInterestHist?symbol=${symbol}&period=${period}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (f && f.length > 0) {
        return {
            rows: f.map((h)=>({
                    sumOpenInterest: Number(h.sumOpenInterest),
                    sumOpenInterestValue: Number(h.sumOpenInterestValue),
                    timestamp: h.timestamp
                })),
            source: "BINANCE"
        };
    }
    return null;
}
async function spotMirrorDepth(symbol, limit) {
    const steps = [
        5,
        10,
        20,
        50,
        100,
        500
    ];
    const lv = steps.find((s)=>s >= limit) ?? 500;
    const raw = await spotLadderFetch(`/api/v3/depth?symbol=${symbol}&limit=${lv}`);
    if (!raw || raw.bids.length === 0 || raw.asks.length === 0) return null;
    return {
        bids: raw.bids.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        asks: raw.asks.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        source: "SPOT-MIRROR"
    };
}
async function bridgeDepth(symbol, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/depth?symbol=${symbol}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.bids.length > 0 && raw.asks.length > 0) {
        return {
            bids: raw.bids.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            asks: raw.asks.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorDepth(symbol, limit).catch(()=>null);
    if (spot) return spot;
    return null;
}
// ── batched tickers — funding + mark + 24h board for the WHOLE domain ──────
// v14.0 BINANCE-ONLY composite: ONE gated /fapi/v1/ticker/24hr (weight 40) +
// ONE gated /fapi/v1/premiumIndex batch (weight 10) merged per symbol. On a
// fapi ban the SPOT-MIRROR ticker batch prices the board (mark/funding/OI
// honestly null — spot plane carries no perp derivatives).
const TICKERS_TTL = 15_000;
let tickCache = null;
let tickInFlight = null;
async function futTickerMap() {
    if (tickCache && Date.now() - tickCache.at < TICKERS_TTL) return tickCache.map;
    if (tickInFlight) return tickInFlight;
    tickInFlight = (async ()=>{
        const out = new Map();
        const [board, prem] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/ticker/24hr", {
                priority: "telemetry",
                weight: 40,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/premiumIndex", {
                priority: "telemetry",
                weight: 10,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null)
        ]);
        if (board && board.length > 0) {
            const premMap = new Map((prem ?? []).map((p)=>[
                    p.symbol,
                    p
                ]));
            for (const r of board){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                const pm = premMap.get(r.symbol);
                const mark = Number(pm?.markPrice) || null;
                const funding = Number(pm?.lastFundingRate);
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: mark,
                    fundingRate: Number.isFinite(funding) && pm ? funding : null,
                    nextFundingTime: Number(pm?.nextFundingTime) || null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "BINANCE"
                });
            }
            tickCache = {
                at: Date.now(),
                map: out,
                src: "BINANCE"
            };
            return out;
        }
        // fapi banned — SPOT-MIRROR board (price-only rows, honest nulls on perp fields)
        const spot = await spotLadderFetch("/api/v3/ticker/24hr");
        if (spot && spot.length > 0) {
            for (const r of spot){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: null,
                    fundingRate: null,
                    nextFundingTime: null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "SPOT-MIRROR"
                });
            }
        }
        tickCache = {
            at: Date.now(),
            map: out,
            src: "SPOT-MIRROR"
        };
        return out;
    })();
    try {
        return await tickInFlight;
    } finally{
        tickInFlight = null;
    }
}
async function futTickerRow(symbol) {
    const map = await futTickerMap().catch(()=>new Map());
    const row = map.get(symbol);
    if (!row) return null;
    // v14.0 — OI enrichment: /fapi/v1/openInterest is per-symbol (weight 1);
    // fill it only for rows priced by the fapi plane and only when missing.
    if (row.source === "BINANCE" && row.openInterest === null) {
        const oi = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/openInterest?symbol=${symbol}`, {
            priority: "telemetry",
            timeoutMs: 4000
        }).catch(()=>null);
        const v = Number(oi?.openInterest);
        if (Number.isFinite(v) && v > 0) {
            row.openInterest = v;
            if (row.markPrice) row.openInterestValue = v * row.markPrice;
        }
    }
    return row;
}
async function spot5mMove(symbol) {
    const rows = await spotMirrorKlines(symbol, "5m", 4);
    if (!rows || rows.length < 4) return null;
    const open = rows[0].open;
    const close = rows[rows.length - 1].close;
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
async function fapi5mMove(symbol) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=4`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (!raw || raw.length < 4) return null;
    const open = Number(raw[0][1]);
    const close = Number(raw[raw.length - 1][4]);
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
}),
"[project]/src/lib/core-revert.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCoreRevert",
    ()=>getCoreRevert
]);
// ── NEXUS//SIGNALS v13.0 CORE-REVERT knob (server-only) ──
// Operator mandate 2026-10-24 («پیشنهاد من سیستم به همان وضعیت برگردد و با
// دیتای موجود نقاط ضعف را فیلتر کند») after the W42 performance audit:
//   · v12.7 era (10-21 → 10-23 15:18): 111 signals, WR 60.4%, +$39.74,
//     median event→entry delay 13.2min — the SUCCESSFUL core configuration.
//   · v12.8/v12.9 era (10-23 15:31 → now): confirmation stack (CHASE-EXTREME,
//     FLUSH-EXHAUSTION/KNIFE-CATCH/STOP-FLOOR, SINGLE-VENUE, NO-BINANCE +12,
//     SURROGATE-FLOW cap, MULTI-VENUE clamp, STALE-BAR) DOUBLED the median
//     delay to 27.4min and starved the board behind a 200+ veto wall, while
//     the hard-SL class it targeted kept printing (7× −61.2% on 10-24 alone).
// enabled=true (default) → the v12.8+ hard gates become ADVISORY: they keep
// journaling (gate-journal audit trail preserved for future recalibration)
// but never refuse a deploy — deploy semantics return to the v12.7 core.
// Weaknesses are filtered from EXISTING data instead (STALE-CHASE gate +
// REARM-BRAKE-BE window in engine.ts), not by new blocking regimes.
// enabled=false → exact v12.9 blocking behavior, one EngineSetting flip.
// Cached 30s per process; fail-open to the operator mandate default.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const DEFAULT_CFG = {
    enabled: true
};
const CACHE_MS = 30_000;
const g = globalThis;
async function getCoreRevert() {
    const hit = g.__nexusCoreRevert;
    if (hit && Date.now() - hit.at < CACHE_MS) return hit.val;
    let val = {
        ...DEFAULT_CFG
    };
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "core-revert"
            }
        });
        if (row) {
            const p = JSON.parse(row.value);
            if (typeof p.enabled === "boolean") val = {
                enabled: p.enabled
            };
        }
    } catch  {
    /* fail-open → operator-mandate default (enabled) */ }
    g.__nexusCoreRevert = {
        at: Date.now(),
        val
    };
    return val;
}
}),
"[project]/src/lib/flow.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WHALE_PRINT_MIN_USD",
    ()=>WHALE_PRINT_MIN_USD,
    "detectLiquiditySweep",
    ()=>detectLiquiditySweep,
    "ensureFlow",
    ()=>ensureFlow,
    "fetchFlowMetrics",
    ()=>fetchFlowMetrics,
    "flowCoverageOf",
    ()=>flowCoverageOf,
    "getFlowHistory",
    ()=>getFlowHistory,
    "getFlowSource",
    ()=>getFlowSource,
    "getFlowStatus",
    ()=>getFlowStatus,
    "scoreFlow",
    ()=>scoreFlow
]);
// ── FlowRadar Neo order-flow module (server-only) ──
// Real Binance USDT-M flow metrics: OI delta, taker CVD, crowd L/S, funding.
// scoreFlow → ±25 along candidate direction · OI-notional weighting (v4.5)
// · in-memory per-symbol history ring for sparklines (R17).
// v10.24 Task 34-a: fapi REST now goes through the process-wide fapi-gate
// (weight budget + global ban awareness + single-flight). Telemetry lane —
// sheddable under pressure; every caller is throw/null-tolerant already.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)"); // v13.3 — ch.7-ب: honest fapi-plane health for the surrogate demote
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/core-revert.ts [app-route] (ecmascript)"); // v13.0 CORE-REVERT — operator revert mandate
;
;
;
;
const TIMEOUT_MS = 6500;
const CACHE_TTL = 150_000; // 2.5min
const STALE_GRACE = 600_000; // 10min
/** Decision-relevant metric keys — cvdNetBase is structurally null in the
 *  current pipeline and excluded from coverage on purpose. */ const COVERAGE_KEYS = [
    "oiDelta10m",
    "oiDelta1h",
    "oiValueUsd",
    "cvdNetPctOfVol",
    "takerRatio",
    "takerMean",
    "crowdLongShort",
    "topLongShort",
    "funding8h",
    "cvdUsd60s"
];
function flowCoverageOf(m) {
    return COVERAGE_KEYS.reduce((a, k)=>a + (m[k] != null ? 1 : 0), 0);
}
const BLIND_CACHE_TTL = 20_000; // v12.1: all-null metrics are a STARVATION state,
// v12.2 TASK-52 — venue that fed the last metrics bundle per symbol
const flowSrcMap = new Map();
function getFlowSource(symbol) {
    return flowSrcMap.get(symbol) ?? null;
}
// v12.9 MULTI-VENUE CONSENSUS — per-key 60s cache + in-flight dedupe so the
// second-venue cross-check costs at most ONE fetch per venue per minute per
// symbol on the hot path. Fail-soft: any throw → cached null → consensus
// skips (never blocks, never invents).
const consensusCache = new Map();
const consensusInFlight = new Map();
async function cachedConsensusVal(key, ttlMs, fn) {
    const hit = consensusCache.get(key);
    if (hit && Date.now() - hit.at < ttlMs) return hit.val ?? null;
    const inflight = consensusInFlight.get(key);
    if (inflight) return await inflight ?? null;
    const p = (async ()=>{
        let val = null;
        try {
            val = await fn();
        } catch  {
            val = null;
        }
        consensusCache.set(key, {
            at: Date.now(),
            val
        });
        if (consensusCache.size > 800) {
            const oldest = consensusCache.keys().next().value;
            if (oldest) consensusCache.delete(oldest);
        }
        return val;
    })().finally(()=>consensusInFlight.delete(key));
    consensusInFlight.set(key, p);
    return await p ?? null;
}
const WHALE_PRINT_MIN_USD = 250_000;
const flowCache = new Map();
const flowInFlight = new Map();
// per-symbol history ring: 1 point per FRESH sample, cap 60 (~2.5h)
const HISTORY_CAP = 60;
const flowHistory = new Map();
function getFlowStatus() {
    let lastOkAt = null;
    let lastError = null;
    let covered = 0;
    for (const [, e] of flowCache){
        if (Date.now() - e.at < STALE_GRACE) covered++;
        lastOkAt = Math.max(lastOkAt ?? 0, e.at) || null;
    }
    return {
        covered,
        lastOkAt,
        lastError
    };
}
async function fapi(path) {
    const v = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    });
    if (v === null) throw new Error(`fapi ${path} → unavailable`); // preserved throw semantics — allSettled callers treat it as partial absence
    return v;
}
async function fetchFlowMetrics(symbol) {
    const cached = flowCache.get(symbol);
    const cachedTtl = cached?.blind ? BLIND_CACHE_TTL : CACHE_TTL;
    if (cached && Date.now() - cached.at < cachedTtl) return cached.metrics;
    if (cached && Date.now() - cached.at < STALE_GRACE && flowInFlight.has(symbol)) return cached.metrics;
    const existing = flowInFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            const base = symbol.replace("USDT", "");
            const [oiHist, takerLS, crowd, premium, aggTrades, topPos] = await Promise.allSettled([
                fapi(`/futures/data/openInterestHist?symbol=${symbol}&period=5m&limit=13`),
                fapi(`/futures/data/takerlongshortRatio?symbol=${symbol}&period=5m&limit=13`),
                fapi(`/futures/data/globalLongShortAccountRatio?symbol=${symbol}&period=5m&limit=2`),
                fapi(`/fapi/v1/premiumIndex?symbol=${symbol}`),
                fapi(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`),
                fapi(`/futures/data/topLongShortPositionRatio?symbol=${symbol}&period=5m&limit=2`)
            ]);
            // v12.2 TASK-52 — FLOW BRIDGE: when a fapi lane starves (ban/pool silence),
            // recover the recoverable lanes over the bridge instead of sliding into
            // blindness. Honest sourcing: the bundle records the venue that fed it.
            let flowSrc = "BINANCE";
            const srcNote = (s)=>{
                if (flowSrc === "BINANCE") flowSrc = s;
                else if (flowSrc !== s) flowSrc = "MIXED";
            };
            let oi = oiHist.status === "fulfilled" ? oiHist.value : [];
            if (oi.length === 0) {
                const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeOiHist"])(symbol, "5m", 13).catch(()=>null);
                if (b && b.rows.length > 0) {
                    oi = b.rows.map((r)=>({
                            symbol,
                            sumOpenInterest: String(r.sumOpenInterest),
                            sumOpenInterestValue: String(r.sumOpenInterestValue ?? 0),
                            timestamp: r.timestamp
                        }));
                    srcNote(b.source);
                // v14.0 — OI history is fapi-only (perp-native): rows carry the real
                // notional from Binance. No cross-venue rung exists anymore.
                }
            }
            const taker = takerLS.status === "fulfilled" ? takerLS.value : [];
            const crowdArr = crowd.status === "fulfilled" ? crowd.value : [];
            // crowd/top-trader L/S ratios have NO public equivalent on any other
            // venue — during a fapi starvation they stay null (honest absence).
            let prem = premium.status === "fulfilled" ? premium.value : null;
            if (!prem) {
                // v14.0 — premiumIndex/marketPrice fallback via the Binance composite
                // ticker leg (fapi merged board; funding null on a spot-plane board →
                // the guard below fails honestly when fapi is banned).
                const t = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerRow"])(symbol).catch(()=>null);
                if (t && t.fundingRate !== null) {
                    prem = {
                        lastFundingRate: String(t.fundingRate),
                        markPrice: String(t.markPrice ?? t.lastPrice)
                    };
                    srcNote("BINANCE");
                }
            }
            let oiDelta10m = null;
            let oiDelta1h = null;
            let oiValueUsd = null;
            if (oi.length >= 3) {
                const last = oi[oi.length - 1];
                const first = oi[0];
                const cur = Number(last.sumOpenInterest);
                oiValueUsd = Number(last.sumOpenInterestValue);
                oiDelta10m = first ? (cur - Number(oi[Math.max(0, oi.length - 3)].sumOpenInterest)) / Number(oi[Math.max(0, oi.length - 3)].sumOpenInterest) * 100 : null;
                oiDelta1h = Number(first.sumOpenInterest) > 0 ? (cur - Number(first.sumOpenInterest)) / Number(first.sumOpenInterest) * 100 : null;
            }
            // CVD proxy from taker ratio series: (ratio−1) averaged, weighted by recency
            let takerMean = null;
            let takerRatio = null;
            if (taker.length >= 2) {
                const ratios = taker.map((t)=>Number(t.buySellRatio));
                takerRatio = ratios[ratios.length - 1];
                takerMean = ratios.reduce((a, b)=>a + b, 0) / ratios.length;
            }
            const crowdLongShort = crowdArr.length > 0 ? Number(crowdArr[crowdArr.length - 1].longShortRatio) : null;
            const crowdLongPct = crowdArr.length > 0 ? Number(crowdArr[crowdArr.length - 1].longAccount) * 100 : null;
            const topPosArr = topPos.status === "fulfilled" ? topPos.value : [];
            const topLongShort = topPosArr.length > 0 ? Number(topPosArr[topPosArr.length - 1].longShortRatio) : null;
            const funding8h = prem ? Number(prem.lastFundingRate) * 100 : null;
            // v6.7: real USD taker flow + whale prints from the same aggTrades pull
            // (trades ≤1000 ≈ last minutes on liquid symbols; windows clipped by T).
            // v12.2 TASK-52 (v14.0): tape ladder — fapi aggTrades → SPOT-MIRROR trades →
            // SPOT-MIRROR trades (spot = last resort: spot flow ≠ perp flow).
            let agg = aggTrades.status === "fulfilled" ? aggTrades.value : [];
            if (agg.length === 0) {
                const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeTape"])(symbol).catch(()=>null);
                if (b && b.trades.length > 0) {
                    agg = b.trades.map((t)=>({
                            p: t.price,
                            q: t.qty,
                            T: t.time,
                            m: t.isBuyerMaker
                        }));
                    srcNote(b.source);
                }
            }
            const t60 = Date.now() - 60_000;
            const t300 = Date.now() - 300_000;
            let buy60 = 0;
            let sell60 = 0;
            const wp = {
                count: 0,
                totalUsd: 0,
                maxUsd: 0,
                buyUsd: 0,
                sellUsd: 0
            };
            for (const t of agg){
                const usd = t.p * t.q;
                if (t.T >= t60) {
                    if (t.m) sell60 += usd;
                    else buy60 += usd;
                }
                if (t.T >= t300 && usd >= WHALE_PRINT_MIN_USD) {
                    wp.count++;
                    wp.totalUsd += usd;
                    if (usd > wp.maxUsd) wp.maxUsd = usd;
                    if (t.m) wp.sellUsd += usd;
                    else wp.buyUsd += usd;
                }
            }
            const cvdUsd60s = agg.length > 0 ? Math.round(buy60 - sell60) : null;
            const whalePrint5m = wp.count > 0 ? {
                count: wp.count,
                totalUsd: Math.round(wp.totalUsd),
                maxUsd: Math.round(wp.maxUsd),
                buyUsd: Math.round(wp.buyUsd),
                sellUsd: Math.round(wp.sellUsd)
            } : null;
            // v12.2 TASK-52: when the fapi taker-ratio series is absent but a REAL
            // tape exists (bridge), the net-buy % of volume is measured from that
            // same tape — window-capped at 10min (a 1000-trade slice spanning hours
            // on an illiquid symbol is a stale read, not a flow read).
            const winStart = agg.length > 0 ? agg[0].T : 0;
            let buyWin = 0;
            let sellWin = 0;
            for (const t of agg){
                const usd = t.p * t.q;
                if (t.m) sellWin += usd;
                else buyWin += usd;
            }
            const cvdFromTape = agg.length > 0 && buyWin + sellWin > 0 && winStart > 0 && Date.now() - winStart <= 600_000 ? (buyWin - sellWin) / (buyWin + sellWin) * 100 : null;
            const cvdNetPctOfVol = takerMean !== null ? (takerMean - 1) * 100 : cvdFromTape; // % of taker volume net buys
            const metrics = {
                oiDelta10m: oiDelta10m === null ? null : Number(oiDelta10m.toFixed(3)),
                oiDelta1h: oiDelta1h === null ? null : Number(oiDelta1h.toFixed(3)),
                oiValueUsd,
                cvdNetBase: null,
                cvdNetPctOfVol: cvdNetPctOfVol === null ? null : Number(cvdNetPctOfVol.toFixed(3)),
                takerRatio,
                takerMean,
                crowdLongShort,
                crowdLongPct,
                topLongShort: topLongShort === null ? null : Number(topLongShort.toFixed(3)),
                funding8h: funding8h === null ? null : Number(funding8h.toFixed(4)),
                cvdUsd60s,
                whalePrint5m
            };
            const blind = flowCoverageOf(metrics) === 0;
            flowCache.set(symbol, {
                at: Date.now(),
                metrics,
                blind
            });
            flowSrcMap.set(symbol, flowSrc);
            // history ring (fresh samples only)
            if (metrics.oiDelta1h !== null) {
                const ring = flowHistory.get(symbol) ?? [];
                ring.push({
                    at: Date.now(),
                    oiDelta1h: metrics.oiDelta1h
                });
                if (ring.length > HISTORY_CAP) ring.shift();
                flowHistory.set(symbol, ring);
            }
            return metrics;
        } catch  {
            return null;
        } finally{
            flowInFlight.delete(symbol);
        }
    })();
    flowInFlight.set(symbol, p);
    return p;
}
async function ensureFlow(symbols, concurrency = 3) {
    const queue = [
        ...symbols
    ];
    const workers = Array.from({
        length: Math.min(concurrency, queue.length)
    }, async ()=>{
        while(queue.length > 0){
            const s = queue.shift();
            if (s) await fetchFlowMetrics(s);
        }
    });
    await Promise.all(workers);
}
function getFlowHistory(symbol) {
    return flowHistory.get(symbol) ?? [];
}
function fmtUsdShort(v) {
    if (v >= 1e9) return `$${(v / 1e9).toFixed(2)}B`;
    if (v >= 1e6) return `$${(v / 1e6).toFixed(1)}M`;
    return `$${(v / 1e3).toFixed(0)}K`;
}
function detectLiquiditySweep(candles, direction) {
    if (!candles || candles.length < 26) return {
        swept: false,
        supportive: false,
        detail: ""
    };
    const c = candles[candles.length - 1];
    const prior = candles.slice(candles.length - 25, candles.length - 1);
    const swingHigh = Math.max(...prior.map((k)=>k.high));
    const swingLow = Math.min(...prior.map((k)=>k.low));
    const range = c.high - c.low;
    if (range <= 0) return {
        swept: false,
        supportive: false,
        detail: ""
    };
    if (c.high > swingHigh && c.close < swingHigh && (c.high - c.close) / range >= 0.5) {
        const detail = `SMC sweep: bar traded ${((c.high - swingHigh) / swingHigh * 100).toFixed(2)}% above the 24-bar swing high then closed back inside (${Math.round((c.high - c.close) / range * 100)}% rejection wick) — buy-side liquidity grabbed`;
        return {
            swept: true,
            supportive: direction === "SHORT",
            detail: supportive_(detail, direction === "SHORT")
        };
    }
    if (c.low < swingLow && c.close > swingLow && (c.close - c.low) / range >= 0.5) {
        const detail = `SMC sweep: bar pierced ${((swingLow - c.low) / swingLow * 100).toFixed(2)}% below the 24-bar swing low then closed back inside (${Math.round((c.close - c.low) / range * 100)}% rejection wick) — sell-side liquidity grabbed`;
        return {
            swept: true,
            supportive: direction === "LONG",
            detail: supportive_(detail, direction === "LONG")
        };
    }
    return {
        swept: false,
        supportive: false,
        detail: ""
    };
}
function supportive_(detail, ok) {
    return ok ? `${detail}, supports the candidate direction` : detail;
}
async function scoreFlow(symbol, direction, price1hAgoPct) {
    const m = await fetchFlowMetrics(symbol);
    if (!m) {
        return {
            verdict: "UNAVAILABLE",
            score: 0,
            reasons: [
                "flow metrics unavailable — no numbers invented"
            ],
            metrics: {
                oiDelta10m: null,
                oiDelta1h: null,
                oiValueUsd: null,
                cvdNetBase: null,
                cvdNetPctOfVol: null,
                takerRatio: null,
                takerMean: null,
                crowdLongShort: null,
                crowdLongPct: null,
                topLongShort: null,
                funding8h: null,
                cvdUsd60s: null,
                whalePrint5m: null
            },
            oiWeight: 1,
            calibrated: false,
            coverage: 0,
            blind: true
        };
    }
    const coverage = flowCoverageOf(m);
    const dir = direction === "LONG" ? 1 : -1;
    const reasons = [];
    // v12.1 Task-48 ② — HONEST NO-DATA: a fetch that completed with every
    // decision metric null (fapi ban window / budget shed) is BLINDNESS, not a
    // neutral book. The 48h census showed 70% of deploys rode this state while
    // the card read "FLOW-NEUTRAL". Blind flow never votes (score 0) but now
    // carries the NO-DATA verdict so cards, journals and gates can tell the
    // difference. (Gate on blindness = EngineSetting "flow-gate", default
    // tag-only: 10d ledger blind +$204.20 WR 57.1% vs sighted +$7.11 WR 52.8% —
    // blocking the blind cohort would have CUT +$204 of net.)
    if (coverage === 0) {
        return {
            verdict: "NO-DATA",
            score: 0,
            reasons: [
                "flow-blind — every decision metric null (fapi-gate starvation/ban window); no numbers invented, no neutral read claimed"
            ],
            metrics: m,
            oiWeight: 1,
            calibrated: true,
            coverage: 0,
            blind: true
        };
    }
    // v12.2 TASK-52 — honest sourcing: when the bundle rode the bridge, say so
    // on the card/journal instead of silently mixing venues.
    const bridgeSrc = getFlowSource(symbol);
    if (bridgeSrc && bridgeSrc !== "BINANCE") {
        reasons.push(`flow source: ${bridgeSrc} bridge (fapi starved — flow numbers measured on the bridge venue, not Binance)`);
    }
    let raw = 0;
    // 1. CVD imbalance ±9
    if (m.cvdNetPctOfVol !== null) {
        const aligned = m.cvdNetPctOfVol * dir;
        const v = Math.max(-9, Math.min(9, aligned * 1.8));
        raw += v;
        const usdCtx = m.cvdUsd60s !== null ? ` (${m.cvdUsd60s >= 0 ? "+" : ""}$${(m.cvdUsd60s / 1000).toFixed(0)}K net taker USD/60s)` : "";
        reasons.push(`taker CVD ${m.cvdNetPctOfVol >= 0 ? "+" : ""}${m.cvdNetPctOfVol.toFixed(2)}% of taker volume ${aligned > 1 ? "agrees" : aligned < -1 ? "opposes" : "is neutral"}${usdCtx}`);
    }
    // 7. WHALE PRINTS ±5 (v6.7 SMC package): single fills ≥$250K near the entry
    // are the visible footprint of size players — aligned prints confirm, prints
    // against the thesis are distribution risk.
    if (m.whalePrint5m && m.whalePrint5m.totalUsd >= 400_000) {
        const whaleSide = m.whalePrint5m.buyUsd >= m.whalePrint5m.sellUsd ? 1 : -1;
        const aligned = whaleSide * dir;
        const desc = `${m.whalePrint5m.count} fill(s) ≥$250K totaling $${(m.whalePrint5m.totalUsd / 1000).toFixed(0)}K in 5m (max $${(m.whalePrint5m.maxUsd / 1000).toFixed(0)}K, ${m.whalePrint5m.buyUsd >= m.whalePrint5m.sellUsd ? "buy" : "sell"}-side dominant)`;
        if (aligned > 0) {
            raw += 5;
            reasons.push(`WHALE PRINTS ${desc} — pressing WITH the ${direction.toLowerCase()} thesis (smart-money participation)`);
        } else {
            raw -= 5;
            reasons.push(`WHALE PRINTS ${desc} — pressing AGAINST the ${direction.toLowerCase()} thesis (distribution risk)`);
        }
    }
    // 2. OI × price matrix ±7
    if (m.oiDelta1h !== null && price1hAgoPct !== null) {
        const priceDir = price1hAgoPct * dir; // >0: price moving in candidate's favor
        const oiUp = m.oiDelta1h > 0;
        if (priceDir > 0 && oiUp) {
            raw += 7;
            reasons.push(`new positions conviction — price ${price1hAgoPct >= 0 ? "+" : ""}${price1hAgoPct.toFixed(2)}%/1h with OI ${m.oiDelta1h >= 0 ? "+" : ""}${m.oiDelta1h.toFixed(2)}%/1h (fresh ${direction.toLowerCase()}s pressing)`);
        } else if (priceDir > 0 && !oiUp) {
            raw += 2;
            reasons.push(`short-covering style move — OI unwinding ${m.oiDelta1h.toFixed(2)}%/1h while price drifts favorably`);
        } else if (priceDir < 0 && oiUp) {
            raw -= 7;
            reasons.push(`opposing new positions — OI ${m.oiDelta1h.toFixed(2)}%/1h building against the ${direction.toLowerCase()} thesis`);
        } else {
            raw -= 2;
            reasons.push(`capitulation washout pattern — OI and price both unwinding`);
        }
    }
    // 3. REAL liquidation cascade (R16) — exhaustion logic ±3
    const liq = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["liquidationPressure"])(symbol);
    if (liq) {
        if (liq.usd10m >= 400_000) {
            const sideWrecked = direction === "LONG" ? liq.longsUsd10m : liq.shortsUsd10m;
            if (sideWrecked > liq.usd10m * 0.6) {
                raw += 3;
                reasons.push(`REAL liquidation cascade: ${fmtUsdShort(liq.usd10m)} wrecked in 10m — ${direction === "LONG" ? "longs" : "shorts"} flushed (forceOrder), exhaustion tailwind`);
            } else {
                raw -= 1;
                reasons.push(`cascade ${fmtUsdShort(liq.usd10m)} in 10m hit the opposing side — momentum risk`);
            }
        } else {
            reasons.push(`no material liquidation cascade (${fmtUsdShort(liq.usd10m)} in 10m)`);
        }
    }
    // 4. Funding contrarian ±5
    if (m.funding8h !== null) {
        if (m.funding8h > 0.05) {
            const v = dir > 0 ? -5 : 5;
            raw += v;
            reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — crowded longs pay, contrarian edge`);
        } else if (m.funding8h < -0.05) {
            const v = dir > 0 ? 5 : -5;
            raw += v;
            reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — shorts pay, squeeze fuel for longs`);
        } else reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — neutral carry`);
    }
    // 5. Crowd positioning ±4
    if (m.crowdLongShort !== null) {
        if (m.crowdLongShort > 2.2) {
            raw += dir > 0 ? -4 : 4;
            reasons.push(`retail crowd ${m.crowdLongShort.toFixed(2)}:1 long — fade risk on longs`);
        } else if (m.crowdLongShort < 0.5) {
            raw += dir > 0 ? 4 : -4;
            reasons.push(`retail crowd ${m.crowdLongShort.toFixed(2)}:1 (heavy shorts) — contrarian tailwind for longs`);
        }
    }
    // 5b. TOP-TRADER positioning ±4 (v6.7 SMC): the top-20% cohort's POSITION
    // sizing — where size actually sits. Extremes fade; a top-vs-retail DIVERGENCE
    // (smart money leaning where the crowd is not) adds a +2 alignment bonus.
    if (m.topLongShort !== null) {
        if (m.topLongShort > 2) {
            raw += dir > 0 ? -4 : 4;
            reasons.push(`top traders ${m.topLongShort.toFixed(2)}:1 net-LONG by position size — crowded smart-money side, fade risk on longs`);
        } else if (m.topLongShort < 0.5) {
            raw += dir > 0 ? 4 : -4;
            reasons.push(`top traders ${m.topLongShort.toFixed(2)}:1 net-SHORT by position size — crowded smart-money side, tailwind against longs`);
        }
        if (m.crowdLongShort !== null && (m.crowdLongShort > 1.5 && m.topLongShort < 0.8 || m.crowdLongShort < 0.7 && m.topLongShort > 1.5)) {
            const smartSide = m.topLongShort > 1 ? 1 : -1;
            raw += smartSide === dir ? 2 : -2;
            reasons.push(`top-vs-retail divergence: crowd ${m.crowdLongShort.toFixed(2)}:1 vs top traders ${m.topLongShort.toFixed(2)}:1 — size sits with the ${smartSide === 1 ? "longs" : "shorts"}`);
        }
    }
    // 6. Taker acceleration ±5
    if (m.takerRatio !== null && m.takerMean !== null) {
        const accel = m.takerRatio - m.takerMean;
        const aligned = accel * dir;
        if (Math.abs(aligned) > 0.06) {
            raw += Math.max(-5, Math.min(5, aligned * 40));
            reasons.push(`taker buy/sell ${m.takerRatio.toFixed(3)} vs mean ${m.takerMean.toFixed(3)} — ${aligned > 0 ? "accelerating in favor" : "decelerating"}`);
        }
    }
    // OI-notional weighting (v4.5): deep books trusted more
    const oiWeight = m.oiValueUsd ? Math.max(0.5, Math.min(1.2, Math.sqrt(m.oiValueUsd / 50_000_000))) : 1;
    let score = Math.round(Math.max(-25, Math.min(25, raw * oiWeight)));
    if (Math.abs(oiWeight - 1) >= 0.15) reasons.push(`flow weighted ×${oiWeight.toFixed(2)} by OI notional ${fmtUsdShort(m.oiValueUsd ?? 0)} — deep-book flow trusted`);
    // ── v12.9 SECOND-PLANE CONSENSUS (AUDIT-NX3046-20261023, operator mandate
    // «باید از تمام صرافی‌ها مخصوصاً BINANCE تیکت گرفته بشه»; v14.0 Binance-only) ──
    // The bundle rode ONE plane's tape; nothing ever asked a SECOND plane
    // whether the tape agrees. NX-3046: a single-plane JCT tape showed CVD
    // +18.5% OPPOSING the short and OI unwinding — the bundle still rode
    // neutral, and no second plane was consulted. Now: the primary plane's
    // 15m-window (4×5m-bar) direction is compared against the INDEPENDENT
    // Binance plane (fapi-tape → SPOT-MIRROR cross-check; SPOT-MIRROR-tape →
    // gated fapi cross-check). Sign-opposed moves diverging >1.5% clamp
    // conviction to ±6 (below the ±8 CONFIRMS/CONFLICTS line) — cross-plane
    // conflict can never confirm a deploy. 60s per-symbol caches + in-flight
    // dedupe keep the hot path cheap; any fetch failure fails OPEN (consensus
    // simply does not run, no numbers invented). Symbols the second plane
    // cannot price (second rung null) are handled by the engine-side
    // SINGLE-VENUE deploy block.
    const consensusSrc = bridgeSrc ?? null;
    if (consensusSrc) {
        try {
            const pri = await cachedConsensusVal(`PRI5M|${symbol}`, 60_000, async ()=>{
                const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeKlines"])(symbol, "5m", 4).catch(()=>null);
                if (!r || r.rows.length < 4) return null;
                const o = r.rows[0].open, c = r.rows[r.rows.length - 1].close;
                return {
                    move: o > 0 && c > 0 ? (c - o) / o * 100 : null,
                    source: r.source
                };
            });
            const priMove = pri?.move ?? null;
            let secondName = null;
            let secondMove = null;
            // v14.0 — the second-plane cross-check is Binance-only: the plane the
            // primary did NOT ride (fapi primary → SPOT-MIRROR ladder check;
            // SPOT-MIRROR primary → gated fapi check, honest null when banned).
            if (consensusSrc === "BINANCE") {
                secondName = "BINANCE-SPOT";
                secondMove = await cachedConsensusVal(`SPOT5M|${symbol}`, 60_000, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spot5mMove"])(symbol));
            } else if (consensusSrc === "SPOT-MIRROR" || consensusSrc === "MIXED") {
                secondName = "BINANCE-FAPI";
                secondMove = await cachedConsensusVal(`FAPI5M|${symbol}`, 60_000, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapi5mMove"])(symbol));
            }
            if (priMove !== null && secondName && secondMove !== null) {
                const disagree = Math.sign(priMove) !== Math.sign(secondMove) && Math.abs(priMove - secondMove) > 1.5;
                if (disagree) {
                    const cr = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCoreRevert"])();
                    if (!cr.enabled) score = Math.max(-6, Math.min(6, score));
                    reasons.push(`MULTI-VENUE DISAGREE: primary ${consensusSrc} 15m-window ${priMove >= 0 ? "+" : ""}${priMove.toFixed(2)}% vs ${secondName} ${secondMove >= 0 ? "+" : ""}${secondMove.toFixed(2)}% — cross-venue tapes conflict${cr.enabled ? " · CORE-REVERT advisory: clamp lifted, telemetry only (v12.7 doctrine)" : ", conviction clamped ±6, cannot CONFIRM (operator mandate: confirmation from all venues, especially Binance — v12.9)"}`);
                } else if (Math.sign(priMove) === Math.sign(secondMove) && Math.abs(priMove - secondMove) <= 1.5) {
                    reasons.push(`MULTI-VENUE AGREE: primary ${consensusSrc} ${priMove >= 0 ? "+" : ""}${priMove.toFixed(2)}% ≈ ${secondName} ${secondMove >= 0 ? "+" : ""}${secondMove.toFixed(2)}% over 15m — cross-venue tape concordant (v12.9)`);
                }
            }
        } catch  {
        /* fail-open — consensus is telemetry, never a wedging gate */ }
    }
    // ── v12.8 SURROGATE-FLOW CAP (AUDIT-20261023, operator mandate «اصلاح
    // پیشنهادی را کامل و مهندسی اجرا کن») ──
    // Forensics NX-3014 (BTWUSDT 03:13Z): the flow bundle read "CONFIRMS +10"
    // while its source was the SPOT-MIRROR bridge (fapi banned) on a symbol whose
    // BINANCE quote was null and whose cross-venue dislocation ran 90-105bps —
    // the price collapsed −4.5% within 48s of deploy (SL −61.2% in 103s). A
    // surrogate venue's tape is REAL tape, but it is the WRONG venue's tape for
    // a Binance-doctrine engine on dislocated micro-caps: it must not be allowed
    // to CONFIRM a deploy. Cap: when the feeding source is not BINANCE, flow
    // conviction is clamped to ±6 — below the ±8 CONFIRMS/CONFLICTS line, so a
    // surrogate bundle can never confirm NOR fully veto; it can still feed the
    // flowVetoScore ≤−4 soft veto (score −5/−6 survives the clamp) and rides as
    // honest telemetry. BINANCE-sourced bundles are untouched.
    //
    // ── v13.3 SURROGATE-FLOW DEMOTE (ch.7 item ①-ب, operator mandate trace
    // 1a1a8ea4186c6571 «پیشنهادات باقی مانده مهندسی را کامل اجرا کن») ──
    // NX-3247 anatomy (engineering report ch.4-1): with fapi starved, the flow
    // verdict was sourced «SPOT-MIRROR bridge» and read CONFLICTS −9 against a
    // REAL Binance-futures buy flow the operator could see — the engine decided
    // with a surrogate's eyes at the exact top. While the fapi plane is starving
    // (global ban window live OR ≥2 egress IPs banned — fapiBanActivity()), a
    // non-BINANCE bundle is demoted to INFORMATIONAL-ONLY: score contribution 0,
    // verdict NEUTRAL, reason carries the demote tag. This branch runs BEFORE the
    // core-revert advisory check — CORE-REVERT restores the v12.7 core, it was
    // never an authorization for surrogate verdict-making during famine. When
    // fapi recovers, the historical v12.8 cap semantics resume unchanged.
    if (bridgeSrc && bridgeSrc !== "BINANCE") {
        const famine = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapiBanActivity"])().active; // v13.3 ch.7-ب — honest fapi-plane health
        if (famine) {
            score = 0;
            reasons.push(`SURROGATE-FLOW DEMOTE (ch.7-ب): fapi starved + source ${bridgeSrc} → flow bundle is INFORMATIONAL-ONLY this evaluation (score contribution 0, verdict NEUTRAL; NX-3247 CONFLICTS-9-from-mirror forensics — the engine does not decide on a surrogate's eyes while the real perp plane is starved)`);
        } else {
            const crSurrogate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCoreRevert"])();
            if (!crSurrogate.enabled) score = Math.max(-6, Math.min(6, score));
            reasons.push(`SURROGATE-FLOW CAP: source ${bridgeSrc} ≠ BINANCE${crSurrogate.enabled ? " · CORE-REVERT advisory: clamp lifted, surrogate tape rides as telemetry (v12.7 doctrine — the +12/+8/cap stack was the no-Binance drought engine)" : " — conviction clamped ±6, surrogate flow cannot CONFIRM a deploy (NX-3014 48s-collapse forensics, v12.8)"}`);
        }
    }
    const verdict = score >= 8 ? "CONFIRMS" : score <= -8 ? "CONFLICTS" : "NEUTRAL";
    return {
        verdict,
        score,
        reasons,
        metrics: m,
        oiWeight: Number(oiWeight.toFixed(2)),
        calibrated: true,
        coverage,
        blind: false,
        source: bridgeSrc ?? undefined
    };
}
}),
"[project]/src/lib/binance-mirror.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mirrorFunding8h",
    ()=>mirrorFunding8h,
    "mirrorHealth",
    ()=>mirrorHealth,
    "mirrorKlines",
    ()=>mirrorKlines,
    "mirrorOiDelta1h",
    ()=>mirrorOiDelta1h,
    "mirrorTickers",
    ()=>mirrorTickers
]);
// ── NEXUS//SIGNALS — Binance mirror client (server-only, v14.0) ─────────────
// v14.0 BINANCE-ONLY RE-ARCHITECTURE (operator mandate trace 1a185042c872b4f9
// — «ردپای OKX/Bybit در کجا وجود دارد و با بایننس جایگزین شود»): the former
// cross-venue feed module is rebuilt as the BINANCE MIRROR client. Every
// consumer gets a LIVE, honestly-plane-tagged Binance board:
//   • klines/tickers ride the spot-host ladder (data-api.binance.vision →
//     api-gcp → api1-4 → api.binance.com) — a SEPARATE ban pool from fapi,
//     spot klines keep the field-9 taker-buy split (CVD stays REAL).
//   • funding / OI history ride the gated fapi plane (perp-native).
// HONESTY DOCTRINE (October carry-over): fallback-plane data is tagged with
// its real Binance plane; a plane that fails degrades to null — never to
// invented data.
// ─────────────────────────────────────────────────────────────────────────────
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
const TIMEOUT_MS = 6500;
// v13.3 SPOT-HOST LADDER (same family as flow-bridge/market-feed — shared gate)
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
];
const health = (()=>{
    // globalThis dedupe — Turbopack per-bundle instantiation would otherwise
    // fork the counters between the engine bundle and per-route bundles.
    const g = globalThis;
    g.__nexusMirrorHealth ??= {
        lastOkAt: null,
        lastErrorAt: null,
        lastError: null,
        consecutiveFailures: 0,
        latencyMs: null,
        klinesOk: 0,
        tickersOk: 0,
        metricsOk: 0
    };
    return g.__nexusMirrorHealth;
})();
function mirrorHealth() {
    return health;
}
async function ladderGet(path) {
    const t0 = Date.now();
    const ready = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotHostsReady"])(SPOT_HOSTS);
    for (const host of ready){
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["noteSpotHostThrottle"])(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) {
                health.lastErrorAt = Date.now();
                health.lastError = `${path} → ${res.status}`;
                health.consecutiveFailures++;
                continue;
            }
            const json = await res.json();
            health.lastOkAt = Date.now();
            health.latencyMs = Date.now() - t0;
            health.consecutiveFailures = 0;
            return json;
        } catch (e) {
            health.lastErrorAt = Date.now();
            health.lastError = e instanceof Error ? e.message : String(e);
            health.consecutiveFailures++;
        }
    }
    return null;
}
async function mirrorKlines(symbol, interval, limit) {
    const raw = await ladderGet(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${Math.min(1000, limit)}`);
    if (!Array.isArray(raw) || raw.length === 0) return null;
    health.klinesOk++;
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5]),
            takerBuy: Number(k[9])
        }));
}
async function mirrorTickers() {
    const out = new Map();
    const rows = await ladderGet("/api/v3/ticker/24hr");
    if (!Array.isArray(rows)) return out;
    health.tickersOk++;
    for (const t of rows){
        if (!t?.symbol || !(Number(t.lastPrice) > 0)) continue;
        out.set(t.symbol, {
            symbol: t.symbol,
            lastPrice: t.lastPrice,
            priceChangePercent: t.priceChangePercent ?? "0",
            highPrice: t.highPrice ?? t.lastPrice,
            lowPrice: t.lowPrice ?? t.lastPrice,
            quoteVolume: t.quoteVolume ?? "0"
        });
    }
    return out;
}
async function mirrorFunding8h(symbol) {
    const rows = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/fundingRate?symbol=${symbol}&limit=1`, {
        priority: "telemetry",
        timeoutMs: 6000
    }).catch(()=>null);
    const r = rows?.[0]?.fundingRate;
    if (r === undefined) return null;
    health.metricsOk++;
    const n = Number(r);
    return Number.isFinite(n) ? n * 100 : null;
}
async function mirrorOiDelta1h(symbol) {
    const rows = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/futures/data/openInterestHist?symbol=${symbol}&period=1h&limit=2`, {
        priority: "telemetry",
        timeoutMs: 6000
    }).catch(()=>null);
    if (!Array.isArray(rows) || rows.length < 2) return null;
    health.metricsOk++;
    const cur = Number(rows[0]?.sumOpenInterest);
    const prev = Number(rows[rows.length - 1]?.sumOpenInterest);
    if (!Number.isFinite(cur) || !Number.isFinite(prev) || prev <= 0) return null;
    return Number(((cur - prev) / prev * 100).toFixed(3));
}
}),
"[project]/src/lib/flow-scanner.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SCAN_TFS",
    ()=>SCAN_TFS,
    "ensureSymbolFlow",
    ()=>ensureSymbolFlow,
    "flowScanHealth",
    ()=>flowScanHealth,
    "flowShiftTracking",
    ()=>flowShiftTracking,
    "getFlowBoard",
    ()=>getFlowBoard,
    "maybeFlowScan",
    ()=>maybeFlowScan,
    "peekFlowKlines",
    ()=>peekFlowKlines,
    "peekSymbolFlow",
    ()=>peekSymbolFlow,
    "refreshSymbolFlow",
    ()=>refreshSymbolFlow
]);
// ── FlowRadar Neo v8.0 MULTI-TIMEFRAME FLOW SCANNER (EPOCH-2, server-only) ──
// Operator mandate 2026-09-08: «معماری سیستم اسکنر جریانات مالی با قابلیت ردیابی
// در تایم فریمهای مختلف». Research base: docs/RESEARCH-FLOW-DETECTION.md.
//
// Design laws (research-derived):
//   · HTF dominance — 4h/1h carry the bias; 15m/5m only time the entry.
//   · Closed bars only — every structure call is on a CLOSED candle (no repaint,
//     no lookahead).
//   · Flow must explain price — the OI×price validity matrix and CVD divergence
//     rule come from flow.ts; this module extends them across TFs.
//   · Sweeps are context — a sweep counts only against the prior 24-bar swing of
//     ITS OWN timeframe, with a ≥50% rejection wick.
//
// Cadence: rotating batch of 6 symbols per call (engine tick ×25 ≈ 87s) → the
// full 40-64 symbol domain re-scans in ~10-16min. Per-TF kline caches keep the
// API cost at ~24 kline calls/min worst case. Persistence: one FlowScan row per
// (symbol, tf) UPSERTED (no churn) + the whole board in EngineSetting
// "flowscan.board" (single-row upsert — race-free by construction).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$binance$2d$mirror$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/binance-mirror.ts [app-route] (ecmascript)"); // v14.0 — Binance mirror client (bybit-feed retired)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
;
;
;
const SCAN_TFS = [
    "4h",
    "1h",
    "15m",
    "5m"
];
const TF_WEIGHT = {
    "4h": 0.35,
    "1h": 0.3,
    "15m": 0.2,
    "5m": 0.15
};
const TF_LIMIT = {
    "4h": 72,
    "1h": 96,
    "15m": 120,
    "5m": 120
};
const TF_TTL = {
    "4h": 480_000,
    "1h": 240_000,
    "15m": 90_000,
    "5m": 45_000
};
const BOARD_KEY = "flowscan.board";
const BATCH = 6;
// DATA-REVIVAL 2026-10-21 — 60s/6 symbols needed ~11min to rotate a 64-symbol
// board; the operator mandate is flow tracking at HIGH SPEED. 20s/6 → full
// board ~3.5min. The SPOT-MIRROR ladder carries this easily; the fapi-gate
// telemetry lane is sheddable as before.
const MIN_INTERVAL_MS = 20_000;
const NET_BIAS_MIN = 20; // |netScore| needed to call a LONG/SHORT board
const HTF_FLIP_MIN = {
    h4: 25,
    h1: 30
}; // HTF-conflict thresholds for FLOW-SHIFT
const SHIFT_COOLDOWN_MS = 2 * 3600_000;
// ── kline+flow fetch with per-(symbol,tf) cache and in-flight dedupe ──
const klineFlowCache = new Map();
const klineFlowInFlight = new Map();
// RAM-SHED round-2 (P2-c): the tracked domain grew to ~900 symbols × 4 TFs ≈
// 3.6k possible entries; every entry is 72-120 FlowCandle objects (~10-15KB),
// so one slow tail rotation parks ~40-55MB of mostly-stale klines in the Map
// between scans (TTL expiry only gates READS — stale entries linger forever).
// Cap at 600 (hot lane 64×4=256 + recent tail) with oldest-`at` eviction on
// insert: evicted entries are exactly the ones already past their TF TTL that
// would refetch on their next rotation anyway. The __nexusShed hook below
// keeps its exact semantics — the cap just bounds what it has to trim.
const KLINE_FLOW_CACHE_MAX = 600;
function klineFlowCacheSet(key, entry) {
    if (!klineFlowCache.has(key)) {
        while(klineFlowCache.size >= KLINE_FLOW_CACHE_MAX){
            let oldestKey = null;
            let oldestAt = Number.POSITIVE_INFINITY;
            for (const [k, v] of klineFlowCache){
                if (v.at < oldestAt) {
                    oldestAt = v.at;
                    oldestKey = k;
                }
            }
            if (oldestKey === null) break; // unreachable — Map cannot shrink below empty
            klineFlowCache.delete(oldestKey);
        }
    }
    klineFlowCache.set(key, entry);
}
// DATA-REVIVAL 2026-10-21 — silent-starvation fix: when the fapi plane fails
// (IP-ban 418), the failure is COUNTED and rate-limit-logged, and the scan
// falls back to the Binance SPOT mirror ladder with an honest plane tag
// (v14.0: the old cross-venue rung is retired — Binance-only).
const fbStats = (()=>{
    // globalThis dedupe — Turbopack can instantiate per-route bundles; the
    // engine's tick loop and the /api/flows route MUST share one counter set.
    const g = globalThis;
    g.__nexusFlowFbStats ??= {
        fapiFail: 0,
        mirrorOk: 0,
        mirrorFail: 0,
        spotOk: 0,
        lastWarnAt: 0
    };
    return g.__nexusFlowFbStats;
})();
// third rung — Binance SPOT klines via the data-vision mirror host family
// (api.binance.com is IP-banned; data-api.binance.vision is NOT — proven live
// by the feed probe). Spot klines share the exact field layout (takerBuy at
// index 9) so CVD stays REAL. For niche Binance listings absent from spot
// linear this is the only honest revival path.
// v13.2.1 — per-host 418/429 backoff via the shared spot-host gate.
async function spotKlines(symbol, tf, limit) {
    for (const host of (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotHostsReady"])([
        "https://data-api.binance.vision",
        "https://api-gcp.binance.com",
        "https://api1.binance.com",
        "https://api2.binance.com",
        "https://api3.binance.com",
        "https://api4.binance.com",
        "https://api.binance.com"
    ])){
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), 6500);
            const res = await fetch(`${host}/api/v3/klines?symbol=${symbol}&interval=${tf}&limit=${limit}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["noteSpotHostThrottle"])(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) continue;
            const raw = await res.json();
            if (!Array.isArray(raw) || raw.length === 0) continue;
            return raw.map((k)=>({
                    openTime: Number(k[0]),
                    open: Number(k[1]),
                    high: Number(k[2]),
                    low: Number(k[3]),
                    close: Number(k[4]),
                    volume: Number(k[5]),
                    takerBuy: Number(k[9])
                }));
        } catch  {
            continue;
        }
    }
    return null;
}
function warnFallback(msg) {
    if (Date.now() - fbStats.lastWarnAt < 60_000) return;
    fbStats.lastWarnAt = Date.now();
    console.warn(`[flow-scanner] ${msg}`);
}
function flowScanHealth() {
    return {
        fapiFail: fbStats.fapiFail,
        mirrorOk: fbStats.mirrorOk,
        mirrorFail: fbStats.mirrorFail,
        spotOk: fbStats.spotOk,
        mirror: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$binance$2d$mirror$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mirrorHealth"])()
    };
}
async function fetchKlinesFlow(symbol, tf) {
    const key = `${symbol}|${tf}`;
    const hit = klineFlowCache.get(key);
    if (hit && Date.now() - hit.at < TF_TTL[tf]) return hit;
    const existing = klineFlowInFlight.get(key);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            // v10.24 Task 34-a: klines through the central fapi-gate (telemetry lane
            // — a shedded (symbol,tf) simply re-scans on the next rotation).
            let venue = "BINANCE";
            let raw = null;
            try {
                raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${tf}&limit=${TF_LIMIT[tf]}`, {
                    priority: "telemetry",
                    timeoutMs: 6500
                });
            } catch  {
                raw = null;
            }
            if (!raw || raw.length === 0) {
                // v14.0 honest fallback ladder — the SPOT mirror only (keeps CVD REAL
                // via taker-buy field 9). When the spot ladder also misses, the
                // (symbol,tf) starves honestly — no cross-venue rows exist anymore.
                fbStats.fapiFail++;
                const spot = await spotKlines(symbol, tf, TF_LIMIT[tf]);
                if (spot && spot.length > 0) {
                    venue = "BINANCE-SPOT"; // same venue, SPOT instrument class (vision mirror)
                    fbStats.spotOk++;
                    fbStats.mirrorOk++;
                    warnFallback(`fapi kline unavailable (${symbol} ${tf}) → BINANCE-SPOT mirror (CVD real, spot tape)`);
                    klineFlowCacheSet(key, {
                        at: Date.now(),
                        candles: spot,
                        venue
                    });
                    return {
                        candles: spot,
                        venue
                    };
                }
                fbStats.mirrorFail++;
                warnFallback(`kline starved on ALL Binance planes: ${symbol} ${tf} (fapi + spot mirror)`);
                return null;
            }
            const candles = raw.map((k)=>({
                    openTime: Number(k[0]),
                    open: Number(k[1]),
                    high: Number(k[2]),
                    low: Number(k[3]),
                    close: Number(k[4]),
                    volume: Number(k[5]),
                    takerBuy: Number(k[9])
                }));
            klineFlowCacheSet(key, {
                at: Date.now(),
                candles,
                venue: "BINANCE"
            });
            return {
                candles,
                venue: "BINANCE"
            };
        } catch  {
            return null;
        } finally{
            klineFlowInFlight.delete(key);
        }
    })();
    klineFlowInFlight.set(key, p);
    return p;
}
// ── pure per-TF analytics (closed bars ONLY — the last raw kline may be
// unclosed, so it is dropped before any computation) ──
function ema(values, period) {
    if (values.length === 0) return 0;
    const k = 2 / (period + 1);
    let e = values[0];
    for(let i = 1; i < values.length; i++)e = values[i] * k + e * (1 - k);
    return e;
}
function analyzeTf(symbol, tf, raw, funding8h, oiDelta1h) {
    const candles = raw.slice(0, -1); // drop the possibly-unclosed bar — closed bars only
    if (candles.length < 40) return null;
    const closes = candles.map((c)=>c.close);
    const e20 = ema(closes.slice(-60), 20);
    const e50 = ema(closes.slice(-90), 50);
    const trend = e20 > e50 * 1.0005 ? "UP" : e20 < e50 * 0.9995 ? "DOWN" : "FLAT";
    // pivots over the last 30 closed bars (fractal: 2 bars each side)
    const win = candles.slice(-30);
    const pivotHighs = [];
    const pivotLows = [];
    for(let i = 2; i < win.length - 2; i++){
        const h = win[i].high;
        const l = win[i].low;
        if (h > win[i - 1].high && h > win[i - 2].high && h > win[i + 1].high && h > win[i + 2].high) pivotHighs.push(h);
        if (l < win[i - 1].low && l < win[i - 2].low && l < win[i + 1].low && l < win[i + 2].low) pivotLows.push(l);
    }
    const swingHigh = pivotHighs.length ? Math.max(...pivotHighs) : Math.max(...win.slice(0, -1).map((c)=>c.high));
    const swingLow = pivotLows.length ? Math.min(...pivotLows) : Math.min(...win.slice(0, -1).map((c)=>c.low));
    const last = win[win.length - 1];
    const range = last.high - last.low;
    let structure = "RANGE";
    let sweep = false;
    if (range > 0) {
        // liquidity sweep — grab the obvious swing, close back inside, ≥50% rejection wick
        if (last.high > swingHigh && last.close < swingHigh && (last.high - last.close) / range >= 0.5) {
            structure = "SWEEP_HIGH";
            sweep = true;
        } else if (last.low < swingLow && last.close > swingLow && (last.close - last.low) / range >= 0.5) {
            structure = "SWEEP_LOW";
            sweep = true;
        } else if (last.close > swingHigh) {
            structure = trend === "DOWN" ? "CHOH_UP" : "BOS_UP";
        } else if (last.close < swingLow) {
            structure = trend === "UP" ? "CHOH_DOWN" : "BOS_DOWN";
        }
    }
    // CVD over the last 12 closed bars — direct taker aggression from kline field 9.
    // DATA-REVIVAL: fallback candles without field-9 carry takerBuy=NaN → cvdPct stays null
    // (honest measured gap — never invented from price direction).
    const w12 = candles.slice(-12);
    const vol12 = w12.reduce((a, c)=>a + c.volume, 0);
    const buy12 = w12.reduce((a, c)=>a + c.takerBuy, 0);
    const cvdPct = vol12 > 0 && Number.isFinite(buy12) ? Number(((2 * buy12 - vol12) / vol12 * 100).toFixed(2)) : null;
    // volume ignition z-score (last closed bar vs prior 30)
    const v30 = candles.slice(-31, -1).map((c)=>c.volume);
    const vMean = v30.reduce((a, b)=>a + b, 0) / Math.max(1, v30.length);
    const vStd = Math.sqrt(v30.reduce((a, b)=>a + (b - vMean) * (b - vMean), 0) / Math.max(1, v30.length));
    const volZ = vStd > 0 ? Number(((last.volume - vMean) / vStd).toFixed(2)) : null;
    // ATR% (14 bars, true range)
    let atrSum = 0;
    for(let i = candles.length - 14; i < candles.length; i++){
        const c = candles[i];
        const p = candles[i - 1];
        atrSum += Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
    }
    const atrPct = Number((atrSum / 14 / last.close * 100).toFixed(2));
    // per-TF score −100..+100
    let s = 0;
    if (cvdPct !== null) s += Math.max(-40, Math.min(40, cvdPct * 2.2));
    s += trend === "UP" ? 18 : trend === "DOWN" ? -18 : 0;
    if (structure === "BOS_UP") s += 20;
    else if (structure === "BOS_DOWN") s -= 20;
    else if (structure === "CHOH_UP") s += 14;
    else if (structure === "CHOH_DOWN") s -= 14;
    if (structure === "SWEEP_LOW") s += 14; // sell-side liquidity grabbed → fuel for longs
    else if (structure === "SWEEP_HIGH") s -= 14; // buy-side grabbed → fuel for shorts
    if (volZ !== null && cvdPct !== null) s += Math.sign(cvdPct) * Math.min(3, Math.max(0, volZ)) * 4;
    const score = Math.round(Math.max(-100, Math.min(100, s)));
    const bias = score >= 25 ? "LONG" : score <= -25 ? "SHORT" : "NEUTRAL";
    return {
        tf,
        score,
        bias,
        trend,
        structure,
        sweep,
        cvdPct,
        volZ,
        atrPct
    };
}
// ── board state ──
const board = new Map();
let boardLoaded = false;
// (scanCursor removed in v12.10 — the two-speed rotation picks oldest-board-first,
//  no fixed cursor: hot lane 5/6 + tail 1/6 of every batch)
let lastScanAt = 0;
let scanInFlight = false;
const shiftLastAt = new Map();
// RAM-SHED round-2 (P2-c): board churn-guard. Entries are small (~1KB) but the
// Map grows with every distinct symbol ever scanned (universe ~900 and
// growing — delisted symbols never leave). Cap 1024 (≈2× the hot universe)
// with oldest-`at` eviction: evicted rows are far past the 20min peek TTL
// (peekSymbolFlow already returns null for them) and the rotation's
// oldest-board-first sort treats a missing row exactly like a stale one
// (+∞ age → first in line for a re-scan). DB (flowscan.board / FlowScan rows)
// stays the durable source of truth — loadBoard refills ≤64 rows at boot.
const BOARD_MAX = 1024;
function boardSet(symbol, rollup) {
    if (!board.has(symbol)) {
        while(board.size >= BOARD_MAX){
            let oldestKey = null;
            let oldestAt = Number.POSITIVE_INFINITY;
            for (const [k, v] of board){
                if (v.at < oldestAt) {
                    oldestAt = v.at;
                    oldestKey = k;
                }
            }
            if (oldestKey === null) break;
            board.delete(oldestKey);
        }
    }
    board.set(symbol, rollup);
}
// ── RAM-SHED hook (RAM-SHED-20261024) ──────────────────────────────────────
// The instrumentation RSS governor calls this under memory pressure. The
// kline cache is the biggest DISCRETIONARY in-app store (candles per
// symbol×tf — safely refetchable within one scan cycle), so it sheds first:
// entries older than 10min are dropped + in-flight dedupe cleared. Returns
// the number of entries freed for the governor log. globalThis dedupe —
// Turbopack can instantiate per-route bundles; the governor must reach the
// ONE shared cache instance.
{
    const g = globalThis;
    if (!g.__nexusShed) {
        g.__nexusShed = ()=>{
            let freed = 0;
            const now = Date.now();
            for (const [key, entry] of klineFlowCache){
                if (now - entry.at > 10 * 60_000) {
                    klineFlowCache.delete(key);
                    freed++;
                }
            }
            klineFlowInFlight.clear();
            return freed;
        };
    }
}async function loadBoard() {
    if (boardLoaded) return;
    boardLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: BOARD_KEY
            }
        });
        if (row) {
            const parsed = JSON.parse(row.value);
            for (const r of parsed.rows ?? [])board.set(r.symbol, r);
        }
    } catch  {
    /* cold start — the scanner repopulates within minutes */ }
}
async function persistBoard() {
    const rows = [
        ...board.values()
    ].sort((a, b)=>Math.abs(b.netScore) - Math.abs(a.netScore)).slice(0, 64);
    const value = JSON.stringify({
        at: Date.now(),
        rows
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: BOARD_KEY
        },
        create: {
            key: BOARD_KEY,
            value
        },
        update: {
            value
        }
    });
}
async function scanSymbol(symbol) {
    const settled = await Promise.allSettled(SCAN_TFS.map((tf)=>fetchKlinesFlow(symbol, tf)));
    const raw = settled.map((r)=>r.status === "fulfilled" ? r.value : null);
    if (raw.filter(Boolean).length < 3) return null; // honest: need ≥3 TFs, no invented rows
    const venues = raw.filter(Boolean).map((r)=>r.venue);
    const rollupVenue = venues.every((v)=>v === "BINANCE") ? "BINANCE" : venues.every((v)=>v === "BINANCE-SPOT") ? "BINANCE-SPOT" : "MIXED";
    // derivatives context is TF-agnostic — one shared cached fetch (flow.ts)
    let funding8h = null;
    let oiDelta1h = null;
    try {
        const m = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFlowMetrics"])(symbol);
        if (m) {
            funding8h = m.funding8h;
            oiDelta1h = m.oiDelta1h;
        }
    } catch  {
    /* context stays null — rows still ship with the measured price-flow vector */ }
    const tfs = [];
    for(let i = 0; i < SCAN_TFS.length; i++){
        const r = raw[i];
        if (!r) continue;
        const row = analyzeTf(symbol, SCAN_TFS[i], r.candles, funding8h, oiDelta1h);
        if (row) tfs.push(row);
    }
    if (tfs.length < 3) return null;
    const netScore = Math.round(tfs.reduce((a, t)=>a + t.score * TF_WEIGHT[t.tf], 0));
    const netBias = netScore >= NET_BIAS_MIN ? "LONG" : netScore <= -NET_BIAS_MIN ? "SHORT" : "NEUTRAL";
    const alignment = netBias === "NEUTRAL" ? 0 : tfs.filter((t)=>t.bias === netBias).length;
    return {
        symbol,
        at: Date.now(),
        netScore,
        netBias,
        alignment,
        tfs,
        funding8h,
        oiDelta1h,
        venue: rollupVenue
    };
}
async function maybeFlowScan(symbols) {
    await loadBoard();
    if (scanInFlight || symbols.length === 0) return;
    if (Date.now() - lastScanAt < MIN_INTERVAL_MS) return;
    scanInFlight = true;
    lastScanAt = Date.now();
    try {
        // v12.10 TWO-SPEED ROTATION (AUDIT-20261023 root-cause of «سرعت تشخیص»):
        // the tracked domain grew to ~900 symbols while the rotation budget stayed
        // at the 64-symbol design (6/call, 20s) → a full cycle takes ~50min against
        // the 20min board TTL → peekSymbolFlow() returns null (stale-never-gates)
        // for MOST of the universe → the MTF deploy guard silently blind. Fix: the
        // caller now passes the domain VOLUME-RANKED (hot deployable universe
        // first); this lane owns 5/6 of every batch, the long tail 1 slot — both
        // oldest-board-first so ages self-balance. Hot lane (64 syms) re-scans in
        // ~4.3min « well under the TTL; the dust tail rotates slowly but is
        // liquidity-floored out of deploys anyway.
        const HOT = 64;
        const boardAge = (s)=>{
            const r = board.get(s);
            return r ? Date.now() - r.at : Number.POSITIVE_INFINITY;
        };
        const oldestFirst = (arr, n)=>[
                ...arr
            ].sort((a, b)=>boardAge(b) - boardAge(a)).slice(0, Math.max(0, Math.min(n, arr.length)));
        const head = symbols.slice(0, HOT);
        const tail = symbols.slice(HOT);
        const batch = [
            ...oldestFirst(head, tail.length > 0 ? BATCH - 1 : BATCH),
            ...oldestFirst(tail, tail.length > 0 ? 1 : 0)
        ];
        if (batch.length === 0) return;
        for (const symbol of batch){
            const rollup = await scanSymbol(symbol).catch(()=>null);
            if (!rollup) continue;
            boardSet(symbol, rollup);
            for (const t of rollup.tfs){
                const data = {
                    score: t.score,
                    bias: t.bias,
                    cvdPct: t.cvdPct,
                    trend: t.trend,
                    structure: t.structure,
                    sweep: t.sweep,
                    volZ: t.volZ,
                    atrPct: t.atrPct,
                    funding8h: rollup.funding8h,
                    oiDelta1h: rollup.oiDelta1h
                };
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].flowScan.upsert({
                    where: {
                        symbol_tf: {
                            symbol,
                            tf: t.tf
                        }
                    },
                    create: {
                        symbol,
                        tf: t.tf,
                        ...data
                    },
                    update: data
                });
            }
        }
        await persistBoard();
    } finally{
        scanInFlight = false;
    }
}
/** v12.12 CARD-SENTINEL (2026-10-24) — on-demand single-symbol refresh that ALSO
 *  persists the FlowScan DB cards. ensureSymbolFlow() only warms the in-memory
 *  board; the DB rows the dashboard renders were left to the two-speed rotation,
 *  so any symbol that cooled off went stale for hours (BIRBUSDT cards 4h9m old
 *  while its events kept firing — SENTINEL-M0M2 finding #6). One in-flight
 *  refresh per process; callers rate-limit per symbol (route enforces 90s). */ let refreshInFlight = false;
async function refreshSymbolFlow(symbol) {
    if (refreshInFlight) return null;
    refreshInFlight = true;
    try {
        await loadBoard();
        const rollup = await scanSymbol(symbol).catch(()=>null);
        if (!rollup) return null;
        boardSet(symbol, rollup);
        for (const t of rollup.tfs){
            const data = {
                score: t.score,
                bias: t.bias,
                cvdPct: t.cvdPct,
                trend: t.trend,
                structure: t.structure,
                sweep: t.sweep,
                volZ: t.volZ,
                atrPct: t.atrPct,
                funding8h: rollup.funding8h,
                oiDelta1h: rollup.oiDelta1h
            };
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].flowScan.upsert({
                where: {
                    symbol_tf: {
                        symbol,
                        tf: t.tf
                    }
                },
                create: {
                    symbol,
                    tf: t.tf,
                    ...data
                },
                update: data
            });
        }
        await persistBoard();
        return rollup;
    } finally{
        refreshInFlight = false;
    }
}
function peekSymbolFlow(symbol) {
    const r = board.get(symbol);
    if (!r) return null;
    const age = Date.now() - r.at;
    if (age > 20 * 60_000) return null; // stale board never gates — 20min TTL
    return r;
}
async function ensureSymbolFlow(symbol) {
    await loadBoard();
    const peeked = peekSymbolFlow(symbol);
    if (peeked) return peeked;
    return scanSymbol(symbol);
}
function peekFlowKlines(symbol, tf) {
    const hit = klineFlowCache.get(`${symbol}|${tf}`);
    if (!hit || Date.now() - hit.at >= TF_TTL[tf]) return null;
    return hit.candles;
}
async function flowShiftTracking() {
    await loadBoard();
    const active = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "ACTIVE",
                    "TP1",
                    "TP2"
                ]
            }
        },
        select: {
            id: true,
            serial: true,
            symbol: true,
            direction: true
        }
    });
    if (active.length === 0) return;
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)"); // dynamic — keeps the module cycle off the boot path
    for (const s of active){
        const r = board.get(s.symbol);
        if (!r || r.netBias === "NEUTRAL") continue;
        const h1 = r.tfs.find((t)=>t.tf === "1h");
        const h4 = r.tfs.find((t)=>t.tf === "4h");
        if (!h1 || !h4) continue;
        const dirLong = s.direction === "LONG";
        const against = dirLong ? "SHORT" : "LONG";
        const flipped = h1.bias === against && h4.bias === against && Math.abs(h1.score) >= HTF_FLIP_MIN.h1 && Math.abs(h4.score) >= HTF_FLIP_MIN.h4;
        if (!flipped) continue;
        const last = shiftLastAt.get(s.id) ?? 0;
        if (Date.now() - last < SHIFT_COOLDOWN_MS) continue;
        shiftLastAt.set(s.id, Date.now());
        await fireEvent(s.id, s.symbol, "ENGINE", "warn", `FLOW-SHIFT: NX-${String(s.serial).padStart(4, "0")} ${s.direction} ${s.symbol} — 1h (${h1.score}) and 4h (${h4.score}) flow boards both flipped ${against} while the book is live (board net ${r.netScore}, ${r.alignment}/4 TFs aligned). Regime damage visible BEFORE the stop — consider BE-trail status.`);
    }
}
async function getFlowBoard() {
    await loadBoard();
    const rows = [
        ...board.values()
    ].sort((a, b)=>Math.abs(b.netScore) - Math.abs(a.netScore));
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows: rows.slice(0, 48)
    };
}
}),
];

//# sourceMappingURL=src_lib_e819e683._.js.map