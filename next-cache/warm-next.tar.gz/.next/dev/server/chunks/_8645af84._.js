module.exports = [
"[project]/node_modules/z-ai-web-dev-sdk/dist/index.js [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__59570ec3._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/z-ai-web-dev-sdk/dist/index.js [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/supervisor.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_03ca30d4._.js",
  "server/chunks/[root-of-the-server]__a43afe04._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/supervisor.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/verdict.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__2a5af510._.js",
  "server/chunks/[root-of-the-server]__e3d0828a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/verdict.ts [app-route] (ecmascript)");
    });
});
}),
];