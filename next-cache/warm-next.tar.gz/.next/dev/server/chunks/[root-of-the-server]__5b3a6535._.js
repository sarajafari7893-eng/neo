module.exports = [
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[project]/src/lib/db.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[project]/src/lib/stableflow.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BOARD_FRESH_MS",
    ()=>BOARD_FRESH_MS,
    "DATA_DIR",
    ()=>DATA_DIR,
    "DEPEG_MUTE_PCT",
    ()=>DEPEG_MUTE_PCT,
    "DEPEG_WARN_PCT",
    ()=>DEPEG_WARN_PCT,
    "MINTBURN_USD",
    ()=>MINTBURN_USD,
    "REGIME_OFF_PCT",
    ()=>REGIME_OFF_PCT,
    "REGIME_ON_PCT",
    ()=>REGIME_ON_PCT,
    "depegMuted",
    ()=>depegMuted,
    "getStableBoard",
    ()=>getStableBoard,
    "getStableBoardSync",
    ()=>getStableBoardSync,
    "isBoardFresh",
    ()=>isBoardFresh,
    "maybePersistStableFlow",
    ()=>maybePersistStableFlow,
    "parseBoard",
    ()=>parseBoard,
    "readRecentStableEvents",
    ()=>readRecentStableEvents,
    "stableRegimeVerdict",
    ()=>stableRegimeVerdict
]);
// ── NEXUS//SIGNALS — v11.0 STABLECOIN FLOW LIB (server-only) ────────────────
// Family-E substrate shared by: engine gates (DEPEG-MUTE / STABLE-REGIME),
// shadow-veto telemetry, /api/stableflow, and the TG digest.
//
// SOURCE OF TRUTH: the stable-feed mini-service (:3017) polls DefiLlama
// (free, no key, no AI — IRAN-VPS compatible) and atomically writes
//   .data/stable-feed/board.json        — the live regime board
//   .data/stable-feed/events.jsonl      — MINTBURN / DEPEG / REGIME events
//   .data/stable-feed/backfill/*.json   — daily history (~9y, backtest substrate)
// The app NEVER talks to DefiLlama and NEVER blocks on the service: reads are
// file-only, cached 10s, and every failure degrades to null (fail-open with
// honest nulls — gates stay silent when the substrate is absent).
//
// DB doctrine: mini-services never write SQLite. maybePersistStableFlow()
// (called from the engine tick rail, 15min throttle) mirrors LIVE snapshots
// and events into StableFlowEvent via Prisma — deduped by watermark query.
//
// Doctrines encoded here:
//   · DEPEG-MUTE — |pegDev| ≥ 1% on ANY tracked stable = systemic liquidity
//     emergency → refuse new deploys fail-closed (tail-risk protection,
//     near-zero false-positive cost; the USDC-May2023 class of event).
//   · STABLE-REGIME — SHADOW ONLY: a RISK-OFF contraction is journaled as a
//     would-block so the shadow arms can ground-truth it; enforcement is a
//     separate operator decision (EngineSetting "stableflow.regimeGate").
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
;
;
;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "stable-feed");
const BOARD_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "board.json");
const EVENTS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "events.jsonl");
const DEPEG_MUTE_PCT = 1.0; // systemic emergency — enforced
const DEPEG_WARN_PCT = 0.5; // event-level only
const REGIME_ON_PCT = 0.5; // 7d total-supply growth = risk-on
const REGIME_OFF_PCT = -0.5; // 7d total-supply contraction = risk-off
const MINTBURN_USD = 150e6; // |Δ24h| per asset worth an event row
const BOARD_FRESH_MS = 40 * 60_000; // board older than this = stale
function parseBoard(raw) {
    if (!raw) return null;
    try {
        const b = JSON.parse(raw);
        if (typeof b?.at !== "number" || !Array.isArray(b?.assets)) return null;
        return b;
    } catch  {
        return null;
    }
}
function isBoardFresh(b) {
    return !!b && Date.now() - b.at < BOARD_FRESH_MS;
}
function depegMuted(b) {
    if (!b) return {
        muted: false,
        reason: "no stable board"
    };
    const worst = b.assets.map((a)=>({
            asset: a.asset,
            dev: a.pegDevPct
        })).filter((x)=>x.dev !== null && Math.abs(x.dev) >= DEPEG_MUTE_PCT).sort((x, y)=>Math.abs(y.dev) - Math.abs(x.dev))[0];
    if (!worst) return {
        muted: false,
        reason: "peg ok"
    };
    return {
        muted: true,
        reason: `${worst.asset} peg deviation ${worst.dev >= 0 ? "+" : ""}${worst.dev.toFixed(2)}% (≥ ±${DEPEG_MUTE_PCT}%) — systemic stablecoin liquidity emergency`
    };
}
function stableRegimeVerdict(b, direction) {
    if (b.regime === "RISK-OFF") {
        return {
            flag: direction === "LONG",
            note: `stable regime RISK-OFF (${b.regimeReason}) — LONG deploys are the flagged cohort`
        };
    }
    if (b.regime === "RISK-ON" && direction === "SHORT") {
        return {
            flag: false,
            note: `stable regime RISK-ON (${b.regimeReason}) — SHORT telemetry-only`
        };
    }
    return {
        flag: false,
        note: `stable regime ${b.regime}`
    };
}
// ── cached board reader (file-only, 10s TTL, fail-open) ─────────────────────
let boardCache = {
    at: 0,
    board: null
};
function getStableBoardSync() {
    if (Date.now() - boardCache.at < 10_000) return boardCache.board;
    let board = null;
    try {
        board = parseBoard((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BOARD_FILE, "utf8"));
    } catch  {
        board = null; // service absent / not booted yet — honest null
    }
    boardCache = {
        at: Date.now(),
        board
    };
    return board;
}
async function getStableBoard() {
    return getStableBoardSync();
}
function readRecentStableEvents(limit = 50) {
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(EVENTS_FILE, "utf8").trim();
        if (!raw) return [];
        const lines = raw.split("\n").slice(-limit);
        const out = [];
        for (const l of lines){
            try {
                out.push(JSON.parse(l));
            } catch  {
            /* skip torn line */ }
        }
        return out;
    } catch  {
        return [];
    }
}
// ── DB persistence (app-side; Prisma owns writes) ───────────────────────────
// Mirrors the service's board + recent events into StableFlowEvent. Watermark
// = MAX(ts) per source, so restarts never duplicate rows. Honest-null: any
// failure returns a quiet {ok:false} — never breaks the engine tick.
const PERSIST_MIN_MS = 15 * 60_000;
let lastPersistAt = 0;
let persisting = null;
async function maybePersistStableFlow(force = false) {
    if (!force && Date.now() - lastPersistAt < PERSIST_MIN_MS) return {
        ok: true,
        detail: "throttled"
    };
    if (persisting) return persisting;
    persisting = (async ()=>{
        try {
            const board = getStableBoardSync();
            if (!board || !isBoardFresh(board)) return {
                ok: false,
                detail: "no fresh board"
            };
            // watermark: newest LIVE snapshot ts already persisted
            const wm = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].stableFlowEvent.findFirst({
                where: {
                    source: "LIVE",
                    kind: "SNAPSHOT"
                },
                orderBy: {
                    ts: "desc"
                },
                select: {
                    ts: true
                }
            });
            const wmMs = wm?.ts ? new Date(wm.ts).getTime() : 0;
            if (board.at <= wmMs) return {
                ok: true,
                detail: "board already persisted"
            };
            const rows = [];
            const pct = (v)=>v === null ? null : Math.round(v * 1000) / 1000;
            // exact USD delta from a % move: Δ = mcap × (1 − 1/(1+pct/100))
            const usdFromPct = (mcap, p)=>mcap !== null && p !== null ? Math.round(mcap * (1 - 1 / (1 + p / 100))) : undefined;
            for (const a of board.assets){
                rows.push({
                    ts: new Date(board.at),
                    source: "LIVE",
                    kind: "SNAPSHOT",
                    asset: a.asset,
                    mcapUsd: a.mcapUsd ?? undefined,
                    delta1hUsd: usdFromPct(a.mcapUsd, a.delta1hPct),
                    delta24hUsd: a.delta24hUsd ?? usdFromPct(a.mcapUsd, a.delta24hPct),
                    delta7dUsd: usdFromPct(a.mcapUsd, a.delta7dPct),
                    pegDevPct: pct(a.pegDevPct) ?? undefined
                });
            }
            rows.push({
                ts: new Date(board.at),
                source: "LIVE",
                kind: "SNAPSHOT",
                asset: "TOTAL",
                mcapUsd: board.totalMcapUsd ?? undefined,
                delta24hUsd: usdFromPct(board.totalMcapUsd, board.totalDelta24hPct),
                delta7dUsd: usdFromPct(board.totalMcapUsd, board.totalDelta7dPct),
                regime: board.regime,
                note: board.regimeReason
            });
            // NOTE: Prisma 6 SQLite has no skipDuplicates — the watermark above is
            // the dedup guarantee (single app process + wmMs guard make this safe).
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].stableFlowEvent.createMany({
                data: rows
            });
            // events since the watermark — mirrored with kind preserved
            const evs = readRecentStableEvents(30).filter((e)=>e.ts > wmMs && e.ts <= Date.now());
            if (evs.length > 0) {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].stableFlowEvent.createMany({
                    data: evs.map((e)=>({
                            ts: new Date(e.ts),
                            source: "LIVE",
                            kind: e.kind,
                            asset: e.asset,
                            note: e.text.slice(0, 240)
                        }))
                });
            }
            lastPersistAt = Date.now();
            return {
                ok: true,
                detail: `persisted ${rows.length} snapshots + ${evs.length} events (wm ${new Date(wmMs).toISOString()})`
            };
        } catch (e) {
            return {
                ok: false,
                detail: String(e).slice(0, 120)
            };
        } finally{
            persisting = null;
        }
    })();
    return persisting;
}
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client-2c3a283f134fdcb6", () => require("@prisma/client-2c3a283f134fdcb6"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__5b3a6535._.js.map