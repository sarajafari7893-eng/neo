module.exports = [
"[project]/src/config/engine-flags.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"radarPrimary":true,"legacyAutoSpawn":true,"sensorBusDormant":false,"_comment":"TASK 19 OPERATOR MANDATE 2026-09-22/23: full de-restriction — legacy full-universe auto-spawn lane RESTORED alongside the radar lane, sensor bus display back on. Rollback: EngineSetting 'gate.rollback.v1022'."});}),
"[project]/src/app/api/pulse/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/triggers.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stats$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/stats.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)"); // v13.5 futures-WS liveness
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/regime.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volCause$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/volCause.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2d$flags$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine-flags.ts [app-route] (ecmascript)"); // v10.18 phased-consolidation flags
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$watchdog$2d$arm$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/watchdog-arm.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/telegram-bridge.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pump$2d$dump$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/pump-dump.ts [app-route] (ecmascript)"); // v9.0 PUMP/DUMP RADAR
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$golden$2d$lane$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/golden-lane.ts [app-route] (ecmascript)"); // Task 79 golden-formula paper lanes; v11.6 EQ-97 window-end adjudication
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$env$2d$guard$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/env-guard.ts [app-route] (ecmascript)"); // 2026-09-21 incident class: self-healing .env
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$daily$2d$scheduler$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/daily-scheduler.ts [app-route] (ecmascript)"); // self-driving Tehran-day reports
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const dynamic = "force-dynamic";
async function GET() {
    try {
        // resilience (egress-outage lesson 2026-09-07): the heartbeat must keep
        // flowing even when upstream exchanges hang — race the tick against a
        // deadline and let it finish in the background; this pulse answers with
        // last-known state instead of stalling the client.
        const tickP = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tick"])().catch(()=>undefined);
        await Promise.race([
            tickP,
            new Promise((r)=>setTimeout(r, 7000))
        ]);
        // v6.4 VOL-CAUSE capture rides the heartbeat — throttled to one run/3min
        // inside the lib; never blocks or breaks the pulse.
        // v10.18 PHASE-1 CONSOLIDATION: the peripheral sensor bus is DORMANT
        // (engine-flags.sensorBusDormant) — vol-cause capture (display + learned
        // telemetry) is suspended. The gate-critical inputs (vol-forecast, flow
        // gating, klines, liq stream) stay LIVE; one flag restores capture.
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2d$flags$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["engineFlags"])().sensorBusDormant) void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volCause$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["captureTopVolCauses"])();
        // P0 WATCHDOG self-arm (2026-09-09 ops mandate) — keeps the bun
        // p0-watchdog service (:3020) dormant-proof: if its lock pid is dead,
        // the pulse heartbeat re-runs watchdog-up.sh; fail-open + 60s throttle
        // inside the lib, ~1ms when healthy. The v6.2 dormancy lesson, closed.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$watchdog$2d$arm$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureP0Watchdog"])();
        // v8.3 TELEGRAM BRIDGE self-heal — if the getUpdates long-poll loop ever
        // dies silently, every heartbeat (keep-alive cron + dashboard) re-arms it.
        // Fail-open, ~0ms when healthy (global beat read only).
        try {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureBridgeLoopAlive"])();
        } catch  {
        /* never break the pulse */ }
        // ENV-GUARD (2026-09-21, incident ×3) — heals .env from the local plain
        // snapshot ring within ~1 probe minute of a platform erasure; internally
        // throttled to 60s, fail-soft, values never logged.
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$env$2d$guard$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["maybeEnsureEnv"])().catch(()=>undefined);
        // DAILY-SCHEDULER (2026-09-21) — self-driving Tehran-day DAILY + SRE
        // reports; removes the external platform-cron dependency for good.
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$daily$2d$scheduler$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["maybeRunScheduledReports"])().catch(()=>undefined);
        const [assets, signals, events, stats, liqStatus] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
                orderBy: {
                    volume24h: "desc"
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
                orderBy: {
                    createdAt: "desc"
                },
                take: 60
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.findMany({
                orderBy: {
                    createdAt: "desc"
                },
                take: 60
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stats$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["buildStats"])(),
            // v10.1 stability pass: secondary calls degrade to null instead of 500-ing
            // the whole heartbeat — the client keeps the last snapshot meanwhile.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getLiquidationStatus"])().catch(()=>null)
        ]);
        const feedStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFeedStatus"])();
        const flowStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFlowStatus"])();
        // auxiliary status calls: never let a radar/domain hiccup kill the pulse
        const scanDomain = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getScanDomain"])().catch(()=>null);
        // v14.0 — per-plane health across the FOUR Binance planes of the consensus
        // sweep persisted on assets (BINANCE / BINANCE-SPOT / BINANCE-FUTWS /
        // BINANCE-GCP) — one exchange, four independent network paths.
        // v14.1 — venue ⑤ TOOBIT: the REAL second exchange (public perp board).
        const exchanges = [
            "BINANCE",
            "BINANCE-SPOT",
            "BINANCE-FUTWS",
            "BINANCE-GCP",
            "TOOBIT"
        ].map((venue)=>{
            if (venue === "BINANCE") return {
                venue,
                ok: feedStatus.source === "LIVE" || feedStatus.source === "STALE",
                latencyMs: feedStatus.latencyMs
            };
            const withVenue = assets.find((a)=>{
                if (!a.exchanges) return false;
                try {
                    return JSON.parse(a.exchanges).some((q)=>q.venue === venue && q.price);
                } catch  {
                    return false;
                }
            });
            return {
                venue,
                ok: !!withVenue,
                latencyMs: null
            };
        });
        const snapshot = {
            ts: Date.now(),
            market: assets.map((a)=>({
                    ...a,
                    sparkline: JSON.parse(a.sparkline),
                    exchanges: a.exchanges ? JSON.parse(a.exchanges) : null
                })),
            signals: signals.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stats$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toSignalDTO"]),
            events: events.map((e)=>({
                    id: e.id,
                    signalId: e.signalId,
                    type: e.type,
                    symbol: e.symbol,
                    message: e.message,
                    level: e.level,
                    createdAt: e.createdAt.toISOString()
                })),
            stats,
            feed: {
                source: feedStatus.source,
                lastOkAt: feedStatus.lastOkAt,
                latencyMs: feedStatus.latencyMs,
                consecutiveFailures: feedStatus.consecutiveFailures,
                host: feedStatus.host,
                futws: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFutwsStatus"])(),
                exchanges,
                flow: flowStatus,
                liq: liqStatus ? {
                    online: true,
                    connected: liqStatus.connected,
                    dataStalled: liqStatus.dataStalled,
                    buffered: liqStatus.buffered,
                    lastEventAt: liqStatus.lastEventAt,
                    uptimeSec: liqStatus.uptimeSec
                } : null,
                triggers: {
                    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTriggerBusSummary"])(),
                    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getEngineTickInfo"])()
                },
                regimes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRegimeSummary"])(),
                universe: scanDomain,
                pump: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pump$2d$dump$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getPumpEngineStatus"])().catch(()=>null),
                goldenLane: ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$golden$2d$lane$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["maybeApplyExtension"])(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$golden$2d$lane$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["maybeRunGoldenLaneAdjudication"])().catch(()=>undefined), await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$golden$2d$lane$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGoldenLaneStatus"])().catch(()=>null))
            }
        };
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(snapshot, {
            headers: {
                "Cache-Control": "no-store"
            }
        });
    } catch (err) {
        console.error("[pulse] error", err);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "engine failure"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=src_da307df3._.js.map