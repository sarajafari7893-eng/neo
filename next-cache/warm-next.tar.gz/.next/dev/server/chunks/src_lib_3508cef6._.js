module.exports = [
"[project]/src/lib/verdict.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/verdict.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/pump-performance.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/pump-performance.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)");
    });
});
}),
];