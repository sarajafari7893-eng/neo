module.exports = [
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_MILESTONE_STEPS",
    ()=>RAWCAL_MILESTONE_STEPS,
    "RAWCAL_TELEMETRY_FILE",
    ()=>RAWCAL_TELEMETRY_FILE,
    "checkRawcalMilestones",
    ()=>checkRawcalMilestones,
    "checkRawcalStallAlarm",
    ()=>checkRawcalStallAlarm,
    "computeRawcalPace",
    ()=>computeRawcalPace,
    "milestoneView",
    ()=>milestoneView,
    "recentBlocks",
    ()=>recentBlocks,
    "recordRawcalSnapshot",
    ()=>recordRawcalSnapshot
]);
// ── v9.2 RAW-CAL PACE MONITOR — engineering observability for the capture run ──
// Operator mandate 2026-09-13: «پایش ریتم صدور RAW-CAL و رشد کتاب EPOCH-2 به
// سمت ۱۰۰. رو کامل و مهندسی انجام بده» — monitor the RAW-CAL issuance rhythm
// and the growth of the EPOCH-2 book toward the 100-settled calibration bar.
//
// THREE PERSISTED INSTRUMENTS:
//  1) SNAPSHOT JOURNAL — .data/rawcal-telemetry.jsonl, one row every ~10min
//     (self-throttled; force on state jumps): {t, issued, issuedTotal,
//     settledE2, openRaw, settledRaw, winsRaw, note?} — the book-growth curve
//     the UI sparkline and rate math read. Trimmed to the last 4000 rows.
//  2) PACE ENGINE — rolling rates from the journal + the DB ledger:
//     issue rate/h (3h + since-armed), settle rate/h (3h + 6h), observed mean
//     spacing between raw issues (DB createdAt diffs), ETA to the 100 bar at
//     the current settle rate, pipeline projection (open raw records that will
//     still settle), mean book settle-time, and stall detection.
//  3) MILESTONE LEDGER — idempotent audited events at 50/60/70/80/90/95/100
//     (EngineSetting "rawcal.milestones"); Telegram only for 90/95/100 (the
//     100 announcement itself stays with the auto-lift in raw-cal.ts).
//
// STALL SEMANTICS (honest, rail-aware):
//  · issue stall  = armed && openRaw < maxOpen && now − lastIssueAt >
//    max(45min, 3 × spacingMin) — issuance SHOULD have produced a record.
//  · settle stall = openRaw > 0 && no EPOCH-2 settle in the last 3h.
//  Neither fires when the open-cap rail is the legitimate blocker.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const RAWCAL_TELEMETRY_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-telemetry.jsonl");
const MILESTONES_KEY = "rawcal.milestones";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const RAWCAL_MILESTONE_STEPS = [
    50,
    60,
    70,
    80,
    90,
    95,
    100
];
const TELEGRAM_MILESTONES = new Set([
    90,
    95,
    100
]);
const MAX_JOURNAL_ROWS = 4000;
// ── memo caches (pulse-safe; these run on hot paths) ──
let lastSnapshotAt = 0;
let paceCache = null;
const PACE_TTL_MS = 30_000;
async function readJournal() {
    try {
        const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(RAWCAL_TELEMETRY_FILE, "utf8");
        const rows = [];
        for (const line of txt.split("\n")){
            const s = line.trim();
            if (!s) continue;
            try {
                rows.push(JSON.parse(s));
            } catch  {
            /* skip torn line */ }
        }
        return rows.slice(-MAX_JOURNAL_ROWS);
    } catch  {
        return [];
    }
}
async function appendJournal(row) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(RAWCAL_TELEMETRY_FILE), {
            recursive: true
        });
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(RAWCAL_TELEMETRY_FILE, JSON.stringify(row) + "\n", "utf8");
        // opportunistic trim (cheap: only when the file grows past 2× the cap)
        try {
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(RAWCAL_TELEMETRY_FILE);
            if (st.size > MAX_JOURNAL_ROWS * 180) {
                const rows = await readJournal();
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(RAWCAL_TELEMETRY_FILE, rows.slice(-MAX_JOURNAL_ROWS).map((r)=>JSON.stringify(r)).join("\n") + "\n", "utf8");
            }
        } catch  {
        /* trim best-effort */ }
    } catch (e) {
        console.error("[rawcal-telemetry] journal append failed", e);
    }
}
async function recordRawcalSnapshot(note, force = false) {
    const now = Date.now();
    if (!force && now - lastSnapshotAt < 10 * 60_000) return null;
    lastSnapshotAt = now;
    try {
        const [settledE2, openRaw, totalRaw, settledRaw, winsRaw] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: {
                        in: SETTLED_STATUSES
                    },
                    tags: {
                        contains: "EPOCH-2"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: [
                            "ACTIVE",
                            "TP1",
                            "TP2"
                        ]
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: SETTLED_STATUSES
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    reachedTp: {
                        gte: 1
                    }
                }
            })
        ]);
        const snap = {
            t: new Date(now).toISOString(),
            issued: 0,
            issuedTotal: totalRaw,
            settledE2,
            openRaw,
            settledRaw,
            winsRaw,
            ...note ? {
                note: note.slice(0, 80)
            } : {}
        };
        // issued-this-run: cheap read of the state key (no import cycle — raw-cal
        // imports telemetry, not vice versa)
        try {
            const s = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "rawcal.state"
                }
            });
            if (s) snap.issued = JSON.parse(s.value).issued ?? 0;
        } catch  {
        /* optional field */ }
        await appendJournal(snap);
        paceCache = null; // fresh data → invalidate pace memo
        return snap;
    } catch (e) {
        console.error("[rawcal-telemetry] snapshot failed", e);
        return null;
    }
}
async function computeRawcalPace(blocks) {
    if (paceCache && Date.now() - paceCache.at < PACE_TTL_MS && !blocks) return paceCache.data;
    const state = await getRawcalStateSafe();
    const now = Date.now();
    const [settledE2, openRaw, openE2, maxOpen] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        Promise.resolve(state.maxOpen)
    ]);
    const target = state.target;
    // issuance ledger (raw rows from the DB itself — ground truth)
    const rawRows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            createdAt: true
        },
        orderBy: {
            createdAt: "asc"
        }
    });
    const issueTimes = rawRows.map((r)=>r.createdAt.getTime());
    const h3 = now - 3 * 3600_000;
    const issues3h = issueTimes.filter((t)=>t >= h3).length;
    const armMs = state.armedAt ? new Date(state.armedAt).getTime() : null;
    const issuesSinceArm = armMs ? issueTimes.filter((t)=>t >= armMs).length : 0;
    const armHours = armMs ? Math.max(1 / 60, (now - armMs) / 3600_000) : null;
    const diffs = issueTimes.slice(1).map((t, i)=>t - issueTimes[i]);
    const meanDiff = diffs.length ? diffs.reduce((a, b)=>a + b, 0) / diffs.length : null;
    // book-growth ledger (EPOCH-2 settles with closedAt)
    const settles = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            },
            closedAt: {
                not: null
            }
        },
        select: {
            closedAt: true,
            createdAt: true
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const settleTimes = settles.map((r)=>r.closedAt.getTime()).reverse(); // asc
    const settles3h = settleTimes.filter((t)=>t >= h3).length;
    const settles6h = settleTimes.filter((t)=>t >= now - 6 * 3600_000).length;
    const recent20 = settles.slice(0, 20);
    const meanSettleMin = recent20.length ? recent20.reduce((a, r)=>a + (r.closedAt.getTime() - r.createdAt.getTime()), 0) / recent20.length / 60_000 : null;
    const [settledRaw, winsRaw] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: SETTLED_STATUSES
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                reachedTp: {
                    gte: 1
                }
            }
        })
    ]);
    const settleRate3h = settles3h / 3;
    const needed = Math.max(0, target - settledE2);
    const etaHours = needed === 0 ? 0 : settleRate3h > 0 ? needed / settleRate3h : null;
    // v9.2.1 steady-state projection — raw cadence ∩ settle-throughput cap.
    // throughputCap = maxOpen concurrent records / mean settle hours; the real
    // fill window is needed / min(issueCadence, throughputCap). Only computed
    // when meanSettleMin is known (honest — no invented throughput).
    const issueSinceArmRateRaw = armHours ? issuesSinceArm / armHours : 0;
    const throughputCapPerH = meanSettleMin !== null && meanSettleMin > 0 ? maxOpen / (meanSettleMin / 60) : null;
    const steadyRatePerH = throughputCapPerH !== null ? Math.min(issueSinceArmRateRaw, throughputCapPerH) : null;
    const etaSteadyHours = needed === 0 ? 0 : steadyRatePerH !== null && steadyRatePerH > 0 ? needed / steadyRatePerH : null;
    // stalls (rail-aware — see header)
    const issueStallMin = state.armed && openRaw < maxOpen && state.lastIssueAt ? Math.max(0, (now - new Date(state.lastIssueAt).getTime()) / 60_000) : null;
    const issueStallActive = issueStallMin !== null && issueStallMin > Math.max(45, 3 * state.spacingMin);
    const lastSettleAt = settleTimes.length ? settleTimes[settleTimes.length - 1] : null;
    const settleStallMin = openRaw > 0 && lastSettleAt ? Math.max(0, (now - lastSettleAt) / 60_000) : null;
    const settleStallActive = settleStallMin !== null && settleStallMin > 180;
    // cadence grade — honest banding of the ISSUE rhythm while armed.
    // v9.2.1 arm-age-aware: inside the first 3h after arming the 3h window still
    // contains pre-RAW-CAL filtered flow (rate lag) → grade on the since-arm
    // cadence instead; afterwards both windows agree and 3h is used.
    const issueRate3hPerH = issues3h / 3;
    let cadenceGrade = "OFF";
    if (state.armed) {
        const baseRate = armHours !== null && armHours < 3 ? issueSinceArmRateRaw : issueRate3hPerH;
        const effRate = issueStallActive ? 0 : baseRate;
        cadenceGrade = effRate >= 3 ? "A" : effRate >= 1.5 ? "B" : effRate >= 0.5 ? "C" : "D";
    }
    // sparkline from the journal (downsample to ≤48 points)
    // v9.4.2 NaN guard: journal gap rows can carry non-finite settledE2 — skip
    // them here so the client never receives NaN chart values.
    const journal = await readJournal();
    const series = journal.length > 1 ? journal : journal.length === 1 ? [
        {
            t: new Date(now).toISOString(),
            settledE2
        }
    ] : [];
    const step = Math.max(1, Math.ceil(series.length / 48));
    const sparkline = [];
    for(let i = 0; i < series.length; i += step){
        const v = series[i].settledE2;
        if (!Number.isFinite(v)) continue;
        sparkline.push({
            t: series[i].t,
            v
        });
    }
    if (sparkline.length && Number.isFinite(settledE2) && sparkline[sparkline.length - 1].v !== settledE2) sparkline.push({
        t: new Date(now).toISOString(),
        v: settledE2
    });
    const lastBlockNote = blocks && blocks.length ? blocks[blocks.length - 1].note : null;
    const pace = {
        armed: state.armed,
        armedAt: state.armedAt,
        settledE2,
        needed,
        target,
        issueRate3hPerH: round2(issueRate3hPerH),
        issueRateSinceArmPerH: armHours ? round2(issuesSinceArm / armHours) : 0,
        observedSpacingMin: {
            mean: meanDiff !== null ? round2(meanDiff / 60_000) : null,
            min: diffs.length ? round2(Math.min(...diffs) / 60_000) : null,
            max: diffs.length ? round2(Math.max(...diffs) / 60_000) : null,
            samples: diffs.length
        },
        lastIssueAt: state.lastIssueAt,
        lastIssueSerial: state.lastIssueSerial,
        openRaw,
        openE2,
        maxOpen,
        spacingMin: state.spacingMin,
        settleRate3hPerH: round2(settleRate3h),
        settleRate6hPerH: round2(settles6h / 6),
        meanSettleMin: meanSettleMin !== null ? Math.round(meanSettleMin) : null,
        winsRaw,
        settledRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        etaHours: etaHours !== null ? round2(etaHours) : null,
        etaAt: etaHours !== null ? new Date(now + etaHours * 3600_000).toISOString() : null,
        steadyRatePerH: steadyRatePerH !== null ? round2(steadyRatePerH) : null,
        etaSteadyHours: etaSteadyHours !== null ? round2(etaSteadyHours) : null,
        etaSteadyAt: etaSteadyHours !== null ? new Date(now + etaSteadyHours * 3600_000).toISOString() : null,
        pipelineProjection: settledE2 + openE2,
        cadenceGrade,
        stalls: {
            issueStallMin: issueStallActive ? Math.round(issueStallMin) : null,
            settleStallMin: settleStallActive ? Math.round(settleStallMin) : null,
            lastBlockNote
        },
        sparkline,
        journalRows: journal.length
    };
    if (!blocks) paceCache = {
        at: Date.now(),
        data: pace
    };
    return pace;
}
async function getRawcalStateSafe() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return await getRawCalState();
    } catch  {
        return {
            armed: false,
            armedAt: null,
            lastIssueAt: null,
            lastIssueSerial: null,
            target: 100,
            spacingMin: 12,
            maxOpen: 8
        };
    }
}
function round2(n) {
    return Math.round(n * 100) / 100;
}
// ── MILESTONE LEDGER ──
async function readMilestones() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: MILESTONES_KEY
            }
        });
        if (!row) return {
            fired: {}
        };
        return JSON.parse(row.value);
    } catch  {
        return {
            fired: {}
        };
    }
}
async function checkRawcalMilestones() {
    const settledE2 = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    }).catch(()=>0);
    const m = await readMilestones();
    const firedNow = [];
    for (const step of RAWCAL_MILESTONE_STEPS){
        const key = String(step);
        if (settledE2 < step || m.fired[key]) continue;
        const at = new Date().toISOString();
        m.fired[key] = at;
        firedNow.push({
            step,
            at
        });
        const isBar = step === 100;
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", `RAW-CAL MILESTONE ${step}/${100} — EPOCH-2 book at ${settledE2} settled${isBar ? " — calibration bar REACHED, capture mode hands back to central-intelligence command (new calibration)" : ` · ${100 - settledE2} records remain to the AI CALIBRATION bar`}`).catch(()=>undefined);
        if (TELEGRAM_MILESTONES.has(step) && !(isBar && stateHasAutoLift())) {
            const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
            void sendDirect(`📈 <b>RAW-CAL MILESTONE ${step}/100</b>\nEPOCH-2 book: <b>${settledE2}/100</b> settled${isBar ? " — AI CALIBRATION lift imminent" : ` · ${100 - settledE2} to go`}\n${progressBar(settledE2)}`).catch(()=>undefined);
        }
    }
    if (firedNow.length) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: MILESTONES_KEY
            },
            create: {
                key: MILESTONES_KEY,
                value: JSON.stringify(m)
            },
            update: {
                value: JSON.stringify(m)
            }
        }).catch(()=>undefined);
    }
    return firedNow;
}
async function stateHasAutoLift() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return !!(await getRawCalState()).autoLiftAt;
    } catch  {
        return false;
    }
}
function progressBar(n) {
    const filled = Math.round(Math.min(100, n) / 100 * 20);
    return "▰".repeat(filled) + "▱".repeat(20 - filled);
}
async function milestoneView() {
    const [m, settledE2] = await Promise.all([
        readMilestones(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }).catch(()=>0)
    ]);
    return {
        steps: RAWCAL_MILESTONE_STEPS.map((step)=>({
                step,
                fired: !!m.fired[String(step)],
                at: m.fired[String(step)] ?? null,
                pending: settledE2 < step
            })),
        settledE2
    };
}
async function recentBlocks(n = 12) {
    try {
        const { getRawCalBlocks } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return getRawCalBlocks(n);
    } catch  {
        return [];
    }
}
// ── v9.2.1 STALL ALARM — push the rhythm break, don't just display it ──
// Tick hook (idempotent, 2h cooldown per stall type). Fires when the armed
// issuer SHOULD have produced (issue stall) or the in-flight pipeline SHOULD
// have settled (settle stall) and didn't. Process-death is covered by the P0
// watchdog + keep-alive crons; this alarm covers "alive but rhythm broken".
const STALL_ALERT_KEY = "rawcal.stallAlerts";
const STALL_COOLDOWN_MS = 2 * 3600_000;
async function checkRawcalStallAlarm() {
    try {
        const pace = await computeRawcalPace().catch(()=>null);
        if (!pace || !pace.armed) return false;
        const issues = [];
        if (pace.stalls.issueStallMin) issues.push(`issue stall — no raw record for ${pace.stalls.issueStallMin}min while armed and open ${pace.openRaw}/${pace.maxOpen}`);
        if (pace.stalls.settleStallMin) issues.push(`settle stall — no EPOCH-2 settle for ${pace.stalls.settleStallMin}min with ${pace.openRaw} raw in flight`);
        if (!issues.length) return false;
        let fired = {};
        try {
            const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: STALL_ALERT_KEY
                }
            });
            if (row) fired = JSON.parse(row.value).fired ?? {};
        } catch  {
        /* fresh ledger */ }
        const now = Date.now();
        const send = [];
        for (const it of issues){
            const k = it.startsWith("issue") ? "issue" : "settle";
            const last = fired[k] ? new Date(fired[k]).getTime() : 0;
            if (now - last > STALL_COOLDOWN_MS) {
                fired[k] = new Date(now).toISOString();
                send.push(it);
            }
        }
        if (!send.length) return false;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: STALL_ALERT_KEY
            },
            create: {
                key: STALL_ALERT_KEY,
                value: JSON.stringify({
                    fired
                })
            },
            update: {
                value: JSON.stringify({
                    fired
                })
            }
        }).catch(()=>undefined);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL PACE ALARM — ${send.join(" · ")} · book ${pace.settledE2}/${pace.target} · cadence ${pace.cadenceGrade}`).catch(()=>undefined);
        const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
        void sendDirect(`⏱ <b>RAW-CAL PACE ALARM</b>\n${send.map((s)=>`• ${s}`).join("\n")}\n📊 Book: <b>${pace.settledE2}/${pace.target}</b> settled · cadence ${pace.cadenceGrade} · open raw ${pace.openRaw}/${pace.maxOpen}`).catch(()=>undefined);
        return true;
    } catch  {
        return false;
    }
}
}),
"[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeRawcalQuality",
    ()=>computeRawcalQuality,
    "r6GateLine",
    ()=>r6GateLine,
    "readPersistedQuality",
    ()=>readPersistedQuality,
    "recordRawcalQuality",
    ()=>recordRawcalQuality
]);
// ── v9.3 RAW-CAL SAMPLE QUALITY LAB — data-health gate for the R6 recalibration ──
// Operator mandate 2026-09-13: «پس از تسویه اولین RAW-CALها (~1-2h) میتوانیم
// کیفیت نمونه‌های خام را هم بررسی کنیم تا کالیبراسیون R6 روی داده سالم بنشیند»
// — after the first RAW-CALs settle, review the quality of the raw samples so
// the R6 calibration rests on HEALTHY data.
//
// WHAT IT MEASURES (every RAW-CAL-tagged ledger row, 100% from the DB):
//  · CAPTURE INTEGRITY (0-30): deploy audit snapshots preserved — factorsJson
//    (confluence votes, 12) / flowJson (order-flow, 9) / mtfJson (multi-TF
//    board, 9). R6 attributes outcomes to factors; a row born without its
//    snapshots can never be attributed, so absence is scored, not forgiven.
//  · PLAN COMPLETENESS (0-20): entry/stop/TP ladder present and
//    direction-consistent, RR > 0, TTL sane — a malformed plan is a malformed
//    sample no matter how it settles.
//  · OUTCOME INFORMATIVENESS (0-30): TP1/TP2/TP3 or SL = fully informative
//    (price proved or disproved the plan — losses are the most instructive
//    rows); EXPIRED with a TP touch = partially informative; EXPIRED with no
//    touch = time-censored (low information); manual CLOSED = censored.
//  · REPRESENTATIVENESS (0-20): spacing ≥ the anti-flood rail (burst-cluster
//    rows are correlated and would inflate calibration confidence), hold time
//    inside the TTL envelope, extension abuse flagged.
// Composite 0-100 → HEALTHY ≥75 · REVIEW 50-74 · CENSORED <50 (PENDING while
// the row is still open).
//
// COHORT HEALTH → R6 GATE: healthy% of the settled raw cohort vs the 85%
// health floor, informative ratio, symbol concentration, side balance,
// snapshot completeness — verdict GREEN / AMBER / RED (WARMING before the
// first settles) with explicit blockers. The gate ADVISES the R6 lift and the
// central intelligence (engine memory + governor context); it NEVER edits the
// calibration math itself (no post-hoc tampering — honest instrumentation).
//
// PERSISTENCE: EngineSetting "rawcal.quality" (compact digest, cross-process)
// + QUALITY rows appended to .data/rawcal-telemetry.jsonl (10min throttle,
// forced the moment the settled-raw count moves — the settle curve of the
// QUALITY of the book, not just its size).
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)");
;
;
;
;
const QUALITY_KEY = "rawcal.quality";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const OPEN_STATUSES = [
    "ACTIVE",
    "TP1",
    "TP2"
];
const HEALTH_FLOOR = 85; // R6 health floor — healthy% of the settled raw cohort
const MAX_JOURNAL_ROWS = 4000;
// ── v10.9 POST-FILTER COHORT (SUPERVISOR proposal 22:55Z, operator-approved
// 2026-09-15 «دستورات سوپروایزر را کامل و مهندسی انجام بده») — before/after
// split around the decisive-excursion filter go-live (first live skip TAOUSDT
// 11:31:27Z, worklog OP-V106-ROOTCAUSE-20260915T1134Z). The blended window is
// dominated by the legacy expired-no-touch stock, so the filter's true effect
// on outcome informativeness is measured on its OWN cohort. Censoring-aware
// pre/post design (gov.uk before-after guidance; Prinja 2010, Turkson 2021).
const FILTER_ERA_START_MS = Date.parse("2026-09-15T11:30:00.000Z");
// ── v10.9.2 EXPIRY-CAUSE ATTRIBUTION (SUPERVISOR proposal, operator-approved
// via bridge 2026-09-16T11:18Z «دستورات سوپروایزر را تایید می کنم») — the gate
// verdict is hostage to expired-no-touch censoring (informative 37.7% blended):
// R6 cannot attribute outcomes when a trade never reaches TP1 or SL. Each
// EXPIRED-no-touch row is now split by its MAX FAVORABLE EXCURSION in R units
// (mfeR = (maxPnlPercent/leverage) / stopDistancePct — existing journal fields,
// zero new capture): WRONG-SIDE (mfeR < 0.25 — price never followed the plan;
// entry direction/timing problem, NOT a TTL problem) vs NO-FOLLOW (mfeR ≥ 0.6 —
// meaningful follow that stalled before TP1; barrier/TP geometry too far for
// realized excursion) vs MIXED (in between). The gate can now NAME the dominant
// expiry cause, and the VOL-BARRIER mult/cap knobs get a direct feedback signal
// (no-follow dominance → tighten barrier; wrong-side dominance → entry filter
// problem). Reporting-layer only — scoring, scan and issue logic untouched.
const EXP_WRONG_SIDE_R = 0.25; // below: never followed — wrong side / late entry
const EXP_NO_FOLLOW_R = 0.6; // above: followed then stalled — geometry too far
// ── v10.9.1 EPOCH-WINDOWED GATE VERDICT (SUPERVISOR proposal, operator blanket-
// approve 2026-09-16T09:03Z «تمام اقدامات و پیشنهادات SUPERVISOR را تایید
// می‌کنم — کامل و مهندسی انجام بده») — the gate verdict is computed on the
// POST-FILTER EPOCH WINDOW, not the blended all-time cohort. The blended
// window is dominated by legacy expired-no-touch stock (metric regime-bias:
// 37.7% blended vs 56% post-filter informative at approval time), so the
// all-time ratio can never turn GREEN even when the CURRENT engine regime is
// decisively healthier. GREEN now requires the epoch window to prove itself:
// window informative ≥50% AND window settled n≥20. Structural integrity
// (snapshots) stays whole-cohort — a row born without snapshots is era-
// independent damage. The healthy-floor check rides the window too (AMBER,
// not RED). VERDICT-ONLY change: scoring, cohort measurement, scan/issue
// logic all untouched — the digest still reports the blended ratios for the
// whole book (honest instrumentation), only the VERDICT anchor moved.
const GATE_WINDOW_MIN_N = 20; // settled rows the window needs before GREEN is reachable
const GATE_WINDOW_FORMING = 3; // below this the window is WARMING, not judged
const GATE_WINDOW_INFORMATIVE = 50; // GREEN bar for the window informative ratio
const GATE_WINDOW_WARN_N = 8; // window small-sample guard for the informative blocker
// ── memo cache (runs on hot paths) ──
let qualityCache = null;
const QUALITY_TTL_MS = 30_000;
let lastJournalAt = 0;
let lastSeenSettled = -1;
function safeParse(json) {
    if (!json || !json.trim()) return false;
    try {
        const v = JSON.parse(json);
        return v !== null && (typeof v !== "object" || Array.isArray(v) ? v.length > 0 : Object.keys(v).length > 0);
    } catch  {
        return false;
    }
}
function round1(n) {
    return Math.round(n * 10) / 10;
}
function pct(part, whole) {
    return whole > 0 ? round1(part / whole * 100) : null;
}
/** Score ONE raw ledger row against the four quality dimensions. */ function scoreSample(row, prevCreatedAt, spacingMin) {
    const flags = [];
    const settled = SETTLED_STATUSES.includes(row.status);
    const open = OPEN_STATUSES.includes(row.status);
    // ── A) capture integrity — the deploy audit snapshots R6 will attribute to (0-30)
    let integrity = 0;
    if (safeParse(row.factorsJson)) integrity += 12;
    else flags.push("no-factors");
    if (safeParse(row.flowJson)) integrity += 9;
    else flags.push("no-flow");
    if (safeParse(row.mtfJson)) integrity += 9;
    else flags.push("no-mtf");
    // ── B) plan completeness — entry/stop/ladder coherent (0-20)
    let plan = 0;
    if (row.entryPrice > 0) plan += 2;
    if (row.stopLoss > 0) plan += 3;
    else flags.push("no-stop");
    if (row.tp1 > 0 && row.tp2 > 0 && row.tp3 > 0) plan += 3;
    else flags.push("ladder-short");
    const long = row.direction === "LONG";
    const ladderOk = long ? row.tp1 > row.entryPrice && row.stopLoss < row.entryPrice : row.direction === "SHORT" ? row.tp1 < row.entryPrice && row.stopLoss > row.entryPrice : false;
    if (ladderOk) plan += 6;
    else flags.push("ladder-inconsistent");
    if (row.riskReward > 0) plan += 2;
    if (row.ttlMinutes > 0 && row.expiresAt.getTime() > row.createdAt.getTime()) plan += 4;
    else flags.push("ttl-bad");
    // ── C) outcome informativeness — what did the settle actually teach (0-30)
    let outcome = 0;
    if (settled) {
        if ([
            "TP1",
            "TP2",
            "TP3"
        ].includes(row.status)) outcome = 30;
        else if (row.status === "SL") outcome = 30;
        else if (row.status === "EXPIRED") {
            if (row.reachedTp >= 1) outcome = 20;
            else {
                outcome = 8;
                flags.push("expired-no-touch"); // time-censored — weakest calibration row
                // v10.9.2 expiry-cause attribution — MFE in R units names WHY it censored
                const slPct = row.entryPrice > 0 ? Math.abs(row.stopLoss - row.entryPrice) / row.entryPrice * 100 : 0;
                if (slPct > 0 && row.leverage > 0) {
                    const mfeR = row.maxPnlPercent / row.leverage / slPct;
                    if (mfeR < EXP_WRONG_SIDE_R) flags.push("expired-wrong-side");
                    else if (mfeR >= EXP_NO_FOLLOW_R) flags.push("expired-no-follow");
                } // slPct/leverage degenerate → cause unknown, censoring flag alone stands
            }
        } else if (row.status === "CLOSED") {
            outcome = 10;
            flags.push("manual-close");
        }
    } else if (!open) {
        flags.push("status-odd");
    }
    // ── D) representativeness — spacing rail + TTL envelope (0-20)
    let timing = 0;
    let spacingOk = null;
    if (prevCreatedAt) {
        const gapMin = (row.createdAt.getTime() - prevCreatedAt.getTime()) / 60_000;
        spacingOk = gapMin >= spacingMin * 0.98;
        if (spacingOk) timing += 10;
        else {
            timing += 4;
            flags.push("cluster-spawn");
        }
    } else {
        timing += 10; // first record of the cohort — no spacing to violate
    }
    if (settled && row.closedAt) {
        const envelope = row.ttlMinutes * (1 + 0.25 * row.ttlExtensions) + 5;
        const holdMin = (row.closedAt.getTime() - row.createdAt.getTime()) / 60_000;
        if (holdMin <= envelope) timing += 10;
        else flags.push("hold-overrun");
        if (row.ttlExtensions >= 3) flags.push(`ttl-ext×${row.ttlExtensions}`);
    } else if (!settled) {
        timing += 10; // hold envelope not yet measurable — neutral until settle
    }
    const score = Math.round(integrity + plan + outcome + timing);
    const cls = open ? "PENDING" : score >= 75 ? "HEALTHY" : score >= 50 ? "REVIEW" : "CENSORED";
    return {
        serial: row.serial,
        symbol: row.symbol,
        direction: row.direction,
        strategy: row.strategy,
        status: row.status,
        settled,
        pnlPercent: round1(row.pnlPercent),
        holdMin: row.closedAt ? Math.round((row.closedAt.getTime() - row.createdAt.getTime()) / 60_000) : null,
        score,
        cls,
        flags,
        spacingOk
    };
}
async function computeRawcalQuality() {
    if (qualityCache && Date.now() - qualityCache.at < QUALITY_TTL_MS) return qualityCache.data;
    let spacingMin = 12;
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        spacingMin = (await getRawCalState()).spacingMin;
    } catch  {
    /* default rail */ }
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            symbol: true,
            direction: true,
            strategy: true,
            status: true,
            reachedTp: true,
            pnlPercent: true,
            ttlMinutes: true,
            ttlExtensions: true,
            entryPrice: true,
            tp1: true,
            tp2: true,
            tp3: true,
            stopLoss: true,
            riskReward: true,
            leverage: true,
            maxPnlPercent: true,
            expiresAt: true,
            createdAt: true,
            closedAt: true,
            factorsJson: true,
            flowJson: true,
            mtfJson: true
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 200
    });
    const asc = [
        ...rows
    ].reverse(); // asc for spacing diffs
    const scored = asc.map((r, i)=>scoreSample(r, i > 0 ? asc[i - 1].createdAt : null, spacingMin));
    const settledSamples = scored.filter((s)=>s.settled);
    const settledRaw = settledSamples.length;
    const openRaw = scored.filter((s)=>!s.settled).length;
    const healthy = settledSamples.filter((s)=>s.cls === "HEALTHY").length;
    const review = settledSamples.filter((s)=>s.cls === "REVIEW").length;
    const censored = settledSamples.filter((s)=>s.cls === "CENSORED").length;
    const healthyPct = pct(healthy, settledRaw);
    // informative = fully readable outcome: TP/SL proved the plan, or EXPIRED
    // after a TP touch (partially readable). EXPIRED-no-touch / CLOSED excluded.
    const informativePct = pct(settledSamples.filter((s)=>[
            "TP1",
            "TP2",
            "TP3",
            "SL"
        ].includes(s.status) || s.status === "EXPIRED" && !s.flags.includes("expired-no-touch")).length, settledRaw);
    const expiredNoTouch = settledSamples.filter((s)=>s.flags.includes("expired-no-touch")).length;
    const expiryCauses = {
        wrongSide: expiredNoTouch ? settledSamples.filter((s)=>s.flags.includes("expired-wrong-side")).length : 0,
        noFollow: expiredNoTouch ? settledSamples.filter((s)=>s.flags.includes("expired-no-follow")).length : 0,
        mixed: 0
    };
    expiryCauses.mixed = Math.max(0, expiredNoTouch - expiryCauses.wrongSide - expiryCauses.noFollow);
    // ── post-filter cohort — reuses the cohort-consistent scores (spacing vs true
    // predecessor) by index alignment with `asc`, not a re-scored sub-list.
    const postScored = asc.map((r, i)=>r.createdAt.getTime() >= FILTER_ERA_START_MS ? scored[i] : null).filter((s)=>s !== null);
    const postSettled = postScored.filter((s)=>s.settled);
    const postInformativePct = pct(postSettled.filter((s)=>[
            "TP1",
            "TP2",
            "TP3",
            "SL"
        ].includes(s.status) || s.status === "EXPIRED" && !s.flags.includes("expired-no-touch")).length, postSettled.length);
    const postExpiryRatePct = pct(postSettled.filter((s)=>s.flags.includes("expired-no-touch")).length, postSettled.length);
    const postFilterCohort = {
        since: new Date(FILTER_ERA_START_MS).toISOString(),
        n: postScored.length,
        settled: postSettled.length,
        informativePct: postInformativePct,
        expiryRatePct: postExpiryRatePct
    };
    const snapshotOk = scored.filter((s)=>!s.flags.includes("no-factors") && !s.flags.includes("no-flow") && !s.flags.includes("no-mtf")).length;
    const snapshotPct = pct(snapshotOk, scored.length);
    const symAcc = new Map();
    let longs = 0;
    for (const s of settledSamples){
        symAcc.set(s.symbol, (symAcc.get(s.symbol) ?? 0) + 1);
        if (s.direction === "LONG") longs++;
    }
    const symbols = symAcc.size;
    const topSymbolShare = symbols ? Math.max(...symAcc.values()) / settledRaw * 100 : null;
    const longPct = pct(longs, settledRaw);
    const shortPct = longPct !== null ? round1(100 - longPct) : null;
    const holds = settledSamples.map((s)=>s.holdMin).filter((h)=>h !== null);
    const meanAbsPnl = settledRaw ? round1(settledSamples.reduce((a, s)=>a + Math.abs(s.pnlPercent), 0) / settledRaw) : null;
    const meanHoldMin = holds.length ? Math.round(holds.reduce((a, b)=>a + b, 0) / holds.length) : null;
    const clusterCount = scored.filter((s)=>s.flags.includes("cluster-spawn")).length;
    // ── warnings (priority-ordered, sample-size-guarded — no noise at n=1) ──
    const warnings = [];
    if (settledRaw >= 3 && informativePct !== null && informativePct < 70) warnings.push(`informative ratio ${informativePct}% < 70% — EXPIRED censoring weakens R6 factor attribution`);
    if (settledRaw >= 5 && topSymbolShare !== null && topSymbolShare > 40) warnings.push(`symbol concentration ${round1(topSymbolShare)}% in one market — R6 may overfit`);
    if (settledRaw >= 5 && (longPct === null || shortPct === null || Math.max(longPct, shortPct ?? 0) > 75)) warnings.push(`side imbalance ${longPct ?? "—"}L/${shortPct ?? "—"}S — thin counter-direction evidence`);
    if (scored.length >= 2 && snapshotPct !== null && snapshotPct < 80) warnings.push(`deploy snapshots complete on ${snapshotPct}% of the cohort — factor attribution degraded`);
    if (clusterCount >= 2) warnings.push(`${clusterCount} records issued inside the ${spacingMin}min rail — burst cluster, correlated samples`);
    if (settledRaw >= 3 && healthyPct !== null && healthyPct < HEALTH_FLOOR) warnings.push(`healthy ${healthyPct}% below the ${HEALTH_FLOOR}% R6 floor`);
    // ── R6 gate verdict — v10.9.1 EPOCH-WINDOWED ──
    // Blocker 1 (structural, whole-cohort): snapshot integrity — era-independent.
    // Blocker 2 (regime, epoch window): window informative ratio below the GREEN
    // bar, only judged once the window carries enough settled rows (≥20) to be
    // statistically meaningful; below the warn-n the window is guarded, not
    // punished (small-sample informative dips are noise, not censoring).
    const blockers = [];
    const winSettled = postSettled.length;
    const winHealthyPct = pct(postSettled.filter((s)=>s.cls === "HEALTHY").length, winSettled);
    if (scored.length >= 2 && snapshotPct !== null && snapshotPct < 50) blockers.push(`snapshots complete on only ${snapshotPct}%`);
    if (winSettled >= GATE_WINDOW_WARN_N && postInformativePct !== null && postInformativePct < GATE_WINDOW_INFORMATIVE) blockers.push(`epoch-window informative ${postInformativePct}% < 50% (n=${winSettled}) — censoring regime`);
    const verdict = settledRaw === 0 || winSettled < GATE_WINDOW_FORMING ? "WARMING" // honest: the window has nothing meaningful to grade yet
     : blockers.length > 0 ? "RED" : winSettled < GATE_WINDOW_MIN_N || winHealthyPct !== null && winHealthyPct < HEALTH_FLOOR ? "AMBER" // window formed but short of the GREEN bar or the health floor
     : "GREEN";
    // UI samples view: settled cohort first (newest first), then in-flight
    const desc = [
        ...scored
    ].reverse();
    const samples = [
        ...desc.filter((s)=>s.settled),
        ...desc.filter((s)=>!s.settled)
    ].slice(0, 12);
    const digest = {
        at: new Date().toISOString(),
        issuedTotal: scored.length,
        openRaw,
        settledRaw,
        healthy,
        review,
        censored,
        healthyPct,
        informativePct,
        expiredNoTouch,
        expiryCauses,
        snapshotPct,
        symbols,
        topSymbolShare: topSymbolShare !== null ? round1(topSymbolShare) : null,
        longPct,
        shortPct,
        meanAbsPnl,
        meanHoldMin,
        clusterCount,
        warnings: warnings.slice(0, 5),
        gate: {
            verdict,
            healthFloor: HEALTH_FLOOR,
            blockers,
            window: {
                since: postFilterCohort.since,
                settled: winSettled,
                healthyPct: winHealthyPct,
                informativePct: postInformativePct
            }
        },
        postFilterCohort,
        samples
    };
    qualityCache = {
        at: Date.now(),
        data: digest
    };
    return digest;
}
function r6GateLine(d) {
    const w = d.gate.window;
    const base = `R6 DATA HEALTH (v10.9.1 epoch-windowed gate — verdict anchors the post-filter window, blended ratios reported for the whole book): raw cohort ${d.settledRaw} settled/${d.issuedTotal} issued · blended healthy ${d.healthyPct ?? "—"}% (floor ${d.gate.healthFloor}) · blended informative ${d.informativePct ?? "—"}% · snapshots ${d.snapshotPct ?? "—"}% · GATE ${d.gate.verdict}` + (w ? ` — window n=${w.settled} informative ${w.informativePct ?? "—"}% healthy ${w.healthyPct ?? "—"}%` : "") + (d.gate.verdict === "WARMING" ? " (window still forming — grading starts at the first window settles)" : "") + (d.gate.blockers.length ? ` · blockers: ${d.gate.blockers.join("; ")}` : "");
    const causes = d.expiryCauses && d.expiryCauses.wrongSide + d.expiryCauses.noFollow + d.expiryCauses.mixed > 0 ? ` · expiry causes: wrong-side ${d.expiryCauses.wrongSide} / no-follow ${d.expiryCauses.noFollow} / mixed ${d.expiryCauses.mixed} (of ${d.expiredNoTouch} no-touch)` : "";
    const post = d.postFilterCohort && d.postFilterCohort.n > 0 ? ` · post-filter cohort n=${d.postFilterCohort.n} (settled ${d.postFilterCohort.settled}) informative ${d.postFilterCohort.informativePct ?? "—"}% expiry ${d.postFilterCohort.expiryRatePct ?? "—"}%` : "";
    return base + causes + post + (d.warnings.length ? ` — watch: ${d.warnings[0]}` : " — no issues");
}
/** Compact digest for EngineSetting persistence (no samples array). */ function compact(d) {
    const { samples: _samples, ...rest } = d;
    void _samples;
    return rest;
}
async function recordRawcalQuality() {
    try {
        const digest = await computeRawcalQuality();
        const changed = digest.settledRaw !== lastSeenSettled;
        if (!changed && Date.now() - lastJournalAt < 10 * 60_000) return null;
        lastJournalAt = Date.now();
        lastSeenSettled = digest.settledRaw;
        const c = compact(digest);
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: QUALITY_KEY
            },
            create: {
                key: QUALITY_KEY,
                value: JSON.stringify(c)
            },
            update: {
                value: JSON.stringify(c)
            }
        }).catch(()=>undefined);
        try {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"]), {
                recursive: true
            });
            const row = {
                kind: "QUALITY",
                t: digest.at,
                issued: digest.issuedTotal,
                settled: digest.settledRaw,
                healthyPct: digest.healthyPct,
                informativePct: digest.informativePct,
                snapshotPct: digest.snapshotPct,
                gate: digest.gate.verdict,
                warns: digest.warnings.length
            };
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], JSON.stringify(row) + "\n", "utf8");
            // opportunistic trim (same policy as the pace journal)
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"]).catch(()=>null);
            if (st && st.size > MAX_JOURNAL_ROWS * 180) {
                const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], "utf8").catch(()=>"");
                const lines = txt.split("\n").filter(Boolean).slice(-MAX_JOURNAL_ROWS);
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], lines.join("\n") + "\n", "utf8").catch(()=>undefined);
            }
        } catch  {
        /* journal best-effort */ }
        return digest;
    } catch (e) {
        console.error("[rawcal-quality] record failed", e);
        return null;
    }
}
async function readPersistedQuality() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: QUALITY_KEY
            }
        });
        if (!row) return null;
        return JSON.parse(row.value);
    } catch  {
        return null;
    }
}
}),
"[project]/src/lib/calibration.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeCalibration",
    ()=>computeCalibration,
    "ensureCalibrationFrozen",
    ()=>ensureCalibrationFrozen,
    "getCalibration",
    ()=>getCalibration,
    "getEffectiveWeights",
    ()=>getEffectiveWeights,
    "refreshCalibration",
    ()=>refreshCalibration
]);
// ── FlowRadar Neo factor-weight calibration (server-only) ──
// v6.3 PROFIT-FIRST CALIBRATION (operator mandate: «کالیبراتور با معیار سود،
// نه تعداد برد»): factor weights are driven by NET PNL expectancy, not raw
// win rate. A factor that wins 44% of the time but bleeds -13%/trade on its
// losers is a LIABILITY (measured: BREAKOUT cohort) — raw WR could not see
// that; expectancy can. Per factor (strong votes only, n≥10 floor):
//
//   expectancy_f = Σ pnlPercent / n          (avg %/trade attributed)
//   profitFactor_f = Σ wins$ / |Σ losses$|   (gross wins ÷ gross losses)
//   weight_f = clamp(1 + expectancy/15 + 0.15·tanh(PF−1), 0.70, 1.30)
//
// Monotone in profit: +4.5%/trade ≈ +0.3 weight, 0%/trade ≈ 1.0, losers sink.
// Calibration goes ACTIVE at ≥30 settled signals, otherwise OBSERVING.
//
// v10.16 R6 QUALITY GATE (audit 4-f): the R6 freeze lift no longer fires on the
// n-count alone — the rawcal sample-quality gate must co-approve (verdict GREEN
// or blended informative ≥ 50%). Rationale: the lift re-fits factor weights on
// the EPOCH-2 book whose recent majority is RAW-CAL capture rows; when the
// raw cohort is censored (informative 43.4% AMBER live), the re-fit optimizes
// against time-censored outcomes. rawcal-quality.ts explicitly never edits the
// calibration math — so the CONDITIONING lives here, at the single decision
// point. No other calibration math is touched.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$quality$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)");
;
;
const KEY = "calibration";
const ACTIVE_AT = 30;
const N_FLOOR = 10;
const MOVING_FACTORS = [
    "EMA STACK",
    "MACD MOMENTUM",
    "RSI POSITION",
    "RANGE BREAKOUT",
    "BOLLINGER EXTREME",
    "VOLUME CONFIRM"
];
/** %/trade of expectancy that maps to a full ±0.3 weight swing */ const EXPECTANCY_SCALE = 15;
/** weight ceiling/floor (matches the deploy-scan clamp in getEffectiveWeights) */ const W_MIN = 0.7;
const W_MAX = 1.3;
// ── v8.4 R3+R6 CALIBRATION FREEZE (module-performance audit 2026-09-11) ──
// Evidence: confidence calibration ran INVERTED (conf-80 bucket avgPnl −14.6%
// vs conf-70 −6.1%; 75%+ basket −$10.10) and the weights floored at 0.70 on
// negative-expectancy factors with n=35 — Wilson-LB far too thin to move on.
// R3: weights are FROZEN at a one-time recalibration over EPOCH-2-only rows.
// R6: no weight may move again until the epoch-2 book reaches minN settled
// samples (100) — then the freeze auto-lifts and normal calibration resumes.
const FROZEN_KEY = "calibration.frozen";
/** v10.16 — audit trail key for lift checks blocked by the rawcal quality gate. */ const R6_LIFT_BLOCKED_KEY = "calibration.r6.liftBlocked";
/** v10.16 — the blended informative share that co-approves the R6 lift
 * (alongside gate verdict GREEN). Matches the rawcal gate's GREEN informative bar. */ const R6_INFORMATIVE_FLOOR = 50;
const FREEZE_MIN_N = 100; // R6 gate — Wilson-LB width ∝ 1/√n; 100 ≈ ±10% at 50%
const FREEZE_EPOCH_TAG = "EPOCH-2";
async function readFreeze() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: FROZEN_KEY
            }
        });
        return row ? JSON.parse(row.value) : null;
    } catch  {
        return null;
    }
}
async function writeFreeze(state) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: FROZEN_KEY
        },
        create: {
            key: FROZEN_KEY,
            value: JSON.stringify(state)
        },
        update: {
            value: JSON.stringify(state)
        }
    });
}
async function ensureCalibrationFrozen() {
    const existing = await readFreeze();
    if (existing) return existing;
    const epoch2 = await computeCalibration(true);
    const state = {
        frozen: true,
        reason: `R3 audit 2026-09-11: calibration INVERTED (conf-80 bucket −14.6%/trade vs conf-70 −6.1%) with n=35 — weights recalibrated on ${epoch2.settled} EPOCH-2 settled rows and frozen (R6: no movement until n≥${FREEZE_MIN_N})`,
        minN: FREEZE_MIN_N,
        epoch: FREEZE_EPOCH_TAG,
        frozenAt: new Date().toISOString(),
        frozenSettled: epoch2.settled
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify({
                ...epoch2,
                updatedAt: new Date().toISOString()
            })
        },
        update: {
            key: KEY,
            value: JSON.stringify({
                ...epoch2,
                updatedAt: new Date().toISOString()
            })
        }
    });
    hot = null; // drop the hot cache so the frozen book is what deploys read
    await writeFreeze(state);
    return state;
}
async function computeCalibration(epoch2Only = false) {
    const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            pnlPercent: true,
            reachedTp: true,
            marginUsd: true,
            factorsJson: true,
            tags: true
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 300
    });
    // v8.4 R3: the frozen book must reflect the CURRENT ledger epoch only —
    // pre-reset rows (different sizing/fee regime) would poison the weights.
    const epochRows = epoch2Only ? settled.filter((s)=>(s.tags ?? "").includes("EPOCH-2")) : settled;
    // accumulate per-factor strong-vote PNL ledgers
    const acc = new Map();
    for (const f of MOVING_FACTORS)acc.set(f, {
        n: 0,
        wins: 0,
        sumPct: 0,
        gains: 0,
        losses: 0,
        sumUsd: 0
    });
    for (const s of epochRows){
        if (!s.factorsJson) continue;
        let votes = [];
        try {
            votes = JSON.parse(s.factorsJson);
        } catch  {
            continue;
        }
        for (const v of votes){
            const cell = acc.get(v.factor);
            if (!cell || Math.abs(v.vote) < 8) continue; // strong votes only
            cell.n++;
            cell.sumPct += s.pnlPercent;
            cell.sumUsd += s.marginUsd * s.pnlPercent / 100;
            if (s.pnlPercent >= 0) cell.gains += s.pnlPercent;
            else cell.losses += Math.abs(s.pnlPercent);
            // v5.4 TP-proven win kept for the transparency column only
            if (s.pnlPercent > 0 || s.reachedTp >= 1) cell.wins++;
        }
    }
    const rows = [];
    const weights = {};
    for (const f of MOVING_FACTORS){
        const cell = acc.get(f);
        if (cell.n < N_FLOOR) continue;
        const expectancy = cell.sumPct / cell.n;
        const pf = cell.losses > 0 ? Math.min(9.9, cell.gains / cell.losses) : 9.9;
        const raw = 1 + expectancy / EXPECTANCY_SCALE + 0.15 * Math.tanh(pf - 1);
        const w = Math.min(W_MAX, Math.max(W_MIN, raw));
        weights[f] = Number(w.toFixed(3));
        rows.push({
            factor: f,
            weight: weights[f],
            n: cell.n,
            expectancy: Number(expectancy.toFixed(2)),
            netPct: Number(cell.sumPct.toFixed(1)),
            profitFactor: Number(pf.toFixed(2)),
            winRate: Number((cell.wins / cell.n * 100).toFixed(1)),
            avgPct: Number(expectancy.toFixed(2)),
            pnlUsd: Number(cell.sumUsd.toFixed(2))
        });
    }
    let updatedAt = null;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) {
            const prev = JSON.parse(row.value);
            updatedAt = prev.updatedAt ?? null;
        }
    } catch  {
    /* ignore */ }
    return {
        status: (epoch2Only ? epochRows : settled).length >= ACTIVE_AT ? "ACTIVE" : "OBSERVING",
        settled: (epoch2Only ? epochRows : settled).length,
        target: ACTIVE_AT,
        criterion: "NET-PNL-EXPECTANCY",
        weights,
        rows,
        updatedAt
    };
}
async function refreshCalibration() {
    const freeze = await ensureCalibrationFrozen();
    const epoch2Settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    });
    if (freeze.frozen && epoch2Settled < freeze.minN) {
        const state = await computeCalibration(true); // display-only
        // v8.4.1 G3 (operator mandate): surface the freeze honestly — the card must
        // not read "OBSERVING 28/30" while weights are locked with a n≥100 lift bar.
        state.status = "FROZEN";
        state.settled = epoch2Settled;
        state.target = freeze.minN;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY
            },
            create: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            },
            update: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            }
        });
        return {
            state,
            auditLine: tickFreezeLine++ % 10 === 0 ? `CALIBRATION FROZEN (R3/R6): weights locked at epoch-2 recalibration (${freeze.frozenSettled} settled) — no movement until n≥${freeze.minN} (now ${epoch2Settled}). Learned/advisor weight writes are ignored while frozen.` : null
        };
    }
    if (freeze.frozen && epoch2Settled >= freeze.minN) {
        // ── v10.16 R6 QUALITY GATE — the n-count alone must not unfreeze. The lift
        // re-fits weights on the ledger; when the RAW-CAL sample quality is AMBER/RED
        // (censored book), the re-fit would learn from censoring, not edge. Require
        // gate GREEN OR blended informative ≥ 50% IN ADDITION to the n-bar.
        // Fail-closed: if the quality digest is unavailable, the freeze HOLDS
        // (an unverifiable book is not a healthy book).
        let quality = null;
        try {
            quality = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$quality$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["computeRawcalQuality"])(); // 30s-memoized, cheap at this cadence (~3.5min)
        } catch  {
            quality = null;
        }
        const qStatus = quality?.gate.verdict ?? "UNAVAILABLE";
        const qInformative = quality?.informativePct ?? null;
        const qualityOk = quality !== null && (quality.gate.verdict === "GREEN" || (quality.informativePct ?? -1) >= R6_INFORMATIVE_FLOOR);
        if (!qualityOk) {
            const blocked = {
                at: new Date().toISOString(),
                informativePct: qInformative,
                status: qStatus,
                epoch2Settled
            };
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: R6_LIFT_BLOCKED_KEY
                },
                create: {
                    key: R6_LIFT_BLOCKED_KEY,
                    value: JSON.stringify(blocked)
                },
                update: {
                    value: JSON.stringify(blocked)
                }
            }).catch(()=>undefined);
            const state = await computeCalibration(true); // display-only — weights stay frozen
            state.status = "FROZEN";
            state.settled = epoch2Settled;
            state.target = freeze.minN;
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: KEY
                },
                create: {
                    key: KEY,
                    value: JSON.stringify({
                        ...state,
                        updatedAt: new Date().toISOString()
                    })
                },
                update: {
                    key: KEY,
                    value: JSON.stringify({
                        ...state,
                        updatedAt: new Date().toISOString()
                    })
                }
            });
            if (r6BlockWarn++ % 10 === 0) {
                console.warn(`[calibration] R6 lift BLOCKED by rawcal quality gate — status ${qStatus}, informative ${qInformative ?? "n/a"}% (need GREEN or ≥${R6_INFORMATIVE_FLOOR}%), epoch2Settled ${epoch2Settled} ≥ n-bar ${freeze.minN}. Weights stay frozen — no re-fit on a censored book (v10.16).`);
            }
            return {
                state,
                auditLine: tickFreezeLine++ % 10 === 0 ? `CALIBRATION STILL FROZEN (R3/R6 + v10.16 quality gate): n-bar reached (${epoch2Settled} ≥ ${freeze.minN}) but rawcal sample gate ${qStatus} (blended informative ${qInformative ?? "n/a"}% < ${R6_INFORMATIVE_FLOOR}% or not GREEN) — no weight re-fit on a censored book until the gate co-approves.` : null
            };
        }
        await writeFreeze({
            ...freeze,
            frozen: false,
            reason: `${freeze.reason} → R6 LIFT: epoch-2 book reached n=${epoch2Settled} ≥ ${freeze.minN} with rawcal quality co-approval (gate ${qStatus}, informative ${qInformative}%) — calibration unfrozen`
        });
        const state = await computeCalibration();
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY
            },
            create: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            },
            update: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            }
        });
        return {
            state,
            auditLine: `R6 CALIBRATION LIFT: epoch-2 book reached n=${epoch2Settled} ≥ ${freeze.minN} — profit-first weight calibration RESUMES (was frozen since ${freeze.frozenAt}).`
        };
    }
    const state = await computeCalibration();
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify({
                ...state,
                updatedAt: new Date().toISOString()
            })
        },
        update: {
            key: KEY,
            value: JSON.stringify({
                ...state,
                updatedAt: new Date().toISOString()
            })
        }
    });
    const auditLine = state.status === "ACTIVE" && state.rows.length > 0 ? `AI CALIBRATION (net-PNL criterion): weights from ${state.settled} settled — ${state.rows.map((r)=>`${r.factor} ×${r.weight.toFixed(2)} (exp ${r.expectancy >= 0 ? "+" : ""}${r.expectancy}%/trade, PF ${r.profitFactor}, n=${r.n})`).join(" · ")}` : null;
    return {
        state,
        auditLine
    };
}
let tickFreezeLine = 0; // rate-limit the frozen audit line inside the 60-tick calibration hook
let r6BlockWarn = 0; // v10.16 — rate-limit the quality-blocked console.warn (~1 line / 35min at the 60-tick cadence)
/** Cached read for hot paths (deploy scan). Falls back to compute on miss. */ let hot = null;
async function getCalibration() {
    if (hot && Date.now() - hot.at < 60_000) return hot.state;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) {
            const state = JSON.parse(row.value);
            hot = {
                at: Date.now(),
                state
            };
            return state;
        }
    } catch  {
    /* ignore */ }
    const state = await computeCalibration();
    hot = {
        at: Date.now(),
        state
    };
    return state;
}
async function getEffectiveWeights() {
    const cal = await getCalibration();
    const weights = {
        ...cal.weights
    };
    let source = Object.keys(weights).length ? "calibration" : "none";
    // v8.4 R6: while frozen, learned autotune adoption is ignored — the whole
    // point of the freeze is that n=35 evidence must not steer live scoring.
    if (source === "calibration" && (await readFreeze())?.frozen) {
        return {
            weights,
            source: "frozen"
        };
    }
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "backtest.autotune"
            }
        });
        if (row) {
            const at = JSON.parse(row.value);
            if (at.adopted && at.adoptedWeights) {
                for (const [f, w] of Object.entries(at.adoptedWeights)){
                    const base = weights[f] ?? 1;
                    weights[f] = Number(Math.min(1.3, Math.max(0.7, base * w)).toFixed(3));
                }
                source = Object.keys(cal.weights).length ? "calibration×autotune" : "autotune";
            }
        }
    } catch  {
    /* ignore */ }
    return {
        weights,
        source
    };
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__197111c1._.js.map