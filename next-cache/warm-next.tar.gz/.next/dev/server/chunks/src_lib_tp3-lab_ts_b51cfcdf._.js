module.exports = [
"[project]/src/lib/tp3-lab.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildTp3Lab",
    ()=>buildTp3Lab,
    "getDeepLearnState",
    ()=>getDeepLearnState,
    "maybeAutoDeepLearn",
    ()=>maybeAutoDeepLearn,
    "runDeepLearnCycle",
    ()=>runDeepLearnCycle
]);
// ── FlowRadar Neo TP3 DEEP-LAB + DEEP-LEARN LOOP (server-only, v5.4) ──
// Operator request: full-TP (TP3) signals get their OWN calculator with a
// deeper learning cycle, and both full-TP + stopped-out signals go through an
// LLM research Q&A ("why did this win big / why did this die?"). The resulting
// lessons are persisted, broadcast to the event feed, injected into every AI
// agent's grounding (chat / governor / card briefs), and audited in EngineSetting.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
// v8.2 GATE GAUGE — the central core studies the LIVE confirm/reject ledger
// (boundary-band verdicts + hard blocks with their full reason payload)
// alongside the terminal outcomes, so lessons attribute RESULTS to REASONS.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-journal.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sv-telemetry.ts [app-route] (ecmascript)"); // v10.2 — the core studies its own feed wiring
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — the core studies the GOVERNOR FOUR-PACK journal
;
;
;
;
;
function tagList(s) {
    return (s.tags ?? "").split(",").filter(Boolean);
}
function topN(counter, n) {
    return [
        ...counter.entries()
    ].sort((a, b)=>b[1] - a[1]).slice(0, n);
}
/** Parse the regime tag out of the deployment tags (REGIME-*). */ function regimeOf(tags) {
    return tags.find((t)=>t.startsWith("REGIME-")) ?? null;
}
/** Case-file mapper — module scope so both buildTp3Lab and runDeepLearnCycle share it. */ function toCase(s) {
    let votes = null;
    if (s.factorsJson) {
        try {
            const parsed = JSON.parse(s.factorsJson);
            votes = parsed.map((v)=>({
                    factor: String(v.factor ?? "?"),
                    vote: Number(v.vote ?? 0)
                }));
        } catch  {
            votes = null;
        }
    }
    let flowVerdict = null;
    let flowScore = null;
    if (s.flowJson) {
        try {
            const f = JSON.parse(s.flowJson);
            flowVerdict = f.verdict ?? null;
            flowScore = typeof f.score === "number" ? f.score : null;
        } catch  {
        /* keep nulls */ }
    }
    const tags = tagList(s);
    return {
        serial: s.serial,
        symbol: s.symbol,
        direction: s.direction,
        strategy: s.strategy,
        outcome: s.status === "TP3" ? "TP3_FULL" : "SL",
        confidence: s.confidence,
        riskReward: s.riskReward,
        timeframe: s.timeframe,
        holdMinutes: s.closedAt && s.createdAt ? Math.round((s.closedAt.getTime() - s.createdAt.getTime()) / 60_000) : 0,
        reachedTp: s.reachedTp,
        maxPnlPercent: s.maxPnlPercent,
        netPnlPercent: s.pnlPercent,
        flowVerdict,
        flowScore,
        regimeTag: regimeOf(tags),
        tags,
        factorVotes: votes,
        occurredAt: (s.closedAt ?? s.createdAt).toISOString()
    };
}
async function buildTp3Lab(windowDays = 14) {
    const since = new Date(Date.now() - windowDays * 24 * 3600_000);
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP3",
                    "SL"
                ]
            },
            closedAt: {
                gte: since
            }
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const full = rows.filter((s)=>s.status === "TP3");
    const stopped = rows.filter((s)=>s.status === "SL");
    const cases = rows.map(toCase);
    const fullCases = cases.filter((c)=>c.outcome === "TP3_FULL");
    const stoppedCases = cases.filter((c)=>c.outcome === "SL");
    const countTags = (list)=>{
        const m = new Map();
        for (const c of list)for (const t of c.tags)if (!t.startsWith("REGIME-")) m.set(t, (m.get(t) ?? 0) + 1);
        return topN(m, 4);
    };
    const countStrategy = (list)=>{
        const m = {};
        for (const c of list)m[c.strategy] = (m[c.strategy] ?? 0) + 1;
        return m;
    };
    const countSymbols = (list)=>{
        const m = new Map();
        for (const c of list)m.set(c.symbol, (m.get(c.symbol) ?? 0) + 1);
        return topN(m, 4);
    };
    const avg = (nums)=>nums.length ? nums.reduce((a, b)=>a + b, 0) / nums.length : 0;
    const fullTp = {
        count: fullCases.length,
        ratePct: rows.length ? Number((fullCases.length / rows.length * 100).toFixed(1)) : 0,
        avgConfidence: Math.round(avg(fullCases.map((c)=>c.confidence))),
        avgRr: Number(avg(fullCases.map((c)=>c.riskReward)).toFixed(2)),
        avgHoldMin: Math.round(avg(fullCases.map((c)=>c.holdMinutes))),
        flowConfirmShare: fullCases.length ? Number((fullCases.filter((c)=>c.flowVerdict === "CONFIRMS").length / fullCases.length * 100).toFixed(0)) : 0,
        topTags: countTags(fullCases),
        topSymbols: countSymbols(fullCases),
        byStrategy: countStrategy(fullCases)
    };
    const stoppedStats = {
        count: stoppedCases.length,
        avgConfidence: Math.round(avg(stoppedCases.map((c)=>c.confidence))),
        avgHoldMin: Math.round(avg(stoppedCases.map((c)=>c.holdMinutes))),
        flowConflictShare: stoppedCases.length ? Number((stoppedCases.filter((c)=>c.flowVerdict === "CONFLICTS").length / stoppedCases.length * 100).toFixed(0)) : 0,
        topTags: countTags(stoppedCases),
        byStrategy: countStrategy(stoppedCases)
    };
    const confDelta = fullTp.avgConfidence - stoppedStats.avgConfidence;
    const rrDelta = Number((fullTp.avgRr - avg(stoppedCases.map((c)=>c.riskReward))).toFixed(2));
    const contrast = {
        confDelta,
        rrDelta,
        note: fullCases.length && stoppedCases.length ? `full-TP winners deployed at ${confDelta >= 0 ? "+" : ""}${confDelta} conviction vs stop-outs, with ${rrDelta >= 0 ? "+" : ""}${rrDelta} wider targets — winners ran ${fullTp.avgHoldMin}m avg vs ${stoppedStats.avgHoldMin}m for losers` : "not enough TP3/SL pairs in the window for a contrast read"
    };
    return {
        windowDays,
        fullTp,
        stopped: stoppedStats,
        contrast,
        recentCases: cases.slice(0, 10)
    };
}
const RING_CAP = 12;
const PERSIST_KEY = "deep-learn";
const MIN_INTERVAL_MS = 30 * 60_000; // autonomous cycle every ~30min
const state = {
    lastRunAt: null,
    runs: 0,
    casesLearned: 0,
    lessons: [],
    lastQuestion: null,
    lastAnswer: null,
    label: "IDLE"
};
let restored = false;
async function persistState() {
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: PERSIST_KEY
            },
            create: {
                key: PERSIST_KEY,
                value: JSON.stringify(state)
            },
            update: {
                value: JSON.stringify(state)
            }
        });
    } catch  {
    /* non-fatal */ }
}
async function getDeepLearnState() {
    await restoreState();
    return {
        ...state
    };
}
async function restoreState() {
    if (restored) return;
    restored = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: PERSIST_KEY
            }
        });
        if (!row) return;
        const v = JSON.parse(row.value);
        if ((v.runs ?? 0) > state.runs) {
            state.lastRunAt = v.lastRunAt ?? null;
            state.runs = v.runs ?? 0;
            state.casesLearned = v.casesLearned ?? 0;
            state.lessons = v.lessons ?? [];
            state.lastQuestion = v.lastQuestion ?? null;
            state.lastAnswer = v.lastAnswer ?? null;
            state.label = v.label ?? "IDLE";
        }
    } catch  {
    /* fresh start */ }
}
/** Compact, audit-grade case file — the ONLY facts the LLM may reason over. */ function caseFile(c) {
    const flow = c.flowVerdict ? `${c.flowVerdict} ${c.flowScore !== null ? `${c.flowScore >= 0 ? "+" : ""}${c.flowScore}/25` : ""}` : "n/a";
    const votes = c.factorVotes && c.factorVotes.length ? c.factorVotes.map((v)=>`${v.factor}${v.vote >= 0 ? "+" : ""}${v.vote}`).join(",") : "n/a";
    return [
        `NX-${String(c.serial).padStart(4, "0")} ${c.symbol} ${c.direction} ${c.strategy} ${c.timeframe} → ${c.outcome}`,
        `conf ${c.confidence} · RR ${c.riskReward} · held ${c.holdMinutes}m · ladder ${c.reachedTp}/3 · maxPnl ${c.maxPnlPercent.toFixed(1)}% · net ${c.netPnlPercent.toFixed(1)}%`,
        `flow ${flow} · regime ${c.regimeTag ?? "n/a"} · tags ${c.tags.join(",") || "n/a"} · votes ${votes}`
    ].join(" | ");
}
async function runDeepLearnCycle(force = false) {
    await restoreState();
    if (!force && state.lastRunAt && Date.now() - new Date(state.lastRunAt).getTime() < MIN_INTERVAL_MS) {
        return {
            ran: false,
            learned: 0,
            reason: "throttled (30min)"
        };
    }
    const since = state.lastRunAt ? new Date(state.lastRunAt) : new Date(Date.now() - 48 * 3600_000);
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP3",
                    "SL"
                ]
            },
            closedAt: {
                gt: since
            }
        },
        orderBy: {
            closedAt: "asc"
        },
        take: 8
    });
    if (rows.length === 0) {
        state.lastRunAt = new Date().toISOString();
        await persistState();
        return {
            ran: false,
            learned: 0,
            reason: "no new TP3/SL outcomes since last cycle"
        };
    }
    const lab = await buildTp3Lab(14);
    // v8.2 GATE GAUGE — live reason ledger for the core (boundary band + blocks)
    const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateJournalForCore"])(12, 8);
    // v8.2 SHADOW-VETO Phase 0 — the core's own fence adjudications + A/B arms
    const shadow = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["shadowVetoForCore"])(6).catch(()=>({
            narrative: "SHADOW-VETO: unavailable this cycle.",
            verdictFiles: []
        }));
    // v10.2 SV-TELEMETRY — arm feed wiring narrative (best-effort, never blocks)
    const svTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["svTelemetryNarrative"])().catch(()=>"SV-TELEMETRY: unavailable this cycle.");
    // v10.8 FOUR-PACK journal — governance module verdicts in the research grounding
    const fpTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fourpackNarrative"])().catch(()=>"FOUR-PACK: unavailable this cycle.");
    const gateGrounding = [
        `GATE JOURNAL (live, 12h): ${gate.narrative}`,
        ...gate.boundaryFiles.slice(0, 8).map((l)=>`BOUNDARY VERDICT: ${l}`),
        ...gate.blockFiles.map((l)=>`GATE BLOCK: ${l}`),
        `SHADOW-VETO: ${shadow.narrative}`,
        `SV-TELEMETRY: ${svTel}`,
        `FOUR-PACK: ${fpTel}`,
        ...shadow.verdictFiles.slice(0, 6).map((l)=>`SHADOW ADJUDICATION: ${l}`)
    ].join("\n");
    const tp3Cases = rows.filter((r)=>r.status === "TP3").map(toCase);
    const slCases = rows.filter((r)=>r.status === "SL").map(toCase);
    const allCases = [
        ...tp3Cases,
        ...slCases
    ].map(caseFile).join("\n");
    const question = [
        `RESEARCH QUESTIONS for this cycle (${tp3Cases.length} full-TP, ${slCases.length} stopped-out):`,
        "1. What did the full-TP winners share at deploy time (confluence votes, flow verdict, regime, conviction, R:R) that let them run the whole ladder?",
        "2. What did the stopped-out trades show that should have been a warning?",
        "3. Which single, measurable behaviour change would most improve the next 20 deployments?",
        // v8.2 GATE GAUGE — reason-level research question fed by the live journal
        "4. GATE JOURNAL (below): the boundary band (gap −8..0 from the effective threshold) is where confirm and reject blur — which boundary reasons (thr modifiers, opposing votes, hard blocks) actually predicted later TP3 vs SL outcomes, and which gate modifier deserves tightening or loosening on that measured evidence?",
        // v8.2 SHADOW-VETO — the core's own adjudication quality
        "5. SHADOW-VETO (below): your own veto-only adjudications at the fence are now outcome-tracked — are your VETO calls landing on trades that lose and your TRADE calls on trades that win? Cite the A/B arms (real-keep / real-veto / paper-keep / paper-veto) with their Wilson-LB numbers; if any arm has <30 settled outcomes, say the evidence is still forming — never extrapolate from thin arms."
    ].join(" ");
    const grounding = [
        "TP3 LAB CONTRAST (measured, 14d): " + lab.contrast.note,
        `FULL-TP profile: n=${lab.fullTp.count} rate ${lab.fullTp.ratePct}% avgConf ${lab.fullTp.avgConfidence} avgRR ${lab.fullTp.avgRr} flow-CONFIRMS ${lab.fullTp.flowConfirmShare}% tags ${lab.fullTp.topTags.map(([t, n])=>`${t}×${n}`).join(",") || "n/a"}`,
        `STOP-OUT profile: n=${lab.stopped.count} avgConf ${lab.stopped.avgConfidence} held ${lab.stopped.avgHoldMin}m flow-CONFLICTS ${lab.stopped.flowConflictShare}% tags ${lab.stopped.topTags.map(([t, n])=>`${t}×${n}`).join(",") || "n/a"}`,
        "CASE FILES:",
        allCases,
        // v8.2 GATE JOURNAL — the reasons layer the boundary band lives on
        gateGrounding
    ].join("\n");
    const { aiDeepLearn } = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)");
    const result = await aiDeepLearn(grounding, question, lab);
    // persist lessons (newest first, ring-capped)
    const at = new Date().toISOString();
    const lessons = result.lessons.map((l)=>({
            at,
            scope: l.scope,
            pattern: String(l.pattern).slice(0, 240),
            evidence: String(l.evidence).slice(0, 300),
            action: String(l.action).slice(0, 240),
            confidence: Math.max(0, Math.min(100, Math.round(Number(l.confidence) || 60))),
            label: result.label
        }));
    state.lessons = [
        ...lessons,
        ...state.lessons
    ].slice(0, RING_CAP);
    state.lastQuestion = question.slice(0, 600);
    state.lastAnswer = String(result.hypothesis ?? "").slice(0, 2400);
    state.lastRunAt = at;
    state.runs++;
    state.casesLearned += rows.length;
    state.label = result.label;
    await persistState();
    // broadcast the strongest lesson to the terminal feed (audited)
    const lead = lessons[0];
    if (lead) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.create({
            data: {
                signalId: null,
                symbol: null,
                type: "ENGINE",
                level: "ai",
                message: `AI DEEP-LEARN #${state.runs}: studied ${rows.length} terminal outcomes (${tp3Cases.length} full-TP / ${slCases.length} stopped) — [${lead.scope}] ${lead.pattern} → ${lead.action} (${lead.label}, conf ${lead.confidence}%) · lesson stored to agent memory`
            }
        });
    }
    return {
        ran: true,
        learned: rows.length
    };
}
async function maybeAutoDeepLearn() {
    try {
        await runDeepLearnCycle(false);
    } catch (err) {
        console.error("[deep-learn]", err);
    }
}
}),
];

//# sourceMappingURL=src_lib_tp3-lab_ts_b51cfcdf._.js.map