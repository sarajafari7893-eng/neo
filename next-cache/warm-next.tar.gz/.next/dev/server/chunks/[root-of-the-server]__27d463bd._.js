module.exports = [
"[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_7c56381c._.js",
  "server/chunks/[root-of-the-server]__7c418860._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/raw-cal.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__9c8ae4f1._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/notify.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/lifecycle-learning.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_lifecycle-learning_ts_fe0da598._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/lifecycle-learning.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/flow-scanner.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/flow-scanner.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/oi-funding.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_oi-funding_ts_1fa859a7._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/oi-funding.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/shadow-veto.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__9c93d62a._.js",
  "server/chunks/[root-of-the-server]__5f06902d._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/calibration.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_b3826ea5._.js",
  "server/chunks/[root-of-the-server]__197111c1._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/calibration.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/tp3-lab.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__2a5af510._.js",
  "server/chunks/[root-of-the-server]__8abd16df._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/tp3-lab.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/persist-guard.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ab39de61._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/persist-guard.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/_8645af84._.js",
  "server/chunks/[root-of-the-server]__9cf9b63b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/ai.ts [app-route] (ecmascript)");
    });
});
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[externals]_node:fs_promises_ef82023e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
    });
});
}),
"[project]/src/lib/governor.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__27d463bd._.js",
  "server/chunks/src_lib_engine_ts_0bd90ac0._.js",
  "server/chunks/src_lib_144f6e7a._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__087147ff._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/governor.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/supervisor.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_03ca30d4._.js",
  "server/chunks/[root-of-the-server]__a43afe04._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/supervisor.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/advisor.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__736ccc24._.js",
  "server/chunks/src_lib_engine_ts_0bd90ac0._.js",
  "server/chunks/src_lib_87d24664._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__8d16f881._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/advisor.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/shadow-modules.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__fd35e77c._.js",
  "server/chunks/src_lib_engine_ts_0bd90ac0._.js",
  "server/chunks/src_lib_3e0615bc._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__8d16f881._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/shadow-modules.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/stableflow.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__85f1434c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/stableflow.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/futures-taxonomy.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_9bd533fd._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/futures-taxonomy.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/verdict.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__2a5af510._.js",
  "server/chunks/[root-of-the-server]__e3d0828a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/verdict.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/pump-performance.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_pump-performance_ts_9ec0ab80._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/pump-performance.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_b3826ea5._.js",
  "server/chunks/[root-of-the-server]__abff28af._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)");
    });
});
}),
];