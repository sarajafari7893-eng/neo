module.exports = [
"[project]/src/config/engine-flags.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"radarPrimary":true,"legacyAutoSpawn":true,"sensorBusDormant":false,"_comment":"TASK 19 OPERATOR MANDATE 2026-09-22/23: full de-restriction — legacy full-universe auto-spawn lane RESTORED alongside the radar lane, sensor bus display back on. Rollback: EngineSetting 'gate.rollback.v1022'."});}),
];

//# sourceMappingURL=src_config_engine-flags_json_878641d8._.js.map