module.exports = [
"[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bridgeDepth",
    ()=>bridgeDepth,
    "bridgeKlines",
    ()=>bridgeKlines,
    "bridgeOiHist",
    ()=>bridgeOiHist,
    "bridgeTape",
    ()=>bridgeTape,
    "fapi5mMove",
    ()=>fapi5mMove,
    "futTickerMap",
    ()=>futTickerMap,
    "futTickerRow",
    ()=>futTickerRow,
    "spot5mMove",
    ()=>spot5mMove,
    "spotMirrorDepth",
    ()=>spotMirrorDepth,
    "spotMirrorKlines",
    ()=>spotMirrorKlines,
    "spotMirrorTape",
    ()=>spotMirrorTape
]);
// ── FlowRadar Neo FLOW BRIDGE (server-only, v14.0 BINANCE-ONLY) ──
// Operator mandate (trace 1a185042c872b4f9 — «ردپای OKX/Bybit در کجا وجود
// دارد و با بایننس جایگزین شود»): the v12.2 cross-venue bridge is retired.
// Every ladder is now BINANCE-ONLY, riding the two independent Binance REST
// planes measured live from this egress:
//
//  ① fapi plane — gated (fapi-gate, weight budget, ban ledger), perp-native.
//  ② SPOT-MIRROR plane — the v13.3 spot-host ladder (data-api.binance.vision
//     → api-gcp → api1-4 → api.binance.com) with the shared per-host 418/429
//     gate: SEPARATE ban pool from fapi, SAME kline shape (field-9 taker
//     volume intact), zero fapi weight.
//
// LADDERS (best → last): klines fapi→SPOT-MIRROR · tape fapi→SPOT-MIRROR ·
// OI history fapi (perp-native — no spot equivalent, honest null on ban) ·
// depth fapi→SPOT-MIRROR · batched tickers fapi(composite)→SPOT-MIRROR.
// HONESTY LAWS unchanged: a plane that fails degrades to null — never to
// invented data; every result carries its SOURCE so cards/journals say which
// Binance plane the number came from. crowd/top-trader L/S ratios stay
// Binance-only and honestly null. FLAT-10 engine policy untouched.
//
// Note: 1000X-style perp symbols (1000PEPEUSDT…) have no spot pair — the
// SPOT-MIRROR rung 404s on them and the ladder ends honestly (fapi rung
// serves them whenever the gate is open).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
const TIMEOUT_MS = 6500;
async function jfetch(url, init) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
    try {
        const res = await fetch(url, {
            ...init,
            signal: ctrl.signal,
            cache: "no-store"
        });
        if (!res.ok) return null;
        return await res.json();
    } catch  {
        return null;
    } finally{
        clearTimeout(timer);
    }
}
// ── klines rungs ────────────────────────────────────────────────────────
// ── v13.2 SPOT-HOST LADDER (operator mandate trace 1a1704d407f00dad —
// «از data-api.binance.vision استفاده کن؛ جریان زندهٔ لحظه‌ای باید با بایننس
// باشد»): measured live 2026-10-25 — data-api.binance.vision 32/32 HTTP 200
// p50 57ms while api.binance.com rides 418 ban-storms from this shared egress.
// v13.2.3 (trace 1a170bba02dff781): api1-4 added as mid rungs, api last.
// v14.0: this ladder is now the ONLY fallback plane (Binance-only mandate).
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
// v13.2.1 — per-host 418/429 backoff via the shared spot-host gate: a banned
// rung is SKIPPED (not re-poked every tick) and traffic slides to the healthy
// host until retry-after expires (live evidence: vision 418 @467wt/min while
// jfetch swallowed the status and kept hammering).
async function spotLadderFetch(path) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotLadderJson"])(path, SPOT_HOSTS, TIMEOUT_MS);
}
function binanceKlineRows(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5]),
            takerBuyBase: Number(k[9])
        }));
}
async function spotMirrorKlines(symbol, interval, limit) {
    const spot = await spotLadderFetch(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
    if (!spot || spot.length === 0) return null;
    return binanceKlineRows(spot);
}
async function bridgeKlines(symbol, interval, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.length > 0) return {
        rows: binanceKlineRows(raw),
        source: "BINANCE"
    };
    const spot = await spotMirrorKlines(symbol, interval, limit).catch(()=>null);
    if (spot && spot.length > 0) return {
        rows: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function spotMirrorTape(symbol) {
    const spot = await spotLadderFetch(`/api/v3/trades?symbol=${symbol}&limit=1000`);
    if (!spot || spot.length === 0) return null;
    return spot.map((t)=>({
            price: Number(t.price),
            qty: Number(t.qty),
            quoteQty: Number(t.quoteQty) || Number(t.price) * Number(t.qty),
            isBuyerMaker: t.isBuyerMaker,
            time: t.time
        }));
}
async function bridgeTape(symbol) {
    const agg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (agg && agg.length > 0) {
        return {
            trades: agg.map((t)=>({
                    price: Number(t.p),
                    qty: Number(t.q),
                    quoteQty: Number(t.p) * Number(t.q),
                    isBuyerMaker: t.m,
                    time: t.T
                })),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorTape(symbol).catch(()=>null);
    if (spot && spot.length > 0) return {
        trades: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function bridgeOiHist(symbol, period, limit) {
    const f = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/futures/data/openInterestHist?symbol=${symbol}&period=${period}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (f && f.length > 0) {
        return {
            rows: f.map((h)=>({
                    sumOpenInterest: Number(h.sumOpenInterest),
                    sumOpenInterestValue: Number(h.sumOpenInterestValue),
                    timestamp: h.timestamp
                })),
            source: "BINANCE"
        };
    }
    return null;
}
async function spotMirrorDepth(symbol, limit) {
    const steps = [
        5,
        10,
        20,
        50,
        100,
        500
    ];
    const lv = steps.find((s)=>s >= limit) ?? 500;
    const raw = await spotLadderFetch(`/api/v3/depth?symbol=${symbol}&limit=${lv}`);
    if (!raw || raw.bids.length === 0 || raw.asks.length === 0) return null;
    return {
        bids: raw.bids.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        asks: raw.asks.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        source: "SPOT-MIRROR"
    };
}
async function bridgeDepth(symbol, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/depth?symbol=${symbol}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.bids.length > 0 && raw.asks.length > 0) {
        return {
            bids: raw.bids.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            asks: raw.asks.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorDepth(symbol, limit).catch(()=>null);
    if (spot) return spot;
    return null;
}
// ── batched tickers — funding + mark + 24h board for the WHOLE domain ──────
// v14.0 BINANCE-ONLY composite: ONE gated /fapi/v1/ticker/24hr (weight 40) +
// ONE gated /fapi/v1/premiumIndex batch (weight 10) merged per symbol. On a
// fapi ban the SPOT-MIRROR ticker batch prices the board (mark/funding/OI
// honestly null — spot plane carries no perp derivatives).
const TICKERS_TTL = 15_000;
let tickCache = null;
let tickInFlight = null;
async function futTickerMap() {
    if (tickCache && Date.now() - tickCache.at < TICKERS_TTL) return tickCache.map;
    if (tickInFlight) return tickInFlight;
    tickInFlight = (async ()=>{
        const out = new Map();
        const [board, prem] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/ticker/24hr", {
                priority: "telemetry",
                weight: 40,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/premiumIndex", {
                priority: "telemetry",
                weight: 10,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null)
        ]);
        if (board && board.length > 0) {
            const premMap = new Map((prem ?? []).map((p)=>[
                    p.symbol,
                    p
                ]));
            for (const r of board){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                const pm = premMap.get(r.symbol);
                const mark = Number(pm?.markPrice) || null;
                const funding = Number(pm?.lastFundingRate);
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: mark,
                    fundingRate: Number.isFinite(funding) && pm ? funding : null,
                    nextFundingTime: Number(pm?.nextFundingTime) || null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "BINANCE"
                });
            }
            tickCache = {
                at: Date.now(),
                map: out,
                src: "BINANCE"
            };
            return out;
        }
        // fapi banned — SPOT-MIRROR board (price-only rows, honest nulls on perp fields)
        const spot = await spotLadderFetch("/api/v3/ticker/24hr");
        if (spot && spot.length > 0) {
            for (const r of spot){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: null,
                    fundingRate: null,
                    nextFundingTime: null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "SPOT-MIRROR"
                });
            }
        }
        tickCache = {
            at: Date.now(),
            map: out,
            src: "SPOT-MIRROR"
        };
        return out;
    })();
    try {
        return await tickInFlight;
    } finally{
        tickInFlight = null;
    }
}
async function futTickerRow(symbol) {
    const map = await futTickerMap().catch(()=>new Map());
    const row = map.get(symbol);
    if (!row) return null;
    // v14.0 — OI enrichment: /fapi/v1/openInterest is per-symbol (weight 1);
    // fill it only for rows priced by the fapi plane and only when missing.
    if (row.source === "BINANCE" && row.openInterest === null) {
        const oi = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/openInterest?symbol=${symbol}`, {
            priority: "telemetry",
            timeoutMs: 4000
        }).catch(()=>null);
        const v = Number(oi?.openInterest);
        if (Number.isFinite(v) && v > 0) {
            row.openInterest = v;
            if (row.markPrice) row.openInterestValue = v * row.markPrice;
        }
    }
    return row;
}
async function spot5mMove(symbol) {
    const rows = await spotMirrorKlines(symbol, "5m", 4);
    if (!rows || rows.length < 4) return null;
    const open = rows[0].open;
    const close = rows[rows.length - 1].close;
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
async function fapi5mMove(symbol) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=4`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (!raw || raw.length < 4) return null;
    const open = Number(raw[0][1]);
    const close = Number(raw[raw.length - 1][4]);
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
}),
"[project]/src/lib/oi-funding.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getOiFundBoard",
    ()=>getOiFundBoard,
    "maybeOiFundScan",
    ()=>maybeOiFundScan,
    "peekOiFund",
    ()=>peekOiFund
]);
// ── FlowRadar Neo v8.1 OI / FUNDING BOARD (P1 liq-deepening, server-only) ──
// Operator mandate 2026-09-08: «طبق نظر مهندسی P1 و P2 رو کامل اجرا کن».
//
// What P1 adds on top of the existing reactive L3 cascade layer:
//   · a PERSISTENT derivatives board covering the tracked domain with OI deltas
//     across three horizons (15m / 1h / 4h) + funding carry + OI notional —
//     flow.ts only computes a 1h delta on demand with no board.
//   · the raw material the predictive L3-PRE layer needs: "positions still
//     piling in near a liquidation cluster" is a cascade BEFORE it happens.
//
// Cadence & budget (mirrors flow-scanner doctrine): rotating batch of 6
// symbols per call, ≥60s between calls → ~12 REST calls/min worst case on top
// of the flow scanner's ~24. Board persisted as ONE EngineSetting row
// (race-free by construction), in-memory map bounded at 64 symbols.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)");
;
;
;
const BOARD_KEY = "oifund.board";
const BATCH = 6;
const MIN_INTERVAL_MS = 60_000;
const BOARD_CAP = 64;
// ── bounded cache + in-flight dedupe (flow-scanner pattern) ──
const board = new Map();
let boardLoaded = false;
let scanCursor = 0;
let lastScanAt = 0;
let scanInFlight = false;
async function loadBoard() {
    if (boardLoaded) return;
    boardLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: BOARD_KEY
            }
        });
        if (row) {
            const parsed = JSON.parse(row.value);
            for (const r of parsed.rows ?? [])board.set(r.symbol, r);
        }
    } catch  {
    /* cold start — the scanner repopulates within ~10min */ }
}
async function persistBoard() {
    const rows = [
        ...board.values()
    ].sort((a, b)=>(b.oiUsd ?? 0) - (a.oiUsd ?? 0)).slice(0, BOARD_CAP);
    const value = JSON.stringify({
        at: Date.now(),
        rows
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: BOARD_KEY
        },
        create: {
            key: BOARD_KEY,
            value
        },
        update: {
            value
        }
    });
}
// v10.24 Task 34-a: fapi REST goes through the central fapi-gate (telemetry
// lane — a shedded rotation returns nulls and the board keeps its previous
// rows; the op-audit-20260908 carry-over semantics still apply downstream).
async function fapi(path, timeoutMs = 6000) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "telemetry",
        timeoutMs
    });
}
async function scanSymbol(symbol, prem, prev) {
    // v12.2 TASK-52 — OI LADDER: fapi openInterestHist (perp-native; v14.0 — the
    // only rung; on a fapi ban the scan honestly returns null, no invented rows).
    const histB = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeOiHist"])(symbol, "15m", 17).catch(()=>null);
    if (!histB || histB.rows.length < 4) return null; // honest — no invented rows
    const hist = histB.rows.map((r)=>({
            sumOpenInterest: String(r.sumOpenInterest),
            sumOpenInterestValue: String(r.sumOpenInterestValue ?? 0),
            timestamp: r.timestamp
        }));
    const oi = hist.map((h)=>Number(h.sumOpenInterest));
    const cur = oi[oi.length - 1];
    const pct = (barsBack)=>{
        const ref = oi[oi.length - 1 - barsBack];
        return ref !== undefined && ref > 0 ? Number(((cur - ref) / ref * 100).toFixed(2)) : null;
    };
    // z-score of the last 1h change vs its own distribution across the window
    let oiZ1h = null;
    const d1h = pct(4);
    if (d1h !== null && oi.length >= 10) {
        const deltas = [];
        for(let i = 4; i < oi.length; i++){
            const ref = oi[i - 4];
            if (ref > 0) deltas.push((oi[i] - ref) / ref * 100);
        }
        if (deltas.length >= 5) {
            const mean = deltas.reduce((a, b)=>a + b, 0) / deltas.length;
            const std = Math.sqrt(deltas.reduce((a, b)=>a + (b - mean) * (b - mean), 0) / deltas.length);
            if (std > 0) oiZ1h = Number(((d1h - mean) / std).toFixed(2));
        }
    }
    const oiUsdRow = Number(hist[hist.length - 1]?.sumOpenInterestValue ?? 0) || null;
    let oiUsd = oiUsdRow;
    if (!oiUsd) {
        // v14.0 — notional fallback from the Binance composite ticker leg (fapi
        // openInterest × markPrice); null honestly when the fapi plane is banned.
        oiUsd = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerRow"])(symbol).catch(()=>null))?.openInterestValue ?? null;
    }
    // op-audit-20260908: when the batch premiumIndex call missed (transient fapi
    // weight pressure), CARRY OVER the previous funding fields instead of
    // overwriting good data with nulls — funding changes every 8h, staleness of
    // one rotation is harmless, data loss was not.
    return {
        symbol,
        at: Date.now(),
        markPrice: prem ? Number(prem.markPrice) || null : prev?.markPrice ?? null,
        funding8h: prem ? Number((Number(prem.lastFundingRate) * 100).toFixed(4)) : prev?.funding8h ?? null,
        nextFundingAt: prem ? Number(prem.nextFundingTime) || null : prev?.nextFundingAt ?? null,
        oiBase: cur,
        oiUsd: oiUsd ? Number((oiUsd / 1e6).toFixed(2)) : null,
        oiDelta15m: pct(1),
        oiDelta1h: d1h,
        oiDelta4h: pct(16),
        oiZ1h,
        src: histB.source
    };
}
async function maybeOiFundScan(symbols) {
    await loadBoard();
    if (scanInFlight || symbols.length === 0) return;
    if (Date.now() - lastScanAt < MIN_INTERVAL_MS) return;
    scanInFlight = true;
    lastScanAt = Date.now();
    try {
        const batch = [];
        for(let i = 0; i < Math.min(BATCH, symbols.length); i++)batch.push(symbols[(scanCursor + i) % symbols.length]);
        scanCursor = (scanCursor + batch.length) % symbols.length;
        // op-audit-20260908: ONE batched premiumIndex call (no symbol param → ALL
        // markers, weight ~10) replaces 6 per-symbol calls per rotation — funding
        // coverage climbs 6/33 → full domain in one pass AND the per-second fapi
        // weight bursts that tripped -1003 endpoint bans disappear.
        // v12.2 TASK-52 (v14.0 rewrite): when the fapi batch starves, the Binance
        // composite ticker leg feeds the whole rotation instead — the board
        // carries funding only when the fapi plane priced it (spot rows keep
        // funding honestly null, so the carry-over guard below stays truthful).
        const premRows = await fapi(`/fapi/v1/premiumIndex`).catch(()=>null);
        let premMap = new Map();
        for (const p of premRows ?? [])if (p?.symbol) premMap.set(p.symbol, p);
        if (premMap.size === 0) {
            const tickers = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerMap"])().catch(()=>null);
            if (tickers && tickers.size > 0) {
                console.log(`[oi-funding] fapi premiumIndex starved — Binance composite ticker board (${tickers.size} symbols, v14.0)`);
                for (const symbol of batch){
                    const t = tickers.get(symbol);
                    if (t && t.fundingRate !== null) {
                        premMap.set(symbol, {
                            lastFundingRate: String(t.fundingRate),
                            markPrice: String(t.markPrice ?? t.lastPrice),
                            nextFundingTime: t.nextFundingTime ?? 0
                        });
                    }
                }
            }
        }
        for (const symbol of batch){
            const prev = board.get(symbol) ?? null;
            const row = await scanSymbol(symbol, premMap.get(symbol) ?? null, prev).catch(()=>null);
            if (row) board.set(symbol, row);
        }
        await persistBoard();
    } finally{
        scanInFlight = false;
    }
}
function peekOiFund(symbol) {
    const r = board.get(symbol);
    if (!r || Date.now() - r.at > 20 * 60_000) return null;
    return r;
}
async function getOiFundBoard() {
    await loadBoard();
    const rows = [
        ...board.values()
    ].sort((a, b)=>(b.oiUsd ?? 0) - (a.oiUsd ?? 0));
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows: rows.slice(0, 48).map((r)=>({
                ...r,
                oiUsdM: r.oiUsd
            }))
    };
}
}),
];

//# sourceMappingURL=src_lib_34489f4f._.js.map