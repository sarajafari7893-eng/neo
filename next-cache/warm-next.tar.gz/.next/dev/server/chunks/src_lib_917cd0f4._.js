module.exports = [
"[project]/src/lib/liquidations.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLiquidationSnapshot",
    ()=>getLiquidationSnapshot,
    "getLiquidationStatus",
    ()=>getLiquidationStatus,
    "liquidationPressure",
    ()=>liquidationPressure
]);
// ── FlowRadar Neo liquidation feed client (server-only) ──
// Reads mini-services/liq-service (:3010). Honesty contract: when the stream
// is stalled or down we return null — never a fabricated "quiet tape".
const LIQ_URL = process.env.LIQ_SERVICE_URL ?? "http://localhost:3010";
const TIMEOUT_MS = 2500;
const CACHE_TTL = 20_000;
let cache = null;
let inFlight = null;
async function getLiquidationSnapshot() {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.snap;
    if (inFlight) return inFlight;
    inFlight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${LIQ_URL}/liquidations`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (!res.ok) throw new Error(`liq ${res.status}`);
            const snap = await res.json();
            cache = {
                at: Date.now(),
                snap
            };
            return snap;
        } catch  {
            cache = {
                at: Date.now(),
                snap: null
            };
            return null;
        } finally{
            inFlight = null;
        }
    })();
    return inFlight;
}
async function getLiquidationStatus() {
    const snap = await getLiquidationSnapshot();
    if (!snap) return null;
    return {
        online: true,
        ...snap.status
    };
}
async function liquidationPressure(symbol) {
    const snap = await getLiquidationSnapshot();
    if (!snap || snap.status.dataStalled || !snap.status.connected) return null;
    const row = snap.bySymbol[symbol];
    if (!row) return {
        usd10m: 0,
        longsUsd10m: 0,
        shortsUsd10m: 0
    };
    return {
        usd10m: row.usd10m,
        longsUsd10m: row.longsUsd10m,
        shortsUsd10m: row.shortsUsd10m
    };
}
}),
"[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bridgeDepth",
    ()=>bridgeDepth,
    "bridgeKlines",
    ()=>bridgeKlines,
    "bridgeOiHist",
    ()=>bridgeOiHist,
    "bridgeTape",
    ()=>bridgeTape,
    "fapi5mMove",
    ()=>fapi5mMove,
    "futTickerMap",
    ()=>futTickerMap,
    "futTickerRow",
    ()=>futTickerRow,
    "spot5mMove",
    ()=>spot5mMove,
    "spotMirrorDepth",
    ()=>spotMirrorDepth,
    "spotMirrorKlines",
    ()=>spotMirrorKlines,
    "spotMirrorTape",
    ()=>spotMirrorTape
]);
// ── FlowRadar Neo FLOW BRIDGE (server-only, v14.0 BINANCE-ONLY) ──
// Operator mandate (trace 1a185042c872b4f9 — «ردپای OKX/Bybit در کجا وجود
// دارد و با بایننس جایگزین شود»): the v12.2 cross-venue bridge is retired.
// Every ladder is now BINANCE-ONLY, riding the two independent Binance REST
// planes measured live from this egress:
//
//  ① fapi plane — gated (fapi-gate, weight budget, ban ledger), perp-native.
//  ② SPOT-MIRROR plane — the v13.3 spot-host ladder (data-api.binance.vision
//     → api-gcp → api1-4 → api.binance.com) with the shared per-host 418/429
//     gate: SEPARATE ban pool from fapi, SAME kline shape (field-9 taker
//     volume intact), zero fapi weight.
//
// LADDERS (best → last): klines fapi→SPOT-MIRROR · tape fapi→SPOT-MIRROR ·
// OI history fapi (perp-native — no spot equivalent, honest null on ban) ·
// depth fapi→SPOT-MIRROR · batched tickers fapi(composite)→SPOT-MIRROR.
// HONESTY LAWS unchanged: a plane that fails degrades to null — never to
// invented data; every result carries its SOURCE so cards/journals say which
// Binance plane the number came from. crowd/top-trader L/S ratios stay
// Binance-only and honestly null. FLAT-10 engine policy untouched.
//
// Note: 1000X-style perp symbols (1000PEPEUSDT…) have no spot pair — the
// SPOT-MIRROR rung 404s on them and the ladder ends honestly (fapi rung
// serves them whenever the gate is open).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
const TIMEOUT_MS = 6500;
async function jfetch(url, init) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
    try {
        const res = await fetch(url, {
            ...init,
            signal: ctrl.signal,
            cache: "no-store"
        });
        if (!res.ok) return null;
        return await res.json();
    } catch  {
        return null;
    } finally{
        clearTimeout(timer);
    }
}
// ── klines rungs ────────────────────────────────────────────────────────
// ── v13.2 SPOT-HOST LADDER (operator mandate trace 1a1704d407f00dad —
// «از data-api.binance.vision استفاده کن؛ جریان زندهٔ لحظه‌ای باید با بایننس
// باشد»): measured live 2026-10-25 — data-api.binance.vision 32/32 HTTP 200
// p50 57ms while api.binance.com rides 418 ban-storms from this shared egress.
// v13.2.3 (trace 1a170bba02dff781): api1-4 added as mid rungs, api last.
// v14.0: this ladder is now the ONLY fallback plane (Binance-only mandate).
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
// v13.2.1 — per-host 418/429 backoff via the shared spot-host gate: a banned
// rung is SKIPPED (not re-poked every tick) and traffic slides to the healthy
// host until retry-after expires (live evidence: vision 418 @467wt/min while
// jfetch swallowed the status and kept hammering).
async function spotLadderFetch(path) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotLadderJson"])(path, SPOT_HOSTS, TIMEOUT_MS);
}
function binanceKlineRows(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5]),
            takerBuyBase: Number(k[9])
        }));
}
async function spotMirrorKlines(symbol, interval, limit) {
    const spot = await spotLadderFetch(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
    if (!spot || spot.length === 0) return null;
    return binanceKlineRows(spot);
}
async function bridgeKlines(symbol, interval, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.length > 0) return {
        rows: binanceKlineRows(raw),
        source: "BINANCE"
    };
    const spot = await spotMirrorKlines(symbol, interval, limit).catch(()=>null);
    if (spot && spot.length > 0) return {
        rows: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function spotMirrorTape(symbol) {
    const spot = await spotLadderFetch(`/api/v3/trades?symbol=${symbol}&limit=1000`);
    if (!spot || spot.length === 0) return null;
    return spot.map((t)=>({
            price: Number(t.price),
            qty: Number(t.qty),
            quoteQty: Number(t.quoteQty) || Number(t.price) * Number(t.qty),
            isBuyerMaker: t.isBuyerMaker,
            time: t.time
        }));
}
async function bridgeTape(symbol) {
    const agg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (agg && agg.length > 0) {
        return {
            trades: agg.map((t)=>({
                    price: Number(t.p),
                    qty: Number(t.q),
                    quoteQty: Number(t.p) * Number(t.q),
                    isBuyerMaker: t.m,
                    time: t.T
                })),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorTape(symbol).catch(()=>null);
    if (spot && spot.length > 0) return {
        trades: spot,
        source: "SPOT-MIRROR"
    };
    return null;
}
async function bridgeOiHist(symbol, period, limit) {
    const f = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/futures/data/openInterestHist?symbol=${symbol}&period=${period}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (f && f.length > 0) {
        return {
            rows: f.map((h)=>({
                    sumOpenInterest: Number(h.sumOpenInterest),
                    sumOpenInterestValue: Number(h.sumOpenInterestValue),
                    timestamp: h.timestamp
                })),
            source: "BINANCE"
        };
    }
    return null;
}
async function spotMirrorDepth(symbol, limit) {
    const steps = [
        5,
        10,
        20,
        50,
        100,
        500
    ];
    const lv = steps.find((s)=>s >= limit) ?? 500;
    const raw = await spotLadderFetch(`/api/v3/depth?symbol=${symbol}&limit=${lv}`);
    if (!raw || raw.bids.length === 0 || raw.asks.length === 0) return null;
    return {
        bids: raw.bids.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        asks: raw.asks.map(([p, q])=>[
                Number(p),
                Number(q)
            ]),
        source: "SPOT-MIRROR"
    };
}
async function bridgeDepth(symbol, limit) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/depth?symbol=${symbol}&limit=${limit}`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (raw && raw.bids.length > 0 && raw.asks.length > 0) {
        return {
            bids: raw.bids.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            asks: raw.asks.map(([p, q])=>[
                    Number(p),
                    Number(q)
                ]),
            source: "BINANCE"
        };
    }
    const spot = await spotMirrorDepth(symbol, limit).catch(()=>null);
    if (spot) return spot;
    return null;
}
// ── batched tickers — funding + mark + 24h board for the WHOLE domain ──────
// v14.0 BINANCE-ONLY composite: ONE gated /fapi/v1/ticker/24hr (weight 40) +
// ONE gated /fapi/v1/premiumIndex batch (weight 10) merged per symbol. On a
// fapi ban the SPOT-MIRROR ticker batch prices the board (mark/funding/OI
// honestly null — spot plane carries no perp derivatives).
const TICKERS_TTL = 15_000;
let tickCache = null;
let tickInFlight = null;
async function futTickerMap() {
    if (tickCache && Date.now() - tickCache.at < TICKERS_TTL) return tickCache.map;
    if (tickInFlight) return tickInFlight;
    tickInFlight = (async ()=>{
        const out = new Map();
        const [board, prem] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/ticker/24hr", {
                priority: "telemetry",
                weight: 40,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/premiumIndex", {
                priority: "telemetry",
                weight: 10,
                timeoutMs: TIMEOUT_MS
            }).catch(()=>null)
        ]);
        if (board && board.length > 0) {
            const premMap = new Map((prem ?? []).map((p)=>[
                    p.symbol,
                    p
                ]));
            for (const r of board){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                const pm = premMap.get(r.symbol);
                const mark = Number(pm?.markPrice) || null;
                const funding = Number(pm?.lastFundingRate);
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: mark,
                    fundingRate: Number.isFinite(funding) && pm ? funding : null,
                    nextFundingTime: Number(pm?.nextFundingTime) || null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "BINANCE"
                });
            }
            tickCache = {
                at: Date.now(),
                map: out,
                src: "BINANCE"
            };
            return out;
        }
        // fapi banned — SPOT-MIRROR board (price-only rows, honest nulls on perp fields)
        const spot = await spotLadderFetch("/api/v3/ticker/24hr");
        if (spot && spot.length > 0) {
            for (const r of spot){
                const last = Number(r.lastPrice);
                if (!Number.isFinite(last) || last <= 0) continue;
                out.set(r.symbol, {
                    lastPrice: last,
                    markPrice: null,
                    fundingRate: null,
                    nextFundingTime: null,
                    openInterest: null,
                    openInterestValue: null,
                    turnover24h: Number(r.quoteVolume) || null,
                    price24hPcnt: r.priceChangePercent !== undefined && isFinite(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) / 100 : null,
                    highPrice24h: Number(r.highPrice) || null,
                    lowPrice24h: Number(r.lowPrice) || null,
                    prevPrice24h: Number(r.prevClosePrice) || null,
                    bid1Price: Number(r.bidPrice) || null,
                    ask1Price: Number(r.askPrice) || null,
                    source: "SPOT-MIRROR"
                });
            }
        }
        tickCache = {
            at: Date.now(),
            map: out,
            src: "SPOT-MIRROR"
        };
        return out;
    })();
    try {
        return await tickInFlight;
    } finally{
        tickInFlight = null;
    }
}
async function futTickerRow(symbol) {
    const map = await futTickerMap().catch(()=>new Map());
    const row = map.get(symbol);
    if (!row) return null;
    // v14.0 — OI enrichment: /fapi/v1/openInterest is per-symbol (weight 1);
    // fill it only for rows priced by the fapi plane and only when missing.
    if (row.source === "BINANCE" && row.openInterest === null) {
        const oi = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/openInterest?symbol=${symbol}`, {
            priority: "telemetry",
            timeoutMs: 4000
        }).catch(()=>null);
        const v = Number(oi?.openInterest);
        if (Number.isFinite(v) && v > 0) {
            row.openInterest = v;
            if (row.markPrice) row.openInterestValue = v * row.markPrice;
        }
    }
    return row;
}
async function spot5mMove(symbol) {
    const rows = await spotMirrorKlines(symbol, "5m", 4);
    if (!rows || rows.length < 4) return null;
    const open = rows[0].open;
    const close = rows[rows.length - 1].close;
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
async function fapi5mMove(symbol) {
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=4`, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    }).catch(()=>null);
    if (!raw || raw.length < 4) return null;
    const open = Number(raw[0][1]);
    const close = Number(raw[raw.length - 1][4]);
    if (!(open > 0) || !(close > 0)) return null;
    return (close - open) / open * 100;
}
}),
"[project]/src/lib/core-revert.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCoreRevert",
    ()=>getCoreRevert
]);
// ── NEXUS//SIGNALS v13.0 CORE-REVERT knob (server-only) ──
// Operator mandate 2026-10-24 («پیشنهاد من سیستم به همان وضعیت برگردد و با
// دیتای موجود نقاط ضعف را فیلتر کند») after the W42 performance audit:
//   · v12.7 era (10-21 → 10-23 15:18): 111 signals, WR 60.4%, +$39.74,
//     median event→entry delay 13.2min — the SUCCESSFUL core configuration.
//   · v12.8/v12.9 era (10-23 15:31 → now): confirmation stack (CHASE-EXTREME,
//     FLUSH-EXHAUSTION/KNIFE-CATCH/STOP-FLOOR, SINGLE-VENUE, NO-BINANCE +12,
//     SURROGATE-FLOW cap, MULTI-VENUE clamp, STALE-BAR) DOUBLED the median
//     delay to 27.4min and starved the board behind a 200+ veto wall, while
//     the hard-SL class it targeted kept printing (7× −61.2% on 10-24 alone).
// enabled=true (default) → the v12.8+ hard gates become ADVISORY: they keep
// journaling (gate-journal audit trail preserved for future recalibration)
// but never refuse a deploy — deploy semantics return to the v12.7 core.
// Weaknesses are filtered from EXISTING data instead (STALE-CHASE gate +
// REARM-BRAKE-BE window in engine.ts), not by new blocking regimes.
// enabled=false → exact v12.9 blocking behavior, one EngineSetting flip.
// Cached 30s per process; fail-open to the operator mandate default.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const DEFAULT_CFG = {
    enabled: true
};
const CACHE_MS = 30_000;
const g = globalThis;
async function getCoreRevert() {
    const hit = g.__nexusCoreRevert;
    if (hit && Date.now() - hit.at < CACHE_MS) return hit.val;
    let val = {
        ...DEFAULT_CFG
    };
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "core-revert"
            }
        });
        if (row) {
            const p = JSON.parse(row.value);
            if (typeof p.enabled === "boolean") val = {
                enabled: p.enabled
            };
        }
    } catch  {
    /* fail-open → operator-mandate default (enabled) */ }
    g.__nexusCoreRevert = {
        at: Date.now(),
        val
    };
    return val;
}
}),
"[project]/src/lib/flow.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WHALE_PRINT_MIN_USD",
    ()=>WHALE_PRINT_MIN_USD,
    "detectLiquiditySweep",
    ()=>detectLiquiditySweep,
    "ensureFlow",
    ()=>ensureFlow,
    "fetchFlowMetrics",
    ()=>fetchFlowMetrics,
    "flowCoverageOf",
    ()=>flowCoverageOf,
    "getFlowHistory",
    ()=>getFlowHistory,
    "getFlowSource",
    ()=>getFlowSource,
    "getFlowStatus",
    ()=>getFlowStatus,
    "scoreFlow",
    ()=>scoreFlow
]);
// ── FlowRadar Neo order-flow module (server-only) ──
// Real Binance USDT-M flow metrics: OI delta, taker CVD, crowd L/S, funding.
// scoreFlow → ±25 along candidate direction · OI-notional weighting (v4.5)
// · in-memory per-symbol history ring for sparklines (R17).
// v10.24 Task 34-a: fapi REST now goes through the process-wide fapi-gate
// (weight budget + global ban awareness + single-flight). Telemetry lane —
// sheddable under pressure; every caller is throw/null-tolerant already.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)"); // v13.3 — ch.7-ب: honest fapi-plane health for the surrogate demote
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/core-revert.ts [app-route] (ecmascript)"); // v13.0 CORE-REVERT — operator revert mandate
;
;
;
;
const TIMEOUT_MS = 6500;
const CACHE_TTL = 150_000; // 2.5min
const STALE_GRACE = 600_000; // 10min
/** Decision-relevant metric keys — cvdNetBase is structurally null in the
 *  current pipeline and excluded from coverage on purpose. */ const COVERAGE_KEYS = [
    "oiDelta10m",
    "oiDelta1h",
    "oiValueUsd",
    "cvdNetPctOfVol",
    "takerRatio",
    "takerMean",
    "crowdLongShort",
    "topLongShort",
    "funding8h",
    "cvdUsd60s"
];
function flowCoverageOf(m) {
    return COVERAGE_KEYS.reduce((a, k)=>a + (m[k] != null ? 1 : 0), 0);
}
const BLIND_CACHE_TTL = 20_000; // v12.1: all-null metrics are a STARVATION state,
// v12.2 TASK-52 — venue that fed the last metrics bundle per symbol
const flowSrcMap = new Map();
function getFlowSource(symbol) {
    return flowSrcMap.get(symbol) ?? null;
}
// v12.9 MULTI-VENUE CONSENSUS — per-key 60s cache + in-flight dedupe so the
// second-venue cross-check costs at most ONE fetch per venue per minute per
// symbol on the hot path. Fail-soft: any throw → cached null → consensus
// skips (never blocks, never invents).
const consensusCache = new Map();
const consensusInFlight = new Map();
async function cachedConsensusVal(key, ttlMs, fn) {
    const hit = consensusCache.get(key);
    if (hit && Date.now() - hit.at < ttlMs) return hit.val ?? null;
    const inflight = consensusInFlight.get(key);
    if (inflight) return await inflight ?? null;
    const p = (async ()=>{
        let val = null;
        try {
            val = await fn();
        } catch  {
            val = null;
        }
        consensusCache.set(key, {
            at: Date.now(),
            val
        });
        if (consensusCache.size > 800) {
            const oldest = consensusCache.keys().next().value;
            if (oldest) consensusCache.delete(oldest);
        }
        return val;
    })().finally(()=>consensusInFlight.delete(key));
    consensusInFlight.set(key, p);
    return await p ?? null;
}
const WHALE_PRINT_MIN_USD = 250_000;
const flowCache = new Map();
const flowInFlight = new Map();
// per-symbol history ring: 1 point per FRESH sample, cap 60 (~2.5h)
const HISTORY_CAP = 60;
const flowHistory = new Map();
function getFlowStatus() {
    let lastOkAt = null;
    let lastError = null;
    let covered = 0;
    for (const [, e] of flowCache){
        if (Date.now() - e.at < STALE_GRACE) covered++;
        lastOkAt = Math.max(lastOkAt ?? 0, e.at) || null;
    }
    return {
        covered,
        lastOkAt,
        lastError
    };
}
async function fapi(path) {
    const v = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "telemetry",
        timeoutMs: TIMEOUT_MS
    });
    if (v === null) throw new Error(`fapi ${path} → unavailable`); // preserved throw semantics — allSettled callers treat it as partial absence
    return v;
}
async function fetchFlowMetrics(symbol) {
    const cached = flowCache.get(symbol);
    const cachedTtl = cached?.blind ? BLIND_CACHE_TTL : CACHE_TTL;
    if (cached && Date.now() - cached.at < cachedTtl) return cached.metrics;
    if (cached && Date.now() - cached.at < STALE_GRACE && flowInFlight.has(symbol)) return cached.metrics;
    const existing = flowInFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            const base = symbol.replace("USDT", "");
            const [oiHist, takerLS, crowd, premium, aggTrades, topPos] = await Promise.allSettled([
                fapi(`/futures/data/openInterestHist?symbol=${symbol}&period=5m&limit=13`),
                fapi(`/futures/data/takerlongshortRatio?symbol=${symbol}&period=5m&limit=13`),
                fapi(`/futures/data/globalLongShortAccountRatio?symbol=${symbol}&period=5m&limit=2`),
                fapi(`/fapi/v1/premiumIndex?symbol=${symbol}`),
                fapi(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`),
                fapi(`/futures/data/topLongShortPositionRatio?symbol=${symbol}&period=5m&limit=2`)
            ]);
            // v12.2 TASK-52 — FLOW BRIDGE: when a fapi lane starves (ban/pool silence),
            // recover the recoverable lanes over the bridge instead of sliding into
            // blindness. Honest sourcing: the bundle records the venue that fed it.
            let flowSrc = "BINANCE";
            const srcNote = (s)=>{
                if (flowSrc === "BINANCE") flowSrc = s;
                else if (flowSrc !== s) flowSrc = "MIXED";
            };
            let oi = oiHist.status === "fulfilled" ? oiHist.value : [];
            if (oi.length === 0) {
                const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeOiHist"])(symbol, "5m", 13).catch(()=>null);
                if (b && b.rows.length > 0) {
                    oi = b.rows.map((r)=>({
                            symbol,
                            sumOpenInterest: String(r.sumOpenInterest),
                            sumOpenInterestValue: String(r.sumOpenInterestValue ?? 0),
                            timestamp: r.timestamp
                        }));
                    srcNote(b.source);
                // v14.0 — OI history is fapi-only (perp-native): rows carry the real
                // notional from Binance. No cross-venue rung exists anymore.
                }
            }
            const taker = takerLS.status === "fulfilled" ? takerLS.value : [];
            const crowdArr = crowd.status === "fulfilled" ? crowd.value : [];
            // crowd/top-trader L/S ratios have NO public equivalent on any other
            // venue — during a fapi starvation they stay null (honest absence).
            let prem = premium.status === "fulfilled" ? premium.value : null;
            if (!prem) {
                // v14.0 — premiumIndex/marketPrice fallback via the Binance composite
                // ticker leg (fapi merged board; funding null on a spot-plane board →
                // the guard below fails honestly when fapi is banned).
                const t = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerRow"])(symbol).catch(()=>null);
                if (t && t.fundingRate !== null) {
                    prem = {
                        lastFundingRate: String(t.fundingRate),
                        markPrice: String(t.markPrice ?? t.lastPrice)
                    };
                    srcNote("BINANCE");
                }
            }
            let oiDelta10m = null;
            let oiDelta1h = null;
            let oiValueUsd = null;
            if (oi.length >= 3) {
                const last = oi[oi.length - 1];
                const first = oi[0];
                const cur = Number(last.sumOpenInterest);
                oiValueUsd = Number(last.sumOpenInterestValue);
                oiDelta10m = first ? (cur - Number(oi[Math.max(0, oi.length - 3)].sumOpenInterest)) / Number(oi[Math.max(0, oi.length - 3)].sumOpenInterest) * 100 : null;
                oiDelta1h = Number(first.sumOpenInterest) > 0 ? (cur - Number(first.sumOpenInterest)) / Number(first.sumOpenInterest) * 100 : null;
            }
            // CVD proxy from taker ratio series: (ratio−1) averaged, weighted by recency
            let takerMean = null;
            let takerRatio = null;
            if (taker.length >= 2) {
                const ratios = taker.map((t)=>Number(t.buySellRatio));
                takerRatio = ratios[ratios.length - 1];
                takerMean = ratios.reduce((a, b)=>a + b, 0) / ratios.length;
            }
            const crowdLongShort = crowdArr.length > 0 ? Number(crowdArr[crowdArr.length - 1].longShortRatio) : null;
            const crowdLongPct = crowdArr.length > 0 ? Number(crowdArr[crowdArr.length - 1].longAccount) * 100 : null;
            const topPosArr = topPos.status === "fulfilled" ? topPos.value : [];
            const topLongShort = topPosArr.length > 0 ? Number(topPosArr[topPosArr.length - 1].longShortRatio) : null;
            const funding8h = prem ? Number(prem.lastFundingRate) * 100 : null;
            // v6.7: real USD taker flow + whale prints from the same aggTrades pull
            // (trades ≤1000 ≈ last minutes on liquid symbols; windows clipped by T).
            // v12.2 TASK-52 (v14.0): tape ladder — fapi aggTrades → SPOT-MIRROR trades →
            // SPOT-MIRROR trades (spot = last resort: spot flow ≠ perp flow).
            let agg = aggTrades.status === "fulfilled" ? aggTrades.value : [];
            if (agg.length === 0) {
                const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeTape"])(symbol).catch(()=>null);
                if (b && b.trades.length > 0) {
                    agg = b.trades.map((t)=>({
                            p: t.price,
                            q: t.qty,
                            T: t.time,
                            m: t.isBuyerMaker
                        }));
                    srcNote(b.source);
                }
            }
            const t60 = Date.now() - 60_000;
            const t300 = Date.now() - 300_000;
            let buy60 = 0;
            let sell60 = 0;
            const wp = {
                count: 0,
                totalUsd: 0,
                maxUsd: 0,
                buyUsd: 0,
                sellUsd: 0
            };
            for (const t of agg){
                const usd = t.p * t.q;
                if (t.T >= t60) {
                    if (t.m) sell60 += usd;
                    else buy60 += usd;
                }
                if (t.T >= t300 && usd >= WHALE_PRINT_MIN_USD) {
                    wp.count++;
                    wp.totalUsd += usd;
                    if (usd > wp.maxUsd) wp.maxUsd = usd;
                    if (t.m) wp.sellUsd += usd;
                    else wp.buyUsd += usd;
                }
            }
            const cvdUsd60s = agg.length > 0 ? Math.round(buy60 - sell60) : null;
            const whalePrint5m = wp.count > 0 ? {
                count: wp.count,
                totalUsd: Math.round(wp.totalUsd),
                maxUsd: Math.round(wp.maxUsd),
                buyUsd: Math.round(wp.buyUsd),
                sellUsd: Math.round(wp.sellUsd)
            } : null;
            // v12.2 TASK-52: when the fapi taker-ratio series is absent but a REAL
            // tape exists (bridge), the net-buy % of volume is measured from that
            // same tape — window-capped at 10min (a 1000-trade slice spanning hours
            // on an illiquid symbol is a stale read, not a flow read).
            const winStart = agg.length > 0 ? agg[0].T : 0;
            let buyWin = 0;
            let sellWin = 0;
            for (const t of agg){
                const usd = t.p * t.q;
                if (t.m) sellWin += usd;
                else buyWin += usd;
            }
            const cvdFromTape = agg.length > 0 && buyWin + sellWin > 0 && winStart > 0 && Date.now() - winStart <= 600_000 ? (buyWin - sellWin) / (buyWin + sellWin) * 100 : null;
            const cvdNetPctOfVol = takerMean !== null ? (takerMean - 1) * 100 : cvdFromTape; // % of taker volume net buys
            const metrics = {
                oiDelta10m: oiDelta10m === null ? null : Number(oiDelta10m.toFixed(3)),
                oiDelta1h: oiDelta1h === null ? null : Number(oiDelta1h.toFixed(3)),
                oiValueUsd,
                cvdNetBase: null,
                cvdNetPctOfVol: cvdNetPctOfVol === null ? null : Number(cvdNetPctOfVol.toFixed(3)),
                takerRatio,
                takerMean,
                crowdLongShort,
                crowdLongPct,
                topLongShort: topLongShort === null ? null : Number(topLongShort.toFixed(3)),
                funding8h: funding8h === null ? null : Number(funding8h.toFixed(4)),
                cvdUsd60s,
                whalePrint5m
            };
            const blind = flowCoverageOf(metrics) === 0;
            flowCache.set(symbol, {
                at: Date.now(),
                metrics,
                blind
            });
            flowSrcMap.set(symbol, flowSrc);
            // history ring (fresh samples only)
            if (metrics.oiDelta1h !== null) {
                const ring = flowHistory.get(symbol) ?? [];
                ring.push({
                    at: Date.now(),
                    oiDelta1h: metrics.oiDelta1h
                });
                if (ring.length > HISTORY_CAP) ring.shift();
                flowHistory.set(symbol, ring);
            }
            return metrics;
        } catch  {
            return null;
        } finally{
            flowInFlight.delete(symbol);
        }
    })();
    flowInFlight.set(symbol, p);
    return p;
}
async function ensureFlow(symbols, concurrency = 3) {
    const queue = [
        ...symbols
    ];
    const workers = Array.from({
        length: Math.min(concurrency, queue.length)
    }, async ()=>{
        while(queue.length > 0){
            const s = queue.shift();
            if (s) await fetchFlowMetrics(s);
        }
    });
    await Promise.all(workers);
}
function getFlowHistory(symbol) {
    return flowHistory.get(symbol) ?? [];
}
function fmtUsdShort(v) {
    if (v >= 1e9) return `$${(v / 1e9).toFixed(2)}B`;
    if (v >= 1e6) return `$${(v / 1e6).toFixed(1)}M`;
    return `$${(v / 1e3).toFixed(0)}K`;
}
function detectLiquiditySweep(candles, direction) {
    if (!candles || candles.length < 26) return {
        swept: false,
        supportive: false,
        detail: ""
    };
    const c = candles[candles.length - 1];
    const prior = candles.slice(candles.length - 25, candles.length - 1);
    const swingHigh = Math.max(...prior.map((k)=>k.high));
    const swingLow = Math.min(...prior.map((k)=>k.low));
    const range = c.high - c.low;
    if (range <= 0) return {
        swept: false,
        supportive: false,
        detail: ""
    };
    if (c.high > swingHigh && c.close < swingHigh && (c.high - c.close) / range >= 0.5) {
        const detail = `SMC sweep: bar traded ${((c.high - swingHigh) / swingHigh * 100).toFixed(2)}% above the 24-bar swing high then closed back inside (${Math.round((c.high - c.close) / range * 100)}% rejection wick) — buy-side liquidity grabbed`;
        return {
            swept: true,
            supportive: direction === "SHORT",
            detail: supportive_(detail, direction === "SHORT")
        };
    }
    if (c.low < swingLow && c.close > swingLow && (c.close - c.low) / range >= 0.5) {
        const detail = `SMC sweep: bar pierced ${((swingLow - c.low) / swingLow * 100).toFixed(2)}% below the 24-bar swing low then closed back inside (${Math.round((c.close - c.low) / range * 100)}% rejection wick) — sell-side liquidity grabbed`;
        return {
            swept: true,
            supportive: direction === "LONG",
            detail: supportive_(detail, direction === "LONG")
        };
    }
    return {
        swept: false,
        supportive: false,
        detail: ""
    };
}
function supportive_(detail, ok) {
    return ok ? `${detail}, supports the candidate direction` : detail;
}
async function scoreFlow(symbol, direction, price1hAgoPct) {
    const m = await fetchFlowMetrics(symbol);
    if (!m) {
        return {
            verdict: "UNAVAILABLE",
            score: 0,
            reasons: [
                "flow metrics unavailable — no numbers invented"
            ],
            metrics: {
                oiDelta10m: null,
                oiDelta1h: null,
                oiValueUsd: null,
                cvdNetBase: null,
                cvdNetPctOfVol: null,
                takerRatio: null,
                takerMean: null,
                crowdLongShort: null,
                crowdLongPct: null,
                topLongShort: null,
                funding8h: null,
                cvdUsd60s: null,
                whalePrint5m: null
            },
            oiWeight: 1,
            calibrated: false,
            coverage: 0,
            blind: true
        };
    }
    const coverage = flowCoverageOf(m);
    const dir = direction === "LONG" ? 1 : -1;
    const reasons = [];
    // v12.1 Task-48 ② — HONEST NO-DATA: a fetch that completed with every
    // decision metric null (fapi ban window / budget shed) is BLINDNESS, not a
    // neutral book. The 48h census showed 70% of deploys rode this state while
    // the card read "FLOW-NEUTRAL". Blind flow never votes (score 0) but now
    // carries the NO-DATA verdict so cards, journals and gates can tell the
    // difference. (Gate on blindness = EngineSetting "flow-gate", default
    // tag-only: 10d ledger blind +$204.20 WR 57.1% vs sighted +$7.11 WR 52.8% —
    // blocking the blind cohort would have CUT +$204 of net.)
    if (coverage === 0) {
        return {
            verdict: "NO-DATA",
            score: 0,
            reasons: [
                "flow-blind — every decision metric null (fapi-gate starvation/ban window); no numbers invented, no neutral read claimed"
            ],
            metrics: m,
            oiWeight: 1,
            calibrated: true,
            coverage: 0,
            blind: true
        };
    }
    // v12.2 TASK-52 — honest sourcing: when the bundle rode the bridge, say so
    // on the card/journal instead of silently mixing venues.
    const bridgeSrc = getFlowSource(symbol);
    if (bridgeSrc && bridgeSrc !== "BINANCE") {
        reasons.push(`flow source: ${bridgeSrc} bridge (fapi starved — flow numbers measured on the bridge venue, not Binance)`);
    }
    let raw = 0;
    // 1. CVD imbalance ±9
    if (m.cvdNetPctOfVol !== null) {
        const aligned = m.cvdNetPctOfVol * dir;
        const v = Math.max(-9, Math.min(9, aligned * 1.8));
        raw += v;
        const usdCtx = m.cvdUsd60s !== null ? ` (${m.cvdUsd60s >= 0 ? "+" : ""}$${(m.cvdUsd60s / 1000).toFixed(0)}K net taker USD/60s)` : "";
        reasons.push(`taker CVD ${m.cvdNetPctOfVol >= 0 ? "+" : ""}${m.cvdNetPctOfVol.toFixed(2)}% of taker volume ${aligned > 1 ? "agrees" : aligned < -1 ? "opposes" : "is neutral"}${usdCtx}`);
    }
    // 7. WHALE PRINTS ±5 (v6.7 SMC package): single fills ≥$250K near the entry
    // are the visible footprint of size players — aligned prints confirm, prints
    // against the thesis are distribution risk.
    if (m.whalePrint5m && m.whalePrint5m.totalUsd >= 400_000) {
        const whaleSide = m.whalePrint5m.buyUsd >= m.whalePrint5m.sellUsd ? 1 : -1;
        const aligned = whaleSide * dir;
        const desc = `${m.whalePrint5m.count} fill(s) ≥$250K totaling $${(m.whalePrint5m.totalUsd / 1000).toFixed(0)}K in 5m (max $${(m.whalePrint5m.maxUsd / 1000).toFixed(0)}K, ${m.whalePrint5m.buyUsd >= m.whalePrint5m.sellUsd ? "buy" : "sell"}-side dominant)`;
        if (aligned > 0) {
            raw += 5;
            reasons.push(`WHALE PRINTS ${desc} — pressing WITH the ${direction.toLowerCase()} thesis (smart-money participation)`);
        } else {
            raw -= 5;
            reasons.push(`WHALE PRINTS ${desc} — pressing AGAINST the ${direction.toLowerCase()} thesis (distribution risk)`);
        }
    }
    // 2. OI × price matrix ±7
    if (m.oiDelta1h !== null && price1hAgoPct !== null) {
        const priceDir = price1hAgoPct * dir; // >0: price moving in candidate's favor
        const oiUp = m.oiDelta1h > 0;
        if (priceDir > 0 && oiUp) {
            raw += 7;
            reasons.push(`new positions conviction — price ${price1hAgoPct >= 0 ? "+" : ""}${price1hAgoPct.toFixed(2)}%/1h with OI ${m.oiDelta1h >= 0 ? "+" : ""}${m.oiDelta1h.toFixed(2)}%/1h (fresh ${direction.toLowerCase()}s pressing)`);
        } else if (priceDir > 0 && !oiUp) {
            raw += 2;
            reasons.push(`short-covering style move — OI unwinding ${m.oiDelta1h.toFixed(2)}%/1h while price drifts favorably`);
        } else if (priceDir < 0 && oiUp) {
            raw -= 7;
            reasons.push(`opposing new positions — OI ${m.oiDelta1h.toFixed(2)}%/1h building against the ${direction.toLowerCase()} thesis`);
        } else {
            raw -= 2;
            reasons.push(`capitulation washout pattern — OI and price both unwinding`);
        }
    }
    // 3. REAL liquidation cascade (R16) — exhaustion logic ±3
    const liq = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["liquidationPressure"])(symbol);
    if (liq) {
        if (liq.usd10m >= 400_000) {
            const sideWrecked = direction === "LONG" ? liq.longsUsd10m : liq.shortsUsd10m;
            if (sideWrecked > liq.usd10m * 0.6) {
                raw += 3;
                reasons.push(`REAL liquidation cascade: ${fmtUsdShort(liq.usd10m)} wrecked in 10m — ${direction === "LONG" ? "longs" : "shorts"} flushed (forceOrder), exhaustion tailwind`);
            } else {
                raw -= 1;
                reasons.push(`cascade ${fmtUsdShort(liq.usd10m)} in 10m hit the opposing side — momentum risk`);
            }
        } else {
            reasons.push(`no material liquidation cascade (${fmtUsdShort(liq.usd10m)} in 10m)`);
        }
    }
    // 4. Funding contrarian ±5
    if (m.funding8h !== null) {
        if (m.funding8h > 0.05) {
            const v = dir > 0 ? -5 : 5;
            raw += v;
            reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — crowded longs pay, contrarian edge`);
        } else if (m.funding8h < -0.05) {
            const v = dir > 0 ? 5 : -5;
            raw += v;
            reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — shorts pay, squeeze fuel for longs`);
        } else reasons.push(`funding ${m.funding8h.toFixed(4)}%/8h — neutral carry`);
    }
    // 5. Crowd positioning ±4
    if (m.crowdLongShort !== null) {
        if (m.crowdLongShort > 2.2) {
            raw += dir > 0 ? -4 : 4;
            reasons.push(`retail crowd ${m.crowdLongShort.toFixed(2)}:1 long — fade risk on longs`);
        } else if (m.crowdLongShort < 0.5) {
            raw += dir > 0 ? 4 : -4;
            reasons.push(`retail crowd ${m.crowdLongShort.toFixed(2)}:1 (heavy shorts) — contrarian tailwind for longs`);
        }
    }
    // 5b. TOP-TRADER positioning ±4 (v6.7 SMC): the top-20% cohort's POSITION
    // sizing — where size actually sits. Extremes fade; a top-vs-retail DIVERGENCE
    // (smart money leaning where the crowd is not) adds a +2 alignment bonus.
    if (m.topLongShort !== null) {
        if (m.topLongShort > 2) {
            raw += dir > 0 ? -4 : 4;
            reasons.push(`top traders ${m.topLongShort.toFixed(2)}:1 net-LONG by position size — crowded smart-money side, fade risk on longs`);
        } else if (m.topLongShort < 0.5) {
            raw += dir > 0 ? 4 : -4;
            reasons.push(`top traders ${m.topLongShort.toFixed(2)}:1 net-SHORT by position size — crowded smart-money side, tailwind against longs`);
        }
        if (m.crowdLongShort !== null && (m.crowdLongShort > 1.5 && m.topLongShort < 0.8 || m.crowdLongShort < 0.7 && m.topLongShort > 1.5)) {
            const smartSide = m.topLongShort > 1 ? 1 : -1;
            raw += smartSide === dir ? 2 : -2;
            reasons.push(`top-vs-retail divergence: crowd ${m.crowdLongShort.toFixed(2)}:1 vs top traders ${m.topLongShort.toFixed(2)}:1 — size sits with the ${smartSide === 1 ? "longs" : "shorts"}`);
        }
    }
    // 6. Taker acceleration ±5
    if (m.takerRatio !== null && m.takerMean !== null) {
        const accel = m.takerRatio - m.takerMean;
        const aligned = accel * dir;
        if (Math.abs(aligned) > 0.06) {
            raw += Math.max(-5, Math.min(5, aligned * 40));
            reasons.push(`taker buy/sell ${m.takerRatio.toFixed(3)} vs mean ${m.takerMean.toFixed(3)} — ${aligned > 0 ? "accelerating in favor" : "decelerating"}`);
        }
    }
    // OI-notional weighting (v4.5): deep books trusted more
    const oiWeight = m.oiValueUsd ? Math.max(0.5, Math.min(1.2, Math.sqrt(m.oiValueUsd / 50_000_000))) : 1;
    let score = Math.round(Math.max(-25, Math.min(25, raw * oiWeight)));
    if (Math.abs(oiWeight - 1) >= 0.15) reasons.push(`flow weighted ×${oiWeight.toFixed(2)} by OI notional ${fmtUsdShort(m.oiValueUsd ?? 0)} — deep-book flow trusted`);
    // ── v12.9 SECOND-PLANE CONSENSUS (AUDIT-NX3046-20261023, operator mandate
    // «باید از تمام صرافی‌ها مخصوصاً BINANCE تیکت گرفته بشه»; v14.0 Binance-only) ──
    // The bundle rode ONE plane's tape; nothing ever asked a SECOND plane
    // whether the tape agrees. NX-3046: a single-plane JCT tape showed CVD
    // +18.5% OPPOSING the short and OI unwinding — the bundle still rode
    // neutral, and no second plane was consulted. Now: the primary plane's
    // 15m-window (4×5m-bar) direction is compared against the INDEPENDENT
    // Binance plane (fapi-tape → SPOT-MIRROR cross-check; SPOT-MIRROR-tape →
    // gated fapi cross-check). Sign-opposed moves diverging >1.5% clamp
    // conviction to ±6 (below the ±8 CONFIRMS/CONFLICTS line) — cross-plane
    // conflict can never confirm a deploy. 60s per-symbol caches + in-flight
    // dedupe keep the hot path cheap; any fetch failure fails OPEN (consensus
    // simply does not run, no numbers invented). Symbols the second plane
    // cannot price (second rung null) are handled by the engine-side
    // SINGLE-VENUE deploy block.
    const consensusSrc = bridgeSrc ?? null;
    if (consensusSrc) {
        try {
            const pri = await cachedConsensusVal(`PRI5M|${symbol}`, 60_000, async ()=>{
                const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeKlines"])(symbol, "5m", 4).catch(()=>null);
                if (!r || r.rows.length < 4) return null;
                const o = r.rows[0].open, c = r.rows[r.rows.length - 1].close;
                return {
                    move: o > 0 && c > 0 ? (c - o) / o * 100 : null,
                    source: r.source
                };
            });
            const priMove = pri?.move ?? null;
            let secondName = null;
            let secondMove = null;
            // v14.0 — the second-plane cross-check is Binance-only: the plane the
            // primary did NOT ride (fapi primary → SPOT-MIRROR ladder check;
            // SPOT-MIRROR primary → gated fapi check, honest null when banned).
            if (consensusSrc === "BINANCE") {
                secondName = "BINANCE-SPOT";
                secondMove = await cachedConsensusVal(`SPOT5M|${symbol}`, 60_000, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spot5mMove"])(symbol));
            } else if (consensusSrc === "SPOT-MIRROR" || consensusSrc === "MIXED") {
                secondName = "BINANCE-FAPI";
                secondMove = await cachedConsensusVal(`FAPI5M|${symbol}`, 60_000, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapi5mMove"])(symbol));
            }
            if (priMove !== null && secondName && secondMove !== null) {
                const disagree = Math.sign(priMove) !== Math.sign(secondMove) && Math.abs(priMove - secondMove) > 1.5;
                if (disagree) {
                    const cr = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCoreRevert"])();
                    if (!cr.enabled) score = Math.max(-6, Math.min(6, score));
                    reasons.push(`MULTI-VENUE DISAGREE: primary ${consensusSrc} 15m-window ${priMove >= 0 ? "+" : ""}${priMove.toFixed(2)}% vs ${secondName} ${secondMove >= 0 ? "+" : ""}${secondMove.toFixed(2)}% — cross-venue tapes conflict${cr.enabled ? " · CORE-REVERT advisory: clamp lifted, telemetry only (v12.7 doctrine)" : ", conviction clamped ±6, cannot CONFIRM (operator mandate: confirmation from all venues, especially Binance — v12.9)"}`);
                } else if (Math.sign(priMove) === Math.sign(secondMove) && Math.abs(priMove - secondMove) <= 1.5) {
                    reasons.push(`MULTI-VENUE AGREE: primary ${consensusSrc} ${priMove >= 0 ? "+" : ""}${priMove.toFixed(2)}% ≈ ${secondName} ${secondMove >= 0 ? "+" : ""}${secondMove.toFixed(2)}% over 15m — cross-venue tape concordant (v12.9)`);
                }
            }
        } catch  {
        /* fail-open — consensus is telemetry, never a wedging gate */ }
    }
    // ── v12.8 SURROGATE-FLOW CAP (AUDIT-20261023, operator mandate «اصلاح
    // پیشنهادی را کامل و مهندسی اجرا کن») ──
    // Forensics NX-3014 (BTWUSDT 03:13Z): the flow bundle read "CONFIRMS +10"
    // while its source was the SPOT-MIRROR bridge (fapi banned) on a symbol whose
    // BINANCE quote was null and whose cross-venue dislocation ran 90-105bps —
    // the price collapsed −4.5% within 48s of deploy (SL −61.2% in 103s). A
    // surrogate venue's tape is REAL tape, but it is the WRONG venue's tape for
    // a Binance-doctrine engine on dislocated micro-caps: it must not be allowed
    // to CONFIRM a deploy. Cap: when the feeding source is not BINANCE, flow
    // conviction is clamped to ±6 — below the ±8 CONFIRMS/CONFLICTS line, so a
    // surrogate bundle can never confirm NOR fully veto; it can still feed the
    // flowVetoScore ≤−4 soft veto (score −5/−6 survives the clamp) and rides as
    // honest telemetry. BINANCE-sourced bundles are untouched.
    //
    // ── v13.3 SURROGATE-FLOW DEMOTE (ch.7 item ①-ب, operator mandate trace
    // 1a1a8ea4186c6571 «پیشنهادات باقی مانده مهندسی را کامل اجرا کن») ──
    // NX-3247 anatomy (engineering report ch.4-1): with fapi starved, the flow
    // verdict was sourced «SPOT-MIRROR bridge» and read CONFLICTS −9 against a
    // REAL Binance-futures buy flow the operator could see — the engine decided
    // with a surrogate's eyes at the exact top. While the fapi plane is starving
    // (global ban window live OR ≥2 egress IPs banned — fapiBanActivity()), a
    // non-BINANCE bundle is demoted to INFORMATIONAL-ONLY: score contribution 0,
    // verdict NEUTRAL, reason carries the demote tag. This branch runs BEFORE the
    // core-revert advisory check — CORE-REVERT restores the v12.7 core, it was
    // never an authorization for surrogate verdict-making during famine. When
    // fapi recovers, the historical v12.8 cap semantics resume unchanged.
    if (bridgeSrc && bridgeSrc !== "BINANCE") {
        const famine = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapiBanActivity"])().active; // v13.3 ch.7-ب — honest fapi-plane health
        if (famine) {
            score = 0;
            reasons.push(`SURROGATE-FLOW DEMOTE (ch.7-ب): fapi starved + source ${bridgeSrc} → flow bundle is INFORMATIONAL-ONLY this evaluation (score contribution 0, verdict NEUTRAL; NX-3247 CONFLICTS-9-from-mirror forensics — the engine does not decide on a surrogate's eyes while the real perp plane is starved)`);
        } else {
            const crSurrogate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$core$2d$revert$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCoreRevert"])();
            if (!crSurrogate.enabled) score = Math.max(-6, Math.min(6, score));
            reasons.push(`SURROGATE-FLOW CAP: source ${bridgeSrc} ≠ BINANCE${crSurrogate.enabled ? " · CORE-REVERT advisory: clamp lifted, surrogate tape rides as telemetry (v12.7 doctrine — the +12/+8/cap stack was the no-Binance drought engine)" : " — conviction clamped ±6, surrogate flow cannot CONFIRM a deploy (NX-3014 48s-collapse forensics, v12.8)"}`);
        }
    }
    const verdict = score >= 8 ? "CONFIRMS" : score <= -8 ? "CONFLICTS" : "NEUTRAL";
    return {
        verdict,
        score,
        reasons,
        metrics: m,
        oiWeight: Number(oiWeight.toFixed(2)),
        calibrated: true,
        coverage,
        blind: false,
        source: bridgeSrc ?? undefined
    };
}
}),
"[project]/src/lib/regime.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "btcSpilloverThrAdj",
    ()=>btcSpilloverThrAdj,
    "bumpRegimeTelemetry",
    ()=>bumpRegimeTelemetry,
    "classifyRegime",
    ()=>classifyRegime,
    "getRegimeCached",
    ()=>getRegimeCached,
    "getRegimeSummary",
    ()=>getRegimeSummary,
    "getRegimeTelemetry",
    ()=>getRegimeTelemetry,
    "peekRegime",
    ()=>peekRegime,
    "regimeRuling",
    ()=>regimeRuling,
    "regimeTagOf",
    ()=>regimeTagOf
]);
// ── FlowRadar Neo market-regime classifier (server-only, v6.3) ──
// Layer-0 filter for the trigger hierarchy: every candidate is priced by the
// regime it lives in. TREND regimes punish counter-trend entries, CHOP punishes
// breakout chasing, VOLATILE cuts size and widens stops.
// Pure candle math — no invented data: everything derives from real klines.
//
// ── v6.3 REGIME FILTER HARDENING (operator mandate #2) ──
// Grounds: live ledger showed 94% of deploys landed in CHOP (WR 41%, net −$)
// while TREND deploys won 83% — the old soft penalties (−7 score, ×0.8 size)
// did not actually keep the engine out of rotational chop. Changes:
//   · RegimeRuling gains thrAdj — a per-candidate MIN_SCORE threshold
//     adjustment. MIN_SCORE stops being one flat number: the EFFECTIVE
//     threshold = gate.minScore + thrAdj (+ BTC spillover at guard L2).
//   · regimeGuard levels (governor-owned knob):
//       L0 — legacy soft penalties only
//       L1 — HARD VETO: BREAKOUT/MOMENTUM in strong chop (strength ≥ 0.6);
//            heavy threshold surcharge (+10) in moderate chop
//       L2 — full guard: + BTC-spillover counter-trend surcharge (engine
//            applies btcSpilloverThrAdj) + MEAN-REVERT veto in VOLATILE
//   · Per-regime outcome telemetry (n/wins/net $) persisted so the governor
//     reads a REGIME LEDGER each cycle and tunes regimeGuard from evidence.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indicators.ts [app-route] (ecmascript)");
;
;
const memo = new Map();
const MEMO_TTL = 90_000;
function percentileRank(series, v) {
    if (series.length < 5) return 0.5;
    const below = series.filter((x)=>x <= v).length;
    return below / series.length;
}
function classifyRegime(candles) {
    if (candles.length < 80) return null;
    const closes = candles.map((c)=>c.close);
    const price = closes[closes.length - 1];
    const e9 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ema"])(closes, 9);
    const e21 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ema"])(closes, 21);
    const emaSpreadPct = (e9[e9.length - 1] - e21[e21.length - 1]) / e21[e21.length - 1] * 100;
    const a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["atr"])(candles);
    const atrPct = a > 0 ? a / price * 100 : 0.5;
    const trendPct = a === 0 ? 0 : emaSpreadPct / a * 100;
    // realized-vol percentile: current ATR% vs trailing 80-candle rolling ATR%
    const volSeries = [];
    for(let i = Math.max(15, candles.length - 80); i < candles.length; i++){
        const seg = candles.slice(Math.max(0, i - 14), i + 1);
        const av = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["atr"])(seg);
        volSeries.push(av / seg[seg.length - 1].close * 100);
    }
    const volPctile = percentileRank(volSeries, atrPct);
    // directional efficiency over last 24 completed candles (Kaufman-style)
    const win = candles.slice(-25, -1);
    const net = Math.abs(win[win.length - 1].close - win[0].open);
    const path = win.reduce((s, c)=>s + Math.abs(c.close - c.open) + Math.abs(c.high - c.low), 0) / 2;
    const efficiency = path === 0 ? 0 : Math.min(1, net / path);
    let regime;
    let note;
    if (volPctile >= 0.88 && Math.abs(trendPct) < 2.2) {
        regime = "VOLATILE";
        note = `ATR% ${atrPct.toFixed(2)} at ${Math.round(volPctile * 100)}th pctile — expansion regime, size cut`;
    } else if (Math.abs(trendPct) >= 1.1 && efficiency >= 0.33) {
        regime = trendPct > 0 ? "TREND_UP" : "TREND_DOWN";
        note = `EMA spread ${emaSpreadPct.toFixed(2)}% = ${Math.abs(trendPct).toFixed(1)}×ATR with ${(efficiency * 100).toFixed(0)}% path efficiency — ${trendPct > 0 ? "markup" : "markdown"} trend`;
    } else {
        regime = "CHOP";
        note = `path efficiency ${(efficiency * 100).toFixed(0)}% below threshold — rotational chop, breakouts decay`;
    }
    const strength = regime === "VOLATILE" ? Math.min(1, (volPctile - 0.7) / 0.3) : Math.min(1, Math.abs(trendPct) / 2.6) * 0.6 + efficiency * 0.4;
    const label = regime === "TREND_UP" ? "TREND ▲" : regime === "TREND_DOWN" ? "TREND ▼" : regime === "CHOP" ? "CHOP ∿" : "VOLATILE ⚡";
    return {
        regime,
        strength: Number(strength.toFixed(2)),
        atrPct: Number(atrPct.toFixed(2)),
        trendPct: Number(trendPct.toFixed(2)),
        volPctile: Number(volPctile.toFixed(2)),
        efficiency: Number(efficiency.toFixed(2)),
        label,
        note
    };
}
function getRegimeCached(symbol, candles) {
    if (!candles || candles.length < 80) return null;
    const hit = memo.get(symbol);
    if (hit && Date.now() - hit.at < MEMO_TTL) return hit.regime;
    const r = classifyRegime(candles);
    if (r) memo.set(symbol, {
        at: Date.now(),
        regime: r
    });
    return r;
}
function peekRegime(symbol) {
    const hit = memo.get(symbol);
    return hit && Date.now() - hit.at < MEMO_TTL * 4 ? hit.regime : null;
}
function regimeRuling(regime, direction, strategy, guard = 1) {
    if (!regime) return {
        ok: true,
        sizeMult: 1,
        slMult: 1,
        scoreAdj: 0,
        thrAdj: 0,
        tag: "REGIME-UNKNOWN"
    };
    const long = direction === "LONG";
    if (regime.regime === "TREND_UP") {
        if (!long && strategy === "MEAN-REVERT") return {
            ok: false,
            reason: `TREND ▲ (${regime.note}) — counter-trend short mean-revert vetoed`,
            sizeMult: 0,
            slMult: 1,
            scoreAdj: 0,
            thrAdj: 0,
            tag: "REGIME-TREND-UP"
        };
        if (!long) return {
            ok: true,
            sizeMult: 0.75,
            slMult: 1.1,
            scoreAdj: -6,
            thrAdj: 8,
            reason: "short against markup trend — penalized (+8 threshold)",
            tag: "REGIME-TREND-UP"
        };
        return {
            ok: true,
            sizeMult: 1,
            slMult: 1,
            scoreAdj: 4,
            thrAdj: -5,
            reason: "with-trend long in markup (−5 threshold: trend alignment admits more)",
            tag: "REGIME-TREND-UP"
        };
    }
    if (regime.regime === "TREND_DOWN") {
        if (long && strategy === "MEAN-REVERT") return {
            ok: false,
            reason: `TREND ▼ (${regime.note}) — counter-trend long mean-revert vetoed`,
            sizeMult: 0,
            slMult: 1,
            scoreAdj: 0,
            thrAdj: 0,
            tag: "REGIME-TREND-DOWN"
        };
        if (long) return {
            ok: true,
            sizeMult: 0.75,
            slMult: 1.1,
            scoreAdj: -6,
            thrAdj: 8,
            reason: "long against markdown trend — penalized (+8 threshold)",
            tag: "REGIME-TREND-DOWN"
        };
        return {
            ok: true,
            sizeMult: 1,
            slMult: 1,
            scoreAdj: 4,
            thrAdj: -5,
            reason: "with-trend short in markdown (−5 threshold: trend alignment admits more)",
            tag: "REGIME-TREND-DOWN"
        };
    }
    if (regime.regime === "CHOP") {
        // ── v9.3 STRONGER CHOP LADDER (operator mandate — «فیلتر قوی‌تر CHOP») ──
        // REGIME LEDGER evidence: 197 of 218 EPOCH-2 closes carried REGIME-CHOP at
        // WR 25.9% / −$29.98 — the old ladder (veto only BREAKOUT/MOMENTUM in
        // strong chop) let the other strategies bleed freely. New guard-governed
        // ladder: L1 vetoes ALL breakout/momentum in ANY chop and taxes every
        // other strategy hard in strong chop; L2 vetoes everything in chop.
        // (v9.4 amendment below: L2 is now the ASYMMETRIC activation — SHORT
        // admitted through the tax ladder, LONG stays vetoed, ledger-cited.)
        //
        // ── v9.4 ASYMMETRIC CHOP LADDER (EQ-100 operator mandate 2026-10-13:
        // «ممیزی کامل … رژیم CHOP را فعال کن») — the blanket L2 chop stop was an
        // over-fit to the AGGREGATE ledger (CHOP cell n=2011 WR 34% net −$16.12).
        // Deep direction-split forensics of the same ledger (EQ-100 audit,
        // 1795 settled REGIME-CHOP rows): the damage is entirely LONG-side while
        // the SHORT book EARNED in every window, including under the CURRENT
        // guard stack (shortGuard=1 HTF-align + QUAD-SHORT + STRATW, FLAT-10):
        //   LONG  book: −$123.69 all-time (n=1031) · −$111.22 Oct · −$108.09 W41+42
        //   SHORT book:  +$37.42 all-time (n=621)  ·  +$37.67 Oct ·  +$40.49 W41+42
        //     AI-SWING|SHORT  +$36.89 W41+42 (n=105, WR 41%)
        //     MEAN-REVERT|SHORT +$12.04 W41+42 (n=51, WR 56.9% — doctrinal rotation fit)
        //   Structural driver: 86% of CHOP rows never touch TP1 (1537/1795
        //   reachedTp=0) — LONGs round-trip via EXPIRED fees + deep −1R stops,
        //   while counter-rotation shorts monetize the decay.
        // L2 is therefore RE-OPENED asymmetrically: LONG vetoed (evidence-ledger),
        // SHORT admitted through the L1 tax ladder (strong chop ×0.7/+10thr,
        // moderate ×0.85/+6thr) — FLAT-10 keeps every margin at exactly $10, the
        // size multipliers remain TAG-ONLY audit metadata. BREAKOUT/MOMENTUM keep
        // their unconditional hard veto (0/9, −$2.58 in chop).
        const strongChop = regime.strength >= 0.6;
        // ── v11.6 CHOP FINAL ACTIVATION (EQ-100 re-audit 2026-10-14, full 2411-row
        // ledger restored from GitHub d7cef8d) ── the asymmetric verdict is
        // CONFIRMED on the complete book:
        //   CHOP all-time: LONG −$959.39 (n=1100, WR 33.3%) · SHORT +$1171.84
        //   (n=812, WR 36.3%). Anatomy: TP1-touch LONG 18.7% vs SHORT 20.3%;
        //   expired-drift LONG −2.95% vs SHORT +0.70%; avgLoss −9.61 vs avgWin
        //   +18.5 — rotational decay bleeds longs and monetizes shorts.
        //   Recent-14d CHOP SHORT cells: AI-SWING +$657.31 (n=266, WR 41.4%) ·
        //   MEAN-REVERT +$416.88 (n=141, WR 43.3%) — the admitted SHORT tax ladder
        //   IS the data-driven CHOP activation and stays live (post-ladder cohort
        //   Oct-13: 5/5 SHORT, 3 wins, +$82.64; post-recovery signals #2410/2411
        //   deployed SHORT in CHOP).
        // NEW CELL FLIP (v11.6): AI-SCALP|CHOP is deep-negative BOTH sides in the
        // recent window (14d: LONG −$245.63 n=146 WR 24% · SHORT −$169.39 n=102
        // WR 19.6%; all-time it was +$31.48 WR 33.3% — the cell decayed through
        // it) and the L1 tax does not save it. AI-SCALP therefore joins
        // BREAKOUT/MOMENTUM in the unconditional CHOP hard-veto. This is the
        // STRUCTURAL half of the fix; the TEMPORAL half is the EQ-97 STRAT-PAUSE
        // switch engaged on AI-SCALP book-wide (non-CHOP cells also bleed) — the
        // veto survives any pause-lift until the cell re-earns its way out.
        if (strategy === "BREAKOUT" || strategy === "MOMENTUM" || strategy === "AI-SCALP") {
            // v6.3 evidence: BREAKOUT in chop bled −$28 at WR 28% — a soft −7 penalty
            // did not keep the engine out. v9.3: guard L1+ hard-vetoes ANY chop
            // (strong or moderate); guard 0 still vetoes the strong-chop extreme.
            // v9.4 ledger re-check: 9 settled chop rows, 0 wins, −$2.58 — veto stands.
            // v11.6: AI-SCALP joins (ledger: scalp decay −$169/−$245 recent-14d, WR
            // 19.6%/24% — above).
            const vetoFamily = strategy === "AI-SCALP" ? "scalp VETOED in chop (v11.6 cell-flip: AI-SCALP −$169.39 SHORT / −$245.63 LONG recent-14d, WR 19.6%/24% — tax ladder cannot save a decayed cell)" : "breakout/momentum VETOED in chop";
            if (guard >= 1 || strongChop) {
                return {
                    ok: false,
                    reason: `CHOP (${regime.note}) — ${vetoFamily} (guard L${guard}, strength ${regime.strength.toFixed(2)}${strongChop ? ", strong" : ""}; ledger 197/218 closes CHOP −$29.98)`,
                    sizeMult: 0,
                    slMult: 1,
                    scoreAdj: 0,
                    thrAdj: 0,
                    tag: "REGIME-CHOP"
                };
            }
            return {
                ok: true,
                sizeMult: 0.7,
                slMult: 1,
                scoreAdj: -7,
                thrAdj: 8,
                reason: `CHOP (${regime.note}) — ${strategy === "AI-SCALP" ? "scalp" : "breakout/momentum"} decays, +8 threshold + size cut ×0.7 (guard L0 moderate-chop residual)`,
                tag: "REGIME-CHOP"
            };
        }
        // v9.4 ASYMMETRIC GUARD L1+ — the EQ-100 activation. NOTE: the asymmetry
        // must hold at L1 TOO, not only at L2: the W41+42 LONG bleed (−$108.09)
        // accrued UNDER L1-style taxation — the tax does not save the LONG book.
        // Live correction: the AI governor auto-softened L2→L1 minutes after the
        // v9.4 deploy (its knob, legal) which would have re-opened the condemned
        // cohort — so the LONG veto is pinned to guard ≥ 1; guard 0 (explicit
        // legacy softening) is the only path that re-opens CHOP LONGs.
        if (guard >= 1) {
            if (long) {
                return {
                    ok: false,
                    reason: `CHOP (${regime.note}) — LONG vetoed in chop at guard L${guard} (EQ-100 ledger: LONG −$111.22 Oct / −$108.09 W41+42, TP1-touch only 14% — rotational decay, strength ${regime.strength.toFixed(2)})`,
                    sizeMult: 0,
                    slMult: 1,
                    scoreAdj: 0,
                    thrAdj: 0,
                    tag: "REGIME-CHOP"
                };
            }
            // v13.4-operator — CHOP SHORT OPENED (operator mandate trace 1a1ae0a3a58bd421, 2026-11-05): the EQ-100 ledger itself crowns CHOP SHORT the winning cohort (+$40.49 W41+42, MR|S WR 56.9%) while the +10/+6 threshold tax was the clean-window suppressor behind the issuance drought. Threshold+conviction tax REMOVED; the size haircut (×0.7/×0.85) is KEPT as residual risk discipline. LONG veto and the BREAKOUT/MOMENTUM/AI-SCALP hard vetoes are UNTOUCHED (protective walls stay).
            return strongChop ? {
                ok: true,
                sizeMult: 0.7,
                slMult: 1,
                scoreAdj: 0,
                thrAdj: 0,
                reason: `CHOP strong (${regime.note}) — SHORT OPENED in chop per operator mandate (EQ-100: CHOP SHORT +$40.49 W41+42, MR|S WR 56.9%): base threshold, size ×0.7 kept`,
                tag: "REGIME-CHOP"
            } : {
                ok: true,
                sizeMult: 0.85,
                slMult: 1,
                scoreAdj: 0,
                thrAdj: 0,
                reason: `CHOP (${regime.note}) — SHORT OPENED in chop per operator mandate (EQ-100: CHOP SHORT +$40.49 W41+42, AI-SWING|S +$36.89 WR41%): base threshold, size ×0.85 kept`,
                tag: "REGIME-CHOP"
            };
        }
        // guard 0 — legacy soft ladder (explicit operator softening only)
        if (strongChop) {
            return {
                ok: true,
                sizeMult: 0.7,
                slMult: 1,
                scoreAdj: -6,
                thrAdj: 10,
                reason: `CHOP strong (${regime.note}) — rotational decay taxes all strategies: +10 threshold, size ×0.7, conviction −6`,
                tag: "REGIME-CHOP"
            };
        }
        return {
            ok: true,
            sizeMult: 0.85,
            slMult: 1,
            scoreAdj: 0,
            thrAdj: 2,
            reason: `rotational regime — mean-revert favored (+2 threshold) (guard L0 legacy soft path)`,
            tag: "REGIME-CHOP"
        };
    }
    // VOLATILE — v6.3: expansion regimes tax EVERY entry (unpredictable wick risk);
    // at guard L2 mean-revert is also vetoed (catching knives in vol spikes).
    if (guard >= 2 && strategy === "MEAN-REVERT") {
        return {
            ok: false,
            reason: `VOLATILE (${regime.note}) — mean-revert vetoed in vol expansion (guard L2 — no knife-catching)`,
            sizeMult: 0,
            slMult: 1.3,
            scoreAdj: 0,
            thrAdj: 0,
            tag: "REGIME-VOLATILE"
        };
    }
    return {
        ok: true,
        sizeMult: 0.6,
        slMult: 1.3,
        scoreAdj: 0,
        thrAdj: 6,
        reason: `VOLATILE (${regime.note}) — margin ×0.6, stops ×1.3, +6 threshold`,
        tag: "REGIME-VOLATILE"
    };
}
function btcSpilloverThrAdj(btcRegime, symbol, direction) {
    if (!btcRegime || symbol === "BTCUSDT" || symbol === "ETHUSDT") return {
        adj: 0,
        reason: null
    };
    if (btcRegime.regime === "TREND_DOWN" && direction === "LONG") return {
        adj: 5,
        reason: `BTC TREND ▼ spillover (+5 threshold on counter-BTC long)`
    };
    if (btcRegime.regime === "TREND_UP" && direction === "SHORT") return {
        adj: 5,
        reason: `BTC TREND ▲ spillover (+5 threshold on counter-BTC short)`
    };
    return {
        adj: 0,
        reason: null
    };
}
// ── v6.3 REGIME OUTCOME TELEMETRY — per-regime realized ledger ──
// resolveSignals bumps this on every close (tag parsed from signal tags); the
// governor reads it as the REGIME LEDGER and tunes regimeGuard from evidence.
const REGIME_TELEMETRY_KEY = "regime.telemetry";
function regimeTagOf(tags) {
    if (!tags) return null;
    const t = tags.split(",").find((x)=>x.startsWith("REGIME-"));
    return t ? t.replace("REGIME-", "") : null;
}
async function bumpRegimeTelemetry(tag, win, pnlUsd) {
    let tel = {};
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: REGIME_TELEMETRY_KEY
            }
        });
        if (row) tel = JSON.parse(row.value);
    } catch  {
    /* fresh */ }
    const cell = tel[tag] ?? {
        n: 0,
        wins: 0,
        pnlUsd: 0
    };
    cell.n += 1;
    if (win) cell.wins += 1;
    cell.pnlUsd = Number((cell.pnlUsd + pnlUsd).toFixed(2));
    tel[tag] = cell;
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: REGIME_TELEMETRY_KEY
        },
        create: {
            key: REGIME_TELEMETRY_KEY,
            value: JSON.stringify(tel)
        },
        update: {
            value: JSON.stringify(tel)
        }
    });
}
async function getRegimeTelemetry() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: REGIME_TELEMETRY_KEY
            }
        });
        if (row) return JSON.parse(row.value);
    } catch  {
    /* fresh */ }
    return {};
}
function getRegimeSummary() {
    const out = [];
    for (const [sym, hit] of memo){
        if (Date.now() - hit.at < MEMO_TTL * 4) {
            out.push({
                symbol: sym,
                regime: hit.regime.regime,
                label: hit.regime.label,
                strength: hit.regime.strength
            });
        }
    }
    return out.sort((a, b)=>b.strength - a.strength).slice(0, 12);
}
}),
"[project]/src/lib/macro.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getMacroSnapshot",
    ()=>getMacroSnapshot,
    "macroHealth",
    ()=>macroHealth,
    "peekMacro",
    ()=>peekMacro
]);
// ── FlowRadar Neo v6.2 macro layer — key-less Fear & Greed feed ─────────
// Architecture review P2 remediation: L4_MACRO was a PERMANENT OBSERVER
// ("no key-less measurable source — never fabricated"). There IS a key-less,
// free, measurable macro sentiment source: the Crypto Fear & Greed Index
// (alternative.me, no API key, aggregated from volatility/momentum/social/
// dominance/trend across the market). This module fetches it on a 30min
// cache with honest degradation: any failure returns null and the trigger
// bus keeps its previous honest "OBSERVING" declaration instead of inventing
// data. Extremes become measurable L4 context triggers (contrarian side).
const FNG_URL = "https://api.alternative.me/fng/?limit=1";
const CACHE_TTL_MS = 30 * 60_000;
const FETCH_TIMEOUT_MS = 6000;
let cache = null;
let inflight = null;
let lastError = null;
async function fetchFng() {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), FETCH_TIMEOUT_MS);
    try {
        const res = await fetch(FNG_URL, {
            signal: ctrl.signal,
            cache: "no-store"
        });
        if (!res.ok) {
            lastError = `HTTP ${res.status}`;
            return null;
        }
        const json = await res.json();
        const row = json.data?.[0];
        const value = Number(row?.value);
        if (!Number.isFinite(value) || value < 0 || value > 100) {
            lastError = "malformed payload";
            return null;
        }
        lastError = null;
        return {
            value,
            classification: row?.value_classification ?? "Unknown",
            fetchedAt: Date.now()
        };
    } catch (e) {
        lastError = e instanceof Error ? e.name : "network error";
        return null;
    } finally{
        clearTimeout(timer);
    }
}
async function getMacroSnapshot() {
    if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) return cache;
    if (!inflight) {
        inflight = fetchFng().then((snap)=>{
            if (snap) cache = snap;
            return snap;
        }).finally(()=>{
            inflight = null;
        });
    }
    return inflight;
}
function peekMacro() {
    return cache;
}
function macroHealth() {
    if (!cache) return {
        hasData: false,
        value: null,
        classification: null,
        ageMin: null,
        lastError
    };
    return {
        hasData: true,
        value: cache.value,
        classification: cache.classification,
        ageMin: Math.round((Date.now() - cache.fetchedAt) / 60_000),
        lastError: null
    };
}
}),
"[project]/src/lib/oi-funding.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getOiFundBoard",
    ()=>getOiFundBoard,
    "maybeOiFundScan",
    ()=>maybeOiFundScan,
    "peekOiFund",
    ()=>peekOiFund
]);
// ── FlowRadar Neo v8.1 OI / FUNDING BOARD (P1 liq-deepening, server-only) ──
// Operator mandate 2026-09-08: «طبق نظر مهندسی P1 و P2 رو کامل اجرا کن».
//
// What P1 adds on top of the existing reactive L3 cascade layer:
//   · a PERSISTENT derivatives board covering the tracked domain with OI deltas
//     across three horizons (15m / 1h / 4h) + funding carry + OI notional —
//     flow.ts only computes a 1h delta on demand with no board.
//   · the raw material the predictive L3-PRE layer needs: "positions still
//     piling in near a liquidation cluster" is a cascade BEFORE it happens.
//
// Cadence & budget (mirrors flow-scanner doctrine): rotating batch of 6
// symbols per call, ≥60s between calls → ~12 REST calls/min worst case on top
// of the flow scanner's ~24. Board persisted as ONE EngineSetting row
// (race-free by construction), in-memory map bounded at 64 symbols.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)");
;
;
;
const BOARD_KEY = "oifund.board";
const BATCH = 6;
const MIN_INTERVAL_MS = 60_000;
const BOARD_CAP = 64;
// ── bounded cache + in-flight dedupe (flow-scanner pattern) ──
const board = new Map();
let boardLoaded = false;
let scanCursor = 0;
let lastScanAt = 0;
let scanInFlight = false;
async function loadBoard() {
    if (boardLoaded) return;
    boardLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: BOARD_KEY
            }
        });
        if (row) {
            const parsed = JSON.parse(row.value);
            for (const r of parsed.rows ?? [])board.set(r.symbol, r);
        }
    } catch  {
    /* cold start — the scanner repopulates within ~10min */ }
}
async function persistBoard() {
    const rows = [
        ...board.values()
    ].sort((a, b)=>(b.oiUsd ?? 0) - (a.oiUsd ?? 0)).slice(0, BOARD_CAP);
    const value = JSON.stringify({
        at: Date.now(),
        rows
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: BOARD_KEY
        },
        create: {
            key: BOARD_KEY,
            value
        },
        update: {
            value
        }
    });
}
// v10.24 Task 34-a: fapi REST goes through the central fapi-gate (telemetry
// lane — a shedded rotation returns nulls and the board keeps its previous
// rows; the op-audit-20260908 carry-over semantics still apply downstream).
async function fapi(path, timeoutMs = 6000) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "telemetry",
        timeoutMs
    });
}
async function scanSymbol(symbol, prem, prev) {
    // v12.2 TASK-52 — OI LADDER: fapi openInterestHist (perp-native; v14.0 — the
    // only rung; on a fapi ban the scan honestly returns null, no invented rows).
    const histB = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeOiHist"])(symbol, "15m", 17).catch(()=>null);
    if (!histB || histB.rows.length < 4) return null; // honest — no invented rows
    const hist = histB.rows.map((r)=>({
            sumOpenInterest: String(r.sumOpenInterest),
            sumOpenInterestValue: String(r.sumOpenInterestValue ?? 0),
            timestamp: r.timestamp
        }));
    const oi = hist.map((h)=>Number(h.sumOpenInterest));
    const cur = oi[oi.length - 1];
    const pct = (barsBack)=>{
        const ref = oi[oi.length - 1 - barsBack];
        return ref !== undefined && ref > 0 ? Number(((cur - ref) / ref * 100).toFixed(2)) : null;
    };
    // z-score of the last 1h change vs its own distribution across the window
    let oiZ1h = null;
    const d1h = pct(4);
    if (d1h !== null && oi.length >= 10) {
        const deltas = [];
        for(let i = 4; i < oi.length; i++){
            const ref = oi[i - 4];
            if (ref > 0) deltas.push((oi[i] - ref) / ref * 100);
        }
        if (deltas.length >= 5) {
            const mean = deltas.reduce((a, b)=>a + b, 0) / deltas.length;
            const std = Math.sqrt(deltas.reduce((a, b)=>a + (b - mean) * (b - mean), 0) / deltas.length);
            if (std > 0) oiZ1h = Number(((d1h - mean) / std).toFixed(2));
        }
    }
    const oiUsdRow = Number(hist[hist.length - 1]?.sumOpenInterestValue ?? 0) || null;
    let oiUsd = oiUsdRow;
    if (!oiUsd) {
        // v14.0 — notional fallback from the Binance composite ticker leg (fapi
        // openInterest × markPrice); null honestly when the fapi plane is banned.
        oiUsd = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerRow"])(symbol).catch(()=>null))?.openInterestValue ?? null;
    }
    // op-audit-20260908: when the batch premiumIndex call missed (transient fapi
    // weight pressure), CARRY OVER the previous funding fields instead of
    // overwriting good data with nulls — funding changes every 8h, staleness of
    // one rotation is harmless, data loss was not.
    return {
        symbol,
        at: Date.now(),
        markPrice: prem ? Number(prem.markPrice) || null : prev?.markPrice ?? null,
        funding8h: prem ? Number((Number(prem.lastFundingRate) * 100).toFixed(4)) : prev?.funding8h ?? null,
        nextFundingAt: prem ? Number(prem.nextFundingTime) || null : prev?.nextFundingAt ?? null,
        oiBase: cur,
        oiUsd: oiUsd ? Number((oiUsd / 1e6).toFixed(2)) : null,
        oiDelta15m: pct(1),
        oiDelta1h: d1h,
        oiDelta4h: pct(16),
        oiZ1h,
        src: histB.source
    };
}
async function maybeOiFundScan(symbols) {
    await loadBoard();
    if (scanInFlight || symbols.length === 0) return;
    if (Date.now() - lastScanAt < MIN_INTERVAL_MS) return;
    scanInFlight = true;
    lastScanAt = Date.now();
    try {
        const batch = [];
        for(let i = 0; i < Math.min(BATCH, symbols.length); i++)batch.push(symbols[(scanCursor + i) % symbols.length]);
        scanCursor = (scanCursor + batch.length) % symbols.length;
        // op-audit-20260908: ONE batched premiumIndex call (no symbol param → ALL
        // markers, weight ~10) replaces 6 per-symbol calls per rotation — funding
        // coverage climbs 6/33 → full domain in one pass AND the per-second fapi
        // weight bursts that tripped -1003 endpoint bans disappear.
        // v12.2 TASK-52 (v14.0 rewrite): when the fapi batch starves, the Binance
        // composite ticker leg feeds the whole rotation instead — the board
        // carries funding only when the fapi plane priced it (spot rows keep
        // funding honestly null, so the carry-over guard below stays truthful).
        const premRows = await fapi(`/fapi/v1/premiumIndex`).catch(()=>null);
        let premMap = new Map();
        for (const p of premRows ?? [])if (p?.symbol) premMap.set(p.symbol, p);
        if (premMap.size === 0) {
            const tickers = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["futTickerMap"])().catch(()=>null);
            if (tickers && tickers.size > 0) {
                console.log(`[oi-funding] fapi premiumIndex starved — Binance composite ticker board (${tickers.size} symbols, v14.0)`);
                for (const symbol of batch){
                    const t = tickers.get(symbol);
                    if (t && t.fundingRate !== null) {
                        premMap.set(symbol, {
                            lastFundingRate: String(t.fundingRate),
                            markPrice: String(t.markPrice ?? t.lastPrice),
                            nextFundingTime: t.nextFundingTime ?? 0
                        });
                    }
                }
            }
        }
        for (const symbol of batch){
            const prev = board.get(symbol) ?? null;
            const row = await scanSymbol(symbol, premMap.get(symbol) ?? null, prev).catch(()=>null);
            if (row) board.set(symbol, row);
        }
        await persistBoard();
    } finally{
        scanInFlight = false;
    }
}
function peekOiFund(symbol) {
    const r = board.get(symbol);
    if (!r || Date.now() - r.at > 20 * 60_000) return null;
    return r;
}
async function getOiFundBoard() {
    await loadBoard();
    const rows = [
        ...board.values()
    ].sort((a, b)=>(b.oiUsd ?? 0) - (a.oiUsd ?? 0));
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows: rows.slice(0, 48).map((r)=>({
                ...r,
                oiUsdM: r.oiUsd
            }))
    };
}
}),
"[project]/src/lib/liq-heatmap.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLiqHeat",
    ()=>getLiqHeat,
    "getLiqHeatBoard",
    ()=>getLiqHeatBoard,
    "peekLiqHeat",
    ()=>peekLiqHeat
]);
// ── FlowRadar Neo v8.1 LIQUIDATION HEATMAP (P1 liq-deepening, server-only) ──
// Operator mandate 2026-09-08: «طبق نظر مهندسی P1 و P2 رو کامل اجرا کن».
//
// HONESTY CONTRACT: no exchange publishes leveraged-position maps. This module
// computes the standard volume-mapped ESTIMATE used by Coinglass-class tools:
// recent traded volume is bucketed by price, each bucket is projected through
// the popular leverage tiers (liq price = entry × (1 ∓ 1/lev)), and the
// projected mass is scaled by the symbol's REAL open-interest notional from
// the oi-funding board. Every surface that renders it must keep the
// "ESTIMATE" label — the module refuses to emit numbers when its inputs
// (klines, OI) are missing rather than inventing them.
//
// Semantics (the doctrine that drives the engine hooks):
//   · clusters BELOW price  = long liquidations  — flush fuel: price falling
//     into them tends to ACCELERATE down (magnet for an open/new LONG).
//   · clusters ABOVE price  = short liquidations — squeeze fuel: rallies into
//     them tend to ACCELERATE up (magnet for an open/new SHORT).
//
// Memory law: per-symbol result cache TTL 180s, map bounded at 64 symbols
// (evict-oldest), klines reused from the flow scanner cache when fresh —
// zero extra kline fetches on the hot path.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)"); // v12.3 TASK-52 — kline ladder · v14.0 Binance-only
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$oi$2d$funding$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/oi-funding.ts [app-route] (ecmascript)");
;
;
;
const LEV_TIERS = [
    {
        lev: 10,
        weight: 0.40
    },
    {
        lev: 25,
        weight: 0.35
    },
    {
        lev: 50,
        weight: 0.25
    }
];
const BAND_PCT = 8; // map ±8% around price
const BUCKETS = 24;
const CLUSTER_MIN_SHARE = 0.06; // a bucket needs ≥6% of mapped mass to be "significant"
const CACHE_TTL = 180_000;
const CACHE_CAP = 64;
const heatCache = new Map();
const heatInFlight = new Map();
function evictOldest() {
    if (heatCache.size <= CACHE_CAP) return;
    const oldest = [
        ...heatCache.entries()
    ].sort((a, b)=>a[1].at - b[1].at)[0];
    if (oldest) heatCache.delete(oldest[0]);
}
// v10.24 Task 34-a: klines fetch went through the central fapi-gate.
// v12.3 TASK-52: SPOT-MIRROR is rung 1 (separate rate/ban pool — heat mass is
// volume×price math, venue-agnostic); fapi gate is rung 2. v14.0 Binance-only:
// the heatmap degrades honestly to null when both rungs fail.
async function fetchKlines15m(symbol) {
    const spot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotMirrorKlines"])(symbol, "15m", 96).catch(()=>null);
    if (spot && spot.length > 0) {
        return spot.map((k)=>({
                openTime: k.openTime,
                open: k.open,
                high: k.high,
                low: k.low,
                close: k.close,
                volume: k.volume
            }));
    }
    const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=15m&limit=96`, {
        priority: "telemetry",
        timeoutMs: 6500
    }).catch(()=>null);
    if (raw && raw.length > 0) {
        return raw.map((k)=>({
                openTime: Number(k[0]),
                open: Number(k[1]),
                high: Number(k[2]),
                low: Number(k[3]),
                close: Number(k[4]),
                volume: Number(k[5])
            }));
    }
    return null;
}
/** Compute the estimated heatmap for one symbol. Returns null when inputs are missing. */ async function computeHeat(symbol, klines) {
    if (!klines || klines.length < 24) return null;
    const candles = klines.slice(0, -1); // closed bars only
    const price = candles[candles.length - 1].close;
    if (!(price > 0)) return null;
    const oiRow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$oi$2d$funding$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekOiFund"])(symbol);
    const oiUsdM = oiRow?.oiUsd ?? null;
    // volume mass per price bucket across the ±8% band (vwap-ish weighting by recency)
    const lo = price * (1 - BAND_PCT / 100);
    const hi = price * (1 + BAND_PCT / 100);
    const step = (hi - lo) / BUCKETS;
    const mass = new Float64Array(BUCKETS);
    const recent = candles.slice(-64); // last 16h of 15m bars
    let bandVol = 0;
    for(let i = 0; i < recent.length; i++){
        const c = recent[i];
        const mid = (c.high + c.low + c.close) / 3;
        if (mid < lo || mid > hi) continue;
        const idx = Math.min(BUCKETS - 1, Math.max(0, Math.floor((mid - lo) / step)));
        mass[idx] += c.volume * (0.5 + i / recent.length * 0.5); // linear recency weight
        bandVol += c.volume;
    }
    if (bandVol <= 0) return null;
    // project each bucket's mass through the leverage tiers, BOTH directions:
    //   bucket price treated as entry → long liq price = entry×(1−1/lev),
    //   short liq price = entry×(1+1/lev); the liq price lands in another bucket.
    const below = new Float64Array(BUCKETS); // long-liq mass per bucket
    const above = new Float64Array(BUCKETS); // short-liq mass per bucket
    const scale = oiUsdM !== null && oiUsdM > 0 ? oiUsdM / bandVol : 1; // $M per unit volume (unscaled → unitless proxy)
    for(let i = 0; i < BUCKETS; i++){
        if (mass[i] <= 0) continue;
        const entry = lo + step * (i + 0.5);
        for (const { lev, weight } of LEV_TIERS){
            const liqLong = entry * (1 - 1 / lev);
            const liqShort = entry * (1 + 1 / lev);
            const w = mass[i] * weight;
            const li = Math.floor((liqLong - lo) / step);
            if (li >= 0 && li < BUCKETS) below[li] += w;
            const si = Math.floor((liqShort - lo) / step);
            if (si >= 0 && si < BUCKETS) above[si] += w;
        }
    }
    // scale is $M per unit base volume (oiUsdM / bandVol) — v is in base units,
    // so v×scale is ALREADY $M. Bug fix 2026-09-08: the previous /1e6 here was a
    // double division (the 1e6 conversion already happened in `scale`) which
    // collapsed every cluster to $0.0M on the board.
    const toUsdM = (v)=>Number((v * scale).toFixed(2));
    const sumBelow = below.reduce((a, b)=>a + b, 0);
    const sumAbove = above.reduce((a, b)=>a + b, 0);
    const total = sumBelow + sumAbove;
    if (total <= 0) return null;
    const clusters = [];
    const push = (i, v, side)=>{
        const share = v / total;
        if (share < CLUSTER_MIN_SHARE) return;
        const p = lo + step * (i + 0.5);
        clusters.push({
            side,
            price: Number(p.toFixed(p > 100 ? 2 : 6)),
            distPct: Number(((p - price) / price * 100).toFixed(2)),
            estUsdM: toUsdM(v),
            sharePct: Number((share * 100).toFixed(1))
        });
    };
    for(let i = 0; i < BUCKETS; i++){
        if (below[i] > 0) push(i, below[i], "LONGS_BELOW");
        if (above[i] > 0) push(i, above[i], "SHORTS_ABOVE");
    }
    clusters.sort((a, b)=>Math.abs(a.distPct) - Math.abs(b.distPct));
    const nearestBelow = clusters.find((c)=>c.side === "LONGS_BELOW") ?? null;
    const nearestAbove = clusters.find((c)=>c.side === "SHORTS_ABOVE") ?? null;
    return {
        symbol,
        at: Date.now(),
        price: Number(price.toFixed(price > 100 ? 2 : 6)),
        oiUsdM,
        oiScaled: oiUsdM !== null && oiUsdM > 0,
        totalBelowUsdM: toUsdM(sumBelow),
        totalAboveUsdM: toUsdM(sumAbove),
        clusters: clusters.slice(0, 12),
        nearestBelow,
        nearestAbove
    };
}
async function loadKlines(symbol) {
    // reuse the flow scanner's fresh 15m cache when available (no extra fetch)
    try {
        const m = await __turbopack_context__.A("[project]/src/lib/flow-scanner.ts [app-route] (ecmascript, async loader)");
        const cached = m.peekFlowKlines(symbol, "15m");
        if (cached && cached.length >= 24) return cached;
    } catch  {
    /* fall through to own fetch */ }
    return fetchKlines15m(symbol);
}
async function getLiqHeat(symbol) {
    const hit = heatCache.get(symbol);
    if (hit && Date.now() - hit.at < CACHE_TTL) return hit.v;
    const existing = heatInFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        const klines = await loadKlines(symbol).catch(()=>null);
        const v = await computeHeat(symbol, klines).catch(()=>null);
        heatCache.set(symbol, {
            at: Date.now(),
            v
        });
        evictOldest();
        return v;
    })();
    heatInFlight.set(symbol, p);
    try {
        return await p;
    } finally{
        heatInFlight.delete(symbol);
    }
}
function peekLiqHeat(symbol) {
    const hit = heatCache.get(symbol);
    if (!hit || !hit.v || Date.now() - hit.at > CACHE_TTL) return null;
    return hit.v;
}
async function getLiqHeatBoard(limit = 10) {
    const { getOiFundBoard } = await __turbopack_context__.A("[project]/src/lib/oi-funding.ts [app-route] (ecmascript, async loader)");
    const board = await getOiFundBoard();
    const symbols = board.rows.slice(0, limit).map((r)=>r.symbol);
    const rows = [];
    for (const s of symbols){
        const h = await getLiqHeat(s).catch(()=>null);
        if (h) rows.push(h);
    }
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows
    };
}
}),
"[project]/src/lib/vol-forecast.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getKlines15m",
    ()=>getKlines15m,
    "getVolBoard",
    ()=>getVolBoard,
    "getVolForecast",
    ()=>getVolForecast,
    "peekVolForecast",
    ()=>peekVolForecast,
    "volGeometry",
    ()=>volGeometry
]);
// ── FlowRadar Neo v8.1 VOLATILITY FORECAST (P2, server-only) ─────────────
// Operator mandate 2026-09-08: «طبق نظر مهندسی P1 و P2 رو کامل اجرا کن».
//
// Model — deterministic, measured only, closed bars only:
//   · EWMA(λ=0.94) on 15m log returns (RiskMetrics recursion) → ewmaBarPct
//     scaled by √4 to the 1h horizon → ewma1hPct
//   · HAR-lite realized blend over the 6h window → har6hPct
//   · ATR%(14) on 15m bars → atr15mPct (shared with the liq-heat reach band)
//   · regime = ewma1hPct vs the symbol's OWN trailing distribution (percentile
//     rank over the last 96 bars, 8-bar steps) — self-referential, honest:
//     LOW <p20 · NORMAL · ELEVATED <p80 · EXTREME ≥p80
//
// Geometry contract consumed by engine.ts deploy path (volGeometry):
//   LOW      → stop ×0.90, RR +0.1  (dead tape: tighter stop, closer targets)
//   NORMAL   → ×1.00, ±0            (unchanged — tag omitted)
//   ELEVATED → stop ×1.05, RR −0.1  (room without paying the far rung)
//   EXTREME  → stop ×1.15, RR −0.2  (eruption tape: wider stop, trimmed targets)
// Cohort tags VOL-REGIME-{LOW|ELEVATED|EXTREME} feed the A/B ledger.
//
// Memory bounds: k15 cache ≤64 symbols × 97 bars (TTL 120s, in-flight dedupe),
// forecast cache ≤64 rows. No unbounded state, no invented numbers.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)"); // v12.3 TASK-52 — kline ladder · v14.0 Binance-only
;
;
;
const CACHE_TTL = 90_000; // recompute at most ~1/min per symbol
const PEEK_TTL = 10 * 60_000; // hot-path read guard — stale rows never gate
const BOARD_KEY = "volforecast.board";
const BOARD_TTL = 30 * 60_000; // persisted board feeds the API on cold boot
// ── geometry table (doctrine in the header) ──
const GEOMETRY = {
    LOW: {
        slMult: 0.9,
        rrAdj: 0.1
    },
    NORMAL: {
        slMult: 1.0,
        rrAdj: 0
    },
    ELEVATED: {
        slMult: 1.05,
        rrAdj: -0.1
    },
    EXTREME: {
        slMult: 1.15,
        rrAdj: -0.2
    }
};
function volGeometry(v) {
    if (!v) return {
        slMult: 1,
        rrAdj: 0,
        tag: null,
        note: null
    };
    if (v.regime === "NORMAL") return {
        slMult: 1,
        rrAdj: 0,
        tag: null,
        note: null
    };
    const g = GEOMETRY[v.regime];
    const tag = `VOL-REGIME-${v.regime}`;
    const note = v.regime === "LOW" ? `regime LOW (self-pct ${v.percentile}, EWMA 1h ${v.ewma1hPct.toFixed(2)}%) → stop ×0.9, targets +0.1R — dead tape, tighten` : v.regime === "ELEVATED" ? `regime ELEVATED (self-pct ${v.percentile}, EWMA 1h ${v.ewma1hPct.toFixed(2)}%) → stop ×1.05, targets −0.1R — hot tape, breathe but trim` : `regime EXTREME (self-pct ${v.percentile}, EWMA 1h ${v.ewma1hPct.toFixed(2)}%) → stop ×1.15, targets −0.2R — eruption tape, survive first`;
    return {
        slMult: g.slMult,
        rrAdj: g.rrAdj,
        tag,
        note
    };
}
const k15Cache = new Map();
const k15InFlight = new Map();
async function getKlines15m(symbol) {
    const hit = k15Cache.get(symbol);
    if (hit && Date.now() - hit.at < 120_000) return hit.candles;
    const existing = k15InFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            // v10.24 Task 34-a: klines through the central fapi-gate (telemetry lane
            // — the deploy path's volGeometry(null) is fail-open NORMAL).
            // v12.3 TASK-52: SPOT-MIRROR is rung 1 (separate rate/ban pool — the
            // vol-geometry is price-path math, venue-agnostic at bps level); fapi
            // gate is rung 2. v14.0: Binance-only — both miss → honest null.
            const spot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotMirrorKlines"])(symbol, "15m", 97);
            let candles = null;
            if (spot && spot.length > 0) {
                candles = spot.map((k)=>({
                        openTime: k.openTime,
                        open: k.open,
                        high: k.high,
                        low: k.low,
                        close: k.close
                    }));
            } else {
                const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=15m&limit=97`, {
                    priority: "telemetry",
                    timeoutMs: 6500
                });
                candles = raw ? raw.map((k)=>({
                        openTime: Number(k[0]),
                        open: Number(k[1]),
                        high: Number(k[2]),
                        low: Number(k[3]),
                        close: Number(k[4])
                    })) : null;
            }
            if (!candles) return null;
            k15Cache.set(symbol, {
                at: Date.now(),
                candles
            });
            if (k15Cache.size > 64) {
                const oldest = [
                    ...k15Cache.entries()
                ].sort((a, b)=>a[1].at - b[1].at)[0];
                if (oldest) k15Cache.delete(oldest[0]);
            }
            return candles;
        } catch  {
            return null;
        } finally{
            k15InFlight.delete(symbol);
        }
    })();
    k15InFlight.set(symbol, p);
    return p;
}
// ── core math (closed bars only — the possibly-unclosed last bar is dropped) ──
function computeForecast(symbol, raw) {
    const candles = raw ? raw.slice(0, -1) : null;
    if (!candles || candles.length < 60) return null;
    const rets = [];
    for(let i = 1; i < candles.length; i++){
        const p0 = candles[i - 1].close;
        const p1 = candles[i].close;
        if (p0 > 0 && p1 > 0) rets.push(Math.log(p1 / p0));
    }
    if (rets.length < 55) return null;
    // EWMA variance (λ=0.94), RiskMetrics recursion
    const lambda = 0.94;
    let ewmaVar = rets[0] * rets[0];
    for(let i = 1; i < rets.length; i++)ewmaVar = lambda * ewmaVar + (1 - lambda) * rets[i] * rets[i];
    const ewmaBarPct = Math.sqrt(ewmaVar) * 100;
    const ewma1hPct = ewmaBarPct * 2; // √4 bars per hour
    // HAR-lite: realized-vol blend over the 6h window (24 bars) vs 24h (96)
    const rv = (n)=>{
        const w = rets.slice(-n);
        if (w.length < Math.min(20, n)) return null;
        const mean = w.reduce((a, b)=>a + b, 0) / w.length;
        return Math.sqrt(w.reduce((a, b)=>a + (b - mean) * (b - mean), 0) / w.length) * 100;
    };
    const rv6h = rv(24);
    const rv1d = rv(96);
    const parts = [
        rv6h,
        rv1d
    ].filter((v)=>v !== null);
    if (parts.length === 0) return null;
    const har6hPct = parts.length === 2 ? 0.6 * rv6h + 0.4 * rv1d : parts[0];
    // ATR%(14) true range on 15m bars
    let atrSum = 0;
    for(let i = candles.length - 14; i < candles.length; i++){
        const c = candles[i];
        const p = candles[i - 1];
        atrSum += Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
    }
    const atr15mPct = atrSum / 14 / candles[candles.length - 1].close * 100;
    // trailing EWMA-1h distribution for the self-percentile rank (96 bars, 8-bar steps)
    const trail = [];
    for(let start = Math.max(0, rets.length - 96); start <= rets.length - 24; start += 8){
        const w = rets.slice(start, start + 24);
        if (w.length < 20) continue;
        let v = w[0] * w[0];
        for(let i = 1; i < w.length; i++)v = lambda * v + (1 - lambda) * w[i] * w[i];
        trail.push(Math.sqrt(v) * 100 * 2);
    }
    const percentile = trail.length >= 6 ? Math.round(trail.filter((v)=>v <= ewma1hPct).length / trail.length * 100) : 50;
    const regime = percentile < 20 ? "LOW" : percentile < 55 ? "NORMAL" : percentile < 80 ? "ELEVATED" : "EXTREME";
    return {
        symbol,
        at: Date.now(),
        ewmaBarPct: Number(ewmaBarPct.toFixed(3)),
        ewma1hPct: Number(ewma1hPct.toFixed(3)),
        har6hPct: Number(har6hPct.toFixed(3)),
        regime,
        percentile,
        atr15mPct: Number(atr15mPct.toFixed(3))
    };
}
// ── caches ──
const forecastCache = new Map();
const inFlight = new Map();
let boardLoaded = false;
async function loadBoard() {
    if (boardLoaded) return;
    boardLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: BOARD_KEY
            }
        });
        if (!row) return;
        const parsed = JSON.parse(row.value);
        if (Date.now() - parsed.at > BOARD_TTL) return;
        for (const r of parsed.rows ?? [])forecastCache.set(r.symbol, {
            at: r.at,
            v: r
        });
    } catch  {
    /* cold start — warms on demand */ }
}
async function persistBoard() {
    try {
        const rows = [
            ...forecastCache.values()
        ].map((e)=>e.v).slice(0, 48);
        const value = JSON.stringify({
            at: Date.now(),
            rows
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: BOARD_KEY
            },
            create: {
                key: BOARD_KEY,
                value
            },
            update: {
                value
            }
        });
    } catch  {
    /* best-effort */ }
}
async function getVolForecast(symbol) {
    await loadBoard();
    const hit = forecastCache.get(symbol);
    if (hit && Date.now() - hit.at < CACHE_TTL) return hit.v;
    const existing = inFlight.get(symbol);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            const candles = await getKlines15m(symbol);
            const v = computeForecast(symbol, candles);
            if (v) {
                forecastCache.set(symbol, {
                    at: Date.now(),
                    v
                });
                await persistBoard();
            }
            return v;
        } finally{
            inFlight.delete(symbol);
        }
    })();
    inFlight.set(symbol, p);
    return p;
}
function peekVolForecast(symbol) {
    const hit = forecastCache.get(symbol);
    if (!hit) return null;
    if (Date.now() - hit.at > PEEK_TTL) return null;
    return hit.v;
}
const SEVERITY = {
    EXTREME: 0,
    ELEVATED: 1,
    NORMAL: 2,
    LOW: 3
};
async function getVolBoard(symbols, take = 12) {
    await loadBoard();
    let computed = 0;
    for (const s of symbols){
        if (computed >= take) break;
        const hit = forecastCache.get(s);
        if (hit && Date.now() - hit.at < CACHE_TTL) continue;
        const v = await getVolForecast(s).catch(()=>null);
        if (v) computed++;
    }
    const rows = [
        ...forecastCache.values()
    ].map((e)=>e.v).sort((a, b)=>SEVERITY[a.regime] - SEVERITY[b.regime] || Math.abs(b.percentile - 50) - Math.abs(a.percentile - 50));
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows: rows.slice(0, 24)
    };
}
}),
"[project]/src/lib/triggers.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LAYER_LABEL",
    ()=>LAYER_LABEL,
    "canTriggerSpawn",
    ()=>canTriggerSpawn,
    "getTriggerBusSummary",
    ()=>getTriggerBusSummary,
    "isCounterCascadeSuppressed",
    ()=>isCounterCascadeSuppressed,
    "isCrowdCut",
    ()=>isCrowdCut,
    "markTriggerSpawn",
    ()=>markTriggerSpawn,
    "runTriggerCycle",
    ()=>runTriggerCycle,
    "scanSymbolTriggers",
    ()=>scanSymbolTriggers
]);
// ── FlowRadar Neo trigger hierarchy + event-driven bus (server-only, v5.0) ──
// Replaces "scan every 15 minutes" with REACTION: the fastest movers (taker
// sweeps, book imbalance) are millisecond-to-second phenomena — a periodic scan
// always arrives late. The bus measures the trigger-hierarchy layers on real
// exchange data and, when a trigger fires WITH fuel confirmed, hands the engine
// an immediate candidate (which still passes EVERY deployment gate).
//
// Layer  1   AGGRESSIVE TAKER SWEEP   — aggTrades same-side burst (seconds)
// Layer  1.5 ORDER-BOOK IMBALANCE     — depth top-band OBI, spoof-guarded (seconds)
// Layer  2   LIQUIDITY VACUUM / WALL  — ±2% depth map gaps & clusters (seconds-minutes)
// Layer  3   LIQUIDATION CASCADE      — REAL forceOrder stream + OI (minutes)
// Layer  3.5 LEVERAGE CROWDING        — funding extreme + OI z-jump (hours)
// Layer  4   MACRO FLOWS              — v6.2: key-less measurable source found
//            (Crypto Fear & Greed Index, alternative.me — no API key). Extreme
//            readings fire contrarian context triggers; unreachable source
//            keeps the honest OBSERVING declaration, never fabricated.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)"); // v14.2 — live ban probe backs the SURROGATE-FLOW hard gate
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow-bridge.ts [app-route] (ecmascript)"); // v12.3 TASK-52 — tape/depth ladders
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/regime.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$macro$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/macro.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liq$2d$heatmap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liq-heatmap.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$oi$2d$funding$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/oi-funding.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$vol$2d$forecast$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/vol-forecast.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const LAYER_LABEL = {
    L1_TAKER_SWEEP: "L1 · TAKER SWEEP",
    L15_OBI_IMBALANCE: "L1.5 · OBI",
    L2_VACUUM: "L2 · VACUUM",
    L3_LIQ_CASCADE: "L3 · LIQ CASCADE",
    L3P_LIQ_PRE: "L3P · LIQ PRE",
    L35_CROWD_JUMP: "L3.5 · CROWDING",
    L4_MACRO: "L4 · MACRO"
};
const RING_CAP = 40;
const PERSIST_KEY = "triggerbus";
const SPAWN_COOLDOWN_MS = 8 * 60_000; // max 1 trigger-spawned deploy / 8min
const COUNTER_CASCADE_SUPPRESS_MS = 10 * 60_000;
const CROWD_CUT_MS = 30 * 60_000;
const gState = globalThis;
const S = gState.__nexusTriggerState ?? {
    counts: {
        L1_TAKER_SWEEP: 0,
        L15_OBI_IMBALANCE: 0,
        L2_VACUUM: 0,
        L3_LIQ_CASCADE: 0,
        L3P_LIQ_PRE: 0,
        L35_CROWD_JUMP: 0,
        L4_MACRO: 0
    },
    ring: [],
    lastCycleAt: null,
    lastSpawnAt: 0
};
gState.__nexusTriggerState = S;
const { counts, ring } = S; // shared references — mutations flow through S
let cursor = 0;
let rotationSize = 40;
let cycleInFlight = false;
let macroAnnounced = false;
const cascadeUntil = new Map(); // counter-cascade suppression
const crowdCutUntil = new Map(); // size-cut windows
const lastOBI = new Map(); // spoof guard
const lastTriggerAt = new Map(); // per-symbol+layer cooldown
const measCache = new Map();
const MEAS_TTL = 35_000;
// ── measurement primitives (all real endpoints, cached) ────────
// v10.24 Task 34-a: through the central fapi-gate, CRITICAL lane — the
// reaction layer rides ahead of the telemetry scanners when the weight
// budget tightens (one 250ms negative retry, then an honest null).
async function fapi(path, timeoutMs = 5500) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
        priority: "critical",
        timeoutMs
    });
}
/** L1 — aggressive taker sweep over the last 60s of real aggTrades. */ async function measureTakerSweep(symbol) {
    const ck = `agg:${symbol}`;
    const hit = measCache.get(ck);
    if (hit && Date.now() - hit.at < MEAS_TTL) return hit.v;
    // v12.3 TASK-52: fapi aggTrades (w20) is rung 1 — during fapi starvation the
    // sweep survives on the bridge ladder (fapi → SPOT-MIRROR, honest plane tag).
    let trades = await fapi(`/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`);
    if (!trades || trades.length < 10) {
        const b = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeTape"])(symbol).catch(()=>null);
        if (b && b.trades.length >= 10) trades = b.trades.map((t)=>({
                p: t.price,
                q: t.qty,
                T: t.time,
                m: t.isBuyerMaker
            }));
    }
    if (!trades || trades.length < 10) {
        measCache.set(ck, {
            at: Date.now(),
            v: null
        });
        return null;
    }
    const cutoff = Date.now() - 60_000;
    let buyUsd = 0;
    let sellUsd = 0;
    for (const t of trades){
        if (t.T < cutoff) continue;
        const usd = t.p * t.q;
        if (t.m) sellUsd += usd;
        else buyUsd += usd;
    }
    const total = buyUsd + sellUsd;
    const dominant = Math.max(buyUsd, sellUsd);
    const res = {
        buyUsd: Math.round(buyUsd),
        sellUsd: Math.round(sellUsd),
        sweepSide: total >= 250_000 && dominant >= 250_000 && dominant >= total * 0.62 ? buyUsd > sellUsd ? "LONG" : "SHORT" : null,
        sweepUsd: Math.round(dominant),
        dominance: total > 0 ? dominant / total : 0
    };
    measCache.set(ck, {
        at: Date.now(),
        v: res
    });
    return res;
}
/** L1.5 + L2 — order-book imbalance + ±2% vacuum/wall map from one depth snapshot. */ async function measureDepth(symbol) {
    const ck = `depth:${symbol}`;
    const hit = measCache.get(ck);
    if (hit && Date.now() - hit.at < MEAS_TTL) return hit.v;
    // v12.3 TASK-52 (v14.0): depth rides the ladder — fapi (w5) → SPOT-MIRROR book →
    // SPOT-MIRROR book; OBI/vacuum math is venue-shape-agnostic (bids DESC / asks ASC).
    const d = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2d$bridge$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bridgeDepth"])(symbol, 500);
    if (!d || d.bids.length === 0 || d.asks.length === 0) {
        measCache.set(ck, {
            at: Date.now(),
            v: null
        });
        return null;
    }
    const bids = d.bids.map(([p, q])=>({
            price: p,
            qty: q
        }));
    const asks = d.asks.map(([p, q])=>({
            price: p,
            qty: q
        }));
    const mid = (bids[0].price + asks[0].price) / 2;
    // OBI over the top ±0.5% band
    let bidNot = 0;
    let askNot = 0;
    for (const b of bids)if (b.price >= mid * 0.995) bidNot += b.price * b.qty;
    else break;
    for (const a of asks)if (a.price <= mid * 1.005) askNot += a.price * a.qty;
    else break;
    const obi = askNot > 0 ? bidNot / askNot : 1;
    // ±2% map: find the widest liquidity gap (vacuum) and the biggest single wall
    const band = 0.02;
    const buckets = 40;
    const bucketUsd = new Array(buckets).fill(0);
    const push = (price, qty)=>{
        const dev = (price - mid) / mid;
        if (Math.abs(dev) > band) return;
        const idx = Math.min(buckets - 1, Math.max(0, Math.floor((dev + band) / (2 * band) * buckets)));
        bucketUsd[idx] += price * qty;
    };
    for (const b of bids)push(b.price, b.qty);
    for (const a of asks)push(a.price, a.qty);
    const nonZero = bucketUsd.filter((v)=>v > 0);
    const median = nonZero.length ? [
        ...nonZero
    ].sort((a, b)=>a - b)[Math.floor(nonZero.length / 2)] : 0;
    let vacuum = null;
    if (median > 0) {
        let bestStart = -1;
        let bestLen = 0;
        let curStart = -1;
        for(let i = 0; i < buckets; i++){
            const empty = bucketUsd[i] < median * 0.15;
            if (empty && curStart < 0) curStart = i;
            if ((!empty || i === buckets - 1) && curStart >= 0) {
                const len = (empty ? i + 1 : i) - curStart;
                if (len > bestLen) {
                    bestLen = len;
                    bestStart = curStart;
                }
                curStart = -1;
            }
        }
        if (bestLen >= 4) {
            const midIdx = bestStart + bestLen / 2;
            const devMid = midIdx / buckets * 2 * band - band;
            const edgeDev = bestStart / buckets * 2 * band - band;
            vacuum = {
                side: devMid >= 0 ? "ABOVE" : "BELOW",
                widthPct: Number((bestLen / buckets * 2 * band * 100).toFixed(2)),
                edgeDistPct: Number((Math.abs(edgeDev) * 100).toFixed(2))
            };
        }
    }
    // wall: biggest single level within ±2%
    let wall = null;
    for (const b of bids){
        const usd = b.price * b.qty;
        if (!wall || usd > wall.usd) wall = {
            side: "BID",
            priceDistPct: Number(((mid - b.price) / mid * 100).toFixed(2)),
            usd: Math.round(usd)
        };
    }
    for (const a of asks){
        const usd = a.price * a.qty;
        if (!wall || usd > wall.usd) wall = {
            side: "ASK",
            priceDistPct: Number(((a.price - mid) / mid * 100).toFixed(2)),
            usd: Math.round(usd)
        };
    }
    const res = {
        mid: Number(mid.toFixed(mid > 100 ? 2 : 6)),
        obi: Number(obi.toFixed(3)),
        vacuum,
        wall
    };
    measCache.set(ck, {
        at: Date.now(),
        v: res
    });
    return res;
}
// ── trigger firing ──────────────────────────────────────────────
// v9.3: fire() stamps the event-instant mid price so the engine's ANTI-LATE-
// ENTRY guard can measure how far price ran between the TRIGGER and the deploy.
//
// v14.2 SURROGATE-FLOW HARD GATE (operator order «توصیه‌ها را کامل و مهندسی
// انجام بده», trace 1a1a15fb6bc0bd75 — audit rec #2 «قانون سخت: بدون deploy
// EVENT-TRIGGER با منبع جریان سورگت», NX-3247 forensics fc143950) ───────────
// NX-3247 was born EVENT-TRIGGER while its flow evidence was SPOT-MIRROR
// surrogate (fapi starved): the trigger plane measured the RIGHT microstructure
// (bridge tape/depth) but the deploy evaluation consumed CONFLICTS −9 flow
// measured on the WRONG venue, and the record spawned straight into the top of
// a markup leg. Law from this audit: an ACTED trigger (spawn-eligible, L1/L2)
// is downgraded to fuel (acted=false) whenever the symbol's flow bundle source
// is not BINANCE (SPOT-MIRROR / MIXED). The event stays in the ring with an
// honest block note (ring is persisted → fully auditable), the engine's
// actionable picker (requires acted) can never select it, and NO engine.ts
// change is needed. When flow is BINANCE or unknown (null — deploy-path gates
// own that case), the gate is a no-op.
function fire(layer, symbol, side, strength, detail, acted = false, price) {
    let actedFinal = acted;
    let detailFinal = detail;
    if (actedFinal && symbol) {
        // v14.2 hardening: the bundle tag can lag reality by up to one flow sweep
        // (~19min over the 48-perp domain) — a ban that started minutes ago would
        // still read a fresh "BINANCE" tag. The LIVE fapiBanActivity() probe
        // closes that gap: while a global window is live or the pool is in
        // distress (≥2 named IPs banned), spawn-eligible triggers stand down
        // regardless of the tag. Both probes fail-safe: tag unknown + no ban →
        // deploy-path gates own the residual case (SURROGATE-BREAKOUT / SURR-CAP).
        const src = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFlowSource"])(symbol);
        const surrogate = src !== null && src !== "BINANCE";
        const ban = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapiBanActivity"])();
        if (surrogate || ban.active) {
            const why = ban.active ? `fapi ban ACTIVE (${ban.reason})` : `flow plane ${src} ≠ BINANCE (fapi starved)`;
            actedFinal = false;
            detailFinal += ` — SURROGATE-FLOW BLOCK: EVENT-TRIGGER spawn denied (${why}; hard rule «no EVENT-TRIGGER deploy on surrogate flow», NX-3247 forensics)`;
        }
    }
    const ev = {
        at: Date.now(),
        layer,
        symbol,
        side,
        strength: Number(strength.toFixed(2)),
        detail: detailFinal,
        acted: actedFinal,
        regime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekRegime"])(symbol)?.label ?? null,
        price: typeof price === "number" && Number.isFinite(price) && price > 0 ? price : null
    };
    ring.unshift(ev);
    if (ring.length > RING_CAP) ring.pop();
    counts[layer]++;
    lastTriggerAt.set(`${layer}:${symbol}`, ev.at);
    void persist();
    return ev;
}
function cooled(layer, symbol, ms = 4 * 60_000) {
    const t = lastTriggerAt.get(`${layer}:${symbol}`);
    return !t || Date.now() - t > ms;
}
function isCounterCascadeSuppressed(symbol) {
    const t = cascadeUntil.get(symbol);
    return !!t && Date.now() < t;
}
function isCrowdCut(symbol) {
    const t = crowdCutUntil.get(symbol);
    return !!t && Date.now() < t;
}
async function persist() {
    if (!restoreOk) return; // TASK-40: never overwrite an unrestored (possibly good) row with cold state
    try {
        const value = JSON.stringify({
            counts: S.counts,
            last: S.ring.slice(0, RING_CAP),
            lastCycleAt: S.lastCycleAt,
            lastSpawnAt: S.lastSpawnAt
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: PERSIST_KEY
            },
            create: {
                key: PERSIST_KEY,
                value
            },
            update: {
                value
            }
        });
    } catch  {
    /* non-fatal */ }
}
/** Restore counters/ring after a dev-server restart.
 * TASK-40 hardening: a TRANSIENT DB error no longer latches the restore —
 * failed restores retry on the next cycle and persist() stays denied until
 * this succeeds. Counters merge MAX (they are monotonic), the ring merges
 * deduped by at|layer|symbol: a double-restore or a racing generation can
 * never move the visible numbers backwards. */ let restoreOk = false;
async function restore() {
    if (restoreOk) return;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: PERSIST_KEY
            }
        });
        if (!row) {
            restoreOk = true; // confirmed fresh — first persist may create the row
            return;
        }
        const v = JSON.parse(row.value);
        // layer-set evolution guard + MAX-merge — a layer added after the persist
        // was written would otherwise sit at undefined and NaN on the first ++
        for (const k of Object.keys(S.counts)){
            const disk = Number(v.counts?.[k] ?? 0);
            S.counts[k] = Math.max(S.counts[k] ?? 0, Number.isFinite(disk) ? disk : 0);
        }
        const seen = new Set(S.ring.map((e)=>`${e?.at}|${e?.layer}|${e?.symbol}`));
        for (const e of (v.last ?? []).slice(0, RING_CAP)){
            if (!e || typeof e.at !== "number") continue;
            const k = `${e.at}|${e.layer}|${e.symbol}`;
            if (seen.has(k)) continue;
            seen.add(k);
            S.ring.push(e);
        }
        S.ring.sort((a, b)=>b.at - a.at);
        if (S.ring.length > RING_CAP) S.ring.length = RING_CAP;
        if (typeof v.lastCycleAt === "number") S.lastCycleAt = Math.max(S.lastCycleAt ?? 0, v.lastCycleAt);
        S.lastSpawnAt = Math.max(S.lastSpawnAt, v.lastSpawnAt ?? 0);
        restoreOk = true;
    } catch  {
    /* transient DB hiccup — NOT latched; next cycle retries; persist stays denied */ }
}
async function scanSymbolTriggers(symbol) {
    const fired = [];
    const depth = await measureDepth(symbol);
    if (!depth) return fired;
    const px = depth.mid; // v9.3 — event-instant reference price for every layer below
    // L1.5 — persistent OBI extreme (spoof guard: needs 2 consecutive extreme reads)
    // v6.7 FIX (dead-layer root cause): the guard window was 90s, but the bus
    // rotates 3 symbols/cycle over a ≤64-symbol domain — each symbol is re-scanned
    // every ~10-20min, so `prev.at` was ALWAYS older than 90s and L15 could never
    // fire (count stuck at 0 since launch). A spoofed wall must now survive one
    // full rotation (~10-20min of real depth) — a STRICTER guard, not a looser one.
    const prev = lastOBI.get(symbol);
    lastOBI.set(symbol, {
        at: Date.now(),
        obi: depth.obi
    });
    if (cooled("L15_OBI_IMBALANCE", symbol) && prev && Date.now() - prev.at < 30 * 60_000) {
        const extreme = depth.obi >= 2.5 || depth.obi <= 0.4;
        const sameDir = Math.sign(depth.obi - 1) === Math.sign(prev.obi - 1);
        if (extreme && sameDir) {
            const side = depth.obi > 1 ? "LONG" : "SHORT";
            fired.push(fire("L15_OBI_IMBALANCE", symbol, side, Math.min(1, Math.abs(depth.obi - 1) / 1.5), `book imbalance ${depth.obi.toFixed(2)}× (bid/ask notional, ±0.5% band) held across 2 snapshots — ${side === "LONG" ? "bids" : "asks"} stacked`, false, px));
        }
    }
    // L1 — taker sweep, with OBI alignment check (the money combo)
    const sweep = await measureTakerSweep(symbol);
    if (sweep && sweep.sweepSide && cooled("L1_TAKER_SWEEP", symbol)) {
        const obiAligned = sweep.sweepSide === "LONG" ? depth.obi >= 1.3 : depth.obi <= 0.77;
        if (obiAligned) {
            const strength = Math.min(1, (sweep.dominance - 0.62) / 0.38 * 0.5 + Math.min(1, sweep.sweepUsd / 1_500_000) * 0.5);
            const ev = fire("L1_TAKER_SWEEP", symbol, sweep.sweepSide, strength, `aggressive ${sweep.sweepSide === "LONG" ? "buy" : "sell"} sweep $${(sweep.sweepUsd / 1000).toFixed(0)}K/60s (${Math.round(sweep.dominance * 100)}% dominant) + OBI ${depth.obi.toFixed(2)} aligned — liquidity consumed toward the thin side`, true, px);
            fired.push(ev);
        } else {
            fired.push(fire("L1_TAKER_SWEEP", symbol, sweep.sweepSide, strength0(sweep.dominance), `sweep $${(sweep.sweepUsd / 1000).toFixed(0)}K/60s but OBI ${depth.obi.toFixed(2)} NOT aligned — recorded as fuel, no spawn`, false, px));
        }
    }
    // L2 — vacuum edge within reach (fuel for the move INTO the gap)
    if (depth.vacuum && cooled("L2_VACUUM", symbol)) {
        const v = depth.vacuum;
        if (v.edgeDistPct <= 0.35 && v.widthPct >= 0.4) {
            const side = v.side === "ABOVE" ? "LONG" : "SHORT";
            const sweptIntoIt = sweep && sweep.sweepSide === side;
            fired.push(fire("L2_VACUUM", symbol, side, Math.min(1, v.widthPct / 1.2), `liquidity vacuum ${v.widthPct}% wide ${v.side.toLowerCase()} mid (edge ${v.edgeDistPct}% away) — ${sweptIntoIt ? "sweep already filling it: momentum fuel with open path" : "air pocket ahead; sweep into it accelerates"}`, !!sweptIntoIt, px));
        }
    }
    // wall opposite the vacuum path is reported inside detail when relevant (wall data feeds flow display)
    // L3 — REAL liquidation cascade (forceOrder stream) + anti-cascade veto window
    const snap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getLiquidationSnapshot"])();
    if (snap && snap.status.connected && !snap.status.dataStalled && cooled("L3_LIQ_CASCADE", symbol)) {
        const row = snap.bySymbol[symbol];
        if (row && row.usd10m >= 1_500_000) {
            const dom = Math.max(row.longsUsd10m, row.shortsUsd10m) / Math.max(1, row.usd10m);
            if (dom >= 0.6) {
                const wreckedSide = row.longsUsd10m > row.shortsUsd10m ? "LONG" : "SHORT";
                cascadeUntil.set(symbol, Date.now() + COUNTER_CASCADE_SUPPRESS_MS);
                fired.push(fire("L3_LIQ_CASCADE", symbol, wreckedSide === "LONG" ? "SHORT" : "LONG", Math.min(1, row.usd10m / 5_000_000), `cascade: $${(row.usd10m / 1e6).toFixed(2)}M ${wreckedSide.toLowerCase()}s liquidated in 10m (${Math.round(dom * 100)}% one-sided) — counter-cascade entries suppressed 10min; exhaustion setup armed`, false, px));
            }
        }
    }
    // L3P — v8.1 P1 PREDICTIVE PRE-CASCADE (engineering opinion, operator-approved):
    // L3 only reacts once a cascade is ALREADY flowing through the forceOrder
    // stream. This layer watches the LIQUIDATION HEATMAP estimate + the OI board:
    // price drifting within reach of a dense cluster WHILE positions are still
    // piling in (OI Δ1h ≥ +1% or OI z ≥ +1) is the cascade BEFORE it happens —
    // the magnet warning. Zero extra fetches: both caches are warm from the
    // tick rotation. Telemetry fuel (acted=false) — deploys still pass the gates.
    if (cooled("L3P_LIQ_PRE", symbol, 8 * 60_000)) {
        const heat = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liq$2d$heatmap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekLiqHeat"])(symbol);
        const oif = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$oi$2d$funding$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekOiFund"])(symbol);
        if (heat && oif) {
            const nearest = heat.nearestBelow && heat.nearestAbove ? Math.abs(heat.nearestBelow.distPct) <= Math.abs(heat.nearestAbove.distPct) ? heat.nearestBelow : heat.nearestAbove : heat.nearestBelow ?? heat.nearestAbove;
            const volRow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$vol$2d$forecast$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekVolForecast"])(symbol);
            const reachPct = Math.max(0.35, (volRow?.atr15mPct ?? 1) * 0.35); // 0.35×ATR band, 0.35% floor
            const oiPiling = oif.oiDelta1h !== null && oif.oiDelta1h >= 1 || oif.oiZ1h !== null && oif.oiZ1h >= 1;
            if (nearest && Math.abs(nearest.distPct) <= reachPct && oiPiling) {
                const cascadeSide = nearest.side === "LONGS_BELOW" ? "SHORT" : "LONG";
                fired.push(fire("L3P_LIQ_PRE", symbol, cascadeSide, Math.min(1, nearest.sharePct / 25), `PRE-CASCADE: est. ${nearest.estUsdM}${heat.oiScaled ? "M OI-scaled" : "M (unscaled est.)"} ${nearest.side === "LONGS_BELOW" ? "long" : "short"} liq cluster ${Math.abs(nearest.distPct).toFixed(2)}% ${nearest.distPct < 0 ? "below" : "above"} price (reach ${reachPct.toFixed(2)}%) + OI ${oif.oiDelta1h !== null ? `${oif.oiDelta1h >= 0 ? "+" : ""}${oif.oiDelta1h.toFixed(2)}%/1h` : `z ${oif.oiZ1h}`} still piling — cascade magnet armed ${cascadeSide === "SHORT" ? "down" : "up"}`, false, px));
            }
        }
    }
    // L3.5 — leverage crowding: funding extreme + OI acceleration
    if (cooled("L35_CROWD_JUMP", symbol)) {
        const m = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFlowMetrics"])(symbol);
        if (m && m.funding8h !== null && m.oiDelta1h !== null) {
            const hist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFlowHistory"])(symbol);
            const mean = hist.length >= 5 ? hist.reduce((a, h)=>a + h.oiDelta1h, 0) / hist.length : 0;
            const jump = m.oiDelta1h >= Math.max(1.5, mean * 2 + 1);
            if (Math.abs(m.funding8h) >= 0.06 && jump) {
                crowdCutUntil.set(symbol, Date.now() + CROWD_CUT_MS);
                const side = m.funding8h > 0 ? "SHORT" : "LONG"; // crowded side gets punished
                fired.push(fire("L35_CROWD_JUMP", symbol, side, Math.min(1, Math.abs(m.funding8h) / 0.15), `leverage crowded: funding ${m.funding8h.toFixed(4)}%/8h + OI ${m.oiDelta1h >= 0 ? "+" : ""}${m.oiDelta1h.toFixed(2)}%/1h (≥2× recent mean) — same-direction size cut 30min`, false, px));
            }
        }
    }
    // L4 — macro flows (v6.2): the key-less Fear & Greed feed gives the layer a
    // REAL measurable source. Extremes (≤20 EXTREME FEAR / ≥80 EXTREME GREED)
    // fire a contrarian context trigger — recorded as fuel, never an auto-spawn
    // (macro context informs, the deployment gates still decide). While the
    // source is unreachable the honest OBSERVING declaration remains.
    if (cooled("L4_MACRO", "MACRO")) {
        const macro = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$macro$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getMacroSnapshot"])();
        if (macro && (macro.value <= 20 || macro.value >= 80)) {
            const extremeFear = macro.value <= 20;
            fired.push(fire("L4_MACRO", "MACRO", extremeFear ? "LONG" : "SHORT", Math.min(1, Math.abs(macro.value - 50) / 50), `macro sentiment extreme: Fear & Greed ${macro.value}/100 (${macro.classification}) — contrarian ${extremeFear ? "LONG" : "SHORT"} context fuel (source: alternative.me, key-less, 30min cache)`));
        } else if (!macro && !macroAnnounced && fired.length === 0) {
            macroAnnounced = true;
            counts.L4_MACRO++; // count the honest declaration itself
            fired.push(fire("L4_MACRO", "—", "NEUTRAL", 0, "macro layer — Fear & Greed feed unreachable, no key-less measurable source right now: layer stays OBSERVING, never fabricated"));
        }
    }
    return fired;
}
function strength0(d) {
    return Number(Math.min(1, Math.max(0, (d - 0.62) / 0.38)).toFixed(2));
}
// ── bus cycle: rotate the FULL scan domain, 3 per cycle (v5.1: domain up to 64) ──
// v5.2 WEDGE ARMOR: a cycle is wrapped in a hard timeout — a single hung probe
// (socket that never settles, DB write lock) previously wedged `cycleInFlight`
// forever and silently killed the whole event-driven layer (observed live:
// counts frozen at 0, lastCycleAt null while regimes kept refreshing). Now the
// bus can stall at most one cycle, then self-heals with an audited error.
const CYCLE_TIMEOUT_MS = 60_000;
const SYMBOL_TIMEOUT_MS = 15_000;
function withTimeout(p, ms, label) {
    return new Promise((resolve, reject)=>{
        const t = setTimeout(()=>reject(new Error(`${label} timeout ${ms}ms`)), ms);
        p.then((v)=>{
            clearTimeout(t);
            resolve(v);
        }).catch((e)=>{
            clearTimeout(t);
            reject(e);
        });
    });
}
let cyclesStarted = 0;
let cyclesCompleted = 0;
let lastCycleMs = null;
let lastCycleError = null;
async function runTriggerCycleInner(symbols) {
    await restore();
    rotationSize = Math.max(6, Math.min(64, symbols.length));
    const batch = [
        symbols[cursor % symbols.length],
        symbols[(cursor + 1) % symbols.length],
        symbols[(cursor + 2) % symbols.length]
    ].filter(Boolean);
    cursor = (cursor + 3) % symbols.length;
    for (const s of batch){
        await withTimeout(scanSymbolTriggers(s), SYMBOL_TIMEOUT_MS, `trigger scan ${s}`);
    }
    S.lastCycleAt = Date.now();
}
async function runTriggerCycle(symbols) {
    if (cycleInFlight || symbols.length === 0) return;
    cycleInFlight = true;
    cyclesStarted++;
    const t0 = Date.now();
    try {
        await withTimeout(runTriggerCycleInner(symbols), CYCLE_TIMEOUT_MS, "trigger cycle");
        cyclesCompleted++;
        lastCycleMs = Date.now() - t0;
        lastCycleError = null;
    } catch (err) {
        lastCycleError = String(err);
        console.error("[trigger-bus] cycle failed:", err);
    } finally{
        cycleInFlight = false;
    }
}
function canTriggerSpawn() {
    return Date.now() - S.lastSpawnAt > SPAWN_COOLDOWN_MS;
}
function markTriggerSpawn() {
    S.lastSpawnAt = Date.now();
    void persist();
}
function getTriggerBusSummary() {
    // TASK-40: kick the restore on the READ path too — a fresh process used to
    // report zero counts until the first bus cycle ran (a seconds-wide window
    // that reads exactly like "the data was wiped again"). The kick is
    // fire-and-forget; the first poll may still be cold, the next one (≤5s) is
    // already MAX-merged from EngineSetting.
    void restore();
    return {
        counts: {
            ...S.counts
        },
        last: S.ring.slice(0, 12),
        rotation: cursor,
        rotationSize,
        lastCycleAt: S.lastCycleAt,
        lastSpawnAt: S.lastSpawnAt || null,
        suppressed: [
            ...cascadeUntil.entries()
        ].filter(([, t])=>Date.now() < t).map(([s])=>s),
        crowdCut: [
            ...crowdCutUntil.entries()
        ].filter(([, t])=>Date.now() < t).map(([s])=>s),
        macroNote: (()=>{
            const m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$macro$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekMacro"])();
            return m ? `L4 macro: Fear & Greed ${m.value}/100 (${m.classification}) — key-less source live, 30min cache` : "L4 macro flows: Fear & Greed feed not yet reachable — OBSERVING, never fabricated";
        })(),
        cyclesStarted,
        cyclesCompleted,
        cycleInFlight,
        lastCycleMs,
        lastCycleError
    };
}
// TASK-40: module-load self-restore — every Turbopack per-route module instance
// pulls its persisted counters/ring the moment it is imported, so even the
// FIRST dashboard poll after a restart/recompile serves real state (the
// getTriggerBusSummary read-path kick is the second line of defense).
void restore().catch(()=>undefined);
}),
"[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_MILESTONE_STEPS",
    ()=>RAWCAL_MILESTONE_STEPS,
    "RAWCAL_TELEMETRY_FILE",
    ()=>RAWCAL_TELEMETRY_FILE,
    "checkRawcalMilestones",
    ()=>checkRawcalMilestones,
    "checkRawcalStallAlarm",
    ()=>checkRawcalStallAlarm,
    "computeRawcalPace",
    ()=>computeRawcalPace,
    "milestoneView",
    ()=>milestoneView,
    "recentBlocks",
    ()=>recentBlocks,
    "recordRawcalSnapshot",
    ()=>recordRawcalSnapshot
]);
// ── v9.2 RAW-CAL PACE MONITOR — engineering observability for the capture run ──
// Operator mandate 2026-09-13: «پایش ریتم صدور RAW-CAL و رشد کتاب EPOCH-2 به
// سمت ۱۰۰. رو کامل و مهندسی انجام بده» — monitor the RAW-CAL issuance rhythm
// and the growth of the EPOCH-2 book toward the 100-settled calibration bar.
//
// THREE PERSISTED INSTRUMENTS:
//  1) SNAPSHOT JOURNAL — .data/rawcal-telemetry.jsonl, one row every ~10min
//     (self-throttled; force on state jumps): {t, issued, issuedTotal,
//     settledE2, openRaw, settledRaw, winsRaw, note?} — the book-growth curve
//     the UI sparkline and rate math read. Trimmed to the last 4000 rows.
//  2) PACE ENGINE — rolling rates from the journal + the DB ledger:
//     issue rate/h (3h + since-armed), settle rate/h (3h + 6h), observed mean
//     spacing between raw issues (DB createdAt diffs), ETA to the 100 bar at
//     the current settle rate, pipeline projection (open raw records that will
//     still settle), mean book settle-time, and stall detection.
//  3) MILESTONE LEDGER — idempotent audited events at 50/60/70/80/90/95/100
//     (EngineSetting "rawcal.milestones"); Telegram only for 90/95/100 (the
//     100 announcement itself stays with the auto-lift in raw-cal.ts).
//
// STALL SEMANTICS (honest, rail-aware):
//  · issue stall  = armed && openRaw < maxOpen && now − lastIssueAt >
//    max(45min, 3 × spacingMin) — issuance SHOULD have produced a record.
//  · settle stall = openRaw > 0 && no EPOCH-2 settle in the last 3h.
//  Neither fires when the open-cap rail is the legitimate blocker.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const RAWCAL_TELEMETRY_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-telemetry.jsonl");
const MILESTONES_KEY = "rawcal.milestones";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const RAWCAL_MILESTONE_STEPS = [
    50,
    60,
    70,
    80,
    90,
    95,
    100
];
const TELEGRAM_MILESTONES = new Set([
    90,
    95,
    100
]);
const MAX_JOURNAL_ROWS = 4000;
// ── memo caches (pulse-safe; these run on hot paths) ──
let lastSnapshotAt = 0;
let paceCache = null;
const PACE_TTL_MS = 30_000;
async function readJournal() {
    try {
        const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(RAWCAL_TELEMETRY_FILE, "utf8");
        const rows = [];
        for (const line of txt.split("\n")){
            const s = line.trim();
            if (!s) continue;
            try {
                rows.push(JSON.parse(s));
            } catch  {
            /* skip torn line */ }
        }
        return rows.slice(-MAX_JOURNAL_ROWS);
    } catch  {
        return [];
    }
}
async function appendJournal(row) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(RAWCAL_TELEMETRY_FILE), {
            recursive: true
        });
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(RAWCAL_TELEMETRY_FILE, JSON.stringify(row) + "\n", "utf8");
        // opportunistic trim (cheap: only when the file grows past 2× the cap)
        try {
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(RAWCAL_TELEMETRY_FILE);
            if (st.size > MAX_JOURNAL_ROWS * 180) {
                const rows = await readJournal();
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(RAWCAL_TELEMETRY_FILE, rows.slice(-MAX_JOURNAL_ROWS).map((r)=>JSON.stringify(r)).join("\n") + "\n", "utf8");
            }
        } catch  {
        /* trim best-effort */ }
    } catch (e) {
        console.error("[rawcal-telemetry] journal append failed", e);
    }
}
async function recordRawcalSnapshot(note, force = false) {
    const now = Date.now();
    if (!force && now - lastSnapshotAt < 10 * 60_000) return null;
    lastSnapshotAt = now;
    try {
        const [settledE2, openRaw, totalRaw, settledRaw, winsRaw] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: {
                        in: SETTLED_STATUSES
                    },
                    tags: {
                        contains: "EPOCH-2"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: [
                            "ACTIVE",
                            "TP1",
                            "TP2"
                        ]
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    status: {
                        in: SETTLED_STATUSES
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    tags: {
                        contains: "RAW-CAL"
                    },
                    reachedTp: {
                        gte: 1
                    }
                }
            })
        ]);
        const snap = {
            t: new Date(now).toISOString(),
            issued: 0,
            issuedTotal: totalRaw,
            settledE2,
            openRaw,
            settledRaw,
            winsRaw,
            ...note ? {
                note: note.slice(0, 80)
            } : {}
        };
        // issued-this-run: cheap read of the state key (no import cycle — raw-cal
        // imports telemetry, not vice versa)
        try {
            const s = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "rawcal.state"
                }
            });
            if (s) snap.issued = JSON.parse(s.value).issued ?? 0;
        } catch  {
        /* optional field */ }
        await appendJournal(snap);
        paceCache = null; // fresh data → invalidate pace memo
        return snap;
    } catch (e) {
        console.error("[rawcal-telemetry] snapshot failed", e);
        return null;
    }
}
async function computeRawcalPace(blocks) {
    if (paceCache && Date.now() - paceCache.at < PACE_TTL_MS && !blocks) return paceCache.data;
    const state = await getRawcalStateSafe();
    const now = Date.now();
    const [settledE2, openRaw, openE2, maxOpen] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }),
        Promise.resolve(state.maxOpen)
    ]);
    const target = state.target;
    // issuance ledger (raw rows from the DB itself — ground truth)
    const rawRows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            createdAt: true
        },
        orderBy: {
            createdAt: "asc"
        }
    });
    const issueTimes = rawRows.map((r)=>r.createdAt.getTime());
    const h3 = now - 3 * 3600_000;
    const issues3h = issueTimes.filter((t)=>t >= h3).length;
    const armMs = state.armedAt ? new Date(state.armedAt).getTime() : null;
    const issuesSinceArm = armMs ? issueTimes.filter((t)=>t >= armMs).length : 0;
    const armHours = armMs ? Math.max(1 / 60, (now - armMs) / 3600_000) : null;
    const diffs = issueTimes.slice(1).map((t, i)=>t - issueTimes[i]);
    const meanDiff = diffs.length ? diffs.reduce((a, b)=>a + b, 0) / diffs.length : null;
    // book-growth ledger (EPOCH-2 settles with closedAt)
    const settles = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            },
            closedAt: {
                not: null
            }
        },
        select: {
            closedAt: true,
            createdAt: true
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const settleTimes = settles.map((r)=>r.closedAt.getTime()).reverse(); // asc
    const settles3h = settleTimes.filter((t)=>t >= h3).length;
    const settles6h = settleTimes.filter((t)=>t >= now - 6 * 3600_000).length;
    const recent20 = settles.slice(0, 20);
    const meanSettleMin = recent20.length ? recent20.reduce((a, r)=>a + (r.closedAt.getTime() - r.createdAt.getTime()), 0) / recent20.length / 60_000 : null;
    const [settledRaw, winsRaw] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: SETTLED_STATUSES
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                reachedTp: {
                    gte: 1
                }
            }
        })
    ]);
    const settleRate3h = settles3h / 3;
    const needed = Math.max(0, target - settledE2);
    const etaHours = needed === 0 ? 0 : settleRate3h > 0 ? needed / settleRate3h : null;
    // v9.2.1 steady-state projection — raw cadence ∩ settle-throughput cap.
    // throughputCap = maxOpen concurrent records / mean settle hours; the real
    // fill window is needed / min(issueCadence, throughputCap). Only computed
    // when meanSettleMin is known (honest — no invented throughput).
    const issueSinceArmRateRaw = armHours ? issuesSinceArm / armHours : 0;
    const throughputCapPerH = meanSettleMin !== null && meanSettleMin > 0 ? maxOpen / (meanSettleMin / 60) : null;
    const steadyRatePerH = throughputCapPerH !== null ? Math.min(issueSinceArmRateRaw, throughputCapPerH) : null;
    const etaSteadyHours = needed === 0 ? 0 : steadyRatePerH !== null && steadyRatePerH > 0 ? needed / steadyRatePerH : null;
    // stalls (rail-aware — see header)
    const issueStallMin = state.armed && openRaw < maxOpen && state.lastIssueAt ? Math.max(0, (now - new Date(state.lastIssueAt).getTime()) / 60_000) : null;
    const issueStallActive = issueStallMin !== null && issueStallMin > Math.max(45, 3 * state.spacingMin);
    const lastSettleAt = settleTimes.length ? settleTimes[settleTimes.length - 1] : null;
    const settleStallMin = openRaw > 0 && lastSettleAt ? Math.max(0, (now - lastSettleAt) / 60_000) : null;
    const settleStallActive = settleStallMin !== null && settleStallMin > 180;
    // cadence grade — honest banding of the ISSUE rhythm while armed.
    // v9.2.1 arm-age-aware: inside the first 3h after arming the 3h window still
    // contains pre-RAW-CAL filtered flow (rate lag) → grade on the since-arm
    // cadence instead; afterwards both windows agree and 3h is used.
    const issueRate3hPerH = issues3h / 3;
    let cadenceGrade = "OFF";
    if (state.armed) {
        const baseRate = armHours !== null && armHours < 3 ? issueSinceArmRateRaw : issueRate3hPerH;
        const effRate = issueStallActive ? 0 : baseRate;
        cadenceGrade = effRate >= 3 ? "A" : effRate >= 1.5 ? "B" : effRate >= 0.5 ? "C" : "D";
    }
    // sparkline from the journal (downsample to ≤48 points)
    // v9.4.2 NaN guard: journal gap rows can carry non-finite settledE2 — skip
    // them here so the client never receives NaN chart values.
    const journal = await readJournal();
    const series = journal.length > 1 ? journal : journal.length === 1 ? [
        {
            t: new Date(now).toISOString(),
            settledE2
        }
    ] : [];
    const step = Math.max(1, Math.ceil(series.length / 48));
    const sparkline = [];
    for(let i = 0; i < series.length; i += step){
        const v = series[i].settledE2;
        if (!Number.isFinite(v)) continue;
        sparkline.push({
            t: series[i].t,
            v
        });
    }
    if (sparkline.length && Number.isFinite(settledE2) && sparkline[sparkline.length - 1].v !== settledE2) sparkline.push({
        t: new Date(now).toISOString(),
        v: settledE2
    });
    const lastBlockNote = blocks && blocks.length ? blocks[blocks.length - 1].note : null;
    const pace = {
        armed: state.armed,
        armedAt: state.armedAt,
        settledE2,
        needed,
        target,
        issueRate3hPerH: round2(issueRate3hPerH),
        issueRateSinceArmPerH: armHours ? round2(issuesSinceArm / armHours) : 0,
        observedSpacingMin: {
            mean: meanDiff !== null ? round2(meanDiff / 60_000) : null,
            min: diffs.length ? round2(Math.min(...diffs) / 60_000) : null,
            max: diffs.length ? round2(Math.max(...diffs) / 60_000) : null,
            samples: diffs.length
        },
        lastIssueAt: state.lastIssueAt,
        lastIssueSerial: state.lastIssueSerial,
        openRaw,
        openE2,
        maxOpen,
        spacingMin: state.spacingMin,
        settleRate3hPerH: round2(settleRate3h),
        settleRate6hPerH: round2(settles6h / 6),
        meanSettleMin: meanSettleMin !== null ? Math.round(meanSettleMin) : null,
        winsRaw,
        settledRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        etaHours: etaHours !== null ? round2(etaHours) : null,
        etaAt: etaHours !== null ? new Date(now + etaHours * 3600_000).toISOString() : null,
        steadyRatePerH: steadyRatePerH !== null ? round2(steadyRatePerH) : null,
        etaSteadyHours: etaSteadyHours !== null ? round2(etaSteadyHours) : null,
        etaSteadyAt: etaSteadyHours !== null ? new Date(now + etaSteadyHours * 3600_000).toISOString() : null,
        pipelineProjection: settledE2 + openE2,
        cadenceGrade,
        stalls: {
            issueStallMin: issueStallActive ? Math.round(issueStallMin) : null,
            settleStallMin: settleStallActive ? Math.round(settleStallMin) : null,
            lastBlockNote
        },
        sparkline,
        journalRows: journal.length
    };
    if (!blocks) paceCache = {
        at: Date.now(),
        data: pace
    };
    return pace;
}
async function getRawcalStateSafe() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return await getRawCalState();
    } catch  {
        return {
            armed: false,
            armedAt: null,
            lastIssueAt: null,
            lastIssueSerial: null,
            target: 100,
            spacingMin: 12,
            maxOpen: 8
        };
    }
}
function round2(n) {
    return Math.round(n * 100) / 100;
}
// ── MILESTONE LEDGER ──
async function readMilestones() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: MILESTONES_KEY
            }
        });
        if (!row) return {
            fired: {}
        };
        return JSON.parse(row.value);
    } catch  {
        return {
            fired: {}
        };
    }
}
async function checkRawcalMilestones() {
    const settledE2 = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: SETTLED_STATUSES
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    }).catch(()=>0);
    const m = await readMilestones();
    const firedNow = [];
    for (const step of RAWCAL_MILESTONE_STEPS){
        const key = String(step);
        if (settledE2 < step || m.fired[key]) continue;
        const at = new Date().toISOString();
        m.fired[key] = at;
        firedNow.push({
            step,
            at
        });
        const isBar = step === 100;
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", `RAW-CAL MILESTONE ${step}/${100} — EPOCH-2 book at ${settledE2} settled${isBar ? " — calibration bar REACHED, capture mode hands back to central-intelligence command (new calibration)" : ` · ${100 - settledE2} records remain to the AI CALIBRATION bar`}`).catch(()=>undefined);
        if (TELEGRAM_MILESTONES.has(step) && !(isBar && stateHasAutoLift())) {
            const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
            void sendDirect(`📈 <b>RAW-CAL MILESTONE ${step}/100</b>\nEPOCH-2 book: <b>${settledE2}/100</b> settled${isBar ? " — AI CALIBRATION lift imminent" : ` · ${100 - settledE2} to go`}\n${progressBar(settledE2)}`).catch(()=>undefined);
        }
    }
    if (firedNow.length) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: MILESTONES_KEY
            },
            create: {
                key: MILESTONES_KEY,
                value: JSON.stringify(m)
            },
            update: {
                value: JSON.stringify(m)
            }
        }).catch(()=>undefined);
    }
    return firedNow;
}
async function stateHasAutoLift() {
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return !!(await getRawCalState()).autoLiftAt;
    } catch  {
        return false;
    }
}
function progressBar(n) {
    const filled = Math.round(Math.min(100, n) / 100 * 20);
    return "▰".repeat(filled) + "▱".repeat(20 - filled);
}
async function milestoneView() {
    const [m, settledE2] = await Promise.all([
        readMilestones(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: SETTLED_STATUSES
                },
                tags: {
                    contains: "EPOCH-2"
                }
            }
        }).catch(()=>0)
    ]);
    return {
        steps: RAWCAL_MILESTONE_STEPS.map((step)=>({
                step,
                fired: !!m.fired[String(step)],
                at: m.fired[String(step)] ?? null,
                pending: settledE2 < step
            })),
        settledE2
    };
}
async function recentBlocks(n = 12) {
    try {
        const { getRawCalBlocks } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        return getRawCalBlocks(n);
    } catch  {
        return [];
    }
}
// ── v9.2.1 STALL ALARM — push the rhythm break, don't just display it ──
// Tick hook (idempotent, 2h cooldown per stall type). Fires when the armed
// issuer SHOULD have produced (issue stall) or the in-flight pipeline SHOULD
// have settled (settle stall) and didn't. Process-death is covered by the P0
// watchdog + keep-alive crons; this alarm covers "alive but rhythm broken".
const STALL_ALERT_KEY = "rawcal.stallAlerts";
const STALL_COOLDOWN_MS = 2 * 3600_000;
async function checkRawcalStallAlarm() {
    try {
        const pace = await computeRawcalPace().catch(()=>null);
        if (!pace || !pace.armed) return false;
        const issues = [];
        if (pace.stalls.issueStallMin) issues.push(`issue stall — no raw record for ${pace.stalls.issueStallMin}min while armed and open ${pace.openRaw}/${pace.maxOpen}`);
        if (pace.stalls.settleStallMin) issues.push(`settle stall — no EPOCH-2 settle for ${pace.stalls.settleStallMin}min with ${pace.openRaw} raw in flight`);
        if (!issues.length) return false;
        let fired = {};
        try {
            const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: STALL_ALERT_KEY
                }
            });
            if (row) fired = JSON.parse(row.value).fired ?? {};
        } catch  {
        /* fresh ledger */ }
        const now = Date.now();
        const send = [];
        for (const it of issues){
            const k = it.startsWith("issue") ? "issue" : "settle";
            const last = fired[k] ? new Date(fired[k]).getTime() : 0;
            if (now - last > STALL_COOLDOWN_MS) {
                fired[k] = new Date(now).toISOString();
                send.push(it);
            }
        }
        if (!send.length) return false;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: STALL_ALERT_KEY
            },
            create: {
                key: STALL_ALERT_KEY,
                value: JSON.stringify({
                    fired
                })
            },
            update: {
                value: JSON.stringify({
                    fired
                })
            }
        }).catch(()=>undefined);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL PACE ALARM — ${send.join(" · ")} · book ${pace.settledE2}/${pace.target} · cadence ${pace.cadenceGrade}`).catch(()=>undefined);
        const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
        void sendDirect(`⏱ <b>RAW-CAL PACE ALARM</b>\n${send.map((s)=>`• ${s}`).join("\n")}\n📊 Book: <b>${pace.settledE2}/${pace.target}</b> settled · cadence ${pace.cadenceGrade} · open raw ${pace.openRaw}/${pace.maxOpen}`).catch(()=>undefined);
        return true;
    } catch  {
        return false;
    }
}
}),
"[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeRawcalQuality",
    ()=>computeRawcalQuality,
    "r6GateLine",
    ()=>r6GateLine,
    "readPersistedQuality",
    ()=>readPersistedQuality,
    "recordRawcalQuality",
    ()=>recordRawcalQuality
]);
// ── v9.3 RAW-CAL SAMPLE QUALITY LAB — data-health gate for the R6 recalibration ──
// Operator mandate 2026-09-13: «پس از تسویه اولین RAW-CALها (~1-2h) میتوانیم
// کیفیت نمونه‌های خام را هم بررسی کنیم تا کالیبراسیون R6 روی داده سالم بنشیند»
// — after the first RAW-CALs settle, review the quality of the raw samples so
// the R6 calibration rests on HEALTHY data.
//
// WHAT IT MEASURES (every RAW-CAL-tagged ledger row, 100% from the DB):
//  · CAPTURE INTEGRITY (0-30): deploy audit snapshots preserved — factorsJson
//    (confluence votes, 12) / flowJson (order-flow, 9) / mtfJson (multi-TF
//    board, 9). R6 attributes outcomes to factors; a row born without its
//    snapshots can never be attributed, so absence is scored, not forgiven.
//  · PLAN COMPLETENESS (0-20): entry/stop/TP ladder present and
//    direction-consistent, RR > 0, TTL sane — a malformed plan is a malformed
//    sample no matter how it settles.
//  · OUTCOME INFORMATIVENESS (0-30): TP1/TP2/TP3 or SL = fully informative
//    (price proved or disproved the plan — losses are the most instructive
//    rows); EXPIRED with a TP touch = partially informative; EXPIRED with no
//    touch = time-censored (low information); manual CLOSED = censored.
//  · REPRESENTATIVENESS (0-20): spacing ≥ the anti-flood rail (burst-cluster
//    rows are correlated and would inflate calibration confidence), hold time
//    inside the TTL envelope, extension abuse flagged.
// Composite 0-100 → HEALTHY ≥75 · REVIEW 50-74 · CENSORED <50 (PENDING while
// the row is still open).
//
// COHORT HEALTH → R6 GATE: healthy% of the settled raw cohort vs the 85%
// health floor, informative ratio, symbol concentration, side balance,
// snapshot completeness — verdict GREEN / AMBER / RED (WARMING before the
// first settles) with explicit blockers. The gate ADVISES the R6 lift and the
// central intelligence (engine memory + governor context); it NEVER edits the
// calibration math itself (no post-hoc tampering — honest instrumentation).
//
// PERSISTENCE: EngineSetting "rawcal.quality" (compact digest, cross-process)
// + QUALITY rows appended to .data/rawcal-telemetry.jsonl (10min throttle,
// forced the moment the settled-raw count moves — the settle curve of the
// QUALITY of the book, not just its size).
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)");
;
;
;
;
const QUALITY_KEY = "rawcal.quality";
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
const OPEN_STATUSES = [
    "ACTIVE",
    "TP1",
    "TP2"
];
const HEALTH_FLOOR = 85; // R6 health floor — healthy% of the settled raw cohort
const MAX_JOURNAL_ROWS = 4000;
// ── v10.9 POST-FILTER COHORT (SUPERVISOR proposal 22:55Z, operator-approved
// 2026-09-15 «دستورات سوپروایزر را کامل و مهندسی انجام بده») — before/after
// split around the decisive-excursion filter go-live (first live skip TAOUSDT
// 11:31:27Z, worklog OP-V106-ROOTCAUSE-20260915T1134Z). The blended window is
// dominated by the legacy expired-no-touch stock, so the filter's true effect
// on outcome informativeness is measured on its OWN cohort. Censoring-aware
// pre/post design (gov.uk before-after guidance; Prinja 2010, Turkson 2021).
const FILTER_ERA_START_MS = Date.parse("2026-09-15T11:30:00.000Z");
// ── v10.9.2 EXPIRY-CAUSE ATTRIBUTION (SUPERVISOR proposal, operator-approved
// via bridge 2026-09-16T11:18Z «دستورات سوپروایزر را تایید می کنم») — the gate
// verdict is hostage to expired-no-touch censoring (informative 37.7% blended):
// R6 cannot attribute outcomes when a trade never reaches TP1 or SL. Each
// EXPIRED-no-touch row is now split by its MAX FAVORABLE EXCURSION in R units
// (mfeR = (maxPnlPercent/leverage) / stopDistancePct — existing journal fields,
// zero new capture): WRONG-SIDE (mfeR < 0.25 — price never followed the plan;
// entry direction/timing problem, NOT a TTL problem) vs NO-FOLLOW (mfeR ≥ 0.6 —
// meaningful follow that stalled before TP1; barrier/TP geometry too far for
// realized excursion) vs MIXED (in between). The gate can now NAME the dominant
// expiry cause, and the VOL-BARRIER mult/cap knobs get a direct feedback signal
// (no-follow dominance → tighten barrier; wrong-side dominance → entry filter
// problem). Reporting-layer only — scoring, scan and issue logic untouched.
const EXP_WRONG_SIDE_R = 0.25; // below: never followed — wrong side / late entry
const EXP_NO_FOLLOW_R = 0.6; // above: followed then stalled — geometry too far
// ── v10.9.1 EPOCH-WINDOWED GATE VERDICT (SUPERVISOR proposal, operator blanket-
// approve 2026-09-16T09:03Z «تمام اقدامات و پیشنهادات SUPERVISOR را تایید
// می‌کنم — کامل و مهندسی انجام بده») — the gate verdict is computed on the
// POST-FILTER EPOCH WINDOW, not the blended all-time cohort. The blended
// window is dominated by legacy expired-no-touch stock (metric regime-bias:
// 37.7% blended vs 56% post-filter informative at approval time), so the
// all-time ratio can never turn GREEN even when the CURRENT engine regime is
// decisively healthier. GREEN now requires the epoch window to prove itself:
// window informative ≥50% AND window settled n≥20. Structural integrity
// (snapshots) stays whole-cohort — a row born without snapshots is era-
// independent damage. The healthy-floor check rides the window too (AMBER,
// not RED). VERDICT-ONLY change: scoring, cohort measurement, scan/issue
// logic all untouched — the digest still reports the blended ratios for the
// whole book (honest instrumentation), only the VERDICT anchor moved.
const GATE_WINDOW_MIN_N = 20; // settled rows the window needs before GREEN is reachable
const GATE_WINDOW_FORMING = 3; // below this the window is WARMING, not judged
const GATE_WINDOW_INFORMATIVE = 50; // GREEN bar for the window informative ratio
const GATE_WINDOW_WARN_N = 8; // window small-sample guard for the informative blocker
// ── memo cache (runs on hot paths) ──
let qualityCache = null;
const QUALITY_TTL_MS = 30_000;
let lastJournalAt = 0;
let lastSeenSettled = -1;
function safeParse(json) {
    if (!json || !json.trim()) return false;
    try {
        const v = JSON.parse(json);
        return v !== null && (typeof v !== "object" || Array.isArray(v) ? v.length > 0 : Object.keys(v).length > 0);
    } catch  {
        return false;
    }
}
function round1(n) {
    return Math.round(n * 10) / 10;
}
function pct(part, whole) {
    return whole > 0 ? round1(part / whole * 100) : null;
}
/** Score ONE raw ledger row against the four quality dimensions. */ function scoreSample(row, prevCreatedAt, spacingMin) {
    const flags = [];
    const settled = SETTLED_STATUSES.includes(row.status);
    const open = OPEN_STATUSES.includes(row.status);
    // ── A) capture integrity — the deploy audit snapshots R6 will attribute to (0-30)
    let integrity = 0;
    if (safeParse(row.factorsJson)) integrity += 12;
    else flags.push("no-factors");
    if (safeParse(row.flowJson)) integrity += 9;
    else flags.push("no-flow");
    if (safeParse(row.mtfJson)) integrity += 9;
    else flags.push("no-mtf");
    // ── B) plan completeness — entry/stop/ladder coherent (0-20)
    let plan = 0;
    if (row.entryPrice > 0) plan += 2;
    if (row.stopLoss > 0) plan += 3;
    else flags.push("no-stop");
    if (row.tp1 > 0 && row.tp2 > 0 && row.tp3 > 0) plan += 3;
    else flags.push("ladder-short");
    const long = row.direction === "LONG";
    const ladderOk = long ? row.tp1 > row.entryPrice && row.stopLoss < row.entryPrice : row.direction === "SHORT" ? row.tp1 < row.entryPrice && row.stopLoss > row.entryPrice : false;
    if (ladderOk) plan += 6;
    else flags.push("ladder-inconsistent");
    if (row.riskReward > 0) plan += 2;
    if (row.ttlMinutes > 0 && row.expiresAt.getTime() > row.createdAt.getTime()) plan += 4;
    else flags.push("ttl-bad");
    // ── C) outcome informativeness — what did the settle actually teach (0-30)
    let outcome = 0;
    if (settled) {
        if ([
            "TP1",
            "TP2",
            "TP3"
        ].includes(row.status)) outcome = 30;
        else if (row.status === "SL") outcome = 30;
        else if (row.status === "EXPIRED") {
            if (row.reachedTp >= 1) outcome = 20;
            else {
                outcome = 8;
                flags.push("expired-no-touch"); // time-censored — weakest calibration row
                // v10.9.2 expiry-cause attribution — MFE in R units names WHY it censored
                const slPct = row.entryPrice > 0 ? Math.abs(row.stopLoss - row.entryPrice) / row.entryPrice * 100 : 0;
                if (slPct > 0 && row.leverage > 0) {
                    const mfeR = row.maxPnlPercent / row.leverage / slPct;
                    if (mfeR < EXP_WRONG_SIDE_R) flags.push("expired-wrong-side");
                    else if (mfeR >= EXP_NO_FOLLOW_R) flags.push("expired-no-follow");
                } // slPct/leverage degenerate → cause unknown, censoring flag alone stands
            }
        } else if (row.status === "CLOSED") {
            outcome = 10;
            flags.push("manual-close");
        }
    } else if (!open) {
        flags.push("status-odd");
    }
    // ── D) representativeness — spacing rail + TTL envelope (0-20)
    let timing = 0;
    let spacingOk = null;
    if (prevCreatedAt) {
        const gapMin = (row.createdAt.getTime() - prevCreatedAt.getTime()) / 60_000;
        spacingOk = gapMin >= spacingMin * 0.98;
        if (spacingOk) timing += 10;
        else {
            timing += 4;
            flags.push("cluster-spawn");
        }
    } else {
        timing += 10; // first record of the cohort — no spacing to violate
    }
    if (settled && row.closedAt) {
        const envelope = row.ttlMinutes * (1 + 0.25 * row.ttlExtensions) + 5;
        const holdMin = (row.closedAt.getTime() - row.createdAt.getTime()) / 60_000;
        if (holdMin <= envelope) timing += 10;
        else flags.push("hold-overrun");
        if (row.ttlExtensions >= 3) flags.push(`ttl-ext×${row.ttlExtensions}`);
    } else if (!settled) {
        timing += 10; // hold envelope not yet measurable — neutral until settle
    }
    const score = Math.round(integrity + plan + outcome + timing);
    const cls = open ? "PENDING" : score >= 75 ? "HEALTHY" : score >= 50 ? "REVIEW" : "CENSORED";
    return {
        serial: row.serial,
        symbol: row.symbol,
        direction: row.direction,
        strategy: row.strategy,
        status: row.status,
        settled,
        pnlPercent: round1(row.pnlPercent),
        holdMin: row.closedAt ? Math.round((row.closedAt.getTime() - row.createdAt.getTime()) / 60_000) : null,
        score,
        cls,
        flags,
        spacingOk
    };
}
async function computeRawcalQuality() {
    if (qualityCache && Date.now() - qualityCache.at < QUALITY_TTL_MS) return qualityCache.data;
    let spacingMin = 12;
    try {
        const { getRawCalState } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        spacingMin = (await getRawCalState()).spacingMin;
    } catch  {
    /* default rail */ }
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            }
        },
        select: {
            serial: true,
            symbol: true,
            direction: true,
            strategy: true,
            status: true,
            reachedTp: true,
            pnlPercent: true,
            ttlMinutes: true,
            ttlExtensions: true,
            entryPrice: true,
            tp1: true,
            tp2: true,
            tp3: true,
            stopLoss: true,
            riskReward: true,
            leverage: true,
            maxPnlPercent: true,
            expiresAt: true,
            createdAt: true,
            closedAt: true,
            factorsJson: true,
            flowJson: true,
            mtfJson: true
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 200
    });
    const asc = [
        ...rows
    ].reverse(); // asc for spacing diffs
    const scored = asc.map((r, i)=>scoreSample(r, i > 0 ? asc[i - 1].createdAt : null, spacingMin));
    const settledSamples = scored.filter((s)=>s.settled);
    const settledRaw = settledSamples.length;
    const openRaw = scored.filter((s)=>!s.settled).length;
    const healthy = settledSamples.filter((s)=>s.cls === "HEALTHY").length;
    const review = settledSamples.filter((s)=>s.cls === "REVIEW").length;
    const censored = settledSamples.filter((s)=>s.cls === "CENSORED").length;
    const healthyPct = pct(healthy, settledRaw);
    // informative = fully readable outcome: TP/SL proved the plan, or EXPIRED
    // after a TP touch (partially readable). EXPIRED-no-touch / CLOSED excluded.
    const informativePct = pct(settledSamples.filter((s)=>[
            "TP1",
            "TP2",
            "TP3",
            "SL"
        ].includes(s.status) || s.status === "EXPIRED" && !s.flags.includes("expired-no-touch")).length, settledRaw);
    const expiredNoTouch = settledSamples.filter((s)=>s.flags.includes("expired-no-touch")).length;
    const expiryCauses = {
        wrongSide: expiredNoTouch ? settledSamples.filter((s)=>s.flags.includes("expired-wrong-side")).length : 0,
        noFollow: expiredNoTouch ? settledSamples.filter((s)=>s.flags.includes("expired-no-follow")).length : 0,
        mixed: 0
    };
    expiryCauses.mixed = Math.max(0, expiredNoTouch - expiryCauses.wrongSide - expiryCauses.noFollow);
    // ── post-filter cohort — reuses the cohort-consistent scores (spacing vs true
    // predecessor) by index alignment with `asc`, not a re-scored sub-list.
    const postScored = asc.map((r, i)=>r.createdAt.getTime() >= FILTER_ERA_START_MS ? scored[i] : null).filter((s)=>s !== null);
    const postSettled = postScored.filter((s)=>s.settled);
    const postInformativePct = pct(postSettled.filter((s)=>[
            "TP1",
            "TP2",
            "TP3",
            "SL"
        ].includes(s.status) || s.status === "EXPIRED" && !s.flags.includes("expired-no-touch")).length, postSettled.length);
    const postExpiryRatePct = pct(postSettled.filter((s)=>s.flags.includes("expired-no-touch")).length, postSettled.length);
    const postFilterCohort = {
        since: new Date(FILTER_ERA_START_MS).toISOString(),
        n: postScored.length,
        settled: postSettled.length,
        informativePct: postInformativePct,
        expiryRatePct: postExpiryRatePct
    };
    const snapshotOk = scored.filter((s)=>!s.flags.includes("no-factors") && !s.flags.includes("no-flow") && !s.flags.includes("no-mtf")).length;
    const snapshotPct = pct(snapshotOk, scored.length);
    const symAcc = new Map();
    let longs = 0;
    for (const s of settledSamples){
        symAcc.set(s.symbol, (symAcc.get(s.symbol) ?? 0) + 1);
        if (s.direction === "LONG") longs++;
    }
    const symbols = symAcc.size;
    const topSymbolShare = symbols ? Math.max(...symAcc.values()) / settledRaw * 100 : null;
    const longPct = pct(longs, settledRaw);
    const shortPct = longPct !== null ? round1(100 - longPct) : null;
    const holds = settledSamples.map((s)=>s.holdMin).filter((h)=>h !== null);
    const meanAbsPnl = settledRaw ? round1(settledSamples.reduce((a, s)=>a + Math.abs(s.pnlPercent), 0) / settledRaw) : null;
    const meanHoldMin = holds.length ? Math.round(holds.reduce((a, b)=>a + b, 0) / holds.length) : null;
    const clusterCount = scored.filter((s)=>s.flags.includes("cluster-spawn")).length;
    // ── warnings (priority-ordered, sample-size-guarded — no noise at n=1) ──
    const warnings = [];
    if (settledRaw >= 3 && informativePct !== null && informativePct < 70) warnings.push(`informative ratio ${informativePct}% < 70% — EXPIRED censoring weakens R6 factor attribution`);
    if (settledRaw >= 5 && topSymbolShare !== null && topSymbolShare > 40) warnings.push(`symbol concentration ${round1(topSymbolShare)}% in one market — R6 may overfit`);
    if (settledRaw >= 5 && (longPct === null || shortPct === null || Math.max(longPct, shortPct ?? 0) > 75)) warnings.push(`side imbalance ${longPct ?? "—"}L/${shortPct ?? "—"}S — thin counter-direction evidence`);
    if (scored.length >= 2 && snapshotPct !== null && snapshotPct < 80) warnings.push(`deploy snapshots complete on ${snapshotPct}% of the cohort — factor attribution degraded`);
    if (clusterCount >= 2) warnings.push(`${clusterCount} records issued inside the ${spacingMin}min rail — burst cluster, correlated samples`);
    if (settledRaw >= 3 && healthyPct !== null && healthyPct < HEALTH_FLOOR) warnings.push(`healthy ${healthyPct}% below the ${HEALTH_FLOOR}% R6 floor`);
    // ── R6 gate verdict — v10.9.1 EPOCH-WINDOWED ──
    // Blocker 1 (structural, whole-cohort): snapshot integrity — era-independent.
    // Blocker 2 (regime, epoch window): window informative ratio below the GREEN
    // bar, only judged once the window carries enough settled rows (≥20) to be
    // statistically meaningful; below the warn-n the window is guarded, not
    // punished (small-sample informative dips are noise, not censoring).
    const blockers = [];
    const winSettled = postSettled.length;
    const winHealthyPct = pct(postSettled.filter((s)=>s.cls === "HEALTHY").length, winSettled);
    if (scored.length >= 2 && snapshotPct !== null && snapshotPct < 50) blockers.push(`snapshots complete on only ${snapshotPct}%`);
    if (winSettled >= GATE_WINDOW_WARN_N && postInformativePct !== null && postInformativePct < GATE_WINDOW_INFORMATIVE) blockers.push(`epoch-window informative ${postInformativePct}% < 50% (n=${winSettled}) — censoring regime`);
    const verdict = settledRaw === 0 || winSettled < GATE_WINDOW_FORMING ? "WARMING" // honest: the window has nothing meaningful to grade yet
     : blockers.length > 0 ? "RED" : winSettled < GATE_WINDOW_MIN_N || winHealthyPct !== null && winHealthyPct < HEALTH_FLOOR ? "AMBER" // window formed but short of the GREEN bar or the health floor
     : "GREEN";
    // UI samples view: settled cohort first (newest first), then in-flight
    const desc = [
        ...scored
    ].reverse();
    const samples = [
        ...desc.filter((s)=>s.settled),
        ...desc.filter((s)=>!s.settled)
    ].slice(0, 12);
    const digest = {
        at: new Date().toISOString(),
        issuedTotal: scored.length,
        openRaw,
        settledRaw,
        healthy,
        review,
        censored,
        healthyPct,
        informativePct,
        expiredNoTouch,
        expiryCauses,
        snapshotPct,
        symbols,
        topSymbolShare: topSymbolShare !== null ? round1(topSymbolShare) : null,
        longPct,
        shortPct,
        meanAbsPnl,
        meanHoldMin,
        clusterCount,
        warnings: warnings.slice(0, 5),
        gate: {
            verdict,
            healthFloor: HEALTH_FLOOR,
            blockers,
            window: {
                since: postFilterCohort.since,
                settled: winSettled,
                healthyPct: winHealthyPct,
                informativePct: postInformativePct
            }
        },
        postFilterCohort,
        samples
    };
    qualityCache = {
        at: Date.now(),
        data: digest
    };
    return digest;
}
function r6GateLine(d) {
    const w = d.gate.window;
    const base = `R6 DATA HEALTH (v10.9.1 epoch-windowed gate — verdict anchors the post-filter window, blended ratios reported for the whole book): raw cohort ${d.settledRaw} settled/${d.issuedTotal} issued · blended healthy ${d.healthyPct ?? "—"}% (floor ${d.gate.healthFloor}) · blended informative ${d.informativePct ?? "—"}% · snapshots ${d.snapshotPct ?? "—"}% · GATE ${d.gate.verdict}` + (w ? ` — window n=${w.settled} informative ${w.informativePct ?? "—"}% healthy ${w.healthyPct ?? "—"}%` : "") + (d.gate.verdict === "WARMING" ? " (window still forming — grading starts at the first window settles)" : "") + (d.gate.blockers.length ? ` · blockers: ${d.gate.blockers.join("; ")}` : "");
    const causes = d.expiryCauses && d.expiryCauses.wrongSide + d.expiryCauses.noFollow + d.expiryCauses.mixed > 0 ? ` · expiry causes: wrong-side ${d.expiryCauses.wrongSide} / no-follow ${d.expiryCauses.noFollow} / mixed ${d.expiryCauses.mixed} (of ${d.expiredNoTouch} no-touch)` : "";
    const post = d.postFilterCohort && d.postFilterCohort.n > 0 ? ` · post-filter cohort n=${d.postFilterCohort.n} (settled ${d.postFilterCohort.settled}) informative ${d.postFilterCohort.informativePct ?? "—"}% expiry ${d.postFilterCohort.expiryRatePct ?? "—"}%` : "";
    return base + causes + post + (d.warnings.length ? ` — watch: ${d.warnings[0]}` : " — no issues");
}
/** Compact digest for EngineSetting persistence (no samples array). */ function compact(d) {
    const { samples: _samples, ...rest } = d;
    void _samples;
    return rest;
}
async function recordRawcalQuality() {
    try {
        const digest = await computeRawcalQuality();
        const changed = digest.settledRaw !== lastSeenSettled;
        if (!changed && Date.now() - lastJournalAt < 10 * 60_000) return null;
        lastJournalAt = Date.now();
        lastSeenSettled = digest.settledRaw;
        const c = compact(digest);
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: QUALITY_KEY
            },
            create: {
                key: QUALITY_KEY,
                value: JSON.stringify(c)
            },
            update: {
                value: JSON.stringify(c)
            }
        }).catch(()=>undefined);
        try {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"]), {
                recursive: true
            });
            const row = {
                kind: "QUALITY",
                t: digest.at,
                issued: digest.issuedTotal,
                settled: digest.settledRaw,
                healthyPct: digest.healthyPct,
                informativePct: digest.informativePct,
                snapshotPct: digest.snapshotPct,
                gate: digest.gate.verdict,
                warns: digest.warnings.length
            };
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].appendFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], JSON.stringify(row) + "\n", "utf8");
            // opportunistic trim (same policy as the pace journal)
            const st = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].stat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"]).catch(()=>null);
            if (st && st.size > MAX_JOURNAL_ROWS * 180) {
                const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], "utf8").catch(()=>"");
                const lines = txt.split("\n").filter(Boolean).slice(-MAX_JOURNAL_ROWS);
                await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RAWCAL_TELEMETRY_FILE"], lines.join("\n") + "\n", "utf8").catch(()=>undefined);
            }
        } catch  {
        /* journal best-effort */ }
        return digest;
    } catch (e) {
        console.error("[rawcal-quality] record failed", e);
        return null;
    }
}
async function readPersistedQuality() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: QUALITY_KEY
            }
        });
        if (!row) return null;
        return JSON.parse(row.value);
    } catch  {
        return null;
    }
}
}),
"[project]/src/lib/calibration.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeCalibration",
    ()=>computeCalibration,
    "ensureCalibrationFrozen",
    ()=>ensureCalibrationFrozen,
    "getCalibration",
    ()=>getCalibration,
    "getEffectiveWeights",
    ()=>getEffectiveWeights,
    "refreshCalibration",
    ()=>refreshCalibration
]);
// ── FlowRadar Neo factor-weight calibration (server-only) ──
// v6.3 PROFIT-FIRST CALIBRATION (operator mandate: «کالیبراتور با معیار سود،
// نه تعداد برد»): factor weights are driven by NET PNL expectancy, not raw
// win rate. A factor that wins 44% of the time but bleeds -13%/trade on its
// losers is a LIABILITY (measured: BREAKOUT cohort) — raw WR could not see
// that; expectancy can. Per factor (strong votes only, n≥10 floor):
//
//   expectancy_f = Σ pnlPercent / n          (avg %/trade attributed)
//   profitFactor_f = Σ wins$ / |Σ losses$|   (gross wins ÷ gross losses)
//   weight_f = clamp(1 + expectancy/15 + 0.15·tanh(PF−1), 0.70, 1.30)
//
// Monotone in profit: +4.5%/trade ≈ +0.3 weight, 0%/trade ≈ 1.0, losers sink.
// Calibration goes ACTIVE at ≥30 settled signals, otherwise OBSERVING.
//
// v10.16 R6 QUALITY GATE (audit 4-f): the R6 freeze lift no longer fires on the
// n-count alone — the rawcal sample-quality gate must co-approve (verdict GREEN
// or blended informative ≥ 50%). Rationale: the lift re-fits factor weights on
// the EPOCH-2 book whose recent majority is RAW-CAL capture rows; when the
// raw cohort is censored (informative 43.4% AMBER live), the re-fit optimizes
// against time-censored outcomes. rawcal-quality.ts explicitly never edits the
// calibration math — so the CONDITIONING lives here, at the single decision
// point. No other calibration math is touched.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$quality$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript)");
;
;
const KEY = "calibration";
const ACTIVE_AT = 30;
const N_FLOOR = 10;
const MOVING_FACTORS = [
    "EMA STACK",
    "MACD MOMENTUM",
    "RSI POSITION",
    "RANGE BREAKOUT",
    "BOLLINGER EXTREME",
    "VOLUME CONFIRM"
];
/** %/trade of expectancy that maps to a full ±0.3 weight swing */ const EXPECTANCY_SCALE = 15;
/** weight ceiling/floor (matches the deploy-scan clamp in getEffectiveWeights) */ const W_MIN = 0.7;
const W_MAX = 1.3;
// ── v8.4 R3+R6 CALIBRATION FREEZE (module-performance audit 2026-09-11) ──
// Evidence: confidence calibration ran INVERTED (conf-80 bucket avgPnl −14.6%
// vs conf-70 −6.1%; 75%+ basket −$10.10) and the weights floored at 0.70 on
// negative-expectancy factors with n=35 — Wilson-LB far too thin to move on.
// R3: weights are FROZEN at a one-time recalibration over EPOCH-2-only rows.
// R6: no weight may move again until the epoch-2 book reaches minN settled
// samples (100) — then the freeze auto-lifts and normal calibration resumes.
const FROZEN_KEY = "calibration.frozen";
/** v10.16 — audit trail key for lift checks blocked by the rawcal quality gate. */ const R6_LIFT_BLOCKED_KEY = "calibration.r6.liftBlocked";
/** v10.16 — the blended informative share that co-approves the R6 lift
 * (alongside gate verdict GREEN). Matches the rawcal gate's GREEN informative bar. */ const R6_INFORMATIVE_FLOOR = 50;
const FREEZE_MIN_N = 100; // R6 gate — Wilson-LB width ∝ 1/√n; 100 ≈ ±10% at 50%
const FREEZE_EPOCH_TAG = "EPOCH-2";
async function readFreeze() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: FROZEN_KEY
            }
        });
        return row ? JSON.parse(row.value) : null;
    } catch  {
        return null;
    }
}
async function writeFreeze(state) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: FROZEN_KEY
        },
        create: {
            key: FROZEN_KEY,
            value: JSON.stringify(state)
        },
        update: {
            value: JSON.stringify(state)
        }
    });
}
async function ensureCalibrationFrozen() {
    const existing = await readFreeze();
    if (existing) return existing;
    const epoch2 = await computeCalibration(true);
    const state = {
        frozen: true,
        reason: `R3 audit 2026-09-11: calibration INVERTED (conf-80 bucket −14.6%/trade vs conf-70 −6.1%) with n=35 — weights recalibrated on ${epoch2.settled} EPOCH-2 settled rows and frozen (R6: no movement until n≥${FREEZE_MIN_N})`,
        minN: FREEZE_MIN_N,
        epoch: FREEZE_EPOCH_TAG,
        frozenAt: new Date().toISOString(),
        frozenSettled: epoch2.settled
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify({
                ...epoch2,
                updatedAt: new Date().toISOString()
            })
        },
        update: {
            key: KEY,
            value: JSON.stringify({
                ...epoch2,
                updatedAt: new Date().toISOString()
            })
        }
    });
    hot = null; // drop the hot cache so the frozen book is what deploys read
    await writeFreeze(state);
    return state;
}
async function computeCalibration(epoch2Only = false) {
    const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            pnlPercent: true,
            reachedTp: true,
            marginUsd: true,
            factorsJson: true,
            tags: true
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 300
    });
    // v8.4 R3: the frozen book must reflect the CURRENT ledger epoch only —
    // pre-reset rows (different sizing/fee regime) would poison the weights.
    const epochRows = epoch2Only ? settled.filter((s)=>(s.tags ?? "").includes("EPOCH-2")) : settled;
    // accumulate per-factor strong-vote PNL ledgers
    const acc = new Map();
    for (const f of MOVING_FACTORS)acc.set(f, {
        n: 0,
        wins: 0,
        sumPct: 0,
        gains: 0,
        losses: 0,
        sumUsd: 0
    });
    for (const s of epochRows){
        if (!s.factorsJson) continue;
        let votes = [];
        try {
            votes = JSON.parse(s.factorsJson);
        } catch  {
            continue;
        }
        for (const v of votes){
            const cell = acc.get(v.factor);
            if (!cell || Math.abs(v.vote) < 8) continue; // strong votes only
            cell.n++;
            cell.sumPct += s.pnlPercent;
            cell.sumUsd += s.marginUsd * s.pnlPercent / 100;
            if (s.pnlPercent >= 0) cell.gains += s.pnlPercent;
            else cell.losses += Math.abs(s.pnlPercent);
            // v5.4 TP-proven win kept for the transparency column only
            if (s.pnlPercent > 0 || s.reachedTp >= 1) cell.wins++;
        }
    }
    const rows = [];
    const weights = {};
    for (const f of MOVING_FACTORS){
        const cell = acc.get(f);
        if (cell.n < N_FLOOR) continue;
        const expectancy = cell.sumPct / cell.n;
        const pf = cell.losses > 0 ? Math.min(9.9, cell.gains / cell.losses) : 9.9;
        const raw = 1 + expectancy / EXPECTANCY_SCALE + 0.15 * Math.tanh(pf - 1);
        const w = Math.min(W_MAX, Math.max(W_MIN, raw));
        weights[f] = Number(w.toFixed(3));
        rows.push({
            factor: f,
            weight: weights[f],
            n: cell.n,
            expectancy: Number(expectancy.toFixed(2)),
            netPct: Number(cell.sumPct.toFixed(1)),
            profitFactor: Number(pf.toFixed(2)),
            winRate: Number((cell.wins / cell.n * 100).toFixed(1)),
            avgPct: Number(expectancy.toFixed(2)),
            pnlUsd: Number(cell.sumUsd.toFixed(2))
        });
    }
    let updatedAt = null;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) {
            const prev = JSON.parse(row.value);
            updatedAt = prev.updatedAt ?? null;
        }
    } catch  {
    /* ignore */ }
    return {
        status: (epoch2Only ? epochRows : settled).length >= ACTIVE_AT ? "ACTIVE" : "OBSERVING",
        settled: (epoch2Only ? epochRows : settled).length,
        target: ACTIVE_AT,
        criterion: "NET-PNL-EXPECTANCY",
        weights,
        rows,
        updatedAt
    };
}
async function refreshCalibration() {
    const freeze = await ensureCalibrationFrozen();
    const epoch2Settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    });
    if (freeze.frozen && epoch2Settled < freeze.minN) {
        const state = await computeCalibration(true); // display-only
        // v8.4.1 G3 (operator mandate): surface the freeze honestly — the card must
        // not read "OBSERVING 28/30" while weights are locked with a n≥100 lift bar.
        state.status = "FROZEN";
        state.settled = epoch2Settled;
        state.target = freeze.minN;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY
            },
            create: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            },
            update: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            }
        });
        return {
            state,
            auditLine: tickFreezeLine++ % 10 === 0 ? `CALIBRATION FROZEN (R3/R6): weights locked at epoch-2 recalibration (${freeze.frozenSettled} settled) — no movement until n≥${freeze.minN} (now ${epoch2Settled}). Learned/advisor weight writes are ignored while frozen.` : null
        };
    }
    if (freeze.frozen && epoch2Settled >= freeze.minN) {
        // ── v10.16 R6 QUALITY GATE — the n-count alone must not unfreeze. The lift
        // re-fits weights on the ledger; when the RAW-CAL sample quality is AMBER/RED
        // (censored book), the re-fit would learn from censoring, not edge. Require
        // gate GREEN OR blended informative ≥ 50% IN ADDITION to the n-bar.
        // Fail-closed: if the quality digest is unavailable, the freeze HOLDS
        // (an unverifiable book is not a healthy book).
        let quality = null;
        try {
            quality = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$quality$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["computeRawcalQuality"])(); // 30s-memoized, cheap at this cadence (~3.5min)
        } catch  {
            quality = null;
        }
        const qStatus = quality?.gate.verdict ?? "UNAVAILABLE";
        const qInformative = quality?.informativePct ?? null;
        const qualityOk = quality !== null && (quality.gate.verdict === "GREEN" || (quality.informativePct ?? -1) >= R6_INFORMATIVE_FLOOR);
        if (!qualityOk) {
            const blocked = {
                at: new Date().toISOString(),
                informativePct: qInformative,
                status: qStatus,
                epoch2Settled
            };
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: R6_LIFT_BLOCKED_KEY
                },
                create: {
                    key: R6_LIFT_BLOCKED_KEY,
                    value: JSON.stringify(blocked)
                },
                update: {
                    value: JSON.stringify(blocked)
                }
            }).catch(()=>undefined);
            const state = await computeCalibration(true); // display-only — weights stay frozen
            state.status = "FROZEN";
            state.settled = epoch2Settled;
            state.target = freeze.minN;
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: KEY
                },
                create: {
                    key: KEY,
                    value: JSON.stringify({
                        ...state,
                        updatedAt: new Date().toISOString()
                    })
                },
                update: {
                    key: KEY,
                    value: JSON.stringify({
                        ...state,
                        updatedAt: new Date().toISOString()
                    })
                }
            });
            if (r6BlockWarn++ % 10 === 0) {
                console.warn(`[calibration] R6 lift BLOCKED by rawcal quality gate — status ${qStatus}, informative ${qInformative ?? "n/a"}% (need GREEN or ≥${R6_INFORMATIVE_FLOOR}%), epoch2Settled ${epoch2Settled} ≥ n-bar ${freeze.minN}. Weights stay frozen — no re-fit on a censored book (v10.16).`);
            }
            return {
                state,
                auditLine: tickFreezeLine++ % 10 === 0 ? `CALIBRATION STILL FROZEN (R3/R6 + v10.16 quality gate): n-bar reached (${epoch2Settled} ≥ ${freeze.minN}) but rawcal sample gate ${qStatus} (blended informative ${qInformative ?? "n/a"}% < ${R6_INFORMATIVE_FLOOR}% or not GREEN) — no weight re-fit on a censored book until the gate co-approves.` : null
            };
        }
        await writeFreeze({
            ...freeze,
            frozen: false,
            reason: `${freeze.reason} → R6 LIFT: epoch-2 book reached n=${epoch2Settled} ≥ ${freeze.minN} with rawcal quality co-approval (gate ${qStatus}, informative ${qInformative}%) — calibration unfrozen`
        });
        const state = await computeCalibration();
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY
            },
            create: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            },
            update: {
                key: KEY,
                value: JSON.stringify({
                    ...state,
                    updatedAt: new Date().toISOString()
                })
            }
        });
        return {
            state,
            auditLine: `R6 CALIBRATION LIFT: epoch-2 book reached n=${epoch2Settled} ≥ ${freeze.minN} — profit-first weight calibration RESUMES (was frozen since ${freeze.frozenAt}).`
        };
    }
    const state = await computeCalibration();
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify({
                ...state,
                updatedAt: new Date().toISOString()
            })
        },
        update: {
            key: KEY,
            value: JSON.stringify({
                ...state,
                updatedAt: new Date().toISOString()
            })
        }
    });
    const auditLine = state.status === "ACTIVE" && state.rows.length > 0 ? `AI CALIBRATION (net-PNL criterion): weights from ${state.settled} settled — ${state.rows.map((r)=>`${r.factor} ×${r.weight.toFixed(2)} (exp ${r.expectancy >= 0 ? "+" : ""}${r.expectancy}%/trade, PF ${r.profitFactor}, n=${r.n})`).join(" · ")}` : null;
    return {
        state,
        auditLine
    };
}
let tickFreezeLine = 0; // rate-limit the frozen audit line inside the 60-tick calibration hook
let r6BlockWarn = 0; // v10.16 — rate-limit the quality-blocked console.warn (~1 line / 35min at the 60-tick cadence)
/** Cached read for hot paths (deploy scan). Falls back to compute on miss. */ let hot = null;
async function getCalibration() {
    if (hot && Date.now() - hot.at < 60_000) return hot.state;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) {
            const state = JSON.parse(row.value);
            hot = {
                at: Date.now(),
                state
            };
            return state;
        }
    } catch  {
    /* ignore */ }
    const state = await computeCalibration();
    hot = {
        at: Date.now(),
        state
    };
    return state;
}
async function getEffectiveWeights() {
    const cal = await getCalibration();
    const weights = {
        ...cal.weights
    };
    let source = Object.keys(weights).length ? "calibration" : "none";
    // v8.4 R6: while frozen, learned autotune adoption is ignored — the whole
    // point of the freeze is that n=35 evidence must not steer live scoring.
    if (source === "calibration" && (await readFreeze())?.frozen) {
        return {
            weights,
            source: "frozen"
        };
    }
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "backtest.autotune"
            }
        });
        if (row) {
            const at = JSON.parse(row.value);
            if (at.adopted && at.adoptedWeights) {
                for (const [f, w] of Object.entries(at.adoptedWeights)){
                    const base = weights[f] ?? 1;
                    weights[f] = Number(Math.min(1.3, Math.max(0.7, base * w)).toFixed(3));
                }
                source = Object.keys(cal.weights).length ? "calibration×autotune" : "autotune";
            }
        }
    } catch  {
    /* ignore */ }
    return {
        weights,
        source
    };
}
}),
"[project]/src/lib/backtest.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAutotune",
    ()=>getAutotune,
    "getBacktest",
    ()=>getBacktest,
    "getBacktestBundle",
    ()=>getBacktestBundle,
    "getLearnerAutoState",
    ()=>getLearnerAutoState,
    "getRuns",
    ()=>getRuns,
    "isAutotuneRunning",
    ()=>isAutotuneRunning,
    "learnedGateAllows",
    ()=>learnedGateAllows,
    "maybeAutoLearner",
    ()=>maybeAutoLearner,
    "runAutotune",
    ()=>runAutotune,
    "runBacktest",
    ()=>runBacktest,
    "simulate",
    ()=>simulate
]);
// ── FlowRadar Neo replayed-history performance learner (v5.0, server-only) ──
// FORCES the engine to learn from PAST data instead of staying static:
//   1. REPLAY  — real Binance klines candle-by-candle through the exact
//      confluence+gate scorer with the real deployment ladder + fee NET math.
//   2. AUTO-TUNE — coordinate sweep over factor weights around the current
//      baseline; adopts the best combo ONLY when it genuinely improves the
//      objective (Wilson-LB + expectancy) — otherwise the baseline stands.
//   3. LEARNING PROGRESS — every run is appended to a persistent runs ring so
//      the operator can watch WR/expectancy/Wilson-LB evolve run over run.
//   4. SCHEDULER — re-runs itself every LEARNER_AUTO_H (default 6h), so the
//      learned mean keeps moving as new history accrues.
// Its verdicts feed the LEARNED GATE that decides when live auto-signals start.
//
// ── v10.16 PARITY FIX ────────────────────────────────────────────────────
// Settlement mirrors engine.ts resolveSignals (engine.ts:439-662): tranche
// 50/30/20 (LADDER_TRANCHES, accounting.ts:47) banked at RUNG prices, BE-trail
// at TP1 (stop := entry, engine.ts:493), +1R trail at TP2 (stop := tp1 rung,
// engine.ts:489), TP3 runner priced at the deploy-time tp3 RUNG — never the old
// 2.6R-on-full-margin projection (engine.ts:597) — SL-first ordering per candle
// (engine.ts:467/474), a single feeBreakdown NET pass on the full notional with
// the tranche-weighted move (engine.ts:607, accounting.ts:49-57), the mid-ladder
// BE arm (engine.ts:508-514) and early time-exit (engine.ts:515-541) evaluated
// at the candle close, and OPEN-SYMBOL DEDUP replacing the fabricated 24h
// per-symbol cooldown (engine.ts:989+1004 — live dedups open symbols only).
// Remaining known delta: dynamic TTL-extension gate not simulated (fixed TTL =
// conservative; live gate at engine.ts:541-562).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indicators.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accounting.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$calibration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/calibration.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
;
;
;
;
;
;
const INTERVAL = "15m";
const CANDLES = 500; // ~5.2 days per symbol
const WARMUP = 60;
const BASE_STEP = 2; // baseline evaluates every 2nd candle (30min grid)
const SWEEP_STEP = 4; // sweeps use a coarser grid (60min) for speed
const TTL_MIN = {
    "AI-SCALP": 75,
    BREAKOUT: 120,
    MOMENTUM: 150,
    "MEAN-REVERT": 90,
    "AI-SWING": 240
};
const KEY_BT = "backtest";
const KEY_RUNS = "backtest.runs";
const KEY_AT = "backtest.autotune";
// ── kline cache: every sweep reuses ONE fetch per symbol ──────
const klineCache = new Map();
const KLINE_TTL = 10 * 60_000;
async function primeKlines(symbols) {
    const ok = [];
    for (const s of symbols){
        const hit = klineCache.get(s);
        if (hit && Date.now() - hit.at < KLINE_TTL) {
            ok.push(s);
            continue;
        }
        try {
            const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(s, INTERVAL, CANDLES);
            klineCache.set(s, {
                at: Date.now(),
                candles
            });
            ok.push(s);
        } catch  {
        /* skip symbol this run */ }
    }
    return ok;
}
function wilsonLowerBound(wins, n, z = 1.96) {
    if (n === 0) return 0;
    const p = wins / n;
    const denom = 1 + z * z / n;
    const centre = p + z * z / (2 * n);
    const margin = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n));
    return Math.max(0, (centre - margin) / denom) * 100;
}
/** learner objective: Wilson-LB dominates, expectancy breaks ties, small-n disqualified. */ function objectiveOf(res) {
    if (res.n < 12) return -999;
    return res.wilsonLB + Math.max(-15, Math.min(20, res.avgNetPct * 10));
}
function simulate(candles, entryIdx, dir, entry, sl, tp1, tp2, tp3, ttlCandles, ctx) {
    const isLong = dir === "LONG";
    const slDist = Math.abs(entry - sl) / entry;
    const lev = Math.round(Math.min(20, Math.max(5, 60 / Math.max(0.7, slDist * 100)))); // mirror engine leverage pick
    const rGross = slDist * 100 * lev; // 1R in levered %-on-margin — engine.ts:533 (rAnchor = initialStopLoss = deploy stop `sl`)
    const moveAtPct = (px)=>(px - entry) / entry * (isLong ? 1 : -1) * 100; // UNLEVERED — engine.ts:584
    const ttlMinutes = ttlCandles * 15;
    let stop = sl; // EFFECTIVE (trailed) stop — v5.4 semantics: trailed stops are real (engine.ts:461, 477-481)
    let reachedTp = 0; // TP-PROVEN ledger (engine.ts:469-472)
    let beBank = null; // v11.2 BE-BANK — parity with the live ledger (engine.ts resolveSignals)
    // ── v6.6 TRANCHE-AWARE NET ACCOUNTING (arithmetic copied verbatim from engine.ts:569-607) ──
    function finalize(outcome, exitIdx, mark) {
        let finalMovePct;
        // v11.2 BE-BANK tranche — parity with engine.ts settlement: the banked leg
        // exits at its arm mark, the ladder weights scale by 1−frac so tranches
        // still sum to 1. Legacy rows (never banked) keep the exact old math.
        const remain = beBank ? 1 - beBank.frac : 1;
        if (reachedTp >= 1) {
            // TRANCHES FIRST — 50%/30% already left the book at their RUNG prices while
            // the trade was open; the runner leg exits by final status: TP3 → tp3 rung
            // (a deploy-time price stop moves can never touch) · SL → EFFECTIVE (trailed)
            // stop · EXPIRED → closing mark (engine.ts:592-601).
            const runnerMove = outcome === "TP3" ? moveAtPct(tp3) : outcome === "SL" ? moveAtPct(stop) : moveAtPct(mark);
            const tranches = [];
            if (beBank) tranches.push({
                weight: beBank.frac,
                movePct: beBank.movePct
            });
            tranches.push({
                weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp1 * remain,
                movePct: moveAtPct(tp1)
            });
            if (reachedTp >= 2) tranches.push({
                weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp2 * remain,
                movePct: moveAtPct(tp2)
            });
            tranches.push({
                weight: (1 - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp1 - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp2) * remain,
                movePct: runnerMove
            });
            finalMovePct = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ladderWeightedMove"])(tranches);
        } else if (beBank) {
            // BE-banked, no rung — bank leg @ arm mark + remainder at the real exit
            // (SL → the post-arm stop at entry · EXPIRED → the closing mark).
            finalMovePct = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ladderWeightedMove"])([
                {
                    weight: beBank.frac,
                    movePct: beBank.movePct
                },
                {
                    weight: remain,
                    movePct: outcome === "SL" ? moveAtPct(stop) : moveAtPct(mark)
                }
            ]);
        } else if (outcome === "SL") {
            finalMovePct = moveAtPct(stop); // effective (trailed) stop is the real exit — nothing was banked (engine.ts:602-603)
        } else {
            finalMovePct = moveAtPct(mark); // EXPIRED without a banked rung — mark on full margin (engine.ts:604-605)
        }
        return {
            outcome,
            movePct: finalMovePct,
            lev,
            heldMin: (exitIdx - entryIdx) * 15,
            reachedTp,
            exitIdx
        };
    }
    for(let j = entryIdx + 1; j < candles.length && j <= entryIdx + ttlCandles; j++){
        const c = candles[j];
        const heldMin = (j - entryIdx) * 15;
        // ① SL FIRST — live evaluates hitSl before every TP branch in the same tick
        // (engine.ts:467 + 474). Within one 15m candle the intracandle order is
        // unknowable; the mandated conservative reading stops the trade first.
        // The runner (plus any unbanked margin) exits at the EFFECTIVE stop, which
        // may already be BE/+1R after trails (engine.ts:479, 597, 603).
        if (isLong ? c.low <= stop : c.high >= stop) return finalize("SL", j, stop);
        // ② TP ladder — banks price at RUNG levels exactly like the live ledger
        // (engine.ts:598-600). A tp3 touch geometrically implies tp1+tp2 were touched
        // (same-side extremes), so reachedTp=3 prices all three legs below.
        if (isLong ? c.high >= tp3 : c.low <= tp3) {
            reachedTp = 3;
            return finalize("TP3", j, tp3); // runner exits at the tp3 RUNG — engine.ts:597
        }
        if (isLong ? c.high >= tp2 : c.low <= tp2) {
            reachedTp = 2; // TP1 leg banked earlier or same candle — both legs priced in finalize
            stop = tp1; // v5.4: trail to the TP1 RUNG = the announced +1R lock (engine.ts:489; tp1 = entry ± 1×risk, engine.ts:1515)
        } else if (isLong ? c.high >= tp1 : c.low <= tp1) {
            reachedTp = 1;
            stop = entry; // v5.4: breakeven trail enforced at TP1 (engine.ts:493)
        }
        // ③ mid-ladder BE arm / ④ early time-exit — only while UNBANKED (live
        // requires s.status === "ACTIVE", engine.ts:508 + 527). Mark-based checks
        // evaluate at the candle CLOSE — the coarse-grained analogue of the live
        // 3.5s tick. Live orders these as one else-if chain per tick (508 → 515).
        if (reachedTp === 0) {
            const closeMovePct = moveAtPct(c.close);
            const stillUntrailed = isLong ? stop < entry : stop > entry; // engine.ts:509
            if (stillUntrailed && (ctx.gate.beArmRMult > 0 && slDist * 100 > 0 && closeMovePct >= ctx.gate.beArmRMult * slDist * 100 || ctx.gate.beArmMovePct > 0 && closeMovePct >= ctx.gate.beArmMovePct || ctx.gate.beTrailPct > 0 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(ctx.margin, lev, closeMovePct, heldMin).netPct >= ctx.gate.beTrailPct)) {
                // v11.2 STRUCTURAL R-ARM + BE-BANK (engine.ts:699-738): primary trigger
                // = the trade's own risk geometry (price ≥ beArmRMult × slDist), the
                // absolute-price arm stays as the wide-stop ceiling, the legacy NET arm
                // stays governor-available. The bank tranche is captured at the arm
                // CLOSE mark (candle-close analogue of the live 3.5s tick mark).
                stop = entry;
                if (ctx.gate.beBankFrac > 0) beBank = {
                    frac: ctx.gate.beBankFrac,
                    movePct: closeMovePct
                };
            } else if (ctx.gate.earlyExitGuard > 0 && heldMin >= ctx.gate.earlyExitFrac * ttlMinutes) {
                // v8.4 R2/R7 EARLY TIME-EXIT (engine.ts:515-541): an unbanked trade after
                // earlyExitFrac of TTL closes at the mark when ADVERSE (NET ≤ −earlyExitR × 1R)
                // or STALLED (|gross| ≤ 0.15R) — booked EXPIRED, not ridden to −1R.
                const fb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(ctx.margin, lev, closeMovePct, heldMin);
                const adverse = ctx.gate.earlyExitR > 0 && fb.netPct <= -(ctx.gate.earlyExitR * rGross);
                const stalled = Math.abs(closeMovePct * lev) <= 0.15 * rGross;
                if (adverse || stalled) return finalize("EXPIRED", j, c.close);
            }
        }
    }
    // ⑤ TTL expiry — auto-close at the closing mark (engine.ts:541-567 + 597/605).
    // KNOWN DELTA: the live DYNAMIC EXPIRY GATE (TTL extensions, engine.ts:541-562)
    // is not simulated — fixed TTL is the conservative bound.
    const endIdx = Math.min(candles.length - 1, entryIdx + ttlCandles);
    return finalize("EXPIRED", endIdx, candles[endIdx].close);
}
async function runBacktest(opts = {}) {
    const t0 = Date.now();
    const persist = opts.persist !== false;
    const step = opts.step ?? BASE_STEP;
    const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
    const cal = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$calibration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["computeCalibration"])();
    const assets = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
        orderBy: {
            volume24h: "desc"
        },
        take: 12
    });
    const wanted = (opts.symbolsOverride?.length ? opts.symbolsOverride : assets.map((a)=>a.symbol)).slice(0, 12);
    const symbols = await primeKlines(wanted);
    const weights = opts.weights ?? (Object.keys(cal.weights).length ? cal.weights : null);
    const minScore = Math.max(15, Math.min(65, gate.minScore + (opts.minScoreAdj ?? 0)));
    const trades = [];
    let candidatesEvaluated = 0;
    let equity = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ACCOUNT_START_USD"];
    const equityCurve = [
        {
            i: 0,
            equity
        }
    ];
    const factorAcc = new Map();
    let candlesPerSymbol = 0;
    let spanHours = 0;
    for (const symbol of symbols){
        const candles = klineCache.get(symbol)?.candles;
        if (!candles || candles.length < WARMUP + 30) continue;
        candlesPerSymbol = candles.length;
        spanHours = Math.max(spanHours, (candles[candles.length - 1].openTime - candles[0].openTime) / 3600_000);
        // v10.16: open-symbol dedup window for THIS symbol (per-symbol scope, like the
        // live openSymbols set — engine.ts:989)
        let openUntilIdx = -1;
        for(let i = WARMUP; i < candles.length - 5; i += step){
            const c = candles[i];
            // v10.16 OPEN-SYMBOL DEDUP (parity — engine.ts:989 openSymbols fetch +
            // :1004 `if (openSymbols.has(asset.symbol)) return false`, applied at the
            // scan pool BEFORE scoring): a candidate is skipped while its symbol already
            // carries an open simulated position. The previous 24h per-symbol cooldown
            // was FABRICATED — the live engine has no such rule — and it throttled the
            // replay sample ~24× per symbol.
            if (i <= openUntilIdx) continue;
            const snap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["buildSnapshot"])(symbol, candles.slice(0, i + 1));
            if (!snap) continue;
            const conf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["scoreConfluence"])(snap, weights ?? undefined);
            candidatesEvaluated++;
            if (Math.abs(conf.score) < minScore) continue;
            // simulate the ladder
            const isLong = conf.direction === "LONG";
            const entry = c.close;
            const slDistPct = Math.min(4.5, Math.max(0.7, 1.5 * snap.atrPct)) / 100;
            const sl = entry * (isLong ? 1 - slDistPct : 1 + slDistPct);
            const risk = Math.abs(entry - sl);
            const tp1 = isLong ? entry + risk : entry - risk;
            const tp2 = isLong ? entry + risk * 1.8 : entry - risk * 1.8;
            const tp3 = isLong ? entry + risk * 2.6 : entry - risk * 2.6;
            const ttlCandles = Math.round((TTL_MIN[conf.strategy] ?? 120) / 15);
            // margin sized BEFORE the walk — the live mid-trade BE-arm reads the real
            // position margin for its NET check (engine.ts:456 + :510)
            const margin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["confidenceMargin"])(conf.confidence, equity, equity * 0.9);
            const sim = simulate(candles, i, conf.direction, entry, sl, tp1, tp2, tp3, ttlCandles, {
                margin,
                gate
            });
            // v10.16: the symbol stays dedup-blocked until the simulated position resolves
            openUntilIdx = sim.exitIdx;
            // fee-aware NET on a running $100 equity account — ONE feeBreakdown pass on
            // the FULL notional with the tranche-weighted move (engine.ts:607; the three
            // exit fills sum to one position, so commission/swap totals are unchanged —
            // accounting.ts:49-57). sim.movePct = UNLEVERED weighted move.
            const lev = sim.lev;
            const fb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(margin, lev, sim.movePct, sim.heldMin);
            equity += fb.netUsd;
            equityCurve.push({
                i: trades.length + 1,
                equity: Number(equity.toFixed(2))
            });
            // win stays NET-based (exported stat semantics unchanged); with tranche
            // accounting a TP1-banked round-trip now nets ≈ +0.5R−fees like live. Note:
            // live regime telemetry additionally counts any reachedTp≥1 close as a win
            // (engine.ts:615) — the backtest WR deliberately keeps its NET definition.
            const win = fb.netPct > 0;
            for (const v of conf.votes){
                if (Math.abs(v.vote) < 8) continue;
                const cell = factorAcc.get(v.factor) ?? {
                    wins: 0,
                    n: 0
                };
                cell.n++;
                if (win) cell.wins++;
                factorAcc.set(v.factor, cell);
            }
            trades.push({
                symbol,
                openedAt: c.openTime,
                direction: conf.direction,
                score: conf.score,
                strategy: conf.strategy,
                confidence: conf.confidence,
                outcome: sim.outcome,
                grossPct: Number((sim.movePct * sim.lev).toFixed(2)),
                netPct: Number(fb.netPct.toFixed(2)),
                netUsd: Number(fb.netUsd.toFixed(3)),
                heldMin: sim.heldMin,
                votes: conf.votes.map((v)=>({
                        factor: v.factor,
                        vote: v.vote
                    }))
            });
        // v10.16: NO per-symbol cooldown — live re-deploys as soon as the symbol has
        // no open position (engine.ts:1004 dedups OPEN symbols only).
        }
    }
    const n = trades.length;
    const wins = trades.filter((t)=>t.netPct > 0).length;
    const losses = n - wins;
    const winRate = n ? wins / n * 100 : 0;
    const avgNetPct = n ? trades.reduce((a, t)=>a + t.netPct, 0) / n : 0;
    const expectancyR = n ? trades.reduce((a, t)=>a + t.netPct / 100, 0) / n : 0;
    const wilsonLB = wilsonLowerBound(wins, n);
    const stratAcc = new Map();
    for (const t of trades){
        const cell = stratAcc.get(t.strategy) ?? {
            n: 0,
            wins: 0,
            net: 0
        };
        cell.n++;
        if (t.netPct > 0) cell.wins++;
        cell.net += t.netPct;
        stratAcc.set(t.strategy, cell);
    }
    const factorLessons = [
        ...factorAcc.entries()
    ].filter(([, c])=>c.n >= 5).map(([factor, c])=>({
            factor,
            n: c.n,
            winRate: Number((c.wins / c.n * 100).toFixed(1))
        })).sort((a, b)=>b.winRate - a.winRate);
    const byStrategy = [
        ...stratAcc.entries()
    ].map(([strategy, c])=>({
            strategy,
            c0: c.n,
            c1: c.wins,
            c2: Number((c.net / c.n).toFixed(2))
        })).sort((a, b)=>b.c0 - a.c0).map(({ strategy, c0, c1, c2 })=>({
            strategy,
            n: c0,
            wins: c1,
            avgNetPct: c2
        }));
    const verdict = n === 0 ? `NO QUALIFYING SETUPS in the replayed window — minScore ${minScore} too strict for this volatility regime` : wilsonLB >= 45 && avgNetPct > 0 ? `LEARNED EDGE CONFIRMED — WR ${winRate.toFixed(0)}% (Wilson-LB ${wilsonLB.toFixed(0)}%) · expectancy ${avgNetPct.toFixed(2)}%/trade NET — live auto-deployment UNLOCKED by the learned gate` : wilsonLB >= 40 ? `MARGINAL — WR ${winRate.toFixed(0)}% (LB ${wilsonLB.toFixed(0)}%), expectancy ${avgNetPct.toFixed(2)}%/trade — auto-deploy stays gated, keep observing` : `NO LEARNED EDGE — WR ${winRate.toFixed(0)}% (LB ${wilsonLB.toFixed(0)}%), expectancy ${avgNetPct.toFixed(2)}%/trade NET — live auto-deployment stays SUPPRESSED until recalibration`;
    const objective = objectiveOf({
        n,
        wilsonLB,
        avgNetPct
    });
    const result = {
        ranAt: new Date().toISOString(),
        engine: "FLOWRADAR-NEO v5.1 BACKTEST & LEARNER",
        label: opts.label ?? (persist ? "REPLAY" : "sweep"),
        symbolsScanned: symbols,
        candlesPerSymbol,
        spanHours: Number(spanHours.toFixed(1)),
        candidatesEvaluated,
        n,
        wins,
        losses,
        winRate: Number(winRate.toFixed(1)),
        wilsonLB: Number(wilsonLB.toFixed(1)),
        avgNetPct: Number(avgNetPct.toFixed(2)),
        expectancyR: Number(expectancyR.toFixed(3)),
        totalNetUsd: Number((equity - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ACCOUNT_START_USD"]).toFixed(2)),
        equityEnd: Number(equity.toFixed(2)),
        byStrategy,
        factorLessons,
        equityCurve: equityCurve.slice(-64),
        trades: persist ? trades.slice(-24).reverse() : [],
        verdict,
        calibration: {
            status: cal.status,
            settled: cal.settled,
            target: cal.target
        },
        weightsUsed: weights ? Object.fromEntries(Object.entries(weights).map(([k, v])=>[
                k,
                Number(v.toFixed(3))
            ])) : null,
        minScoreAdj: opts.minScoreAdj ?? 0,
        objective: Number(objective.toFixed(1))
    };
    if (persist) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_BT
            },
            create: {
                key: KEY_BT,
                value: JSON.stringify(result)
            },
            update: {
                value: JSON.stringify(result)
            }
        });
        const runs = await getRuns();
        runs.unshift({
            ranAt: result.ranAt,
            label: result.label,
            n,
            winRate: result.winRate,
            wilsonLB: result.wilsonLB,
            avgNetPct: result.avgNetPct,
            equityEnd: result.equityEnd,
            objective: result.objective,
            adopted: null
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_RUNS
            },
            create: {
                key: KEY_RUNS,
                value: JSON.stringify(runs.slice(0, 14))
            },
            update: {
                value: JSON.stringify(runs.slice(0, 14))
            }
        });
    }
    console.log(`[backtest] v5.1 ${result.label} done in ${Date.now() - t0}ms — ${n} sim trades from ${candidatesEvaluated} candidates (step=${step}, minScore=${minScore}) · objective ${result.objective}`);
    return result;
}
// ── AUTO-TUNE: coordinate sweep that can actually IMPROVE the engine ──
const TUNED_FACTORS = [
    "EMA STACK",
    "MACD MOMENTUM",
    "RANGE BREAKOUT",
    "RSI POSITION"
];
const SWEEP_VALUES = [
    0.75,
    0.9,
    1.1,
    1.25
];
const ADOPT_MARGIN = 3; // best must beat baseline objective by ≥3
let autotuneInFlight = false;
function isAutotuneRunning() {
    return autotuneInFlight;
}
async function runAutotune() {
    if (autotuneInFlight) throw new Error("auto-tune already running");
    autotuneInFlight = true;
    try {
        // baseline on the full grid with current effective weights
        const baseline = await runBacktest({
            label: "AUTO-TUNE BASELINE",
            persist: true
        });
        const baseWeights = baseline.weightsUsed ?? {};
        const baseObj = objectiveOf(baseline);
        let best = null;
        let bestCombo = null;
        let trials = 0;
        for (const factor of TUNED_FACTORS){
            for (const val of SWEEP_VALUES){
                // skip combos that equal the untouched baseline weight (1.0 excluded by grid)
                const combo = {
                    ...baseWeights,
                    [factor]: val
                };
                const res = await runBacktest({
                    label: `SWEEP ${factor}×${val}`,
                    weights: combo,
                    step: SWEEP_STEP,
                    persist: false
                });
                trials++;
                if (!best || objectiveOf(res) > objectiveOf(best)) {
                    best = res;
                    bestCombo = combo;
                }
            }
        }
        const bestObj = best ? objectiveOf(best) : -999;
        const delta = Number((bestObj - baseObj).toFixed(1));
        const adopt = best !== null && bestObj >= baseObj + ADOPT_MARGIN && best.n >= baseline.n * 0.8;
        let at = await getAutotune();
        if (!at) {
            at = {
                adoptedAt: null,
                adoptedWeights: null,
                baselineObjective: baseObj,
                bestObjective: bestObj,
                bestCombo: null,
                trials,
                adopted: false,
                lastRunAt: new Date().toISOString(),
                history: []
            };
        }
        at.baselineObjective = Number(baseObj.toFixed(1));
        at.bestObjective = Number(bestObj.toFixed(1));
        at.bestCombo = adopt ? Object.fromEntries(Object.entries(bestCombo).map(([k, v])=>[
                k,
                Number(v.toFixed(3))
            ])) : at.bestCombo;
        at.trials = trials;
        at.adopted = adopt;
        at.lastRunAt = new Date().toISOString();
        if (adopt) at.adoptedAt = at.lastRunAt;
        if (adopt && bestCombo) at.adoptedWeights = Object.fromEntries(Object.entries(bestCombo).map(([k, v])=>[
                k,
                Number(v.toFixed(3))
            ]));
        at.history.unshift({
            at: at.lastRunAt,
            adopted: adopt,
            baseline: at.baselineObjective,
            best: at.bestObjective,
            delta,
            summary: adopt ? `ADOPTED — ${TUNED_FACTORS.filter((f)=>at.adoptedWeights?.[f] !== undefined && at.adoptedWeights[f] !== baseWeights[f]).map((f)=>`${f}×${at.adoptedWeights[f].toFixed(2)}`).join(" ")} — objective ${baseObj.toFixed(1)}→${bestObj.toFixed(1)}` : `NO ADOPTION — best sweep objective ${bestObj.toFixed(1)} < baseline ${baseObj.toFixed(1)} + ${ADOPT_MARGIN} margin; baseline stands`
        });
        at.history = at.history.slice(0, 8);
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_AT
            },
            create: {
                key: KEY_AT,
                value: JSON.stringify(at)
            },
            update: {
                value: JSON.stringify(at)
            }
        });
        // mark the adopted flag on the newest runs rows
        const runs = await getRuns();
        if (runs[0]) runs[0].adopted = adopt;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_RUNS
            },
            create: {
                key: KEY_RUNS,
                value: JSON.stringify(runs.slice(0, 14))
            },
            update: {
                value: JSON.stringify(runs.slice(0, 14))
            }
        });
        console.log(`[backtest:autotune] trials=${trials} baseline=${baseObj.toFixed(1)} best=${bestObj.toFixed(1)} adopted=${adopt}`);
        return {
            baseline,
            best,
            adopted: adopt,
            trials,
            delta
        };
    } finally{
        autotuneInFlight = false;
    }
}
async function getAutotune() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY_AT
            }
        });
        return row ? JSON.parse(row.value) : null;
    } catch  {
        return null;
    }
}
async function getRuns() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY_RUNS
            }
        });
        return row ? JSON.parse(row.value) : [];
    } catch  {
        return [];
    }
}
async function getBacktestBundle() {
    const [result, runs, autotune] = await Promise.all([
        getBacktest(),
        getRuns(),
        getAutotune()
    ]);
    return {
        result,
        runs,
        autotune
    };
}
async function getBacktest() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY_BT
            }
        });
        return row ? JSON.parse(row.value) : null;
    } catch  {
        return null;
    }
}
// ── SCHEDULER: the learner re-runs itself so the mean never goes stale ──
// v6.0 FULL AUTONOMY: the scheduler is ALWAYS ON — the pre-v6 manual
// enable/disable toggle (`setLearnerAuto`) was removed with the operator
// mandate «هیچ حالت دستی برای یادگیری و استقرار نباید باشه». Only the cadence
// (intervalHours) is configurable, and the stored config can never disable it.
const AUTO_KEY = "learner.auto";
const KEY_BASELINE = "learner.baseline"; // v8.4.1 G2 — frozen-mode baseline replay clock
let autoInFlight = false;
let autoLastAt = 0;
const AUTO_MIN_INTERVAL_MS = 60_000; // DB guard between checks
async function getAutoCfg() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: AUTO_KEY
            }
        });
        if (row) {
            const v = JSON.parse(row.value);
            // enabled is FORCED true — a stale persisted pause can never freeze learning
            return {
                enabled: true,
                intervalHours: Math.min(24, Math.max(1, Number(v.intervalHours) || 6))
            };
        }
    } catch  {
    /* defaults */ }
    return {
        enabled: true,
        intervalHours: 6
    };
}
async function getLearnerAutoState() {
    const cfg = await getAutoCfg();
    const at = await getAutotune();
    const last = at?.lastRunAt ?? null;
    const next = last ? new Date(new Date(last).getTime() + cfg.intervalHours * 3600_000).toISOString() : null;
    return {
        ...cfg,
        lastRunAt: last,
        nextRunAt: next,
        running: autoInFlight
    };
}
async function maybeAutoLearner() {
    if (autoInFlight) return;
    if (Date.now() - autoLastAt < AUTO_MIN_INTERVAL_MS) return;
    autoLastAt = Date.now();
    const cfg = await getAutoCfg();
    if (!cfg.enabled) return;
    const at = await getAutotune();
    if (at?.lastRunAt && Date.now() - new Date(at.lastRunAt).getTime() < cfg.intervalHours * 3600_000) return;
    autoInFlight = true;
    void (async ()=>{
        try {
            // v9.0 LIFECYCLE LEARNING (operator request 2026-09-12): TTL-extension,
            // BE-trail and afterlife outcomes are now measured + persisted on every
            // learner cadence — the evidence the governor/advisor read. Self-throttled
            // inside the module (5h floor); failure never blocks the learner.
            void __turbopack_context__.A("[project]/src/lib/lifecycle-learning.ts [app-route] (ecmascript, async loader)").then((m)=>m.recordLifecycleLearning()).catch((e)=>console.error("[lifecycle-learning]", e));
            // v8.4 R6 + v8.4.1 G2 (operator mandate 2026-09-11): while the calibration
            // freeze is ON, autotune ADOPTION stays pointless — getEffectiveWeights
            // ignores adopted weights until the epoch-2 book reaches n≥100. BUT the
            // baseline backtest REPLAY must keep running: learnedGateAllows() consumes
            // it as the second gate-evidence path, and a stale replay froze that path
            // shut too (the deadlock). Decoupled: frozen → baseline replay refreshes
            // on its own 6h clock (KEY_BASELINE), sweep+adoption stay suspended.
            const frozen = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "calibration.frozen"
                }
            }).then((r)=>r ? JSON.parse(r.value).frozen : false).catch(()=>false);
            if (frozen) {
                const lastBase = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                    where: {
                        key: KEY_BASELINE
                    }
                }).then((r)=>r ? JSON.parse(r.value).at : null).catch(()=>null);
                if (lastBase && Date.now() - new Date(lastBase).getTime() < cfg.intervalHours * 3600_000) return;
                const baseline = await runBacktest({
                    label: "AUTO-BASELINE (FROZEN)",
                    persist: true
                });
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                    where: {
                        key: KEY_BASELINE
                    },
                    create: {
                        key: KEY_BASELINE,
                        value: JSON.stringify({
                            at: new Date().toISOString()
                        })
                    },
                    update: {
                        value: JSON.stringify({
                            at: new Date().toISOString()
                        })
                    }
                });
                await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, null, "ENGINE", "info", `AUTO-LEARNER (frozen, R6/G2): baseline replay refreshed — ${baseline.n} sim trades, objective ${baseline.objective}, WR ${baseline.winRate}% (LB ${baseline.wilsonLB?.toFixed(0) ?? "--"}%) — sweep + weight adoption stay SUSPENDED until n≥100; gate evidence stays live.`));
                return;
            }
            const { baseline, adopted, delta } = await runAutotune();
            await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, null, "ENGINE", "ai", `AUTO-LEARNER (6h cycle): replay ${baseline.n} sim trades — objective ${baseline.objective}; auto-tune ${adopted ? `ADOPTED improved weights (Δ+${delta})` : `kept baseline (best sweep Δ${delta >= 0 ? "+" : ""}${delta})`} — learned mean refreshed`));
        } catch (err) {
            console.error("[auto-learner]", err);
        } finally{
            autoInFlight = false;
        }
    })();
}
/** Learned gate: does past performance justify live auto-deployment?
 * v8.4.1 G1 (operator mandate 2026-09-11 «اقدامات بعدی رو کامل و مهندسی انجام بده»):
 * realized WR is now measured over the CURRENT ledger epoch (EPOCH-2 tags) with
 * a ROLLING window of the last 30 settles. The old cumulative all-time book
 * mixed pre-audit geometry (WR poison) into the gate and — combined with the
 * R6 freeze skipping autotune sweeps — deadlocked auto-deployment forever
 * (no deploys → WR can never rise → no deploys). The gate must judge the NEW
 * engine on the NEW book; old rows roll OUT of the window as new ones land. */ const LEARNED_GATE_WINDOW = 30;
const SETTLED_IN = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
async function learnedGateAllows() {
    const bt = await getBacktest();
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    ...SETTLED_IN
                ]
            },
            tags: {
                contains: "EPOCH-2"
            }
        },
        orderBy: {
            createdAt: "desc"
        },
        take: LEARNED_GATE_WINDOW,
        select: {
            pnlPercent: true
        }
    });
    const settled = rows.length;
    const wins = rows.filter((r)=>r.pnlPercent > 0).length;
    const realizedWr = settled >= 1 ? wins / settled * 100 : 0;
    if (settled >= 8 && realizedWr >= 25) return {
        allowed: true,
        reason: `realized WR ${realizedWr.toFixed(0)}% over ${settled} EPOCH-2 settles (rolling window ${LEARNED_GATE_WINDOW}) — above 25% floor`
    };
    if (bt && bt.n >= 20 && bt.wilsonLB >= 45 && bt.avgNetPct > 0) return {
        allowed: true,
        reason: `backtest learner: WR ${bt.winRate}% (Wilson-LB ${bt.wilsonLB}%, n=${bt.n}) — learned edge confirmed`
    };
    if (settled < 8 && (!bt || bt.n < 20)) return {
        allowed: false,
        reason: `insufficient evidence — ${settled}/8 EPOCH-2 settles, ${bt?.n ?? 0}/20 backtest trades`
    };
    return {
        allowed: false,
        reason: `learned performance below threshold — realized WR ${realizedWr.toFixed(0)}% (${settled} EPOCH-2 rolling), backtest LB ${bt?.wilsonLB.toFixed(0) ?? "--"}%`
    };
}
}),
"[project]/src/lib/tick-archive.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "flushTickArchive",
    ()=>flushTickArchive,
    "recordTick",
    ()=>recordTick
]);
// ── Task 79 TICK ARCHIVE — missing-data doctrine item ① (operator mandate
// 2026-10-05 «اقدامات لازم را کامل و مهندسی انجام بده») ──────────────────────
// The Task-78 audit proved 60s PricePoint sampling misclassified 15/102 BE
// cohorts and minted 19 phantom SLs (engine truth is a ~3.5s tick). Every
// price-distance filter is currently tuned on blurred prices. Cheapest fix:
// persist the tick stream ALREADY flowing through updatePrices().
//
// Two-tier engineered archive (disk-aware: 3.5GB free):
//   · tier-1 FULL RATE (~3.5s) — symbols with live exposure (ACTIVE/TP1/TP2
//     signals or open PumpTrack): full tick truth exactly where money moves.
//   · tier-2 16s — the rest of the universe (still 3× denser than PricePoint).
// Storage: compact `epochMs|symIdx|price` lines, hour-keyed files under
// .data/ticks/, 14-day retention + 150MB hard cap, dictionary-encoded symbols.
// NEVER throws into the engine tick loop — every path is fail-open.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const TICKS_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"](process.cwd(), ".data", "ticks");
const SYMBOLS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"](TICKS_DIR, "symbols.json");
const RETENTION_DAYS = 14;
const DIR_CAP_BYTES = 150 * 1024 * 1024;
const TIER2_MIN_MS = 16_000; // universe tier cadence
const ACTIVE_REFRESH_MS = 30_000;
const FLUSH_LINES = 1200;
let st = null;
function S() {
    if (st) return st;
    st = {
        buf: [],
        symIdx: new Map(),
        lastT2: new Map(),
        activeSyms: new Set(),
        activeAt: 0,
        activeLoading: false,
        curHour: Math.floor(Date.now() / 3_600_000)
    };
    try {
        __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"](TICKS_DIR, {
            recursive: true
        });
        const dict = JSON.parse(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"](SYMBOLS_FILE, "utf8"));
        dict.forEach((s, i)=>st.symIdx.set(s, i));
    } catch  {
    /* fresh dictionary */ }
    return st;
}
function symCode(sym) {
    const s = S();
    let i = s.symIdx.get(sym);
    if (i === undefined) {
        i = s.symIdx.size;
        s.symIdx.set(sym, i);
        try {
            const dict = [
                ...s.symIdx.keys()
            ];
            __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["writeFileSync"](SYMBOLS_FILE, JSON.stringify(dict));
        } catch  {
        /* dictionary re-persists on next flush */ }
    }
    return i;
}
function refreshActiveSymbols() {
    const s = S();
    if (s.activeLoading || Date.now() - s.activeAt < ACTIVE_REFRESH_MS) return;
    s.activeLoading = true;
    void (async ()=>{
        const [sigSyms, trackSyms] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
                where: {
                    status: {
                        in: [
                            "ACTIVE",
                            "TP1",
                            "TP2"
                        ]
                    }
                },
                select: {
                    symbol: true
                },
                distinct: [
                    "symbol"
                ]
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.findMany({
                where: {
                    phase: {
                        not: "RESOLVED"
                    }
                },
                select: {
                    symbol: true
                },
                distinct: [
                    "symbol"
                ]
            })
        ]);
        s.activeSyms = new Set([
            ...sigSyms.map((r)=>r.symbol),
            ...trackSyms.map((r)=>r.symbol)
        ]);
        s.activeAt = Date.now();
    })().catch(()=>undefined).finally(()=>{
        s.activeLoading = false;
    });
}
function flush(hour) {
    const s = S();
    if (!s.buf.length) return;
    const lines = s.buf;
    s.buf = [];
    try {
        __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["appendFileSync"](__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"](TICKS_DIR, `${hour}.jsonl`), lines.join("\n") + "\n");
    } catch  {
    /* archive is additive instrumentation — never fail the engine */ }
}
function cleanup() {
    try {
        const cutoff = Date.now() - RETENTION_DAYS * 86_400_000;
        const files = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readdirSync"](TICKS_DIR).filter((f)=>/^\d+\.jsonl$/.test(f)).map((f)=>({
                f,
                hour: Number(f.replace(".jsonl", "")),
                size: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["statSync"](__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"](TICKS_DIR, f)).size
            })).sort((a, b)=>a.hour - b.hour);
        let total = 0;
        for (const x of files){
            if (x.hour * 3_600_000 < cutoff) {
                __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["rmSync"](__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"](TICKS_DIR, x.f), {
                    force: true
                });
            } else {
                total += x.size;
            }
        }
        for (const x of files){
            if (total <= DIR_CAP_BYTES) break;
            if (x.hour * 3_600_000 >= cutoff) {
                __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["rmSync"](__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"](TICKS_DIR, x.f), {
                    force: true
                });
                total -= x.size;
            }
        }
    } catch  {
    /* fail-open */ }
}
function recordTick(symbol, price, atMs) {
    try {
        const s = S();
        refreshActiveSymbols();
        if (!s.activeSyms.has(symbol)) {
            const last = s.lastT2.get(symbol) ?? 0;
            if (atMs - last < TIER2_MIN_MS) return;
            s.lastT2.set(symbol, atMs);
        }
        s.buf.push(`${atMs}|${symCode(symbol)}|${price}`);
        const hour = Math.floor(atMs / 3_600_000);
        if (s.buf.length >= FLUSH_LINES || hour !== s.curHour) {
            flush(s.curHour);
            if (hour !== s.curHour) {
                s.curHour = hour;
                cleanup();
            }
        }
    } catch  {
    /* fail-open */ }
}
function flushTickArchive(nowMs = Date.now()) {
    try {
        const s = S();
        const hour = Math.floor(nowMs / 3_600_000);
        if (s.buf.length) flush(s.curHour);
        if (hour !== s.curHour) {
            s.curHour = hour;
            cleanup();
        }
    } catch  {
    /* fail-open */ }
}
}),
"[project]/src/lib/fill-ledger.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "recordFillLedger",
    ()=>recordFillLedger
]);
// ── Task 79 FILL LEDGER — missing-data doctrine item ② (operator mandate
// 2026-10-05) ─────────────────────────────────────────────────────────────────
// "Deflated edge $0.067/trade — unmeasured slippage could eat 15-75% of it.
// Cheapest: two extra columns on existing records." This module writes those
// columns at deploy time: the detection/scan reference price the chase gate
// anchored on, the actual entry, direction-adjusted adverse slippage in bps,
// and detection→deploy latency. One row per signal (unique).
// Fire-and-forget: a ledger failure can never block a deploy.
// P1-b ENTRY-DELAY TELEMETRY (audit 2026-10-25: 962/962 window rows were
// refSource='none', slipBps=0, latencyMs=NULL): the caller now labels the
// detection path explicitly (refSource) and the scan path feeds its REAL
// detection instant (frozen MTF snapshot `at`, FlowScan.updatedAt fallback)
// so latencyMs measures board→deploy lag instead of dying at NULL. slipBps
// math unchanged.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
function recordFillLedger(r) {
    void (async ()=>{
        const ref = r.refPrice && r.refPrice > 0 ? r.refPrice : r.entryPrice;
        const isLong = r.direction !== "SHORT";
        // adverse slippage, direction-adjusted: positive = paid WORSE than detection
        const slipBps = ref > 0 ? (r.entryPrice - ref) / ref * 10_000 * (isLong ? 1 : -1) : 0;
        // P1-b KPI: latencyMs = signal.createdAt − detectionInstant. Scan path =
        // board→deploy lag (the operator's standing entry-delay complaint, now
        // measured); radar path = track detection→deploy.
        const latencyMs = r.detectedAt ? Math.max(0, r.createdAtMs - r.detectedAt) : null;
        // P1-b: the explicit caller label wins; legacy heuristic keeps any old
        // caller (no refSource) honest.
        const refSource = r.refSource ?? (r.detectedAt ? "radar-anchor" : Math.abs(r.entryPrice - ref) < 1e-12 ? "none" : "scan");
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].fillLedger.upsert({
            where: {
                signalId: r.signalId
            },
            create: {
                signalId: r.signalId,
                symbol: r.symbol,
                engine: r.engine,
                direction: r.direction,
                refPrice: ref,
                entryPrice: r.entryPrice,
                slipBps: Number(slipBps.toFixed(2)),
                detectedAt: r.detectedAt ? new Date(r.detectedAt) : null,
                latencyMs,
                refSource
            },
            update: {}
        });
    })().catch(()=>undefined); // absolute fail-open — ledger never blocks trading
}
}),
"[project]/src/lib/multi-exchange.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getConsensusHealth",
    ()=>getConsensusHealth,
    "robustMedian",
    ()=>robustMedian,
    "sweepConsensus",
    ()=>sweepConsensus
]);
// ── FlowRadar Neo BINANCE MULTI-PLANE consensus (server-only) ──
// v14.0 BINANCE-ONLY RE-ARCHITECTURE (operator mandate trace 1a185042c872b4f9
// — «ردپای OKX/Bybit در کجا وجود دارد و با بایننس جایگزین شود»): the old
// cross-exchange median (Binance+OKX+Bybit+Hyperliquid+GATE) is replaced by
// FOUR Binance planes — ONE exchange, FOUR independent network paths — so the
// outlier defense (robustMedian) survives on pure Binance data:
//   ① BINANCE       — composite: rung 0 spot-ws prints (price-ws :3003 push
//                     file) → gated fapi batch → SPOT-POOL mirror ladder
//   ② BINANCE-SPOT  — the vision-primary spot-pool ladder (data-api.binance.
//                     vision → api-gcp → api1-4 → api), separate ban budget
//   ③ BINANCE-FUTWS — the futures bookTicker ring pushed by price-ws (:3003,
//                     per-symbol fstream WS) — REAL futures plane, zero REST
//                     weight, mid = (bid+ask)/2 from .data/futws-quotes.json
//   ④ BINANCE-GCP   — gcp-pinned spot ladder (api-gcp → api1-4 → api) — an
//                     independent host path from the vision-primary ladder
// A plane that errors degrades to "no quote for that plane" — never to sim;
// the terminal price stays live if ANY real plane responded.
// v10.24 Task 34-a: only the composite leg's fapi batch rides the fapi-gate
// (weight 40 full-universe ticker, critical lane); the spot ladders keep their
// own direct fetch + shared spot-host gate (v13.2.1).
// The v12.10 venue-expansion (GATE) and Task-49 HL allowlist are RETIRED here —
// the system is Binance-primary by mandate; PHANTOM-FEED outlier defense is now
// carried by robustMedian across the four Binance planes (v10.30 doctrine).
// v14.1 REAL SECOND EXCHANGE (operator mandate trace 1a18c926cd7742fd —
// «EXCHANGE CONSENSUS از چند صرافی تشکیل شده بود اما الان فقط یک صرافی وجود
// دارد. این کلیدها معتبر و فعال قابل استفاده هستن»): TOOBIT joins the consensus
// as venue ⑤ — a genuine second exchange, not another Binance path. Market data
// is PUBLIC (keys are only for account/execution): /quote/v1/contract/ticker/
// 24hr returns the FULL perp board (1038 contracts) in ONE call, mapped
// BTCUSDT → BTC-SWAP-USDT. Mid = (bid+ask)/2 when the book prints, else last.
// A symbol absent from Toobit stays honestly null; robustMedian treats venue ⑤
// symmetrically — a dislocated Toobit quote is REJECTED as an outlier exactly
// like a rogue Binance plane would be.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
;
;
;
const TIMEOUT_MS = 6500;
async function fetchWithTimeout(url, init) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
    try {
        return await fetch(url, {
            ...init,
            signal: ctrl.signal,
            cache: "no-store"
        });
    } finally{
        clearTimeout(timer);
    }
}
function median(values) {
    const sorted = [
        ...values
    ].sort((a, b)=>a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}
// ── v10.30 PHANTOM-FEED-0930 — robust median + outlier refusal ─────────────
// Rule: the median is trusted only while every quote is within 8% of it.
// Otherwise: if a CLEAR MAJORITY exists (strictly fewer deviants than
// agreements) reject the minority quotes and recompute; if two or more
// disagreeing clusters remain (no majority), return null — the engine then
// falls back to the real Binance fapi ticker instead of inventing a midpoint
// that no market ever printed. (QNT phantom-print doctrine, carried over.)
const ROBUST_DEV_PCT = 8;
function robustMedian(quotes) {
    const priced = quotes.filter((q)=>typeof q.price === "number" && q.price > 0);
    if (priced.length === 0) return {
        median: null,
        degraded: false
    };
    if (priced.length === 1) return {
        median: priced[0].price,
        degraded: false
    };
    const deviates = (p, ref)=>Math.abs(p - ref) / ref * 100 > ROBUST_DEV_PCT;
    let mdn = median(priced.map((q)=>q.price));
    const deviants = priced.filter((q)=>deviates(q.price, mdn));
    if (deviants.length === 0) return {
        median: mdn,
        degraded: false
    };
    if (deviants.length * 2 < priced.length) {
        // clear majority — reject the minority outliers and take the majority median
        for (const q of deviants)q.rejected = `outlier >${ROBUST_DEV_PCT}% vs majority median`;
        const kept = priced.filter((q)=>!q.rejected);
        mdn = median(kept.map((q)=>q.price));
        return {
            median: mdn,
            degraded: true
        };
    }
    // no majority (two clusters of comparable size) — refuse to invent a midpoint
    return {
        median: null,
        degraded: true
    };
}
// v10.16 (a) REAL Binance composite quote — rung 0 spot prints → batch
// /fapi/v1/ticker/24hr once per sweep (15s cache) → SPOT-POOL mirror on ban.
// v12.11 RUNG 0 — SPOT-PRINT FILE STORE: price-ws :3003 (the process that
// holds the SUSTAINED Binance spot WS plane) pushes lane-isolated spot prints
// every 3s; this file read costs zero REST weight. REST rungs fill only what
// it cannot price; futures-only microcaps stay honestly NULL.
// v14.0 — unchanged leg, now venue "BINANCE" of the four-plane consensus.
const SPOTWS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].resolve(".data/spotws-quotes.json");
const SPOTWS_FILE_MAX_AGE_MS = 12_000; // pushes every 3s — older means price-ws down
const SPOTWS_QUOTE_FRESH_MS = 90_000;
let binanceFutCache = null;
let spotwsFileCache = null;
let lastSpotwsLogAt = 0;
async function spotwsFileQuotes() {
    const now = Date.now();
    if (spotwsFileCache && now - spotwsFileCache.at < 3_000) return spotwsFileCache.data;
    const out = new Map();
    try {
        const raw = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(SPOTWS_FILE, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed.at && now - parsed.at <= SPOTWS_FILE_MAX_AGE_MS && Array.isArray(parsed.rows)) {
            for (const r of parsed.rows){
                const sym = String(r.s ?? "").toUpperCase();
                const p = Number(r.p);
                const t = Number(r.t);
                if (!sym.endsWith("USDT") || !(p > 0) || !(t > 0)) continue;
                out.set(sym, {
                    price: p,
                    at: t
                });
            }
        }
    } catch  {
    /* no file yet / unreadable — rung 0 skips honestly, REST rungs cover */ }
    spotwsFileCache = {
        at: now,
        data: out
    };
    return out;
}
async function binanceFuturesBatch(symbols) {
    const out = new Map();
    // RUNG 0 — live spot prints from the sustained Binance WS plane (pushed file)
    try {
        const spotws = await spotwsFileQuotes();
        const now = Date.now();
        for (const s of symbols){
            const q = spotws.get(s);
            if (q && now - q.at <= SPOTWS_QUOTE_FRESH_MS) out.set(s, q.price);
        }
    } catch  {
    /* rung never throws — REST rungs below are the safety net */ }
    if (symbols.length > 0 && out.size === symbols.length) {
        if (Date.now() - lastSpotwsLogAt > 600_000) {
            lastSpotwsLogAt = Date.now();
            console.log(`[multi-exchange] v14.0 BINANCE plane fully spotws-fed (${out.size}/${symbols.length} spot prints ≤90s) — zero Binance REST contact this sweep`);
        }
        return out;
    }
    const miss = symbols.filter((s)=>!out.has(s));
    if (binanceFutCache && Date.now() - binanceFutCache.at < CACHE_TTL) {
        for (const s of miss){
            const p = binanceFutCache.data.get(s);
            if (p) out.set(s, p);
        }
        return out;
    }
    // v10.24 Task 34-a: full-universe /fapi/v1/ticker/24hr — weight 40, gated.
    const json = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])("/fapi/v1/ticker/24hr", {
        priority: "critical",
        weight: 40,
        timeoutMs: TIMEOUT_MS
    });
    if (!json) {
        // v12.8 SPOT-POOL MIRROR rung: a banned fapi poll must not leave the
        // BINANCE venue null — the spot pool (separate ban budget) keeps the
        // reference venue priced (spot ≈ perp within bps on shared tickers);
        // futures-only tickers stay null (honest).
        const mirrored = await spotLadderBatch(symbols, SPOT_LADDER_VISION, "BINANCE-SPOT");
        if (mirrored.size > 0) {
            binanceFutCache = {
                at: Date.now(),
                data: mirrored
            };
            // v12.11 — fill ONLY the ring's misses: a 15s-old spot REST quote must
            // never overwrite a live aggTrade print (fresher wins, always).
            for (const s of miss){
                const p = mirrored.get(s);
                if (p) out.set(s, p);
            }
            if (Date.now() - lastSpotMirrorLogAt > 600_000) {
                lastSpotMirrorLogAt = Date.now();
                console.log(`[multi-exchange] v14.0 BINANCE plane fed by SPOT-POOL MIRROR (${mirrored.size} tickers) — fapi plane banned, spot pool alive`);
            }
        }
        return out;
    }
    const all = new Map();
    for (const row of json){
        const p = Number(row.lastPrice);
        if (Number.isFinite(p) && p > 0) all.set(row.symbol, p);
    }
    binanceFutCache = {
        at: Date.now(),
        data: all
    };
    for (const s of miss){
        const p = all.get(s);
        if (p) out.set(s, p);
    }
    return out;
}
// v14.0 — the two SPOT ladders as consensus planes. The vision-primary ladder
// (v13.3, shared with flow-bridge via the spot-host gate) is plane ②; the
// gcp-pinned ladder is plane ④ — an independent host path so a vision outage
// or a bad vision snapshot cannot take BOTH spot planes down at once.
const SPOT_LADDER_VISION = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
const SPOT_LADDER_GCP = [
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v14.0 — gcp-pinned independent path
const spotPlaneCache = new Map();
let lastSpotMirrorLogAt = 0;
async function spotLadderBatch(symbols, hosts, plane) {
    const hit = spotPlaneCache.get(plane);
    if (hit && Date.now() - hit.at < 60_000) return hit.data;
    const out = new Map();
    const ready = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotHostsReady"])(hosts);
    if (ready.length === 0) return hit?.data ?? out;
    // v14.2 CONSENSUS-STABILIZE (operator trace 1a1c1ecd9694a129, 2026-11-09): both REST
    // spot planes (BINANCE-SPOT / BINANCE-GCP) sat at 32/32 NULL — every sweep pulled the
    // FULL spot board (weight 200 × 2 planes on a 15s sweep cache) and the hosts answered
    // 418/429 with long retry-after windows, so the EXCHANGE CONSENSUS card showed dead
    // venues even while the WS planes were healthy (spotws file 439 fresh prints, TOOBIT ok).
    // Fix: request ONLY the sweep's symbols via the ?symbols= filter — weight 4 (≤100
    // symbols) instead of 200, a 50× weight cut with identical data for the consensus
    // universe. Safety: symbols NOT proven spot-traded are excluded, because Binance
    // rejects the WHOLE request with -1121 when any symbol is unknown (futures-only
    // microcaps); the spotws print file — real Binance spot symbols pushed by price-ws
    // :3003 — is the honest membership oracle. If the oracle is unreachable (price-ws
    // down → empty file), fall back to the legacy full-board pull (old behavior).
    const spotws = await spotwsFileQuotes().catch(()=>new Map());
    const wanted = spotws.size > 0 ? symbols.filter((s)=>spotws.has(s)).slice(0, 100) : [];
    const symQ = wanted.length > 0 ? `?symbols=${encodeURIComponent(JSON.stringify(wanted))}` : "";
    for (const host of ready){
        const t0 = Date.now();
        try {
            const ctrl = new AbortController();
            const t = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${host}/api/v3/ticker/24hr${symQ}`, {
                signal: ctrl.signal,
                cache: "no-store",
                headers: {
                    Connection: "close"
                }
            });
            clearTimeout(t);
            if (res.status === 418 || res.status === 429) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["noteSpotHostThrottle"])(host, res.status, res.headers);
                continue; // gate armed — next rung serves until expiry
            }
            if (!res.ok) continue;
            const rows = await res.json();
            for (const r of rows){
                const p = Number(r.lastPrice);
                if (Number.isFinite(p) && p > 0) out.set(r.symbol, p);
            }
            spotPlaneCache.set(plane, {
                at: Date.now(),
                data: out
            });
            if (out.size > 0 && Date.now() - lastSpotMirrorLogAt > 600_000) {
                lastSpotMirrorLogAt = Date.now();
                console.log(`[multi-exchange] v14.0 ${plane} plane fed by ${host.replace("https://", "")} (${out.size} tickers, ${Date.now() - t0}ms)`);
            }
            return out;
        } catch  {
            continue; // next rung — honest nulls downstream if all fail
        }
    }
    return out;
}
// v14.0 — BINANCE-FUTWS plane: the per-symbol futures bookTicker ring pushed
// by price-ws :3003 (.data/futws-quotes.json). Real Binance futures mids with
// ZERO REST weight; the ring is the v13.5 fstream per-symbol design that is
// live-proven from this egress (market-wide !arr streams are muted here, but
// per-symbol bookTicker streams sustain).
const FUTWS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].resolve(".data/futws-quotes.json");
const FUTWS_FILE_MAX_AGE_MS = 15_000; // ring pushes continuously — older means the ring is down
const FUTWS_QUOTE_FRESH_MS = 90_000;
let futwsFileCache = null;
let lastFutwsLogAt = 0;
async function futwsRingQuotes() {
    const now = Date.now();
    if (futwsFileCache && now - futwsFileCache.at < 3_000) return futwsFileCache.data;
    const out = new Map();
    try {
        const raw = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(FUTWS_FILE, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed.at && now - parsed.at <= FUTWS_FILE_MAX_AGE_MS && Array.isArray(parsed.rows)) {
            for (const r of parsed.rows){
                const sym = String(r.s ?? "").toUpperCase();
                const m = Number(r.m);
                const t = Number(r.t);
                if (!sym.endsWith("USDT") || !(m > 0) || !(t > 0) || now - t > FUTWS_QUOTE_FRESH_MS) continue;
                out.set(sym, m);
            }
        }
    } catch  {
    /* ring file absent — plane skips honestly */ }
    if (out.size > 0 && Date.now() - lastFutwsLogAt > 600_000) {
        lastFutwsLogAt = Date.now();
        console.log(`[multi-exchange] v14.0 BINANCE-FUTWS plane fed by the futures bookTicker ring (${out.size} mids, zero REST weight)`);
    }
    futwsFileCache = {
        at: now,
        data: out
    };
    return out;
}
// v14.1 — TOOBIT plane (venue ⑤): public perp board, one call, zero keys.
const TOOBIT_QUOTE_URL = "https://api.toobit.com/quote/v1/contract/ticker/24hr";
const TOOBIT_SWAP_SUFFIX = "-SWAP-USDT";
let toobitBatchCache = null;
let lastToobitLogAt = 0;
async function toobitContractBatch() {
    const now = Date.now();
    if (toobitBatchCache && now - toobitBatchCache.at < CACHE_TTL) return toobitBatchCache.data;
    const out = new Map();
    try {
        const ctrl = new AbortController();
        const t = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
        const res = await fetch(TOOBIT_QUOTE_URL, {
            signal: ctrl.signal,
            cache: "no-store",
            headers: {
                Connection: "close"
            }
        });
        clearTimeout(t);
        if (res.ok) {
            const rows = await res.json();
            for (const r of rows){
                const tb = String(r.s ?? "").toUpperCase();
                if (!tb.endsWith(TOOBIT_SWAP_SUFFIX)) continue;
                const bid = Number(r.b), ask = Number(r.a), last = Number(r.c);
                const mid = bid > 0 && ask > 0 ? (bid + ask) / 2 : last;
                if (!(mid > 0)) continue;
                out.set(`${tb.slice(0, tb.length - TOOBIT_SWAP_SUFFIX.length)}USDT`, mid);
            }
            toobitBatchCache = {
                at: now,
                data: out
            };
            if (out.size > 0 && Date.now() - lastToobitLogAt > 600_000) {
                lastToobitLogAt = Date.now();
                console.log(`[multi-exchange] v14.1 TOOBIT plane fed by the public contract board (${out.size} perp mids, zero keys, one call)`);
            }
        }
    } catch  {
    /* plane skips honestly — absent venue, never invented data */ }
    return out;
}
// cached sweep (15s TTL, in-flight dedupe)
const CACHE_TTL = 15_000;
let cache = null;
let inFlight = null;
// v10.16 (e) per-venue health — lastOkAt stamped on every successful batch
// contribution inside sweepConsensus; a venue is ok ONLY while its last
// success is ≤90s old (cache existence alone no longer counts).
const venueLastOkAt = new Map();
const VENUE_OK_WINDOW_MS = 90_000;
async function sweepConsensus(symbols) {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.data;
    if (inFlight) return inFlight;
    inFlight = (async ()=>{
        // v14.0 — four Binance planes (see header). Order matters only for the
        // quotes array; robustMedian treats them symmetrically.
        // v14.1 — venue ⑤ TOOBIT: the REAL second exchange joins the consensus.
        const [composite, spot, futws, gcp, toobit] = await Promise.allSettled([
            binanceFuturesBatch(symbols),
            spotLadderBatch(symbols, SPOT_LADDER_VISION, "BINANCE-SPOT"),
            futwsRingQuotes(),
            spotLadderBatch(symbols, SPOT_LADDER_GCP, "BINANCE-GCP"),
            toobitContractBatch()
        ]);
        const compositeMap = composite.status === "fulfilled" ? composite.value : new Map();
        const spotMap = spot.status === "fulfilled" ? spot.value : new Map();
        const futwsMap = futws.status === "fulfilled" ? futws.value : new Map();
        const gcpMap = gcp.status === "fulfilled" ? gcp.value : new Map();
        const toobitMap = toobit.status === "fulfilled" ? toobit.value : new Map();
        const binanceStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFeedStatus"])();
        const now = Date.now();
        if (compositeMap.size > 0) venueLastOkAt.set("BINANCE", now);
        if (spotMap.size > 0) venueLastOkAt.set("BINANCE-SPOT", now);
        if (futwsMap.size > 0) venueLastOkAt.set("BINANCE-FUTWS", now);
        if (gcpMap.size > 0) venueLastOkAt.set("BINANCE-GCP", now);
        if (toobitMap.size > 0) venueLastOkAt.set("TOOBIT", now);
        const out = new Map();
        for (const sym of symbols){
            const quotes = [
                {
                    venue: "BINANCE",
                    price: compositeMap.get(sym) ?? null,
                    latencyMs: binanceStatus.latencyMs,
                    ok: compositeMap.has(sym)
                },
                {
                    venue: "BINANCE-SPOT",
                    price: spotMap.get(sym) ?? null,
                    latencyMs: null,
                    ok: spotMap.has(sym)
                },
                {
                    venue: "BINANCE-FUTWS",
                    price: futwsMap.get(sym) ?? null,
                    latencyMs: null,
                    ok: futwsMap.has(sym)
                },
                {
                    venue: "BINANCE-GCP",
                    price: gcpMap.get(sym) ?? null,
                    latencyMs: null,
                    ok: gcpMap.has(sym)
                },
                {
                    venue: "TOOBIT",
                    price: toobitMap.get(sym) ?? null,
                    latencyMs: null,
                    ok: toobitMap.has(sym)
                }
            ];
            const prices = quotes.map((q)=>q.price).filter((p)=>typeof p === "number" && p > 0);
            // v10.30: robust median — rejects outlier planes, refuses impossible midpoints
            const rm = robustMedian(quotes);
            const mdn = rm.median;
            const maxDevBps = mdn && prices.length >= 2 ? Math.max(...prices.map((p)=>Math.abs(p - mdn) / mdn * 10_000)) : 0;
            out.set(sym, {
                symbol: sym,
                median: mdn,
                quotes,
                maxDevBps: Number(maxDevBps.toFixed(2)),
                venuesOk: prices.length,
                sweptAt: now,
                degraded: rm.degraded
            });
        }
        cache = {
            at: Date.now(),
            data: out
        };
        return out;
    })();
    try {
        return await inFlight;
    } finally{
        inFlight = null;
    }
}
function getConsensusHealth() {
    // v10.16 (e) ok = a real per-venue quote contribution within the last 90s —
    // "a cache exists somewhere" no longer marks a silent venue healthy.
    const fresh = (venue)=>Date.now() - (venueLastOkAt.get(venue) ?? 0) <= VENUE_OK_WINDOW_MS;
    return [
        {
            venue: "BINANCE",
            ok: fresh("BINANCE"),
            latencyMs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFeedStatus"])().latencyMs
        },
        {
            venue: "BINANCE-SPOT",
            ok: fresh("BINANCE-SPOT"),
            latencyMs: null
        },
        {
            venue: "BINANCE-FUTWS",
            ok: fresh("BINANCE-FUTWS"),
            latencyMs: null
        },
        {
            venue: "BINANCE-GCP",
            ok: fresh("BINANCE-GCP"),
            latencyMs: null
        },
        {
            venue: "TOOBIT",
            ok: fresh("TOOBIT"),
            latencyMs: null
        }
    ];
}
}),
"[project]/src/lib/pump-dump.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PUMP_RULES",
    ()=>PUMP_RULES,
    "RADAR_LANE_DEFAULTS",
    ()=>RADAR_LANE_DEFAULTS,
    "gatherEvidence",
    ()=>gatherEvidence,
    "getPumpAuthority",
    ()=>getPumpAuthority,
    "getPumpEngineStatus",
    ()=>getPumpEngineStatus,
    "pumpGateAllows",
    ()=>pumpGateAllows,
    "pumpScreen",
    ()=>pumpScreen,
    "pumpTick",
    ()=>pumpTick,
    "setPumpAuthority",
    ()=>setPumpAuthority
]);
// ── v9.0 PUMP/DUMP RADAR — independent flow-tracking engine ──────────────
// Operator mandate 2026-09-12: «تحقیق و جستجوی عمیق ممیزی برای نحوه شناسایی
// و ردیابی جریانات پامپی و دامپی انجام بده، یک ماژول و موتور مستقل کامل و
// هوشمند براش بساز و تا زمانی که ۵ ردیابی موفق نداشته اجازه ارسال سیگنال
// ندارد، بعد از تایید میتواند سیگنال هایی با کارت اختصاصی pump با dump
// داشته باشد»
//
// RESEARCH SUMMARY (codebase audit + market microstructure literature):
//  · Pump/dump flows leave a measurable fingerprint chain: (1) velocity —
//    unlevered 1m/5m price displacement far above the symbol's own baseline;
//    (2) volume ignition — 1m quote-volume bursts ≥3× the rolling median;
//    (3) derivatives confirmation — OI delta (new money vs deleveraging
//    squeeze), CVD net-taker USD, taker buy/sell ratio, whale prints, and
//    forced-liquidation fuel (shorts liquidated fuel pumps, longs fuel dumps).
//  · The existing stack already measures every ingredient separately
//    (flow.ts, liquidations.ts, volOnset.ts, trigger bus L1/L3) but never
//    chained them into a pump/dump classifier with accountable tracking.
//
// ARCHITECTURE (independent module — zero coupling into scoring/gates):
//  STAGE 1 (every tick, in-memory): per-symbol tape of (t, price, quoteVol).
//    Computes vel1m/vel5m + 1m quote-volume burst vs the symbol's own median.
//  STAGE 2 (candidate only, 45s/symbol throttle): fetchFlowMetrics +
//    liquidationPressure → evidence-weighted conviction score 0..100.
//  DECLARE (score ≥ 62): PumpTrack row + the success criterion FIXED at
//    declaration (+2.0% unlevered MFE from anchor within 90min) — honest,
//    no post-hoc re-scoring. Event mirrors to Telegram (PUMP_RADAR).
//  TRACK (15s/track): MFE/MAE + phase machine ONSET→EXTENSION→EXHAUSTION;
//    resolves SUCCESS on criterion hit, FAILURE at horizon/collapse.
// v10.16 (deep-audit 3-a P1 pump-leak fix, task 4-c): the stage-1 tape IGNORES
//    sim-source prices (random-walk drift must never create fake velocity),
//    and updateTrack resolves a track whose symbol has no live price by the
//    CLOCK at the same 90min horizon — outcome EXPIRED / phase RESOLVED /
//    note "clock-expired: no live price (v10.16)" — instead of freezing
//    forever when a symbol leaves the universe or the feed degrades
//    (GENIUSUSDT stuck in EXHAUSTION for 22h).
//  LEARNING GATE: signals FORBIDDEN until ≥5 tracks resolved SUCCESS
//    (operator's exact number). After unlock, fresh ONSET tracks with
//    score ≥ 78 propose deploys through deploySignal's FULL normal gate
//    stack — the radar only nominates, the engine still judges. Signals
//    carry the dedicated PUMP/DUMP card cohort tags.
//
// v9.2 UNFILTERED DIRECT EMISSION (operator mandate 2026-09-13 20:06Z:
// «من شرط ورود مستقیم رو دادم، بررسی کن و بدون هیچ فیلتری سیگنال را صادر کن»)
//  · Diagnosis: authority=direct was BANKED but v9.1 still filtered through
//    the radar's own 78-conviction deploy floor + 20min spacing + max-2-open
//    — of 17 declared tracks only 2 ever spawned a card (LSK 72 / VTHO 76
//    vetoed hours after the operator granted direct authority).
//  · Fix: authority="direct" → EVERY declared track (score ≥ 62 declare
//    floor = the detection itself) emits its dedicated card 1:1, immediately.
//    Learning gate, 78 floor, spacing and max-open are ALL bypassed.
//  · What stays HARD: deploySignal's honesty rails (feed-fresh guard,
//    sim-price ban) — a pump/dump card must never be born from stale or
//    invented prices (operator's own honesty doctrine). One card per track
//    (spawnedSignal flag) and the 45min per-symbol redeclare cooldown keep
//    the 1:1 detection→card mapping honest, not filtered.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
;
;
;
const PUMP_RULES = {
    tapeWindowMs: 30 * 60_000,
    vel1mMinPct: 0.35,
    vel5mMinPct: 1.1,
    volBurstMinX: 3,
    volFloorUsd1m: 30_000,
    warmPoints: 55,
    scoreDeclare: 62,
    scoreDeploy: 78,
    confirmTtlMs: 45_000,
    horizonMin: 90,
    successMovePct: 2.0,
    collapseMaePct: 4.0,
    extendPct: 1.2,
    exhaustRetraceFrac: 0.5,
    redeCooldownMs: 45 * 60_000,
    activeCap: 12,
    signalSpacingMs: 20 * 60_000,
    signalMaxActive: 2,
    requiredSuccesses: 5,
    trackUpdateMs: 15_000
};
const RADAR_LANE_DEFAULTS = {
    enabled: true,
    dailyCap: 4,
    probationN: 30
};
async function getRadarLaneCfg() {
    const cfg = {
        ...RADAR_LANE_DEFAULTS
    };
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "radar-lane"
            }
        });
        if (row) {
            const p = JSON.parse(row.value);
            if (p.enabled === false) cfg.enabled = false;
            if (typeof p.dailyCap === "number") cfg.dailyCap = Math.max(0, Math.min(20, Math.floor(p.dailyCap)));
            if (typeof p.probationN === "number") cfg.probationN = Math.max(10, Math.min(200, Math.floor(p.probationN)));
        }
    } catch  {}
    return cfg;
}
/** Auto-demote: settled R6-LANE cohort fails probation → lane self-disables.
 *  Mirrors the v10.18 retirement doctrine — modes die on evidence, not opinion. */ async function radarLaneProbationCheck(cfg) {
    try {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                tags: {
                    contains: "R6-LANE"
                }
            },
            select: {
                status: true,
                reachedTp: true,
                pnlPercent: true,
                marginUsd: true,
                closedAt: true
            }
        });
        const settled = rows.filter((r)=>r.closedAt);
        if (settled.length < cfg.probationN) return {
            ok: true,
            note: `probation pending — ${settled.length}/${cfg.probationN} settled`
        };
        const wins = settled.filter((r)=>r.reachedTp >= 1 || [
                "TP1",
                "TP2",
                "TP3"
            ].includes(r.status)).length;
        const wr = wins / settled.length * 100;
        const avgPnl = settled.reduce((a, r)=>a + r.pnlPercent, 0) / settled.length;
        // baseline = non-lane settled book over the same window (approx: all-time
        // tp-proven book minus lane rows — the v10.18 endpoint's cohort logic)
        const all = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                closedAt: {
                    not: null
                }
            },
            select: {
                tags: true,
                reachedTp: true,
                status: true
            }
        });
        const nonLane = all.filter((r)=>!(r.tags ?? "").includes("R6-LANE"));
        const nlWins = nonLane.filter((r)=>r.reachedTp >= 1 || [
                "TP1",
                "TP2",
                "TP3"
            ].includes(r.status)).length;
        const baselineWr = nonLane.length ? nlWins / nonLane.length * 100 : 0;
        if (wr < baselineWr || avgPnl <= 0) {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: "radar-lane"
                },
                create: {
                    key: "radar-lane",
                    value: JSON.stringify({
                        ...cfg,
                        enabled: false,
                        demotedAt: new Date().toISOString(),
                        demoteReason: `probation fail n=${settled.length} WR ${wr.toFixed(1)}% vs baseline ${baselineWr.toFixed(1)}% avgPnl ${avgPnl.toFixed(2)}%`
                    })
                },
                update: {
                    value: JSON.stringify({
                        ...cfg,
                        enabled: false,
                        demotedAt: new Date().toISOString(),
                        demoteReason: `probation fail n=${settled.length} WR ${wr.toFixed(1)}% vs baseline ${baselineWr.toFixed(1)}% avgPnl ${avgPnl.toFixed(2)}%`
                    })
                }
            }).catch(()=>undefined);
            return {
                ok: false,
                note: `AUTO-DEMOTED — n=${settled.length} WR ${wr.toFixed(1)}% < baseline ${baselineWr.toFixed(1)}% or avgPnl ${avgPnl.toFixed(2)}% ≤ 0 (v10.18 probation doctrine)`
            };
        }
        return {
            ok: true,
            note: `probation PASS — n=${settled.length} WR ${wr.toFixed(1)}% vs baseline ${baselineWr.toFixed(1)}%, avgPnl ${avgPnl.toFixed(2)}%`
        };
    } catch  {
        return {
            ok: true,
            note: "probation check failed-open"
        };
    }
}
// lane daily counter (memory; UTC-day keyed — restart resets to a conservative 0,
// DB recount below re-arms it after every boot)
const laneDay = {
    key: "",
    count: 0
};
const tape = new Map();
const volSamples = new Map(); // 1m quote-vol deltas
const lastConfirmAt = new Map(); // stage-2 throttle
const lastResolveAt = new Map(); // re-declaration cooldown
const lastSignalAt = {
    v: 0
}; // global radar-signal spacing
// ── v11.1 NOMINATION FUNNEL COUNTERS (operator: «چرا ردیابی‌ها تبدیل به سیگنال نمی‌شود؟») ──
// Every silent drop in the nomination funnel is now counted and surfaced in
// the pump status block (/api/pulse → pump.nomination). Before v11.1 the
// spacing/maxActive floors dropped candidates with NO event and NO counter —
// DB audit (2026-10-04): gated-era 457 tracks → 208 SUCCESS, but only 45 ever
// passed the one-shot 78 deploy floor (163 SUCCESS tracks permanently missed).
const nomStats = {
    declared: 0,
    learningHeld: 0,
    belowDeployFloor: 0,
    spacingDrop: 0,
    maxActiveDrop: 0,
    nominated: 0,
    deployed: 0,
    engineVetoed: 0,
    successResolutions: 0,
    renomSkippedHasCard: 0,
    renomAttempts: 0,
    renomDeployed: 0,
    renomSpacingDrop: 0,
    renomMaxActiveDrop: 0,
    // v12.1 R6 RADAR LANE counters
    laneAttempts: 0,
    laneCapDrop: 0,
    laneProbationNote: "",
    laneDeployed: 0,
    laneVetoed: 0
};
let openTracks = new Map(); // symbol → live track
let lastTrackSweepAt = 0;
let lastSyncAt = 0; // DB reconcile cursor — heals multi-bundle/restart divergence
let lastLaneProbationAt = 0; // v12.1 lane probation check throttle (10min)
let memo = null;
let booted = false;
const median = (xs)=>{
    if (!xs.length) return 0;
    const s = [
        ...xs
    ].sort((a, b)=>a - b);
    return s[Math.floor(s.length / 2)];
};
function pumpScreen(assets) {
    const now = Date.now();
    const out = [];
    for (const a of assets){
        if (!a.price || a.price <= 0) continue;
        // v10.16 P1 PUMP-LEAK — never ingest sim-source prices into the tape: the
        // random-walk drift fallback would fabricate velocity/volume bursts and
        // declare pump tracks from invented prices.
        if (a.source === "sim") continue;
        let ring = tape.get(a.symbol);
        if (!ring) {
            ring = [];
            tape.set(a.symbol, ring);
        }
        ring.push({
            t: now,
            p: a.price,
            qv: a.volume24h
        });
        while(ring.length && now - ring[0].t > PUMP_RULES.tapeWindowMs)ring.shift();
        // 1m quote-volume delta samples (minute-bucketed) for the burst baseline
        let vs = volSamples.get(a.symbol);
        if (!vs) {
            vs = [];
            volSamples.set(a.symbol, vs);
        }
        const lastS = vs[vs.length - 1];
        if (!lastS || now - lastS.t >= 55_000) {
            const ref = ring.find((pt)=>now - pt.t <= 65_000) ?? ring[0];
            const dv = Math.max(0, a.volume24h - ref.qv);
            vs.push({
                t: now,
                dv
            });
            while(vs.length > 32)vs.shift();
        }
        if (ring.length < PUMP_RULES.warmPoints) continue; // honest warmup after restart
        const at = (ms)=>{
            let best = null;
            let bestDev = Number.POSITIVE_INFINITY;
            for (const pt of ring){
                const dev = Math.abs(pt.t - (now - ms));
                if (dev < bestDev) {
                    bestDev = dev;
                    best = pt;
                }
            }
            return bestDev <= 15_000 ? best : null;
        };
        const p1 = at(60_000);
        const p5 = at(300_000);
        if (!p1 || !p5) continue;
        const vel1m = (a.price - p1.p) / p1.p * 100;
        const vel5m = (a.price - p5.p) / p5.p * 100;
        const dvNow = Math.max(0, a.volume24h - p1.qv);
        const base = median(vs.map((s)=>s.dv).slice(0, -1));
        const burstX = base >= 1_000 ? dvNow / base : 0;
        if (dvNow < PUMP_RULES.volFloorUsd1m) continue;
        const kind = vel5m > 0 ? "PUMP" : "DUMP";
        const av1 = Math.abs(vel1m);
        const av5 = Math.abs(vel5m);
        if (av5 < PUMP_RULES.vel5mMinPct || av1 < PUMP_RULES.vel1mMinPct || burstX < PUMP_RULES.volBurstMinX) continue;
        if (openTracks.has(a.symbol)) continue;
        if (now - (lastResolveAt.get(a.symbol) ?? 0) < PUMP_RULES.redeCooldownMs) continue;
        out.push({
            symbol: a.symbol,
            kind,
            vel1m,
            vel5m,
            burstX,
            price: a.price
        });
    }
    // strongest first (5m displacement × burst)
    return out.sort((a, b)=>Math.abs(b.vel5m) * b.burstX - Math.abs(a.vel5m) * a.burstX).slice(0, 3);
}
async function gatherEvidence(c) {
    const sign = c.kind === "PUMP" ? 1 : -1;
    let score = 0;
    // velocity core (≤45)
    score += Math.min(27, Math.abs(c.vel5m) / PUMP_RULES.vel5mMinPct * 12);
    score += Math.min(18, Math.abs(c.vel1m) / PUMP_RULES.vel1mMinPct * 9);
    // volume burst (≤15)
    score += Math.min(15, c.burstX / PUMP_RULES.volBurstMinX * 8);
    const ev = {
        oiDelta10m: null,
        cvdUsd60s: null,
        takerRatio: null,
        funding8h: null,
        whaleUsd5m: null,
        whaleSideAligned: false,
        liqUsd10m: null,
        liqSideAligned: false
    };
    try {
        const [flow, liq] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFlowMetrics"])(c.symbol),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["liquidationPressure"])(c.symbol)
        ]);
        if (flow) {
            ev.oiDelta10m = flow.oiDelta10m;
            ev.cvdUsd60s = flow.cvdUsd60s;
            ev.takerRatio = flow.takerRatio;
            ev.funding8h = flow.funding8h;
            if (flow.oiDelta10m !== null) {
                // OI rising WITH the move = fresh money (strongest); falling = deleveraging squeeze (real, weaker)
                if (flow.oiDelta10m * sign > 0) score += 12;
                else if (flow.oiDelta10m < 0) score += 6;
            }
            if (flow.cvdUsd60s !== null && flow.cvdUsd60s * sign > 0) {
                score += flow.cvdUsd60s * sign >= 200_000 ? 15 : 12;
            }
            if (flow.takerRatio !== null && flow.takerRatio * sign > 1) score += flow.takerRatio * sign >= 1.15 ? 8 : 5;
            if (flow.whalePrint5m && flow.whalePrint5m.totalUsd >= 250_000) {
                ev.whaleUsd5m = flow.whalePrint5m.totalUsd;
                ev.whaleSideAligned = flow.whalePrint5m.buyUsd >= flow.whalePrint5m.sellUsd ? sign > 0 : sign < 0;
                if (ev.whaleSideAligned) score += 8;
            }
            // funding tailwind: not already paying the crowd to be on our side's neck
            if (flow.funding8h !== null && flow.funding8h * sign <= 0.02) score += 4;
        }
        if (liq) {
            ev.liqUsd10m = liq.usd10m;
            // forced-liquidation fuel: shorts liquidated → pump fuel; longs → dump fuel
            const fuel = sign > 0 ? liq.shortsUsd10m : liq.longsUsd10m;
            ev.liqSideAligned = fuel >= 100_000;
            if (ev.liqSideAligned) score += 6;
        }
    } catch  {
    /* evidence unavailable — velocity/volume core still stands, honest score */ }
    return {
        score: Math.min(100, Math.round(score)),
        ev
    };
}
// ── module lifecycle ─────────────────────────────────────────────────────
async function ensureBooted() {
    if (booted) return;
    booted = true;
    try {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.findMany({
            where: {
                phase: {
                    not: "RESOLVED"
                }
            }
        });
        openTracks = new Map(rows.map((r)=>[
                r.symbol,
                {
                    id: r.id,
                    symbol: r.symbol,
                    kind: r.kind,
                    phase: r.phase,
                    anchor: r.anchorPrice,
                    peak: r.peakPrice,
                    mfe: r.mfePct,
                    mae: r.maePct,
                    score: r.score,
                    detectedAt: r.detectedAt.getTime(),
                    lastWriteAt: 0,
                    spawnedSignal: !!r.signalId
                }
            ]));
    } catch  {
    /* first boot — empty */ }
}
const fmtEvidence = (ev)=>{
    const parts = [];
    if (ev.oiDelta10m !== null) parts.push(`OI ${ev.oiDelta10m >= 0 ? "+" : ""}${ev.oiDelta10m.toFixed(2)}%/10m`);
    if (ev.cvdUsd60s !== null) parts.push(`CVD ${ev.cvdUsd60s >= 0 ? "+" : ""}$${Math.round(Math.abs(ev.cvdUsd60s) / 1000)}K/60s`);
    if (ev.takerRatio !== null) parts.push(`taker ${ev.takerRatio.toFixed(2)}`);
    if (ev.whaleSideAligned) parts.push(`whale $${Math.round((ev.whaleUsd5m ?? 0) / 1000)}K/5m`);
    if (ev.liqSideAligned) parts.push(`liq-fuel $${Math.round((ev.liqUsd10m ?? 0) / 1000)}K/10m`);
    return parts.join(" · ");
};
/** Reconcile in-memory open tracks with the DB (1/min — heal for restarts
 *  and Next dev's per-route module bundles: a track created in one instance
 *  must be tracked by every instance that runs the tick). */ async function syncOpenTracks(now) {
    if (now - lastSyncAt < 60_000) return;
    lastSyncAt = now;
    try {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.findMany({
            where: {
                phase: {
                    not: "RESOLVED"
                }
            }
        });
        const rowIds = new Set(rows.map((r)=>r.id));
        for (const [sym, t] of [
            ...openTracks.entries()
        ]){
            if (!rowIds.has(t.id)) openTracks.delete(sym); // resolved elsewhere
        }
        for (const r of rows){
            if (openTracks.has(r.symbol)) continue; // memory copy is fresher
            openTracks.set(r.symbol, {
                id: r.id,
                symbol: r.symbol,
                kind: r.kind,
                phase: r.phase,
                anchor: r.anchorPrice,
                peak: r.peakPrice,
                mfe: r.mfePct,
                mae: r.maePct,
                score: r.score,
                detectedAt: r.detectedAt.getTime(),
                lastWriteAt: 0,
                spawnedSignal: !!r.signalId
            });
        }
    } catch  {
    /* reconcile is best-effort */ }
}
async function pumpTick(assets) {
    await ensureBooted();
    const now = Date.now();
    // 0) reconcile memory ↔ DB (1/min)
    await syncOpenTracks(now);
    // 1) track maintenance first — MFE/MAE + phase machine + resolution.
    // v10.16: tracks whose symbol has NO price row (left the universe) are no
    // longer silently skipped forever — updateTrack clock-expires them.
    if (now - lastTrackSweepAt >= 5_000 && openTracks.size > 0) {
        lastTrackSweepAt = now;
        const priceMap = new Map(assets.map((a)=>[
                a.symbol,
                a.price
            ]));
        const srcMap = new Map(assets.map((a)=>[
                a.symbol,
                a.source ?? "live"
            ]));
        for (const t of [
            ...openTracks.values()
        ]){
            await updateTrack(t, priceMap.get(t.symbol) ?? null, srcMap.get(t.symbol) ?? null, now);
        }
    }
    // 2) stage-1 screen
    if (openTracks.size >= PUMP_RULES.activeCap) return;
    const cands = pumpScreen(assets);
    if (!cands.length) return;
    // 3) stage-2 confirm + declare
    for (const c of cands){
        if (openTracks.has(c.symbol)) continue;
        const lc = lastConfirmAt.get(c.symbol) ?? 0;
        if (now - lc < PUMP_RULES.confirmTtlMs) continue;
        lastConfirmAt.set(c.symbol, now);
        const { score, ev } = await gatherEvidence(c);
        if (score < PUMP_RULES.scoreDeclare) continue;
        await declareTrack(c, score, ev, now);
    }
}
async function declareTrack(c, score, ev, now) {
    nomStats.declared++;
    const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.create({
        data: {
            symbol: c.symbol,
            kind: c.kind,
            phase: "ONSET",
            anchorPrice: c.price,
            peakPrice: c.price,
            vel1mPct: Number(c.vel1m.toFixed(3)),
            vel5mPct: Number(c.vel5m.toFixed(3)),
            volBurstX: Number(c.burstX.toFixed(2)),
            oiDelta10m: ev.oiDelta10m,
            cvdUsd60s: ev.cvdUsd60s,
            takerRatio: ev.takerRatio,
            funding8h: ev.funding8h,
            whaleUsd5m: ev.whaleUsd5m,
            liqUsd10m: ev.liqUsd10m,
            score,
            metricsJson: JSON.stringify({
                ev,
                rules: {
                    successMovePct: PUMP_RULES.successMovePct,
                    horizonMin: PUMP_RULES.horizonMin
                }
            })
        }
    });
    openTracks.set(c.symbol, {
        id: row.id,
        symbol: c.symbol,
        kind: c.kind,
        phase: "ONSET",
        anchor: c.price,
        peak: c.price,
        mfe: 0,
        mae: 0,
        score,
        detectedAt: now,
        lastWriteAt: 0,
        spawnedSignal: false
    });
    const engine = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    await engine.fireEvent(null, c.symbol, "PUMP_RADAR", "ai", `${c.kind} TRACK DECLARED — ${c.symbol} @ ${c.price} · conviction ${score}/100 · vel5m ${c.vel5m >= 0 ? "+" : ""}${c.vel5m.toFixed(2)}% · vel1m ${c.vel1m >= 0 ? "+" : ""}${c.vel1m.toFixed(2)}% · vol-burst ${c.burstX.toFixed(1)}× · ${fmtEvidence(ev) || "flow evidence warming"} — SUCCESS criterion fixed NOW: +${PUMP_RULES.successMovePct}% MFE from anchor within ${PUMP_RULES.horizonMin}min · gate ${await gateLine()}`);
    // v9.2 — every declared track proposes its card; maybeSpawnSignal applies
    // the 78-floor ONLY in gated mode (direct = unfiltered emission).
    await maybeSpawnSignal(c.kind, c.symbol, score, row.id, now, c.price);
}
async function gateLine() {
    const g = await pumpGateAllows();
    return g.unlocked ? `UNLOCKED (${g.successful}/${g.total} successes)` : `LOCKED ${g.successful}/${PUMP_RULES.requiredSuccesses} successes — signals forbidden`;
}
/** Shared resolution write — flips the track to RESOLVED, persists outcome,
 *  drops it from the open map, resets the redeclare cooldown and fires the
 *  event. Extracted in v10.16 so the clock-expiry path reuses it verbatim. */ async function resolveTrack(t, outcome, note, now) {
    t.phase = "RESOLVED";
    t.lastWriteAt = now;
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.update({
            where: {
                id: t.id
            },
            data: {
                phase: t.phase,
                mfePct: Number(t.mfe.toFixed(3)),
                maePct: Number(t.mae.toFixed(3)),
                peakPrice: t.peak,
                outcome,
                resolvedAt: new Date(),
                successNote: note
            }
        });
    } catch (e) {
        console.error("[pump-radar] track resolution failed:", e);
        return;
    }
    openTracks.delete(t.symbol);
    lastResolveAt.set(t.symbol, now);
    const engine = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    await engine.fireEvent(null, t.symbol, outcome === "SUCCESS" ? "PUMP_RADAR" : "ENGINE", outcome === "SUCCESS" ? "success" : "info", `${t.kind} TRACK ${outcome} — ${t.symbol} ${outcome === "SUCCESS" ? "✓" : "✕"} · ${note} (MAE ${t.mae.toFixed(2)}%) · gate ${await gateLine()}`);
}
async function updateTrack(t, price, src, now) {
    // ── v10.16 P1 PUMP-LEAK — no live price for this track's symbol (it left
    // the universe, or the feed degraded to sim): MFE/MAE/peak/phase must NOT
    // move on invented prices, but the CLOCK still runs — once the same horizon
    // constant used by the price-based resolution elapses, the track resolves
    // EXPIRED instead of freezing forever (GENIUSUSDT-class heal).
    const live = price !== null && price > 0 && src !== "sim";
    if (!live) {
        if ((now - t.detectedAt) / 60_000 < PUMP_RULES.horizonMin) return;
        await resolveTrack(t, "EXPIRED", "clock-expired: no live price (v10.16)", now);
        return;
    }
    const sign = t.kind === "PUMP" ? 1 : -1;
    const fav = (price - t.anchor) / t.anchor * 100 * sign;
    t.mfe = Math.max(t.mfe, fav);
    t.mae = Math.max(t.mae, -fav);
    if (sign > 0) t.peak = Math.max(t.peak, price);
    else t.peak = Math.min(t.peak, price);
    // phase machine
    let phase = t.phase;
    if (t.phase === "ONSET" && t.mfe >= PUMP_RULES.extendPct) phase = "EXTENSION";
    else if (t.phase === "EXTENSION") {
        const leg = Math.max(t.mfe, 0.01);
        const retrace = (sign > 0 ? t.peak - price : price - t.peak) / (t.peak || price) * 100;
        if (retrace >= PUMP_RULES.exhaustRetraceFrac * leg) phase = "EXHAUSTION";
    }
    // resolution
    const ageMin = (now - t.detectedAt) / 60_000;
    if (t.mfe >= PUMP_RULES.successMovePct) {
        await resolveTrack(t, "SUCCESS", `MFE +${t.mfe.toFixed(2)}% ≥ +${PUMP_RULES.successMovePct}% in ${ageMin.toFixed(0)}min — continuation validated`, now);
        // ── v11.1 SUCCESS-CONFIRMED RE-NOMINATION (data-proven performance filter) ──
        // DB audit 2026-10-04: tracks that converted to signals after a SUCCESS
        // outcome averaged +20.4% (mixed era, n=59) and +25.1% (gated era, n=7)
        // vs −14.8% for FAILURE-converted — the realized SUCCESS outcome IS the
        // performance filter. The one-shot declare-moment 78 floor permanently
        // missed 163/208 gated-era SUCCESS tracks (score only evaluated at the
        // detection instant, never re-visited). Nomination now gets a SECOND,
        // outcome-confirmed chance: still through the full engine gate stack,
        // still spacing/maxActive-capped, chase-cap anchored at the confirmation
        // point (track peak) instead of the detection anchor.
        await renominateSuccessTrack(t, now);
        return;
    }
    if (t.mae >= PUMP_RULES.collapseMaePct) {
        await resolveTrack(t, "FAILURE", `collapsed — MAE ${t.mae.toFixed(2)}% against the thesis (MFE was +${t.mfe.toFixed(2)}%)`, now);
        return;
    }
    if (ageMin >= PUMP_RULES.horizonMin) {
        await resolveTrack(t, "FAILURE", `horizon ${PUMP_RULES.horizonMin}min elapsed — MFE +${t.mfe.toFixed(2)}% never reached +${PUMP_RULES.successMovePct}%`, now);
        return;
    }
    const dirty = phase !== t.phase || now - t.lastWriteAt >= PUMP_RULES.trackUpdateMs;
    if (!dirty) return;
    t.phase = phase;
    t.lastWriteAt = now;
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.update({
            where: {
                id: t.id
            },
            data: {
                phase: t.phase,
                mfePct: Number(t.mfe.toFixed(3)),
                maePct: Number(t.mae.toFixed(3)),
                peakPrice: t.peak
            }
        });
    } catch (e) {
        console.error("[pump-radar] track update failed:", e);
        return;
    }
}
// ── LEARNING GATE (operator: 5 successful tracks before any signal) ──────
let gateMemo = null;
async function pumpGateAllows() {
    if (!gateMemo || Date.now() - gateMemo.at >= 30_000) {
        const groups = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.groupBy({
            by: [
                "outcome"
            ],
            _count: {
                _all: true
            }
        });
        const get = (k)=>groups.find((g)=>g.outcome === k)?._count._all ?? 0;
        gateMemo = {
            at: Date.now(),
            successful: get("SUCCESS"),
            failed: get("FAILURE"),
            total: get("SUCCESS") + get("FAILURE")
        };
        if (gateMemo.successful >= PUMP_RULES.requiredSuccesses) {
            const cur = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                where: {
                    key: "pump.gate.unlockedAt"
                }
            }).catch(()=>null);
            if (!cur) {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                    where: {
                        key: "pump.gate.unlockedAt"
                    },
                    create: {
                        key: "pump.gate.unlockedAt",
                        value: new Date().toISOString()
                    },
                    update: {
                        value: new Date().toISOString()
                    }
                }).catch(()=>undefined);
                const engine = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
                await engine.fireEvent(null, null, "PUMP_RADAR", "success", `PUMP/DUMP RADAR UNLOCKED — ${gateMemo.successful} successful tracks confirmed the detector; dedicated PUMP/DUMP signal cards now ARMED (all normal engine gates still apply to every deploy)`).catch(()=>undefined);
            }
        }
    }
    const unlocked = gateMemo.successful >= PUMP_RULES.requiredSuccesses;
    return {
        unlocked,
        successful: gateMemo.successful,
        failed: gateMemo.failed,
        total: gateMemo.total,
        required: PUMP_RULES.requiredSuccesses,
        reason: unlocked ? `radar confirmed — ${gateMemo.successful} successful tracks (≥${PUMP_RULES.requiredSuccesses})` : `signals forbidden until ${PUMP_RULES.requiredSuccesses} successful tracks — ${gateMemo.successful} so far (${gateMemo.total} resolved)`
    };
}
// ── v9.1 DIRECT AUTHORITY → RETIRED v10.18 (operator option A, 2026-09-24:
// «کل سیستم بر پایه MARKET MATRIX و PUMP/DUMP RADAR، اما مهارشده») — the
// radar is the PRIMARY detection source of the consolidated system, but the
// unfiltered DIRECT emission mode (authorityBypass, live 2026-09-13 →
// 2026-09-24) is retired: clean-cohort evidence showed unfiltered pump
// emission UNDERPERFORMING the gated book (WR 10.8% vs 24.3%, avg −13.82%
// vs +8.66% over the last 7d). Every radar nomination now passes the FULL
// gate stack; the EngineSetting key below stays only as historical audit.
const AUTHORITY_KEY = "pump.authority";
async function getPumpAuthority() {
    // v10.18 honesty-by-construction: reports "gated" unconditionally so no
    // dashboard badge can ever narrate a mode that no longer exists in code.
    return "gated";
}
async function setPumpAuthority(mode) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: AUTHORITY_KEY
        },
        create: {
            key: AUTHORITY_KEY,
            value: mode
        },
        update: {
            value: mode
        }
    });
}
/** v11.1 — second nomination chance at SUCCESS resolution. Only for tracks
 *  that never got their card (no signalId). The realized SUCCESS outcome
 *  replaces the declare-moment 78 conviction floor as the proven filter;
 *  spacing + max-open + the full engine gate stack still apply. */ async function renominateSuccessTrack(t, now) {
    nomStats.successResolutions++;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.findUnique({
            where: {
                id: t.id
            },
            select: {
                signalId: true
            }
        });
        if (!row) return;
        if (row.signalId) {
            nomStats.renomSkippedHasCard++;
            return;
        }
    } catch  {
        return; // DB hiccup — never let the funnel heal break the radar loop
    }
    await maybeSpawnSignal(t.kind, t.symbol, t.score, t.id, now, t.anchor, {
        renom: true,
        // chase-cap anchor = confirmation point (the track's extreme), NOT the
        // detection anchor: post-SUCCESS the price is by definition ≥2% past the
        // anchor, so anchoring there would veto every re-nomination.
        renomRefPrice: t.peak
    });
}
async function maybeSpawnSignal(kind, symbol, score, trackId, now, anchorPrice, opts) {
    const engine = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    // ── v10.18 PHASE-2 CONSOLIDATION (operator option A, 2026-09-24) ──
    // The DIRECT-AUTHORITY bypass is RETIRED. The PUMP/DUMP RADAR is the
    // PRIMARY detection source of the consolidated system, but every emission
    // now passes the SAME gate stack as the rest of the book: learning gate +
    // 78 deploy floor + 20min spacing + max-open + the engine's full quality
    // gates (score/min_score, regime, dislocation, chase, DEGEN-STOP birth
    // guard). `authorityBypass` remains engine-internal for operator-forced
    // deploys and RAW-CAL capture only — the radar can no longer reach it.
    // Evidence basis: clean-cohort 7d ledger (post DEGEN/INVERTED exclusion)
    // pump WR 10.8% / avg −13.82% vs non-pump 24.3% / +8.66% — unfiltered
    // emission measurably UNDERPERFORMS the gated book. Acceptance gate for
    // the radar-primary era: GET /api/analytics/radar-probation (n≥30 settled
    // inside 14d, WR ≥ non-radar clean baseline, avgPnl > 0).
    {
        // v9.0 gated path — learning gate + 78 deploy floor + spacing + max-open
        const gate = await pumpGateAllows();
        if (!gate.unlocked) {
            nomStats.learningHeld++;
            await engine.fireEvent(null, symbol, "ENGINE", "info", `PUMP/DUMP RADAR: ${kind} ${symbol} scored ${score}/100 (deploy-grade) but the learning gate holds — ${gate.reason}`);
            return;
        }
        // v11.1: on the SUCCESS-confirmed re-nomination path the realized outcome
        // (MFE ≥ +2% validated within horizon) replaces the one-shot declare-moment
        // 78 conviction floor as the performance filter — that floor permanently
        // missed 163/208 gated-era SUCCESS tracks (funnel audit 2026-10-04).
        if (!opts?.renom && score < PUMP_RULES.scoreDeploy) {
            nomStats.belowDeployFloor++;
            return;
        }
        const now_ = Date.now();
        if (now_ - lastSignalAt.v < PUMP_RULES.signalSpacingMs) {
            if (opts?.renom) nomStats.renomSpacingDrop++;
            else nomStats.spacingDrop++;
            return;
        }
        const openRadar = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: kind
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        });
        if (openRadar >= PUMP_RULES.signalMaxActive) {
            if (opts?.renom) nomStats.renomMaxActiveDrop++;
            else nomStats.maxActiveDrop++;
            return;
        }
        // ── v12.1 TASK-48 ① R6 RADAR LANE rails (renom cohort only) ──
        if (opts?.renom) {
            nomStats.laneAttempts++;
            const laneCfg = await getRadarLaneCfg();
            const todayKey = new Date().toISOString().slice(0, 10);
            if (laneDay.key !== todayKey) {
                // re-arm the in-memory daily counter from the DB after day roll / boot
                const c = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                    where: {
                        tags: {
                            contains: "R6-LANE"
                        },
                        createdAt: {
                            gte: new Date(`${todayKey}T00:00:00.000Z`)
                        }
                    }
                }).catch(()=>0);
                laneDay.key = todayKey;
                laneDay.count = c;
            }
            if (!laneCfg.enabled) {
                nomStats.laneCapDrop++;
                await engine.fireEvent(null, symbol, "ENGINE", "info", `PUMP/DUMP RADAR: ${kind} ${symbol} SUCCESS re-nom held — R6 LANE disabled (${(await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
                    where: {
                        key: "radar-lane"
                    }
                }).catch(()=>null))?.value ?? "{}"})`);
                return;
            }
            if (laneDay.count >= laneCfg.dailyCap) {
                nomStats.laneCapDrop++;
                await engine.fireEvent(null, symbol, "ENGINE", "info", `PUMP/DUMP RADAR: ${kind} ${symbol} SUCCESS re-nom held — R6 LANE daily cap ${laneDay.count}/${laneCfg.dailyCap} (bounded blast radius)`);
                return;
            }
            // probation verdict — at most one check per 10min (two DB scans)
            if (now - lastLaneProbationAt >= 600_000) {
                lastLaneProbationAt = now;
                const prob = await radarLaneProbationCheck(laneCfg);
                nomStats.laneProbationNote = prob.note;
                if (!prob.ok) {
                    nomStats.laneCapDrop++;
                    const e2 = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
                    await e2.fireEvent(null, null, "PUMP_RADAR", "warn", `R6 RADAR LANE AUTO-DEMOTED — ${prob.note} · lane disabled by evidence, SUCCESS renoms return to the strict gate stack`);
                    return;
                }
            } else if (nomStats.laneProbationNote.startsWith("AUTO-DEMOTED")) {
                nomStats.laneCapDrop++;
                return;
            }
        }
        lastSignalAt.v = now_;
        if (opts?.renom) nomStats.renomAttempts++;
        else nomStats.nominated++;
    }
    // v9.2 comment RETIRED with the direct path (v10.18, see block above).
    // v9.3 R6-INFORMATIVE PACKAGE (operator mandate الف + anti-late-entry):
    //   · ttlMinutes 60–75 (vs the 180–300 AI-SWING default these cards inherit)
    //     → cards RESOLVE fast: fewer EXPIRED-no-touch censors, higher R6
    //     informative ratio, faster capital cycle.
    //   · ttlNoExtend → the dynamic expiry gate may NOT re-extend radar cards
    //     (an extension would reintroduce exactly the censoring R6 suffers from).
    //   · refPrice = track anchorPrice + chaseCapPct 1.5 → the deploy is refused
    //     if price already ran >1.5% past DETECTION — execution can no longer
    //     enter later than the radar saw the move (Duration-Lab: the fast-kill
    //     cohort never went green; they were cascade chases).
    // v9.3.1 ROUTING FIX (independent audit 2026-09-13 18:05 +08, DB evidence):
    //   focusSymbol was MISSING here — deploySignal ran a FULL-UNIVERSE scan and
    //   the authorityBypass fallback picked the strongest candidate of the WHOLE
    //   market, so cards were born on a DIFFERENT symbol than the detected flow
    //   (proven pairs: VTHOUSDT track → AAVEUSDT card NX-0129, STEEMUSDT track →
    //   ZECUSDT card NX-0136, METUSDT track → SOLUSDT card NX-0123). That is the
    //   literal "execution enters later (and elsewhere) than detection" defect,
    //   AND it poisoned the anchor-referenced chase cap: refPrice(anchor of X)
    //   vs entry(price of Y) is a cross-symbol ratio — nonsense drift that would
    //   either refuse every radar deploy or bless a wrong-symbol chase. With
    //   focusSymbol the pool IS the radar symbol, the 1:1 detection→card mapping
    //   holds on the right market, and chase-cap 1.5% measures the TRUE
    //   detection→fill drift of the detected flow.
    const res = await engine.deploySignal(symbol, kind === "PUMP" ? "LONG" : "SHORT", {
        triggerTag: "PUMP-RADAR",
        extraTags: [
            kind,
            ...opts?.renom ? [
                "R6-LANE"
            ] : []
        ],
        // v12.1 TASK-48 ①: the SUCCESS-renom cohort rides the R6 RADAR LANE —
        // the four cohort-blind MOOD gates (R1 SHORT-GUARD, regime CHOP ladder,
        // MEMORY-GATE, dynamic MIN_SCORE) are bypassed; every physical gate stays
        // live; lane rails (dailyCap/maxActive/spacing/probation) bound the
        // cohort. Declare-time nominations keep the strict path unchanged.
        radarLane: !!opts?.renom,
        // v10.18: NO authorityBypass — radar emissions ride the full gate stack.
        focusSymbol: symbol,
        ttlMinutes: 60 + Math.round(Math.random() * 15),
        ttlNoExtend: true,
        // v11.1: re-nominations anchor the chase cap at the SUCCESS confirmation
        // point (track peak); declare-time nominations keep the detection anchor.
        refPrice: opts?.renom ? opts.renomRefPrice ?? anchorPrice : anchorPrice,
        chaseCapPct: 1.5,
        // Task 79 FILL LEDGER — detection instant for the slippage/latency ledger
        detectedAt: (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.findUnique({
            where: {
                id: trackId
            },
            select: {
                detectedAt: true
            }
        }).catch(()=>null))?.detectedAt?.getTime()
    });
    if (res.signal) {
        if (opts?.renom) nomStats.renomDeployed++;
        else nomStats.deployed++;
        if (opts?.renom) {
            nomStats.laneDeployed++;
            laneDay.count += 1;
        }
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.update({
            where: {
                id: trackId
            },
            data: {
                signalId: res.signal.id
            }
        }).catch(()=>undefined);
        await engine.fireEvent(null, symbol, "PUMP_RADAR", "success", `${kind} RADAR DEPLOY${opts?.renom ? " (SUCCESS-CONFIRMED RE-NOMINATION v11.1 · R6 RADAR LANE — mood gates bypassed, physical gates + probation live)" : ""} — ${symbol} conviction ${score}/100 → NX-${String(res.signal.serial).padStart(4, "0")} deployed${opts?.renom ? " through the R6 lane" : " THROUGH THE FULL GATE STACK (radar-primary gated emission)"} with the dedicated ${kind} card`);
    } else if (res.error) {
        nomStats.engineVetoed++;
        if (opts?.renom) nomStats.laneVetoed++;
        await engine.fireEvent(null, symbol, "ENGINE", "info", `PUMP/DUMP RADAR: ${kind} ${symbol} nomination${opts?.renom ? " (SUCCESS re-nom · R6 LANE — physical gates still live)" : ""} VETOED by the engine gates — ${res.error.slice(0, 160)}`);
    }
}
// ── status for the dashboard radar panel ─────────────────────────────────
const toDTO = (r)=>({
        id: r.id,
        symbol: r.symbol,
        kind: r.kind === "PUMP" ? "PUMP" : "DUMP",
        phase: r.phase,
        outcome: r.outcome,
        anchorPrice: r.anchorPrice,
        mfePct: r.mfePct,
        maePct: r.maePct,
        score: r.score,
        vel5mPct: r.vel5mPct,
        volBurstX: r.volBurstX,
        detectedAt: r.detectedAt.toISOString(),
        resolvedAt: r.resolvedAt?.toISOString() ?? null,
        successNote: r.successNote
    });
async function getPumpEngineStatus() {
    if (memo && Date.now() - memo.at < 15_000) return memo.v;
    try {
        await ensureBooted();
        const gate = await pumpGateAllows();
        const authority = await getPumpAuthority();
        const [active, recent] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.findMany({
                where: {
                    phase: {
                        not: "RESOLVED"
                    }
                },
                orderBy: {
                    detectedAt: "desc"
                },
                take: 8
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.findMany({
                where: {
                    outcome: {
                        not: null
                    }
                },
                orderBy: {
                    resolvedAt: "desc"
                },
                take: 6
            })
        ]);
        const unlockedRow = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "pump.gate.unlockedAt"
            }
        }).catch(()=>null);
        const v = {
            gate: {
                unlocked: gate.unlocked,
                successful: gate.successful,
                failed: gate.failed,
                total: gate.total,
                required: gate.required,
                unlockedAt: unlockedRow?.value ?? null
            },
            authority,
            nomination: {
                ...nomStats
            },
            active: active.map(toDTO),
            recent: recent.map(toDTO),
            tapeSymbols: tape.size,
            warm: tape.size > 0 && [
                ...tape.values()
            ].every((r)=>r.length >= PUMP_RULES.warmPoints || r.length === 0)
        };
        memo = {
            at: Date.now(),
            v
        };
        return v;
    } catch  {
        return {
            gate: {
                unlocked: false,
                successful: 0,
                failed: 0,
                total: 0,
                required: PUMP_RULES.requiredSuccesses,
                unlockedAt: null
            },
            authority: "gated",
            nomination: {
                ...nomStats
            },
            active: [],
            recent: [],
            tapeSymbols: tape.size,
            warm: false
        };
    }
}
}),
"[project]/src/lib/rawcal-heartbeat.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "touchRawcalHeartbeat",
    ()=>touchRawcalHeartbeat
]);
// ── v10.20 RAW-CAL RUN HEARTBEAT (engine-native) ───────────────────────────
// M4 mission finding SENTINEL-20260921-M4 #6: the RAWCAL run heartbeat
// (.data/rawcal-run-heartbeat.txt) was historically written by an external
// 2h cron that died 2026-09-19T11:33Z — the sentinel kept reading a stale
// "heartbeatAgeH" for a system that was in fact alive-but-idle (disarmed by
// design at target). This module makes the ENGINE itself the heartbeat
// writer: maybeRawCalDeploy() runs every 10 ticks (always alive while Next
// runs), so the heartbeat now reflects the true run-loop state:
//   · ARMED  — capture mode issuing (state carries issued/target)
//   · IDLE   — disarmed by policy (the honest "alive, not dead" signal)
//   · ISSUE  — a raw record was just issued (state change → always written)
//   · ARMED/…— arm/disarm transitions (always written)
// Format stays sentinel-compatible: each line begins with the minute-precision
// UTC stamp the sentinel parses (`YYYY-MM-DDTHHMMZ`), state detail follows.
// Failure contract: best-effort telemetry — never throws, never blocks a tick.
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const HB_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "rawcal-run-heartbeat.txt");
const SAME_STATE_THROTTLE_MS = 30 * 60_000; // idle/armed steady-state: 1 line / 30min
const MAX_LINES = 200; // bounded file — ~4 days of steady-state history
let lastState = "";
let lastWriteAt = 0;
let chain = Promise.resolve(); // serialize read-modify-write
const p2 = (n)=>String(n).padStart(2, "0");
function stamp(d) {
    return `${d.getUTCFullYear()}-${p2(d.getUTCMonth() + 1)}-${p2(d.getUTCDate())}T${p2(d.getUTCHours())}${p2(d.getUTCMinutes())}Z`;
}
async function writeHeartbeat(state) {
    const now = Date.now();
    const line = `${stamp(new Date(now))} ${state}`;
    if (line === lastState && now - lastWriteAt < SAME_STATE_THROTTLE_MS) return; // steady-state throttle
    const txt = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].readFile(HB_FILE, "utf8").catch(()=>"");
    const lines = txt.trim().split("\n").filter(Boolean);
    lines.push(line);
    const keep = lines.slice(-MAX_LINES).join("\n") + "\n";
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].dirname(HB_FILE), {
        recursive: true
    });
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(HB_FILE, keep, "utf8");
    lastState = line;
    lastWriteAt = now;
}
function touchRawcalHeartbeat(state) {
    const trimmed = state.slice(0, 110);
    chain = chain.then(()=>writeHeartbeat(trimmed)).catch(()=>undefined); // telemetry is best-effort — never block the caller
}
}),
"[project]/src/lib/raw-cal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RAWCAL_KEY",
    ()=>RAWCAL_KEY,
    "RAWCAL_TARGET",
    ()=>RAWCAL_TARGET,
    "armRawCal",
    ()=>armRawCal,
    "captureBookRegimeSplit",
    ()=>captureBookRegimeSplit,
    "clampManualBatch",
    ()=>clampManualBatch,
    "disarmRawCal",
    ()=>disarmRawCal,
    "epoch2SettledCount",
    ()=>epoch2SettledCount,
    "getRawCalBlocks",
    ()=>getRawCalBlocks,
    "getRawCalState",
    ()=>getRawCalState,
    "getV146Guard",
    ()=>getV146Guard,
    "maybeRawCalDeploy",
    ()=>maybeRawCalDeploy,
    "rawCalStatus",
    ()=>rawCalStatus
]);
// ── v9.1 RAW-CAL — UNFILTERED CALIBRATION CAPTURE MODE (operator mandate) ──
// Operator order 2026-09-13: «یک دستور اجرای صدور سیگنال بدون فیلتر و فقط
// ثبت داده و پیگیری و جورنال سازی برای ارسال به ENGINE MEMORY تا سریعتر به
// حد 100 سیگنال برای AI CALIBRATION برسد، سپس این دستور لغو و تمام عملکرد
// فیلتر و ردیابی با دستور هوش مرکزی و کالیبراسون جدید انجام بشه»
//
// WHAT IT DOES (exactly the operator's words, engineered honestly):
//  · ARMED → the engine issues RAW-CAL signals with the quality filters
//    bypassed (threshold/memory/strategy/short/learned/flow/shadow-veto —
//    engine.ts deploySignal opts.calCapture). Every record keeps its REAL
//    confluence votes + strategy + flow snapshot so the R6 recalibration at
//    n≥100 attributes outcomes to actual factors, not noise.
//  · ONLY data capture: records enter the normal ledger → tracked → settled
//    → journaled exactly like every other signal (same TTL, TP ladder,
//    trailing, afterlife) — nothing is faked, nothing is skipped.
//  · ENGINE MEMORY: state + issued-cohort stats are injected into
//    buildEngineMemory() (ai-memory.ts) so the central intelligence sees the
//    raw cohort as ground truth, and the governor context carries the mode.
//  · AUTO-CANCEL: when the EPOCH-2 settled book reaches the target (100),
//    the mode disarms ITSELF, fires the audited RAW-CAL LIFT event, forces
//    refreshCalibration() (the R6 freeze lifts at n≥100 — new calibration
//    under central-intelligence command), and announces on Telegram.
//  · The operator can DISARM any time (dashboard button / /api/rawcal POST).
//
// ANTI-FLOOD RAILS (protect the ledger, not the filter):
//  · spacingMin (default 12min) between raw issues
//  · maxOpen (default 8) concurrent open RAW-CAL records
//  · the scan's own honesty rails stay HARD inside deploySignal (feed-fresh
//    guard + sim-price ban) — calibration rows are never born from stale
//    or invented prices.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-telemetry.ts [app-route] (ecmascript)"); // v9.2 pace monitor (no cycle: telemetry imports raw-cal only dynamically)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rawcal-heartbeat.ts [app-route] (ecmascript)"); // v10.20 engine-native run heartbeat (sentinel-compatible)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)"); // v14.2 — ban-aware issuer suspension (audit rec #1)
;
;
;
;
const RAWCAL_KEY = "rawcal.state";
const RAWCAL_TARGET = 100; // the R6 calibration-lift bar (calibration.ts)
// v10.6.1 spacing 12→10 (operator APPROVE 2026-09-18, proposal #3 of msg 3435):
// tightens the anti-flood floor so evidence windows fill faster without
// loosening honesty rails (open-cap + scan rails unchanged).
const DEFAULT_SPACING_MIN = 10;
const DEFAULT_MAX_OPEN = 8;
// EQ-99 (operator: «ماژول RAW-CAL چرا بطور دستی فعال نمی شود؟» 2026-10-13):
// a POST-graduation manual re-arm used to be AUTO-LIFTED within 10 ticks —
// the tick's graduation tripwire (settledN ≥ target + arms complete) has no
// concept of "the operator deliberately re-armed". Fix: a manual re-arm after
// graduation is a NEW CAPTURE CAMPAIGN — the book target moves ahead of the
// settled count by this batch so the tripwire stays dormant until the fresh
// evidence settles. 300 = the R6 refresh basis (calibration.ts recalibration
// window); operator-overridable via the API (clamped 50..2000).
const MANUAL_CAPTURE_BATCH_DEFAULT = 300;
function clampManualBatch(v) {
    const n = typeof v === "number" ? Math.floor(v) : NaN;
    if (!Number.isFinite(n)) return MANUAL_CAPTURE_BATCH_DEFAULT;
    return Math.min(2000, Math.max(50, n));
}
const DEFAULT_STATE = {
    armed: false,
    armedAt: null,
    armedBy: "",
    disarmReason: null,
    disarmedAt: null,
    issued: 0,
    issuedTotal: 0,
    lastIssueAt: null,
    lastIssueSerial: null,
    target: RAWCAL_TARGET,
    spacingMin: DEFAULT_SPACING_MIN,
    maxOpen: DEFAULT_MAX_OPEN,
    autoLiftAt: null
};
async function getRawCalState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: RAWCAL_KEY
            }
        });
        if (!row) return {
            ...DEFAULT_STATE
        };
        const raw = {
            ...DEFAULT_STATE,
            ...JSON.parse(row.value)
        };
        // TASK-49 NAN-PROOF — a historic write escaped `target: settledN + NaN` into
        // JSON (NaN serializes to null), which made `settledN >= null` ALWAYS true
        // and pinned the arms-coupled extension branch on every pass. Sanitize on
        // read: any non-finite spacing/maxOpen/target heals to a sane value here,
        // so the loop can never be wedged by one bad write again.
        const num = (v, dflt)=>typeof v === "number" && Number.isFinite(v) && v > 0 ? v : dflt;
        return {
            ...raw,
            spacingMin: num(raw.spacingMin, DEFAULT_SPACING_MIN),
            maxOpen: num(raw.maxOpen, DEFAULT_MAX_OPEN),
            target: num(raw.target, RAWCAL_TARGET)
        };
    } catch  {
        return {
            ...DEFAULT_STATE
        };
    }
}
// ── v9.2 ISSUANCE-BLOCK RING (observability) — why the issuer last paused ──
// maybeRawCalDeploy returns a note on every non-issue pass; the ring keeps the
// recent ones so the pace monitor can show WHY cadence paused (spacing rail,
// open cap, scan-no-candidate, feed-stale…). Duplicate identical notes inside
// 5min refresh the timestamp instead of stacking.
const blockRing = [];
function noteRawCalBlock(note) {
    const last = blockRing[blockRing.length - 1];
    if (last && last.note === note && Date.now() - last.t < 5 * 60_000) {
        last.t = Date.now();
        return;
    }
    blockRing.push({
        t: Date.now(),
        note: note.slice(0, 90)
    });
    if (blockRing.length > 40) blockRing.shift();
}
function getRawCalBlocks(n = 12) {
    return blockRing.slice(-n);
}
async function writeState(state) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: RAWCAL_KEY
        },
        create: {
            key: RAWCAL_KEY,
            value: JSON.stringify(state)
        },
        update: {
            value: JSON.stringify(state)
        }
    });
}
async function epoch2SettledCount() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            tags: {
                contains: "EPOCH-2"
            }
        }
    });
}
async function armRawCal(by = "OPERATOR", batch) {
    const cur = await getRawCalState();
    if (cur.armed) return cur;
    const settledN = await epoch2SettledCount();
    // EQ-99 POST-GRADUATION RE-ARM CAMPAIGN — if the graduation tripwire condition
    // already holds (settledN ≥ target && arms complete), a plain re-arm would be
    // auto-lifted by the very next tick (line-proven 2026-10-13: settled 2376 ≥
    // target 2348 → tick calls disarmRawCal(auto) unconditionally). An operator
    // re-arm AFTER graduation is therefore a NEW CAPTURE CAMPAIGN: the target
    // moves settledN+batch so the auto-lift fires only when the FRESH batch has
    // settled — the operator's command sticks and the lift still re-runs the
    // R6 calibration over the grown book, unchanged.
    const campaign = settledN >= cur.target;
    const campaignTarget = campaign ? settledN + clampManualBatch(batch) : cur.target;
    const state = {
        ...cur,
        armed: true,
        armedAt: new Date().toISOString(),
        armedBy: by,
        disarmReason: null,
        disarmedAt: null,
        issued: 0,
        autoLiftAt: null,
        ...campaign ? {
            target: campaignTarget,
            manualCampaign: true,
            retargetNote: `EQ-99 OPERATOR RE-ARM CAMPAIGN (${by}): graduation condition already held (${settledN} settled ≥ ${cur.target}) — a plain re-arm would be auto-lifted within 10 ticks. Book target moved +${campaignTarget - settledN} → ${campaignTarget} so this campaign captures FRESH evidence and the organic auto-lift + R6 recalibration fires at the new bar`
        } : {
            manualCampaign: false
        }
    };
    await writeState(state);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ARMED by ${by.slice(0, 70)}${campaign ? ` (re-campaign → target ${campaignTarget})` : ""}`); // v10.20 — transition write (throttle bypassed on state change)
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    await fireEvent(null, null, "ENGINE", "warn", `RAW-CAL CAPTURE MODE ARMED (${by}) — signal issuance now runs WITHOUT quality filters: every scan's best candidate is issued as a tagged RAW-CAL record (data capture + tracking + journaling only), feeding the engine-memory book toward the AI CALIBRATION bar (${settledN}/${state.target} EPOCH-2 settled)${campaign ? ` — EQ-99 RE-CAMPAIGN: graduation bar was already met, so this re-arm opens a FRESH capture batch (+${state.target - settledN}); auto-lift + R6 recalibration fires at the new bar` : ""}. Anti-flood rails: ≥${state.spacingMin}min spacing, ≤${state.maxOpen} open raw records. The mode AUTO-CANCELS at ${state.target} settled and hands back to central-intelligence command with the new calibration.`);
    const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
    void sendDirect(`🧪 <b>RAW-CAL CAPTURE MODE ARMED</b>${campaign ? " — RE-CAMPAIGN" : ""}\nUnfiltered signal issuance is now ON — every scan's best flow is recorded as a RAW-CAL signal (tracked + journaled, no quality filters).\n📊 Progress: <b>${settledN}/${state.target}</b> EPOCH-2 settled → AI CALIBRATION lift${campaign ? ` (fresh batch +${state.target - settledN})` : ""}\n🛡 Rails: ≥${state.spacingMin}min spacing · ≤${state.maxOpen} open · auto-cancel at ${state.target}`).catch(()=>undefined);
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])("ARMED", true).catch(()=>undefined);
    return state;
}
async function disarmRawCal(reason, auto = false) {
    const cur = await getRawCalState();
    if (!cur.armed && !auto) return cur;
    const settledN = await epoch2SettledCount();
    const state = {
        ...cur,
        armed: false,
        disarmReason: reason,
        disarmedAt: new Date().toISOString(),
        ...auto ? {
            autoLiftAt: new Date().toISOString()
        } : {}
    };
    await writeState(state);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`IDLE ${auto ? "AUTO-LIFT" : "disarmed"} — ${reason.slice(0, 60)}`); // v10.20 — transition write
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    await fireEvent(null, null, "ENGINE", "ai", `${auto ? "RAW-CAL LIFT — CAPTURE MODE AUTO-CANCELED" : "RAW-CAL CAPTURE MODE DISARMED"} (${reason}) — EPOCH-2 book ${settledN}/${cur.target} settled. All filtering, tracking and sizing return to CENTRAL-INTELLIGENCE command (governor + advisor + AI core) under the NEW calibration${settledN >= cur.target ? " — R6 freeze lifts at n≥100 and profit-first weights recalibrate over the full book including the RAW-CAL cohort" : ""}.`);
    const { sendDirect } = await __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)");
    void sendDirect(`${auto ? "🎓 <b>RAW-CAL LIFT — CAPTURE COMPLETE</b>" : "⏹ <b>RAW-CAL MODE DISARMED</b>"}\n${reason}\n📊 EPOCH-2 book: <b>${settledN}/${cur.target}</b> settled${settledN >= cur.target ? " — AI CALIBRATION recalibrates over the full book (R6 lift)" : ""}\nFiltered operation returned to central-intelligence command.`).catch(()=>undefined);
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])(auto ? "AUTO-LIFT" : "DISARMED", true).catch(()=>undefined);
    return state;
}
// ── v14.6 WINNER-LANE AUTO-ABORT GUARD ──────────────────────────────────────
// The honest rail behind the v14.6 reopen: FAPI-DEG-W rows are accounted
// separately, and the moment ≥20 of them settle with avg net ≤ −$0.10 the
// v14.5 protected stand-down re-arms ITSELF (persisted in rawcal.v146) — no
// operator vigilance required, the bleed cannot restart silently.
const V146_KEY = "rawcal.v146";
const V146_DEFAULT = {
    suspended: false,
    reason: null,
    at: null,
    cohortN: 0,
    cohortAvgNet: null,
    checkedAt: null
};
async function readV146Row() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: V146_KEY
            }
        });
        if (!row) return {
            ...V146_DEFAULT
        };
        return {
            ...V146_DEFAULT,
            ...JSON.parse(row.value)
        };
    } catch  {
        return {
            ...V146_DEFAULT
        };
    }
}
async function getV146Guard() {
    const st = await readV146Row();
    st.checkedAt = new Date().toISOString();
    try {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                tags: {
                    contains: "FAPI-DEG-W"
                },
                status: {
                    in: [
                        "TP1",
                        "TP2",
                        "TP3",
                        "SL",
                        "EXPIRED",
                        "CLOSED"
                    ]
                }
            },
            select: {
                marginUsd: true,
                pnlPercent: true
            }
        });
        let net = 0;
        for (const r of rows)net += r.marginUsd * r.pnlPercent / 100;
        st.cohortN = rows.length;
        st.cohortAvgNet = rows.length ? Number((net / rows.length).toFixed(3)) : null;
        if (!st.suspended && rows.length >= 20 && st.cohortAvgNet !== null && st.cohortAvgNet <= -0.1) {
            st.suspended = true;
            st.reason = `AUTO-ABORT: FAPI-DEG-W cohort n=${rows.length} avg net $${st.cohortAvgNet}/row ≤ −$0.10 — winner-lane degraded capture re-suspended (v14.5 semantics)`;
            st.at = st.checkedAt;
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
                where: {
                    key: V146_KEY
                },
                create: {
                    key: V146_KEY,
                    value: JSON.stringify(st)
                },
                update: {
                    value: JSON.stringify(st)
                }
            });
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
            void fireEvent(null, null, "ENGINE", "warn", `RAW-CAL v14.6 AUTO-ABORT: FAPI-DEG-W winner-lane cohort n=${rows.length} settled, avg net $${st.cohortAvgNet}/row ≤ −$0.10 — degraded-winner capture SUSPENDED, v14.5 protected stand-down re-armed.`).catch(()=>undefined);
        }
    } catch  {
    // fail-open: guard probe errors never block the issuer (rows stay tagged)
    }
    return st;
}
async function maybeRawCalDeploy() {
    const state = await getRawCalState();
    // v10.20 — engine-native run heartbeat: the tick proves the run loop is ALIVE
    // every 10 ticks (idle/armed steady-state throttled to 1 line / 30min inside).
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(state.armed ? `ARMED issued=${state.issued}/${state.issuedTotal} target=${state.target}` : `IDLE disarmed by policy (target ${state.target})`);
    if (!state.armed) {
        noteRawCalBlock("not armed");
        return {
            issued: false,
            note: "not armed"
        };
    }
    // 0) v14.6 WINNER-LANE DEGRADED CAPTURE (operator order 2026-11-11 trace
    //    1a1ca1b0320831a9 «…بررسی ممیزی از عملکرد سیگنالهای برنده و استفاده و باز
    //    گذاشتن ویژگی های شاخص برای گیت و تایید سیگنال…») — SUPERSEDES the v14.5
    //    hard stand-down. ─────────────
    //    WHY the flip back (evidence, ops-audit-1111):
    //    · v14.5's premise ("bans are intermittent ~24-min windows") DIED —
    //      ban.active held ~100% of the wall clock for 14h+ (rolling named-IP
    //      renewals on the external 3-IP egress pool; heartbeat 08:57→10:15Z all
    //      protected; scan-no-candidate events ceased 20:41Z; stall alert 08:36Z),
    //      so the stand-down became the exact total-issuance freeze it replaced.
    //    · The scoring lane is HEALTHY during bans: 2,788 candidates PASSed in
    //      24h — 100% SHORT, AI-SWING-dominated — exactly the proven winner
    //      cohort (CHOP|AI-SWING|SHORT n=230 · WR 30.4% · +$49.56/14d; CHOP
    //      all-time +$125.26). The wall sits ONLY in this ban check.
    //    · The v14.5 FAPI-DEG loss cohort (−$0.20/row) was accumulated 11-06→11-10
    //      while AI-SCALP + MEAN-REVERT were OPEN and CHOP-LONGs flowed — those
    //      cohorts are now BLOCKED UPSTREAM (strat-pause 11-10, regimeGuard L1,
    //      memory gate), so a ban-window row today is a different, winner-shaped
    //      cohort. The WS tape is LIVE during bans (feed failures=0, futws fresh
    //      43 rows) — only the flow bundle is demoted (blind flow,
    //      INFORMATIONAL-ONLY, historically non-negative).
    //    · GUARDRAIL (the honest part): rows carry FAPI-DEG + FAPI-DEG-W tags for
    //      separate cohort accounting, and an AUTO-ABORT re-arms the v14.5
    //      stand-down by itself once ≥20 FAPI-DEG-W rows settle with avg net
    //      ≤ −$0.10 (persisted rawcal.v146) — the drought ends, the bleed cannot
    //      restart silently. Reversible by writing rawcal.v146 {suspended:false}.
    const ban = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fapiBanActivity"])();
    if (ban.active) {
        const v146 = await getV146Guard();
        if (v146.suspended) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`OPEN (protected) — v14.6 auto-abort live: winner-lane degraded capture suspended (${(v146.reason ?? "winner cohort bled").slice(0, 70)})`);
            noteRawCalBlock(`v14.6 auto-abort — ${(v146.reason ?? "winner cohort bled").slice(0, 80)}`);
            return {
                issued: false,
                note: "v14.6 winner-lane auto-abort"
            };
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`OPEN (degraded-winner) — fapi ban active (${ban.reason?.slice(0, 50)}): capture continues on WS-live tape, tagged FAPI-DEG-W (auto-abort armed: n≥20 & avg ≤ −$0.10) — operator order 2026-11-11 «باز گذاشتن ویژگی های شاخص»`);
    }
    // 1) progress check FIRST — Task 34-2 ARMS-COUPLED AUTO-CANCEL (2026-09-26
    //    operator mandate: «RAW-CAL باید AI CALIBRATION BAR را تا زمان کامل شدن
    //    بازوهای Shadow veto فعال باشد و PACE MONITOR بر این اساس تنظیم شود»):
    //    the book target alone no longer lifts the capture. When the target is
    //    reached but the shadow-veto REAL evidence arms are still incomplete,
    //    the mode AUTO-EXTENDS its target by the arm deficit (audited retarget,
    //    EVID-BUDGET pattern) instead of disarming — the calibration book keeps
    //    growing while the veto evidence window stays open. Only when BOTH the
    //    book target is met AND the arms are complete (paper-veto waived in
    //    shadow mode — it structurally cannot fill) does the auto-lift fire.
    const settledN = await epoch2SettledCount();
    if (settledN >= state.target) {
        const sv = await __turbopack_context__.A("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript, async loader)");
        const cfg = await sv.getShadowVetoConfig();
        // v11.5 hotfix (tsc-caught latent bug): shadowArmsCompletion is ASYNC —
        // the missing await made `completion` a Promise whose fields are all
        // undefined, so `!completion.allComplete` was ALWAYS true: the lift path
        // could never fire and the target auto-extended forever. Dormant only
        // because the mode is currently disarmed.
        const completion = await sv.shadowArmsCompletion(cfg.mode);
        if (!completion.allComplete) {
            // TASK-49 — NaN-proof: a stale compiled module (Turbopack chunk from the
            // pre-Task-34-2 snapshot) once returned a completion WITHOUT
            // note/pendingDeficit → Math.max(undefined)=NaN → target NaN → JSON null
            // → this branch pinned forever (repeating "[raw-cal] slice of undefined").
            // Guard every unknown now.
            const deficit = Number.isFinite(completion.pendingDeficit) ? completion.pendingDeficit : 10;
            const extension = Math.max(deficit, 10);
            const note = completion.note ?? "arms probe shape mismatch — treated as incomplete";
            const nextTarget = Number.isFinite(settledN + extension) ? settledN + extension : state.target + extension;
            const next = {
                ...state,
                target: nextTarget,
                retargetNote: `ARMS-COUPLED EXTENSION (operator mandate 2026-09-26 «تا زمان کامل شدن بازوهای Shadow veto فعال باشد»): book target ${state.target} reached but shadow-veto real arms incomplete (${note}) — target auto-extended +${extension} to ${nextTarget} so the capture keeps feeding evidence; PACE MONITOR tracks arm completion`
            };
            await writeState(next);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ARM-EXTEND target ${state.target}→${next.target} (${note.slice(0, 80)})`);
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
            await fireEvent(null, null, "ENGINE", "info", `RAW-CAL: book target reached (${settledN}) but shadow-veto arms incomplete — capture AUTO-EXTENDED +${extension} (target → ${next.target}). Arms: ${(completion.arms ?? []).map((a)=>`${a.id} ${a.n}/${a.target}${a.waived ? " (waived)" : ""}`).join(" · ")}`);
            return {
                issued: false,
                note: `arms-coupled extension → target ${next.target}`
            };
        }
        await disarmRawCal(`target reached + shadow-veto arms complete — ${settledN} EPOCH-2 settled ≥ ${state.target}`, true);
        const { refreshCalibration } = await __turbopack_context__.A("[project]/src/lib/calibration.ts [app-route] (ecmascript, async loader)");
        const { state: cal, auditLine } = await refreshCalibration();
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "ai", auditLine ?? `AI CALIBRATION post-RAW-CAL: status ${cal.status} over ${cal.settled} settled — ${cal.rows.length} moving factors ${cal.rows.map((r)=>`${r.factor} ×${r.weight.toFixed(2)}`).join(" · ")}`);
        return {
            issued: false,
            note: `auto-lifted at ${settledN} (arms complete)`
        };
    }
    // 2) spacing rail
    if (state.lastIssueAt && Date.now() - new Date(state.lastIssueAt).getTime() < state.spacingMin * 60_000) {
        noteRawCalBlock(`spacing rail — next window ≥ ${state.spacingMin}min`);
        return {
            issued: false,
            note: "spacing"
        };
    }
    // 3) open-records rail (RAW-CAL cohort only)
    const openRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "ACTIVE",
                    "TP1",
                    "TP2"
                ]
            }
        }
    });
    if (openRaw >= state.maxOpen) {
        noteRawCalBlock(`open-cap rail — ${openRaw}/${state.maxOpen} raw records in flight`);
        return {
            issued: false,
            note: `open cap ${openRaw}/${state.maxOpen}`
        };
    }
    // 4) issue the capture record through the engine scan (honesty rails stay
    //    hard inside deploySignal: feed-fresh guard + sim-price ban)
    //    v14.6 — during a live fapi ban the row is tagged FAPI-DEG (cohort
    //    continuity) + FAPI-DEG-W (winner-lane window, auto-abort accounting).
    const { deploySignal } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    const res = await deploySignal(undefined, undefined, {
        calCapture: true,
        triggerTag: "RAW-CAL",
        ...ban.active ? {
            extraTags: [
                "FAPI-DEG",
                "FAPI-DEG-W"
            ]
        } : {}
    });
    if (!res.signal) {
        // rate-limit the "scan found nothing" chatter — one event / 30min
        noteRawCalBlock(`scan-no-candidate — ${res.error?.slice(0, 60) ?? "no setup"}`);
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        const recent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.count({
            where: {
                type: "ENGINE",
                level: "info",
                message: {
                    contains: "RAW-CAL: scan found no live candidate"
                },
                createdAt: {
                    gte: new Date(Date.now() - 30 * 60_000)
                }
            }
        }).catch(()=>1);
        if (!recent) await fireEvent(null, null, "ENGINE", "info", `RAW-CAL: scan found no live candidate this window — ${res.error?.slice(0, 120) ?? "no setup"}`);
        return {
            issued: false,
            note: res.error?.slice(0, 80)
        };
    }
    // 5) journal the issue + update state
    const next = {
        ...state,
        issued: state.issued + 1,
        issuedTotal: state.issuedTotal + 1,
        lastIssueAt: new Date().toISOString(),
        lastIssueSerial: res.signal.serial
    };
    await writeState(next);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$heartbeat$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["touchRawcalHeartbeat"])(`ISSUE NX-${String(res.signal.serial).padStart(4, "0")} raw open ${openRaw + 1}/${state.maxOpen}`); // v10.20 — always written (state change)
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rawcal$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordRawcalSnapshot"])(`ISSUE NX-${String(res.signal.serial).padStart(4, "0")}`, true).catch(()=>undefined); // v9.2 — instant book-curve reaction
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
    const milestone = next.issued % 5 === 0 || settledN + 1 >= state.target;
    await fireEvent(null, res.signal.symbol, "ENGINE", milestone ? "ai" : "info", `RAW-CAL ISSUE #${next.issued} → NX-${String(res.signal.serial).padStart(4, "0")} ${res.signal.direction} ${res.signal.symbol} @ ${res.signal.entryPrice} (${res.signal.strategy}, score ${res.signal.confidence}%) — unfiltered capture record, tracked + journaled to ENGINE MEMORY · EPOCH-2 book ${settledN + 1}/${state.target} settled · open raw ${openRaw + 1}/${state.maxOpen}${settledN + 1 >= state.target ? " — TARGET REACHED, mode auto-cancels next tick" : ""}`);
    return {
        issued: true,
        serial: res.signal.serial
    };
}
// ── v11.5 CAPTURE-BOOK REGIME GAUGE (operator question 2026-10-12: «آیا
// رژیم‌سنجی قبل از اعتماد به کتاب کپچر اضافه شده؟») ──
// Two-part engineering answer, both auditable:
//   1) AT ISSUE TIME — the LAYER-0 regime ruling (regimeRuling, engine.ts
//      evaluate()) is NOT bypassed by calCapture: a candidate standing in a
//      vetoed regime (BREAKOUT/MOMENTUM in chop at guard L1, counter-trend
//      mean-revert in trends) never becomes a capture row. Every issued row
//      then carries its REGIME-* tag for life.
//   2) BEFORE TRUSTING THE BOOK — the settled capture book is split BY REGIME
//      (n / WR / net $) so the operator and the AI core trust capture-derived
//      conclusions per regime, not book-wide (a CHOP-heavy book must never be
//      read as a trend verdict). Surfaced on /api/rawcal + RawCalCard.
const REGIME_LABELS = {
    "TREND-UP": "TREND ▲",
    "TREND-DOWN": "TREND ▼",
    CHOP: "CHOP ∿",
    VOLATILE: "VOLATILE ⚡",
    UNKNOWN: "UNKNOWN"
};
async function captureBookRegimeSplit() {
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            tags: true,
            status: true,
            reachedTp: true,
            marginUsd: true,
            pnlPercent: true
        }
    });
    const map = new Map();
    for (const r of rows){
        const tag = r.tags?.split(",").find((t)=>t.startsWith("REGIME-"))?.replace("REGIME-", "") ?? "UNKNOWN";
        const cell = map.get(tag) ?? {
            n: 0,
            wins: 0,
            net: 0
        };
        cell.n += 1;
        if (r.reachedTp >= 1 || r.status === "TP1" || r.status === "TP2" || r.status === "TP3") cell.wins += 1;
        cell.net += r.marginUsd * r.pnlPercent / 100;
        map.set(tag, cell);
    }
    return [
        ...map.entries()
    ].map(([regime, c])=>({
            regime,
            label: REGIME_LABELS[regime] ?? regime,
            n: c.n,
            wins: c.wins,
            winRatePct: c.n ? Number((c.wins / c.n * 100).toFixed(1)) : 0,
            netUsd: Number(c.net.toFixed(2))
        })).sort((a, b)=>b.n - a.n);
}
async function rawCalStatus() {
    const state = await getRawCalState();
    const [settledN, openRaw, totalRaw] = await Promise.all([
        epoch2SettledCount(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                },
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }).catch(()=>0),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                tags: {
                    contains: "RAW-CAL"
                }
            }
        }).catch(()=>0)
    ]);
    const settledRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        }
    }).catch(()=>0);
    const winsRaw = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
        where: {
            tags: {
                contains: "RAW-CAL"
            },
            reachedTp: {
                gte: 1
            }
        }
    }).catch(()=>0);
    // Task 34-2 — ARMS-COUPLED PACE: the AI CALIBRATION bar now reports the
    // shadow-veto arm completion it is geared to (operator mandate 2026-09-26);
    // fail-soft: any probe error keeps the block null instead of breaking status.
    const armsCompletion = await __turbopack_context__.A("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript, async loader)").then(async (m)=>m.shadowArmsCompletion((await m.getShadowVetoConfig()).mode)).catch(()=>null);
    // v11.5 capture-book regime gauge (operator question: رژیم‌سنجی قبل از اعتماد)
    const regimeSplit = await captureBookRegimeSplit().catch(()=>[]);
    // v14.6 winner-lane auto-abort guard (observability on /api/rawcal)
    const v146 = await getV146Guard().catch(()=>null);
    return {
        ...state,
        settledN,
        needed: Math.max(0, state.target - settledN),
        openRaw,
        issuedTotal: totalRaw,
        settledRaw,
        winsRaw,
        rawWinRatePct: settledRaw ? Number((winsRaw / settledRaw * 100).toFixed(1)) : null,
        spacingMin: state.spacingMin,
        maxOpen: state.maxOpen,
        armsCompletion,
        regimeSplit,
        v146
    };
}
}),
"[project]/src/lib/pump-performance.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PUMP_PERFORMANCE_KEY",
    ()=>PUMP_PERFORMANCE_KEY,
    "computePumpPerformance",
    ()=>computePumpPerformance,
    "persistPumpPerformance",
    ()=>persistPumpPerformance,
    "readPersistedPumpPerformance",
    ()=>readPersistedPumpPerformance
]);
// ── v9.1 PUMP/DUMP RADAR · PERFORMANCE FORENSICS + AI JOURNAL ────────────
// Operator mandate 2026-09-13: «ماژول نمایش عملکرد و جورنال برای هوش مرکزی»
// — a performance module and journal FOR THE CENTRAL INTELLIGENCE.
//
// Two products, one module:
//  1. PERFORMANCE (UI + API): per-kind (PUMP/DUMP) success/failure rates,
//     avg MFE/MAE at resolution, resolution-time distributions, 24h activity,
//     top symbols, best/worst tracks — all measured from the PumpTrack ledger.
//  2. JOURNAL (AI core): a compact digest persisted to EngineSetting
//     "pump.performance" (same channel the governor/advisor read) AND
//     injected into buildEngineMemory() → the analyst prompt + ENGINE MEMORY
//     card + governor context consume it as ground truth. Journal entries
//     mirror the recent PUMP_RADAR SignalEvents (declare/unlock/deploy lines).
//
// Read-only forensics on the ledger — the radar engine itself is untouched.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
async function computePumpPerformance() {
    const [tracks, journalRows] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pumpTrack.findMany({
            orderBy: {
                detectedAt: "desc"
            },
            take: 600
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.findMany({
            where: {
                type: "PUMP_RADAR"
            },
            orderBy: {
                createdAt: "desc"
            },
            take: 12
        })
    ]);
    const resolvedRows = tracks.filter((t)=>t.outcome !== null);
    const success = resolvedRows.filter((t)=>t.outcome === "SUCCESS");
    const failure = resolvedRows.filter((t)=>t.outcome === "FAILURE");
    const pending = tracks.filter((t)=>t.outcome === null).length;
    const spawnedSignals = tracks.filter((t)=>t.signalId !== null).length;
    const kindRow = (kind)=>{
        const rows = resolvedRows.filter((t)=>t.kind === kind);
        const succ = rows.filter((t)=>t.outcome === "SUCCESS").length;
        const resMins = rows.filter((t)=>t.resolvedAt).map((t)=>(t.resolvedAt.getTime() - t.detectedAt.getTime()) / 60_000);
        return {
            kind,
            resolved: rows.length,
            success: succ,
            failure: rows.length - succ,
            successRatePct: rows.length ? Number((succ / rows.length * 100).toFixed(1)) : 0,
            avgMfePct: rows.length ? Number((rows.reduce((a, t)=>a + t.mfePct, 0) / rows.length).toFixed(2)) : 0,
            avgMaePct: rows.length ? Number((rows.reduce((a, t)=>a + t.maePct, 0) / rows.length).toFixed(2)) : 0,
            avgResolutionMin: resMins.length ? Number((resMins.reduce((a, b)=>a + b, 0) / resMins.length).toFixed(1)) : 0
        };
    };
    const dayAgo = Date.now() - 24 * 3600_000;
    const recent = tracks.filter((t)=>t.detectedAt.getTime() >= dayAgo);
    const symAcc = new Map();
    for (const t of tracks){
        const cell = symAcc.get(t.symbol) ?? {
            tracks: 0,
            success: 0
        };
        cell.tracks++;
        if (t.outcome === "SUCCESS") cell.success++;
        symAcc.set(t.symbol, cell);
    }
    const bestResolved = [
        ...resolvedRows
    ].sort((a, b)=>b.mfePct - a.mfePct)[0] ?? null;
    const worstResolved = [
        ...resolvedRows
    ].sort((a, b)=>b.maePct - a.maePct)[0] ?? null;
    const rate = resolvedRows.length ? Number((success.length / resolvedRows.length * 100).toFixed(1)) : 0;
    const k = kindRow("PUMP");
    const d = kindRow("DUMP");
    const headline = resolvedRows.length ? `Radar resolved ${resolvedRows.length} tracks at ${rate}% success — PUMP ${k.success}/${k.resolved} (${k.successRatePct}%) vs DUMP ${d.success}/${d.resolved} (${d.successRatePct}%); detector honesty held: criteria fixed at declaration, no post-hoc rescoring.` : "Radar ledger warming — no resolved tracks yet.";
    return {
        at: new Date().toISOString(),
        totals: {
            tracks: tracks.length,
            resolved: resolvedRows.length,
            success: success.length,
            failure: failure.length,
            pending,
            successRatePct: rate,
            spawnedSignals
        },
        perKind: [
            k,
            d
        ],
        window24h: {
            declared: recent.length,
            success: recent.filter((t)=>t.outcome === "SUCCESS").length,
            failure: recent.filter((t)=>t.outcome === "FAILURE").length
        },
        topSymbols: [
            ...symAcc.entries()
        ].map(([symbol, v])=>({
                symbol,
                tracks: v.tracks,
                success: v.success,
                successRatePct: v.tracks ? Number((v.success / v.tracks * 100).toFixed(1)) : 0
            })).sort((a, b)=>b.tracks - a.tracks).slice(0, 6),
        best: bestResolved ? {
            symbol: bestResolved.symbol,
            kind: bestResolved.kind,
            mfePct: bestResolved.mfePct,
            outcome: bestResolved.outcome,
            detectedAt: bestResolved.detectedAt.toISOString()
        } : null,
        worst: worstResolved ? {
            symbol: worstResolved.symbol,
            kind: worstResolved.kind,
            maePct: worstResolved.maePct,
            outcome: worstResolved.outcome,
            detectedAt: worstResolved.detectedAt.toISOString()
        } : null,
        headline,
        journal: journalRows.map((e)=>({
                at: e.createdAt.toISOString(),
                level: e.level,
                message: e.message.slice(0, 220)
            }))
    };
}
const PUMP_PERFORMANCE_KEY = "pump.performance";
const PERSIST_DEBOUNCE_MS = 30 * 60_000;
async function persistPumpPerformance(perf, force = false) {
    const prev = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
        where: {
            key: PUMP_PERFORMANCE_KEY
        }
    }).catch(()=>null);
    if (prev && !force) {
        try {
            const p = JSON.parse(prev.value);
            if (p.at && Date.now() - new Date(p.at).getTime() < PERSIST_DEBOUNCE_MS) return false;
        } catch  {
        /* corrupted previous row → overwrite */ }
    }
    const digest = {
        at: perf.at,
        headline: perf.headline,
        totals: perf.totals,
        perKind: perf.perKind,
        window24h: perf.window24h,
        topSymbols: perf.topSymbols,
        best: perf.best,
        worst: perf.worst
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: PUMP_PERFORMANCE_KEY
        },
        create: {
            key: PUMP_PERFORMANCE_KEY,
            value: JSON.stringify(digest)
        },
        update: {
            value: JSON.stringify(digest)
        }
    });
    return true;
}
async function readPersistedPumpPerformance() {
    const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
        where: {
            key: PUMP_PERFORMANCE_KEY
        }
    }).catch(()=>null);
    if (!row) return null;
    try {
        return JSON.parse(row.value);
    } catch  {
        return null;
    }
}
}),
"[project]/src/lib/entry-context.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BOTTOM_FADE_DEFAULTS",
    ()=>BOTTOM_FADE_DEFAULTS,
    "EMPTY_CTX",
    ()=>EMPTY_CTX,
    "VREV_DEFAULTS",
    ()=>VREV_DEFAULTS,
    "bottomFadeVerdict",
    ()=>bottomFadeVerdict,
    "computeTapeContext",
    ()=>computeTapeContext,
    "getDeployTapeContext",
    ()=>getDeployTapeContext,
    "vRevVerdict",
    ()=>vRevVerdict
]);
// ── v12.1 TASK-48 ENTRY-CONTEXT — bottom-fade + V-reversal deploy context ──
// Operator mandate 2026-10-19: «پیشنهادها را کامل و مهندسی اجرا کن» — the four
// Task-47 APRUSDT/BRUSDT forensics proposals, items ③+④. Pure decision math
// (unit-replayable) + one DB-tape reader (engine's own PricePoint history).
//
// EVIDENCE BASE (scripts/verify-task48-guards.ts, Tehran 10-18 book):
//   deep stops  — NX-2770 APR SHORT: RSI 18.0 oversold, entry 23% of ±30min
//                 range, price had ALREADY bounced +3.71% off the local low
//                 (the inverse-V pump leg began at 09:35); NX-2779 BRU SHORT:
//                 %B −0.01 below lower band, entry 25% of range; NX-2769 BTW
//                 SHORT: %B −0.25 stretched, entry 19% of range.
//   winners     — 14/14 recent +9..+70% SHORT winners carried RSI 30.2–47.3,
//                 %B 0.03–0.53, bounce-off-low ≤ 0.92% — the guards below are
//                 tuned to separate exactly these two cohorts (verified 0
//                 false blocks on the winner control set).
// Doctrine: the guards NEVER block operator-forced deploys; RAW-CAL capture
// rides through tagged (same audited-override doctrine as LIQUIDITY-FLOOR /
// PHANTOM-FEED / REENTRY-LOCKOUT). Fail-open on internal error — a context
// guard must never wedge the deploy path.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indicators.ts [app-route] (ecmascript)");
;
;
const BOTTOM_FADE_DEFAULTS = {
    enabled: true,
    bottomPct: 30,
    rsiMax: 25,
    bbMax: 0,
    rangeMinutes: 30
};
const VREV_DEFAULTS = {
    enabled: true,
    bouncePct: 1.5,
    minRangePct: 2.5,
    enforceLongMirror: false,
    rangeMinutes: 30
};
const EMPTY_CTX = {
    ok: false,
    points: 0,
    lo: 0,
    hi: 0,
    heightPct: 0,
    entryHeightPct: 50,
    bounceOffLowPct: 0,
    dropOffHighPct: 0
};
function computeTapeContext(points, entry, nowMs, rangeMinutes = 30) {
    const from = nowMs - (rangeMinutes + 2) * 60_000;
    const to = nowMs + 5 * 60_000;
    const win = points.filter((pt)=>pt.t >= from && pt.t <= to && pt.p > 0);
    if (win.length < 4 || !(entry > 0)) return {
        ...EMPTY_CTX
    };
    const lo = Math.min(...win.map((pt)=>pt.p));
    const hi = Math.max(...win.map((pt)=>pt.p));
    if (!(hi > lo) || lo <= 0) return {
        ...EMPTY_CTX,
        points: win.length
    };
    const heightPct = (hi - lo) / lo * 100;
    const entryHeightPct = (entry - lo) / (hi - lo) * 100;
    return {
        ok: true,
        points: win.length,
        lo,
        hi,
        heightPct,
        entryHeightPct,
        bounceOffLowPct: (entry - lo) / lo * 100,
        dropOffHighPct: (entry - hi) / hi * 100
    };
}
function bottomFadeVerdict(ctx, closes15m, direction, cfg) {
    const rsi14 = closes15m && closes15m.length >= 15 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["rsi"])(closes15m) : null;
    const bbB = closes15m && closes15m.length >= 20 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bollingerPercentB"])(closes15m) : null;
    if (!cfg.enabled || direction !== "SHORT" || !ctx.ok) {
        return {
            blocked: false,
            shadow: false,
            reason: "",
            rsi14,
            bbB
        };
    }
    if (ctx.entryHeightPct > cfg.bottomPct) {
        return {
            blocked: false,
            shadow: false,
            reason: "",
            rsi14,
            bbB
        };
    }
    const oversold = rsi14 !== null && rsi14 <= cfg.rsiMax;
    const stretched = bbB !== null && bbB <= cfg.bbMax;
    if (!oversold && !stretched) {
        return {
            blocked: false,
            shadow: false,
            reason: "",
            rsi14,
            bbB
        };
    }
    return {
        blocked: true,
        shadow: false,
        reason: `selling the bottom ${cfg.bottomPct.toFixed(0)}% of the ±${cfg.rangeMinutes}m range (entry at ${ctx.entryHeightPct.toFixed(0)}% height, range ${ctx.heightPct.toFixed(1)}%) with ${oversold ? `RSI ${rsi14.toFixed(1)} ≤ ${cfg.rsiMax}` : `%B ${bbB.toFixed(2)} ≤ ${cfg.bbMax}`} — support-fade class (Task-48 evidence: NX-2770 RSI 18 / NX-2779 %B −0.01 / NX-2769 %B −0.25 = −$18.42 combined)`,
        rsi14,
        bbB
    };
}
function vRevVerdict(ctx, direction, cfg) {
    if (!cfg.enabled || !ctx.ok) return {
        blocked: false,
        shadow: false,
        reason: "",
        rsi14: null,
        bbB: null
    };
    const rangeMaterial = ctx.heightPct >= cfg.minRangePct;
    if (!rangeMaterial) return {
        blocked: false,
        shadow: false,
        reason: "",
        rsi14: null,
        bbB: null
    };
    if (direction === "SHORT") {
        if (ctx.bounceOffLowPct >= cfg.bouncePct) {
            return {
                blocked: true,
                shadow: false,
                reason: `young V-reversal — price already bounced +${ctx.bounceOffLowPct.toFixed(2)}% off the ±${cfg.rangeMinutes}m low (entry at ${ctx.entryHeightPct.toFixed(0)}% of a ${ctx.heightPct.toFixed(1)}% range) — shorting the first leg of a V (Task-48 evidence: NX-2770 bounced +3.71% at entry → +21% pump within 39m)`,
                rsi14: null,
                bbB: null
            };
        }
        return {
            blocked: false,
            shadow: false,
            reason: "",
            rsi14: null,
            bbB: null
        };
    }
    // LONG mirror — shadow only unless enforceLongMirror is enabled
    if (Math.abs(ctx.dropOffHighPct) >= cfg.bouncePct) {
        return {
            blocked: cfg.enforceLongMirror,
            shadow: !cfg.enforceLongMirror,
            reason: `[${cfg.enforceLongMirror ? "ENFORCED" : "SHADOW"}] V-collapse mirror — price already dropped ${ctx.dropOffHighPct.toFixed(2)}% off the ±${cfg.rangeMinutes}m high (entry at ${ctx.entryHeightPct.toFixed(0)}% of a ${ctx.heightPct.toFixed(1)}% range) — buying the first leg of an inverse-V`,
            rsi14: null,
            bbB: null
        };
    }
    return {
        blocked: false,
        shadow: false,
        reason: "",
        rsi14: null,
        bbB: null
    };
}
const ctxMemo = new Map();
const CTX_MEMO_TTL = 30_000;
async function getDeployTapeContext(symbol, entry, rangeMinutes = 30) {
    const key = `${symbol}|${rangeMinutes}`;
    const hit = ctxMemo.get(key);
    const now = Date.now();
    if (hit && now - hit.at < CTX_MEMO_TTL && hit.ok) {
        // lo/hi are entry-independent — recompute only the entry-relative geometry
        if (!(hit.hi > hit.lo)) return {
            ...EMPTY_CTX,
            points: hit.points
        };
        const heightPct = (hit.hi - hit.lo) / hit.lo * 100;
        return {
            ok: true,
            points: hit.points,
            lo: hit.lo,
            hi: hit.hi,
            heightPct,
            entryHeightPct: (entry - hit.lo) / (hit.hi - hit.lo) * 100,
            bounceOffLowPct: (entry - hit.lo) / hit.lo * 100,
            dropOffHighPct: (entry - hit.hi) / hit.hi * 100
        };
    }
    try {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pricePoint.findMany({
            where: {
                symbol,
                createdAt: {
                    gte: new Date(now - (rangeMinutes + 3) * 60_000)
                }
            },
            orderBy: {
                createdAt: "asc"
            },
            select: {
                price: true,
                createdAt: true
            }
        });
        const ctx = computeTapeContext(rows.map((r)=>({
                t: r.createdAt.getTime(),
                p: r.price
            })), entry, now, rangeMinutes);
        ctxMemo.set(key, {
            at: now,
            lo: ctx.lo,
            hi: ctx.hi,
            points: ctx.points,
            ok: ctx.ok
        });
        return ctx;
    } catch  {
        return {
            ...EMPTY_CTX
        };
    }
}
}),
"[project]/src/lib/execution/state-machine.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * NEXUS//SIGNALS — order execution state machine (LIVE-HARDENING Phase 4).
 *
 * Deterministic, auditable, fail-closed. Per the master task the required
 * states and transitions are encoded EXACTLY as specified; anything not in
 * the table is rejected. Unknown state => hard refusal (never guess).
 *
 * Non-bypassability: the ONLY way out of RISK_APPROVED toward ORDER_SUBMITTED
 * runs through riskEngine.assess() (see transitionFrom with riskContext).
 * Strategy code has no alternate door — this module is the door.
 *
 * Real orders: structurally absent. `submitOrder` accepts an ExecutionAdapter;
 * this repository ships ONLY the paper adapter. Wiring a real adapter requires
 * an explicit future operator action AND passing every Phase-13 gate.
 */ __turbopack_context__.s([
    "ALLOWED_TRANSITIONS",
    ()=>ALLOWED_TRANSITIONS,
    "OPEN_ORDER_STATES",
    ()=>OPEN_ORDER_STATES,
    "OrderBook",
    ()=>OrderBook,
    "TERMINAL_STATES",
    ()=>TERMINAL_STATES,
    "clientOrderId",
    ()=>clientOrderId,
    "entryGate",
    ()=>entryGate,
    "isPositionHealthy",
    ()=>isPositionHealthy,
    "promoteToRiskApproved",
    ()=>promoteToRiskApproved,
    "transition",
    ()=>transition
]);
const ALLOWED_TRANSITIONS = {
    SIGNAL: [
        "ELIGIBLE",
        "QUARANTINED",
        "FAILED"
    ],
    ELIGIBLE: [
        "RISK_APPROVED",
        "QUARANTINED",
        "FAILED"
    ],
    RISK_APPROVED: [
        "ORDER_SUBMITTED",
        "QUARANTINED",
        "FAILED"
    ],
    ORDER_SUBMITTED: [
        "ACKNOWLEDGED",
        "FAILED"
    ],
    ACKNOWLEDGED: [
        "PARTIALLY_FILLED",
        "FILLED",
        "FAILED",
        "RECONCILING"
    ],
    PARTIALLY_FILLED: [
        "PARTIALLY_FILLED",
        "FILLED",
        "EXITING",
        "FAILED",
        "RECONCILING"
    ],
    FILLED: [
        "PROTECTED",
        "EXITING",
        "FAILED",
        "RECONCILING"
    ],
    PROTECTED: [
        "EXITING",
        "CLOSED",
        "FAILED",
        "RECONCILING"
    ],
    EXITING: [
        "CLOSED",
        "FAILED",
        "RECONCILING"
    ],
    CLOSED: [],
    // reconciliation resolves to the TRUE external state, or quarantines
    RECONCILING: [
        "ACKNOWLEDGED",
        "PARTIALLY_FILLED",
        "FILLED",
        "PROTECTED",
        "CLOSED",
        "QUARANTINED",
        "FAILED"
    ],
    // quarantine releases only through reconciliation (operator-assisted)
    QUARANTINED: [
        "RECONCILING"
    ],
    FAILED: []
};
const TERMINAL_STATES = new Set([
    "CLOSED",
    "FAILED"
]);
const OPEN_ORDER_STATES = new Set([
    "ORDER_SUBMITTED",
    "ACKNOWLEDGED",
    "PARTIALLY_FILLED",
    "FILLED",
    "PROTECTED",
    "EXITING"
]);
function transition(from, to) {
    const allowed = ALLOWED_TRANSITIONS[from];
    if (allowed === undefined) {
        return {
            ok: false,
            code: "UNKNOWN_STATE",
            detail: `state "${String(from)}" is unknown — fail-closed`
        };
    }
    if (!allowed.includes(to)) {
        return {
            ok: false,
            code: "ILLEGAL_TRANSITION",
            detail: `${from} → ${to} not permitted (allowed: ${allowed.join(", ") || "none — terminal"})`
        };
    }
    return {
        ok: true,
        from,
        to
    };
}
function isPositionHealthy(state) {
    return state === "PROTECTED";
}
function entryGate(ctx) {
    if (ctx.killSwitchEngaged) {
        return {
            ok: false,
            code: "KILL_SWITCH",
            detail: "kill-switch engaged — all entries blocked"
        };
    }
    if (ctx.unresolvedOpenStates.length > 0) {
        return {
            ok: false,
            code: "UNRECONCILED_OPEN_STATE",
            detail: `open states require reconciliation before new entries: ${ctx.unresolvedOpenStates.join(",")}`
        };
    }
    if (!ctx.startupReconciled) {
        return {
            ok: false,
            code: "STARTUP_NOT_RECONCILED",
            detail: "startup reconciliation has not passed"
        };
    }
    if (!ctx.dataFresh) {
        return {
            ok: false,
            code: "STALE_DATA",
            detail: "market data stale — fail closed"
        };
    }
    if (!ctx.exchangeConnected) {
        return {
            ok: false,
            code: "DISCONNECTED",
            detail: "exchange feed disconnected — fail closed"
        };
    }
    return {
        ok: true
    };
}
function clientOrderId(signalId, attempt) {
    return `NX-${signalId}-${attempt}`;
}
class OrderBook {
    /** clientOrderId → record; in-memory in the paper domain (persisted by caller) */ orders = new Map();
    /** duplicate submission with the SAME clientOrderId returns the existing record unchanged */ getOrSubmit(signalId, attempt) {
        const id = clientOrderId(signalId, attempt);
        const existing = this.orders.get(id);
        if (existing) return {
            record: existing,
            created: false
        };
        const record = {
            clientOrderId: id,
            signalId,
            state: "SIGNAL",
            history: [
                {
                    at: new Date().toISOString(),
                    from: "NEW",
                    to: "SIGNAL"
                }
            ]
        };
        this.orders.set(id, record);
        return {
            record,
            created: true
        };
    }
    advance(record, to) {
        const r = transition(record.state, to);
        if (r.ok) {
            record.state = to;
            record.history.push({
                at: new Date().toISOString(),
                from: r.from,
                to
            });
        }
        return r;
    }
    findByClientOrderId(id) {
        return this.orders.get(id);
    }
    allOpen() {
        return [
            ...this.orders.values()
        ].filter((o)=>OPEN_ORDER_STATES.has(o.state));
    }
}
function promoteToRiskApproved(from, assessment) {
    if (from !== "ELIGIBLE") {
        return transition(from, "RISK_APPROVED"); // normal table verdict (likely illegal)
    }
    if (!assessment.approved) {
        return {
            ok: false,
            code: assessment.reasonCode ?? "RISK_REJECTED",
            detail: assessment.detail ?? "risk engine declined — non-bypassable"
        };
    }
    return {
        ok: true,
        from,
        to: "RISK_APPROVED"
    };
}
}),
"[project]/src/lib/execution/kill-switch.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KILL_SWITCH_PATH",
    ()=>KILL_SWITCH_PATH,
    "engageKillSwitch",
    ()=>engageKillSwitch,
    "readKillSwitch",
    ()=>readKillSwitch,
    "releaseKillSwitch",
    ()=>releaseKillSwitch
]);
/**
 * NEXUS//SIGNALS — independent kill-switch (LIVE-HARDENING Phase 4).
 *
 * Path-independence: reads a dedicated flag file (.data/execution/kill-switch.json)
 * that strategy/engine code does not own. Even if the engine is wedged, the
 * operator (or watchdog) flipping this file blocks every new entry at the
 * entryGate — the gate consults THIS module, not engine state.
 *
 * Fail-closed semantics:
 *  · missing file            → clean (never engaged) — normal fresh boot
 *  · unreadable/corrupt file → ENGAGED (fail closed) until operator repairs
 *  · engaged.engaged === true → ENGAGED
 */ var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
;
;
const KILL_SWITCH_PATH = "/home/z/my-project/.data/execution/kill-switch.json";
function clean() {
    return {
        engaged: false,
        at: null,
        by: null,
        reason: null
    };
}
function readKillSwitch(path = KILL_SWITCH_PATH) {
    if (!(0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["existsSync"])(path)) return clean();
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(path, "utf8");
        const parsed = JSON.parse(raw);
        if (typeof parsed.engaged !== "boolean") {
            return {
                engaged: true,
                at: new Date().toISOString(),
                by: "system",
                reason: "corrupt kill-switch file (engaged flag not boolean) — fail closed",
                degraded: true
            };
        }
        return parsed;
    } catch  {
        return {
            engaged: true,
            at: new Date().toISOString(),
            by: "system",
            reason: "unreadable kill-switch file — fail closed",
            degraded: true
        };
    }
}
function engageKillSwitch(by, reason, path = KILL_SWITCH_PATH) {
    const state = {
        engaged: true,
        at: new Date().toISOString(),
        by,
        reason
    };
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"])((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["dirname"])(path), {
        recursive: true
    });
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["writeFileSync"])(path, JSON.stringify(state, null, 2));
    return state;
}
function releaseKillSwitch(by, path = KILL_SWITCH_PATH) {
    const state = {
        engaged: false,
        at: new Date().toISOString(),
        by,
        reason: "released"
    };
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"])((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["dirname"])(path), {
        recursive: true
    });
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["writeFileSync"])(path, JSON.stringify(state, null, 2));
    return state;
}
}),
"[project]/src/lib/open-pnl.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "liveOpenMarkPct",
    ()=>liveOpenMarkPct,
    "openBookNet",
    ()=>openBookNet
]);
// ── NEXUS//SIGNALS OPEN-PNL SINGLE SOURCE OF TRUTH (v12.0 · Task 45 Q2) ─────
// Operator query 2026-10-18: «چرا دستور بسته شدن تمام معاملات با رسیدن open pnl
// به 20$ انجام نمیشه؟ درصورتی که الان UNREALIZED بالای این عدد است»
//
// ROOT CAUSE (audited live): TWO different "unrealized" formulas existed.
//   · ACCOUNT bar (stats.ts) priced 100% of the margin at the CURRENT price on
//     EVERY open row — including settlement-unsafe (sim-sourced) rows. For
//     banked rows (TP1/TP2/BE-bank) this re-prices already-banked tranches at
//     today's mark → overstated book pnl (+$21.31 live vs +$12.9 real).
//   · The v11.5 close-all BREAKER (engine.ts) priced the tranche-aware ladder
//     mark (banked rungs at their rung prices, runner at current mark) and
//     skipped settlement-unsafe rows per the v10.16 doctrine — the honest
//     bankable number.
//   → The documented v11.5 contract («the trigger reads the same number the
//     ACCOUNT bar shows») was violated — by the BAR, not by the breaker.
//     The bar also disagreed with the sum of the position cards themselves
//     (cards carry the per-row tranche-aware pnlPercent stored by the engine).
//
// This module is now THE one open-pnl implementation; both the breaker and the
// ACCOUNT bar call it, so a $20 mandate can never again disagree with the bar:
//   · bankableUsd — breaker semantics: tranche-aware fee-NET mark, live-price,
//     settlement-safe rows only (rows that could actually be banked right now).
//   · allRowsUsd — legacy full-margin-at-current-price over every row with a
//     price (kept as account.unrealizedPnlAllRows for transparency).
// Pure + client-safe (imports only accounting.ts).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accounting.ts [app-route] (ecmascript)");
;
function liveOpenMarkPct(s, movePct, isLong) {
    const moveAtPct = (px)=>(px - s.entryPrice) / s.entryPrice * (isLong ? 1 : -1) * 100;
    if (s.reachedTp >= 1) {
        const beB = s.beBankedMovePct !== null && s.beBankedFrac != null ? {
            frac: s.beBankedFrac,
            movePct: s.beBankedMovePct
        } : null;
        const remain = beB ? 1 - beB.frac : 1;
        const tranches = [];
        if (beB) tranches.push({
            weight: beB.frac,
            movePct: beB.movePct
        });
        tranches.push({
            weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp1 * remain,
            movePct: moveAtPct(s.tp1)
        });
        if (s.reachedTp >= 2) tranches.push({
            weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp2 * remain,
            movePct: moveAtPct(s.tp2)
        });
        tranches.push({
            weight: (1 - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp1 - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp2) * remain,
            movePct
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ladderWeightedMove"])(tranches);
    }
    if (s.beBankedMovePct !== null && s.beBankedFrac != null) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ladderWeightedMove"])([
            {
                weight: s.beBankedFrac,
                movePct: s.beBankedMovePct
            },
            {
                weight: 1 - s.beBankedFrac,
                movePct
            }
        ]);
    }
    return movePct;
}
function openBookNet(rows, now) {
    let bankableUsd = 0;
    let allRowsUsd = 0;
    const included = [];
    const skipped = [];
    for (const r of rows){
        const s = r.signal;
        if (!(r.price > 0)) {
            skipped.push({
                symbol: s.symbol,
                reason: "no-price"
            });
            continue;
        }
        const isLong = s.direction === "LONG";
        const movePct = (r.price - s.entryPrice) / s.entryPrice * (isLong ? 1 : -1) * 100;
        const heldMin = Math.max(0, (now - s.createdAt.getTime()) / 60_000);
        // legacy display mark: 100% of margin at the current price (old ACCOUNT bar)
        allRowsUsd += (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(s.marginUsd, s.leverage, movePct, heldMin).netUsd;
        if (!r.safe) {
            skipped.push({
                symbol: s.symbol,
                reason: "settlement-unsafe"
            });
            continue;
        }
        const mark = liveOpenMarkPct(s, movePct, isLong);
        const netUsd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(s.marginUsd, s.leverage, mark, heldMin).netUsd;
        bankableUsd += netUsd;
        included.push({
            id: s.id,
            symbol: s.symbol,
            price: r.price,
            markPct: Number(mark.toFixed(2)),
            netUsd: Number(netUsd.toFixed(4))
        });
    }
    return {
        bankableUsd,
        allRowsUsd,
        included,
        skipped
    };
}
}),
"[project]/src/lib/close-all.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CLOSEALL_DEFAULT_TARGET",
    ()=>CLOSEALL_DEFAULT_TARGET,
    "CLOSEALL_KEY",
    ()=>CLOSEALL_KEY,
    "getCloseAllState",
    ()=>getCloseAllState,
    "recordCloseAllTrigger",
    ()=>recordCloseAllTrigger,
    "setCloseAllState",
    ()=>setCloseAllState
]);
// ── v11.5 GLOBAL OPEN-PNL CLOSE-ALL BREAKER (operator mandate 2026-10-12) ──
// «اگر مجموع open pnl به 20$ رسید تمام معاملات بسته شود»
//
// BOOK-LEVEL PROFIT-LOCK CIRCUIT BREAKER: when the SUM of unrealized (fee-NET)
// PnL across ALL open signals reaches the target (default +$20), the engine
// closes EVERY open signal at the current live mark in ONE audited sweep —
// the book's aggregate open profit is banked instead of riding round-trips.
//
// Design contract:
//   · NET accounting — the trigger reads the same fee-NET unrealized number
//     the dashboard's ACCOUNT bar shows (feeBreakdown on the tranche-aware
//     live mark), not gross.
//   · Honest settlement — every closed row settles with the engine's standard
//     math (tranche-aware for banked rungs, feeBreakdown NET, real fees),
//     status CLOSED + tag CLOSE-ALL, per-row event + one summary event.
//   · Fail-soft — rows whose symbol has no live price are NOT invented-
//     settled; they stay open for the normal settlement loop (v10.16
//     settlement-staleness doctrine) and the breaker re-fires next tick.
//   · Operator-tunable — enabled/targetUsd live in EngineSetting
//     "closeall.state" (POST /api/closeall, x-nexus-key/session gated by the
//     control-plane middleware); defaults ON at $20.
//   · FLAT-10 untouched — margin is never resized; this is an exit rule.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const CLOSEALL_KEY = "closeall.state";
const CLOSEALL_DEFAULT_TARGET = 20;
const DEFAULT_STATE = {
    enabled: true,
    targetUsd: CLOSEALL_DEFAULT_TARGET,
    lastTriggeredAt: null,
    triggerCount: 0,
    lastClosedN: null,
    lastClosedUsd: null
};
async function getCloseAllState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: CLOSEALL_KEY
            }
        });
        if (!row) return {
            ...DEFAULT_STATE
        };
        const raw = {
            ...DEFAULT_STATE,
            ...JSON.parse(row.value)
        };
        const num = (v, dflt)=>typeof v === "number" && Number.isFinite(v) && v > 0 ? v : dflt;
        return {
            enabled: typeof raw.enabled === "boolean" ? raw.enabled : DEFAULT_STATE.enabled,
            targetUsd: num(raw.targetUsd, CLOSEALL_DEFAULT_TARGET),
            lastTriggeredAt: typeof raw.lastTriggeredAt === "string" ? raw.lastTriggeredAt : null,
            triggerCount: num(raw.triggerCount, 0),
            lastClosedN: typeof raw.lastClosedN === "number" && Number.isFinite(raw.lastClosedN) ? raw.lastClosedN : null,
            lastClosedUsd: typeof raw.lastClosedUsd === "number" && Number.isFinite(raw.lastClosedUsd) ? raw.lastClosedUsd : null
        };
    } catch  {
        return {
            ...DEFAULT_STATE
        };
    }
}
async function setCloseAllState(patch) {
    const cur = await getCloseAllState();
    const next = {
        ...cur,
        ...typeof patch.enabled === "boolean" ? {
            enabled: patch.enabled
        } : {},
        ...typeof patch.targetUsd === "number" && Number.isFinite(patch.targetUsd) && patch.targetUsd > 0 ? {
            targetUsd: Math.min(500, Math.max(1, patch.targetUsd))
        } : {}
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: CLOSEALL_KEY
        },
        create: {
            key: CLOSEALL_KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
    return next;
}
async function recordCloseAllTrigger(closedN, closedUsd) {
    const cur = await getCloseAllState();
    const next = {
        ...cur,
        lastTriggeredAt: new Date().toISOString(),
        triggerCount: cur.triggerCount + 1,
        lastClosedN: closedN,
        lastClosedUsd: Number(closedUsd.toFixed(2))
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: CLOSEALL_KEY
        },
        create: {
            key: CLOSEALL_KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
}
}),
"[project]/src/lib/sizing.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MIN_NOTIONAL_DEFAULT_USD",
    ()=>MIN_NOTIONAL_DEFAULT_USD,
    "MIN_NOTIONAL_OVERRIDES",
    ()=>MIN_NOTIONAL_OVERRIDES,
    "SIZING_DEFAULTS",
    ()=>SIZING_DEFAULTS,
    "SIZING_KEY",
    ()=>SIZING_KEY,
    "SIZING_MODES",
    ()=>SIZING_MODES,
    "computeMarginBase",
    ()=>computeMarginBase,
    "getConsecutiveSlCount",
    ()=>getConsecutiveSlCount,
    "getSizingConfig",
    ()=>getSizingConfig,
    "minNotionalUsd",
    ()=>minNotionalUsd,
    "setSizingConfig",
    ()=>setSizingConfig,
    "tradeableFloorMargin",
    ()=>tradeableFloorMargin
]);
// ── MARGIN SIZING MODES (Task 65 — operator mandate «فرمول پیشنهادی را کامل
// و مهارندسی اجرا کن») ────────────────────────────────────────────────────
// Backtest verdict (2026-10-02, 1031 closed signals, no-lookahead):
//   CONFIDENCE (legacy, equity×2..8% linear in conf)  → −$10.65 · PF 0.837
//   FLAT $2                                           → −$3.02 · PF 0.979
//   ANTI_MARTINGALE base$2 ×0.5 after each SL         → +$2.99 · PF 1.064
// Root cause: the 68 biggest-margin trades (m ≥ $2, conf 77-94) produced 88%
// of ALL net losses — confidence had zero outcome correlation (r=+0.027) and
// loss clusters got the biggest checks. Sizing NEVER changes pnlPercent or
// win-rate — it only re-weights dollars (honest doctrine note).
//
// Engineering contract:
//  · computeMarginBase returns the BASE — the whole governor/regime/risk
//    overlay stack in engine.ts (riskPerTrade, regimeSize, crowdCut,
//    shortSizeMult, probation, riskMult, …) multiplies ANY base unchanged.
//  · The consecutive-SL run is recomputed from the DB at every deploy
//    (stateless, restart-proof, recycle-proof) — parity with the backtest
//    walk: SL increments, TP1/TP2/TP3 restores, EXPIRED/CLOSED ignored.
//  · Mode lives in EngineSetting("sizing.mode") — live-switchable, no restart.
//  · Safety clamps (floor / freeMargin / 10%-equity cap) never bind at the
//    current ~$90 equity but protect a shrunken account.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accounting.ts [app-route] (ecmascript)");
;
;
const SIZING_KEY = "sizing.mode";
const SIZING_MODES = [
    "CONFIDENCE",
    "FLAT",
    "ANTI_MARTINGALE"
];
const SIZING_DEFAULTS = {
    mode: "CONFIDENCE",
    flatBase: 2,
    antiBase: 2,
    decay: 0.5,
    floor: 0.5,
    consecCap: 4
};
function sanitize(raw) {
    const cfg = {
        ...SIZING_DEFAULTS
    };
    if (!raw) return cfg;
    if (raw.mode && SIZING_MODES.includes(raw.mode)) cfg.mode = raw.mode;
    for (const k of [
        "flatBase",
        "antiBase",
        "decay",
        "floor",
        "consecCap"
    ]){
        const v = Number(raw[k]);
        if (Number.isFinite(v) && v > 0) cfg[k] = v;
    }
    if (cfg.decay > 0.95) cfg.decay = 0.95; // must actually decay
    if (cfg.consecCap > 8) cfg.consecCap = 8;
    return cfg;
}
async function getSizingConfig() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: SIZING_KEY
            }
        });
        return sanitize(row ? JSON.parse(row.value) : null);
    } catch  {
        return {
            ...SIZING_DEFAULTS
        };
    }
}
async function setSizingConfig(patch) {
    const next = sanitize({
        ...await getSizingConfig(),
        ...patch
    });
    const value = JSON.stringify(next);
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: SIZING_KEY
        },
        update: {
            value
        },
        create: {
            key: SIZING_KEY,
            value
        }
    });
    return next;
}
async function getConsecutiveSlCount(cfg) {
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            closedAt: {
                not: null
            }
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 60,
        select: {
            status: true
        }
    });
    let k = 0;
    for (const r of rows){
        if (r.status === "SL") {
            k++;
            if (k >= cfg.consecCap) break;
        } else if (r.status === "TP1" || r.status === "TP2" || r.status === "TP3") {
            break;
        }
    }
    return k;
}
const MIN_NOTIONAL_DEFAULT_USD = 5;
const MIN_NOTIONAL_OVERRIDES = {
    BTCUSDT: 50,
    ETHUSDT: 20
};
function minNotionalUsd(symbol) {
    return MIN_NOTIONAL_OVERRIDES[symbol.toUpperCase()] ?? MIN_NOTIONAL_DEFAULT_USD;
}
function tradeableFloorMargin(symbol, leverage) {
    return minNotionalUsd(symbol) / Math.max(1, leverage);
}
async function computeMarginBase(cfg, confidence, equity, freeMargin) {
    const room = Math.max(0, Math.min(freeMargin, equity * 0.1));
    if (cfg.mode === "FLAT") {
        const margin = Number(Math.max(cfg.floor, Math.min(cfg.flatBase, room)).toFixed(2));
        return {
            margin,
            mode: "FLAT",
            consecSl: 0
        };
    }
    if (cfg.mode === "ANTI_MARTINGALE") {
        const k = await getConsecutiveSlCount(cfg);
        const margin = Number(Math.max(cfg.floor, Math.min(cfg.antiBase, room) * Math.pow(cfg.decay, k)).toFixed(2));
        return {
            margin,
            mode: "ANTI_MARTINGALE",
            consecSl: k
        };
    }
    return {
        margin: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["confidenceMargin"])(confidence, equity, freeMargin),
        mode: "CONFIDENCE",
        consecSl: 0
    };
}
}),
"[project]/src/lib/ttl-gate.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bumpTtlTelemetry",
    ()=>bumpTtlTelemetry,
    "evaluateTtlExtension",
    ()=>evaluateTtlExtension,
    "getTtlTelemetry",
    ()=>getTtlTelemetry
]);
// ── FlowRadar Neo v6.1 DYNAMIC EXPIRY GATE (server-only) ────────────────
// Post-expiry afterlife evidence showed most expiries reach TP afterwards
// (64% would-have-won at the time of implementation). This module owns the
// gate: a DETERMINISTIC policy evaluator (every input measured) plus the
// telemetry loop the AI governor uses to tune its own knobs
// (set_ttl_extend_max / set_ttl_extend_minutes / set near-TP band via gates).
// Zero manual modes — the governor is the only policy authority.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const TTL_GATE_KEY = "ttl-gate";
const EMPTY = {
    extended: 0,
    tpAfter: 0,
    slAfter: 0,
    reExpired: 0,
    capturedUsd: 0,
    denied: 0,
    deniedNearTp: 0,
    updatedAt: "1970-01-01T00:00:00.000Z"
};
async function getTtlTelemetry() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: TTL_GATE_KEY
            }
        });
        if (!row) return {
            ...EMPTY
        };
        return {
            ...EMPTY,
            ...JSON.parse(row.value)
        };
    } catch  {
        return {
            ...EMPTY
        };
    }
}
async function bumpTtlTelemetry(patch) {
    try {
        const cur = await getTtlTelemetry();
        const next = {
            extended: cur.extended + (patch.extended ?? 0),
            tpAfter: cur.tpAfter + (patch.tpAfter ?? 0),
            slAfter: cur.slAfter + (patch.slAfter ?? 0),
            reExpired: cur.reExpired + (patch.reExpired ?? 0),
            capturedUsd: Number((cur.capturedUsd + (patch.capturedUsd ?? 0)).toFixed(2)),
            denied: cur.denied + (patch.denied ?? 0),
            deniedNearTp: cur.deniedNearTp + (patch.deniedNearTp ?? 0),
            updatedAt: new Date().toISOString()
        };
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: TTL_GATE_KEY
            },
            create: {
                key: TTL_GATE_KEY,
                value: JSON.stringify(next)
            },
            update: {
                value: JSON.stringify(next)
            }
        });
    } catch  {
    /* telemetry is best-effort — never block signal resolution */ }
}
/** live 20-minute price momentum from recorded PricePoint history (unlevered %) */ async function momentum20m(symbol, price) {
    const since = new Date(Date.now() - 20 * 60_000);
    const [oldest, newest] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pricePoint.findFirst({
            where: {
                symbol,
                createdAt: {
                    gte: since
                }
            },
            orderBy: {
                createdAt: "asc"
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pricePoint.findFirst({
            where: {
                symbol,
                createdAt: {
                    gte: since
                }
            },
            orderBy: {
                createdAt: "desc"
            }
        })
    ]);
    if (!oldest || !newest || oldest.price <= 0) return 0; // sparse tape → neutral pass
    return (price - oldest.price) / oldest.price * 100;
}
async function evaluateTtlExtension(s, price, movePct, gate, now) {
    const nextTp = s.status === "ACTIVE" ? s.tp1 : s.status === "TP1" ? s.tp2 : s.tp3;
    const distTpPct = Math.abs(nextTp - price) / price * 100; // remaining unlevered journey to the next rung
    const band = s.strategy === "AI-SWING" ? Math.max(gate.ttlNearTpPct * 2, 8) : gate.ttlNearTpPct; // v6.6 per-strategy widening
    const bandNote = s.strategy === "AI-SWING" ? ` (AI-SWING widened band ${band.toFixed(1)}% = max(${gate.ttlNearTpPct}%×2, 8))` : "";
    const nearTp = distTpPct <= band * 2;
    const swingNote = s.strategy === "AI-SWING" ? ` · band ${band.toFixed(1)}% (AI-SWING)` : "";
    // 1) budget — each signal gets at most ttlExtendMax grants (0 disables);
    //    v6.6 RE-ARM: one extra grant beyond budget when in profit AND within
    //    half the band — hard cap 2 grants total, never when the gate is off.
    const rearm = gate.ttlExtendMax > 0 && s.ttlExtensions === gate.ttlExtendMax && s.ttlExtensions < 2 && movePct > 0 && distTpPct <= band / 2;
    if (s.ttlExtensions >= gate.ttlExtendMax && !rearm) {
        return {
            grant: false,
            nearTp,
            reason: `extension budget spent (${s.ttlExtensions}/${gate.ttlExtendMax})${s.ttlExtensions < 2 ? " · re-arm needs profit + <" + (band / 2).toFixed(1) + "% to next TP" : ""}`
        };
    }
    // 2) lifetime cap — extensions can never exceed 3× the original TTL
    const ageMin = (now.getTime() - s.createdAt.getTime()) / 60_000;
    if (ageMin >= s.ttlMinutes * 3) return {
        grant: false,
        nearTp,
        reason: `lifetime cap 3×TTL reached (${Math.round(ageMin)}m)`
    };
    // 3) v6.6 MFE<0 DENIAL — never add time to a trade under water at expiry
    //    (explicit rule; the 60%-of-risk-distance guard below stays as the harder backstop)
    if (movePct < 0) return {
        grant: false,
        nearTp,
        reason: `under water ${movePct.toFixed(2)}% at expiry — MFE<0 never extends`
    };
    // 4) drawdown guard — never add time to a trade that already spent 60% of its risk distance
    const slDistPct = Math.abs((s.entryPrice - s.stopLoss) / s.entryPrice) * 100;
    if (movePct <= -(0.6 * slDistPct)) return {
        grant: false,
        nearTp,
        reason: `drawdown ${movePct.toFixed(2)}% ≥ 60% of risk distance`
    };
    // 5a) qualification — near the next unbanked TP rung (v6.6 widened for AI-SWING)
    if (distTpPct <= band) {
        const slope = await momentum20m(s.symbol, price);
        return {
            grant: true,
            nearTp,
            reason: `${rearm ? "RE-ARM " : ""}next TP only ${distTpPct.toFixed(2)}% away (≤${band}% band${swingNote}) · 20m momentum ${slope >= 0 ? "+" : ""}${slope.toFixed(2)}%`
        };
    }
    // 5b) v6.1.1 journey-progress rule — in profit AND past the midpoint to the next rung.
    // Afterlife evidence: profitable maturing trades usually finish the trip (64% would-have-won);
    // a shallow pullback in the last 20m must not kill a trade that already covered >50% of the way.
    if (movePct > 0 && movePct >= distTpPct) {
        const slope = await momentum20m(s.symbol, price);
        const journey = movePct + distTpPct;
        return {
            grant: true,
            nearTp,
            reason: `${rearm ? "RE-ARM " : ""}in profit +${movePct.toFixed(2)}% — covered ${(journey > 0 ? 100 * movePct / journey : 0).toFixed(0)}% of the journey to next TP (${distTpPct.toFixed(2)}% away, 20m ${slope >= 0 ? "+" : ""}${slope.toFixed(2)}%)${bandNote}`
        };
    }
    // 5c) qualification — profitably afloat with constructive tape
    if (movePct > 0) {
        const slope = await momentum20m(s.symbol, price);
        if (slope >= 0) return {
            grant: true,
            nearTp,
            reason: `${rearm ? "RE-ARM " : ""}in profit +${movePct.toFixed(2)}% with constructive tape (20m +${slope.toFixed(2)}%)${bandNote}`
        };
    }
    const slope = nearTp ? await momentum20m(s.symbol, price) : 0;
    return {
        grant: false,
        nearTp,
        reason: `no qualification — TP ${distTpPct.toFixed(2)}% away, move ${movePct.toFixed(2)}%, 20m momentum ${slope >= 0 ? "+" : ""}${slope.toFixed(2)}%${bandNote}`
    };
}
}),
"[project]/src/lib/lesson-gate.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "lessonThrAdj",
    ()=>lessonThrAdj
]);
const CACHE_MS = 5 * 60_000; // deep-learn cycles every ~30min — a 5min cache is fresh
const FRESH_MS = 6 * 3600_000; // lessons older than 6h no longer speak
const MIN_CONFIDENCE = 60; // below this the lesson is research noise
const CLAMP_LO = -3; // max loosening (TP3_FULL evidence only)
const CLAMP_HI = 8; // max tightening (anti-loss bias)
const SCOPE_WEIGHT = {
    SL: 1.2,
    MIXED: 1.0,
    TP3_FULL: 0.8
};
// tighten-polarity verbs (loss avoidance language) vs loosen-polarity (edge-admission language)
const TIGHTEN_RE = /(tighten|rais\w*|avoid|reduc\w*|skip|block|filter|require|suppress|throttle|narrow|refuse|lower the size|cut|veto|chop|late)/;
const LOOSEN_RE = /(widen|relax|admit|allow|permit|keep buying|reward|stretch|favored|works)/;
let cache = null;
function evalLessons(lessons) {
    const now = Date.now();
    let adj = 0;
    let applied = 0;
    const bits = [];
    for (const l of lessons){
        const atMs = new Date(l.at).getTime();
        if (!Number.isFinite(atMs) || now - atMs > FRESH_MS) continue;
        if (l.confidence < MIN_CONFIDENCE) continue;
        const text = `${l.pattern} ${l.action}`.toLowerCase();
        const tighten = TIGHTEN_RE.test(text);
        const loosen = !tighten && LOOSEN_RE.test(text);
        if (!tighten && !loosen) continue;
        // contribution 0..~3.6 per lesson, scaled by scope weight (loss lessons weigh most)
        const base = (Math.min(100, l.confidence) - MIN_CONFIDENCE) / (100 - MIN_CONFIDENCE) * 3 * (SCOPE_WEIGHT[l.scope] ?? 1);
        if (tighten) {
            adj += base;
            applied++;
            if (bits.length < 3) bits.push(`${l.scope}:${l.label} +${base.toFixed(1)}`);
        } else if (l.scope === "TP3_FULL") {
            // only FULL-TAKE-PROFIT lessons may loosen the gate — loss lessons never do
            adj -= base * 0.5;
            applied++;
            if (bits.length < 3) bits.push(`TP3_FULL:${l.label} −${(base * 0.5).toFixed(1)}`);
        }
    }
    const clamped = Math.max(CLAMP_LO, Math.min(CLAMP_HI, adj));
    const rounded = Math.round(clamped * 2) / 2; // half-point granularity
    return {
        adj: rounded,
        applied,
        note: applied > 0 ? `LESSON-GATE ${rounded >= 0 ? "+" : ""}${rounded} (${bits.join(" · ")}${bits.length < applied ? ` +${applied - bits.length} more` : ""})` : null
    };
}
async function lessonThrAdj() {
    if (cache && Date.now() - cache.at < CACHE_MS) return cache.res;
    let res = {
        adj: 0,
        note: null,
        applied: 0
    };
    try {
        // dynamic import — tp3-lab drags the AI stack; keep it off the engine's
        // static import graph (cycle-safe, boot-path-light)
        const { getDeepLearnState } = await __turbopack_context__.A("[project]/src/lib/tp3-lab.ts [app-route] (ecmascript, async loader)");
        const st = await getDeepLearnState();
        if (st.lessons.length > 0) res = evalLessons(st.lessons);
    } catch  {
    /* fail-open: no lessons → no adjustment */ }
    cache = {
        at: Date.now(),
        res
    };
    return res;
}
}),
"[project]/src/lib/entry-levers.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_LEVER_PARAMS",
    ()=>DEFAULT_LEVER_PARAMS,
    "ENTRY_LEVER_IDS",
    ()=>ENTRY_LEVER_IDS,
    "ENTRY_LEVER_LABELS",
    ()=>ENTRY_LEVER_LABELS,
    "entryLeverStats",
    ()=>entryLeverStats,
    "entryLeversDeployGate",
    ()=>entryLeversDeployGate,
    "entryLeversState",
    ()=>entryLeversState,
    "evaluateEntryLevers",
    ()=>evaluateEntryLevers,
    "getEntryLeverConfig",
    ()=>getEntryLeverConfig,
    "parseEmaTrendAtr",
    ()=>parseEmaTrendAtr,
    "readJournalTail",
    ()=>readJournalTail,
    "setEntryLeverMode",
    ()=>setEntryLeverMode,
    "syncEntryLeverModes",
    ()=>syncEntryLeverModes
]);
// ── v11.3 ENTRY-LEVERS — the late-entry shield (operator mandate 2026-10-07
// «کامل و مهندسی شده اجرا کن» after the EQ-89/EQ-90 forensics) ──
// DIAGNOSIS (14d ledger, n=1183 settled clean rows): the book does not lose to
// noisy/fake flow data — it loses to SYSTEMATIC LATE ENTRIES. Measured layers:
//   · flow confirmation barely separates (CONFIRMS 30.7% WR vs NEUTRAL 31.6%)
//     and STRONG along-direction flow is negative (score ≥+10: avg −1.73, 55%
//     never reached +5%) — visible agreement is already priced in;
//   · entry extension degrades monotonically: |EMA9−EMA21 trend| ≥60×ATR
//     avg −2.57, ≥120×ATR avg −3.55; worst quadrant lev≥15 × ext≥60 avg −4.74;
//   · chase causes die: WHALE-PUSH WR 13% (n=23), VOL-ONSET↑ WR 10% (n=10,
//     avg −9.37), SESSION-THIN WR 15% (n=13); stale radar fills (>8s) WR 15.8%
//     vs ≤2s 44%; AI-SCALP rows never reached +5% in 66..69% of cases;
//   · leverage ≥15 carried net −696 units (risk-shaping lever, not a veto).
// NOTE (direction-relative audit EQ-90): absolute-sign factor buckets were
// confounded by direction mix — EMA/MACD/VOLUME-CONFIRM vote SIGNS do NOT
// separate once measured relative to trade direction. The shield therefore
// uses ONLY sign-agnostic measurements (extension magnitude, cause labels,
// staleness, leverage, strategy) plus the flow score, which is
// direction-aligned by construction (FlowAssessment: −25..+25 along direction).
// ROLLOUT DOCTRINE = shadow first, evidence-gated enforcement — the same
// ladder as volCause LEARN_GATE and shadow-veto: every deploy is evaluated by
// EVERY lever and journaled; a lever may only enforce after its OWN statistical
// gate passes on settled rows (n≥100 · flagged avg ≤ −0.5 · separation ≥0.5 vs
// unflagged) and is auto-demoted when its flagged cohort heals (avg > +0.3).
// Forced / capture-authority deploys are OBSERVE-ONLY — the shield never
// fights the operator. Fail-open everywhere: an evaluator error must never
// stall a deploy.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const ENTRY_LEVER_IDS = [
    "EXT",
    "FLOW",
    "CAUSE",
    "STALE",
    "SCALP",
    "LEVCAP",
    "MOMENTUM"
];
const ENTRY_LEVER_LABELS = {
    EXT: "EXTENSION — stretched entry (|EMA trend| ≥ N×ATR at deploy)",
    FLOW: "CROWDED-FLOW — strong along-direction flow at deploy (score ≥ +N)",
    CAUSE: "CHASE-CAUSE — whale-push / vol-onset / session-thin tape",
    STALE: "STALE-DETECTION — radar fill paid >N ms after detection",
    SCALP: "SCALP-VALVE — AI-SCALP needs +N extra effective score",
    LEVCAP: "LEV-CAP — leverage trimmed to ≤N×",
    // v11.4 7th lever — the EQ-93 TIGHTEN alternative: per-strategy valve with an
    // INDEPENDENT statistical gate (the advisor's minScore 12→17 was rejected:
    // fee-aware counterfactual showed ΔΣnet NEGATIVE at every raise post-shield,
    // and MOMENTUM cohort n=3–6 is not decision-grade). Shadow journals the
    // cohort; the ladder enforces only when MOMENTUM's OWN gate passes.
    MOMENTUM: "MOMENTUM-VALVE — MOMENTUM needs +N extra effective score"
};
const DEFAULT_LEVER_PARAMS = {
    extAtr: 60,
    flowScoreMin: 10,
    badCauses: [
        "WHALE-PUSH",
        "VOL-ONSET↑",
        "SESSION-THIN"
    ],
    staleMs: 8000,
    scalpBonus: 5,
    momentumBonus: 3,
    levCap: 14,
    windowDays: 14,
    promoteMinN: 100,
    promoteMaxFlagAvg: -0.5,
    promoteMinSep: 0.5,
    demoteFlagAvg: 0.3
};
const MODES_KEY = "entry-levers";
const CONFIG_CACHE_MS = 60_000;
const STATS_CACHE_MS = 300_000;
const JOURNAL_MAX_BYTES = 5_000_000;
const JOURNAL_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "entry-levers.jsonl");
let configCache = null;
let statsCache = null;
function defaultConfig() {
    return {
        modes: {
            EXT: "shadow",
            FLOW: "shadow",
            CAUSE: "shadow",
            STALE: "shadow",
            SCALP: "shadow",
            LEVCAP: "shadow",
            MOMENTUM: "shadow"
        },
        params: {
            ...DEFAULT_LEVER_PARAMS,
            badCauses: [
                ...DEFAULT_LEVER_PARAMS.badCauses
            ]
        },
        updatedAt: new Date().toISOString(),
        autoNotes: [],
        manual: {}
    };
}
function parseEmaTrendAtr(votes) {
    const ema = votes.find((v)=>/EMA STACK/i.test(v.factor));
    if (!ema) return null;
    const atr = parseFloat((ema.detail.match(/trend ([\d.]+)×ATR/) || [])[1] ?? "nan");
    return Number.isFinite(atr) ? atr : null;
}
function shortVal(v, p) {
    switch(v.lever){
        case "EXT":
            return `${v.value?.toFixed(0)}×ATR`;
        case "FLOW":
            return `+${v.value}/25`;
        case "CAUSE":
            return String(v.note);
        case "STALE":
            return `${((v.value ?? 0) / 1000).toFixed(1)}s`;
        case "SCALP":
            return `eff +${p.scalpBonus}`;
        case "LEVCAP":
            return `${v.value}×`;
        case "MOMENTUM":
            return `eff +${p.momentumBonus}`;
    }
}
function evaluateEntryLevers(ctx, p) {
    const out = [];
    // EXT — sign-agnostic extension magnitude (direction-relative audit showed
    // vote SIGNS do not separate; the MAGNITUDE does)
    const atr = parseEmaTrendAtr(ctx.votes);
    out.push({
        lever: "EXT",
        measurable: atr != null,
        fired: atr != null && Math.abs(atr) >= p.extAtr,
        value: atr,
        note: atr != null ? `trend ${atr.toFixed(0)}×ATR` : "ema snapshot unavailable"
    });
    // FLOW — flow score is direction-aligned by construction
    out.push({
        lever: "FLOW",
        measurable: ctx.flowScore != null,
        fired: ctx.flowScore != null && ctx.flowScore >= p.flowScoreMin,
        value: ctx.flowScore,
        note: ctx.flowScore != null ? `flow ${ctx.flowScore >= 0 ? "+" : ""}${ctx.flowScore}/25 along direction` : "flow unavailable"
    });
    // CAUSE — chase-tape blacklist
    const bad = ctx.volCause != null && p.badCauses.includes(ctx.volCause);
    out.push({
        lever: "CAUSE",
        measurable: ctx.volCause != null,
        fired: bad,
        value: bad ? 1 : 0,
        note: ctx.volCause ?? "no vol-cause"
    });
    // STALE — late detection → late (worse) price
    out.push({
        lever: "STALE",
        measurable: ctx.detectionAgeMs != null,
        fired: ctx.detectionAgeMs != null && ctx.detectionAgeMs > p.staleMs,
        value: ctx.detectionAgeMs,
        note: ctx.detectionAgeMs != null ? `detection age ${(ctx.detectionAgeMs / 1000).toFixed(1)}s` : "scan path (no radar detection)"
    });
    // SCALP — structural fast-death strategy → threshold valve (not a ban: the
    // scalp book carries real TP3 winners, only the weak entries must pay more)
    out.push({
        lever: "SCALP",
        measurable: true,
        fired: ctx.strategy === "AI-SCALP",
        value: ctx.strategy === "AI-SCALP" ? 1 : 0,
        note: ctx.strategy === "AI-SCALP" ? `AI-SCALP → eff +${p.scalpBonus} when enforced` : ctx.strategy
    });
    // LEVCAP — high leverage trims to the cap (risk shaping, never a veto)
    out.push({
        lever: "LEVCAP",
        measurable: true,
        fired: ctx.leverage > p.levCap,
        value: ctx.leverage,
        note: ctx.leverage > p.levCap ? `leverage ${ctx.leverage}× > cap ${p.levCap}×` : `leverage ${ctx.leverage}× within cap`
    });
    // MOMENTUM (v11.4 7th lever) — the TIGHTEN alternative: per-strategy valve.
    // The advisor's global minScore 12→17 was measured (EQ-94 fee-aware
    // counterfactual) to be inert-to-harmful; the honest tool is a per-strategy
    // valve whose OWN cohort must pass the promotion gate before it ever bites.
    out.push({
        lever: "MOMENTUM",
        measurable: true,
        fired: ctx.strategy === "MOMENTUM",
        value: ctx.strategy === "MOMENTUM" ? 1 : 0,
        note: ctx.strategy === "MOMENTUM" ? `MOMENTUM → eff +${p.momentumBonus} when enforced` : ctx.strategy
    });
    return out;
}
async function getEntryLeverConfig(force = false) {
    if (!force && configCache && Date.now() - configCache.at < CONFIG_CACHE_MS) return configCache.cfg;
    let cfg = defaultConfig();
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: MODES_KEY
            }
        });
        if (row) {
            const parsed = JSON.parse(row.value);
            cfg = {
                modes: {
                    ...cfg.modes,
                    ...parsed.modes ?? {}
                },
                params: {
                    ...cfg.params,
                    ...parsed.params ?? {},
                    badCauses: parsed.params?.badCauses ?? cfg.params.badCauses
                },
                updatedAt: parsed.updatedAt ?? cfg.updatedAt,
                autoNotes: parsed.autoNotes ?? [],
                manual: parsed.manual ?? {}
            };
        }
    } catch  {
    /* fail-open: defaults */ }
    configCache = {
        at: Date.now(),
        cfg
    };
    return cfg;
}
async function saveConfig(cfg) {
    cfg.updatedAt = new Date().toISOString();
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: MODES_KEY
        },
        create: {
            key: MODES_KEY,
            value: JSON.stringify(cfg)
        },
        update: {
            value: JSON.stringify(cfg)
        }
    });
    configCache = {
        at: Date.now(),
        cfg
    };
}
async function setEntryLeverMode(id, mode, by, pin = true) {
    const cfg = await getEntryLeverConfig(true);
    cfg.modes[id] = mode;
    if (pin) cfg.manual[id] = true;
    await saveConfig(cfg);
    try {
        const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
        await fireEvent(null, null, "ENGINE", "warn", `ENTRY-LEVER mode [${id}] → ${mode.toUpperCase()} (${by}) — late-entry shield v11.3`);
    } catch  {
    /* audit event best-effort */ }
    return cfg;
}
function ctxFromRow(row, latencyMs) {
    let votes = [];
    try {
        const parsed = JSON.parse(row.factorsJson ?? "null");
        if (Array.isArray(parsed)) votes = parsed;
    } catch  {
    /* immutable evidence missing → levers report unmeasurable */ }
    let flowScore = null;
    try {
        const flow = JSON.parse(row.flowJson ?? "null");
        if (flow && typeof flow.score === "number") flowScore = flow.score;
    } catch  {
    /* no flow snapshot */ }
    const causeVote = votes.find((v)=>v.factor.startsWith("VOL-CAUSE:"));
    return {
        symbol: row.symbol,
        direction: row.direction === "SHORT" ? "SHORT" : "LONG",
        strategy: row.strategy,
        votes,
        flowScore,
        volCause: causeVote ? causeVote.factor.slice("VOL-CAUSE:".length) : null,
        leverage: row.leverage,
        detectionAgeMs: latencyMs,
        adjScore: 0,
        effMin: 0
    };
}
async function entryLeverStats(force = false) {
    if (!force && statsCache && Date.now() - statsCache.at < STATS_CACHE_MS) return statsCache.stats;
    const cfg = await getEntryLeverConfig();
    const p = cfg.params;
    const since = new Date(Date.now() - p.windowDays * 86_400_000);
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                notIn: [
                    "ACTIVE"
                ]
            },
            qualityFlag: null,
            createdAt: {
                gte: since
            }
        },
        select: {
            id: true,
            createdAt: true,
            pnlPercent: true,
            direction: true,
            strategy: true,
            leverage: true,
            symbol: true,
            factorsJson: true,
            flowJson: true
        }
    });
    const fills = new Map((await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].fillLedger.findMany({
        select: {
            signalId: true,
            latencyMs: true
        }
    })).map((f)=>[
            f.signalId,
            f.latencyMs
        ]));
    const weekAgo = Date.now() - 7 * 86_400_000;
    const flagged = new Map(ENTRY_LEVER_IDS.map((id)=>[
            id,
            {
                n: 0,
                w: 0,
                sum: 0,
                fires7d: 0
            }
        ]));
    const unflagged = new Map(ENTRY_LEVER_IDS.map((id)=>[
            id,
            {
                n: 0,
                w: 0,
                sum: 0,
                fires7d: 0
            }
        ]));
    let cohortN = 0;
    let cohortW = 0;
    let cohortSum = 0;
    for (const row of rows){
        cohortN++;
        if (row.pnlPercent > 0) cohortW++;
        cohortSum += row.pnlPercent;
        const ctx = ctxFromRow(row, fills.get(row.id) ?? null);
        const verdicts = evaluateEntryLevers(ctx, p);
        const recent = row.createdAt.getTime() >= weekAgo;
        for (const v of verdicts){
            const bucket = v.fired ? flagged.get(v.lever) : unflagged.get(v.lever);
            bucket.n++;
            if (row.pnlPercent > 0) bucket.w++;
            bucket.sum += row.pnlPercent;
            if (v.fired && recent) bucket.fires7d++;
        }
    }
    const perLever = ENTRY_LEVER_IDS.map((id)=>{
        const f = flagged.get(id);
        const u = unflagged.get(id);
        const flagAvg = f.n ? f.sum / f.n : 0;
        const baseAvg = u.n ? u.sum / u.n : 0;
        const nOk = f.n >= p.promoteMinN;
        const avgOk = flagAvg <= p.promoteMaxFlagAvg;
        const sepOk = baseAvg - flagAvg >= p.promoteMinSep;
        const parts = [];
        if (!nOk) parts.push(`n ${f.n}/${p.promoteMinN}`);
        if (!avgOk) parts.push(`flagAvg ${flagAvg.toFixed(2)} > ${p.promoteMaxFlagAvg}`);
        if (!sepOk) parts.push(`sep ${(baseAvg - flagAvg).toFixed(2)} < ${p.promoteMinSep}`);
        return {
            lever: id,
            flagN: f.n,
            flagWr: f.n ? 100 * f.w / f.n : 0,
            flagAvg,
            baseN: u.n,
            baseAvg,
            fires7d: f.fires7d,
            gatePass: nOk && avgOk && sepOk,
            gateNote: nOk && avgOk && sepOk ? "PROMOTION GATE PASSED" : `gate open: ${parts.join(" · ") || "accruing"}`
        };
    });
    const stats = {
        windowDays: p.windowDays,
        cohortN,
        cohortWr: cohortN ? 100 * cohortW / cohortN : 0,
        cohortAvg: cohortN ? cohortSum / cohortN : 0,
        perLever,
        computedAt: new Date().toISOString()
    };
    statsCache = {
        at: Date.now(),
        stats
    };
    return stats;
}
// ─────────────────────────────────────────────────────────────
// Auto promotion / demotion — deterministic, evented, hysteresis-protected.
// Runs on the deploy gate path (throttled by the stats cache) and on GET.
// ─────────────────────────────────────────────────────────────
async function syncLeverModes() {
    const cfg = await getEntryLeverConfig();
    const stats = await entryLeverStats();
    let changed = false;
    const notes = [];
    for (const s of stats.perLever){
        if (cfg.manual[s.lever]) continue; // operator-pinned — manual authority wins
        const mode = cfg.modes[s.lever];
        if (mode === "shadow" && s.gatePass) {
            cfg.modes[s.lever] = "enforce";
            changed = true;
            notes.push(`${s.lever} shadow→enforce (flagAvg ${s.flagAvg.toFixed(2)}, sep ${(s.baseAvg - s.flagAvg).toFixed(2)}, n=${s.flagN})`);
        } else if (mode === "enforce" && s.flagN >= cfg.params.promoteMinN && s.flagAvg > cfg.params.demoteFlagAvg) {
            // honest feedback loop: the enforced lever's own flagged cohort healed —
            // step back to shadow and let the gate re-prove it
            cfg.modes[s.lever] = "shadow";
            changed = true;
            notes.push(`${s.lever} enforce→shadow (flagged cohort healed: avg ${s.flagAvg.toFixed(2)})`);
        } else if (mode === "enforce" && s.flagN < cfg.params.promoteMinN) {
            // evidence drain: an enforcing lever censors its own cohort — blocked
            // deploys never settle, so flagN decays below the gate floor as the
            // window rolls. Step back to shadow to re-accrue fresh, uncensored
            // evidence (drain takes ≥windowDays of enforcement — no flapping).
            cfg.modes[s.lever] = "shadow";
            changed = true;
            notes.push(`${s.lever} enforce→shadow (evidence drain: flagN ${s.flagN} < ${cfg.params.promoteMinN} — re-accrue)`);
        }
    }
    if (changed) {
        cfg.autoNotes = [
            ...notes,
            ...cfg.autoNotes
        ].slice(0, 12);
        await saveConfig(cfg);
        try {
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
            await fireEvent(null, null, "ENGINE", "warn", `ENTRY-LEVER auto-mode: ${notes.join(" | ")} — evidence-gated rollout v11.3`);
        } catch  {
        /* audit event best-effort */ }
    }
}
async function syncEntryLeverModes() {
    await syncLeverModes();
}
const LEVER_TAG = {
    EXT: "LEV-EXT",
    FLOW: "LEV-FLOW",
    CAUSE: "LEV-CAUSE",
    STALE: "LEV-STALE",
    SCALP: "LEV-SCALP",
    LEVCAP: "LEV-CAP",
    MOMENTUM: "LEV-MOM"
};
async function entryLeversDeployGate(ctx, opts) {
    const res = {
        block: false,
        lever: null,
        reason: null,
        capTo: null,
        note: "",
        tags: [],
        observe: opts.observe
    };
    try {
        const cfg = await getEntryLeverConfig();
        const verdicts = evaluateEntryLevers(ctx, cfg.params);
        const fired = verdicts.filter((v)=>v.fired);
        res.tags = fired.map((v)=>LEVER_TAG[v.lever]);
        if (fired.length) void syncLeverModes().catch(()=>undefined); // best-effort, throttled by the stats cache
        if (!opts.observe) {
            for (const v of fired){
                const mode = cfg.modes[v.lever];
                if (mode !== "enforce") continue; // shadow → journal only · off → silent
                if (v.lever === "SCALP") {
                    // valve, not a ban: the scalp candidate must clear effMin + bonus
                    const bar = ctx.effMin + cfg.params.scalpBonus;
                    if (Math.abs(ctx.adjScore) >= bar) continue;
                    res.block = true;
                    res.lever = "SCALP";
                    res.reason = `AI-SCALP valve: |score| ${Math.abs(ctx.adjScore).toFixed(0)} < eff ${ctx.effMin}+${cfg.params.scalpBonus} scalp bonus`;
                    break;
                }
                if (v.lever === "MOMENTUM") {
                    // v11.4 valve, not a ban — same semantics as SCALP, own stat gate:
                    // the MOMENTUM candidate must clear effMin + momentumBonus
                    const bar = ctx.effMin + cfg.params.momentumBonus;
                    if (Math.abs(ctx.adjScore) >= bar) continue;
                    res.block = true;
                    res.lever = "MOMENTUM";
                    res.reason = `MOMENTUM valve: |score| ${Math.abs(ctx.adjScore).toFixed(0)} < eff ${ctx.effMin}+${cfg.params.momentumBonus} momentum bonus`;
                    break;
                }
                if (v.lever === "LEVCAP") {
                    res.capTo = cfg.params.levCap; // fired ⇒ ctx.leverage > cap — engine trims
                    continue;
                }
                res.block = true;
                res.lever = v.lever;
                res.reason = `${ENTRY_LEVER_LABELS[v.lever].split(" — ")[0]} fired: ${v.note}`;
                break;
            }
        }
        res.note = fired.length ? `${fired.length}/${ENTRY_LEVER_IDS.length} flagged (${fired.map((v)=>`${v.lever} ${shortVal(v, cfg.params)}`).join(", ")})${opts.observe ? " · OBSERVE-ONLY" : ""}` : "";
        await appendJournal({
            at: new Date().toISOString(),
            symbol: ctx.symbol,
            direction: ctx.direction,
            strategy: ctx.strategy,
            leverage: ctx.leverage,
            observe: opts.observe,
            modes: {
                ...cfg.modes
            },
            fired: fired.map((v)=>({
                    lever: v.lever,
                    value: v.value
                })),
            block: res.block ? res.lever : null,
            capTo: res.capTo
        });
    } catch  {
    /* fail-open — the shield must never stall a deploy */ }
    return res;
}
// ── journal (.data/entry-levers.jsonl) — audit trail, size-capped rotate ──
async function appendJournal(line) {
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].dirname(JOURNAL_FILE), {
            recursive: true
        });
        try {
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(JOURNAL_FILE);
            if (st.size > JOURNAL_MAX_BYTES) await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(JOURNAL_FILE, `${JOURNAL_FILE}.1`);
        } catch  {
        /* first write */ }
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(JOURNAL_FILE, JSON.stringify(line) + "\n", "utf8");
    } catch  {
    /* journal best-effort */ }
}
async function readJournalTail(max = 15) {
    try {
        const text = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(JOURNAL_FILE, "utf8");
        const lines = text.trim().split("\n").filter(Boolean);
        return lines.slice(-max).reverse().map((l)=>{
            try {
                return JSON.parse(l);
            } catch  {
                return {
                    raw: l
                };
            }
        });
    } catch  {
        return [];
    }
}
async function entryLeversState() {
    await syncEntryLeverModes().catch(()=>undefined); // ladder runs on read — visible in autoNotes
    const [cfg, stats, journal] = await Promise.all([
        getEntryLeverConfig(true),
        entryLeverStats(),
        readJournalTail()
    ]);
    return {
        ts: Date.now(),
        modes: cfg.modes,
        manual: cfg.manual,
        params: cfg.params,
        updatedAt: cfg.updatedAt,
        autoNotes: cfg.autoNotes,
        stats,
        journal,
        labels: ENTRY_LEVER_LABELS
    };
}
}),
"[project]/src/lib/brand.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo — canonical brand + version registry ──────────────────────
// Operator mandate 2026-09-15: rename the program to «FlowRadar Neo» across ALL
// components (dashboard theme respected) and surface the LATEST project version
// in the UI. Every branding surface (header, footer, metadata, Telegram copy,
// posters) imports from this single module so the name/version can never drift.
__turbopack_context__.s([
    "APP_ENGINE_LINE",
    ()=>APP_ENGINE_LINE,
    "APP_NAME",
    ()=>APP_NAME,
    "APP_OG_TITLE",
    ()=>APP_OG_TITLE,
    "APP_STAGE",
    ()=>APP_STAGE,
    "APP_TAGLINE",
    ()=>APP_TAGLINE,
    "APP_TITLE",
    ()=>APP_TITLE,
    "APP_VERSION",
    ()=>APP_VERSION,
    "APP_VERSION_LABEL",
    ()=>APP_VERSION_LABEL,
    "BRAND_TERMINAL",
    ()=>BRAND_TERMINAL
]);
const APP_NAME = "FlowRadar Neo";
const BRAND_TERMINAL = {
    head: "FLOWRADAR",
    sep: "//",
    tail: "NEO"
};
const APP_VERSION = "10.0.0";
const APP_VERSION_LABEL = `v${APP_VERSION}`;
const APP_STAGE = "NEO";
const APP_TAGLINE = `AI TRADING COMMAND ${APP_VERSION_LABEL} — FULL AUTONOMY`;
const APP_ENGINE_LINE = `FLOWRADAR-NEO ${APP_VERSION_LABEL} — AUTONOMOUS`;
const APP_TITLE = `${APP_NAME} — AI Trading Command Terminal`;
const APP_OG_TITLE = `${BRAND_TERMINAL.head}${BRAND_TERMINAL.sep}${BRAND_TERMINAL.tail}`;
}),
"[project]/src/lib/telegram-image.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "renderStatusBanner",
    ()=>renderStatusBanner
]);
// ── FlowRadar Neo v6.3 telegram banner renderer (server-only) ──
// Dependency-free PNG generator for signal status banners (WIN / STOP /
// EXPIRED / NEW / SHORT / TTL_EXT / FULL). Draws a dark cyber-terminal card
// with a status headline, symbol line and two detail lines using an embedded
// 5×7 bitmap font, then encodes a real PNG via node:zlib — no canvas, no
// image library, nothing invented: every byte is rendered from the numbers
// the engine measured.
// (Operator round: «استفاده از تصویرهای ضمینه شده برای سیگنالهای win ، stop ، EXPIRED»
//  + lost-window batch 2026-09-05 21:09: NEW / TTL / FULL / Short banners)
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$zlib__$5b$external$5d$__$28$node$3a$zlib$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:zlib [external] (node:zlib, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/brand.ts [app-route] (ecmascript)");
;
;
// classic 5×7 bitmap font (HD44780-style), one byte per row, bit4 = leftmost px
const FONT = {
    "0": [
        0x0e,
        0x11,
        0x13,
        0x15,
        0x19,
        0x11,
        0x0e
    ],
    "1": [
        0x04,
        0x0c,
        0x04,
        0x04,
        0x04,
        0x04,
        0x0e
    ],
    "2": [
        0x0e,
        0x11,
        0x01,
        0x02,
        0x04,
        0x08,
        0x1f
    ],
    "3": [
        0x1f,
        0x02,
        0x04,
        0x02,
        0x01,
        0x11,
        0x0e
    ],
    "4": [
        0x02,
        0x06,
        0x0a,
        0x12,
        0x1f,
        0x02,
        0x02
    ],
    "5": [
        0x1f,
        0x10,
        0x1e,
        0x01,
        0x01,
        0x11,
        0x0e
    ],
    "6": [
        0x06,
        0x08,
        0x10,
        0x1e,
        0x11,
        0x11,
        0x0e
    ],
    "7": [
        0x1f,
        0x01,
        0x02,
        0x04,
        0x08,
        0x08,
        0x08
    ],
    "8": [
        0x0e,
        0x11,
        0x11,
        0x0e,
        0x11,
        0x11,
        0x0e
    ],
    "9": [
        0x0e,
        0x11,
        0x11,
        0x0f,
        0x01,
        0x02,
        0x0c
    ],
    A: [
        0x0e,
        0x11,
        0x11,
        0x1f,
        0x11,
        0x11,
        0x11
    ],
    B: [
        0x1e,
        0x11,
        0x11,
        0x1e,
        0x11,
        0x11,
        0x1e
    ],
    C: [
        0x0e,
        0x11,
        0x10,
        0x10,
        0x10,
        0x11,
        0x0e
    ],
    D: [
        0x1c,
        0x12,
        0x11,
        0x11,
        0x11,
        0x12,
        0x1c
    ],
    E: [
        0x1f,
        0x10,
        0x10,
        0x1e,
        0x10,
        0x10,
        0x1f
    ],
    F: [
        0x1f,
        0x10,
        0x10,
        0x1e,
        0x10,
        0x10,
        0x10
    ],
    G: [
        0x0e,
        0x11,
        0x10,
        0x17,
        0x11,
        0x11,
        0x0f
    ],
    H: [
        0x11,
        0x11,
        0x11,
        0x1f,
        0x11,
        0x11,
        0x11
    ],
    I: [
        0x0e,
        0x04,
        0x04,
        0x04,
        0x04,
        0x04,
        0x0e
    ],
    J: [
        0x07,
        0x02,
        0x02,
        0x02,
        0x02,
        0x12,
        0x0c
    ],
    K: [
        0x11,
        0x12,
        0x14,
        0x18,
        0x14,
        0x12,
        0x11
    ],
    L: [
        0x10,
        0x10,
        0x10,
        0x10,
        0x10,
        0x10,
        0x1f
    ],
    M: [
        0x11,
        0x1b,
        0x15,
        0x15,
        0x11,
        0x11,
        0x11
    ],
    N: [
        0x11,
        0x11,
        0x19,
        0x15,
        0x13,
        0x11,
        0x11
    ],
    O: [
        0x0e,
        0x11,
        0x11,
        0x11,
        0x11,
        0x11,
        0x0e
    ],
    P: [
        0x1e,
        0x11,
        0x11,
        0x1e,
        0x10,
        0x10,
        0x10
    ],
    Q: [
        0x0e,
        0x11,
        0x11,
        0x11,
        0x15,
        0x12,
        0x0d
    ],
    R: [
        0x1e,
        0x11,
        0x11,
        0x1e,
        0x14,
        0x12,
        0x11
    ],
    S: [
        0x0f,
        0x10,
        0x10,
        0x0e,
        0x01,
        0x01,
        0x1e
    ],
    T: [
        0x1f,
        0x04,
        0x04,
        0x04,
        0x04,
        0x04,
        0x04
    ],
    U: [
        0x11,
        0x11,
        0x11,
        0x11,
        0x11,
        0x11,
        0x0e
    ],
    V: [
        0x11,
        0x11,
        0x11,
        0x11,
        0x11,
        0x0a,
        0x04
    ],
    W: [
        0x11,
        0x11,
        0x11,
        0x15,
        0x15,
        0x1b,
        0x11
    ],
    X: [
        0x11,
        0x11,
        0x0a,
        0x04,
        0x0a,
        0x11,
        0x11
    ],
    Y: [
        0x11,
        0x11,
        0x0a,
        0x04,
        0x04,
        0x04,
        0x04
    ],
    Z: [
        0x1f,
        0x01,
        0x02,
        0x04,
        0x08,
        0x10,
        0x1f
    ],
    " ": [
        0,
        0,
        0,
        0,
        0,
        0,
        0
    ],
    "+": [
        0x00,
        0x04,
        0x04,
        0x1f,
        0x04,
        0x04,
        0x00
    ],
    "-": [
        0x00,
        0x00,
        0x00,
        0x1f,
        0x00,
        0x00,
        0x00
    ],
    "%": [
        0x19,
        0x1a,
        0x02,
        0x04,
        0x08,
        0x0b,
        0x13
    ],
    ".": [
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x0c,
        0x0c
    ],
    ":": [
        0x00,
        0x0c,
        0x0c,
        0x00,
        0x0c,
        0x0c,
        0x00
    ],
    "/": [
        0x01,
        0x01,
        0x02,
        0x04,
        0x08,
        0x10,
        0x10
    ],
    "(": [
        0x02,
        0x04,
        0x08,
        0x08,
        0x08,
        0x04,
        0x02
    ],
    ")": [
        0x08,
        0x04,
        0x02,
        0x02,
        0x02,
        0x04,
        0x08
    ]
};
const BG = [
    10,
    13,
    20
]; // #0a0d14 — terminal ink
const INK = [
    232,
    240,
    236
]; // near-white
const MUTED = [
    110,
    128,
    120
]; // dim sage
const WIN = [
    0,
    255,
    163
]; // neon mint
const STOP = [
    255,
    77,
    94
]; // danger
const EXPIRED = [
    255,
    179,
    71
]; // amber
const VIOLET = [
    178,
    107,
    255
];
const AFTERLIFE = [
    219,
    96,
    255
]; // spectral magenta — EXPIRED FOLLOW-UP verdicts
const STATUS_TEXT = {
    WIN: "WIN",
    STOP: "STOPPED",
    EXPIRED: "EXPIRED",
    NEW: "NEW SIGNAL",
    SHORT: "SHORT SIGNAL",
    TTL_EXT: "TTL EXTENDED",
    FULL: "FULL TARGET",
    AFTERLIFE: "AFTERLIFE"
};
const STATUS_COLOR = {
    WIN: WIN,
    STOP: STOP,
    EXPIRED: EXPIRED,
    NEW: WIN,
    SHORT: STOP,
    TTL_EXT: VIOLET,
    FULL: WIN,
    AFTERLIFE: AFTERLIFE
};
function asciiUpper(s) {
    return s.toUpperCase().replace(/[^A-Z0-9 +\-%.:()/]/g, "");
}
function makeCanvas(w, h) {
    const px = new Uint8Array(w * h * 3);
    for(let i = 0; i < w * h; i++){
        px[i * 3] = BG[0];
        px[i * 3 + 1] = BG[1];
        px[i * 3 + 2] = BG[2];
    }
    return {
        w,
        h,
        px
    };
}
function setPx(c, x, y, [r, g, b]) {
    if (x < 0 || y < 0 || x >= c.w || y >= c.h) return;
    const i = (y * c.w + x) * 3;
    c.px[i] = r;
    c.px[i + 1] = g;
    c.px[i + 2] = b;
}
function fillRect(c, x, y, w, h, col) {
    for(let dy = 0; dy < h; dy++)for(let dx = 0; dx < w; dx++)setPx(c, x + dx, y + dy, col);
}
function textWidth(text, scale) {
    return asciiUpper(text).length * 6 * scale - scale; // 5px glyph + 1px gap
}
function drawText(c, text, x, y, scale, col) {
    const chars = asciiUpper(text);
    let cx = x;
    for (const ch of chars){
        const glyph = FONT[ch];
        if (glyph) {
            for(let row = 0; row < 7; row++){
                const bits = glyph[row];
                for(let gx = 0; gx < 5; gx++){
                    if (bits & 1 << 4 - gx) fillRect(c, cx + gx * scale, y + row * scale, scale, scale, col);
                }
            }
        }
        cx += 6 * scale;
    }
}
function drawTextCentered(c, text, y, scale, col) {
    const w = textWidth(text, scale);
    drawText(c, text, Math.max(4, Math.floor((c.w - w) / 2)), y, scale, col);
}
// ── PNG encoder (color type 2 — truecolor RGB, 8-bit, filter 0) ──
const CRC_TABLE = (()=>{
    const t = [];
    for(let n = 0; n < 256; n++){
        let c = n;
        for(let k = 0; k < 8; k++)c = c & 1 ? 0xedb88320 ^ c >>> 1 : c >>> 1;
        t[n] = c >>> 0;
    }
    return t;
})();
function crc32(buf) {
    let c = 0xffffffff;
    for (const b of buf)c = CRC_TABLE[(c ^ b) & 0xff] ^ c >>> 8;
    return (c ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const body = Buffer.concat([
        Buffer.from(type, "ascii"),
        data
    ]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(body));
    return Buffer.concat([
        len,
        body,
        crc
    ]);
}
function encodePng(c) {
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(c.w, 0);
    ihdr.writeUInt32BE(c.h, 4);
    ihdr[8] = 8; // bit depth
    ihdr[9] = 2; // color type RGB
    // raw scanlines with leading filter byte 0
    const raw = Buffer.alloc(c.h * (c.w * 3 + 1));
    for(let y = 0; y < c.h; y++){
        raw[y * (c.w * 3 + 1)] = 0;
        Buffer.from(c.px.buffer, c.px.byteOffset + y * c.w * 3, c.w * 3).copy(raw, y * (c.w * 3 + 1) + 1);
    }
    return Buffer.concat([
        Buffer.from([
            0x89,
            0x50,
            0x4e,
            0x47,
            0x0d,
            0x0a,
            0x1a,
            0x0a
        ]),
        chunk("IHDR", ihdr),
        chunk("IDAT", __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$zlib__$5b$external$5d$__$28$node$3a$zlib$2c$__cjs$29$__["default"].deflateSync(raw, {
            level: 6
        })),
        chunk("IEND", Buffer.alloc(0))
    ]);
}
function renderStatusBanner(spec) {
    const W = 640;
    const H = 360;
    const c = makeCanvas(W, H);
    const accent = STATUS_COLOR[spec.status];
    // top + bottom accent bars
    fillRect(c, 0, 0, W, 8, accent);
    fillRect(c, 0, H - 8, W, 8, accent);
    // thin rules under the headline zone
    fillRect(c, 32, 232, W - 64, 2, [
        36,
        46,
        42
    ]);
    fillRect(c, 32, 300, W - 64, 2, [
        36,
        46,
        42
    ]);
    // HUD corner ticks
    for (const [x, y] of [
        [
            16,
            20
        ],
        [
            W - 22,
            20
        ],
        [
            16,
            H - 28
        ],
        [
            W - 22,
            H - 28
        ]
    ]){
        fillRect(c, x, y, 6, 2, MUTED);
        fillRect(c, x < W / 2 ? x : x + 4, y, 2, 6, MUTED);
    }
    drawTextCentered(c, `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].head}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].sep}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].tail}`, 26, 2, MUTED);
    drawTextCentered(c, STATUS_TEXT[spec.status], 74, 9, accent);
    drawTextCentered(c, asciiUpper(spec.title), 180, 4, INK);
    if (spec.line1) drawTextCentered(c, spec.line1, 246, 3, accent);
    if (spec.line2) drawTextCentered(c, spec.line2, 276, 3, INK);
    drawTextCentered(c, asciiUpper(spec.footer ?? "FLOWRADAR-NEO LIVE ENGINE"), 320, 2, VIOLET);
    return encodePng(c);
}
}),
"[project]/src/lib/daily-skin.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo v9.4 DAILY SKIN — operator mandate 2026-09-13 ────────────
// «TELEGRAM ART SKIN باید ساخت و تولید تصویر را با 7-SKIN CYCLE ACROSS ALL
//  TELEGRAM REPORTS انجام دهد» — the skin cycle must drive REAL AI image
// generation, one visual style per day, across all Telegram reports.
//
// Operator's 7 styles (fixed order, one per Tehran day):
//   1. BLUEPRINT   2. MOVIE (cinematic)   3. CYBERPUNK   4. ANIME
//   5. POP ART     6. VECTOR              7. CLAY
//
// Each skin now carries:
//   key   → assets/telegram/skin-{key}.png — AI-generated backdrop in THIS
//           style (same subject scene, seven different renderings; produced by
//           scripts/gen-skin-art.sh, idempotent + rate-limit aware)
//   style → the style prompt fragment used by the generator (single source of
//           truth: the artwork and this table can never drift apart)
//   tune  → composite modulation so overlay text stays readable WITHOUT hue-
//           rotating the style identity (hueShift stays 0 — a hue-rotated
//           blueprint or pop-art piece would stop being one)
//   artKind → legacy art-{KIND}.png fallback while skin files generate
//
// Deterministic per-Tehran-day pick (same day → same skin everywhere: daily
// poster, report previews, dashboard badge; next Tehran midnight → next style
// in the operator's order). Zero randomness, zero I/O, edge-safe.
__turbopack_context__.s([
    "SKIN_COUNT",
    ()=>SKIN_COUNT,
    "SKIN_KEYS",
    ()=>SKIN_KEYS,
    "SKIN_KINDS",
    ()=>SKIN_KINDS,
    "SKIN_NAMES",
    ()=>SKIN_NAMES,
    "dailySkin",
    ()=>dailySkin,
    "skinBySeed",
    ()=>skinBySeed,
    "tehranDayKey",
    ()=>tehranDayKey
]);
const SKINS = [
    {
        key: "blueprint",
        name: "BLUEPRINT",
        accent: "#5fd4d0",
        deep1: "#0a1a20",
        deep2: "#060f14",
        art: "DAILY",
        tune: {
            brightness: 0.62,
            saturation: 0.8
        },
        style: "ultra-premium dark technical blueprint art, glowing cyan holographic schematic line-work on deep navy slate, layered translucent drafting sheets floating in depth, precise measurement marks and cross-section annotations, soft cyan edge-glow, subtle depth-of-field bokeh between drawing layers, elegant engineering masterpiece composition"
    },
    {
        key: "movie",
        name: "CINEMATIC",
        accent: "#ffb347",
        deep1: "#140f0a",
        deep2: "#0a0705",
        art: "WIN",
        tune: {
            brightness: 0.58,
            saturation: 0.9
        },
        style: "epic cinematic movie key art, anamorphic widescreen composition, dramatic volumetric god rays cutting through haze, strong rim lighting sculpting the subject, teal and amber color grade, shallow depth of field, high-contrast chiaroscuro lighting, luxury film-poster craft, subtle film grain"
    },
    {
        key: "cyberpunk",
        name: "CYBERPUNK",
        accent: "#ff5c4d",
        deep1: "#170a12",
        deep2: "#0b0509",
        art: "STOP",
        tune: {
            brightness: 0.72,
            saturation: 0.92
        },
        style: "futuristic neon cyberpunk megacity key art, glowing magenta and cyan neon signage, rain-slick streets with mirror reflections, volumetric fog carrying neon glow, holographic depth layers, high-contrast night atmosphere, cinematic blade-runner mood, ultra-detailed professional digital art"
    },
    {
        key: "anime",
        name: "ANIME",
        accent: "#ff6b9a",
        deep1: "#160b14",
        deep2: "#0b060a",
        art: "NEW",
        tune: {
            brightness: 0.66,
            saturation: 0.95
        },
        style: "premium japanese anime key visual, bold cel shading with crisp highlights, dynamic energy trails and speed lines, dramatic backlighting, vibrant saturated palette, studio-grade composition, sharp expressive detail, cinematic anime poster quality"
    },
    {
        key: "popart",
        name: "POP ART",
        accent: "#ffd166",
        deep1: "#1a1206",
        deep2: "#0d0904",
        art: "FULL",
        tune: {
            brightness: 0.7,
            saturation: 1.0
        },
        style: "premium retro pop-art screen print, bold black ink outlines, large crisp halftone ben-day dots, punchy flat color blocks with offset print misregistration, dramatic comic-book shading, gallery-quality warhol poster composition"
    },
    {
        key: "vector",
        name: "VECTOR",
        accent: "#3ddc97",
        deep1: "#0a1510",
        deep2: "#050c09",
        art: "EXPIRED",
        tune: {
            brightness: 0.64,
            saturation: 0.85
        },
        style: "premium minimal vector fintech key art, smooth gradient mesh shapes, elegant geometric composition with layered depth, crisp rounded edges, subtle isometric accents, sophisticated dark-mode palette with glowing mint accents, high-end poster design"
    },
    {
        key: "clay",
        name: "CLAY",
        accent: "#c0e860",
        deep1: "#121408",
        deep2: "#090b05",
        art: "SHORT",
        tune: {
            brightness: 0.68,
            saturation: 0.82
        },
        style: "premium 3D claymation diorama, soft matte plasticine textures, rounded chunky shapes, cozy pastel studio lighting with soft shadows, subtle subsurface scattering glow, high-end 3D render quality, charming handcrafted look"
    }
];
function tehranDayKey(d = new Date()) {
    return new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Tehran",
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    }).format(d);
}
/** Epoch-day index for a Tehran day key (rotation counter). */ function seedFor(dayKey) {
    const [y, m, d] = dayKey.split("-").map(Number);
    return Math.floor(Date.UTC(y, (m ?? 1) - 1, d ?? 1) / 86_400_000);
}
function build(dayKey, seed, s) {
    return {
        dayKey,
        key: s.key,
        name: s.name,
        accent: s.accent,
        deep1: s.deep1,
        deep2: s.deep2,
        artKind: s.art,
        geometry: seed % 3,
        hueShift: 0,
        tune: s.tune,
        style: s.style,
        seed
    };
}
function dailySkin(d = new Date()) {
    const dayKey = tehranDayKey(d);
    const seed = seedFor(dayKey);
    const s = SKINS[(seed % SKINS.length + SKINS.length) % SKINS.length];
    return build(dayKey, seed, s);
}
function skinBySeed(seed) {
    const s = SKINS[(seed % SKINS.length + SKINS.length) % SKINS.length];
    return build(`seed-${seed}`, seed, s);
}
const SKIN_COUNT = SKINS.length;
const SKIN_NAMES = SKINS.map((s)=>s.name);
const SKIN_KEYS = SKINS.map((s)=>s.key);
const SKIN_KINDS = [
    "LONG",
    "SHORT",
    "TP",
    "STOP",
    "EXPIRED"
];
}),
"[project]/src/lib/telegram-art.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "baseAsset",
    ()=>baseAsset,
    "kindForStatus",
    ()=>kindForStatus,
    "loadCoinLogo",
    ()=>loadCoinLogo,
    "loadSkinArt",
    ()=>loadSkinArt,
    "loadSkinKindArt",
    ()=>loadSkinKindArt,
    "renderDailyPoster",
    ()=>renderDailyPoster,
    "renderSignalBannerV2",
    ()=>renderSignalBannerV2,
    "renderWeeklyPoster",
    ()=>renderWeeklyPoster
]);
// ── FlowRadar Neo v8.1 professional telegram artwork renderer (server-only) ─
// Operator round 2026-09-09: «آیا میشه ساخت تصاویر رو ارتقا داد تا گرافیکی‌تر
// و حرفه‌ای‌تر باشه؟ مثل نماد لوگو ارزها، برای وین گاو خشمگین و برای استاپ
// خرس خشمگین». This module is the YES: sharp (already a dependency) rasterizes
// design-grade SVG templates on top of AI-generated artwork, with real
// typography (DejaVu), live per-signal data, fetched coin logos, glow filters
// and stat cards. Every number drawn comes from the REAL signal/digest rows —
// the artwork is presentation, never invention.
//
// Fallback chain (wired in notify.ts):
//   renderSignalBannerV2 (this) → operator JPG art → renderStatusBanner (pixel)
//   renderDailyPoster (this)    → DAILY.jpg        → plain text caption
var __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__ = __turbopack_context__.i("[externals]/sharp [external] (sharp, cjs, [project]/node_modules/sharp)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/brand.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$daily$2d$skin$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/daily-skin.ts [app-route] (ecmascript)");
;
;
;
;
;
const W = 1280;
const H = 720;
const ASSETS_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), "assets", "telegram");
const COINS_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), "assets", "coins");
// ── palette (matches the v6.3 terminal identity) ──
const INK = "#e8f0ec";
const MUTED = "#8aa094";
const DIM = "#5a6e66";
const MINT = "#00ffa3";
const DANGER = "#ff4d5e";
const AMBER = "#ffb347";
const VIOLET = "#b26bff";
const GOLD = "#ffd700";
const PANEL_BG = "rgba(10,14,22,0.62)";
const PANEL_STROKE = "rgba(138,160,148,0.22)";
const STATUS_TEXT = {
    WIN: "WIN",
    STOP: "STOPPED",
    EXPIRED: "EXPIRED",
    NEW: "NEW SIGNAL",
    SHORT: "SHORT SIGNAL",
    TTL_EXT: "TTL EXTENDED",
    FULL: "FULL TARGET",
    AFTERLIFE: "AFTERLIFE"
};
const SPECTRAL = "#DB60FF"; // spectral magenta — EXPIRED FOLLOW-UP verdicts
const STATUS_COLOR = {
    WIN: MINT,
    STOP: DANGER,
    EXPIRED: AMBER,
    NEW: MINT,
    SHORT: DANGER,
    TTL_EXT: VIOLET,
    FULL: GOLD,
    AFTERLIFE: SPECTRAL
};
function escXml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
// ── AI artwork loading (art-{KIND}.png, generated once via scripts/gen-telegram-art.sh) ──
const artCache = new Map();
async function loadArt(kind) {
    if (artCache.has(kind)) return artCache.get(kind) ?? null;
    try {
        const buf = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(ASSETS_DIR, `art-${kind}.png`));
        artCache.set(kind, buf);
        return buf;
    } catch  {
        artCache.set(kind, null);
        return null;
    }
}
// ── v9.4 SKIN-CYCLE backdrop (skin-{KEY}.png, scripts/gen-skin-art.sh) ──
// The 7-skin cycle drives REAL AI generation: one visual style per day
// (BLUEPRINT · MOVIE · CYBERPUNK · ANIME · POP ART · VECTOR · CLAY), same
// subject scene across all seven. Negative results are cached for only 60s
// so backdrops generated while the server is live are picked up on the next
// render — the report must never wait on generation, but it must not need a
// restart to start wearing the new skin either.
const SKIN_NEG_TTL = 60_000;
const skinCache = new Map();
async function loadSkinArt(key) {
    const hit = skinCache.get(key);
    if (hit && (hit.buf || Date.now() - hit.at < SKIN_NEG_TTL)) return hit.buf;
    let buf = null;
    try {
        buf = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(ASSETS_DIR, `skin-${key}.png`));
    } catch  {
        buf = null;
    }
    skinCache.set(key, {
        buf,
        at: Date.now()
    });
    return buf;
}
function kindForStatus(status) {
    switch(status){
        case "NEW":
            return "LONG";
        case "SHORT":
            return "SHORT";
        case "WIN":
        case "FULL":
            return "TP";
        case "STOP":
            return "STOP";
        case "EXPIRED":
        case "AFTERLIFE":
        case "TTL_EXT":
            return "EXPIRED";
    }
}
async function loadSkinFile(file) {
    const hit = skinCache.get(file);
    if (hit && (hit.buf || Date.now() - hit.at < SKIN_NEG_TTL)) return hit.buf;
    let buf = null;
    try {
        buf = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(ASSETS_DIR, file));
    } catch  {
        buf = null;
    }
    skinCache.set(file, {
        buf,
        at: Date.now()
    });
    return buf;
}
async function loadSkinKindArt(key, kind) {
    return await loadSkinFile(`skin-${key}-${kind}.png`) ?? await loadSkinFile(`skin-${key}.png`);
}
/** Shared composite: style backdrop + modulation tuned per skin (v9.4 — the
 * style identity is never hue-rotated; brightness/saturation keep the overlay
 * text readable). v10.21: the modulated 1280×720 backdrop is cached per art
 * file — an animation burst re-renders the SAME backdrop 14× and only the
 * overlay changes, so re-modulating every frame was 60%+ of the burst cost
 * (688ms/frame → the cache removes the resize+modulate from frames 2..14). */ const bgCache = new Map(); // art cacheKey → modulated 1280×720 bg
async function modulatedBackdrop(art, skin, cacheKey) {
    const hit = bgCache.get(cacheKey);
    if (hit) return hit;
    const bg = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(art).resize(W, H, {
        fit: "cover"
    }).modulate({
        brightness: skin.tune.brightness,
        saturation: skin.tune.saturation,
        hue: skin.hueShift
    }).toBuffer();
    if (bgCache.size >= 6) bgCache.delete(bgCache.keys().next().value);
    bgCache.set(cacheKey, bg);
    return bg;
}
async function withBackdrop(art, skin, overlay, extra = [], cacheKey = "poster") {
    const bg = await modulatedBackdrop(art, skin, cacheKey);
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(bg).composite([
        {
            input: overlay
        },
        ...extra
    ]).png({
        compressionLevel: 8
    }).toBuffer();
}
// ── coin logos: jsdelivr cryptocurrency-icons (spothq), cached on disk ──
// https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/svg/color/{base}.svg
const logoCache = new Map(); // base → rasterized 160px PNG
function baseAsset(symbol) {
    const s = symbol.toUpperCase();
    for (const quote of [
        "USDT",
        "USDC",
        "BUSD",
        "FDUSD",
        "USD"
    ]){
        if (s.endsWith(quote) && s.length > quote.length) return s.slice(0, s.length - quote.length);
    }
    return s;
}
async function loadCoinLogo(symbol) {
    const base = baseAsset(symbol);
    if (logoCache.has(base)) return logoCache.get(base) ?? null;
    let result = null;
    // 1) disk cache
    const diskPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(COINS_DIR, `${base}.svg`);
    try {
        const svg = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(diskPath);
        result = await rasterizeLogo(svg);
    } catch  {
        // 2) remote fetch (3s cap — relay is fire-and-forget, never stall the tick)
        try {
            const ctrl = new AbortController();
            const t = setTimeout(()=>ctrl.abort(), 3000);
            const res = await fetch(`https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/svg/color/${base.toLowerCase()}.svg`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(t);
            if (res.ok) {
                const svg = Buffer.from(await res.arrayBuffer());
                result = await rasterizeLogo(svg);
                if (result) {
                    await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].mkdir(COINS_DIR, {
                        recursive: true
                    }).catch(()=>undefined);
                    await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(diskPath, svg).catch(()=>undefined);
                }
            }
        } catch  {}
    }
    logoCache.set(base, result);
    return result;
}
async function rasterizeLogo(svg) {
    try {
        return await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(svg, {
            density: 300
        }).resize(160, 160).png().toBuffer();
    } catch  {
        return null;
    }
}
// ── shared SVG fragments ──
// v10.20: DejaVu Sans Mono advance ≈ 0.602em — width estimates keep the three
// footer zones collision-free (the old fixed x=W/2 center collided with the
// brand line whenever the center text ran long — seen live on WIN cards:
// «LIVE ENGINEDONEST NUMBERS…», letter-spacing was the hidden multiplier).
const MONO_EM = 0.602;
function monoW(text, size, ls = 0) {
    if (!text) return 0;
    return text.length * (size * MONO_EM + ls) - ls; // trailing letter-spacing is not drawn
}
/** v10.20 top-right timestamp chip — a dark scrim pill so the stamp stays
 * readable when the skin art behind it is bright (gold coins, neon halos). */ function tsChip(ts, baseline, size, ls = 2) {
    if (!ts) return "";
    const w = monoW(ts, size, ls) + 26;
    const h = size + 18;
    return `<rect x="${(W - 40 - w).toFixed(0)}" y="${(baseline - size - 6).toFixed(0)}" width="${w.toFixed(0)}" height="${h}" rx="10" ry="10" fill="rgba(6,9,16,0.62)" stroke="rgba(138,160,148,0.2)" stroke-width="1"/>
  <text x="${W - 40 - 13}" y="${baseline}" font-family="DejaVu Sans Mono" font-size="${size}" fill="${INK}" text-anchor="end" letter-spacing="${ls}">${escXml(ts)}</text>`;
}
function hudTicks(accent) {
    const t = 26, o = 20, len = 26, sw = 3;
    const corner = (x, y, dx, dy)=>`<path d="M ${x + dx * len} ${y} L ${x} ${y} L ${x} ${y + dy * len}" stroke="${accent}" stroke-width="${sw}" fill="none" opacity="0.85"/>`;
    return corner(o, t, 1, 1) + corner(W - o, t, -1, 1) + corner(o, H - t, 1, -1) + corner(W - o, H - t, -1, -1);
}
function footerBar(ts, center) {
    const y = H - 62;
    const left = "FLOWRADAR-NEO LIVE ENGINE";
    const L = 40 + monoW(left, 21, 2) + 30; // usable span for the center text
    const R = W - 40 - monoW(ts, 21) - 30;
    let shown = "";
    if (center) {
        shown = center;
        if (monoW(shown, 21, 2) > R - L) {
            // v10.20 auto-fit: truncate with ellipsis instead of colliding with the brand line
            while(shown.length > 4 && monoW(`${shown}…`, 21, 2) > R - L)shown = shown.slice(0, -1);
            shown = `${shown.trimEnd()}…`;
        }
    }
    const cx = Math.round((L + R) / 2);
    return `
  <rect x="0" y="${y}" width="${W}" height="62" fill="rgba(6,9,16,0.88)"/>
  <rect x="0" y="${y}" width="${W}" height="2" fill="${PANEL_STROKE}"/>
  <text x="40" y="${y + 39}" font-family="DejaVu Sans Mono" font-size="21" fill="${VIOLET}" letter-spacing="2">${left}</text>
  ${shown ? `<text x="${cx}" y="${y + 39}" font-family="DejaVu Sans Mono" font-size="21" fill="${MUTED}" text-anchor="middle" letter-spacing="2">${escXml(shown)}</text>` : ""}
  <text x="${W - 40}" y="${y + 39}" font-family="DejaVu Sans Mono" font-size="21" fill="${DIM}" text-anchor="end">${escXml(ts)}</text>`;
}
function gridPattern() {
    const lines = [];
    for(let x = 64; x < W; x += 64)lines.push(`<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="rgba(138,160,148,0.05)" stroke-width="1"/>`);
    for(let y = 64; y < H; y += 64)lines.push(`<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="rgba(138,160,148,0.05)" stroke-width="1"/>`);
    return lines.join("");
}
function defs(status, skin, pulse = 0) {
    const accent = STATUS_COLOR[status];
    const deep1 = skin?.deep1 ?? "#0b101c";
    const deep2 = skin?.deep2 ?? "#070a12";
    const haloAccent = skin?.accent ?? accent;
    const haloCx = skin ? [
        0.22,
        0.78,
        0.5
    ][skin.geometry] : 0.22;
    const haloCy = skin ? [
        0.42,
        0.35,
        0.62
    ][skin.geometry] : 0.42;
    return `<defs>
    <linearGradient id="scrim" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="rgba(6,9,16,0.94)"/>
      <stop offset="0.45" stop-color="rgba(6,9,16,0.82)"/>
      <stop offset="0.78" stop-color="rgba(6,9,16,0.30)"/>
      <stop offset="1" stop-color="rgba(6,9,16,0.12)"/>
    </linearGradient>
    <linearGradient id="topbar" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="${accent}"/>
      <stop offset="1" stop-color="${accent}" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="bgdeep" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${deep1}"/>
      <stop offset="1" stop-color="${deep2}"/>
    </linearGradient>
    <radialGradient id="bghalo" cx="${haloCx}" cy="${haloCy}" r="0.85">
      <stop offset="0" stop-color="${haloAccent}" stop-opacity="0.18"/>
      <stop offset="1" stop-color="${haloAccent}" stop-opacity="0"/>
    </radialGradient>
    <filter id="glow" x="-40%" y="-40%" width="180%" height="180%">
      <feGaussianBlur stdDeviation="${(7 + 9 * pulse).toFixed(1)}" result="b"/>
      <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <filter id="softglow" x="-40%" y="-40%" width="180%" height="180%">
      <feGaussianBlur stdDeviation="4" result="b"/>
      <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <linearGradient id="sweepbeam" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#ffffff" stop-opacity="0"/>
      <stop offset="0.5" stop-color="#ffffff" stop-opacity="0.26"/>
      <stop offset="1" stop-color="#ffffff" stop-opacity="0"/>
    </linearGradient>
  </defs>`;
}
/** v10.21 MOTION LAYER — animated-card-only elements (phase 0..1 loop).
 * v10.20 shipped a pulse so faint it read as a static GIF (operator:
 * «هیچ موشنی ندارد») — the only deltas were blur 8→13 behind the headline
 * and a 3px bar's opacity. The fix is motion you cannot miss:
 *   · sonar rings — pings expanding from the coin badge (under text)
 *   · sweep beam — a diagonal light pass crossing the whole card (over all)
 *   · headline glow — 2.5× stronger breathing (7→16 blur)
 *   · bottom traveler — a bright segment physically crossing the footer
 * Traveling elements key off `phase` (monotonic 0→1) so the loop is
 * seamless: the sweep and traveler are fully off-canvas at both ends,
 * rings fade to zero opacity before restarting. Static cards never draw
 * this layer (phase undefined). Split under/over: rings sit behind the
 * typography, the sweep + traveler must land AFTER footerBar (the footer
 * rect would otherwise cover them). */ function ringsLayer(status, phase) {
    const accent = STATUS_COLOR[status];
    const ringR = (36 + phase * 264).toFixed(0);
    const ringOp = (0.5 * (1 - phase)).toFixed(3);
    return `
  <circle cx="108" cy="214" r="${ringR}" fill="none" stroke="${accent}" stroke-width="${(1 + 2.2 * (1 - phase)).toFixed(2)}" opacity="${ringOp}"/>
  <circle cx="108" cy="214" r="${(Number(ringR) * 0.62).toFixed(0)}" fill="none" stroke="${accent}" stroke-width="1.4" opacity="${(0.3 * (1 - phase)).toFixed(3)}"/>`;
}
function shineLayer(status, phase) {
    const accent = STATUS_COLOR[status];
    // sweep beam: rotate(-14°) rect traveling left→right, 240px wide,
    // taller than the card so the rotation never exposes corners
    const sweepX = -720 + phase * (W + 1440) - 120;
    const sweep = `
  <g transform="rotate(-14 ${W / 2} ${H / 2})">
    <rect x="${sweepX.toFixed(0)}" y="-240" width="240" height="${H + 480}" fill="url(#sweepbeam)"/>
  </g>`;
    // bottom traveler: bright segment crossing the footer bar, off-canvas at both ends
    const segX = -300 + phase * (W + 600);
    const traveler = `<rect x="${segX.toFixed(0)}" y="${H - 8}" width="300" height="3" fill="${accent}" opacity="0.9"/>`;
    return `${sweep}${traveler}`;
}
function fmtLadderPrice(p) {
    return p >= 100 ? p.toFixed(2) : p.toFixed(p >= 1 ? 4 : 6);
}
function ladderStrip(l) {
    const vals = [
        l.sl,
        l.entry,
        l.tp1,
        l.tp2,
        l.tp3
    ];
    if (vals.some((v)=>!Number.isFinite(v) || v <= 0)) return "";
    // monotone guard — inverted/crossed ladders are skipped, never redrawn "fixed"
    const ok = l.direction === "LONG" ? l.sl < l.entry && l.entry < l.tp1 && l.tp1 < l.tp2 && l.tp2 < l.tp3 : l.sl > l.entry && l.entry > l.tp1 && l.tp1 > l.tp2 && l.tp2 > l.tp3;
    if (!ok) return "";
    const x0 = 76, x1 = 590, railY = 592;
    const lo = Math.min(...vals), hi = Math.max(...vals);
    const span = hi - lo || 1;
    const X = (p)=>x0 + (p - lo) / span * (x1 - x0);
    const levels = [
        {
            p: l.sl,
            name: "SL",
            col: DANGER,
            banked: false,
            kind: "sl"
        },
        {
            p: l.entry,
            name: "ENTRY",
            col: INK,
            banked: false,
            kind: "entry"
        },
        {
            p: l.tp1,
            name: "TP1",
            col: MINT,
            banked: l.reachedTp >= 1,
            kind: "tp"
        },
        {
            p: l.tp2,
            name: "TP2",
            col: MINT,
            banked: l.reachedTp >= 2,
            kind: "tp"
        },
        {
            p: l.tp3,
            name: "TP3",
            col: GOLD,
            banked: l.reachedTp >= 3,
            kind: "tp"
        }
    ];
    // label stagger — two rows keep close levels readable (mark near a rung, tight ladders)
    const sorted = [
        ...levels
    ].sort((a, b)=>X(a.p) - X(b.p));
    const rowOf = new Map();
    let lastX = -999, lastRow = 0;
    for (const lv of sorted){
        const x = X(lv.p);
        const row = x - lastX < 64 ? (lastRow + 1) % 2 : 0;
        rowOf.set(lv.name, row);
        lastX = x;
        lastRow = row;
    }
    const bankedTp = l.reachedTp >= 3 ? l.tp3 : l.reachedTp >= 2 ? l.tp2 : l.reachedTp >= 1 ? l.tp1 : null;
    const seg = (a, b, col, wdt, op)=>a === b ? "" : `<line x1="${X(Math.min(a, b)).toFixed(1)}" y1="${railY}" x2="${X(Math.max(a, b)).toFixed(1)}" y2="${railY}" stroke="${col}" stroke-width="${wdt}" opacity="${op}" stroke-linecap="round"/>`;
    const segments = seg(l.entry, l.sl, DANGER, 5, 0.3) + seg(l.entry, l.tp3, MINT, 5, 0.22) + (bankedTp !== null ? seg(l.entry, bankedTp, GOLD, 6, 0.9) : "");
    const ticks = levels.map((lv)=>{
        const x = X(lv.p);
        const xs = x.toFixed(1);
        const row = rowOf.get(lv.name) ?? 0;
        const nameY = railY - 16 - row * 16;
        const priceY = railY + 26 + row * 17;
        const mark = lv.kind === "entry" ? `<rect x="${(x - 5).toFixed(1)}" y="${railY - 5}" width="10" height="10" fill="${lv.col}" transform="rotate(45 ${xs} ${railY})" stroke="rgba(6,9,16,0.8)" stroke-width="1.5"/>` : lv.banked ? `<circle cx="${xs}" cy="${railY}" r="7" fill="${GOLD}" filter="url(#softglow)"/><path d="M ${(x - 3).toFixed(1)} ${railY} l 2.4 2.8 l 4 -5.4" stroke="#0b101c" stroke-width="1.8" fill="none" stroke-linecap="round"/>` : `<circle cx="${xs}" cy="${railY}" r="5" fill="rgba(6,9,16,0.85)" stroke="${lv.col}" stroke-width="2.2"/>`;
        return `<line x1="${xs}" y1="${railY - 9}" x2="${xs}" y2="${railY + 9}" stroke="${lv.col}" stroke-width="1.4" opacity="0.55"/>
    <text x="${xs}" y="${nameY}" font-family="DejaVu Sans Mono" font-size="14" fill="${lv.banked ? GOLD : lv.col}" text-anchor="middle" letter-spacing="1" font-weight="${lv.banked ? 700 : 400}">${lv.name}</text>
    <text x="${xs}" y="${priceY}" font-family="DejaVu Sans Mono" font-size="14.5" fill="${lv.banked ? GOLD : MUTED}" text-anchor="middle">${fmtLadderPrice(lv.p)}</text>
    ${mark}`;
    }).join("");
    return `
  <text x="40" y="552" font-family="DejaVu Sans Mono" font-size="15" fill="${MUTED}" letter-spacing="3">PRICE LADDER — BANKED IN GOLD</text>
  ${segments}
  <line x1="${x0 - 14}" y1="${railY}" x2="${x1 + 14}" y2="${railY}" stroke="rgba(138,160,148,0.3)" stroke-width="1"/>
  ${ticks}`;
}
function bannerOverlaySvg(spec, hasLogo, hasArt, skin) {
    const accent = STATUS_COLOR[spec.status];
    const pulse = spec.pulse ?? 0;
    const parts = spec.title.trim().split(/\s+/);
    const symbol = escXml(parts[0] ?? "");
    const direction = /SHORT/i.test(spec.title) ? "SHORT" : "LONG";
    const dirCol = direction === "LONG" ? MINT : DANGER;
    const dirArrow = direction === "LONG" ? "▲" : "▼";
    const base = baseAsset(symbol);
    const badgeCx = 108, badgeCy = 214, badgeR = 56;
    // data rows
    const rows = [];
    if (spec.line1) rows.push({
        text: spec.line1,
        col: accent
    });
    if (spec.line2) rows.push({
        text: spec.line2,
        col: INK
    });
    return `
  <svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    ${defs(spec.status, skin, pulse)}
    ${hasArt ? "" : proceduralBackdrop(spec.status, skin)}
    <rect x="0" y="0" width="${W}" height="${H}" fill="url(#scrim)"/>
    <rect x="0" y="0" width="${W}" height="6" fill="url(#topbar)"/>
    <rect x="0" y="${H - 8}" width="${W}" height="3" fill="${accent}" opacity="${(0.45 + 0.35 * pulse).toFixed(2)}"/>
    ${spec.phase !== undefined ? ringsLayer(spec.status, spec.phase) : ""}
    ${hudTicks(accent)}
    <text x="40" y="52" font-family="DejaVu Sans" font-size="24" font-weight="700" fill="${MUTED}" letter-spacing="7">${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].head}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].sep}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].tail}</text>
    ${tsChip(spec.ts ?? "", 52, 22)}

    <!-- coin badge -->
    <circle cx="${badgeCx}" cy="${badgeCy}" r="${badgeR + 6}" fill="rgba(6,9,16,0.65)" stroke="${PANEL_STROKE}" stroke-width="2"/>
    <circle cx="${badgeCx}" cy="${badgeCy}" r="${badgeR}" fill="rgba(255,255,255,0.04)" stroke="${accent}" stroke-width="3"/>
    ${hasLogo ? "" : `<text x="${badgeCx}" y="${badgeCy + 16}" font-family="DejaVu Sans" font-size="40" font-weight="700" fill="${INK}" text-anchor="middle">${escXml(base.slice(0, 3))}</text>`}

    <!-- symbol + direction -->
    <text x="196" y="200" font-family="DejaVu Sans" font-size="52" font-weight="700" fill="${INK}" letter-spacing="1">${symbol}</text>
    <rect x="196" y="222" rx="17" ry="17" width="168" height="34" fill="${dirCol}" opacity="0.16"/>
    <text x="212" y="247" font-family="DejaVu Sans Mono" font-size="24" font-weight="700" fill="${dirCol}" letter-spacing="3">${dirArrow} ${direction}</text>

    <!-- status headline -->
    <text x="38" y="372" font-family="DejaVu Sans" font-size="104" font-weight="700" fill="${accent}" filter="url(#glow)" letter-spacing="2">${escXml(STATUS_TEXT[spec.status])}</text>

    <!-- separator + data rows -->
    <rect x="40" y="410" width="560" height="2" fill="rgba(138,160,148,0.25)"/>
    ${rows.map((r, i)=>`<text x="40" y="${462 + i * 48}" font-family="DejaVu Sans Mono" font-size="32" fill="${r.col}" letter-spacing="1" filter="url(#softglow)">${escXml(r.text)}</text>`).join("")}

    ${spec.ladder ? ladderStrip(spec.ladder) : ""}

    ${footerBar(spec.ts ?? "", spec.footer ?? "HONEST NUMBERS FROM THE LIVE ENGINE")}
    ${spec.phase !== undefined ? shineLayer(spec.status, spec.phase) : ""}
  </svg>`;
}
function proceduralBackdrop(status, skin) {
    const accent = STATUS_COLOR[status];
    const halo = skin?.accent ?? accent;
    const gx = skin ? [
        W - 240,
        240,
        W / 2
    ][skin.geometry] : W - 240;
    const gy = skin ? [
        H / 2 - 60,
        H / 2 + 40,
        H / 2
    ][skin.geometry] : H / 2 - 60;
    return `<rect x="0" y="0" width="${W}" height="${H}" fill="url(#bgdeep)"/>
  <rect x="0" y="0" width="${W}" height="${H}" fill="url(#bghalo)"/>
  ${gridPattern()}
  <circle cx="${gx}" cy="${gy}" r="230" fill="${halo}" opacity="0.06"/>
  <circle cx="${gx}" cy="${gy}" r="150" fill="${halo}" opacity="0.06"/>`;
}
async function renderSignalBannerV2(spec) {
    const skin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$daily$2d$skin$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dailySkin"])(); // v9.4 daily style rotation — the day's skin dresses every card
    const logo = await loadCoinLogo(spec.title.split(/\s+/)[0] ?? "");
    // AFTERLIFE reuses the EXPIRED artwork — post-expiry verdicts ARE expired
    // signals reporting back; the spectral headline + accents tell them apart.
    const legacyArt = await loadArt(spec.status === "SHORT" ? "SHORT" : spec.status === "FULL" ? "FULL" : spec.status === "AFTERLIFE" ? "EXPIRED" : spec.status);
    const kind = kindForStatus(spec.status);
    const kindArt = await loadSkinKindArt(skin.key, kind);
    const skinArt = kindArt ?? await loadSkinArt(skin.key);
    const backdrop = skinArt ?? legacyArt;
    const overlay = Buffer.from(bannerOverlaySvg(spec, Boolean(logo), Boolean(backdrop), skin));
    const composites = [
        {
            input: overlay
        }
    ];
    if (logo) composites.push({
        input: await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(logo).resize(88, 88).png().toBuffer(),
        left: 108 - 44,
        top: 214 - 44
    });
    if (backdrop) {
        if (skinArt) {
            // kind skin art primary — skin.tune modulation keeps the day's style identity readable
            // cacheKey = the exact art file behind skinArt (kind file or generic fallback)
            const cacheKey = `card:${skin.key}:${kindArt ? kind : "generic"}`;
            return withBackdrop(skinArt, skin, overlay, composites.slice(1), cacheKey);
        }
        const bg = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(legacyArt).resize(W, H, {
            fit: "cover"
        }).modulate({
            brightness: 0.78,
            saturation: 0.88,
            hue: skin.hueShift
        }).toBuffer();
        return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(bg).composite(composites).png({
            compressionLevel: 8
        }).toBuffer();
    }
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(overlay).composite(composites.slice(1)).png({
        compressionLevel: 8
    }).toBuffer();
}
// ── daily performance poster ──
function fmtUsd(v) {
    const sign = v >= 0 ? "+" : "−";
    return `${sign}$${Math.abs(v).toFixed(2)}`;
}
function statCard(x, y, w, h, label, value, col, accentBorder = false) {
    return `
  <rect x="${x}" y="${y}" width="${w}" height="${h}" rx="14" ry="14" fill="${PANEL_BG}" stroke="${accentBorder ? col : PANEL_STROKE}" stroke-width="${accentBorder ? 2 : 1}"/>
  <text x="${x + 20}" y="${y + 34}" font-family="DejaVu Sans Mono" font-size="19" fill="${MUTED}" letter-spacing="3">${escXml(label)}</text>
  <text x="${x + 20}" y="${y + 78}" font-family="DejaVu Sans" font-size="36" font-weight="700" fill="${col}">${escXml(value)}</text>`;
}
function miniStat(x, y, w, h, label, value, col) {
    return `
  <rect x="${x}" y="${y}" width="${w}" height="${h}" rx="12" ry="12" fill="${PANEL_BG}" stroke="${PANEL_STROKE}" stroke-width="1"/>
  <text x="${x + 16}" y="${y + 28}" font-family="DejaVu Sans Mono" font-size="16" fill="${MUTED}" letter-spacing="2">${escXml(label)}</text>
  <text x="${x + w - 16}" y="${y + 46}" font-family="DejaVu Sans" font-size="30" font-weight="700" fill="${col}" text-anchor="end">${escXml(value)}</text>`;
}
function winRateRing(cx, cy, r, pct) {
    const C = 2 * Math.PI * r;
    const frac = pct === null ? 0 : Math.max(0, Math.min(100, pct)) / 100;
    const col = pct === null ? MUTED : pct >= 50 ? MINT : pct >= 35 ? AMBER : DANGER;
    const label = pct === null ? "—" : `${Math.round(pct)}%`;
    return `
  <circle cx="${cx}" cy="${cy}" r="${r}" fill="rgba(10,14,22,0.55)" stroke="${PANEL_STROKE}" stroke-width="1"/>
  <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(255,255,255,0.07)" stroke-width="15"/>
  <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${col}" stroke-width="15" stroke-linecap="round"
    stroke-dasharray="${(frac * C).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 ${cx} ${cy})" filter="url(#softglow)"/>
  <text x="${cx}" y="${cy + 6}" font-family="DejaVu Sans" font-size="40" font-weight="700" fill="${col}" text-anchor="middle">${label}</text>
  <text x="${cx}" y="${cy + 34}" font-family="DejaVu Sans Mono" font-size="15" fill="${MUTED}" text-anchor="middle" letter-spacing="2">WIN RATE</text>`;
}
/** v10.20 EQUITY SPARKLINE — real 14-day realized-equity walk from the DB
 * (dailyReport.equityCurve), last point = live equity mark. Feeds the
 * top-right panel of the daily/weekly poster. */ function sparkline(curve, x, y, w, h) {
    const pts = curve.filter((v)=>Number.isFinite(v));
    if (pts.length < 2) return "";
    const lo = Math.min(...pts), hi = Math.max(...pts);
    const span = hi - lo || Math.max(1, Math.abs(hi) * 0.02);
    const px = (i)=>x + 14 + i / (pts.length - 1) * (w - 28);
    const py = (v)=>y + h - 18 - (v - lo) / span * (h - 40);
    const line = pts.map((v, i)=>`${i === 0 ? "M" : "L"} ${px(i).toFixed(1)} ${py(v).toFixed(1)}`).join(" ");
    const area = `${line} L ${px(pts.length - 1).toFixed(1)} ${(y + h - 12).toFixed(1)} L ${px(0).toFixed(1)} ${(y + h - 12).toFixed(1)} Z`;
    const up = pts[pts.length - 1] >= pts[0];
    const col = up ? MINT : DANGER;
    return `
  <path d="${area}" fill="${col}" opacity="0.10"/>
  <path d="${line}" fill="none" stroke="${col}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" filter="url(#softglow)"/>
  <circle cx="${px(pts.length - 1).toFixed(1)}" cy="${py(pts[pts.length - 1]).toFixed(1)}" r="4" fill="${col}" filter="url(#softglow)"/>`;
}
function posterOverlaySvg(spec, hasArtBackdrop, skin) {
    const d = spec.digest;
    const netCol = d.realizedUsd >= 0 ? MINT : DANGER;
    const weekly = spec.variant === "weekly";
    const trades = (d.trades ?? []).slice(0, 5);
    const maxAbs = Math.max(0.5, ...trades.map((t)=>Math.abs(t.pnl)));
    const cards = [
        [
            weekly ? "NET 7D" : "NET 24H",
            fmtUsd(d.realizedUsd),
            netCol,
            true
        ],
        [
            "EQUITY",
            `$${d.equityUsd.toFixed(2)}`,
            INK
        ],
        [
            "OPEN PNL",
            fmtUsd(d.unrealizedUsd),
            d.unrealizedUsd >= 0 ? MINT : DANGER
        ],
        [
            "FEES",
            `−$${d.feesUsd.toFixed(2)}`,
            MUTED
        ]
    ];
    const cardW = 268, gap = 24, x0 = 40;
    const cardsSvg = cards.map(([label, value, col, hero], i)=>statCard(x0 + i * (cardW + gap), 196, cardW, 118, label, value, col, Boolean(hero))).join("");
    const minis = [
        [
            "DEPLOYED",
            String(d.opened),
            INK
        ],
        [
            "CLOSED",
            String(d.closed),
            INK
        ],
        [
            "ACTIVE NOW",
            String(d.active),
            VIOLET
        ],
        [
            "WINS",
            String(d.wins),
            MINT
        ],
        [
            "STOPS",
            String(d.stops),
            DANGER
        ],
        [
            "EXPIRED",
            String(d.expired),
            AMBER
        ]
    ];
    const mw = 256, mg = 16, mx0 = 440;
    const minisSvg = minis.map(([label, value, col], i)=>{
        const cx = mx0 + i % 3 * (mw + mg);
        const cy = 360 + Math.floor(i / 3) * 86;
        return miniStat(cx, cy, mw, 72, label, value, col);
    }).join("");
    // trade bars (compact rows — must clear the footer bar at y=658)
    const barRows = trades.map((t, i)=>{
        const y = 552 + i * 21;
        const w = Math.max(6, Math.abs(t.pnl) / maxAbs * 300);
        const col = t.pnl >= 0 ? MINT : DANGER;
        const sign = t.pnl >= 0 ? "+" : "";
        return `
    <text x="440" y="${y + 14}" font-family="DejaVu Sans Mono" font-size="16" fill="${MUTED}">${escXml(t.symbol)}</text>
    <rect x="580" y="${y + 2}" width="${w.toFixed(0)}" height="14" rx="7" ry="7" fill="${col}" opacity="0.85"/>
    <text x="${(580 + w + 10).toFixed(0)}" y="${y + 14}" font-family="DejaVu Sans Mono" font-size="16" fill="${col}">${sign}${t.pnl.toFixed(1)}%</text>`;
    }).join("");
    const bestLine = d.best ? `BEST ${d.best.symbol} +${d.best.pnl.toFixed(1)}%` : "NO CLOSED TRADES YET";
    const volLine = d.volCauseCaptures > 0 ? `VOL-CAUSE ${d.volCauseCaptures}${d.topCause ? ` · ${d.topCause}` : ""}` : "";
    // v10.20 equity sparkline panel — top-right, beside the headline. Panel x=864
    // clears the auto-fit headlines (daily 60px / weekly 54px — DejaVu Bold caps
    // run ≈0.72em, measured off the live render where 64px ran under the panel).
    const curve = (d.equityCurve ?? []).filter((v)=>Number.isFinite(v));
    const sparkPanel = curve.length >= 2 ? `
  <rect x="864" y="76" width="380" height="100" rx="14" ry="14" fill="${PANEL_BG}" stroke="${PANEL_STROKE}" stroke-width="1"/>
  <text x="880" y="100" font-family="DejaVu Sans Mono" font-size="13" fill="${MUTED}" letter-spacing="2">EQUITY 14D · REALIZED + LIVE</text>
  <text x="1228" y="100" font-family="DejaVu Sans" font-size="16" font-weight="700" fill="${INK}" text-anchor="end">$${d.equityUsd.toFixed(2)}</text>
  ${sparkline(curve, 864, 76, 380, 100)}` : "";
    return `
  <svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    ${defs("WIN", skin)}
    ${hasArtBackdrop ? "" : proceduralBackdrop("WIN", skin)}
    <rect x="0" y="0" width="${W}" height="${H}" fill="rgba(6,9,16,0.90)"/>
    <rect x="0" y="0" width="${W}" height="6" fill="url(#topbar)"/>
    ${hudTicks(weekly ? VIOLET : GOLD)}
    <text x="40" y="56" font-family="DejaVu Sans" font-size="24" font-weight="700" fill="${MUTED}" letter-spacing="7">${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].head}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].sep}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].tail}</text>
    ${tsChip(spec.ts ?? "", 56, 21)}
    <text x="40" y="140" font-family="DejaVu Sans" font-size="${weekly ? 54 : 60}" font-weight="700" fill="${weekly ? VIOLET : GOLD}" filter="url(#glow)" letter-spacing="2">${weekly ? "WEEKLY PERFORMANCE" : "DAILY PERFORMANCE"}</text>
    <text x="40" y="176" font-family="DejaVu Sans Mono" font-size="22" fill="${MUTED}" letter-spacing="1">${escXml(d.windowLabel)}${skin ? `  ·  SKIN ${skin.name}` : ""}</text>
    ${sparkPanel}
    ${cardsSvg}
    ${winRateRing(230, 500, 108, d.winRatePct)}
    ${minisSvg}
    <text x="440" y="540" font-family="DejaVu Sans Mono" font-size="17" fill="${MUTED}" letter-spacing="3">CLOSED TRADES — NET %</text>
    ${barRows}
    <text x="1240" y="540" font-family="DejaVu Sans Mono" font-size="17" fill="${MINT}" text-anchor="end" letter-spacing="1">${escXml(bestLine)}</text>
    ${footerBar(spec.ts ?? "", volLine || "HONEST NUMBERS FROM THE LIVE ENGINE")}
  </svg>`;
}
async function renderDailyPoster(spec) {
    const skin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$daily$2d$skin$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dailySkin"])();
    const art = await loadSkinArt(skin.key) ?? await loadArt("DAILY");
    const svg = Buffer.from(posterOverlaySvg(spec, Boolean(art), skin));
    if (art) return withBackdrop(art, skin, svg, [], `poster:${skin.key}`);
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$sharp__$5b$external$5d$__$28$sharp$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$sharp$29$__["default"])(svg).png({
        compressionLevel: 8
    }).toBuffer();
}
async function renderWeeklyPoster(spec) {
    return renderDailyPoster({
        ...spec,
        variant: "weekly"
    });
}
}),
"[project]/src/lib/notify.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BANNED_RELAY_TYPES",
    ()=>BANNED_RELAY_TYPES,
    "RELAYABLE_TYPES",
    ()=>RELAYABLE_TYPES,
    "discoverChat",
    ()=>discoverChat,
    "ensureAutoDiscover",
    ()=>ensureAutoDiscover,
    "loadDailyArt",
    ()=>loadDailyArt,
    "primeRelayState",
    ()=>primeRelayState,
    "relayArmed",
    ()=>relayArmed,
    "relayHealth",
    ()=>relayHealth,
    "relaySignalEvent",
    ()=>relaySignalEvent,
    "sendAnimationDirect",
    ()=>sendAnimationDirect,
    "sendChannelTest",
    ()=>sendChannelTest,
    "sendDailyReport",
    ()=>sendDailyReport,
    "sendDirect",
    ()=>sendDirect,
    "sendPhotoDirect",
    ()=>sendPhotoDirect,
    "sendSampleCards",
    ()=>sendSampleCards
]);
// ── FlowRadar Neo v6.3 outbound relay (server-only) ───────────────────────
// TELEGRAM mirror for ALERTABLE engine events. v6.3 operator round:
// «اصلاح ساختار پیام‌های تلگرامی — چیدمان مرتب و خط به خط با ایموجی، و
// تصویر برای سیگنالهای win / stop / EXPIRED». Every relay now sends a
// STRUCTURED HTML card (tidy line-by-line, emoji-labelled fields) and the
// three outcome classes get a RENDERED BANNER IMAGE (dependency-free PNG
// from telegram-image.ts): WIN (TP1/TP2/TP3, mint), STOP (SL, danger),
// EXPIRED (TTL_EXPIRED, amber). Card fields come from the REAL signal row —
// nothing is invented; when the row is unavailable the engine message line
// is relayed verbatim as the honest fallback.
//
// Delivery remains fire-and-forget with hard timeouts so Telegram can never
// stall the engine tick; the error ring + counters feed /api/notify health.
// ── v12.0.1 TASK-46 RELAY REPAIR (operator: «پیام‌های تکراری مدام + تصاویر
// کامل نیست و در بیشتر موارد بدون تصویر») ─────────────────────────────────
// ① RAW-CAL CREATED cards carry their banner again — the v10.4 text-only
//    strip was designed when capture was an occasional mode; the whole book
//    is RAW-CAL now, so MOST cards shipped bare-text (the operator's exact
//    complaint). Photos ship for every CREATED; a 6/hour global flood valve
//    (createdPhotoBudget) stays as the anti-spam backstop.
// ② TTL_EXTENDED hourly-grant spam — the dynamic expiry gate can legitimately
//    grant up to 3× (+60m each); each grant shipped a FULL photo card → the
//    same card every hour. Grant #1 keeps the full card; grants ≥2 degrade to
//    a compact one-line text (mechanics unchanged — the relay policy changed).
// ③ Upload timeouts: photo 9s→20s, animation→25s, apiCall 4.5s→9s — multipart
//    uploads through the memory-starved process + rotating egress pool were
//    aborting → silent text fallback → «بدون تصویر». One photo retry added.
// ④ Caption safety: photo captions >1024 chars are REJECTED by Telegram (the
//    whole send fails → text fallback = another imageless card). The engine
//    message blockquote now truncates to keep the caption ≤1000.
// ── v12.9 RESTART-PROOF DELIVERY — outbox cursor over SignalEvent (trace
// 1a1ba99d0cb24dd9, operator: «توصیه‌های پیشنهادی را کامل و مهندسی اجرا کن») ──
// DIAGNOSIS 2026-11-08: the dev server recycles every ~6–14min under the RAM
// doctrine (lane-B self-recycles at RSS 2.4–2.5GB plateau + pulse-timeout
// restarts when the box is squeezed). Every recycle wipes this module's
// in-memory state and cuts in-flight fire-and-forget sends — cards mid-flight
// at process death were lost FOREVER, and the channel mirror looked dead to
// the operator even though the code path was intact (proven live on a fresh
// boot: a CREATED card reached @mytradeneo in 5s; the losses all sat inside
// restart windows). FIX — never lose a card to a process death:
//   • SignalEvent rows are the natural outbox: fireEvent writes the row
//     BEFORE relaying, so every card has a durable receipt in SQLite.
//   • A persisted cursor (EngineSetting telegram.relayCursor) + a 90s sweeper
//     re-deliver every RELAYABLE event the cursor has not confirmed — across
//     restarts, which is exactly the window the operator was losing.
//   • The cursor advances ONLY on confirmed delivery (operator send ok AND
//     channel mirror ok-or-unconfigured) → at-least-once, never silent loss.
//   • A compare-and-swap lease (telegram.relayLease, 25s TTL) keeps the
//     multiple per-route module copies of dev mode from double-sweeping; a
//     3-attempt cap stops poison events from wedging the walk (counted
//     honestly in relayHealth.replay).
//   • Non-relatable journal rows (PUMP_RADAR ban etc.) are cursor-skipped so
//     the walk can never stall on a banned type.
// Known tradeoff: a channel-mirror failure after a good operator send makes
// the sweeper re-deliver to BOTH planes (rare + transient) — at-least-once is
// the deliberate contract; per-plane dedup would re-introduce silent loss.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/brand.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:child_process [external] (node:child_process, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:crypto [external] (node:crypto, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$os__$5b$external$5d$__$28$node$3a$os$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:os [external] (node:os, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$image$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/telegram-image.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$art$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/telegram-art.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const TOKEN = process.env.TELEGRAM_BOT_TOKEN ?? "";
const ENV_CHAT = process.env.TELEGRAM_CHAT_ID ?? "";
// v12.8 SIGNAL-CHANNEL MIRROR (operator order 2026-11-06 trace 1a1ae5194b0586d9
// «کارت سیگنال جدید باز شده هم به کانال همزمان ارسال بشه», extended trace
// 1a1ae5ccfa2fba91 «کانال چرخه‌ی کامل عمر سیگنال را نشان دهد») — EVERY relayed
// lifecycle card (CREATED birth · TP1/TP2/TP3 rungs · SL stop · TTL_EXPIRED /
// EARLY_EXIT close · TTL_EXTENDED grant · AFTERLIFE follow-up) is mirrored
// VERBATIM to this channel: same card the operator chat receives. Fire-and-
// forget, never blocks the engine or the operator send; empty/unset = mirror
// dormant. Never echo the value.
// v13.0 CHANNEL-ENV SELF-HEAL (forensic audit 2026-11-10, trace 1a1c76eb…):
// /api/notify reported signalChannel.configured=false for DAYS while manual
// scripts to the same channel succeeded — root cause: the const below bound
// process.env ONCE at module load, and the booting process had NO
// TELEGRAM_SIGNAL_CHANNEL in its environment (.env carried zero such lines).
// The target is now read DYNAMICALLY: process.env first, then a mtime-gated
// .env re-scan (≤30s cadence) so a var added/restored mid-flight self-heals
// without waiting for the next recycle. Never echo the value.
let _sigChanCache = null;
let _sigChanScanAt = 0;
let _sigChanEnvMtime = 0;
function signalChannelEnv() {
    const fromEnv = process.env.TELEGRAM_SIGNAL_CHANNEL ?? "";
    if (fromEnv) {
        _sigChanCache = fromEnv;
        _sigChanScanAt = Date.now();
        return fromEnv;
    }
    const now = Date.now();
    if (_sigChanCache !== null && now - _sigChanScanAt < 30_000) return _sigChanCache;
    _sigChanScanAt = now;
    try {
        const p = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".env");
        const st = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["statSync"])(p);
        if (st.mtimeMs !== _sigChanEnvMtime || _sigChanCache === null) {
            _sigChanEnvMtime = st.mtimeMs;
            const m = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(p, "utf8").match(/^TELEGRAM_SIGNAL_CHANNEL=(.*)$/m);
            _sigChanCache = m ? m[1].trim().replace(/^["']|["']$/g, "") : "";
        }
    } catch  {
        _sigChanCache = _sigChanCache ?? "";
    }
    return _sigChanCache;
}
const CHAT_OVERRIDE_KEY = "telegram.chatId";
const ERR_RING_CAP = 8;
const BANNED_RELAY_TYPES = new Set([
    "PUMP_RADAR"
]);
const RELAYABLE_TYPES = new Set([
    "CREATED",
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "TTL_EXPIRED",
    "TTL_EXTENDED",
    "AFTERLIFE",
    "EARLY_EXIT"
]); // v10.4: + EARLY_EXIT — v8.4 R2/R7 early time-exits are real settle outcomes (7 of the last 8 closes) and were silently dropped from the operator mirror · v10.20: PUMP_RADAR removed (operator ban)
const errRing = [];
let sentCount = 0;
let failCount = 0;
let pumpDumpBlocked = 0; // v10.20 honesty counter — banned pump/dump relays swallowed here
let lastSentAt = null;
let botId = null; // learned once via getMe
let botUsername = null;
let chatOverride = null; // EngineSetting override (wins over env)
let overrideLoaded = false;
let bootLogged = false;
let lastAutoDiscoverSkipLog = 0; // v10.16: dev.log spam throttle (was ~3.5k lines/day)
// v12.0.1 — flood valves
let createdPhotoTimes = []; // CREATED photo sends in the trailing hour
let createdPhotoBudgetSkip = 0;
// v12.7 signal-channel mirror state + its own photo flood valve (≤6/hour, same doctrine)
let chSentCount = 0;
let chFailCount = 0;
let chLastSentAt = null;
let chPhotoTimes = [];
let chLiveLogged = false;
let ttlGrantRelaySeen = new Map(); // signalId → last relayed grant number
// v12.9 outbox-cursor state (restart-proof delivery)
const RELAY_CURSOR_KEY = "telegram.relayCursor"; // EngineSetting row: {at,id,by} — last confirmed-delivered SignalEvent
const RELAY_LEASE_KEY = "telegram.relayLease"; // EngineSetting row: {owner,until} — sweeper CAS lease
const REPLAY_GRACE_MS = 10_000; // live path owns the freshest events; the sweeper only walks older ones
const REPLAY_SWEEP_MS = 90_000; // sweeper cadence
const REPLAY_MAX_BATCH = 12; // events per sweep pass
const REPLAY_MAX_ATTEMPTS = 3; // poison-event cap — never wedge the walk
const REPLAY_CATCHUP_CAP_MS = 6 * 3_600_000; // bounded catch-up after a long cursor gap
const replayInstanceId = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["randomUUID"])(); // identity for the CAS lease (per module copy)
let replayScheduled = false;
let replaySent = 0;
let replayFails = 0;
let replaySkipped = 0;
let lastReplayAt = null;
let relayCursorMirror = null; // sync-readable mirror for relayHealth
const replayAttempts = new Map(); // eventId → failed delivery attempts
function pushErr(msg) {
    errRing.unshift(`${new Date().toISOString().slice(11, 19)}Z ${msg}`);
    if (errRing.length > ERR_RING_CAP) errRing.pop();
}
function relayArmed() {
    return TOKEN.length > 0;
}
function relayHealth() {
    const chat = chatOverride ?? ENV_CHAT;
    const chan = signalChannelEnv(); // v13.0 dynamic read — health must reflect the LIVE env, not boot-time luck
    return {
        armed: relayArmed(),
        tokenValid: botId !== null ? true : null,
        botUsername,
        chatId: chat ? `${chat.slice(0, 3)}***${chat.slice(-2)}` : null,
        chatResolved: chat.length > 0 && botId !== null && chat !== String(botId),
        chatSource: chatOverride ? "discovered" : ENV_CHAT ? "env" : "none",
        sent: sentCount,
        failed: failCount,
        lastSentAt,
        lastErrors: [
            ...errRing
        ],
        pumpDumpBlocked,
        animSent,
        animFails,
        createdPhotoBudgetSkip,
        signalChannel: {
            configured: chan.length > 0,
            target: chan ? `${chan.slice(0, 1)}***${chan.slice(-4)}` : null,
            sent: chSentCount,
            failed: chFailCount,
            lastSentAt: chLastSentAt
        },
        replay: {
            cursorAt: relayCursorMirror?.at ?? null,
            sent: replaySent,
            fails: replayFails,
            skipped: replaySkipped,
            lastSweepAt: lastReplayAt
        }
    };
}
/** Load the persisted chat override (EngineSetting telegram.chatId) once.
 * op-audit-20260908: must run BEFORE the boot log — the first boot log used to
 * print "DORMANT · TELEGRAM_CHAT_ID unset" even when the chat id was already
 * persisted, because ensureAutoDiscover→getMe logged before resolveChat ever
 * loaded the override. One DB read, once per module instance. */ async function loadOverride() {
    if (overrideLoaded) return;
    overrideLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: CHAT_OVERRIDE_KEY
            }
        });
        if (row?.value) chatOverride = row.value;
    } catch  {}
}
async function ensureBotIdentity() {
    if (botId !== null || !TOKEN) return;
    await loadOverride(); // truthful boot log — persisted chat counts as resolved
    try {
        const ctrl = new AbortController();
        const t = setTimeout(()=>ctrl.abort(), 4500);
        const res = await fetch(`https://api.telegram.org/bot${TOKEN}/getMe`, {
            signal: ctrl.signal,
            cache: "no-store"
        });
        clearTimeout(t);
        const json = await res.json();
        if (json.ok && json.result) {
            botId = json.result.id;
            botUsername = json.result.username ?? null;
            if (!bootLogged) {
                bootLogged = true;
                const chat = chatOverride ?? ENV_CHAT;
                const selfRefused = chat === String(botId);
                const chan = signalChannelEnv(); // v13.0 dynamic
                console.log(`[NOTIFY] telegram relay ${selfRefused ? "ARMED (chat PENDING)" : chat ? "ARMED" : "DORMANT (no chat)"} — bot @${botUsername} (#${botId})${selfRefused ? ` · TELEGRAM_CHAT_ID equals the bot's own id — Telegram rejects bot→bot sends; waiting for discoverChat()/override` : chat ? ` · chat ${chat.slice(0, 3)}***${chat.slice(-2)}` : " · TELEGRAM_CHAT_ID unset"}${chan ? ` · signal-channel mirror → ${chan.slice(0, 1)}***${chan.slice(-4)} (full lifecycle)` : ""}`);
            }
        }
    } catch (e) {
        pushErr(`getMe failed: ${e instanceof Error ? e.message : String(e)}`);
    }
}
async function resolveChat() {
    await ensureBotIdentity();
    await loadOverride();
    const chat = chatOverride ?? ENV_CHAT;
    if (!chat || botId === null || chat === String(botId)) return null;
    return chat;
}
async function apiCall(method, body, timeoutMs = 9000) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
    try {
        const res = await fetch(`https://api.telegram.org/bot${TOKEN}/${method}`, {
            method: "POST",
            headers: {
                "content-type": "application/json"
            },
            body: JSON.stringify(body),
            signal: ctrl.signal,
            cache: "no-store"
        });
        const json = await res.json();
        return json.ok ? {
            ok: true,
            result: json.result
        } : {
            ok: false,
            error: json.description ?? `HTTP ${res.status}`
        };
    } catch (e) {
        return {
            ok: false,
            error: e instanceof Error ? e.name === "AbortError" ? `timeout ${timeoutMs}ms` : e.message : String(e)
        };
    } finally{
        clearTimeout(timer);
    }
}
/** Multipart photo upload (sendPhoto) — FormData/Blob are global in Node 18+.
 * v12.0.1: 20s (was 9s — multipart uploads through the starved process/egress
 * pool were aborting into the text fallback), + ONE retry on timeout/5xx. */ async function apiSendPhoto(chat, caption, photo, filename) {
    let last = {
        ok: false,
        error: "unsent"
    };
    for(let attempt = 0; attempt < 2; attempt++){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), 20_000);
        try {
            const isPng = filename.toLowerCase().endsWith(".png");
            const form = new FormData();
            form.append("chat_id", chat);
            form.append("caption", caption.slice(0, 1024));
            form.append("parse_mode", "HTML");
            form.append("photo", new Blob([
                new Uint8Array(photo)
            ], {
                type: isPng ? "image/png" : "image/jpeg"
            }), filename);
            const res = await fetch(`https://api.telegram.org/bot${TOKEN}/sendPhoto`, {
                method: "POST",
                body: form,
                signal: ctrl.signal,
                cache: "no-store"
            });
            const json = await res.json();
            last = json.ok ? {
                ok: true
            } : {
                ok: false,
                error: json.description ?? `HTTP ${res.status}`
            };
        } catch (e) {
            last = {
                ok: false,
                error: e instanceof Error ? e.name === "AbortError" ? "timeout 20000ms" : e.message : String(e)
            };
        } finally{
            clearTimeout(timer);
        }
        if (last.ok) return last;
        if (!(last.error ?? "").includes("timeout") && !/HTTP 5\d\d/.test(last.error ?? "")) return last; // only transient classes retry
        await new Promise((r)=>setTimeout(r, 1200));
    }
    return last;
}
function esc(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
// ── v10.21 ANIMATED OUTCOME CARDS ──────────────────────────────
// TP1/TP2/TP3 (WIN + FULL) cards ship as a 14-frame motion MP4:
// sharp renders each frame with the v10.21 motion layer (diagonal sweep beam
// + sonar pings + headline glow breathing + bottom traveler) → ffmpeg
// (image2pipe → libx264, faststart) → sendAnimation. v10.20's pulse-only
// loop was invisible after H.264 compression (operator: «هیچ موشنی ندارد»)
// — the motion layer is now impossible to miss, and crf 26→23 keeps the
// beam intact. Budget-guarded (max 8/hour + ≥45s gap) so a burst of
// outcomes can never flood the chat; every failure degrades silently to
// the static sendPhoto path. The TEXT is always the payload — the
// animation is presentation, never a blocker.
const ANIMATED_TYPES = new Set([
    "TP1",
    "TP2",
    "TP3"
]);
const ANIM_FRAMES = 14;
const ANIM_FPS = 12;
const ANIM_MAX_PER_HOUR = 8;
const ANIM_MIN_GAP_MS = 45_000;
let animTimes = [];
let animSent = 0;
let animFails = 0;
function animBudgetOk() {
    const now = Date.now();
    animTimes = animTimes.filter((t)=>now - t < 3_600_000);
    if (animTimes.length > 0 && now - animTimes[animTimes.length - 1] < ANIM_MIN_GAP_MS) return false;
    return animTimes.length < ANIM_MAX_PER_HOUR;
}
async function renderAnimFrames(spec) {
    const frames = [];
    for(let i = 0; i < ANIM_FRAMES; i++){
        const phase = i / ANIM_FRAMES;
        const pulse = 0.5 - 0.5 * Math.cos(2 * Math.PI * phase); // smooth 0→1→0 loop
        frames.push(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$art$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["renderSignalBannerV2"])({
            ...spec,
            pulse,
            phase
        }));
    }
    return frames;
}
/** 12 PNG frames in → H.264 MP4 out (≤20s hard kill). null on any failure —
 * the static photo path takes over, the alert never waits. NOTE: the MP4
 * muxer cannot write to a pipe ("does not support non seekable output") so
 * the encode lands in a transient temp file, is read back and unlinked. */ function encodeAnimMp4(frames) {
    return new Promise((resolve)=>{
        const tmpPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$os__$5b$external$5d$__$28$node$3a$os$2c$__cjs$29$__["tmpdir"])(), `nexus-anim-${process.pid}-${Date.now()}.mp4`);
        let child;
        try {
            child = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__["spawn"])("ffmpeg", [
                "-hide_banner",
                "-loglevel",
                "error",
                "-y",
                "-f",
                "image2pipe",
                "-framerate",
                String(ANIM_FPS),
                "-i",
                "-",
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "23",
                "-pix_fmt",
                "yuv420p",
                "-movflags",
                "+faststart",
                tmpPath
            ], {
                stdio: [
                    "pipe",
                    "ignore",
                    "pipe"
                ]
            });
        } catch  {
            resolve(null);
            return;
        }
        let errTail = "";
        let done = false;
        const finish = (v)=>{
            if (!done) {
                done = true;
                void __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].unlink(tmpPath).catch(()=>undefined);
                resolve(v);
            }
        };
        const killer = setTimeout(()=>{
            child.kill("SIGKILL");
            finish(null);
        }, 20_000);
        child.stderr?.on("data", (c)=>{
            errTail = (errTail + c.toString()).slice(-300);
        });
        child.on("error", ()=>{
            clearTimeout(killer);
            finish(null);
        });
        child.on("close", (code)=>{
            clearTimeout(killer);
            if (code !== 0) {
                if (errTail) console.error(`[NOTIFY] anim encode failed (code ${code}): ${errTail.trim().split("\n").pop()}`);
                finish(null);
                return;
            }
            __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(tmpPath).then((buf)=>finish(buf.length > 1024 ? buf : null)).catch(()=>finish(null));
        });
        void (async ()=>{
            try {
                for (const f of frames){
                    if (done) break;
                    if (!child.stdin.write(f)) await new Promise((r)=>child.stdin.once("drain", ()=>r()));
                }
                child.stdin.end();
            } catch  {
                child.kill("SIGKILL");
            }
        })();
    });
}
/** Multipart sendAnimation — mirrors apiSendPhoto (FormData/Blob global). */ async function apiSendAnimation(chat, caption, mp4, filename) {
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), 25_000); // v12.0.1: was 12s — MP4 uploads need headroom under memory pressure
    try {
        const form = new FormData();
        form.append("chat_id", chat);
        form.append("caption", caption.slice(0, 1024));
        form.append("parse_mode", "HTML");
        form.append("width", "1280");
        form.append("height", "720");
        form.append("animation", new Blob([
            new Uint8Array(mp4)
        ], {
            type: "video/mp4"
        }), filename);
        const res = await fetch(`https://api.telegram.org/bot${TOKEN}/sendAnimation`, {
            method: "POST",
            body: form,
            signal: ctrl.signal,
            cache: "no-store"
        });
        const json = await res.json();
        return json.ok ? {
            ok: true
        } : {
            ok: false,
            error: json.description ?? `HTTP ${res.status}`
        };
    } catch (e) {
        return {
            ok: false,
            error: e instanceof Error ? e.name === "AbortError" ? "timeout 25000ms" : e.message : String(e)
        };
    } finally{
        clearTimeout(timer);
    }
}
function fmtPrice(p) {
    return p >= 100 ? p.toFixed(2) : p.toFixed(p >= 1 ? 4 : 6);
}
const ART_FILES = {
    WIN: "WIN.jpg",
    STOP: "STOP.jpg",
    EXPIRED: "EXPIRED.jpg",
    NEW: "NEW.jpg",
    SHORT: "SHORT.jpg",
    TTL_EXT: "TTL.jpg",
    FULL: "FULL.jpg",
    AFTERLIFE: "AFTERLIFE.jpg"
};
const artCache = new Map();
async function loadOperatorArt(kind) {
    if (artCache.has(kind)) return artCache.get(kind) ?? null;
    try {
        const buf = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), "assets", "telegram", ART_FILES[kind]));
        artCache.set(kind, buf);
        return buf;
    } catch  {
        artCache.set(kind, null);
        return null;
    }
}
const HEADLINE = {
    CREATED: {
        emoji: "🚀",
        title: "NEW SIGNAL DEPLOYED"
    },
    TP1: {
        emoji: "💰",
        title: "TP1 HIT — 50% BOOKED"
    },
    TP2: {
        emoji: "💰💰",
        title: "TP2 HIT — 80% BOOKED"
    },
    TP3: {
        emoji: "🏆",
        title: "FULL LADDER — TP3 CAPTURED"
    },
    SL: {
        emoji: "🛑",
        title: "STOPPED OUT"
    },
    TTL_EXPIRED: {
        emoji: "⏰",
        title: "SIGNAL EXPIRED"
    },
    EARLY_EXIT: {
        emoji: "🚪",
        title: "EARLY TIME-EXIT"
    },
    TTL_EXTENDED: {
        emoji: "⏳",
        title: "TTL EXTENDED"
    },
    AFTERLIFE: {
        emoji: "🔮",
        title: "EXPIRED FOLLOW-UP"
    },
    // v9.0 PUMP/DUMP RADAR — flow tracking declarations + resolutions + unlock
    PUMP_RADAR: {
        emoji: "📡",
        title: "PUMP/DUMP RADAR"
    }
};
const BANNER_STATUS = {
    CREATED: "NEW",
    TP1: "WIN",
    TP2: "WIN",
    TP3: "FULL",
    SL: "STOP",
    TTL_EXPIRED: "EXPIRED",
    TTL_EXTENDED: "TTL_EXT",
    AFTERLIFE: "AFTERLIFE",
    EARLY_EXIT: "EXPIRED"
};
/** Tehran wall-clock stamp for artwork corners — presentation only. */ function tehranStamp() {
    return `${new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Tehran",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    }).format(new Date()).replace(",", "")} TEHRAN`;
}
/** The tidy line-by-line HTML body shared by live cards and sample proofs. */ function composeSignalText(type, sig, engineMessage) {
    const head = HEADLINE[type] ?? {
        emoji: "📡",
        title: type
    };
    const dirEmoji = sig.direction === "LONG" ? "🟢 LONG" : "🔴 SHORT";
    const serial = `NX-${String(sig.serial).padStart(4, "0")}`;
    const pnl = sig.pnlPercent ?? 0;
    const pnlLine = `${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}% NET`;
    const reached = sig.reachedTp ?? 0;
    const lines = [
        `${head.emoji} <b>${esc(head.title)}</b>`,
        `${dirEmoji} · <b>${esc(sig.symbol)}</b> · <i>${esc(sig.strategy)}${sig.timeframe ? ` (${esc(sig.timeframe)})` : ""}</i>`,
        "",
        `🎯 TP1: <code>${fmtPrice(sig.tp1)}</code>   💰 TP2: <code>${fmtPrice(sig.tp2)}</code>   🏆 TP3: <code>${fmtPrice(sig.tp3)}</code>`,
        `🛑 Stop: <code>${fmtPrice(sig.stopLoss)}</code>   📍 Entry: <code>${fmtPrice(sig.entryPrice)}</code>`,
        "",
        `⚡ Leverage: <b>${sig.leverage}x</b>   💵 Margin: <b>$${sig.marginUsd.toFixed(0)}</b>   📐 R:R <b>1:${sig.riskReward.toFixed(1)}</b>`,
        `📊 Conviction: <b>${sig.confidence}%</b>   ⏳ TTL: <b>${sig.ttlMinutes}m</b>${sig.ttlExtensions ? ` (+${sig.ttlExtensions} ext)` : ""}`
    ];
    if (type !== "CREATED") {
        lines.push(`💵 Result: <b>${pnl >= 0 ? "✅" : "❌"} ${esc(pnlLine)}</b>   🪜 Ladder: <b>${reached}/3</b>`);
    }
    lines.push("", `<blockquote>💬 ${esc(engineMessage)}</blockquote>`);
    lines.push(`<i>🤖 ${esc(serial)} · FLOWRADAR-NEO AI live engine</i>`);
    return lines.join("\n");
}
async function buildCard(type, symbol, engineMessage, signalId) {
    const head = HEADLINE[type] ?? {
        emoji: "📡",
        title: type
    };
    const sig = signalId ? await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findUnique({
        where: {
            id: signalId
        }
    }).catch(()=>null) : null;
    if (!sig) {
        // honest fallback — engine line only
        return {
            text: `${head.emoji} <b>${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["APP_NAME"]} — ${esc(head.title)}</b>\n${symbol ? `📊 <b>${esc(symbol)}</b>\n` : ""}\n<blockquote>${esc(engineMessage)}</blockquote>`
        };
    }
    const text = composeSignalText(type, sig, engineMessage);
    const banner = BANNER_STATUS[type];
    if (!banner) return {
        text
    };
    // CREATED cards are direction-aware: the red bear artwork ships for SHORT
    // deployments, the rocket/bull for LONG.
    const kind = type === "CREATED" && sig.direction === "SHORT" ? "SHORT" : banner;
    const serial = `NX-${String(sig.serial).padStart(4, "0")}`;
    const pnl = sig.pnlPercent ?? 0;
    const pnlLine = `${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}% NET`;
    const reached = sig.reachedTp ?? 0;
    const line2 = type === "SL" ? `RISK CONTAINED · LADDER ${reached}/3` : type === "TTL_EXPIRED" ? `TTL ${sig.ttlMinutes}M ELAPSED · LADDER ${reached}/3` : type === "EARLY_EXIT" ? `EARLY CUT (R2/R7) · LADDER ${reached}/3` : type === "TTL_EXTENDED" ? `+${sig.ttlExtensions} EXT · STILL LIVE` : type === "AFTERLIFE" ? `POST-EXPIRY ${(sig.afterlife ?? "TRACKING").replace(/_/g, " ")} · MFE ${(sig.maxPostPnlPercent ?? 0) >= 0 ? "+" : ""}${(sig.maxPostPnlPercent ?? 0).toFixed(1)}%` : type === "CREATED" ? `ENTRY ${fmtPrice(sig.entryPrice)} · RR 1:${sig.riskReward.toFixed(1)}` : `LADDER ${reached}/3 BANKED · RR 1:${sig.riskReward.toFixed(1)}`;
    const spec = {
        status: kind,
        title: `${sig.symbol} ${sig.direction}`,
        line1: `${serial} · ${pnlLine}`,
        line2,
        ts: tehranStamp(),
        // v10.20 PRICE LADDER — structural anatomy from the real row (SL/ENTRY/
        // TP1-3, banked rungs gold). ladderStrip self-guards: inverted/crossed
        // rows (qualityFlag INVERTED_STOP legacy) render no ladder, never a
        // redrawn "fixed" one. No live MARK on artwork — honesty doctrine.
        ladder: {
            direction: sig.direction === "SHORT" ? "SHORT" : "LONG",
            entry: sig.entryPrice,
            tp1: sig.tp1,
            tp2: sig.tp2,
            tp3: sig.tp3,
            sl: sig.stopLoss,
            reachedTp: sig.reachedTp ?? 0
        }
    };
    // v8.1: professional composite (AI art + coin logo + live data) first; the
    // operator JPG set and the pixel-font banner remain as fallbacks.
    try {
        const photo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$art$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["renderSignalBannerV2"])(spec);
        return {
            text,
            photo,
            photoName: `${kind.toLowerCase()}-${serial}.png`,
            bannerSpec: spec
        };
    } catch  {}
    const art = await loadOperatorArt(kind);
    if (art) return {
        text,
        photo: art,
        photoName: ART_FILES[kind]
    };
    return {
        text,
        photo: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$image$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["renderStatusBanner"])(spec),
        photoName: `${kind.toLowerCase()}-${serial}.png`
    };
}
// ── v12.8 SIGNAL-CHANNEL MIRROR (operator orders 2026-11-06, traces
// 1a1ae5194b0586d9 + 1a1ae5ccfa2fba91) ──
// FULL-LIFECYCLE cards ride to the public signal channel VERBATIM — the exact
// final card the operator chat received (post flood-valve/caption-compaction),
// photo banner + caption or the text fallback. Animated operator sends (TP
// MP4s) mirror as their static PNG — presentation differs, payload identical,
// and the channel never burns the animation budget. Fire-and-forget: failures
// are counted + ringed and NEVER touch the operator send or the engine hot
// path. Own photo flood valve (≤6/hour, overflow → same card as text) mirrors
// operator doctrine.
async function mirrorCardToChannel(card) {
    const chan = signalChannelEnv(); // v13.0 dynamic read — never depend on boot-time env luck
    if (!chan) return;
    let out = card;
    if (out.photo) {
        const nowH = Date.now();
        chPhotoTimes = chPhotoTimes.filter((t)=>nowH - t < 3_600_000);
        if (chPhotoTimes.length >= 6) out = {
            text: out.text
        }; // valve overflow → text, still honest
        else chPhotoTimes.push(nowH);
    }
    let r;
    if (out.photo) {
        r = await apiSendPhoto(chan, out.text, out.photo, out.photoName ?? "flowradar-signal.png");
        if (!r.ok) r = await apiCall("sendMessage", {
            chat_id: chan,
            text: out.text.slice(0, 3800),
            parse_mode: "HTML",
            disable_web_page_preview: true
        });
    } else {
        r = await apiCall("sendMessage", {
            chat_id: chan,
            text: out.text.slice(0, 3800),
            parse_mode: "HTML",
            disable_web_page_preview: true
        });
    }
    if (r.ok) {
        chSentCount++;
        chLastSentAt = Date.now();
        if (!chLiveLogged) {
            chLiveLogged = true;
            console.log(`[NOTIFY] signal-channel mirror LIVE → ${chan.slice(0, 1)}***${chan.slice(-4)} (first lifecycle card delivered)`);
        }
    } else {
        chFailCount++;
        pushErr(`channel: ${r.error}`);
        console.error(`[NOTIFY] signal-channel mirror send failed: ${r.error}`);
    }
}
async function readRelaySettingJson(key) {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key
            }
        });
        if (!row?.value) return null;
        return JSON.parse(row.value);
    } catch  {
        return null;
    }
}
/** True if cursor `a` is at-or-after `b` in the (createdAt, id) walk order. */ function cursorAtOrAfter(a, b) {
    if (a.at !== b.at) return a.at > b.at;
    return a.id >= b.id;
}
/** CAS-advance the persisted cursor to `to`. Losing a race is fine — another
 * copy advanced past us, which by walk order means the event was handled. */ async function advanceRelayCursor(to) {
    for(let i = 0; i < 3; i++){
        const cur = await readRelaySettingJson(RELAY_CURSOR_KEY);
        if (cur && cursorAtOrAfter(cur, to)) return true; // already past — another writer won
        if (!cur) {
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.create({
                    data: {
                        key: RELAY_CURSOR_KEY,
                        value: JSON.stringify(to)
                    }
                });
                relayCursorMirror = to;
                return true;
            } catch  {
            /* unique-key race → re-read and CAS on the next iteration */ }
            continue;
        }
        const r = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.updateMany({
            where: {
                key: RELAY_CURSOR_KEY,
                value: JSON.stringify(cur)
            },
            data: {
                value: JSON.stringify(to)
            }
        });
        if (r.count === 1) {
            relayCursorMirror = to;
            return true;
        }
    }
    return false;
}
function scheduleReplaySweep() {
    if (replayScheduled) return;
    replayScheduled = true;
    const first = setTimeout(()=>{
        void sweepReplayOnce().catch(()=>undefined);
    }, 8_000);
    first.unref?.();
    const timer = setInterval(()=>{
        void sweepReplayOnce().catch(()=>undefined);
    }, REPLAY_SWEEP_MS);
    timer.unref?.();
}
/** v12.9 RESTART SWEEPER — walk the SignalEvent outbox from the persisted
 * cursor and re-deliver every card the cursor has not confirmed. This is the
 * fix for the restart-window card losses the operator reported: a card whose
 * fire-and-forget send was cut by a process death still has its durable
 * journal row, so the next live copy sweeps it to the operator chat + channel
 * exactly as if it had been sent live. */ async function sweepReplayOnce() {
    if (!relayArmed()) return;
    const now = Date.now();
    // ── CAS lease: only one module copy sweeps at a time (dev mode compiles
    // several copies of this module — every one of them runs this interval). ──
    const lease = await readRelaySettingJson(RELAY_LEASE_KEY);
    if (lease && lease.until > now && lease.owner !== replayInstanceId) return;
    const leaseStr = JSON.stringify({
        owner: replayInstanceId,
        until: now + 25_000
    });
    const claimed = lease ? (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.updateMany({
        where: {
            key: RELAY_LEASE_KEY,
            value: JSON.stringify(lease)
        },
        data: {
            value: leaseStr
        }
    })).count === 1 : await (async ()=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.create({
                data: {
                    key: RELAY_LEASE_KEY,
                    value: leaseStr
                }
            });
            return true;
        } catch  {
            return false;
        }
    })();
    if (!claimed) return;
    lastReplayAt = now;
    try {
        let cur = await readRelaySettingJson(RELAY_CURSOR_KEY);
        if (!cur) {
            // first deploy: initialize at "now" — never flood the channel with
            // ancient history; from this moment every event is cursor-tracked.
            await advanceRelayCursor({
                at: now,
                id: "",
                by: "init"
            });
            return;
        }
        if (cur.at < now - REPLAY_CATCHUP_CAP_MS) {
            const floorAt = now - REPLAY_CATCHUP_CAP_MS;
            await advanceRelayCursor({
                at: floorAt,
                id: cur.id,
                by: "catchup-cap"
            });
            pushErr(`replay: cursor jumped forward to bound catch-up (${Math.round((cur.at - floorAt) / 60_000)}min skipped)`);
            cur = {
                at: floorAt,
                id: cur.id
            };
        }
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.findMany({
            where: {
                AND: [
                    {
                        createdAt: {
                            lt: new Date(now - REPLAY_GRACE_MS)
                        }
                    },
                    {
                        OR: [
                            {
                                createdAt: {
                                    gt: new Date(cur.at)
                                }
                            },
                            ...cur.id ? [
                                {
                                    createdAt: new Date(cur.at),
                                    id: {
                                        gt: cur.id
                                    }
                                }
                            ] : []
                        ]
                    }
                ]
            },
            orderBy: [
                {
                    createdAt: "asc"
                },
                {
                    id: "asc"
                }
            ],
            take: REPLAY_MAX_BATCH,
            select: {
                id: true,
                type: true,
                symbol: true,
                message: true,
                signalId: true,
                createdAt: true
            }
        });
        for (const ev of rows){
            const curNow = {
                at: Number(ev.createdAt),
                id: ev.id,
                by: "sweep"
            };
            if (BANNED_RELAY_TYPES.has(ev.type) || !RELAYABLE_TYPES.has(ev.type)) {
                // non-relatable journal row — the cursor must still walk past it or the
                // whole outbox would stall on a banned type
                replaySkipped++;
                await advanceRelayCursor(curNow);
                continue;
            }
            const attempts = replayAttempts.get(ev.id) ?? 0;
            if (attempts >= REPLAY_MAX_ATTEMPTS) {
                replayFails++;
                replayAttempts.delete(ev.id);
                pushErr(`replay: ${ev.type} ${ev.id.slice(-6)} dropped after ${REPLAY_MAX_ATTEMPTS} failed attempts`);
                await advanceRelayCursor(curNow);
                continue;
            }
            let res;
            try {
                res = await deliverSignalEvent(ev.type, ev.symbol, ev.message, ev.signalId);
            } catch (e) {
                res = {
                    operatorOk: false,
                    channelOk: false,
                    chatPending: false
                };
                pushErr(`replay ${ev.type}: ${e instanceof Error ? e.message : String(e)}`);
            }
            if (res.operatorOk && res.channelOk) {
                replaySent++;
                replayAttempts.delete(ev.id);
                await advanceRelayCursor(curNow);
            } else if (res.chatPending) {
                break; // honest pending state — leave for the next sweep, do not burn attempts
            } else {
                replayFails++;
                replayAttempts.set(ev.id, attempts + 1);
                break; // stop the pass on first failure — strict in-order retry next sweep
            }
        }
    } finally{
    /* lease expires on its own (25s TTL) — no release write needed */ }
}
/** v12.9: the single delivery body — used by BOTH the live fire-and-forget
 * path and the restart sweeper, so a replayed card is byte-identical to the
 * live one. Returns per-plane truth so the cursor only advances on real
 * delivery (at-least-once, never silent loss). */ async function deliverSignalEvent(type, symbol, message, signalId) {
    const chat = await resolveChat();
    if (!chat) return {
        operatorOk: false,
        channelOk: false,
        chatPending: true
    }; // honest pending state — not an error, no doomed send
    // ── v12.0.1 TASK-46 relay policy ──
    // ① RAW-CAL CREATED cards ship their banner again (v10.4 text-only strip
    // removed — the whole book is capture-mode now, so MOST cards went bare).
    // Flood valve: ≤6 CREATED photo posters/hour, overflow → text + counter.
    // ② TTL_EXTENDED grant #1 → full photo card; grants ≥2 → compact one-line
    // text (the hourly-grant spam the operator reported). Mechanics unchanged.
    let rawCalTextOnly = false;
    let ttlGrantNo = 0;
    if (type === "CREATED" && signalId) {
        const sig = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findUnique({
            where: {
                id: signalId
            },
            select: {
                tags: true
            }
        }).catch(()=>null);
        if (sig?.tags?.includes("RAW-CAL")) {
            const nowH = Date.now();
            createdPhotoTimes = createdPhotoTimes.filter((t)=>nowH - t < 3_600_000);
            if (createdPhotoTimes.length >= 6) {
                rawCalTextOnly = true; // flood valve — still honest, just lighter
                createdPhotoBudgetSkip++;
            } else createdPhotoTimes.push(nowH);
        }
    }
    if (type === "TTL_EXTENDED" && signalId) {
        const sig = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findUnique({
            where: {
                id: signalId
            },
            select: {
                ttlExtensions: true
            }
        }).catch(()=>null);
        ttlGrantNo = sig?.ttlExtensions ?? 0;
        const seen = ttlGrantRelaySeen.get(signalId);
        if (seen !== undefined && ttlGrantNo <= seen) return {
            operatorOk: true,
            channelOk: true,
            chatPending: false
        }; // defensive: identical grant re-fire → swallow (v12.9: counts as already-delivered for the cursor)
        ttlGrantRelaySeen.set(signalId, ttlGrantNo);
        if (ttlGrantRelaySeen.size > 64) {
            const oldest = [
                ...ttlGrantRelaySeen.entries()
            ].sort((a, b)=>a[1] - b[1])[0];
            if (oldest) ttlGrantRelaySeen.delete(oldest[0]);
        }
    }
    let card;
    try {
        card = await buildCard(type, symbol, message, signalId ?? null);
    } catch  {
        card = {
            text: `📡 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["APP_NAME"]} ${type}${symbol ? ` · ${esc(symbol)}` : ""}\n${esc(message)}`.slice(0, 3800)
        };
    }
    if (rawCalTextOnly) card = {
        text: card.text
    }; // flood-valve overflow → text (v10.4 heritage, now budget-gated)
    // TTL grant #2+: compact one-line text — the operator already got the full
    // card for grant #1; hourly identical art posters were the reported spam.
    if (type === "TTL_EXTENDED" && ttlGrantNo > 1) {
        const sym = symbol ?? "?";
        card = {
            text: `⏳ <b>TTL extended again</b> · ${esc(sym)} — grant #${ttlGrantNo} (same setup still near its rung; full card was grant #1 · dashboard shows the live mark)`
        };
    }
    // v12.0.1 caption safety: Telegram REJECTS photo captions >1024 → the whole
    // image send fails → text fallback (another imageless card). Compact the
    // blockquote to keep the caption under the cap.
    if (card.photo && card.text.length > 1000) {
        const m = card.text.match(/<blockquote>[\s\S]*?<\/blockquote>/);
        if (m) {
            const room = 1000 - (card.text.length - m[0].length);
            if (room > 40) {
                const inner = m[0].slice(12, -14);
                card = {
                    ...card,
                    text: card.text.replace(m[0], `<blockquote>💬 ${inner.slice(0, Math.max(0, room - 30))}…</blockquote>`)
                };
            } else card = {
                ...card,
                text: card.text.replace(m[0], "")
            };
        }
        if (card.text.length > 1000) card = {
            ...card,
            text: card.text.slice(0, 1000)
        };
    }
    let r = null;
    // v10.20 ANIMATED OUTCOME CARDS — TP1/TP2/TP3 first try the 12-frame
    // glow-pulse MP4 (budget-guarded); any miss degrades to the static photo.
    let animated = false;
    if (card.photo && card.bannerSpec && ANIMATED_TYPES.has(type) && animBudgetOk()) {
        try {
            const frames = await renderAnimFrames(card.bannerSpec);
            const mp4 = await encodeAnimMp4(frames);
            if (mp4) {
                const mp4Name = `${(card.photoName ?? "flowradar-signal.png").replace(/\.png$/i, "")}.mp4`;
                const a = await apiSendAnimation(chat, card.text, mp4, mp4Name);
                if (a.ok) {
                    animated = true;
                    animSent++;
                    animTimes.push(Date.now());
                    r = {
                        ok: true
                    };
                } else {
                    animFails++;
                    pushErr(`anim ${type}: ${a.error}`);
                }
            } else {
                animFails++;
            }
        } catch (e) {
            animFails++;
            pushErr(`anim ${type}: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    if (card.photo && !animated) {
        r = await apiSendPhoto(chat, card.text, card.photo, card.photoName ?? "flowradar-signal.png");
        if (!r.ok) {
            // photo failed (size/network) — retry once as plain HTML text so the
            // alert still lands; banner is presentation, the message is the payload
            r = await apiCall("sendMessage", {
                chat_id: chat,
                text: card.text.slice(0, 3800),
                parse_mode: "HTML",
                disable_web_page_preview: true
            });
        }
    } else if (!card.photo && !animated) {
        r = await apiCall("sendMessage", {
            chat_id: chat,
            text: card.text.slice(0, 3800),
            parse_mode: "HTML",
            disable_web_page_preview: true
        });
    }
    const operatorOk = !!(r && r.ok);
    if (operatorOk) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`${type}: ${r?.error ?? "?"}`);
        console.error(`[NOTIFY] telegram relay send failed (${type}): ${r?.error ?? "?"}`);
    }
    let channelOk = true;
    // v12.8 — operator order «کانال چرخه‌ی کامل عمر سیگنال را نشان دهد»:
    // mirror EVERY final card (exactly what the operator chat got) to the
    // public signal channel — birth, rungs, stop, expiry, extension, afterlife.
    // relaySignalEvent's entry gate already restricts this to RELAYABLE_TYPES;
    // NOTE: rides on the operator chat being resolvable (resolved + persisted
    // for weeks) — unresolved-chat pending state skips the mirror too, by
    // design (one health gate).
    if (signalChannelEnv()) {
        try {
            await mirrorCardToChannel(card);
        } catch (e) {
            channelOk = false;
            chFailCount++;
            pushErr(`channel: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    return {
        operatorOk,
        channelOk,
        chatPending: false
    };
}
function relaySignalEvent(type, symbol, message, signalId) {
    // v10.20 PUMP/DUMP BAN (operator mandate) — swallow banned types at the
    // choke point, count honestly, never touch Telegram with them.
    if (BANNED_RELAY_TYPES.has(type)) {
        pumpDumpBlocked++;
        return;
    }
    if (!relayArmed() || !RELAYABLE_TYPES.has(type)) return;
    scheduleReplaySweep(); // v12.9: lazily arm the outbox sweeper on first engine use
    void deliverSignalEvent(type, symbol, message, signalId ?? null).then(async (res)=>{
        if (!res.operatorOk) return; // failed live send → cursor stays → the sweeper retries in order
        try {
            // Advance past the OLDEST matching journal row still after the cursor:
            // identical re-fires create several rows, and the cursor must walk them
            // one by one — never jump over an undelivered sibling.
            const cur = await readRelaySettingJson(RELAY_CURSOR_KEY);
            const newer = cur ? {
                OR: [
                    {
                        createdAt: {
                            gt: new Date(cur.at)
                        }
                    },
                    ...cur.id ? [
                        {
                            createdAt: new Date(cur.at),
                            id: {
                                gt: cur.id
                            }
                        }
                    ] : []
                ]
            } : {};
            const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.findFirst({
                where: {
                    type,
                    signalId: signalId ?? null,
                    ...symbol ? {
                        symbol
                    } : {
                        symbol: null
                    },
                    message,
                    ...newer
                },
                orderBy: {
                    createdAt: "asc"
                },
                select: {
                    id: true,
                    createdAt: true
                }
            });
            if (row) await advanceRelayCursor({
                at: Number(row.createdAt),
                id: row.id,
                by: "live"
            });
        } catch  {
        /* cursor is best-effort on the live path; the sweeper is the backstop */ }
    }).catch(()=>undefined);
}
async function primeRelayState() {
    await resolveChat();
    scheduleReplaySweep(); // v12.9: route-copy priming also arms the outbox sweeper (lease prevents multi-copy double-sweep)
}
async function sendDirect(text) {
    const chat = await resolveChat();
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    if (!chat) {
        if (botId !== null && (chatOverride ?? ENV_CHAT) === String(botId)) {
            return {
                ok: false,
                error: `TELEGRAM_CHAT_ID (${ENV_CHAT}) is the bot's own id — Telegram rejects bot→bot sends. Message the bot once from your account, then run discover.`
            };
        }
        return {
            ok: false,
            error: chatOverride || ENV_CHAT ? "chat unresolved (getMe pending or override pending)" : "TELEGRAM_CHAT_ID unset and no discovered chat yet"
        };
    }
    const r = await apiCall("sendMessage", {
        chat_id: chat,
        text,
        disable_web_page_preview: true
    });
    if (r.ok) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`direct: ${r.error}`);
    }
    return {
        ok: r.ok,
        error: r.error,
        chatId: chat
    };
}
// ── v6.4 DAILY PERFORMANCE REPORT (operator request 2026-09-07) ──────────
// «هر روز ساعت 00:00 یک گزارش کوتاه و مفید از عملکرد روزانه به تلگرام
//  بفرست با این تصویر» — the DAILY.jpg artwork ships as the photo, the
// compiled 24h performance digest rides as the HTML caption. Numbers come
// from the REAL db rows (lib/dailyReport.ts); DAILY.jpg was uploaded by the
// operator and lives in assets/telegram/.
const DAILY_ART = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), "assets", "telegram", "DAILY.jpg");
let dailyArtCache;
async function loadDailyArt() {
    if (dailyArtCache !== undefined) return dailyArtCache;
    try {
        dailyArtCache = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(DAILY_ART);
    } catch  {
        dailyArtCache = null;
    }
    return dailyArtCache;
}
async function sendDailyReport(text, poster, filename = "DAILY.jpg") {
    const chat = await resolveChat();
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant",
        withPhoto: false
    };
    if (!chat) return {
        ok: false,
        error: "chat unresolved — message the bot once, then retry",
        withPhoto: false
    };
    let art = poster ?? null;
    if (!art && filename === "DAILY.jpg") art = await loadDailyArt();
    const r = art ? await apiSendPhoto(chat, text, art, filename) : await apiCall("sendMessage", {
        chat_id: chat,
        text: text.slice(0, 3800),
        parse_mode: "HTML",
        disable_web_page_preview: true
    });
    if (r.ok) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`daily: ${r.error}`);
    }
    return {
        ok: r.ok,
        error: r.error,
        withPhoto: Boolean(art)
    };
}
async function sendPhotoDirect(caption, photo, filename = "preview.jpg") {
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    const chat = await resolveChat();
    if (!chat) return {
        ok: false,
        error: "chat unresolved — message the bot once, then retry"
    };
    const r = await apiSendPhoto(chat, caption, photo, filename);
    if (r.ok) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`photo-direct: ${r.error}`);
    }
    return r;
}
async function sendAnimationDirect(caption, mp4, filename = "anim.mp4") {
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    const chat = await resolveChat();
    if (!chat) return {
        ok: false,
        error: "chat unresolved — message the bot once, then retry"
    };
    const r = await apiSendAnimation(chat, caption, mp4, filename);
    if (r.ok) {
        sentCount++;
        lastSentAt = Date.now();
    } else {
        failCount++;
        pushErr(`anim-direct: ${r.error}`);
    }
    return r;
}
async function sendSampleCards() {
    const chat = await resolveChat();
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    if (!chat) return {
        ok: false,
        error: "chat unresolved — message the bot once, then retry"
    };
    const mk = (over)=>({
            id: "sample",
            createdAt: new Date(),
            updatedAt: new Date(),
            closedAt: new Date(),
            symbol: "BTCUSDT",
            direction: "LONG",
            entryPrice: 65000,
            entryZoneLow: 64948,
            entryZoneHigh: 65052,
            tp1: 66000,
            tp2: 67500,
            tp3: 69000,
            stopLoss: 64000,
            leverage: 10,
            marginUsd: 12,
            confidence: 78,
            riskReward: 2.8,
            timeframe: "1h",
            strategy: "AI-SWING",
            status: "TP2",
            analysis: "",
            tags: "high-conviction,FLOW-CONFIRM,REGIME-TREND-UP",
            engine: "SAMPLE",
            serial: 0,
            factorsJson: null,
            flowJson: null,
            ttlMinutes: 120,
            expiresAt: new Date(Date.now() + 3600_000),
            pnlPercent: 27.3,
            maxPnlPercent: 31.4,
            feeUsd: 0.11,
            swapUsd: 0.01,
            reachedTp: 2,
            ttlExtensions: 0,
            afterlife: null,
            afterlifeAt: null,
            maxPostPnlPercent: 0,
            operatorNotes: "",
            notesUpdatedAt: null,
            ...over
        });
    const samples = [
        [
            "CREATED",
            mk({
                serial: 1
            }),
            "SAMPLE — new LONG deployment detected by the live engine (card-format proof, not a live signal)"
        ],
        [
            "CREATED",
            mk({
                serial: 2,
                direction: "SHORT",
                symbol: "ETHUSDT",
                strategy: "BREAKOUT",
                timeframe: "15m",
                entryPrice: 3120,
                entryZoneLow: 3118,
                entryZoneHigh: 3122,
                tp1: 3060,
                tp2: 2990,
                tp3: 2900,
                stopLoss: 3180,
                leverage: 8,
                marginUsd: 9.5,
                confidence: 71,
                riskReward: 2.6,
                tags: "confluence,FLOW-NEUTRAL,REGIME-CHOP"
            }),
            "SAMPLE — new SHORT deployment detected by the live engine (card-format proof, not a live signal)"
        ],
        [
            "TP2",
            mk({
                serial: 3,
                pnlPercent: 27.3,
                maxPnlPercent: 31.4,
                feeUsd: 0.11,
                swapUsd: 0.01,
                reachedTp: 2
            }),
            "SAMPLE — TP2 reached — 80% booked, stop trailed to TP1 (card-format proof, not a live signal)"
        ],
        [
            "TP3",
            mk({
                serial: 4,
                symbol: "SOLUSDT",
                strategy: "AI-SWING",
                entryPrice: 184.2,
                entryZoneLow: 183.9,
                entryZoneHigh: 184.5,
                tp1: 191.2,
                tp2: 201.0,
                tp3: 214.0,
                stopLoss: 177.2,
                leverage: 6,
                marginUsd: 8.25,
                confidence: 68,
                riskReward: 3.1,
                pnlPercent: 48.9,
                maxPnlPercent: 52.1,
                reachedTp: 3,
                status: "TP3",
                closedAt: new Date()
            }),
            "SAMPLE — FULL TARGET achieved — ladder 3/3 banked (card-format proof, not a live signal)"
        ],
        [
            "SL",
            mk({
                serial: 5,
                direction: "SHORT",
                symbol: "ETHUSDT",
                strategy: "BREAKOUT",
                timeframe: "15m",
                entryPrice: 3120,
                entryZoneLow: 3118,
                entryZoneHigh: 3122,
                tp1: 3060,
                tp2: 2990,
                tp3: 2900,
                stopLoss: 3180,
                leverage: 8,
                marginUsd: 9.5,
                confidence: 71,
                riskReward: 2.6,
                pnlPercent: -29.8,
                reachedTp: 0,
                status: "SL",
                closedAt: new Date(),
                tags: "confluence,FLOW-NEUTRAL,REGIME-CHOP"
            }),
            "SAMPLE — stopped @ 3180 — risk contained (card-format proof, not a live signal)"
        ],
        [
            "TTL_EXTENDED",
            mk({
                serial: 6,
                symbol: "SOLUSDT",
                strategy: "AI-SWING",
                entryPrice: 184.2,
                entryZoneLow: 183.9,
                entryZoneHigh: 184.5,
                tp1: 191.2,
                tp2: 201.0,
                tp3: 214.0,
                stopLoss: 177.2,
                leverage: 6,
                marginUsd: 8.25,
                confidence: 68,
                riskReward: 3.1,
                ttlMinutes: 90,
                ttlExtensions: 1,
                tags: "confluence,FLOW-CONFIRM,REGIME-TREND-UP"
            }),
            "SAMPLE — TTL 90m extended +1 — expiry gate bought more room (card-format proof, not a live signal)"
        ],
        [
            "TTL_EXPIRED",
            mk({
                serial: 7,
                symbol: "SOLUSDT",
                strategy: "AI-SWING",
                entryPrice: 184.2,
                entryZoneLow: 183.9,
                entryZoneHigh: 184.5,
                tp1: 191.2,
                tp2: 201.0,
                tp3: 214.0,
                stopLoss: 177.2,
                leverage: 6,
                marginUsd: 8.25,
                confidence: 68,
                riskReward: 3.1,
                pnlPercent: 11.2,
                reachedTp: 1,
                ttlMinutes: 90,
                ttlExtensions: 1,
                status: "EXPIRED",
                closedAt: new Date(),
                tags: "confluence,FLOW-CONFIRM,REGIME-TREND-UP"
            }),
            "SAMPLE — TTL 90m +1 ext elapsed — auto-closed at mark (card-format proof, not a live signal)"
        ]
    ];
    const results = [];
    for (const [type, sig, msg] of samples){
        try {
            const text = `🧪 <b>SAMPLE — CARD FORMAT PROOF</b>\n\n${composeSignalText(type, sig, msg)}`;
            const banner = BANNER_STATUS[type];
            let r = null;
            const serial = `NX-${String(sig.serial).padStart(4, "0")}`;
            const pnl = sig.pnlPercent ?? 0;
            const photo = banner ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$telegram$2d$art$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["renderSignalBannerV2"])({
                status: banner,
                title: `${sig.symbol} ${sig.direction}`,
                line1: `${serial} · ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}% NET`,
                line2: banner === "NEW" || banner === "SHORT" ? `ENTRY ${fmtPrice(sig.entryPrice)} · RR 1:${sig.riskReward.toFixed(1)}` : `LADDER ${sig.reachedTp}/3 · RR 1:${sig.riskReward.toFixed(1)}`,
                ts: tehranStamp(),
                // v10.20: the sample proofs exercise the price-ladder strip too
                ladder: {
                    direction: sig.direction === "SHORT" ? "SHORT" : "LONG",
                    entry: sig.entryPrice,
                    tp1: sig.tp1,
                    tp2: sig.tp2,
                    tp3: sig.tp3,
                    sl: sig.stopLoss,
                    reachedTp: sig.reachedTp ?? 0
                }
            }).catch(()=>null) : null;
            if (photo) r = await apiSendPhoto(chat, text, photo, `sample-${type.toLowerCase()}.png`);
            else {
                const art = banner ? await loadOperatorArt(banner) : null;
                if (art) r = await apiSendPhoto(chat, text, art, ART_FILES[banner]);
                else r = await apiCall("sendMessage", {
                    chat_id: chat,
                    text: text.slice(0, 3800),
                    parse_mode: "HTML",
                    disable_web_page_preview: true
                });
            }
            if (!r.ok) r = await apiCall("sendMessage", {
                chat_id: chat,
                text: text.slice(0, 3800),
                parse_mode: "HTML",
                disable_web_page_preview: true
            });
            results.push(`${type}: ${r.ok ? "OK" : r.error}`);
        } catch (e) {
            results.push(`${type}: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    const okAll = results.every((r)=>r.endsWith("OK"));
    if (okAll) {
        sentCount += samples.length;
        lastSentAt = Date.now();
    } else failCount += results.filter((r)=>!r.endsWith("OK")).length;
    return {
        ok: okAll,
        detail: results.join(" · ")
    };
}
async function sendChannelTest() {
    const chan = signalChannelEnv();
    if (!chan) return {
        ok: false,
        configured: false,
        error: "TELEGRAM_SIGNAL_CHANNEL unset — mirror dormant (self-heal re-scans .env every 30s)"
    };
    const r = await apiCall("sendMessage", {
        chat_id: chan,
        text: `🧪 <b>${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["APP_NAME"]} — SIGNAL-CHANNEL TEST</b>\n${new Date().toISOString()} — mirror plane armed; full lifecycle cards (CREATED/TP1-3/SL/TTL/AFTERLIFE) mirror here.`,
        parse_mode: "HTML",
        disable_web_page_preview: true
    });
    if (r?.ok) {
        chSentCount++;
        chLastSentAt = Date.now();
    } else {
        chFailCount++;
        pushErr(`channeltest: ${r?.error ?? "?"}`);
    }
    return {
        ok: !!r?.ok,
        configured: true,
        error: r && !r.ok ? String(r.error) : undefined
    };
}
// ── v6.2.2 AUTO-DISCOVER (operator round) ─────────────────────────────────
// The operator's credential set shipped TELEGRAM_CHAT_ID === the bot's own id
// (Telegram hard-rejects bot→bot sends), leaving the relay stuck in ARMED
// (chat PENDING) until someone runs discoverChat() at exactly the right
// moment. Instead of babysitting, this loop polls getUpdates every 30s WHILE
// the chat is unresolved; the instant the operator messages the bot once,
// the chat id is learned, persisted, confirmed back, and the loop retires.
let autoDiscoverTimer = null;
function chatResolvedNow() {
    const chat = chatOverride ?? ENV_CHAT;
    return chat.length > 0 && botId !== null && chat !== String(botId);
}
function ensureAutoDiscover() {
    if (autoDiscoverTimer || !relayArmed()) return;
    // v8.3 BRIDGE COEXISTENCE: the chat id is already persisted (EngineSetting
    // telegram.chatId) since v6.2.2 — discovery is DONE. The legacy 30s
    // getUpdates probe now 409-terminates the v8.3 bridge long-poller, so the
    // loop may only start after a DB-backed override check FAILS, and each
    // tick re-checks the override BEFORE touching getUpdates.
    void (async ()=>{
        try {
            await ensureBotIdentity();
            await loadOverride();
        } catch  {
        /* identity check is best-effort */ }
        if (chatResolvedNow()) {
            // v10.16: rate-limit this line to once per 10min — it fired on every call
            // and produced ~3.5k dev.log lines/day (audit: unbounded log growth).
            const now = Date.now();
            if (now - lastAutoDiscoverSkipLog > 600_000) {
                lastAutoDiscoverSkipLog = now;
                console.log("[NOTIFY] auto-discover SKIPPED — chat already resolved (v8.3 bridge owns getUpdates)");
            }
            return;
        }
        const timer = setInterval(()=>{
            if (chatResolvedNow()) {
                clearInterval(timer);
                autoDiscoverTimer = null;
                return;
            }
            void (async ()=>{
                try {
                    await ensureBotIdentity();
                    await loadOverride();
                } catch  {
                /* best-effort */ }
                if (chatResolvedNow()) {
                    clearInterval(timer);
                    autoDiscoverTimer = null;
                    return;
                }
                const r = await discoverChat();
                if (r && r.ok) {
                    clearInterval(timer);
                    autoDiscoverTimer = null;
                    const proof = await sendDirect(`🟢 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["APP_NAME"]} relay ARMED — operator chat discovered and persisted.\nFrom now on CREATED / TP1-3 / SL / TTL_EXPIRED / TTL_EXTENDED / AFTERLIFE events mirror here as structured cards (WIN / STOP / EXPIRED outcomes also arrive as rendered banner images).`);
                    console.log(`[NOTIFY] auto-discover complete — confirmation ${proof.ok ? "delivered" : `NOT delivered (${proof.error ?? "unknown"})`}`);
                }
            // ok:false → "no messages waiting" (benign, keep polling) or a
            // transient network error (silent retry on the next 30s pass).
            })();
        }, 30_000);
        autoDiscoverTimer = timer;
        console.log("[NOTIFY] auto-discover loop started — polling getUpdates every 30s until the operator messages the bot");
    })();
}
async function discoverChat() {
    if (!TOKEN) return {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN unset — relay dormant"
    };
    await ensureBotIdentity();
    const r = await apiCall("getUpdates", {
        limit: 10,
        timeout: 0
    }, 8000);
    if (!r.ok || !r.result) return {
        ok: false,
        error: r.error ?? "getUpdates returned no payload"
    };
    const withMsg = r.result.filter((u)=>u.message?.chat?.id !== undefined);
    if (withMsg.length === 0) return {
        ok: false,
        error: "no messages waiting — open the bot in Telegram, press START and send any message (e.g. «سلام»), then retry discover"
    };
    const last = withMsg[withMsg.length - 1].message;
    const chatId = String(last.chat.id);
    chatOverride = chatId;
    overrideLoaded = true;
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: CHAT_OVERRIDE_KEY
        },
        create: {
            key: CHAT_OVERRIDE_KEY,
            value: chatId
        },
        update: {
            value: chatId
        }
    });
    console.log(`[NOTIFY] telegram chat DISCOVERED — id ${chatId} (${last.chat.first_name ?? last.chat.username ?? "unknown"}), persisted to ${CHAT_OVERRIDE_KEY}; relay fully ARMED`);
    return {
        ok: true,
        chatId,
        from: last.chat.first_name ?? last.chat.username,
        text: last.text
    };
}
}),
"[project]/src/lib/volOnset.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ONSET_RULES",
    ()=>ONSET_RULES,
    "coreToTag",
    ()=>coreToTag,
    "detectOnset",
    ()=>detectOnset,
    "getOnsetBoard",
    ()=>getOnsetBoard,
    "isHot",
    ()=>isHot,
    "latestOnsetCore",
    ()=>latestOnsetCore,
    "onsetGateViewFor",
    ()=>onsetGateViewFor,
    "onsetScoreOf",
    ()=>onsetScoreOf,
    "onsetTagFor",
    ()=>onsetTagFor,
    "onsetTagStats",
    ()=>onsetTagStats,
    "resampleTicks",
    ()=>resampleTicks
]);
// ── VOL-ONSET · eruption-bar onset detector (v1 rebuilt 2026-09-07) ──
// Research finding (2026-09-06 session): the |Δ24h| Top-movers board is a
// LAGGING view — by the time a symbol tops the board the move is 6–16h old.
// The LEADING pattern is the "eruption bar": a single 15m candle whose
// |return| ≥ 5× the trailing-24h median |return|. Measured lead: 6–16h
// before board entry; fwd-6h same-direction drift +10.7% avg on 3/3 samples.
//
// CONTRACT (calibration audit 2026-09-06): VOL-ONSET is TELEMETRY ONLY.
// It tags signals + votes 0 in the factor ledger. It NEVER changes score,
// thresholds, sizing or any live gate until the learning loop proves an
// edge on settled outcomes (onsetTagStats).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
;
;
const ONSET_RULES = {
    tfMinutes: 15,
    eruptionMult: 5,
    trailingBars: 96,
    hotMinutes: 90,
    minBars: 110,
    halfLifeMin: 180,
    tickWindowHours: 50
};
function resampleTicks(points, tfMs = ONSET_RULES.tfMinutes * 60_000) {
    const out = [];
    let bucket = -1;
    let cur = null;
    for (const pt of points){
        const b = Math.floor(pt.t / tfMs);
        if (b !== bucket) {
            if (cur) out.push(cur);
            bucket = b;
            cur = {
                openTime: b * tfMs,
                open: pt.p,
                high: pt.p,
                low: pt.p,
                close: pt.p,
                volume: 0
            };
        } else if (cur) {
            cur.high = Math.max(cur.high, pt.p);
            cur.low = Math.min(cur.low, pt.p);
            cur.close = pt.p;
        }
    }
    if (cur) out.push(cur);
    return out;
}
// ── helpers ─────────────────────────────────────────────────────
function median(xs) {
    if (xs.length === 0) return 0;
    const s = [
        ...xs
    ].sort((a, b)=>a - b);
    const mid = s.length >> 1;
    return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}
function percentileRank(xs, v) {
    if (xs.length === 0) return 0.5;
    let below = 0;
    for (const x of xs)if (x <= v) below++;
    return below / xs.length;
}
const clamp01 = (x)=>Math.min(1, Math.max(0, x));
function detectOnset(bars, nowMs = Date.now()) {
    if (!bars || bars.length < ONSET_RULES.minBars) return null;
    const TRAIL = ONSET_RULES.trailingBars;
    const window = bars.slice(-TRAIL);
    const baseline = bars.slice(0, Math.max(0, bars.length - TRAIL));
    if (window.length < TRAIL) return null;
    // median |return| across the trailing window (robust to the eruption itself)
    const absRets = window.map((b, i)=>i === 0 ? 0 : Math.abs((b.close - window[i - 1].close) / window[i - 1].close) * 100);
    const med = median(absRets.slice(1));
    if (!(med > 0)) return null;
    // first eruption bar in the window
    let idx = -1;
    for(let i = 1; i < window.length; i++){
        const prev = window[i - 1];
        const b = window[i];
        const ret = (b.close - prev.close) / prev.close * 100;
        if (Math.abs(ret) >= ONSET_RULES.eruptionMult * med) {
            idx = i;
            break;
        }
    }
    if (idx < 0) return null;
    const erupt = window[idx];
    const prevClose = window[idx - 1].close;
    const eruptRetPct = (erupt.close - prevClose) / prevClose * 100;
    const direction = eruptRetPct >= 0 ? 1 : -1;
    const displacementX = Math.abs(eruptRetPct) / med;
    const minutesSince = Math.max(0, Math.round((nowMs - erupt.openTime) / 60_000));
    // pre-eruption warmth: mean range% of the 8 bars before the eruption,
    // ranked against the baseline distribution ("eruptions start warm,
    // not from dead squeezes" — 2026-09-06 finding: 28–85th pct)
    const preBars = bars.slice(Math.max(0, bars.indexOf(erupt) - 8), bars.indexOf(erupt));
    const preRanges = preBars.map((b)=>(b.high - b.low) / b.close * 100);
    const baseRanges = baseline.map((b)=>(b.high - b.low) / b.close * 100);
    const preRangePct = preRanges.length ? percentileRank(baseRanges, median(preRanges)) : 0.5;
    // pre-eruption slope (%/bar over the same 8 bars)
    let preSlope = 0;
    if (preBars.length >= 2) {
        const first = preBars[0];
        const last = preBars[preBars.length - 1];
        preSlope = (last.close - first.close) / first.close * 100 / (preBars.length - 1);
    }
    // follow-through: drift since the eruption bar close, in eruption direction
    const last = window[window.length - 1];
    const rawFt = (last.close - erupt.close) / erupt.close * 100;
    const followThroughPct = rawFt * direction;
    return {
        eruptionAt: erupt.openTime,
        minutesSince,
        direction,
        eruptRetPct,
        displacementX,
        preRangePct,
        preSlope,
        followThroughPct
    };
}
function onsetScoreOf(core) {
    const displacement = 40 * clamp01((core.displacementX - 1) / 9);
    const recency = 30 * Math.pow(0.5, core.minutesSince / ONSET_RULES.halfLifeMin);
    const ftRatio = clamp01(core.followThroughPct / Math.max(Math.abs(core.eruptRetPct), 0.3));
    let followThrough = 20 * ftRatio;
    if (core.followThroughPct < 0) followThrough = 20 * 0.35 * clamp01(Math.abs(core.followThroughPct) / Math.max(Math.abs(core.eruptRetPct), 0.3));
    const inWarmBelt = core.preRangePct >= 0.28 && core.preRangePct <= 0.85;
    const warming = 10 * (inWarmBelt ? 1 : 0.45);
    return Math.round(Math.min(100, Math.max(0, displacement + recency + followThrough + warming)));
}
function isHot(core) {
    return core.minutesSince <= ONSET_RULES.hotMinutes && core.displacementX >= ONSET_RULES.eruptionMult && (core.followThroughPct >= 0 || Math.abs(core.followThroughPct) < 0.5);
}
function coreToTag(core) {
    const score = onsetScoreOf(core);
    const dir = core.direction === 1 ? "UP" : "DOWN";
    const age = core.minutesSince >= 60 ? `${(core.minutesSince / 60).toFixed(1)}h` : `${core.minutesSince}m`;
    const ft = `${core.followThroughPct >= 0 ? "+" : ""}${core.followThroughPct.toFixed(1)}%`;
    // direction-aware tag (2026-09-07 forward study, n=469): UP-eruptions mean fwd6h +0.88%
    // while DOWN-eruptions mean -1.55% — the calibrator must learn them SEPARATELY.
    const tag = `VOL-ONSET${core.direction === 1 ? "↑" : "↓"}`;
    return {
        hot: isHot(core),
        tag,
        score,
        minutesSince: core.minutesSince,
        direction: dir,
        detail: `15m eruption ×${core.displacementX.toFixed(1)} ${dir.toLowerCase()} ${age} ago · follow-through ${ft} · onset ${score}/100`
    };
}
// ── data sourcing ───────────────────────────────────────────────
async function candlesFromTicks(symbol, windowHours = ONSET_RULES.tickWindowHours) {
    try {
        const since = new Date(Date.now() - windowHours * 3600_000);
        const pts = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].pricePoint.findMany({
            where: {
                symbol,
                createdAt: {
                    gte: since
                }
            },
            orderBy: {
                createdAt: "asc"
            },
            select: {
                price: true,
                createdAt: true
            }
        });
        if (pts.length < ONSET_RULES.minBars * 2) return null; // need density for 15m buckets
        return resampleTicks(pts.map((p)=>({
                t: p.createdAt.getTime(),
                p: p.price
            })));
    } catch  {
        return null;
    }
}
async function onsetTagFor(symbol, candles) {
    try {
        let bars = null;
        let source = "kline";
        if (candles && candles.length >= ONSET_RULES.minBars) {
            bars = candles;
        } else {
            try {
                bars = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(symbol, "15m", 220);
            } catch  {
                bars = null;
            }
        }
        if (!bars || bars.length < ONSET_RULES.minBars) {
            bars = await candlesFromTicks(symbol);
            source = "ticks";
        }
        if (!bars) return null;
        const core = detectOnset(bars);
        if (!core) return null;
        const tag = coreToTag(core);
        void source; // per-symbol source only tracked in board rows
        return tag;
    } catch  {
        return null; // contract: telemetry must never break the deploy path
    }
}
function latestOnsetCore(bars, nowMs = Date.now()) {
    try {
        if (!bars || bars.length < ONSET_RULES.minBars) return null;
        const TRAIL = ONSET_RULES.trailingBars;
        const window = bars.slice(-TRAIL);
        if (window.length < TRAIL) return null;
        const absRets = window.map((b, i)=>i === 0 ? 0 : Math.abs((b.close - window[i - 1].close) / window[i - 1].close) * 100);
        const med = median(absRets.slice(1));
        if (!(med > 0)) return null;
        const tfMs = ONSET_RULES.tfMinutes * 60_000;
        const hotCutoff = nowMs - (ONSET_RULES.hotMinutes + ONSET_RULES.tfMinutes) * 60_000;
        for(let i = window.length - 1; i >= 1; i--){
            const b = window[i];
            if (b.openTime < hotCutoff) return null; // walked past the hot window — nothing fresh
            const ret = (b.close - window[i - 1].close) / window[i - 1].close * 100;
            if (Math.abs(ret) < ONSET_RULES.eruptionMult * med) continue;
            // most recent eruption bar (may be the FORMING bar — intra-bar legs are the storm class)
            const eruptRetPct = ret;
            const direction = eruptRetPct >= 0 ? 1 : -1;
            const minutesSince = Math.max(0, Math.round((nowMs - b.openTime) / 60_000));
            const last = window[window.length - 1];
            const rawFt = (last.close - b.close) / b.close * 100;
            const followThroughPct = rawFt * direction;
            const baseline = bars.slice(0, Math.max(0, bars.length - TRAIL));
            const idx = bars.indexOf(b);
            const preBars = bars.slice(Math.max(0, idx - 8), idx);
            const preRanges = preBars.map((c)=>(c.high - c.low) / c.close * 100);
            const baseRanges = baseline.map((c)=>(c.high - c.low) / c.close * 100);
            const preRangePct = preRanges.length && baseRanges.length ? percentileRank(baseRanges, median(preRanges)) : 0.5;
            let preSlope = 0;
            if (preBars.length >= 2) {
                const first = preBars[0];
                const lastPre = preBars[preBars.length - 1];
                preSlope = (lastPre.close - first.close) / first.close * 100 / (preBars.length - 1);
            }
            return {
                eruptionAt: b.openTime,
                minutesSince,
                direction,
                eruptRetPct,
                displacementX: Math.abs(eruptRetPct) / med,
                preRangePct,
                preSlope,
                followThroughPct
            };
        }
        return null;
    } catch  {
        return null;
    }
}
async function onsetGateViewFor(symbol, candles) {
    try {
        let bars = null;
        if (candles && candles.length >= ONSET_RULES.minBars) {
            bars = candles;
        } else {
            try {
                bars = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(symbol, "15m", 220);
            } catch  {
                bars = null;
            }
        }
        if (!bars || bars.length < ONSET_RULES.minBars) {
            bars = await candlesFromTicks(symbol);
        }
        if (!bars) return null;
        const core = latestOnsetCore(bars);
        if (!core) return null;
        return {
            tag: coreToTag(core),
            core,
            bars
        };
    } catch  {
        return null;
    }
}
let boardCache = null;
let boardBuilding = null;
const BOARD_TTL = 90_000;
// resilience (egress-outage lesson 2026-09-07): never let the route hang on a
// rebuild — answer with the last-good board after this deadline; the rebuild
// keeps running in the background and the next poll picks up fresh rows.
const BOARD_DEADLINE = 12_000;
const BOARD_MAX_SYMBOLS = 48;
const KLINE_CONCURRENCY = 5;
async function detectForSymbol(symbol) {
    let bars = null;
    let source = "kline";
    try {
        bars = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(symbol, "15m", 220);
    } catch  {
        bars = null;
    }
    if (!bars || bars.length < ONSET_RULES.minBars) {
        bars = await candlesFromTicks(symbol);
        source = "ticks";
    }
    if (!bars) return null;
    const core = detectOnset(bars);
    if (!core) return null;
    return {
        symbol,
        score: onsetScoreOf(core),
        hot: isHot(core),
        minutesSince: core.minutesSince,
        direction: core.direction === 1 ? "UP" : "DOWN",
        displacementX: core.displacementX,
        eruptRetPct: core.eruptRetPct,
        followThroughPct: core.followThroughPct,
        source
    };
}
async function rebuildBoard() {
    try {
        const assets = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
            orderBy: {
                volume24h: "desc"
            },
            take: BOARD_MAX_SYMBOLS,
            select: {
                symbol: true
            }
        });
        const rows = [];
        for(let i = 0; i < assets.length; i += KLINE_CONCURRENCY){
            const batch = assets.slice(i, i + KLINE_CONCURRENCY).map((a)=>a.symbol);
            const results = await Promise.all(batch.map((s)=>detectForSymbol(s).catch(()=>null)));
            for (const r of results)if (r) rows.push(r);
        }
        rows.sort((a, b)=>b.score - a.score);
        // only overwrite the cache with a real result — an egress outage must not
        // replace the last-good board with an empty one
        if (rows.length > 0 || !boardCache) boardCache = {
            at: Date.now(),
            rows
        };
    } catch  {
    /* keep last-good boardCache — never throw */ }
}
async function getOnsetBoard() {
    if (boardCache && Date.now() - boardCache.at < BOARD_TTL) {
        return {
            rows: boardCache.rows,
            computedAt: boardCache.at,
            fromCache: true
        };
    }
    // single-flight rebuild + deadline: the caller NEVER waits longer than
    // BOARD_DEADLINE — stale rows beat a hung upstream (2026-09-07 egress outage)
    if (!boardBuilding) boardBuilding = rebuildBoard().finally(()=>{
        boardBuilding = null;
    });
    const raced = await Promise.race([
        boardBuilding.then(()=>"fresh"),
        new Promise((res)=>setTimeout(()=>res("deadline"), BOARD_DEADLINE))
    ]);
    if (raced === "fresh" && boardCache) {
        return {
            rows: boardCache.rows,
            computedAt: boardCache.at,
            fromCache: false
        };
    }
    return {
        rows: boardCache?.rows ?? [],
        computedAt: boardCache?.at ?? Date.now(),
        fromCache: true
    };
}
// ── learning loop: tagged vs rest on SETTLED signals ────────────
// SETTLED = TP1 | TP2 | TP3 | SL | EXPIRED | CLOSED (outcomes known)
const SETTLED_STATUSES = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
function groupStats(signals) {
    const n = signals.length;
    const wins = signals.filter((s)=>s.pnlPercent > 0).length;
    const totalNetUsd = signals.reduce((a, s)=>a + s.marginUsd * s.pnlPercent / 100, 0);
    return {
        n,
        wins,
        winRatePct: n > 0 ? Number((wins / n * 100).toFixed(1)) : null,
        avgNetPct: n > 0 ? Number((signals.reduce((a, s)=>a + s.pnlPercent, 0) / n).toFixed(2)) : null,
        totalNetUsd: Number(totalNetUsd.toFixed(2))
    };
}
async function onsetTagStats() {
    try {
        const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                status: {
                    in: [
                        ...SETTLED_STATUSES
                    ]
                }
            },
            select: {
                tags: true,
                direction: true,
                pnlPercent: true,
                marginUsd: true
            }
        });
        const hasTag = (t)=>t.split(",").map((x)=>x.trim()).some((x)=>x.startsWith("VOL-ONSET"));
        const taggedSignals = settled.filter((s)=>hasTag(s.tags));
        const restSignals = settled.filter((s)=>!hasTag(s.tags));
        const aligned = taggedSignals.filter((s)=>s.direction === "LONG" && s.tags.includes("VOL-ONSET↑") || s.direction === "SHORT" && s.tags.includes("VOL-ONSET↓"));
        const counter = taggedSignals.filter((s)=>!aligned.includes(s));
        return {
            settledTotal: settled.length,
            tagged: groupStats(taggedSignals),
            taggedAligned: groupStats(aligned),
            taggedCounter: groupStats(counter),
            rest: groupStats(restSignals)
        };
    } catch  {
        return {
            settledTotal: 0,
            tagged: groupStats([]),
            taggedAligned: groupStats([]),
            taggedCounter: groupStats([]),
            rest: groupStats([])
        };
    }
}
}),
"[project]/src/lib/volCause.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LEARN_GATE",
    ()=>LEARN_GATE,
    "VOL_CAUSES",
    ()=>VOL_CAUSES,
    "captureTopVolCauses",
    ()=>captureTopVolCauses,
    "getVolCauseBoard",
    ()=>getVolCauseBoard,
    "learnVolCauses",
    ()=>learnVolCauses,
    "sessionOf",
    ()=>sessionOf,
    "settlePendingVolCauses",
    ()=>settlePendingVolCauses,
    "volCauseBoost",
    ()=>volCauseBoost
]);
// ── FlowRadar Neo VOL-CAUSE forensics (server-only) ────────────────────────
// Operator request 2026-09-07: «با تحقیق و جستجوی عمیق دلایل شکل گیری
// Top volatility در MARKET MATRIX رو یاد بگیر و در سیستم برای ردیابی و
// یادگیری و استفاده پیاده کن» — WHY do the top-|Δ24h| movers (the MARKET
// MATRIX "Top volatility" board) actually move?
//
// RESEARCH BASIS (web research round 2026-09-07, distilled):
//   1. WHALE-PUSH       — large players accumulate quietly (OI rises) then hit
//                         the tape aggressively (taker CVD aligned with the
//                         move); footprint = OI Δ↑ + CVD↑ same sign as move.
//   2. LIQUIDATION CASCADE — one forced closure pushes price enough to trigger
//                         the next; visible as a burst of liquidation notional
//                         on the side that is being flushed.
//   3. FUNDING-SQUEEZE  — extreme funding marks crowded leverage; the crowded
//                         side becomes cascade fuel when price moves against it.
//   4. OI-SURGE         — OI surges backing a move = NEW positions, not
//                         day-trading noise → continuation fuel (per OI research).
//   5. UNWIND           — OI dropping hard while price moves = deleveraging,
//                         trend fuel draining.
//   6. CROWD-FLUSH      — retail crowd positioned heavily one way gets flushed
//                         (contrarian crowd input, already measured per symbol).
//   7. VOL-ONSET        — our own measured 15m eruption bar (leading, in-system).
//   8. THIN-TAPE        — small open-interest book: modest flow produces
//                         outsized |Δ24h| (weekend/off-hours amplifies).
//   9. SESSION-THIN     — liquidity drains in off-session hours / weekends.
//
// PIPELINE: capture (top-|Δ24h| entries, 6h dedupe) → attribute (transparent
// rule weights) → settle (real fwd 2h/6h returns from futures klines) →
// learn (per-cause expectancy + continuation rate → EngineSetting
// "volcause.study") → use (engine reads volCauseBoost at deploy; learned
// continuation profiles nudge conviction/sizing ONLY after n ≥ 30 ·
// cont ≥ 55% · |mean fwd6h| ≥ 0.12% — otherwise telemetry-only, vote 0).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volOnset$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/volOnset.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
;
;
;
;
;
const VOL_CAUSES = [
    "WHALE-PUSH",
    "LIQ-CASCADE",
    "FUNDING-SQUEEZE",
    "OI-SURGE",
    "UNWIND",
    "CROWD-FLUSH",
    "VOL-ONSET",
    "THIN-TAPE",
    "SESSION-THIN",
    "MOMENTUM-CARRY",
    "MIXED"
];
function sessionOf(d) {
    const day = d.getUTCDay();
    if (day === 0 || day === 6) return "WEEKEND";
    const h = d.getUTCHours();
    if (h >= 13 && h < 21) return "US";
    if (h >= 7 && h < 13) return "EUROPE";
    return "ASIA";
}
// ── attribution: transparent rule weights (research-derived) ────────────────
function attributeCauses(f) {
    const up = f.change24h >= 0;
    const dirSign = up ? 1 : -1;
    const raw = [];
    // 1) WHALE-PUSH — OI rising while aggressive takers push the same way
    const oi = f.oiDelta1h;
    const cvd = f.cvdPct;
    if (oi !== null && cvd !== null && oi >= 1.5 && Math.abs(cvd) >= 2 && Math.sign(cvd) === dirSign) {
        const w = 26 + Math.min(18, oi * 4 + (Math.abs(cvd) - 2) * 2);
        raw.push({
            cause: "WHALE-PUSH",
            w,
            note: `OI +${oi.toFixed(1)}%/1h with taker CVD ${cvd >= 0 ? "+" : ""}${cvd.toFixed(1)}% flowing ${up ? "into" : "against"} the move — large-player accumulation footprint`
        });
    }
    // 2) OI-SURGE — fresh positions backing the move (continuation fuel)
    if (oi !== null && oi >= 3) {
        raw.push({
            cause: "OI-SURGE",
            w: 12 + Math.min(14, (oi - 3) * 2.5),
            note: `open interest surged +${oi.toFixed(1)}%/1h — new positions, not noise, backing the move`
        });
    }
    // 3) UNWIND — deleveraging: OI draining while price moves
    if (oi !== null && oi <= -2) {
        raw.push({
            cause: "UNWIND",
            w: 14 + Math.min(14, Math.abs(oi) * 2.5),
            note: `open interest unwinding ${oi.toFixed(1)}%/1h — forced de-risking driving the tape, fuel draining`
        });
    }
    // 4) LIQ-CASCADE — liquidation burst on the flushed side
    if (f.liqUsd1h !== null && f.liqUsd1h >= 200_000) {
        const flushed = f.liqDominant ?? (up ? "SHORTS" : "LONGS");
        const aligned = up && flushed === "SHORTS" || !up && flushed === "LONGS";
        raw.push({
            cause: "LIQ-CASCADE",
            w: (16 + Math.min(20, f.liqUsd1h / 50_000)) * (aligned ? 1 : 0.5),
            note: `$${Math.round(f.liqUsd1h / 1000)}k liquidated/10m window, ${flushed === "LONGS" ? "longs" : "shorts"} flushed — cascade mechanics in play`
        });
    }
    // 5) FUNDING-SQUEEZE — crowded leverage as cascade fuel
    if (f.funding8h !== null && Math.abs(f.funding8h) >= 0.0005) {
        const crowded = f.funding8h > 0 ? "LONGS" : "SHORTS";
        // the crowded side becomes fuel when the move runs AGAINST it
        const isFuel = !up && crowded === "LONGS" || up && crowded === "SHORTS";
        raw.push({
            cause: "FUNDING-SQUEEZE",
            w: (10 + Math.min(14, (Math.abs(f.funding8h) - 0.0005) * 12_000)) * (isFuel ? 1 : 0.6),
            note: `funding ${(f.funding8h * 100).toFixed(3)}%/8h — ${crowded === "LONGS" ? "longs" : "shorts"} pay to stay crowded; ${isFuel ? "they are the squeeze fuel here" : "crowd aligned with the move (momentum carry)"}`
        });
    }
    // 6) CROWD-FLUSH — retail crowd on the wrong side
    if (f.crowdLS !== null && (!up && f.crowdLS >= 2 || up && f.crowdLS <= 0.8)) {
        raw.push({
            cause: "CROWD-FLUSH",
            w: 12,
            note: `retail crowd ${f.crowdLS >= 1 ? "long-biased" : "short-biased"} (L/S ${f.crowdLS.toFixed(2)}) caught on the wrong side — flush fuel`
        });
    }
    // 7) VOL-ONSET — our measured eruption bar
    if (f.onsetScore !== null && f.onsetScore >= 30) {
        raw.push({
            cause: "VOL-ONSET",
            w: 10 + Math.min(16, f.onsetScore * 0.2),
            note: `15m eruption bar on the radar (onset score ${f.onsetScore}/100) — measured displacement onset`
        });
    }
    // 8) THIN-TAPE — small book amplifies flow
    if (f.oiValueUsd !== null && f.oiValueUsd < 30_000_000) {
        raw.push({
            cause: "THIN-TAPE",
            w: 10,
            note: `open interest only $${(f.oiValueUsd / 1e6).toFixed(1)}M — a thin book amplifies every order`
        });
    }
    // 9) SESSION-THIN — off-hours / weekend liquidity
    if (f.session === "WEEKEND" || f.hourUtc >= 21 || f.hourUtc < 5) {
        raw.push({
            cause: "SESSION-THIN",
            w: 6,
            note: f.session === "WEEKEND" ? "weekend liquidity drain amplifies moves" : `thin ${f.session === "ASIA" ? "pre-Asia" : "late-US"} hours (${String(f.hourUtc).padStart(2, "0")}:00 UTC)`
        });
    }
    // fallback
    if (raw.length === 0) {
        raw.push({
            cause: "MOMENTUM-CARRY",
            w: 20,
            note: "no single dominant footprint — directional drift carried by steady flow"
        });
    }
    const total = raw.reduce((a, r)=>a + r.w, 0);
    const causes = raw.sort((a, b)=>b.w - a.w).slice(0, 4).map((r)=>({
            cause: r.cause,
            weight: Math.round(r.w / total * 100),
            note: r.note
        }));
    const top = causes[0];
    return {
        causes,
        primary: top.weight >= 18 ? top.cause : "MIXED"
    };
}
// ── capture: top-|Δ24h| entries (the MARKET MATRIX board), 6h dedupe ───────
const CAPTURE_TOP_N = 4;
const CAPTURE_THROTTLE_MS = 180_000; // 3min
const DEDUPE_WINDOW_MS = 6 * 3600_000;
const MIN_ABS_RET = 3.5; // |Δ24h| must clear this to be "top volatility" material
let lastCaptureAt = 0;
let captureRunning = false;
async function captureTopVolCauses() {
    if (captureRunning || Date.now() - lastCaptureAt < CAPTURE_THROTTLE_MS) return 0;
    captureRunning = true;
    lastCaptureAt = Date.now();
    try {
        const assets = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
            orderBy: {
                volume24h: "desc"
            },
            take: 60,
            select: {
                symbol: true,
                price: true,
                change24h: true
            }
        });
        const ranked = assets.filter((a)=>Math.abs(a.change24h) >= MIN_ABS_RET).sort((a, b)=>Math.abs(b.change24h) - Math.abs(a.change24h)).slice(0, CAPTURE_TOP_N);
        if (ranked.length === 0) return 0;
        const since = new Date(Date.now() - DEDUPE_WINDOW_MS);
        const recent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findMany({
            where: {
                detectedAt: {
                    gte: since
                },
                symbol: {
                    in: ranked.map((r)=>r.symbol)
                }
            },
            select: {
                symbol: true,
                direction: true
            }
        });
        // v12.11 — DIRECTION-AWARE dedupe (IRYS forensics): the old per-symbol 6h
        // key meant a captured +565% pump BLACKED OUT the following −77.4% collapse
        // (zero DOWN events for 6h). Dedupe is now (symbol, direction) — an UP
        // regime and a DOWN regime are separate events; rank-0 tick-plane rows
        // (TICK-ONSET) participate equally so the slow plane doesn't duplicate them.
        const recentSet = new Set(recent.map((r)=>`${r.symbol}|${r.direction}`));
        const todo = ranked.filter((r)=>!recentSet.has(`${r.symbol}|${r.change24h >= 0 ? "UP" : "DOWN"}`));
        if (todo.length === 0) return 0;
        // onset radar is cached (90s) — read once
        const onset = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volOnset$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getOnsetBoard"])().catch(()=>null);
        const onsetMap = new Map((onset?.rows ?? []).map((r)=>[
                r.symbol,
                r.score
            ]));
        let created = 0;
        const now = new Date();
        for (const a of todo){
            const [flow, liq] = await Promise.all([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFlowMetrics"])(a.symbol).catch(()=>null),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["liquidationPressure"])(a.symbol).catch(()=>null)
            ]);
            const liqUsd1h = liq ? liq.usd10m * 6 : null; // scale the 10m window to an hour-equivalent (honest: measured 10m × 6)
            const liqDominant = liq ? liq.longsUsd10m >= liq.shortsUsd10m ? "LONGS" : "SHORTS" : null;
            const snap = {
                symbol: a.symbol,
                change24h: a.change24h,
                price: a.price,
                oiDelta10m: flow?.oiDelta10m ?? null,
                oiDelta1h: flow?.oiDelta1h ?? null,
                oiValueUsd: flow?.oiValueUsd ?? null,
                cvdPct: flow?.cvdNetPctOfVol ?? null,
                takerRatio: flow?.takerRatio ?? null,
                crowdLS: flow?.crowdLongShort ?? null,
                funding8h: flow?.funding8h ?? null,
                liqUsd1h,
                liqDominant,
                onsetScore: onsetMap.get(a.symbol) ?? null,
                hourUtc: now.getUTCHours(),
                session: sessionOf(now)
            };
            const { causes, primary } = attributeCauses(snap);
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.create({
                data: {
                    symbol: a.symbol,
                    detectedAt: now,
                    rank: ranked.indexOf(a) + 1,
                    direction: a.change24h >= 0 ? "UP" : "DOWN",
                    change24h: a.change24h,
                    price: a.price,
                    oiDelta10m: snap.oiDelta10m,
                    oiDelta1h: snap.oiDelta1h,
                    oiValueUsd: snap.oiValueUsd,
                    cvdPct: snap.cvdPct,
                    takerRatio: snap.takerRatio,
                    crowdLS: snap.crowdLS,
                    funding8h: snap.funding8h,
                    liqUsd1h: snap.liqUsd1h,
                    onsetScore: snap.onsetScore,
                    hourUtc: snap.hourUtc,
                    session: snap.session,
                    causesJson: JSON.stringify(causes),
                    primaryCause: primary
                }
            });
            created++;
        }
        return created;
    } catch  {
        return 0; // telemetry — never throws
    } finally{
        captureRunning = false;
    }
}
// ── settle: real forward returns from futures klines ────────────────────────
const SETTLE_LOOKBACK_CANDLES = 14; // 1h candles → covers 14h
function priceAt(candles, tMs) {
    const c = candles.find((k)=>k.openTime <= tMs && k.openTime + 3600_000 > tMs);
    return c ? c.close : null;
}
let lastSettleAt = 0;
let settleRunning = false;
async function settlePendingVolCauses() {
    if (settleRunning || Date.now() - lastSettleAt < 120_000) return 0;
    settleRunning = true;
    lastSettleAt = Date.now();
    try {
        const pending = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findMany({
            where: {
                settledAt: null,
                detectedAt: {
                    lt: new Date(Date.now() - 2 * 3600_000)
                }
            },
            orderBy: {
                detectedAt: "asc"
            },
            take: 12
        });
        let n = 0;
        for (const ev of pending){
            let candles = null;
            try {
                candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(ev.symbol, "1h", SETTLE_LOOKBACK_CANDLES);
            } catch  {
                continue; // keep pending — retry next round
            }
            if (!candles || candles.length === 0) continue;
            const t0 = ev.detectedAt.getTime();
            const p2 = priceAt(candles, t0 + 2 * 3600_000);
            const p6 = priceAt(candles, t0 + 6 * 3600_000);
            const ageOk = Date.now() - t0 >= 13 * 3600_000; // beyond kline window → settle with what we have
            if (p6 === null && !ageOk) continue;
            const base = ev.price;
            const data = {
                settledAt: new Date()
            };
            if (p2 !== null) data.fwd2hPct = Number(((p2 - base) / base * 100).toFixed(3));
            if (p6 !== null) data.fwd6hPct = Number(((p6 - base) / base * 100).toFixed(3));
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.update({
                where: {
                    id: ev.id
                },
                data
            });
            n++;
        }
        return n;
    } catch  {
        return 0;
    } finally{
        settleRunning = false;
    }
}
const STUDY_KEY = "volcause.study";
let studyCache = null;
const STUDY_CACHE_TTL = 300_000;
const LEARN_GATE = {
    minN: 30,
    minContPct: 55,
    minAbsFwd: 0.12
};
async function learnVolCauses(force = false) {
    if (!force && studyCache && Date.now() - studyCache.at < STUDY_CACHE_TTL) return studyCache.study;
    try {
        const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findMany({
            where: {
                fwd6hPct: {
                    not: null
                }
            },
            select: {
                causesJson: true,
                primaryCause: true,
                direction: true,
                fwd2hPct: true,
                fwd6hPct: true
            }
        });
        const byCause = new Map();
        const add = (cause, f2, f6, cont)=>{
            const e = byCause.get(cause) ?? {
                n: 0,
                s2: 0,
                s6: 0,
                cont: 0
            };
            e.n++;
            e.s2 += f2 ?? 0;
            e.s6 += f6;
            if (cont) e.cont++;
            byCause.set(cause, e);
        };
        for (const ev of settled){
            const f6 = ev.fwd6hPct ?? 0;
            const cont = ev.direction === "UP" ? f6 > 0 : f6 < 0;
            add(ev.primaryCause, ev.fwd2hPct, f6, cont);
            // also credit attributed causes with meaningful weight
            try {
                const causes = JSON.parse(ev.causesJson);
                for (const c of causes){
                    if (c.cause !== ev.primaryCause && c.weight >= 15) add(c.cause, ev.fwd2hPct, f6, cont);
                }
            } catch  {
            /* single bad row must not kill the study */ }
        }
        const causes = [
            ...byCause.entries()
        ].map(([cause, e])=>{
            const meanFwd6h = Number((e.s6 / e.n).toFixed(3));
            return {
                cause,
                n: e.n,
                meanFwd2h: e.n > 0 ? Number((e.s2 / e.n).toFixed(3)) : null,
                meanFwd6h,
                continuationRatePct: Math.round(e.cont / e.n * 100),
                learnedAllowed: e.n >= LEARN_GATE.minN && e.cont / e.n * 100 >= LEARN_GATE.minContPct && Math.abs(meanFwd6h) >= LEARN_GATE.minAbsFwd
            };
        }).sort((a, b)=>b.n - a.n);
        const allowed = causes.filter((c)=>c.learnedAllowed);
        const study = {
            at: Date.now(),
            settled: settled.length,
            causes,
            verdict: settled.length === 0 ? "NO SETTLED EVENTS YET — the loop settles each capture with real 2h/6h forward returns" : allowed.length > 0 ? `LEARNED CONTINUATION PROFILES ACTIVE: ${allowed.map((c)=>`${c.cause} (n=${c.n}, cont ${c.continuationRatePct}%)`).join(", ")} — engine may nudge conviction/sizing on fresh matching events` : `TELEMETRY-ONLY — no cause has cleared the learned gate (n ≥ ${LEARN_GATE.minN} · cont ≥ ${LEARN_GATE.minContPct}% · |fwd6h| ≥ ${LEARN_GATE.minAbsFwd}%)`
        };
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: STUDY_KEY
            },
            create: {
                key: STUDY_KEY,
                value: JSON.stringify(study)
            },
            update: {
                value: JSON.stringify(study)
            }
        });
        studyCache = {
            at: Date.now(),
            study
        };
        return study;
    } catch  {
        return studyCache?.study ?? null;
    }
}
async function loadStudy() {
    if (studyCache && Date.now() - studyCache.at < STUDY_CACHE_TTL) return studyCache.study;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: STUDY_KEY
            }
        });
        if (!row) return null;
        const study = JSON.parse(row.value);
        studyCache = {
            at: Date.now(),
            study
        };
        return study;
    } catch  {
        return null;
    }
}
async function volCauseBoost(symbol, direction) {
    try {
        const ev = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findFirst({
            where: {
                symbol,
                detectedAt: {
                    gte: new Date(Date.now() - DEDUPE_WINDOW_MS)
                }
            },
            orderBy: {
                detectedAt: "desc"
            }
        });
        if (!ev) return {
            boost: 0,
            cause: null,
            basis: "NO-RECENT-EVENT",
            detail: null
        };
        const study = await loadStudy();
        const attr = JSON.parse(ev.causesJson).filter((c)=>c.weight >= 25).map((c)=>c.cause);
        const candidates = [
            ev.primaryCause,
            ...attr
        ].filter((c, i, arr)=>arr.indexOf(c) === i);
        const eventDir = ev.direction === "UP" ? "LONG" : "SHORT";
        for (const cause of candidates){
            const cs = study?.causes.find((c)=>c.cause === cause);
            if (cs?.learnedAllowed && direction === eventDir) {
                const boost = Math.max(2, Math.min(4, Math.round(Math.abs(cs.meanFwd6h ?? 0) * 10)));
                return {
                    boost,
                    cause,
                    basis: "LEARNED-CONTINUATION",
                    detail: `${cause} continuation profile n=${cs.n} · mean fwd6h ${cs.meanFwd6h !== null ? `${cs.meanFwd6h >= 0 ? "+" : ""}${cs.meanFwd6h}%` : "—"} · cont ${cs.continuationRatePct}%`
                };
            }
        }
        return {
            boost: 0,
            cause: candidates[0] ?? null,
            basis: "TELEMETRY-ONLY",
            detail: `recent top-vol event (${candidates[0] ?? "MIXED"}) — learned gate not cleared for this profile yet`
        };
    } catch  {
        return {
            boost: 0,
            cause: null,
            basis: "UNAVAILABLE",
            detail: null
        };
    }
}
async function getVolCauseBoard() {
    const [events, total, unsettled, study] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.findMany({
            orderBy: {
                detectedAt: "desc"
            },
            take: 24
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.count(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].volCauseEvent.count({
            where: {
                settledAt: null
            }
        }),
        loadStudy()
    ]);
    return {
        computedAt: Date.now(),
        rules: {
            capture: `top-${CAPTURE_TOP_N} of MARKET MATRIX (|Δ24h| ≥ ${MIN_ABS_RET}%), 6h dedupe per symbol`,
            settle: "real fwd 2h/6h returns from 1h futures klines",
            learnGate: `n ≥ ${LEARN_GATE.minN} · continuation ≥ ${LEARN_GATE.minContPct}% · |mean fwd6h| ≥ ${LEARN_GATE.minAbsFwd}%`,
            engineUse: "learned profiles nudge conviction (+2..4) and sizing (×1.15) at deploy; otherwise telemetry-only vote 0"
        },
        totals: {
            total,
            unsettled
        },
        study,
        events: events.map((e)=>({
                id: e.id,
                symbol: e.symbol,
                detectedAt: e.detectedAt.toISOString(),
                rank: e.rank,
                direction: e.direction,
                change24h: e.change24h,
                price: e.price,
                oiDelta10m: e.oiDelta10m,
                oiDelta1h: e.oiDelta1h,
                cvdPct: e.cvdPct,
                crowdLS: e.crowdLS,
                funding8h: e.funding8h,
                liqUsd1h: e.liqUsd1h,
                onsetScore: e.onsetScore,
                session: e.session,
                causes: JSON.parse(e.causesJson || "[]"),
                primaryCause: e.primaryCause,
                fwd2hPct: e.fwd2hPct,
                fwd6hPct: e.fwd6hPct,
                settled: e.settledAt !== null
            }))
    };
}
}),
"[project]/src/lib/binance-mirror.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mirrorFunding8h",
    ()=>mirrorFunding8h,
    "mirrorHealth",
    ()=>mirrorHealth,
    "mirrorKlines",
    ()=>mirrorKlines,
    "mirrorOiDelta1h",
    ()=>mirrorOiDelta1h,
    "mirrorTickers",
    ()=>mirrorTickers
]);
// ── NEXUS//SIGNALS — Binance mirror client (server-only, v14.0) ─────────────
// v14.0 BINANCE-ONLY RE-ARCHITECTURE (operator mandate trace 1a185042c872b4f9
// — «ردپای OKX/Bybit در کجا وجود دارد و با بایننس جایگزین شود»): the former
// cross-venue feed module is rebuilt as the BINANCE MIRROR client. Every
// consumer gets a LIVE, honestly-plane-tagged Binance board:
//   • klines/tickers ride the spot-host ladder (data-api.binance.vision →
//     api-gcp → api1-4 → api.binance.com) — a SEPARATE ban pool from fapi,
//     spot klines keep the field-9 taker-buy split (CVD stays REAL).
//   • funding / OI history ride the gated fapi plane (perp-native).
// HONESTY DOCTRINE (October carry-over): fallback-plane data is tagged with
// its real Binance plane; a plane that fails degrades to null — never to
// invented data.
// ─────────────────────────────────────────────────────────────────────────────
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
const TIMEOUT_MS = 6500;
// v13.3 SPOT-HOST LADDER (same family as flow-bridge/market-feed — shared gate)
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
];
const health = (()=>{
    // globalThis dedupe — Turbopack per-bundle instantiation would otherwise
    // fork the counters between the engine bundle and per-route bundles.
    const g = globalThis;
    g.__nexusMirrorHealth ??= {
        lastOkAt: null,
        lastErrorAt: null,
        lastError: null,
        consecutiveFailures: 0,
        latencyMs: null,
        klinesOk: 0,
        tickersOk: 0,
        metricsOk: 0
    };
    return g.__nexusMirrorHealth;
})();
function mirrorHealth() {
    return health;
}
async function ladderGet(path) {
    const t0 = Date.now();
    const ready = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotHostsReady"])(SPOT_HOSTS);
    for (const host of ready){
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["noteSpotHostThrottle"])(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) {
                health.lastErrorAt = Date.now();
                health.lastError = `${path} → ${res.status}`;
                health.consecutiveFailures++;
                continue;
            }
            const json = await res.json();
            health.lastOkAt = Date.now();
            health.latencyMs = Date.now() - t0;
            health.consecutiveFailures = 0;
            return json;
        } catch (e) {
            health.lastErrorAt = Date.now();
            health.lastError = e instanceof Error ? e.message : String(e);
            health.consecutiveFailures++;
        }
    }
    return null;
}
async function mirrorKlines(symbol, interval, limit) {
    const raw = await ladderGet(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${Math.min(1000, limit)}`);
    if (!Array.isArray(raw) || raw.length === 0) return null;
    health.klinesOk++;
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5]),
            takerBuy: Number(k[9])
        }));
}
async function mirrorTickers() {
    const out = new Map();
    const rows = await ladderGet("/api/v3/ticker/24hr");
    if (!Array.isArray(rows)) return out;
    health.tickersOk++;
    for (const t of rows){
        if (!t?.symbol || !(Number(t.lastPrice) > 0)) continue;
        out.set(t.symbol, {
            symbol: t.symbol,
            lastPrice: t.lastPrice,
            priceChangePercent: t.priceChangePercent ?? "0",
            highPrice: t.highPrice ?? t.lastPrice,
            lowPrice: t.lowPrice ?? t.lastPrice,
            quoteVolume: t.quoteVolume ?? "0"
        });
    }
    return out;
}
async function mirrorFunding8h(symbol) {
    const rows = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/fundingRate?symbol=${symbol}&limit=1`, {
        priority: "telemetry",
        timeoutMs: 6000
    }).catch(()=>null);
    const r = rows?.[0]?.fundingRate;
    if (r === undefined) return null;
    health.metricsOk++;
    const n = Number(r);
    return Number.isFinite(n) ? n * 100 : null;
}
async function mirrorOiDelta1h(symbol) {
    const rows = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/futures/data/openInterestHist?symbol=${symbol}&period=1h&limit=2`, {
        priority: "telemetry",
        timeoutMs: 6000
    }).catch(()=>null);
    if (!Array.isArray(rows) || rows.length < 2) return null;
    health.metricsOk++;
    const cur = Number(rows[0]?.sumOpenInterest);
    const prev = Number(rows[rows.length - 1]?.sumOpenInterest);
    if (!Number.isFinite(cur) || !Number.isFinite(prev) || prev <= 0) return null;
    return Number(((cur - prev) / prev * 100).toFixed(3));
}
}),
"[project]/src/lib/flow-scanner.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SCAN_TFS",
    ()=>SCAN_TFS,
    "ensureSymbolFlow",
    ()=>ensureSymbolFlow,
    "flowScanHealth",
    ()=>flowScanHealth,
    "flowShiftTracking",
    ()=>flowShiftTracking,
    "getFlowBoard",
    ()=>getFlowBoard,
    "maybeFlowScan",
    ()=>maybeFlowScan,
    "peekFlowKlines",
    ()=>peekFlowKlines,
    "peekSymbolFlow",
    ()=>peekSymbolFlow,
    "refreshSymbolFlow",
    ()=>refreshSymbolFlow
]);
// ── FlowRadar Neo v8.0 MULTI-TIMEFRAME FLOW SCANNER (EPOCH-2, server-only) ──
// Operator mandate 2026-09-08: «معماری سیستم اسکنر جریانات مالی با قابلیت ردیابی
// در تایم فریمهای مختلف». Research base: docs/RESEARCH-FLOW-DETECTION.md.
//
// Design laws (research-derived):
//   · HTF dominance — 4h/1h carry the bias; 15m/5m only time the entry.
//   · Closed bars only — every structure call is on a CLOSED candle (no repaint,
//     no lookahead).
//   · Flow must explain price — the OI×price validity matrix and CVD divergence
//     rule come from flow.ts; this module extends them across TFs.
//   · Sweeps are context — a sweep counts only against the prior 24-bar swing of
//     ITS OWN timeframe, with a ≥50% rejection wick.
//
// Cadence: rotating batch of 6 symbols per call (engine tick ×25 ≈ 87s) → the
// full 40-64 symbol domain re-scans in ~10-16min. Per-TF kline caches keep the
// API cost at ~24 kline calls/min worst case. Persistence: one FlowScan row per
// (symbol, tf) UPSERTED (no churn) + the whole board in EngineSetting
// "flowscan.board" (single-row upsert — race-free by construction).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$binance$2d$mirror$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/binance-mirror.ts [app-route] (ecmascript)"); // v14.0 — Binance mirror client (bybit-feed retired)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
;
;
;
const SCAN_TFS = [
    "4h",
    "1h",
    "15m",
    "5m"
];
const TF_WEIGHT = {
    "4h": 0.35,
    "1h": 0.3,
    "15m": 0.2,
    "5m": 0.15
};
const TF_LIMIT = {
    "4h": 72,
    "1h": 96,
    "15m": 120,
    "5m": 120
};
const TF_TTL = {
    "4h": 480_000,
    "1h": 240_000,
    "15m": 90_000,
    "5m": 45_000
};
const BOARD_KEY = "flowscan.board";
const BATCH = 6;
// DATA-REVIVAL 2026-10-21 — 60s/6 symbols needed ~11min to rotate a 64-symbol
// board; the operator mandate is flow tracking at HIGH SPEED. 20s/6 → full
// board ~3.5min. The SPOT-MIRROR ladder carries this easily; the fapi-gate
// telemetry lane is sheddable as before.
const MIN_INTERVAL_MS = 20_000;
const NET_BIAS_MIN = 20; // |netScore| needed to call a LONG/SHORT board
const HTF_FLIP_MIN = {
    h4: 25,
    h1: 30
}; // HTF-conflict thresholds for FLOW-SHIFT
const SHIFT_COOLDOWN_MS = 2 * 3600_000;
// ── kline+flow fetch with per-(symbol,tf) cache and in-flight dedupe ──
const klineFlowCache = new Map();
const klineFlowInFlight = new Map();
// RAM-SHED round-2 (P2-c): the tracked domain grew to ~900 symbols × 4 TFs ≈
// 3.6k possible entries; every entry is 72-120 FlowCandle objects (~10-15KB),
// so one slow tail rotation parks ~40-55MB of mostly-stale klines in the Map
// between scans (TTL expiry only gates READS — stale entries linger forever).
// Cap at 600 (hot lane 64×4=256 + recent tail) with oldest-`at` eviction on
// insert: evicted entries are exactly the ones already past their TF TTL that
// would refetch on their next rotation anyway. The __nexusShed hook below
// keeps its exact semantics — the cap just bounds what it has to trim.
const KLINE_FLOW_CACHE_MAX = 600;
function klineFlowCacheSet(key, entry) {
    if (!klineFlowCache.has(key)) {
        while(klineFlowCache.size >= KLINE_FLOW_CACHE_MAX){
            let oldestKey = null;
            let oldestAt = Number.POSITIVE_INFINITY;
            for (const [k, v] of klineFlowCache){
                if (v.at < oldestAt) {
                    oldestAt = v.at;
                    oldestKey = k;
                }
            }
            if (oldestKey === null) break; // unreachable — Map cannot shrink below empty
            klineFlowCache.delete(oldestKey);
        }
    }
    klineFlowCache.set(key, entry);
}
// DATA-REVIVAL 2026-10-21 — silent-starvation fix: when the fapi plane fails
// (IP-ban 418), the failure is COUNTED and rate-limit-logged, and the scan
// falls back to the Binance SPOT mirror ladder with an honest plane tag
// (v14.0: the old cross-venue rung is retired — Binance-only).
const fbStats = (()=>{
    // globalThis dedupe — Turbopack can instantiate per-route bundles; the
    // engine's tick loop and the /api/flows route MUST share one counter set.
    const g = globalThis;
    g.__nexusFlowFbStats ??= {
        fapiFail: 0,
        mirrorOk: 0,
        mirrorFail: 0,
        spotOk: 0,
        lastWarnAt: 0
    };
    return g.__nexusFlowFbStats;
})();
// third rung — Binance SPOT klines via the data-vision mirror host family
// (api.binance.com is IP-banned; data-api.binance.vision is NOT — proven live
// by the feed probe). Spot klines share the exact field layout (takerBuy at
// index 9) so CVD stays REAL. For niche Binance listings absent from spot
// linear this is the only honest revival path.
// v13.2.1 — per-host 418/429 backoff via the shared spot-host gate.
async function spotKlines(symbol, tf, limit) {
    for (const host of (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotHostsReady"])([
        "https://data-api.binance.vision",
        "https://api-gcp.binance.com",
        "https://api1.binance.com",
        "https://api2.binance.com",
        "https://api3.binance.com",
        "https://api4.binance.com",
        "https://api.binance.com"
    ])){
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), 6500);
            const res = await fetch(`${host}/api/v3/klines?symbol=${symbol}&interval=${tf}&limit=${limit}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["noteSpotHostThrottle"])(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) continue;
            const raw = await res.json();
            if (!Array.isArray(raw) || raw.length === 0) continue;
            return raw.map((k)=>({
                    openTime: Number(k[0]),
                    open: Number(k[1]),
                    high: Number(k[2]),
                    low: Number(k[3]),
                    close: Number(k[4]),
                    volume: Number(k[5]),
                    takerBuy: Number(k[9])
                }));
        } catch  {
            continue;
        }
    }
    return null;
}
function warnFallback(msg) {
    if (Date.now() - fbStats.lastWarnAt < 60_000) return;
    fbStats.lastWarnAt = Date.now();
    console.warn(`[flow-scanner] ${msg}`);
}
function flowScanHealth() {
    return {
        fapiFail: fbStats.fapiFail,
        mirrorOk: fbStats.mirrorOk,
        mirrorFail: fbStats.mirrorFail,
        spotOk: fbStats.spotOk,
        mirror: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$binance$2d$mirror$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mirrorHealth"])()
    };
}
async function fetchKlinesFlow(symbol, tf) {
    const key = `${symbol}|${tf}`;
    const hit = klineFlowCache.get(key);
    if (hit && Date.now() - hit.at < TF_TTL[tf]) return hit;
    const existing = klineFlowInFlight.get(key);
    if (existing) return existing;
    const p = (async ()=>{
        try {
            // v10.24 Task 34-a: klines through the central fapi-gate (telemetry lane
            // — a shedded (symbol,tf) simply re-scans on the next rotation).
            let venue = "BINANCE";
            let raw = null;
            try {
                raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${tf}&limit=${TF_LIMIT[tf]}`, {
                    priority: "telemetry",
                    timeoutMs: 6500
                });
            } catch  {
                raw = null;
            }
            if (!raw || raw.length === 0) {
                // v14.0 honest fallback ladder — the SPOT mirror only (keeps CVD REAL
                // via taker-buy field 9). When the spot ladder also misses, the
                // (symbol,tf) starves honestly — no cross-venue rows exist anymore.
                fbStats.fapiFail++;
                const spot = await spotKlines(symbol, tf, TF_LIMIT[tf]);
                if (spot && spot.length > 0) {
                    venue = "BINANCE-SPOT"; // same venue, SPOT instrument class (vision mirror)
                    fbStats.spotOk++;
                    fbStats.mirrorOk++;
                    warnFallback(`fapi kline unavailable (${symbol} ${tf}) → BINANCE-SPOT mirror (CVD real, spot tape)`);
                    klineFlowCacheSet(key, {
                        at: Date.now(),
                        candles: spot,
                        venue
                    });
                    return {
                        candles: spot,
                        venue
                    };
                }
                fbStats.mirrorFail++;
                warnFallback(`kline starved on ALL Binance planes: ${symbol} ${tf} (fapi + spot mirror)`);
                return null;
            }
            const candles = raw.map((k)=>({
                    openTime: Number(k[0]),
                    open: Number(k[1]),
                    high: Number(k[2]),
                    low: Number(k[3]),
                    close: Number(k[4]),
                    volume: Number(k[5]),
                    takerBuy: Number(k[9])
                }));
            klineFlowCacheSet(key, {
                at: Date.now(),
                candles,
                venue: "BINANCE"
            });
            return {
                candles,
                venue: "BINANCE"
            };
        } catch  {
            return null;
        } finally{
            klineFlowInFlight.delete(key);
        }
    })();
    klineFlowInFlight.set(key, p);
    return p;
}
// ── pure per-TF analytics (closed bars ONLY — the last raw kline may be
// unclosed, so it is dropped before any computation) ──
function ema(values, period) {
    if (values.length === 0) return 0;
    const k = 2 / (period + 1);
    let e = values[0];
    for(let i = 1; i < values.length; i++)e = values[i] * k + e * (1 - k);
    return e;
}
function analyzeTf(symbol, tf, raw, funding8h, oiDelta1h) {
    const candles = raw.slice(0, -1); // drop the possibly-unclosed bar — closed bars only
    if (candles.length < 40) return null;
    const closes = candles.map((c)=>c.close);
    const e20 = ema(closes.slice(-60), 20);
    const e50 = ema(closes.slice(-90), 50);
    const trend = e20 > e50 * 1.0005 ? "UP" : e20 < e50 * 0.9995 ? "DOWN" : "FLAT";
    // pivots over the last 30 closed bars (fractal: 2 bars each side)
    const win = candles.slice(-30);
    const pivotHighs = [];
    const pivotLows = [];
    for(let i = 2; i < win.length - 2; i++){
        const h = win[i].high;
        const l = win[i].low;
        if (h > win[i - 1].high && h > win[i - 2].high && h > win[i + 1].high && h > win[i + 2].high) pivotHighs.push(h);
        if (l < win[i - 1].low && l < win[i - 2].low && l < win[i + 1].low && l < win[i + 2].low) pivotLows.push(l);
    }
    const swingHigh = pivotHighs.length ? Math.max(...pivotHighs) : Math.max(...win.slice(0, -1).map((c)=>c.high));
    const swingLow = pivotLows.length ? Math.min(...pivotLows) : Math.min(...win.slice(0, -1).map((c)=>c.low));
    const last = win[win.length - 1];
    const range = last.high - last.low;
    let structure = "RANGE";
    let sweep = false;
    if (range > 0) {
        // liquidity sweep — grab the obvious swing, close back inside, ≥50% rejection wick
        if (last.high > swingHigh && last.close < swingHigh && (last.high - last.close) / range >= 0.5) {
            structure = "SWEEP_HIGH";
            sweep = true;
        } else if (last.low < swingLow && last.close > swingLow && (last.close - last.low) / range >= 0.5) {
            structure = "SWEEP_LOW";
            sweep = true;
        } else if (last.close > swingHigh) {
            structure = trend === "DOWN" ? "CHOH_UP" : "BOS_UP";
        } else if (last.close < swingLow) {
            structure = trend === "UP" ? "CHOH_DOWN" : "BOS_DOWN";
        }
    }
    // CVD over the last 12 closed bars — direct taker aggression from kline field 9.
    // DATA-REVIVAL: fallback candles without field-9 carry takerBuy=NaN → cvdPct stays null
    // (honest measured gap — never invented from price direction).
    const w12 = candles.slice(-12);
    const vol12 = w12.reduce((a, c)=>a + c.volume, 0);
    const buy12 = w12.reduce((a, c)=>a + c.takerBuy, 0);
    const cvdPct = vol12 > 0 && Number.isFinite(buy12) ? Number(((2 * buy12 - vol12) / vol12 * 100).toFixed(2)) : null;
    // volume ignition z-score (last closed bar vs prior 30)
    const v30 = candles.slice(-31, -1).map((c)=>c.volume);
    const vMean = v30.reduce((a, b)=>a + b, 0) / Math.max(1, v30.length);
    const vStd = Math.sqrt(v30.reduce((a, b)=>a + (b - vMean) * (b - vMean), 0) / Math.max(1, v30.length));
    const volZ = vStd > 0 ? Number(((last.volume - vMean) / vStd).toFixed(2)) : null;
    // ATR% (14 bars, true range)
    let atrSum = 0;
    for(let i = candles.length - 14; i < candles.length; i++){
        const c = candles[i];
        const p = candles[i - 1];
        atrSum += Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
    }
    const atrPct = Number((atrSum / 14 / last.close * 100).toFixed(2));
    // per-TF score −100..+100
    let s = 0;
    if (cvdPct !== null) s += Math.max(-40, Math.min(40, cvdPct * 2.2));
    s += trend === "UP" ? 18 : trend === "DOWN" ? -18 : 0;
    if (structure === "BOS_UP") s += 20;
    else if (structure === "BOS_DOWN") s -= 20;
    else if (structure === "CHOH_UP") s += 14;
    else if (structure === "CHOH_DOWN") s -= 14;
    if (structure === "SWEEP_LOW") s += 14; // sell-side liquidity grabbed → fuel for longs
    else if (structure === "SWEEP_HIGH") s -= 14; // buy-side grabbed → fuel for shorts
    if (volZ !== null && cvdPct !== null) s += Math.sign(cvdPct) * Math.min(3, Math.max(0, volZ)) * 4;
    const score = Math.round(Math.max(-100, Math.min(100, s)));
    const bias = score >= 25 ? "LONG" : score <= -25 ? "SHORT" : "NEUTRAL";
    return {
        tf,
        score,
        bias,
        trend,
        structure,
        sweep,
        cvdPct,
        volZ,
        atrPct
    };
}
// ── board state ──
const board = new Map();
let boardLoaded = false;
// (scanCursor removed in v12.10 — the two-speed rotation picks oldest-board-first,
//  no fixed cursor: hot lane 5/6 + tail 1/6 of every batch)
let lastScanAt = 0;
let scanInFlight = false;
const shiftLastAt = new Map();
// RAM-SHED round-2 (P2-c): board churn-guard. Entries are small (~1KB) but the
// Map grows with every distinct symbol ever scanned (universe ~900 and
// growing — delisted symbols never leave). Cap 1024 (≈2× the hot universe)
// with oldest-`at` eviction: evicted rows are far past the 20min peek TTL
// (peekSymbolFlow already returns null for them) and the rotation's
// oldest-board-first sort treats a missing row exactly like a stale one
// (+∞ age → first in line for a re-scan). DB (flowscan.board / FlowScan rows)
// stays the durable source of truth — loadBoard refills ≤64 rows at boot.
const BOARD_MAX = 1024;
function boardSet(symbol, rollup) {
    if (!board.has(symbol)) {
        while(board.size >= BOARD_MAX){
            let oldestKey = null;
            let oldestAt = Number.POSITIVE_INFINITY;
            for (const [k, v] of board){
                if (v.at < oldestAt) {
                    oldestAt = v.at;
                    oldestKey = k;
                }
            }
            if (oldestKey === null) break;
            board.delete(oldestKey);
        }
    }
    board.set(symbol, rollup);
}
// ── RAM-SHED hook (RAM-SHED-20261024) ──────────────────────────────────────
// The instrumentation RSS governor calls this under memory pressure. The
// kline cache is the biggest DISCRETIONARY in-app store (candles per
// symbol×tf — safely refetchable within one scan cycle), so it sheds first:
// entries older than 10min are dropped + in-flight dedupe cleared. Returns
// the number of entries freed for the governor log. globalThis dedupe —
// Turbopack can instantiate per-route bundles; the governor must reach the
// ONE shared cache instance.
{
    const g = globalThis;
    if (!g.__nexusShed) {
        g.__nexusShed = ()=>{
            let freed = 0;
            const now = Date.now();
            for (const [key, entry] of klineFlowCache){
                if (now - entry.at > 10 * 60_000) {
                    klineFlowCache.delete(key);
                    freed++;
                }
            }
            klineFlowInFlight.clear();
            return freed;
        };
    }
}async function loadBoard() {
    if (boardLoaded) return;
    boardLoaded = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: BOARD_KEY
            }
        });
        if (row) {
            const parsed = JSON.parse(row.value);
            for (const r of parsed.rows ?? [])board.set(r.symbol, r);
        }
    } catch  {
    /* cold start — the scanner repopulates within minutes */ }
}
async function persistBoard() {
    const rows = [
        ...board.values()
    ].sort((a, b)=>Math.abs(b.netScore) - Math.abs(a.netScore)).slice(0, 64);
    const value = JSON.stringify({
        at: Date.now(),
        rows
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: BOARD_KEY
        },
        create: {
            key: BOARD_KEY,
            value
        },
        update: {
            value
        }
    });
}
async function scanSymbol(symbol) {
    const settled = await Promise.allSettled(SCAN_TFS.map((tf)=>fetchKlinesFlow(symbol, tf)));
    const raw = settled.map((r)=>r.status === "fulfilled" ? r.value : null);
    if (raw.filter(Boolean).length < 3) return null; // honest: need ≥3 TFs, no invented rows
    const venues = raw.filter(Boolean).map((r)=>r.venue);
    const rollupVenue = venues.every((v)=>v === "BINANCE") ? "BINANCE" : venues.every((v)=>v === "BINANCE-SPOT") ? "BINANCE-SPOT" : "MIXED";
    // derivatives context is TF-agnostic — one shared cached fetch (flow.ts)
    let funding8h = null;
    let oiDelta1h = null;
    try {
        const m = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFlowMetrics"])(symbol);
        if (m) {
            funding8h = m.funding8h;
            oiDelta1h = m.oiDelta1h;
        }
    } catch  {
    /* context stays null — rows still ship with the measured price-flow vector */ }
    const tfs = [];
    for(let i = 0; i < SCAN_TFS.length; i++){
        const r = raw[i];
        if (!r) continue;
        const row = analyzeTf(symbol, SCAN_TFS[i], r.candles, funding8h, oiDelta1h);
        if (row) tfs.push(row);
    }
    if (tfs.length < 3) return null;
    const netScore = Math.round(tfs.reduce((a, t)=>a + t.score * TF_WEIGHT[t.tf], 0));
    const netBias = netScore >= NET_BIAS_MIN ? "LONG" : netScore <= -NET_BIAS_MIN ? "SHORT" : "NEUTRAL";
    const alignment = netBias === "NEUTRAL" ? 0 : tfs.filter((t)=>t.bias === netBias).length;
    return {
        symbol,
        at: Date.now(),
        netScore,
        netBias,
        alignment,
        tfs,
        funding8h,
        oiDelta1h,
        venue: rollupVenue
    };
}
async function maybeFlowScan(symbols) {
    await loadBoard();
    if (scanInFlight || symbols.length === 0) return;
    if (Date.now() - lastScanAt < MIN_INTERVAL_MS) return;
    scanInFlight = true;
    lastScanAt = Date.now();
    try {
        // v12.10 TWO-SPEED ROTATION (AUDIT-20261023 root-cause of «سرعت تشخیص»):
        // the tracked domain grew to ~900 symbols while the rotation budget stayed
        // at the 64-symbol design (6/call, 20s) → a full cycle takes ~50min against
        // the 20min board TTL → peekSymbolFlow() returns null (stale-never-gates)
        // for MOST of the universe → the MTF deploy guard silently blind. Fix: the
        // caller now passes the domain VOLUME-RANKED (hot deployable universe
        // first); this lane owns 5/6 of every batch, the long tail 1 slot — both
        // oldest-board-first so ages self-balance. Hot lane (64 syms) re-scans in
        // ~4.3min « well under the TTL; the dust tail rotates slowly but is
        // liquidity-floored out of deploys anyway.
        const HOT = 64;
        const boardAge = (s)=>{
            const r = board.get(s);
            return r ? Date.now() - r.at : Number.POSITIVE_INFINITY;
        };
        const oldestFirst = (arr, n)=>[
                ...arr
            ].sort((a, b)=>boardAge(b) - boardAge(a)).slice(0, Math.max(0, Math.min(n, arr.length)));
        const head = symbols.slice(0, HOT);
        const tail = symbols.slice(HOT);
        const batch = [
            ...oldestFirst(head, tail.length > 0 ? BATCH - 1 : BATCH),
            ...oldestFirst(tail, tail.length > 0 ? 1 : 0)
        ];
        if (batch.length === 0) return;
        for (const symbol of batch){
            const rollup = await scanSymbol(symbol).catch(()=>null);
            if (!rollup) continue;
            boardSet(symbol, rollup);
            for (const t of rollup.tfs){
                const data = {
                    score: t.score,
                    bias: t.bias,
                    cvdPct: t.cvdPct,
                    trend: t.trend,
                    structure: t.structure,
                    sweep: t.sweep,
                    volZ: t.volZ,
                    atrPct: t.atrPct,
                    funding8h: rollup.funding8h,
                    oiDelta1h: rollup.oiDelta1h
                };
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].flowScan.upsert({
                    where: {
                        symbol_tf: {
                            symbol,
                            tf: t.tf
                        }
                    },
                    create: {
                        symbol,
                        tf: t.tf,
                        ...data
                    },
                    update: data
                });
            }
        }
        await persistBoard();
    } finally{
        scanInFlight = false;
    }
}
/** v12.12 CARD-SENTINEL (2026-10-24) — on-demand single-symbol refresh that ALSO
 *  persists the FlowScan DB cards. ensureSymbolFlow() only warms the in-memory
 *  board; the DB rows the dashboard renders were left to the two-speed rotation,
 *  so any symbol that cooled off went stale for hours (BIRBUSDT cards 4h9m old
 *  while its events kept firing — SENTINEL-M0M2 finding #6). One in-flight
 *  refresh per process; callers rate-limit per symbol (route enforces 90s). */ let refreshInFlight = false;
async function refreshSymbolFlow(symbol) {
    if (refreshInFlight) return null;
    refreshInFlight = true;
    try {
        await loadBoard();
        const rollup = await scanSymbol(symbol).catch(()=>null);
        if (!rollup) return null;
        boardSet(symbol, rollup);
        for (const t of rollup.tfs){
            const data = {
                score: t.score,
                bias: t.bias,
                cvdPct: t.cvdPct,
                trend: t.trend,
                structure: t.structure,
                sweep: t.sweep,
                volZ: t.volZ,
                atrPct: t.atrPct,
                funding8h: rollup.funding8h,
                oiDelta1h: rollup.oiDelta1h
            };
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].flowScan.upsert({
                where: {
                    symbol_tf: {
                        symbol,
                        tf: t.tf
                    }
                },
                create: {
                    symbol,
                    tf: t.tf,
                    ...data
                },
                update: data
            });
        }
        await persistBoard();
        return rollup;
    } finally{
        refreshInFlight = false;
    }
}
function peekSymbolFlow(symbol) {
    const r = board.get(symbol);
    if (!r) return null;
    const age = Date.now() - r.at;
    if (age > 20 * 60_000) return null; // stale board never gates — 20min TTL
    return r;
}
async function ensureSymbolFlow(symbol) {
    await loadBoard();
    const peeked = peekSymbolFlow(symbol);
    if (peeked) return peeked;
    return scanSymbol(symbol);
}
function peekFlowKlines(symbol, tf) {
    const hit = klineFlowCache.get(`${symbol}|${tf}`);
    if (!hit || Date.now() - hit.at >= TF_TTL[tf]) return null;
    return hit.candles;
}
async function flowShiftTracking() {
    await loadBoard();
    const active = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "ACTIVE",
                    "TP1",
                    "TP2"
                ]
            }
        },
        select: {
            id: true,
            serial: true,
            symbol: true,
            direction: true
        }
    });
    if (active.length === 0) return;
    const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)"); // dynamic — keeps the module cycle off the boot path
    for (const s of active){
        const r = board.get(s.symbol);
        if (!r || r.netBias === "NEUTRAL") continue;
        const h1 = r.tfs.find((t)=>t.tf === "1h");
        const h4 = r.tfs.find((t)=>t.tf === "4h");
        if (!h1 || !h4) continue;
        const dirLong = s.direction === "LONG";
        const against = dirLong ? "SHORT" : "LONG";
        const flipped = h1.bias === against && h4.bias === against && Math.abs(h1.score) >= HTF_FLIP_MIN.h1 && Math.abs(h4.score) >= HTF_FLIP_MIN.h4;
        if (!flipped) continue;
        const last = shiftLastAt.get(s.id) ?? 0;
        if (Date.now() - last < SHIFT_COOLDOWN_MS) continue;
        shiftLastAt.set(s.id, Date.now());
        await fireEvent(s.id, s.symbol, "ENGINE", "warn", `FLOW-SHIFT: NX-${String(s.serial).padStart(4, "0")} ${s.direction} ${s.symbol} — 1h (${h1.score}) and 4h (${h4.score}) flow boards both flipped ${against} while the book is live (board net ${r.netScore}, ${r.alignment}/4 TFs aligned). Regime damage visible BEFORE the stop — consider BE-trail status.`);
    }
}
async function getFlowBoard() {
    await loadBoard();
    const rows = [
        ...board.values()
    ].sort((a, b)=>Math.abs(b.netScore) - Math.abs(a.netScore));
    return {
        at: new Date().toISOString(),
        coverage: rows.length,
        rows: rows.slice(0, 48)
    };
}
}),
"[project]/src/lib/cascade-alerts.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── v12.10 CASCADE-FREEZE registry (server-only) ────────────────────────────
// AUDIT-20261023 follow-up — operator mandate: «چرا سرعت تشخیص هنوز اصلاح
// نشده؟ چه اقدامات مهندسی لازم است؟»
//
// Root cause measured: the L3_LIQ_CASCADE layer is LIQUIDATION-STREAM based
// (forceOrder) — structurally silent for microcaps that produce zero
// forceOrder events (JCT/IRYS forensics), and VolCauseEvent registration is
// backward-looking (IRYS +565% day = ONE event, registered 16h late at the
// tick-top; the −77.4% crash after it registered NOTHING).
//
// This registry is fed by the price-ws TICK-VELOCITY detector (a ≥±5% move
// inside a 60s sliding window — measured on the live WS tape, independent of
// liquidation streams). A cascade alert freezes BOTH-direction machine
// deploys for the symbol for FREEZE_MS: the engine checks
// cascadeFreezeActive(symbol) before deploying. Detection latency drops from
// the measured 359s (NX-3046) to the 15-60s window of the tick plane.
//
// Storage: globalThis singleton map (Turbopack per-route split-brain safe,
// same doctrine as flow-scanner's fbStats) — 10min TTL self-expires, re-fires
// extend the freeze. No DB writes: the single-writer discipline stays intact.
__turbopack_context__.s([
    "cascadeFreezeActive",
    ()=>cascadeFreezeActive,
    "cascadeFreezes",
    ()=>cascadeFreezes,
    "recordCascadeAlert",
    ()=>recordCascadeAlert
]);
const FREEZE_MS = 10 * 60_000;
const MAX_ALERTS = 200;
const g = globalThis;
g.__nexusCascadeAlerts ??= new Map();
const alerts = g.__nexusCascadeAlerts;
function recordCascadeAlert(input) {
    const now = Date.now();
    const prev = alerts.get(input.symbol);
    const rec = {
        symbol: input.symbol,
        side: input.side === "UP" ? "UP" : "DOWN",
        movePct: Number(input.movePct.toFixed(2)),
        windowMs: Math.max(0, Math.round(input.windowMs)),
        lane: String(input.lane).slice(0, 24),
        at: input.at > 0 && input.at <= now + 5_000 ? input.at : now,
        until: Math.max(now + FREEZE_MS, prev && prev.until > now ? prev.until : 0)
    };
    alerts.set(rec.symbol, rec);
    // prune expired + cap the ring (oldest-alert-first)
    for (const [k, v] of alerts)if (v.until < now) alerts.delete(k);
    if (alerts.size > MAX_ALERTS) {
        const oldest = [
            ...alerts.values()
        ].sort((a, b)=>a.at - b.at)[0];
        if (oldest) alerts.delete(oldest.symbol);
    }
    return rec;
}
function cascadeFreezeActive(symbol) {
    const rec = alerts.get(symbol);
    if (!rec || rec.until < Date.now()) return {
        active: false,
        info: null
    };
    return {
        active: true,
        info: rec
    };
}
function cascadeFreezes() {
    const now = Date.now();
    for (const [k, v] of alerts)if (v.until < now) alerts.delete(k);
    return [
        ...alerts.values()
    ].sort((a, b)=>b.at - a.at);
}
}),
"[project]/src/lib/venue-probation.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSingleVenueProbation",
    ()=>getSingleVenueProbation
]);
// ── v12.10 SINGLE-VENUE PROBATION lane (server-only) ────────────────────────
// Operator mandate (AUDIT-20261023 follow-up): «فیلتر و وتوی یک ارز بخاطر
// عملکرد ردیابی اشتباه کار هوشمندانه‌ای نیست و باید ریشه‌ای احیا و کالیبره
// شود».
//
// Doctrine shift: the SINGLE-VENUE hard block stays the DEFAULT for machine
// deploys (cross-venue confirmation is impossible on a single-venue tape —
// the operator's own Binance-ticket mandate), but a coin is NOT banished
// forever. Two rehabilitation paths exist:
//   ① STRUCTURAL — venue expansion: the venue-coverage probe maps which other
//     exchanges list the coin; wiring a second venue lifts vCount to ≥2 and
//     the block converts to the NO-BINANCE-CONFIRM surcharge automatically.
//   ② CALIBRATED — this probation lane: the operator lists a symbol in
//     EngineSetting "single-venue-probation" (JSON {"enabled":bool,"symbols":[...]}).
//     A listed symbol re-enters the machine lane at a HIGHER bar: +8 threshold
//     surcharge, PROBATION tag, every other gate (cascade-freeze / stale-bar /
//     flush-exhaustion / stop-floor) still applies. Reversible and measured —
//     a calibrated re-entry instead of a blind veto.
//
// Cached 15s like gate-settings — never a per-evaluate DB hit.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const KEY = "single-venue-probation";
let cache = null;
const CACHE_TTL = 15_000;
async function getSingleVenueProbation() {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.value;
    const fallback = {
        enabled: false,
        symbols: []
    };
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (!row?.value) {
            cache = {
                at: Date.now(),
                value: fallback
            };
            return fallback;
        }
        const raw = JSON.parse(row.value);
        const value = {
            enabled: raw.enabled === true,
            symbols: Array.isArray(raw.symbols) ? raw.symbols.map((s)=>String(s).toUpperCase()).filter((s)=>s.endsWith("USDT")).slice(0, 50) : []
        };
        cache = {
            at: Date.now(),
            value
        };
        return value;
    } catch  {
        cache = {
            at: Date.now(),
            value: fallback
        };
        return fallback;
    }
}
}),
"[project]/src/lib/feature-scale.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "featureScaleHealth",
    ()=>featureScaleHealth,
    "featureScaleOn",
    ()=>featureScaleOn,
    "loadFeatureStats",
    ()=>loadFeatureStats,
    "noteRescale",
    ()=>noteRescale,
    "rescaleCandidate",
    ()=>rescaleCandidate
]);
// ── NEXUS//SIGNALS — feature-scale gate (server-only) ───────────────────────
// OPERATOR MANDATE 2026-10-21: «هدف حفظ سرمایه نیست، ردیابی جریانات است با
// دقت و سرعت بالا… بجای وتوی کامل، ویژگی‌های منفی را حذف کن و ویژگی‌های مثبت
// را بیشتر تحت نظر داشته باش.»
//
// The old policy BLANKET-VETOED whole strategies/directions on cohort-level
// evidence (BREAKOUT 14.3% WR → veto ALL; SHORT 11.1% WR → veto ALL). That
// throws away every flow signal inside a mixed cohort. The ledger CAN answer
// at feature granularity: every Signal row stores the FactorVote[] at deploy
// (factorsJson, 100% coverage per the 2026-10-21 data audit), and every row
// has a realized outcome (reachedTp / status).
//
// Per (strategy × direction × factor) this module measures:
//   wrBase  — cohort win-rate (win = reachedTp>0; loss = SL with reachedTp=0;
//             EXPIRED-without-TP excluded — no invented outcome)
//   wrConf  — win-rate when the factor CONFIRMED the direction
//   wrOpp   — win-rate when the factor OPPOSED the direction
// and prunes a factor's vote ONLY on measured anti-signal evidence (n≥12):
//   CONFIRM-ANTI  wrConf ≤ wrBase − 6  → its confirming vote predicted LOSSES
//                                        → prune confirm-side vote
//   OPPOSE-NOISE  wrOpp ≥ wrBase − 3  → its opposing vote never predicted
//                                        losses (pure drag) → prune oppose-side
// A candidate dropped ONLY by the score band or a blanket guard gets one
// rescale attempt: pruned votes removed, score recomputed, and it must STILL
// clear the same effective threshold. Everything is journaled via the note
// field — the operator sees exactly which features were removed and why.
// Hard data-integrity gates (feed-fresh, sim-ban, settlement, dislocation,
// kill-switch) are NEVER rescaled — they protect truth, not expectancy.
// Knob: EngineSetting "featureScale" = "1"(on, default) | "0"(off).
// ─────────────────────────────────────────────────────────────────────────────
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const STATS_TTL_MS = 10 * 60_000;
const MIN_N = 12;
const CONFIRM_ANTI_PTS = 6;
const OPPOSE_NOISE_PTS = 3;
const MAX_PRUNED = 2; // bounded surgery — never silently rewrite a whole setup
let statsCache = null;
let statsLoading = null;
let statsLoaded = false;
const health = {
    statsLoaded: false,
    lastStatsAt: 0,
    cohortRows: 0,
    pruneRules: 0,
    rescaleAttempts: 0,
    rescues: 0,
    rescaleFails: 0,
    lastRescaleNote: null
};
function featureScaleHealth() {
    return {
        ...health,
        stats: statsCache?.at ?? 0
    };
}
function noteRescale(kind, note) {
    if (kind === "rescue") {
        health.rescues++;
        health.lastRescaleNote = note;
    } else {
        health.rescaleFails++;
    }
}
async function loadFeatureStats(force = false) {
    if (!force && statsCache && Date.now() - statsCache.at < STATS_TTL_MS) return statsCache.stats;
    if (statsLoading) return statsLoading;
    statsLoading = (async ()=>{
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                qualityFlag: null,
                factorsJson: {
                    not: null
                }
            },
            select: {
                strategy: true,
                direction: true,
                status: true,
                reachedTp: true,
                factorsJson: true
            }
        });
        // cohort baseline: strategy|direction → {settled, wins}
        const base = new Map();
        // factor cohorts: strategy|direction|factor → confirm/oppose outcome tallies
        const agg = new Map();
        for (const r of rows){
            const win = r.reachedTp > 0;
            const loss = r.status === "SL" && r.reachedTp === 0;
            if (!win && !loss) continue; // ACTIVE / EXPIRED-no-TP — outcome not measured
            const bk = `${r.strategy}|${r.direction}`;
            const b = base.get(bk) ?? {
                settled: 0,
                wins: 0
            };
            b.settled++;
            if (win) b.wins++;
            base.set(bk, b);
            let votes = [];
            try {
                votes = JSON.parse(r.factorsJson ?? "[]");
            } catch  {
                continue;
            }
            const dirSign = r.direction === "LONG" ? 1 : -1;
            for (const v of votes){
                if (!v?.factor || typeof v.vote !== "number" || v.vote === 0) continue;
                const key = `${bk}|${v.factor}`;
                const a = agg.get(key) ?? {
                    cS: 0,
                    cW: 0,
                    oS: 0,
                    oW: 0
                };
                if (v.vote * dirSign > 0) {
                    a.cS++;
                    if (win) a.cW++;
                } else {
                    a.oS++;
                    if (win) a.oW++;
                }
                agg.set(key, a);
            }
        }
        const stats = new Map();
        let rules = 0;
        for (const [key, a] of agg){
            const [strategy, direction, factor] = key.split("|");
            const b = base.get(`${strategy}|${direction}`);
            if (!b || b.settled < MIN_N) continue;
            const wrBase = b.wins / b.settled;
            const entry = {
                nConf: a.cS,
                wrConf: a.cS >= MIN_N ? a.cW / a.cS : null,
                nOpp: a.oS,
                wrOpp: a.oS >= MIN_N ? a.oW / a.oS : null,
                wrBase
            };
            stats.set(key, entry);
            void factor;
            if (entry.wrConf !== null && wrBase - entry.wrConf >= CONFIRM_ANTI_PTS / 100 || entry.wrOpp !== null && entry.wrOpp - wrBase >= OPPOSE_NOISE_PTS / 100) rules++;
        }
        statsCache = {
            at: Date.now(),
            stats
        };
        health.statsLoaded = true;
        health.lastStatsAt = Date.now();
        health.cohortRows = rows.length;
        health.pruneRules = rules;
        return stats;
    })();
    try {
        return await statsLoading;
    } finally{
        statsLoading = null;
    }
}
async function featureScaleOn() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "featureScale"
            }
        });
        return (row?.value ?? "1") !== "0";
    } catch  {
        return true; // fail-open to the operator mandate default
    }
}
function rescaleCandidate(votes, strategy, direction, stats) {
    const dirSign = direction === "LONG" ? 1 : -1;
    const pruned = [];
    const watched = [];
    let kept = 0;
    let pruneBudget = MAX_PRUNED;
    for (const v of votes){
        const st = stats.get(`${strategy}|${direction}|${v.factor}`);
        const confirms = v.vote * dirSign > 0;
        if (st && pruneBudget > 0) {
            const confirmAnti = st.wrConf !== null && st.wrBase !== null && st.wrBase - st.wrConf >= CONFIRM_ANTI_PTS / 100;
            const opposeNoise = st.wrOpp !== null && st.wrBase !== null && st.wrOpp - st.wrBase >= OPPOSE_NOISE_PTS / 100;
            if (confirms && confirmAnti || !confirms && opposeNoise) {
                const wrHit = confirms ? st.wrConf : st.wrOpp;
                pruned.push(`${v.factor}(${confirms ? "confirm-anti" : "oppose-noise"}, wrBase ${(st.wrBase * 100).toFixed(0)}% vs ${(wrHit * 100).toFixed(0)}%)`);
                pruneBudget--;
                continue; // vote removed from the pool — measured, journaled, reversible
            }
            if (st.wrConf !== null && st.wrBase !== null && st.wrConf - st.wrBase >= CONFIRM_ANTI_PTS / 100) {
                watched.push(v.factor); // genuinely positive — under closer monitoring
            }
        }
        kept += v.vote;
    }
    return {
        rescore: Math.max(-100, Math.min(100, kept)),
        pruned,
        watched
    };
}
}),
"[project]/src/lib/engine-flags.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "engineFlags",
    ()=>engineFlags
]);
// ── v10.18 PHASED CONSOLIDATION FLAGS (operator option A, 2026-09-24) ──────
// Single flip-point for the three-phase system consolidation ordered by the
// operator after the ARCHITECTURE ADVISORY (ADVISORY-20260924-matrix-radar):
//   radarPrimary     — PUMP/DUMP RADAR is the primary detection source; its
//                      emissions ride the FULL gate stack (no authority bypass)
//                      while the legacy random auto-spawn stays retired.
//   legacyAutoSpawn  — the pre-v10.18 random full-universe spawn loop
//                      (AI-SWING-era candidate factory). false = retired.
//   sensorBusDormant — peripheral sensor bus (smart-money flow matrix, whale
//                      tape, vol-onset radar, vol-cause capture) demoted to
//                      dormant: display + telemetry capture off, components
//                      kept in code. Gate-critical inputs stay live.
// Client-safe: static JSON + no server APIs (the AI CORE dormant strip reads
// the same flags so the UI never contradicts engine behavior).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$engine$2d$flags$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/config/engine-flags.json (json)");
;
let cached = null;
function engineFlags() {
    if (cached) return cached;
    try {
        const f = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$engine$2d$flags$2e$json__$28$json$29$__["default"];
        cached = {
            radarPrimary: f.radarPrimary ?? true,
            legacyAutoSpawn: f.legacyAutoSpawn ?? false,
            sensorBusDormant: f.sensorBusDormant ?? true
        };
    } catch  {
        // The config ships with the repo — fail-open to the operator mandate so a
        // torn read can never silently resurrect the retired legacy paths.
        cached = {
            radarPrimary: true,
            legacyAutoSpawn: false,
            sensorBusDormant: true
        };
    }
    return cached;
}
}),
"[project]/src/lib/risk-overlay.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getRiskState",
    ()=>getRiskState
]);
// ── FlowRadar Neo v8.1 PORTFOLIO RISK OVERLAY (P2, server-only) ──────────
// Operator mandate 2026-09-08: «طبق نظر مهندسی P1 و P2 رو کامل اجرا کن».
// The PORTFOLIO-STRUCTURAL layer: correlated same-direction clusters, one-way
// exposure and drawdown throttle — pure math over the open ledger + the shared
// 15m kline cache (vol-forecast.ts). No new REST surface.
//
// Contract consumed by engine.ts deploy path + /api/risk:
//   getRiskState(symbol?, direction?) →
//     { state: RiskState, candidateJoinsBlocked?: boolean }
//
// Policy (hard-coded per design — not governor knobs):
//   · same-direction correlated cluster ≥35% of equity → BLOCK a candidate
//     joining it (auto path); operator-forced deploys are never refused, the
//     engine half-sizes them with the RISK-CLUSTER tag.
//   · drawdown ≥3% → size ×0.75 · ≥7% → ×0.5 (hard-bounded backstop).
//   · verdict: OK · THROTTLE (sizeMult<1) · BLOCK (standing same-dir cluster ≥35%).
//
// Correlation: Pearson ρ over the last 96 closed 15m returns (aligned series,
// no lookahead). Cluster = union-merge of pairs with |ρ| ≥ 0.65.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$vol$2d$forecast$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/vol-forecast.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accounting.ts [app-route] (ecmascript)");
;
;
;
const CLUSTER_RHO = 0.65; // pairwise ρ for union-merge clustering
const JOIN_RHO = 0.7; // ρ for counting a position into the candidate's cluster
const BLOCK_PCT = 35; // same-direction correlated cluster cap, % of equity
const DD_THROTTLE_PCT = 3; // drawdown that starts throttling
const DD_HEAVY_PCT = 7; // drawdown that halving sizes
// audit fix 2026-09-08: was hardcoded 100 — now imports the canonical seed so a
// future balance reseed can never desync the risk overlay's drawdown baseline
const START_BALANCE = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ACCOUNT_START_USD"];
// ── Pearson ρ over aligned closed-bar returns ──
function pearson(a, b) {
    const n = Math.min(a.length, b.length);
    if (n < 24) return null;
    const x = a.slice(-n);
    const y = b.slice(-n);
    const mx = x.reduce((s, v)=>s + v, 0) / n;
    const my = y.reduce((s, v)=>s + v, 0) / n;
    let sxy = 0;
    let sxx = 0;
    let syy = 0;
    for(let i = 0; i < n; i++){
        const dx = x[i] - mx;
        const dy = y[i] - my;
        sxy += dx * dy;
        sxx += dx * dx;
        syy += dy * dy;
    }
    if (sxx <= 0 || syy <= 0) return null;
    return sxy / Math.sqrt(sxx * syy);
}
// per-process return-series cache (aligned with the k15 cache TTL)
const retsCache = new Map();
async function returns15m(symbol) {
    const hit = retsCache.get(symbol);
    if (hit && Date.now() - hit.at < 120_000) return hit.rets;
    const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$vol$2d$forecast$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getKlines15m"])(symbol);
    if (!candles || candles.length < 30) return null;
    const closed = candles.slice(0, -1);
    const rets = [];
    for(let i = 1; i < closed.length; i++){
        const p0 = closed[i - 1].close;
        const p1 = closed[i].close;
        if (p0 > 0 && p1 > 0) rets.push((p1 - p0) / p0);
    }
    retsCache.set(symbol, {
        at: Date.now(),
        rets
    });
    if (retsCache.size > 64) {
        const oldest = [
            ...retsCache.entries()
        ].sort((a, b)=>a[1].at - b[1].at)[0];
        if (oldest) retsCache.delete(oldest[0]);
    }
    return rets;
}
async function ledgerCurve() {
    const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            pnlPercent: true,
            marginUsd: true,
            closedAt: true
        }
    });
    const open = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "ACTIVE",
                    "TP1",
                    "TP2"
                ]
            }
        },
        select: {
            pnlPercent: true,
            marginUsd: true
        }
    });
    let realized = 0;
    const curve = [
        START_BALANCE
    ];
    const byTime = settled.sort((a, b)=>(a.closedAt?.getTime() ?? 0) - (b.closedAt?.getTime() ?? 0));
    for (const s of byTime){
        realized += s.marginUsd * s.pnlPercent / 100;
        curve.push(START_BALANCE + realized);
    }
    const unrealized = open.reduce((a, s)=>a + s.marginUsd * s.pnlPercent / 100, 0);
    const equity = START_BALANCE + realized + unrealized;
    const peak = Math.max(...curve, equity);
    return {
        equity,
        peak,
        exposureUsd: open.reduce((a, s)=>a + s.marginUsd, 0),
        openCount: open.length
    };
}
function sizeMultFor(drawdownPct) {
    if (drawdownPct >= DD_HEAVY_PCT) return 0.5;
    if (drawdownPct >= DD_THROTTLE_PCT) return 0.75;
    return 1;
}
/** Union-merge clusters over the open book (pairs |ρ| ≥ 0.65). */ async function buildClusters(open, equity) {
    if (open.length < 2) return [];
    const uniqSymbols = [
        ...new Set(open.map((s)=>s.symbol))
    ];
    const dirOf = new Map(open.map((s)=>[
            s.symbol,
            s.direction
        ]));
    const rets = new Map();
    for (const sym of uniqSymbols)rets.set(sym, await returns15m(sym));
    // union-find over symbol indices
    const idx = new Map(uniqSymbols.map((s, i)=>[
            s,
            i
        ]));
    const parent = uniqSymbols.map((_, i)=>i);
    const find = (x)=>parent[x] === x ? x : parent[x] = find(parent[x]);
    const union = (a, b)=>{
        const ra = find(a);
        const rb = find(b);
        if (ra !== rb) parent[rb] = ra;
    };
    const pairRho = new Map();
    for(let i = 0; i < uniqSymbols.length; i++){
        for(let j = i + 1; j < uniqSymbols.length; j++){
            const ra = rets.get(uniqSymbols[i]);
            const rb = rets.get(uniqSymbols[j]);
            if (!ra || !rb) continue;
            const rho = pearson(ra, rb);
            if (rho === null) continue;
            pairRho.set(`${i}|${j}`, rho);
            if (Math.abs(rho) >= CLUSTER_RHO) union(i, j);
        }
    }
    const groups = new Map();
    for (const s of uniqSymbols){
        const root = find(idx.get(s));
        const g = groups.get(root) ?? [];
        g.push(s);
        groups.set(root, g);
    }
    const out = [];
    for (const members of groups.values()){
        if (members.length < 2) continue;
        const rhos = [];
        for(let i = 0; i < members.length; i++){
            for(let j = i + 1; j < members.length; j++){
                const a = idx.get(members[i]);
                const b = idx.get(members[j]);
                const r = pairRho.get(`${a}|${b}`) ?? pairRho.get(`${b}|${a}`);
                if (r !== undefined) rhos.push(Math.abs(r));
            }
        }
        const dirs = members.map((s)=>dirOf.get(s) ?? "");
        const direction = dirs.every((d)=>d === "LONG") ? "LONG" : dirs.every((d)=>d === "SHORT") ? "SHORT" : "MIXED";
        const marginUsd = open.filter((s)=>members.includes(s.symbol)).reduce((a, s)=>a + s.marginUsd, 0);
        out.push({
            symbols: members,
            direction,
            marginUsd: Number(marginUsd.toFixed(2)),
            corr: rhos.length ? Number((rhos.reduce((a, b)=>a + b, 0) / rhos.length).toFixed(2)) : 0,
            equityPct: equity > 0 ? Number((marginUsd / equity * 100).toFixed(1)) : 0
        });
    }
    out.sort((a, b)=>b.equityPct - a.equityPct);
    return out;
}
async function getRiskState(symbol, direction) {
    const open = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "ACTIVE",
                    "TP1",
                    "TP2"
                ]
            }
        },
        select: {
            symbol: true,
            direction: true,
            marginUsd: true
        }
    });
    const { equity, peak, exposureUsd, openCount } = await ledgerCurve();
    const drawdownPct = peak > 0 ? Math.max(0, (peak - equity) / peak * 100) : 0;
    const sizeMult = sizeMultFor(drawdownPct);
    const clusters = await buildClusters(open, equity);
    const sameDirClusters = clusters.filter((c)=>c.direction === "LONG" || c.direction === "SHORT");
    const worstClusterPct = sameDirClusters.length ? Math.max(...sameDirClusters.map((c)=>c.equityPct)) : clusters.length ? Math.max(...clusters.map((c)=>c.equityPct)) : 0;
    const reasons = [];
    for (const c of clusters.slice(0, 3)){
        reasons.push(`correlated cluster ${c.symbols.join("+")} (${c.direction}, ρ̄ ${c.corr.toFixed(2)}) holds ${c.equityPct}% of equity`);
    }
    if (drawdownPct >= DD_THROTTLE_PCT) reasons.push(`drawdown ${drawdownPct.toFixed(1)}% from peak → sizing ×${sizeMult}`);
    let verdict = "OK";
    if (sameDirClusters.some((c)=>c.equityPct >= BLOCK_PCT)) verdict = "BLOCK";
    else if (sizeMult < 1) verdict = "THROTTLE";
    if (reasons.length === 0) reasons.push("book clean — no correlated clusters, drawdown inside bands");
    const state = {
        at: Date.now(),
        equity: Number(equity.toFixed(2)),
        peakEquity: Number(peak.toFixed(2)),
        drawdownPct: Number(drawdownPct.toFixed(1)),
        exposureUsd: Number(exposureUsd.toFixed(2)),
        openCount,
        clusters: clusters.slice(0, 6),
        worstClusterPct: Number(worstClusterPct.toFixed(1)),
        sizeMult,
        verdict,
        reasons
    };
    if (!symbol || !direction) return {
        state
    };
    // candidate join test — same-direction correlated share the candidate adds to
    const candRets = open.length > 0 ? await returns15m(symbol) : null;
    let joinShare = 0;
    if (candRets) {
        for (const pos of open){
            if (pos.symbol === symbol || pos.direction !== direction) continue;
            const posRets = await returns15m(pos.symbol);
            if (!posRets) continue;
            const rho = pearson(candRets, posRets);
            if (rho !== null && Math.abs(rho) >= JOIN_RHO) joinShare += pos.marginUsd;
        }
    }
    const joinPct = equity > 0 ? joinShare / equity * 100 : 0;
    const candidateJoinsBlocked = joinPct >= BLOCK_PCT;
    return {
        state,
        candidateJoinsBlocked
    };
}
}),
"[project]/src/lib/gate-journal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "gateJournalForCore",
    ()=>gateJournalForCore,
    "gateJournalHealth",
    ()=>gateJournalHealth,
    "gateJournalReady",
    ()=>gateJournalReady,
    "gateJournalRefresh",
    ()=>gateJournalRefresh,
    "gateLive",
    ()=>gateLive,
    "gateRecentBlocks",
    ()=>gateRecentBlocks,
    "gateRecentDeploys",
    ()=>gateRecentDeploys,
    "gateStats",
    ()=>gateStats,
    "recordGateBlock",
    ()=>recordGateBlock,
    "recordGateDeploy",
    ()=>recordGateDeploy,
    "recordGateSamples",
    ()=>recordGateSamples
]);
// ── FlowRadar Neo GATE JOURNAL + GAUGE ENGINE (server-only, v8.2) ──
// Operator mandate (2026-09-08): «یک موتور گیج اضافه کن تا بصورت زنده داده
// هایی که به مرز تایید یا رد شدن سیگنال میرسند را نشان دهد و جورنال را به
// هسته مرکزی برای یادگیری عمیق از دلایل ارسال کند».
//
// Every deploy-signal() threshold verdict is journaled here with its FULL
// reason payload: the signed confluence votes (confirm vs oppose), every
// threshold modifier (regime / BTC-spill / chase / MTF-board / liq-heat),
// the effective threshold it faced, and the distance-to-gate. Hard gate
// blocks (memory/strategy/learned/flow/onset-retest/risk-cluster) and
// actual deployments are recorded too — so the boundary band between
// CONFIRM and REJECT becomes a measurable, learnable dataset instead of
// a one-line 409 error.
//
// Storage: in-memory rings (fast, capped) + append-only JSONL
// (.data/gate-journal.jsonl) so history survives dev recompiles and
// restarts, and the central AI core can be fed the exact same records.
// No SQLite writes — the single-writer discipline stays untouched.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
;
;
// ── storage ───────────────────────────────────────────────────
const SAMPLE_CAP = 8000;
const BLOCK_CAP = 800;
const DEPLOY_CAP = 300;
const BOUNDARY_DEDUP_MS = 60_000; // per symbol|direction — boundary state persists tick after tick
const REJECT_DEDUP_MS = 150_000;
const PASS_DEDUP_MS = 60_000; // PASS verdicts change slowly too — keep the ring dense with boundary data
const BLOCK_DEDUP_MS = 120_000;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "gate-journal.jsonl");
const FILE_MAX_BYTES = 8 * 1024 * 1024;
const samples = [];
const blocks = [];
const deploys = [];
const lastAccepted = new Map();
let persisted = 0;
let hydrating = null;
// v8.2.1 SPLIT-BRAIN COUNTERMEASURE — Turbopack dev compiles one module
// instance PER ROUTE: the engine tick's instance writes the JSONL while a
// freshly-compiled read route starts with EMPTY rings and (before this fix)
// never hydrated, because hydration was only triggered from write paths.
// readPos tracks how many bytes of the JSONL this instance has already
// ingested, so reads can TAIL the file incrementally no matter which
// instance is doing the writing (including our own — persist() advances
// readPos so records we wrote ourselves are never re-ingested).
let readPos = 0;
let hydratedAt = 0; // epoch ms of the last successful hydrate/refresh — 0 = cold rings
let refreshing = null;
let lastRefreshAt = 0;
const REFRESH_MIN_INTERVAL_MS = 10_000;
const REFRESH_MAX_BITE = 512 * 1024; // bounded bite per refresh
const seenSerials = new Set(); // deploy serials ingested (hydrate + refresh) — cross-instance deploy dedupe
async function hydrate() {
    if (hydrating) return hydrating;
    hydrating = (async ()=>{
        try {
            const buf = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(FILE, "utf8").catch(()=>"");
            if (!buf) return;
            const lines = buf.split("\n").filter(Boolean);
            const tail = lines.slice(-6000); // bounded restore
            for (const line of tail){
                try {
                    const rec = JSON.parse(line);
                    if (rec.k === "s" && samples.length < SAMPLE_CAP) samples.push(rec.v);
                    else if (rec.k === "b" && blocks.length < BLOCK_CAP) blocks.push(rec.v);
                    else if (rec.k === "d" && deploys.length < DEPLOY_CAP) deploys.push(rec.v);
                } catch  {
                /* skip torn line */ }
            }
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            persisted = st?.size ?? 0;
            // the whole file has been consumed (tail kept) — mark the read position
            readPos = st?.size ?? 0;
            hydratedAt = Date.now();
            // prime the dedup map from the hydrated history so a freshly-compiled
            // instance does not instantly re-accept everything another instance
            // journaled seconds ago (dedup continuity across instance swaps)
            for (const s of samples){
                const key = `${s.symbol}|${s.direction}|${s.band}`;
                const prev = lastAccepted.get(key) ?? 0;
                if (s.at > prev) lastAccepted.set(key, s.at);
            }
            for (const b of blocks){
                const key = `${b.gate}|${b.symbol ?? "*"}`;
                const prev = lastAccepted.get(key) ?? 0;
                if (b.at > prev) lastAccepted.set(key, b.at);
            }
            for (const d of deploys)if (d.serial > 0) seenSerials.add(d.serial);
            if ((st?.size ?? 0) > FILE_MAX_BYTES) {
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
                persisted = 0; // (was a stale-size bug: rotation must reset the counter)
                readPos = 0;
            }
        } catch  {
        /* fresh start — journaling must never break the engine */ }
    })();
    return hydrating;
}
async function persist(rec) {
    try {
        const line = JSON.stringify(rec) + "\n";
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(FILE, line, "utf8");
        persisted += line.length;
        readPos += line.length; // our own bytes are already in the rings — never re-ingest
        if (persisted > FILE_MAX_BYTES) {
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
            persisted = 0;
            readPos = 0;
        }
    } catch  {
    /* non-fatal */ }
}
async function gateJournalReady() {
    await hydrate();
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
            recursive: true
        });
    } catch  {
    /* exists */ }
}
async function gateJournalRefresh(maxAgeMs = REFRESH_MIN_INTERVAL_MS) {
    if (Date.now() - lastRefreshAt < maxAgeMs) return;
    if (refreshing) return refreshing;
    refreshing = (async ()=>{
        try {
            // VERDICT-CORE audit 2026-11-05 — COLD-GENERATION READ FIX: hydrate() only
            // ran on WRITE paths, so a freshly-compiled read generation started with
            // readPos=0 and tailed the file's OLDEST bytes (11-03 history) — 12h-window
            // stats came back EMPTY and the core wrote "journal is empty" (observed live
            // on cycle #1412's first POST). Hydrate cold generations here (once, single-
            // flight, readPos=file-size) so the first refresh already sees the freshest
            // 6000-line history. Warm generations (hydratedAt>0) are untouched — re-running
            // hydrate on them would re-push tail records into the rings.
            if (hydratedAt === 0) await hydrate();
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            if (!st) return;
            if (st.size < readPos) readPos = 0; // rotated — restart the tail on the fresh file
            if (st.size === readPos) return;
            const len = Math.min(st.size - readPos, REFRESH_MAX_BITE);
            const fh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(FILE, "r").catch(()=>null);
            if (!fh) return;
            try {
                const buf = Buffer.alloc(len);
                const { bytesRead } = await fh.read(buf, 0, len, readPos);
                let text = buf.toString("utf8", 0, bytesRead);
                const lastNl = text.lastIndexOf("\n");
                if (lastNl === -1) return; // partial line at the tail — wait for the writer
                text = text.slice(0, lastNl + 1); // only consume COMPLETE lines
                readPos += Buffer.byteLength(text, "utf8");
                for (const line of text.split("\n")){
                    if (!line) continue;
                    try {
                        const rec = JSON.parse(line);
                        if (rec.k === "s") {
                            const s = rec.v;
                            // v8.2.1 ingest discipline — a SECOND module instance may write the
                            // same verdict; apply the exact same dedup rule as recordGateSamples
                            // so rings/stats stay honest no matter the writer
                            const key = `${s.symbol}|${s.direction}|${s.band}`;
                            const interval = s.band === "BOUNDARY" ? BOUNDARY_DEDUP_MS : s.band === "REJECT" ? REJECT_DEDUP_MS : PASS_DEDUP_MS;
                            const last = lastAccepted.get(key) ?? 0;
                            if (interval && s.at - last < interval) continue;
                            lastAccepted.set(key, s.at);
                            samples.push(s);
                            if (samples.length > SAMPLE_CAP) samples.splice(0, samples.length - SAMPLE_CAP);
                        } else if (rec.k === "b") {
                            const b = rec.v;
                            const key = `${b.gate}|${b.symbol ?? "*"}`;
                            if (b.at - (lastAccepted.get(key) ?? 0) < BLOCK_DEDUP_MS) continue;
                            lastAccepted.set(key, b.at);
                            blocks.push(b);
                            if (blocks.length > BLOCK_CAP) blocks.splice(0, blocks.length - BLOCK_CAP);
                        } else if (rec.k === "d") {
                            const d = rec.v;
                            if (d.serial > 0 && seenSerials.has(d.serial)) continue; // duplicate deploy from another instance
                            if (d.serial > 0) seenSerials.add(d.serial);
                            deploys.push(d);
                            if (deploys.length > DEPLOY_CAP) deploys.splice(0, deploys.length - DEPLOY_CAP);
                        }
                    } catch  {
                    /* torn line */ }
                }
                hydratedAt = Date.now();
            } finally{
                await fh.close().catch(()=>undefined);
            }
        } catch  {
        /* non-fatal — reads must never break */ } finally{
            lastRefreshAt = Date.now();
        }
    })().finally(()=>{
        refreshing = null;
    });
    return refreshing;
}
// ── recording ─────────────────────────────────────────────────
function bandOf(gap, passed) {
    if (passed) return "PASS";
    return gap >= -8 ? "BOUNDARY" : "REJECT";
}
async function recordGateSamples(batch) {
    if (batch.length === 0) return;
    await hydrate();
    const now = Date.now();
    let bestGap = Infinity;
    let bestIdx = -1;
    const enriched = batch.map((b, i)=>{
        const gap = Math.abs(b.score) - b.effMin;
        if (Math.abs(gap) < bestGap) {
            bestGap = Math.abs(gap);
            bestIdx = i;
        }
        return {
            ...b,
            at: now,
            gap,
            band: bandOf(gap, b.passed)
        };
    });
    for(let i = 0; i < enriched.length; i++){
        const s = enriched[i];
        const key = `${s.symbol}|${s.direction}|${s.band}`;
        const interval = s.band === "BOUNDARY" ? BOUNDARY_DEDUP_MS : s.band === "REJECT" ? REJECT_DEDUP_MS : PASS_DEDUP_MS;
        const last = lastAccepted.get(key) ?? 0;
        if (interval && now - last < interval) continue;
        lastAccepted.set(key, now);
        const rec = {
            at: s.at,
            symbol: s.symbol,
            direction: s.direction,
            strategy: s.strategy,
            score: s.score,
            effMin: s.effMin,
            baseMin: s.baseMin,
            gap: s.gap,
            band: s.band,
            thr: s.thr,
            confirms: s.confirms,
            opposes: s.opposes,
            notes: s.notes,
            source: s.source,
            best: i === bestIdx
        };
        samples.push(rec);
        if (samples.length > SAMPLE_CAP) samples.splice(0, samples.length - SAMPLE_CAP);
        void persist({
            k: "s",
            v: rec
        });
    }
}
async function recordGateBlock(b) {
    await hydrate();
    const now = Date.now();
    const key = `${b.gate}|${b.symbol ?? "*"}`;
    if (now - (lastAccepted.get(key) ?? 0) < BLOCK_DEDUP_MS) return;
    lastAccepted.set(key, now);
    const rec = {
        ...b,
        at: now
    };
    blocks.push(rec);
    if (blocks.length > BLOCK_CAP) blocks.splice(0, blocks.length - BLOCK_CAP);
    void persist({
        k: "b",
        v: rec
    });
}
async function recordGateDeploy(d) {
    await hydrate();
    const rec = {
        ...d,
        at: Date.now()
    };
    deploys.push(rec);
    if (deploys.length > DEPLOY_CAP) deploys.splice(0, deploys.length - DEPLOY_CAP);
    void persist({
        k: "d",
        v: rec
    });
}
function gateLive(limit = 16) {
    const latest = new Map();
    for (const s of samples)latest.set(`${s.symbol}|${s.direction}`, s); // rings are append-ordered
    const rank = (b)=>b === "BOUNDARY" ? 0 : b === "PASS" ? 1 : 2;
    return [
        ...latest.values()
    ].sort((a, b)=>rank(a.band) - rank(b.band) || Math.abs(a.gap) - Math.abs(b.gap)).slice(0, limit);
}
function gateStats(windowHours = 6) {
    const since = Date.now() - windowHours * 3600_000;
    const win = samples.filter((s)=>s.at >= since);
    const byBand = {
        PASS: 0,
        BOUNDARY: 0,
        REJECT: 0
    };
    for (const s of win)byBand[s.band]++;
    const agg = (list, pick)=>{
        const m = new Map();
        for (const s of list)for (const f of pick(s)){
            const e = m.get(f.factor) ?? {
                n: 0,
                sum: 0,
                last: null
            };
            e.n++;
            e.sum += f.vote;
            if (f.detail) e.last = f.detail;
            m.set(f.factor, e);
        }
        return m;
    };
    const toAgg = (m)=>[
            ...m.entries()
        ].map(([factor, e])=>({
                factor,
                count: e.n,
                avgVote: Number((e.sum / e.n).toFixed(2)),
                lastDetail: e.last
            })).sort((a, b)=>b.count - a.count);
    const confirmAgg = toAgg(agg(win, (s)=>s.confirms));
    const opposeAgg = toAgg(agg(win, (s)=>s.opposes));
    const thrNames = [
        "regime",
        "spill",
        "chase",
        "mtf",
        "liq",
        "lesson"
    ];
    const thrModifiers = thrNames.map((name)=>{
        const vals = win.map((s)=>s.thr[name]).filter((v)=>v !== undefined && v !== 0);
        return {
            name,
            count: vals.length,
            avg: vals.length ? Number((vals.reduce((a, b)=>a + b, 0) / vals.length).toFixed(2)) : 0
        };
    }).filter((t)=>t.count > 0);
    const blockMap = new Map();
    for (const b of blocks){
        if (b.at < since) continue;
        const e = blockMap.get(b.gate) ?? {
            count: 0,
            lastReason: b.reason
        };
        e.count++;
        e.lastReason = b.reason;
        blockMap.set(b.gate, e);
    }
    const deploysWin = deploys.filter((d)=>d.at >= since);
    const boundaryN = byBand.BOUNDARY;
    return {
        windowHours,
        samples: win.length,
        byBand,
        boundary: boundaryN > 0 ? {
            avgGap: Number((win.filter((s)=>s.band === "BOUNDARY").reduce((a, s)=>a + s.gap, 0) / boundaryN).toFixed(2)),
            worstGap: Math.max(...win.filter((s)=>s.band === "BOUNDARY").map((s)=>s.gap)),
            sharePct: Number((boundaryN / Math.max(1, win.length) * 100).toFixed(1))
        } : null,
        confirmReasons: confirmAgg.slice(0, 6),
        opposeReasons: opposeAgg.slice(0, 6),
        thrModifiers,
        blocks: [
            ...blockMap.entries()
        ].map(([gate, e])=>({
                gate,
                count: e.count,
                lastReason: e.lastReason
            })).sort((a, b)=>b.count - a.count),
        deploys: deploysWin.length,
        avgDeployScore: deploysWin.length ? Number((deploysWin.reduce((a, d)=>a + Math.abs(d.score), 0) / deploysWin.length).toFixed(1)) : null,
        blocksRingSize: blocks.length,
        blocksRingSaturated: blocks.length >= BLOCK_CAP
    };
}
function gateRecentBlocks(limit = 8) {
    return blocks.slice(-limit).reverse();
}
function gateRecentDeploys(limit = 6) {
    return deploys.slice(-limit).reverse();
}
function gateJournalHealth() {
    return {
        samples: samples.length,
        blocks: blocks.length,
        deploys: deploys.length,
        fileKB: Math.round(persisted / 1024),
        hydratedAt
    };
}
async function gateJournalForCore(windowHours = 12, maxBoundary = 8) {
    await gateJournalReady(); // hydrate cold generations BEFORE tailing (audit 2026-11-05: read-path emptiness fix)
    await gateJournalRefresh(0); // grounding consumers always see fresh rings
    const stats = gateStats(windowHours);
    const nearGate = samples.filter((s)=>s.at >= Date.now() - windowHours * 3600_000 && s.band === "BOUNDARY").sort((a, b)=>b.at - a.at).slice(0, maxBoundary);
    const boundaryFiles = nearGate.map((s)=>{
        const conf = s.confirms.map((f)=>`${f.factor}${f.vote >= 0 ? "+" : ""}${f.vote}`).join(",") || "n/a";
        const opp = s.opposes.map((f)=>`${f.factor}${f.vote >= 0 ? "+" : ""}${f.vote}`).join(",") || "n/a";
        const thr = Object.entries(s.thr).filter(([, v])=>v !== 0).map(([k, v])=>`${k}${v > 0 ? "+" : ""}${v}`).join(" ") || "none";
        return `${new Date(s.at).toISOString()} ${s.symbol} ${s.direction} ${s.strategy} score ${s.score.toFixed(1)} vs eff ${s.effMin} (gap ${s.gap >= 0 ? "+" : ""}${s.gap.toFixed(1)}) · thr mods: ${thr} · confirms: ${conf} · opposes: ${opp}`;
    });
    const blockFiles = gateRecentBlocks(6).map((b)=>`${new Date(b.at).toISOString()} ${b.gate}${b.symbol ? ` ${b.symbol}` : ""} — ${b.reason.slice(0, 140)}`);
    const topConfirm = stats.confirmReasons[0];
    const topOppose = stats.opposeReasons[0];
    const narrative = [
        `${stats.samples} threshold verdicts in ${windowHours}h: ${stats.byBand.PASS} passed, ${stats.byBand.BOUNDARY} landed in the boundary band (gap −8..0, ${stats.boundary?.sharePct ?? 0}% of evaluations, avg gap ${stats.boundary?.avgGap ?? "n/a"}), ${stats.byBand.REJECT} rejected outright.`,
        `Dominant confirm factor: ${topConfirm ? `${topConfirm.factor} (×${topConfirm.count}, avg ${topConfirm.avgVote})` : "n/a"}. Dominant oppose factor: ${topOppose ? `${topOppose.factor} (×${topOppose.count}, avg ${topOppose.avgVote})` : "n/a"}.`,
        `Threshold modifiers live: ${stats.thrModifiers.map((t)=>`${t.name}×${t.count} avg ${t.avg >= 0 ? "+" : ""}${t.avg}`).join(" · ") || "none"}.`,
        `Hard blocks: ${stats.blocks.map((b)=>`${b.gate}×${b.count}`).join(" · ") || "none"}.${stats.blocksRingSaturated ? ` [BLOCK-RING SATURATED at ${stats.blocksRingSize} — these counts are the newest ~${stats.blocksRingSize} accepted records only (≈60-90min of churn), NOT the full ${windowHours}h census; single-key gates (MEMORY) are dedup-compressed while multi-symbol gates (REGIME) fan out — treat as recent-churn snapshot]` : ""} Deployed: ${stats.deploys}${stats.avgDeployScore !== null ? ` (avg |score| ${stats.avgDeployScore})` : ""}.`
    ].join(" ");
    return {
        narrative,
        stats,
        boundaryFiles,
        blockFiles,
        boundarySamples: nearGate
    };
}
}),
"[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fourpackNarrative",
    ()=>fourpackNarrative,
    "fourpackRefresh",
    ()=>fourpackRefresh,
    "getFourPackDoc",
    ()=>getFourPackDoc,
    "getFourPackTail",
    ()=>getFourPackTail,
    "recordFourPack",
    ()=>recordFourPack
]);
// ── FlowRadar Neo v10.8 — FOUR-PACK GOVERNANCE JOURNAL (server-only) ────────
// Operator mandate (2026-09-15/16): the GOVERNOR MODULES FOUR-PACK (R1
// RISK-GOVERNOR · R2 TIME-GOVERNOR · R5 UI-CANARY · R6 SENIOR-REVIEW) keeps
// its verdicts as small in-memory rings buried inside each module's own
// EngineSetting blob. This module gives the pack ONE retrievable, auditable
// JSON journal doctrine — the same discipline the gate-journal (v8.2) and
// sv-telemetry (v10.2) already follow:
//   · append-only JSONL  .data/fourpack-journal.jsonl  (6MB rotate → .old)
//   · atomic latest-file .data/fourpack-latest.json    (tmp→rename)
//   · in-memory ring (fast reads) + tail-ingest hydration so Turbopack's
//     per-route module split-brain never shows a stale journal.
// Supervision verdict (delivered to operator): the four modules are
// deterministic, shadow-first, clamped and audited — they do NOT need a new
// autonomous agent/central-intelligence control loop on top. What they needed
// is THIS: a machine-readable doctrine file the central AI core (verdict-core
// / tp3-lab grounding) and the operator (download) can both study.
//
// Dependency-free (node:fs only) — the module writers call recordFourPack();
// read routes call fourpackRefresh() then getFourPackTail()/getFourPackDoc().
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
;
;
const RING_CAP = 600;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "fourpack-journal.jsonl");
const FILE_MAX_BYTES = 6 * 1024 * 1024;
const LATEST = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "fourpack-latest.json");
const ring = [];
let persisted = 0;
let readPos = 0;
let hydratedAt = 0;
let hydrating = null;
let refreshing = null;
let lastRefreshAt = 0;
const REFRESH_MIN_INTERVAL_MS = 10_000;
const REFRESH_MAX_BITE = 256 * 1024;
const MODULES = [
    "r1-risk-governor",
    "r2-time-governor",
    "r5-ui-canary",
    "r6-senior-review",
    "ops-supervisor",
    "mode"
];
async function hydrate() {
    if (hydrating) return hydrating;
    hydrating = (async ()=>{
        try {
            const buf = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(FILE, "utf8").catch(()=>"");
            if (buf) {
                const lines = buf.split("\n").filter(Boolean);
                for (const line of lines.slice(-RING_CAP)){
                    try {
                        const rec = JSON.parse(line);
                        if (rec?.v?.at && ring.length < RING_CAP) ring.push(rec.v);
                    } catch  {
                    /* torn line */ }
                }
            }
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            persisted = st?.size ?? 0;
            readPos = st?.size ?? 0;
            hydratedAt = Date.now();
            if ((st?.size ?? 0) > FILE_MAX_BYTES) {
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
                persisted = 0;
                readPos = 0;
            }
        } catch  {
        /* fresh start — journaling must never break the engine */ }
    })();
    return hydrating;
}
async function fourpackRefresh(maxAgeMs = REFRESH_MIN_INTERVAL_MS) {
    await hydrate();
    if (Date.now() - lastRefreshAt < maxAgeMs) return;
    if (refreshing) return refreshing;
    refreshing = (async ()=>{
        try {
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            if (!st) return;
            if (st.size < readPos) readPos = 0; // rotated
            if (st.size === readPos) return;
            const len = Math.min(st.size - readPos, REFRESH_MAX_BITE);
            const fh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(FILE, "r").catch(()=>null);
            if (!fh) return;
            try {
                const buf = Buffer.alloc(len);
                const { bytesRead } = await fh.read(buf, 0, len, readPos);
                let text = buf.toString("utf8", 0, bytesRead);
                const lastNl = text.lastIndexOf("\n");
                if (lastNl === -1) return;
                text = text.slice(0, lastNl + 1);
                readPos += Buffer.byteLength(text, "utf8");
                for (const line of text.split("\n")){
                    if (!line) continue;
                    try {
                        const rec = JSON.parse(line);
                        if (rec?.v?.at) {
                            ring.push(rec.v);
                            if (ring.length > RING_CAP) ring.splice(0, ring.length - RING_CAP);
                        }
                    } catch  {
                    /* torn line */ }
                }
                hydratedAt = Date.now();
            } finally{
                await fh.close().catch(()=>undefined);
            }
        } catch  {
        /* non-fatal */ } finally{
            lastRefreshAt = Date.now();
        }
    })().finally(()=>{
        refreshing = null;
    });
    return refreshing;
}
function health() {
    const counts = {};
    const lastAt = {};
    for (const m of MODULES){
        counts[m] = 0;
        lastAt[m] = 0;
    }
    for (const e of ring){
        counts[e.module] = (counts[e.module] ?? 0) + 1;
        if (e.at > (lastAt[e.module] ?? 0)) lastAt[e.module] = e.at;
    }
    return {
        counts,
        lastAt,
        fileBytes: persisted,
        rotated: false
    };
}
async function writeLatest() {
    try {
        const last = {};
        for (const m of MODULES){
            const evs = ring.filter((e)=>e.module === m);
            last[m] = evs.length ? evs[evs.length - 1] : null;
        }
        const doc = {
            schemaVersion: 1,
            at: Date.now(),
            health: health(),
            last
        };
        const tmp = `${LATEST}.tmp`;
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["writeFile"])(tmp, JSON.stringify(doc), "utf8");
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(tmp, LATEST).catch(async ()=>{
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(LATEST, "").catch(()=>undefined);
        });
    } catch  {
    /* non-fatal */ }
}
async function recordFourPack(module, kind, line, data, verdict) {
    try {
        await hydrate();
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
            recursive: true
        }).catch(()=>undefined);
        const ev = {
            at: Date.now(),
            module,
            kind,
            verdict: verdict ?? null,
            line: line.slice(0, 400),
            data
        };
        ring.push(ev);
        if (ring.length > RING_CAP) ring.splice(0, ring.length - RING_CAP);
        const rec = JSON.stringify({
            k: module,
            v: ev
        }) + "\n";
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(FILE, rec, "utf8");
        persisted += rec.length;
        readPos += rec.length; // our own bytes — never re-ingest
        if (persisted > FILE_MAX_BYTES) {
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
            persisted = 0;
            readPos = 0;
        }
        void writeLatest();
    } catch  {
    /* journaling must never break a governor cycle */ }
}
async function getFourPackTail(limit = 60) {
    await fourpackRefresh();
    return ring.slice(-limit).reverse();
}
async function getFourPackDoc(limit = 500) {
    await fourpackRefresh();
    return {
        schemaVersion: 1,
        generatedAt: new Date().toISOString(),
        health: health(),
        events: ring.slice(-limit).reverse()
    };
}
async function fourpackNarrative() {
    await fourpackRefresh();
    if (!ring.length) return "FOUR-PACK: journal empty — governor modules have not cycled yet this boot.";
    const parts = [];
    for (const m of [
        "r1-risk-governor",
        "r2-time-governor",
        "r5-ui-canary",
        "r6-senior-review"
    ]){
        const last = [
            ...ring
        ].reverse().find((e)=>e.module === m);
        if (last) {
            const ago = Math.round((Date.now() - last.at) / 60_000);
            parts.push(`${m}:${last.kind}${last.verdict ? `=${last.verdict}` : ""} (${ago}m ago) ${last.line}`);
        } else {
            parts.push(`${m}: no journal event yet`);
        }
    }
    return `FOUR-PACK JOURNAL (${ring.length} events): ${parts.join(" | ")}`;
}
}),
"[project]/src/lib/verdict.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVerdictCoreState",
    ()=>getVerdictCoreState,
    "maybeAutoVerdictLearn",
    ()=>maybeAutoVerdictLearn,
    "runVerdictLearn",
    ()=>runVerdictLearn
]);
// ── FlowRadar Neo v8.2 VERDICT-CORE (server-only) ──
// Operator mandate 2026-09-08: «...و جورنال را به هسته مرکزی برای یادگیری
// عمیق از دلایل ارسال کند، از این طریق هم موتور و هم من میتوانیم دقیقا کدام
// دلایل رد و تایید بر چه اساس است و وضعیت را بررسی کنیم.»
//
// Division of labour (converged with the parallel review loop):
//   · lib/gate-journal.ts — the CAPTURE surface: every threshold verdict,
//     hard gate block and deployment journaled (memory rings + JSONL).
//   · THIS module — the LEARNING surface: the central AI core cadence that
//     studies the journal (gateJournalForCore + shadowVetoForCore grounding),
//     derives grounded findings via the LLM research desk (aiVerdictLearn),
//     and persists the state consumed by /api/gauge (GateGaugeDTO.core) and
//     the analyst grounding. Honesty contract: only measured numbers enter
//     the bundle; since SHADOW-VETO Phase 0 (2026-09-09) the fence is
//     outcome-tracked — real linkage for hair-thin passes, clearly-labeled
//     PAPER outcomes for fence rejects.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-journal.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sv-telemetry.ts [app-route] (ecmascript)"); // v10.2 — the core studies its own feed wiring
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — the core studies the GOVERNOR FOUR-PACK journal
;
;
;
;
;
// ── DETERMINISTIC LESSON VERIFIER (VERDICT-CORE audit 2026-11-05, operator mandate)
// The LLM lesson-writer was caught twice in cycle #1410: a fabricated quantifier
// ("8/8 PUMPUSDT" — actual 1/8) and a category error (symbols called strategies).
// Contract: every numeric claim a lesson makes is re-checked against the SAME
// measured rows the model studied; failures are ANNOTATED (never silently
// rewritten) and confidence is capped (مصوبه (ج)). Fail-open — verification
// must never break the learning cycle.
const VERIFIER_SYMBOL_RE = /\b([A-Z0-9]{3,12}USDT)\b/g;
// "8/8 PUMPUSDT" AND the compressed form "8/8 boundary rejects (ZECUSDT, PUMPUSDT)"
// (cycle #1411 showed the model bridges the quantifier to the symbol with prose)
const VERIFIER_QUANT_RE = /(\d{1,3})\s*\/\s*(\d{1,3})(?:[^\n]{0,40}?)([A-Z0-9]{3,12}USDT)/g;
// census forms: "703 REGIME" (cycle #1410) AND "REGIME violations (684/800)" (cycle #1411)
const VERIFIER_BLOCK_RE = /(\d{2,7})\s+(REGIME|MEMORY|STRATEGY|LEARNED|FLOW|DECISIVE|ONSET-RETEST|RISK-CLUSTER)\b/g;
const VERIFIER_BLOCK_FRAC_RE = /\b(REGIME|MEMORY|STRATEGY|LEARNED|FLOW|DECISIVE|ONSET-RETEST|RISK-CLUSTER)\b[^.\n]{0,30}?(\d{2,7})\s*\/\s*\d{2,7}/g;
function verifyLessonFinding(finding, ctx) {
    try {
        const text = `${finding.pattern} ${finding.evidence ?? ""}`;
        const notes = [];
        let corrected = false;
        // ① quantifier check — "N/M SYMBOL" vs the boundary files actually studied
        for (const m of text.matchAll(new RegExp(VERIFIER_QUANT_RE.source, "g"))){
            const sym = m[3];
            const claimed = Number(m[1]);
            const actual = ctx.boundarySamples.filter((s)=>s.symbol === sym).length;
            if (actual < claimed) {
                corrected = true;
                notes.push(`QUANTIFIER-MISMATCH ${sym}: claimed ${m[1]}/${m[2]}, the boundary files studied contain ${actual}`);
            }
        }
        // ② hard-block census check — block counts vs a saturated ring snapshot
        //    (both word orders: "703 REGIME" and "REGIME violations (684/800)")
        const censusA = [
            ...text.matchAll(new RegExp(VERIFIER_BLOCK_RE.source, "g"))
        ].filter((m)=>Number(m[1]) >= 50).map((m)=>m[2]);
        const censusB = [
            ...text.matchAll(new RegExp(VERIFIER_BLOCK_FRAC_RE.source, "g"))
        ].filter((m)=>Number(m[2]) >= 50).map((m)=>m[1]);
        const citesBlockCensus = censusA.length > 0 || censusB.length > 0; // only census-scale numbers, not "1/7 flagged"
        if (citesBlockCensus && ctx.stats.blocksRingSaturated) {
            corrected = true;
            const gates = [
                ...new Set([
                    ...censusA,
                    ...censusB
                ])
            ].join(", ");
            notes.push(`RING-SNAPSHOT ${gates ? `(${gates}) ` : ""}block counts here are the newest ~${ctx.stats.blocksRingSize ?? 800} accepted records (≈60-90min churn), not the ${ctx.stats.windowHours}h census`);
        }
        // symbol-presence sanity: a lesson naming a symbol absent from the studied rows
        for (const m of text.matchAll(new RegExp(VERIFIER_SYMBOL_RE.source, "g"))){
            const sym = m[1];
            const inBoundary = ctx.boundarySamples.some((s)=>s.symbol === sym);
            const inBlocks = ctx.stats.blocks.some((b)=>(b.gate === "REGIME" || b.gate === "MEMORY") && b.count > 0); // weak proxy — block lastReason not per-symbol here
            if (!inBoundary && !inBlocks && ctx.boundarySamples.length > 0) {
                corrected = true;
                notes.push(`SYMBOL-UNVERIFIED ${sym}: not present in the boundary files studied this cycle`);
                break; // one flag per finding is enough
            }
        }
        let confidence = Math.round(finding.confidence);
        if (corrected) {
            confidence = Math.min(confidence, 70); // (ج) cap for corrected lessons
        } else if (new RegExp(VERIFIER_QUANT_RE.source).test(text) || [
            ...text.matchAll(new RegExp(VERIFIER_BLOCK_RE.source, "g"))
        ].some((m)=>Number(m[1]) >= 50) || [
            ...text.matchAll(new RegExp(VERIFIER_BLOCK_FRAC_RE.source, "g"))
        ].some((m)=>Number(m[2]) >= 50)) {
            confidence = Math.min(confidence, 90); // (ج) cap for verified numeric lessons
        }
        const evidence = notes.length ? `${finding.evidence ?? finding.pattern} [VERIFIER: ${notes.join("; ")}]` : finding.evidence;
        return {
            evidence,
            confidence,
            corrected
        };
    } catch  {
        // fail-open — never break the cycle on verifier bugs
        return {
            evidence: finding.evidence,
            confidence: Math.round(finding.confidence),
            corrected: false
        };
    }
}
const STATE_KEY = "verdictcore.state";
const LAST_RUN_KEY = "verdictcore.lastRun";
const AUTO_INTERVAL_MS = 30 * 60_000;
const MIN_SAMPLES = 5; // below this the journal is too thin for a cycle
const LESSON_CAP = 6;
const EMPTY_STATE = {
    runs: 0,
    lastRunAt: null,
    lastAnswer: null,
    lessons: []
};
async function getVerdictCoreState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: STATE_KEY
            }
        });
        if (!row) return EMPTY_STATE;
        const parsed = JSON.parse(row.value);
        return {
            runs: Number(parsed.runs) || 0,
            lastRunAt: parsed.lastRunAt ?? null,
            lastAnswer: parsed.lastAnswer ?? null,
            lessons: Array.isArray(parsed.lessons) ? parsed.lessons.slice(0, LESSON_CAP) : []
        };
    } catch  {
        return EMPTY_STATE;
    }
}
async function saveState(state) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: STATE_KEY
        },
        create: {
            key: STATE_KEY,
            value: JSON.stringify(state)
        },
        update: {
            value: JSON.stringify(state)
        }
    });
}
async function runVerdictLearn(windowHours = 12) {
    const journal = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateJournalForCore"])(windowHours, 10);
    const stats = journal.stats;
    if (stats.samples === 0) {
        const prev = await getVerdictCoreState();
        const state = {
            ...prev,
            lastAnswer: `Gate journal is empty for the last ${windowHours}h — no threshold verdicts to study yet. The gauge accrues rows automatically (real deploy evaluations + the shadow sweep).`
        };
        await saveState(state);
        return state;
    }
    // The grounding bundle — ONLY measured numbers (gate-journal guarantees it)
    // v8.2 SHADOW-VETO Phase 0: the fence is now OUTCOME-TRACKED (real linkage
    // for hair-thin passes, honest paper ledger for fence rejects) — the doctrine
    // line and the arms bundle below replace the old OBSERVING-only contract.
    const shadow = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["shadowVetoForCore"])(6).catch(()=>({
            narrative: "SHADOW-VETO: unavailable this cycle.",
            verdictFiles: []
        }));
    // v10.2 SV-TELEMETRY — arm feed wiring narrative (best-effort, never blocks)
    const svTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["svTelemetryNarrative"])().catch(()=>"SV-TELEMETRY: unavailable this cycle.");
    // v10.8 FOUR-PACK journal — governance module verdicts (R1 risk / R2 time / R5 canary / R6 senior-review)
    const fpTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fourpackNarrative"])().catch(()=>"FOUR-PACK: unavailable this cycle.");
    const grounding = [
        `VERDICT-CORE STUDY WINDOW: last ${windowHours}h of the engine's own deploy-gate journal.`,
        journal.narrative,
        "BOUNDARY CASE FILES (candidates that stood exactly on the confirm/reject border):",
        ...journal.boundaryFiles.length ? journal.boundaryFiles : [
            "(none in window)"
        ],
        "HARD GATE BLOCKS:",
        ...journal.blockFiles.length ? journal.blockFiles : [
            "(none in window)"
        ],
        "SHADOW-VETO EVIDENCE (AI-core Phase 0 — your own veto-only second opinion at the fence, outcome-tracked):",
        shadow.narrative,
        ...shadow.verdictFiles.length ? shadow.verdictFiles : [
            "(no adjudications yet)"
        ],
        svTel,
        fpTel,
        "DOCTRINE: veto-only, fail-open, revocable. Real outcomes = settled trades; fence-reject outcomes = PAPER trades with base geometry (directional-edge evidence, never presented as real PnL). Promotion to live veto power requires ≥30 settled per arm + Wilson-LB separation — never claim it before the arms say so."
    ].join("\n");
    // Adapt the journal stats to the research-desk contract (aiVerdictLearn)
    const adapted = {
        total: stats.samples,
        rejectedScore: stats.byBand.REJECT,
        deployed: stats.deploys,
        boundary: stats.byBand.BOUNDARY,
        avgMarginRejected: stats.boundary?.avgGap ?? null,
        topRejectDrivers: stats.opposeReasons.map((r)=>({
                code: r.factor,
                n: r.count
            })),
        topConfirmDrivers: stats.confirmReasons.map((r)=>({
                code: r.factor,
                n: r.count
            }))
    };
    // aiVerdictLearn never throws — it degrades to a deterministic heuristic read
    const { aiVerdictLearn } = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)");
    const res = await aiVerdictLearn(grounding, adapted);
    // DETERMINISTIC VERIFICATION — every finding's numeric claims re-checked
    // against the rows the model actually studied (audit 2026-11-05, مصوبه ب/ج)
    const verifierCtx = {
        boundarySamples: journal.boundarySamples.map((s)=>({
                symbol: s.symbol,
                direction: s.direction
            })),
        stats: {
            windowHours: stats.windowHours,
            blocks: stats.blocks.map((b)=>({
                    gate: b.gate,
                    count: b.count
                })),
            blocksRingSaturated: stats.blocksRingSaturated,
            blocksRingSize: stats.blocksRingSize
        }
    };
    const verified = res.findings.map((f)=>verifyLessonFinding(f, verifierCtx));
    const correctedCount = verified.filter((v)=>v.corrected).length;
    const prev = await getVerdictCoreState();
    // HISTORY HEALING — persisted lessons from earlier cycles keep their original
    // unverified text (e.g. #1410's "8/8 PUMPUSDT" sat at confidence 100). Re-verify
    // every stored lesson that does not already carry a verifier tag; annotate + cap
    // when it fails against the CURRENT studied rows. Verified-clean history is
    // left untouched (no silent downgrades).
    const healedPrev = prev.lessons.map((l)=>{
        if ((l.evidence ?? l.pattern).includes("[VERIFIER:")) return l;
        const v = verifyLessonFinding({
            pattern: l.pattern,
            evidence: l.evidence,
            confidence: l.confidence
        }, verifierCtx);
        if (!v.corrected) return l;
        return {
            ...l,
            confidence: Math.min(l.confidence, v.confidence),
            evidence: v.evidence ?? l.evidence
        };
    });
    const healedCount = healedPrev.filter((l, i)=>l !== prev.lessons[i]).length;
    const nowIso = new Date().toISOString();
    const lessons = res.findings.map((f, i)=>({
            at: nowIso,
            scope: "GATE-JOURNAL",
            pattern: f.evidence ? `${f.pattern} — ev: ${f.evidence}` : f.pattern,
            action: f.action,
            label: res.label,
            confidence: verified[i]?.confidence ?? Math.round(f.confidence),
            evidence: verified[i]?.evidence ?? f.evidence
        }));
    const state = {
        runs: prev.runs + 1,
        lastRunAt: nowIso,
        lastAnswer: correctedCount > 0 ? `${res.digest} [VERIFIER: ${correctedCount} lesson(s) annotated/corrected against the studied rows this cycle]` : res.digest,
        lessons: [
            ...lessons,
            ...healedPrev
        ].slice(0, LESSON_CAP)
    };
    await saveState(state);
    // audit line in the engine stream (dynamic import — engine imports this module)
    await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, null, "ENGINE", "ai", `VERDICT-CORE cycle #${state.runs} (${res.label}) — studied ${stats.samples} gate verdicts (${stats.byBand.BOUNDARY} boundary · ${stats.byBand.REJECT} rejects · ${stats.deploys} deploys) — top reject driver ${adapted.topRejectDrivers[0]?.code ?? "n/a"}, top confirm driver ${adapted.topConfirmDrivers[0]?.code ?? "n/a"} — verifier: ${correctedCount}/${res.findings.length} findings + ${healedCount} history lessons annotated — lessons persisted to the central core`)).catch(()=>undefined);
    return state;
}
async function maybeAutoVerdictLearn() {
    try {
        const lastRow = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: LAST_RUN_KEY
            }
        });
        const last = lastRow ? new Date(lastRow.value).getTime() : 0;
        if (Date.now() - last < AUTO_INTERVAL_MS) return;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: LAST_RUN_KEY
            },
            create: {
                key: LAST_RUN_KEY,
                value: new Date().toISOString()
            },
            update: {
                value: new Date().toISOString()
            }
        });
        // journal too thin → skip the LLM burn, retry next cadence
        const probe = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateJournalForCore"])(12, 1);
        if (probe.stats.samples < MIN_SAMPLES) return;
        await runVerdictLearn(12);
    } catch (e) {
        console.error("[verdict-core]", e);
    }
}
}),
"[project]/src/lib/strategy-pause.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "STRAT_PAUSE_KEY",
    ()=>STRAT_PAUSE_KEY,
    "getStrategyPauseState",
    ()=>getStrategyPauseState,
    "invalidateStrategyPauseMemo",
    ()=>invalidateStrategyPauseMemo,
    "isStrategyPaused",
    ()=>isStrategyPaused,
    "setStrategyPause",
    ()=>setStrategyPause,
    "strategyTrailingStats",
    ()=>strategyTrailingStats
]);
// ── v11.6 STRATEGY-PAUSE — data-driven per-strategy risk switch (EQ-97) ──
// Operator order (trace 1a1344a53e7ff2d1): «سه اقدام واقعی باقیمانده و مأموریت
// بعدی را کامل و مهندسی اجرا کن». The senior-supervisor review (2026-10-13
// 02:49Z) listed "توقف اجرای استراتژی AI-SCALP تا بازبینی" as its #1 action;
// the ledger corroborates with an overwhelming cohort: 14d n=284 settled,
// WR 6.0%, net −$39.35 (gross −$24.48 + fees $14.86) — the worst
// fee-adjusted bleed per trade in the book.
//
// WHAT IT IS (honest engineering, no discretion drift):
//  · A strategy-level PAUSE gate in the deploy chain (engine.ts, same family
//    as SYMBOL-CAP / RISK-CLUSTER): auto deploys of a paused strategy are
//    refused (409), gate-block journaled, near-miss captured. Operator-forced
//    and capture-authority deploys are never refused — they deploy tagged
//    STRAT-PAUSE so the override cohort stays auditable.
//  · State lives in EngineSetting key "strat-pause.state" (anti-NaN heal on
//    read, same pattern as raw-cal.ts / close-all.ts).
//  · Fail-open: any internal error leaves the gate open — a monitoring switch
//    must never wedge the engine.
//  · Every enable/disable writes an ENGINE SignalEvent + Telegram push (by
//    the API route) so the decision trail is permanent.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const STRAT_PAUSE_KEY = "strat-pause.state";
const DEFAULT_STATE = {
    version: 1,
    pauses: {},
    lastChangedAt: null,
    lastChangedBy: null
};
// TASK-49-style anti-NaN heal — a wedged write can never pin the gate shut.
function healState(raw) {
    const pauses = {};
    for (const [k, v] of Object.entries(raw.pauses ?? {})){
        if (!v || typeof v !== "object") continue;
        pauses[k] = {
            enabled: v.enabled === true,
            reason: typeof v.reason === "string" ? v.reason.slice(0, 300) : "paused",
            by: typeof v.by === "string" ? v.by.slice(0, 120) : "OPERATOR",
            since: typeof v.since === "string" ? v.since : new Date().toISOString(),
            evidence: typeof v.evidence === "string" ? v.evidence.slice(0, 300) : ""
        };
    }
    return {
        version: 1,
        pauses,
        lastChangedAt: typeof raw.lastChangedAt === "string" ? raw.lastChangedAt : null,
        lastChangedBy: typeof raw.lastChangedBy === "string" ? raw.lastChangedBy : null
    };
}
async function getStrategyPauseState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: STRAT_PAUSE_KEY
            }
        });
        if (!row) return {
            ...DEFAULT_STATE,
            pauses: {}
        };
        return healState(JSON.parse(row.value));
    } catch  {
        return {
            ...DEFAULT_STATE,
            pauses: {}
        };
    }
}
// 15s memo for the hot deploy path — state changes invalidate it.
let memo = null;
const MEMO_MS = 15_000;
function invalidateStrategyPauseMemo() {
    memo = null;
}
async function isStrategyPaused(strategy) {
    try {
        if (!memo || Date.now() - memo.at > MEMO_MS) {
            memo = {
                at: Date.now(),
                state: await getStrategyPauseState()
            };
        }
        return memo.state.pauses[strategy]?.enabled === true;
    } catch  {
        return false; // fail-open
    }
}
async function setStrategyPause(strategy, patch) {
    const cur = await getStrategyPauseState();
    const next = {
        ...cur,
        pauses: {
            ...cur.pauses,
            [strategy]: {
                enabled: patch.enabled,
                reason: patch.reason.slice(0, 300),
                by: patch.by.slice(0, 120),
                since: patch.enabled ? new Date().toISOString() : cur.pauses[strategy]?.since ?? new Date().toISOString(),
                evidence: (patch.evidence ?? "").slice(0, 300)
            }
        },
        lastChangedAt: new Date().toISOString(),
        lastChangedBy: patch.by.slice(0, 120)
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: STRAT_PAUSE_KEY
        },
        create: {
            key: STRAT_PAUSE_KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
    invalidateStrategyPauseMemo();
    return next;
}
async function strategyTrailingStats(strategy, days = 14) {
    const since = new Date(Date.now() - days * 86_400_000);
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            strategy,
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            createdAt: {
                gte: since
            }
        },
        select: {
            marginUsd: true,
            pnlPercent: true,
            feeUsd: true,
            swapUsd: true,
            reachedTp: true
        }
    });
    let wins = 0;
    let gross = 0;
    let fees = 0;
    for (const r of rows){
        if (r.reachedTp >= 1) wins += 1;
        gross += r.marginUsd * r.pnlPercent / 100;
        fees += (r.feeUsd ?? 0) + (r.swapUsd ?? 0);
    }
    const n = rows.length;
    return {
        strategy,
        windowDays: days,
        n,
        wins,
        winRatePct: n ? Number((wins / n * 100).toFixed(1)) : 0,
        grossUsd: Number(gross.toFixed(2)),
        feesUsd: Number(fees.toFixed(2)),
        netUsd: Number((gross - fees).toFixed(2))
    };
}
}),
"[project]/src/lib/strategy-weights.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "STAGED_PROPOSAL",
    ()=>STAGED_PROPOSAL,
    "STRATEGY_LIST",
    ()=>STRATEGY_LIST,
    "STRATEGY_WEIGHTS_KEY",
    ()=>STRATEGY_WEIGHTS_KEY,
    "describeStrategyWeights",
    ()=>describeStrategyWeights,
    "getStrategyWeights",
    ()=>getStrategyWeights,
    "putStrategyWeights",
    ()=>putStrategyWeights,
    "strategyWeightFor",
    ()=>strategyWeightFor
]);
// ── FlowRadar Neo v10.6 PER-STRATEGY SIZING WEIGHTS (server-only) ───────────
// SUPERVISOR proposal, completed for operator decision (mandate 2026-09-15:
// «وزن‌دهی per-strategy به جای سایز سراسری — قطع خون AI-SWING، تقویت AI-SCALP»).
//
// WHY (7-day audit 2026-09-15): the book sizes every strategy with ONE global
// margin formula, so the worst cohort gets the most capital:
//   · AI-SWING  = 57% of the settled book, expectancy −1.87%/trade → the
//     single largest bleed (the "blood" this module is built to cut);
//   · AI-SCALP  = +0.84%/trade and MEAN-REVERT = +0.58%/trade — the proven
//     positive edges stay under-allocated;
//   · BREAKOUT  = −10.82% realized (already fenced by breakoutGuard).
// A per-strategy multiplier on the FINAL margin keeps every gate, geometry and
// risk cap untouched — only the stake changes. Staged weights live in
// EngineSetting "strategy.weights"; while enabled=false every weight reads 1.0
// (mechanism deployed, activation = one explicit operator decision).
//
// ACTIVATED + REALLOCATED (operator mandate trace 1a16ff36143328fd, applied
// 2026-10-25 via audited script scripts/apply-strategy-weights-20261025.ts)
// from the FRESH 15-day audit (window 2026-10-10→25, n=974 CLEAN signals):
// AI-SCALP ×0.25 (n=64 WR30% net −$11.34 — pause-by-sizing at clamp floor),
// MEAN-REVERT ×0.5 (n=90 WR38% −$13.98), BREAKOUT ×1.25 (native n=188 WR64%
// +$110.45; surrogate cohort vetoed by the P0-a SURROGATE-BREAKOUT gate),
// AI-SWING ×1.0 (workhorse, native +$104.07), MOMENTUM ×1.0 (n=6 insufficient).
// The STAGED_PROPOSAL below is the superseded 2026-09-15 draft (kept for
// history only — it is NOT live and only renders when the module is OFF).
//
// Invariants: weight ∈ [0.25, 2.0] per strategy (clamped), unknown strategies
// read 1.0, disabled module reads 1.0, every activation change auditable via
// /api/strategy-weights POST (ENGINE event).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const STRATEGY_WEIGHTS_KEY = "strategy.weights";
const STRATEGY_LIST = [
    "AI-SCALP",
    "MEAN-REVERT",
    "MOMENTUM",
    "BREAKOUT",
    "AI-SWING"
];
const W_LO = 0.25;
const W_HI = 2.0;
const STAGED_PROPOSAL = {
    "AI-SWING": 0.5,
    "AI-SCALP": 1.5,
    "MEAN-REVERT": 1.25,
    MOMENTUM: 1.0,
    BREAKOUT: 0.5
};
const DEFAULTS = {
    enabled: false,
    weights: {},
    updatedAt: null,
    updatedBy: null
};
let cache = null;
const CACHE_TTL = 15_000;
function sanitize(raw) {
    const weights = {};
    for (const [k, v] of Object.entries(raw.weights ?? {})){
        const num = Number(v);
        if (Number.isFinite(num)) weights[String(k).toUpperCase().slice(0, 24)] = Math.min(W_HI, Math.max(W_LO, Math.round(num * 100) / 100));
    }
    return {
        enabled: typeof raw.enabled === "boolean" ? raw.enabled : DEFAULTS.enabled,
        weights,
        updatedAt: typeof raw.updatedAt === "string" ? raw.updatedAt : null,
        updatedBy: typeof raw.updatedBy === "string" ? raw.updatedBy.slice(0, 80) : null
    };
}
async function getStrategyWeights(force = false) {
    if (!force && cache && Date.now() - cache.at < CACHE_TTL) return cache.value;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: STRATEGY_WEIGHTS_KEY
            }
        });
        const value = row ? sanitize(JSON.parse(row.value)) : {
            ...DEFAULTS
        };
        cache = {
            at: Date.now(),
            value
        };
        return value;
    } catch  {
        return {
            ...DEFAULTS
        };
    }
}
async function putStrategyWeights(next, by = "OPERATOR") {
    const cur = await getStrategyWeights(true);
    const merged = sanitize({
        enabled: next.enabled ?? cur.enabled,
        weights: {
            ...cur.weights,
            ...next.weights ?? {}
        },
        updatedAt: new Date().toISOString(),
        updatedBy: by
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: STRATEGY_WEIGHTS_KEY
        },
        create: {
            key: STRATEGY_WEIGHTS_KEY,
            value: JSON.stringify(merged)
        },
        update: {
            value: JSON.stringify(merged)
        }
    });
    cache = {
        at: Date.now(),
        value: merged
    };
    return merged;
}
async function strategyWeightFor(strategy) {
    try {
        const sw = await getStrategyWeights();
        if (!sw.enabled) return 1;
        const w = sw.weights[strategy];
        return Number.isFinite(w) ? w : 1;
    } catch  {
        return 1;
    }
}
function describeStrategyWeights(sw) {
    if (!sw.enabled) {
        const staged = STRATEGY_LIST.map((s)=>`${s}:${STAGED_PROPOSAL[s] ?? 1}`).join(" ");
        return `OFF (staged: ${staged} — awaiting operator activation)`;
    }
    const live = STRATEGY_LIST.map((s)=>`${s}:×${sw.weights[s] ?? 1}`).join(" ");
    return `ACTIVE ${live} (updated ${sw.updatedAt ?? "n/a"} by ${sw.updatedBy ?? "n/a"})`;
}
}),
"[project]/src/lib/strategy-probation.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "STRATEGY_PROBATION_KEY",
    ()=>STRATEGY_PROBATION_KEY,
    "describeProbation",
    ()=>describeProbation,
    "evaluateStrategyProbation",
    ()=>evaluateStrategyProbation,
    "getProbationState",
    ()=>getProbationState,
    "probationEffMinBonus",
    ()=>probationEffMinBonus,
    "probationFactorFor",
    ()=>probationFactorFor,
    "probationStrategies",
    ()=>probationStrategies
]);
// ── FlowRadar Neo v10.11 STRAT-PROBATION — strategy-level expectancy probation ──
// SUPERVISOR proposal 2026-09-17 14:55Z, operator APPROVE via bridge 2026-09-17
// 17:50Z («پیشنهادات سوپروایزر رو کامل و مهندسی انجام بده + گزارشات»).
//
// BLIND SPOT (SUPERVISOR audit 1455Z): the realizedEdge memory gate keys on
// (symbol, strategy) combos — a strategy can bleed book-wide while NO single
// combo crosses the combo floor. Measured 2026-09-17: BREAKOUT book-wide
// expectancy −8.2%/trade (n=18, 2W, −$2.71) with every individual combo below
// the n≥8 combo floor → invisible to the gate. Advisor RULE-2 proposes, but a
// proposal is not a valve.
//
// MECHANISM (soft, shrinkage-gated — never a hard kill):
//   1. EB SHRINKAGE (Efron-Morris / normal-normal hierarchical model): each
//      strategy's rolling expectancy is shrunk toward the book grand mean by
//      the method-of-moments between-variance τ̂² — small-n strategies lean
//      on the book mean (posterior sd shrinks accordingly), so a 3-trade
//      disaster CANNOT trip the probation on its own tails.
//   2. MULTIPLE-TESTING CONTROL: the family is the set of strategies with
//      n≥15 (the evaluation set); per-strategy one-sided significance uses
//      Bonferroni α′ = α/S_active — a conservative surrogate for White
//      Reality Check / Hansen SPA over the strategy family (no bootstrap
//      deps; documented surrogate, not a claim of SPA equivalence).
//   3. PROBATION RULE: strategy enters probation when n≥15 AND the shrunk
//      expectancy's ONE-SIDED (1−α′) upper confidence bound is STILL
//      negative — i.e. even the optimistic posterior reading loses money.
//   4. SOFT ACTION (eval-layer, advisor-contract compatible):
//        · margin factor ×0.5 for that strategy (sizing only, no veto);
//        · DOUBLE CONFIRM: +5 on the effective score bar (+5 effMin) — the
//          strategy must beat a higher confluence bar to deploy at all.
//      The memory gate, breakoutGuard, governor and advisor keep their
//      semantics untouched; probation only tightens size + bar for the
//      strategy-level bleed the combo gate cannot see.
//   5. EXIT: re-evaluated on a 30min lazy TTL — UCB(1−α′) ≥ 0 clears the
//      probation automatically (audited). A 48h re-entry cooldown prevents
//      threshold chatter (Schmitt trigger, mirrors v10.9.3 hysteresis).
//
// EXPECTANCY definition: mean NET pnlPercent per settled EPOCH-2 trade over a
// rolling window of STRAT_WINDOW=60 most-recent settles per strategy — the
// SAME book semantics as the realizedEdge memory gate (tags contain EPOCH-2).
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const STRATEGY_PROBATION_KEY = "strategy.probation";
const STRAT_WINDOW = 60; // rolling settled window per strategy (mirrors memory-gate rolling semantics)
const MIN_N = 15; // evaluation floor — below this the posterior is prior-dominated
const ALPHA = 0.05; // family-wise error budget across the strategy family
const EVAL_TTL_MS = 30 * 60_000; // lazy evaluation cadence
const READ_CACHE_TTL_MS = 60_000; // hot-path state cache
const SIZE_MULT = 0.5; // probation margin factor
const EFFMIN_BONUS = 5; // double-confirm score-bar raise
const DEFAULT_STATE = {
    entered: {},
    lastEvalAt: null,
    lastEvalSummary: null
};
let stateCache = null;
let evalCache = null;
let evalInFlight = false;
/** Acklam's inverse-normal CDF (|ε| < 1.15e-9 relative) — no deps. */ function probit(p) {
    if (p <= 0) return -Infinity;
    if (p >= 1) return Infinity;
    const a = [
        -3.969683028665376e1,
        2.209460984245205e2,
        -2.759285104469687e2,
        1.38357751867269e2,
        -3.066479806614716e1,
        2.506628277459239
    ];
    const b = [
        -5.447609879822406e1,
        1.615858368580409e2,
        -1.556989798598866e2,
        6.680131188771972e1,
        -1.328068155288572e1
    ];
    const c = [
        -7.784894002430293e-3,
        -3.223964580411365e-1,
        -2.400758277161838,
        -2.549732539343734,
        4.374664141464968,
        2.938163982698783
    ];
    const d = [
        7.784695709041462e-3,
        3.224671290700398e-1,
        2.445134137142996,
        3.754408661907416
    ];
    const pl = 0.02425;
    let q, r;
    if (p < pl) {
        q = Math.sqrt(-2 * Math.log(p));
        return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
    }
    if (p > 1 - pl) {
        q = Math.sqrt(-2 * Math.log(1 - p));
        return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
    }
    q = p - 0.5;
    r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
}
function sanitize(raw) {
    const entered = {};
    for (const [k, v] of Object.entries(raw.entered ?? {})){
        if (v && typeof v.sinceAt === "number" && typeof v.strategy === "string") {
            entered[String(k).toUpperCase().slice(0, 24)] = {
                strategy: String(v.strategy).slice(0, 24),
                sinceAt: v.sinceAt,
                ucbAtEntry: Number(v.ucbAtEntry) || 0,
                meanAtEntry: Number(v.meanAtEntry) || 0,
                nAtEntry: Number(v.nAtEntry) || 0,
                lastReviewAt: Number(v.lastReviewAt) || v.sinceAt,
                lastReviewUcb: Number(v.lastReviewUcb) || 0,
                posStreak: Number(v.posStreak) || 0
            };
        }
    }
    return {
        entered,
        lastEvalAt: typeof raw.lastEvalAt === "number" ? raw.lastEvalAt : null,
        lastEvalSummary: typeof raw.lastEvalSummary === "string" ? raw.lastEvalSummary.slice(0, 300) : null
    };
}
async function getProbationState(force = false) {
    if (!force && stateCache && Date.now() - stateCache.at < READ_CACHE_TTL_MS) return stateCache.value;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: STRATEGY_PROBATION_KEY
            }
        });
        const value = row ? sanitize(JSON.parse(row.value)) : {
            ...DEFAULT_STATE,
            entered: {}
        };
        stateCache = {
            at: Date.now(),
            value
        };
        return value;
    } catch  {
        return {
            ...DEFAULT_STATE,
            entered: {}
        };
    }
}
async function putProbationState(next) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: STRATEGY_PROBATION_KEY
        },
        create: {
            key: STRATEGY_PROBATION_KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
    stateCache = {
        at: Date.now(),
        value: next
    };
}
async function evaluateStrategyProbation(force = false) {
    if (!force && evalCache && Date.now() - evalCache.at < EVAL_TTL_MS) return evalCache.value;
    if (evalInFlight) return evalCache?.value ?? null;
    evalInFlight = true;
    try {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                status: {
                    in: [
                        "TP1",
                        "TP2",
                        "TP3",
                        "SL",
                        "EXPIRED",
                        "CLOSED"
                    ]
                },
                tags: {
                    contains: "EPOCH-2"
                }
            },
            select: {
                strategy: true,
                pnlPercent: true
            },
            orderBy: {
                createdAt: "desc"
            },
            take: 800
        });
        // per-strategy rolling windows
        const byStrat = new Map();
        for (const r of rows){
            const arr = byStrat.get(r.strategy);
            if (arr) {
                if (arr.length < STRAT_WINDOW) arr.push(r.pnlPercent);
            } else {
                byStrat.set(r.strategy, [
                    r.pnlPercent
                ]);
            }
        }
        const data = [
            ...byStrat.entries()
        ].filter(([, xs])=>xs.length >= 3).map(([strategy, xs])=>{
            const n = xs.length;
            const mean = xs.reduce((a, x)=>a + x, 0) / n;
            const varr = n > 1 ? xs.reduce((a, x)=>a + (x - mean) * (x - mean), 0) / (n - 1) : 0;
            return {
                strategy,
                n,
                mean,
                varr
            };
        });
        const evalSet = data.filter((d)=>d.n >= MIN_N);
        if (data.length < 2 || evalSet.length === 0) {
            const empty = {
                at: Date.now(),
                familySize: evalSet.length,
                grandMean: 0,
                tauSq: 0,
                strats: [],
                actions: []
            };
            evalCache = {
                at: Date.now(),
                value: empty
            };
            return empty;
        }
        const N = data.reduce((a, d)=>a + d.n, 0);
        const grandMean = data.reduce((a, d)=>a + d.mean * d.n, 0) / N;
        const sw = data.reduce((a, d)=>a + (d.n - 1) * d.varr, 0) / Math.max(1, N - data.length); // pooled within-variance
        // method-of-moments between-variance (normal-normal): mean of squared mean-deviations minus average sampling noise
        const S = data.length;
        const rawTau = S > 1 ? (data.reduce((a, d)=>a + (d.mean - grandMean) * (d.mean - grandMean), 0) - data.reduce((a, d)=>a + d.varr / d.n, 0)) / (S - 1) : 0;
        const tauSq = Math.max(0, Number.isFinite(rawTau) ? rawTau : 0);
        const alphaPrime = ALPHA / Math.max(1, evalSet.length); // Bonferroni over the evaluation family
        const zU = probit(1 - alphaPrime); // one-sided upper
        const st = await getProbationState(true);
        const nextEntered = {
            ...st.entered
        };
        const actions = [];
        const strats = [];
        const now = Date.now();
        for (const d of data){
            const inSet = d.n >= MIN_N;
            // EB posterior: precision-weighted blend of the strategy mean with the grand mean
            const w = tauSq > 0 ? d.n / Math.max(1e-9, sw) : 0; // prior dominates completely when τ̂²=0
            const prec = w + (tauSq > 0 ? 1 / tauSq : Infinity);
            const shrunkMean = tauSq > 0 ? (w * d.mean + grandMean / tauSq) / prec : grandMean;
            const sd = tauSq > 0 ? 1 / Math.sqrt(prec) : Math.sqrt(sw / Math.max(1, d.n)); // posterior sd
            const ucb = shrunkMean + (inSet ? zU * sd : Infinity); // non-eval strategies can never qualify
            let onProbation = false;
            if (inSet) {
                const entry = nextEntered[d.strategy];
                if (!entry && ucb < 0) {
                    onProbation = true;
                    nextEntered[d.strategy] = {
                        strategy: d.strategy,
                        sinceAt: now,
                        ucbAtEntry: ucb,
                        meanAtEntry: d.mean,
                        nAtEntry: d.n,
                        lastReviewAt: now,
                        lastReviewUcb: ucb,
                        posStreak: 0
                    };
                    actions.push(`ENTER ${d.strategy}: shrunk expectancy ${shrunkMean.toFixed(2)}%/trade, UCB(1−α′=${alphaPrime.toFixed(3)})=${ucb.toFixed(2)} < 0 over n=${d.n} (raw ${d.mean.toFixed(2)}%) — margin ×${SIZE_MULT} + effMin +${EFFMIN_BONUS}`);
                } else if (entry) {
                    // Schmitt-trigger exit: TWO consecutive reviews with UCB ≥ 0 (optimistic
                    // bound recovered) — single-review exits would chatter at the boundary.
                    const streak = ucb >= 0 ? (entry.posStreak || 0) + 1 : 0;
                    if (streak >= 2) {
                        delete nextEntered[d.strategy];
                        actions.push(`EXIT ${d.strategy}: UCB=${ucb.toFixed(2)} ≥ 0 two consecutive reviews at n=${d.n} — probation cleared (on since ${new Date(entry.sinceAt).toISOString()})`);
                    } else {
                        onProbation = true;
                        nextEntered[d.strategy] = {
                            ...entry,
                            lastReviewAt: now,
                            lastReviewUcb: ucb,
                            posStreak: streak
                        };
                    }
                }
            }
            strats.push({
                strategy: d.strategy,
                n: d.n,
                mean: d.mean,
                shrunkMean,
                sd,
                ucb: Number.isFinite(ucb) ? ucb : 999,
                inEvaluationSet: inSet,
                onProbation
            });
        }
        const evaluation = {
            at: now,
            familySize: evalSet.length,
            grandMean,
            tauSq,
            strats,
            actions
        };
        if (actions.length > 0 || Object.keys(nextEntered).length !== Object.keys(st.entered).length) {
            await putProbationState({
                entered: nextEntered,
                lastEvalAt: now,
                lastEvalSummary: actions.join(" · ").slice(0, 300) || st.lastEvalSummary
            });
            for (const line of actions){
                void __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, null, "ENGINE", "info", `STRAT-PROBATION: ${line}`)).catch(()=>undefined);
            }
        } else {
            await putProbationState({
                ...st,
                lastEvalAt: now,
                lastEvalSummary: st.lastEvalSummary ?? "no transitions"
            });
        }
        evalCache = {
            at: Date.now(),
            value: evaluation
        };
        return evaluation;
    } catch  {
        return evalCache?.value ?? null; // fail-neutral — probation must never break the deploy path
    } finally{
        evalInFlight = false;
    }
}
async function probationFactorFor(strategy) {
    try {
        const st = await getProbationState();
        void ensureFreshEvaluation();
        return st.entered[strategy] ? SIZE_MULT : 1;
    } catch  {
        return 1;
    }
}
function probationEffMinBonus() {
    return EFFMIN_BONUS;
}
async function probationStrategies() {
    try {
        const st = await getProbationState();
        void ensureFreshEvaluation();
        return new Set(Object.keys(st.entered));
    } catch  {
        return new Set();
    }
}
let lastKickAt = 0;
function ensureFreshEvaluation() {
    const now = Date.now();
    if (now - lastKickAt < EVAL_TTL_MS) return;
    lastKickAt = now;
    void evaluateStrategyProbation().catch(()=>undefined);
}
function describeProbation(st, ev) {
    const keys = Object.keys(st.entered);
    if (!ev) return keys.length ? `ON: ${keys.join(", ")} (evaluation pending)` : "no strategy on probation (evaluation pending)";
    const rows = ev.strats.map((s)=>`${s.strategy}${s.onProbation ? "·PROB" : ""} n=${s.n} raw ${s.mean >= 0 ? "+" : ""}${s.mean.toFixed(1)}% shrunk ${s.shrunkMean >= 0 ? "+" : ""}${s.shrunkMean.toFixed(1)}% UCB ${s.ucb >= 900 ? "n/a" : (s.ucb >= 0 ? "+" : "") + s.ucb.toFixed(1) + "%"}`).join(" · ");
    return `family S=${ev.familySize} α′=${(ALPHA / Math.max(1, ev.familySize)).toFixed(3)} τ̂²=${ev.tauSq.toFixed(2)} — ${rows || "no data"}`;
}
}),
"[project]/src/lib/near-miss.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "nearMissCaptureBarrier",
    ()=>nearMissCaptureBarrier,
    "nearMissCaptureGate",
    ()=>nearMissCaptureGate,
    "nearMissCaptureScore",
    ()=>nearMissCaptureScore,
    "nearMissOpenCount",
    ()=>nearMissOpenCount,
    "nearMissReady",
    ()=>nearMissReady,
    "nearMissState",
    ()=>nearMissState,
    "nearMissSweep",
    ()=>nearMissSweep
]);
// ── FlowRadar Neo v10.13+v10.14 NEAR-MISS EVIDENCE PROGRAM (server-only) ──
// Operator APPROVE 2026-09-18T18:58Z (bridge msg 861802415: «تایید پیشنهاد
// سوپروایزر کامل و مهندسی انجام بده») + operator APPROVE 2026-09-19T08:56Z
// (bridge msg 861802419: «پیشنهادات سوپروایزر رو کامل و مهندسی انجام بده») —
// implements the supervisor paper-tier proposals as ONE evidence program,
// ZERO live risk (paper only, no orders, no EngineSetting writes, no gate
// changes):
//
//   Tier S (SCORE-NEAR-MISS, supervisor proposal msg 3677): scan-batch
//   candidates rejected ONLY by the score gate with |adjScore| in
//   [0.85, 1.0)×effMin (gap ∈ [−0.15×effMin, 0)). Top-1 per sweep (closest
//   to the gate buys the most evidence). Paper geometry mirrors the engine
//   (SL 2×ATR-class, strategy RR ladder, SV paper margin).
//
//   Tier B (BARRIER-NEAR-MISS, supervisor proposal 2026-09-18T18:53Z): the
//   drought diagnosis proved the binding constraint moved from MIN_SCORE
//   (relieved 40→35 at 16:43Z) to the VOL-SCALED VERTICAL BARRIER (cap 240m
//   rejecting ETHUSDT LONG t1r 252-432m). When a candidate is rejected by
//   the barrier with projected 1R-touch t1r ∈ (cap, 1.5×cap] — i.e. a
//   hypothetical 1.5×cap barrier would have carried it — capture a paper
//   trade with the ENGINE-IDENTICAL ladder built just above the skip point
//   and ttlMinutes = the hypothetical barrier min(1.5×cap, t1r × mult).
//   Settle outcomes answer "is the barrier cap over-tight?" from measured
//   outcomes, not opinion.
//   v10.14 (BARRIER-CAP-NEAR-MISS, supervisor proposal 2026-09-19T06:51Z,
//   approved 2026-09-19T08:56Z msg 861802419): with the REGIME-ADAPTIVE cap
//   live (volBarrierAdaptive=1), every call passes the EFFECTIVE cap — the
//   band (effCap, 1.5×effCap] and the hypothetical barrier now ride the
//   adaptive policy, and each capture carries volPctile + capUsed + baseCap
//   metadata so the cohort can be split fixed-cap vs adaptive-cap: the
//   counterfactual audit trail of the widening itself ("did the relaxation
//   admit winners, or censored rows?").
//
//   Tier G (GATE-NEAR-MISS, supervisor proposal msg 3920 2026-09-19T03:00Z,
//   approved 2026-09-19T08:56Z msg 861802419): candidates that PASSED the
//   score gate but were suppressed by the MEMORY gate (realized-edge
//   profit-first filter) — captured paper with engine-identical geometry so
//   the gate's OPPORTUNITY COST is measured, not assumed. Decision rule
//   (per proposal): ≥30 settled GATE cohort with NEGATIVE counterfactual
//   expectancy vindicates the −2% floor (keep gate); POSITIVE expectancy →
//   file advisor KNOB_ADJUST upgrading the memory-gate statistic to the
//   SQN-style R-normalized score (expectancy(R)/std(R) × √N — Van Tharp SQN,
//   computed and surfaced per arm below; meta-labeling doctrine requires the
//   FILTER itself to be evidence-validated). The live gate decision rules
//   are UNCHANGED until that evidence lands.
//
// LITERATURE: Hudson & Thames meta-labeling + MDPI 2024 (enhanced GA triple
// barrier) — meta-labels on triple-barrier time-expiry samples improve signal
// efficacy; this module produces exactly those labels (barrier-rejected
// cohorts labelled by hypothetical-barrier outcomes) for the next calibration.
//
// RAILS (anti-flood + honesty):
//  · daily capture cap 8 per tier (per UTC day)
//  · dedup 120min per tier|symbol|direction
//  · max 16 concurrent open papers per tier (drop new when full)
//  · rolling-30 settled arms per tier + Wilson-LB95 (same math as SV arms)
//  · persistence .data/near-miss.jsonl (SV jsonl pattern); in-memory rings;
//    7d prune for settled rows
//  · FAIL-OPEN everywhere: never throws into the scan/deploy path
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accounting.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indicators.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
// ── config / rails ────────────────────────────────────────────
const DAILY_CAP_PER_TIER = 8; // ~8/day per tier (supervisor estimate, anti-spam)
const DEDUP_MS = 120 * 60_000; // 2h per tier|symbol|direction
const MAX_OPEN_PER_TIER = 16;
const MAX_ROWS = 400; // ring cap
const SETTLED_TTL_MS = 7 * 24 * 3600_000; // 7d prune for settled rows
const BARRIER_BAND_MULT = 1.5; // capture band = (cap, 1.5×cap]
const ROLLING = 30; // rolling-30 settled per arm (v10.10 SV semantics)
// mirror of engine.ts deploySignal constants (engine owns the canonical
// values; kept in sync — score-tier paper geometry only)
const RR_BASE = {
    "AI-SCALP": 2.1,
    "MEAN-REVERT": 2.4,
    MOMENTUM: 2.8,
    BREAKOUT: 3.1,
    "AI-SWING": 3.4
};
const TTL_BY_STRATEGY = {
    "AI-SCALP": [
        60,
        90
    ],
    BREAKOUT: [
        90,
        150
    ],
    MOMENTUM: [
        90,
        150
    ],
    "MEAN-REVERT": [
        60,
        120
    ],
    "AI-SWING": [
        180,
        300
    ]
};
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const DATA_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "near-miss.jsonl");
// ── store ─────────────────────────────────────────────────────
let rows = [];
let seq = 0;
let loaded = false;
let loadPromise = null;
const lastCapAt = new Map(); // tier|symbol|direction → ts
const dayCount = new Map(); // tier|YYYYMMDD → count
async function persist(rec) {
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
            recursive: true
        });
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(DATA_FILE, JSON.stringify(rec) + "\n", "utf8");
    } catch  {
    /* evidence persistence must never break the scan */ }
}
async function load() {
    if (loaded) return;
    if (loadPromise) return loadPromise;
    loadPromise = (async ()=>{
        try {
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(DATA_FILE).catch(()=>null);
            if (st?.size) {
                const txt = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(DATA_FILE, "utf8");
                for (const line of txt.split("\n")){
                    if (!line.trim()) continue;
                    try {
                        const j = JSON.parse(line);
                        if (j.k === "c") {
                            const cap = j.v;
                            if (!rows.some((r)=>r.id === cap.id)) rows.push(cap);
                            const n = Number(cap.id.replace("NM-", ""));
                            if (Number.isFinite(n) && n > seq) seq = n;
                        } else if (j.k === "pc") {
                            const p = j.v;
                            const r = rows.find((x)=>x.id === p.id);
                            if (r && !r.outcome) {
                                r.status = p.status;
                                r.reachedTp = p.reachedTp;
                                r.pnlPercent = p.pnlPercent;
                                r.pnlUsd = p.pnlUsd;
                                r.outcome = p.outcome;
                                r.closeNote = p.closeNote;
                            }
                        }
                    } catch  {
                    /* skip malformed line */ }
                }
            }
        } catch  {
        /* start empty */ }
        // v10.14 backfill — pre-v10.14 rows predate the regime/decision metadata
        for (const r of rows){
            if (r.volPctile === undefined) r.volPctile = null;
            if (r.capUsed === undefined) r.capUsed = null;
            if (r.baseCap === undefined) r.baseCap = null;
            if (r.gateReason === undefined) r.gateReason = null;
        }
        loaded = true;
    })();
    return loadPromise;
}
function trimRows() {
    if (rows.length <= MAX_ROWS) return;
    const settledOld = rows.filter((r)=>r.outcome && Date.now() - (r.outcome.closedAt || r.at) > SETTLED_TTL_MS);
    for (const r of settledOld.sort((a, b)=>(a.outcome?.closedAt || 0) - (b.outcome?.closedAt || 0))){
        if (rows.length <= MAX_ROWS) break;
        rows = rows.filter((x)=>x.id !== r.id);
    }
    while(rows.length > MAX_ROWS)rows.shift();
}
const dayKey = (d = new Date())=>`${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, "0")}${String(d.getUTCDate()).padStart(2, "0")}`;
function railsOk(tier, symbol, direction, openInTier) {
    const dk = `${tier}|${dayKey()}`;
    if ((dayCount.get(dk) ?? 0) >= DAILY_CAP_PER_TIER) return false;
    const key = `${tier}|${symbol}|${direction}`;
    const last = lastCapAt.get(key) ?? 0;
    if (Date.now() - last < DEDUP_MS) return false;
    if (openInTier >= MAX_OPEN_PER_TIER) return false;
    return true;
}
function markRails(tier, symbol, direction) {
    lastCapAt.set(`${tier}|${symbol}|${direction}`, Date.now());
    const dk = `${tier}|${dayKey()}`;
    dayCount.set(dk, (dayCount.get(dk) ?? 0) + 1);
}
const movePctAt = (p, px)=>(px - p.entry) / p.entry * (p.direction === "LONG" ? 1 : -1) * 100;
async function nearMissCaptureBarrier(ctx) {
    try {
        await load();
        if (!(ctx.t1rMin > ctx.capMin) || !(ctx.t1rMin <= ctx.capMin * BARRIER_BAND_MULT)) return;
        if (!Number.isFinite(ctx.entry) || ctx.entry <= 0 || !(ctx.rr > 0)) return;
        const openB = rows.filter((r)=>r.tier === "BARRIER" && !r.outcome).length;
        if (!railsOk("BARRIER", ctx.symbol, ctx.direction, openB)) return;
        const cfg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getShadowVetoConfig"])();
        const hypBarrier = Math.round(Math.min(ctx.capMin * BARRIER_BAND_MULT, ctx.t1rMin * ctx.volBarrierMult));
        if (!(hypBarrier > ctx.capMin)) return;
        const levRaw = Math.round(Math.min(20, Math.max(5, 60 / (ctx.slDistPct * 100))));
        seq++;
        const cap = {
            id: `NM-${String(seq).padStart(4, "0")}`,
            tier: "BARRIER",
            at: Date.now(),
            symbol: ctx.symbol,
            direction: ctx.direction,
            strategy: ctx.strategy,
            entry: Number(ctx.entry.toFixed(ctx.entry > 100 ? 2 : 6)),
            stop: Number(ctx.stopLoss.toFixed(ctx.entry > 100 ? 2 : 6)),
            initialStop: Number(ctx.stopLoss.toFixed(ctx.entry > 100 ? 2 : 6)),
            tp1: Number(ctx.tp1.toFixed(ctx.entry > 100 ? 2 : 6)),
            tp2: Number(ctx.tp2.toFixed(ctx.entry > 100 ? 2 : 6)),
            tp3: Number(ctx.tp3.toFixed(ctx.entry > 100 ? 2 : 6)),
            leverage: levRaw,
            marginUsd: cfg.paperMarginUsd,
            slDistPct: ctx.slDistPct,
            rr: ctx.rr,
            ttlMinutes: hypBarrier,
            t1rMin: Math.round(ctx.t1rMin),
            scoreGap: null,
            status: "OPEN",
            reachedTp: 0,
            maxPnlPercent: 0,
            pnlPercent: 0,
            pnlUsd: 0,
            outcome: null,
            closeNote: null,
            epoch: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ARM_EPOCH"],
            volPctile: ctx.volPctile ?? null,
            capUsed: ctx.capMin,
            baseCap: ctx.baseCap ?? ctx.capMin,
            gateReason: null
        };
        rows.push(cap);
        trimRows();
        markRails("BARRIER", ctx.symbol, ctx.direction);
        void persist({
            k: "c",
            v: cap
        });
        try {
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
            const regime = ctx.volPctile != null && ctx.capMin !== ctx.baseCap ? ` · regime p${Math.round(ctx.volPctile)} → adaptive cap ${ctx.capMin}m` : "";
            void fireEvent(null, ctx.symbol, "ENGINE", "info", `NEAR-MISS CAPTURE [BARRIER]: ${ctx.direction} ${ctx.symbol} ${ctx.strategy} paper NM-${String(seq).padStart(4, "0")} — t1r ${Math.round(ctx.t1rMin)}m rejected vs cap ${ctx.capMin}m → hypothetical barrier ${hypBarrier}m (ladder rr ${ctx.rr})${regime} · zero live risk`).catch(()=>undefined);
        } catch  {
        /* terminal event best-effort */ }
    } catch  {
    /* fail-open */ }
}
async function nearMissCaptureGate(ctx) {
    try {
        await load();
        if (!ctx.symbol || !ctx.strategy) return;
        const openG = rows.filter((r)=>r.tier === "GATE" && !r.outcome).length;
        if (!railsOk("GATE", ctx.symbol, ctx.direction, openG)) return;
        const geo = await scoreGeometry(ctx.symbol, ctx.direction, ctx.strategy);
        if (!geo) return;
        const cfg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getShadowVetoConfig"])();
        seq++;
        const cap = {
            id: `NM-${String(seq).padStart(4, "0")}`,
            tier: "GATE",
            at: Date.now(),
            symbol: ctx.symbol,
            direction: ctx.direction,
            strategy: ctx.strategy,
            entry: geo.entry,
            stop: geo.initialStop,
            initialStop: geo.initialStop,
            tp1: geo.tp1,
            tp2: geo.tp2,
            tp3: geo.tp3,
            leverage: geo.leverage,
            marginUsd: cfg.paperMarginUsd,
            slDistPct: geo.slDistPct,
            rr: geo.rr,
            ttlMinutes: geo.ttlMinutes,
            t1rMin: null,
            scoreGap: null,
            status: "OPEN",
            reachedTp: 0,
            maxPnlPercent: 0,
            pnlPercent: 0,
            pnlUsd: 0,
            outcome: null,
            closeNote: null,
            epoch: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ARM_EPOCH"],
            volPctile: null,
            capUsed: null,
            baseCap: null,
            gateReason: (ctx.reason || "").slice(0, 240)
        };
        rows.push(cap);
        trimRows();
        markRails("GATE", ctx.symbol, ctx.direction);
        void persist({
            k: "c",
            v: cap
        });
        try {
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
            void fireEvent(null, ctx.symbol, "ENGINE", "info", `NEAR-MISS CAPTURE [GATE]: ${ctx.direction} ${ctx.symbol} ${ctx.strategy} paper NM-${String(seq).padStart(4, "0")} — memory-gate suppressed (${(ctx.reason || "").slice(0, 120)}) → hypothetical admission, ladder rr ${geo.rr} · zero live risk`).catch(()=>undefined);
        } catch  {
        /* terminal event best-effort */ }
    } catch  {
    /* fail-open */ }
}
// ── tier S: score near-miss (scan fence batches) ──────────────
async function scoreGeometry(symbol, direction, strategy) {
    try {
        const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
        const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchKlines"])(symbol, "15m", 160).catch(()=>null);
        const snap = candles ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["buildSnapshot"])(symbol, candles) : null;
        const entry = snap?.price ?? 0;
        if (!entry) return null;
        const atrPct = snap?.atrPct ?? 1.5;
        const slDistPct = Math.min(5, Math.max(0.7, gate.slAtrMult * atrPct)) / 100;
        const levRaw = Math.round(Math.min(20, Math.max(5, 60 / (slDistPct * 100))));
        const leverage = gate.leveredRiskCap > 0 && slDistPct * 100 * levRaw > gate.leveredRiskCap ? Math.max(5, Math.floor(gate.leveredRiskCap / (slDistPct * 100))) : levRaw;
        const rr = RR_BASE[strategy] ?? 2.6;
        const tp2Mult = Math.min(2.2, Math.max(1.5, 1.2 + rr * 0.22));
        const [ttlMin, ttlMax] = TTL_BY_STRATEGY[strategy] ?? [
            90,
            180
        ];
        const isLong = direction === "LONG";
        const risk = entry * slDistPct;
        const fx = (v)=>Number(v.toFixed(entry > 100 ? 2 : 6));
        return {
            entry: fx(entry),
            initialStop: fx(isLong ? entry - risk : entry + risk),
            tp1: fx(isLong ? entry + risk : entry - risk),
            tp2: fx(isLong ? entry + risk * tp2Mult : entry - risk * tp2Mult),
            tp3: fx(isLong ? entry + risk * rr : entry - risk * rr),
            leverage,
            slDistPct,
            rr,
            ttlMinutes: Math.round(ttlMin + Math.random() * (ttlMax - ttlMin))
        };
    } catch  {
        return null;
    }
}
async function nearMissCaptureScore(batch) {
    try {
        await load();
        if (!Array.isArray(batch) || batch.length === 0) return;
        const band = batch.filter((c)=>c && !c.passed && Number.isFinite(c.score) && Number.isFinite(c.effMin) && c.effMin > 0).map((c)=>({
                c,
                gap: Math.abs(c.score) - c.effMin,
                bandFloor: -0.15 * c.effMin
            })).filter(({ gap, bandFloor })=>gap < 0 && gap >= bandFloor).sort((a, b)=>Math.abs(b.gap) - Math.abs(a.gap)); // closest to gate first
        if (band.length === 0) return;
        const openS = rows.filter((r)=>r.tier === "SCORE" && !r.outcome).length;
        const cand = band[0];
        if (!railsOk("SCORE", cand.c.symbol, cand.c.direction, openS)) return;
        const geo = await scoreGeometry(cand.c.symbol, cand.c.direction, cand.c.strategy);
        if (!geo) return;
        const cfg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getShadowVetoConfig"])();
        seq++;
        const cap = {
            id: `NM-${String(seq).padStart(4, "0")}`,
            tier: "SCORE",
            at: Date.now(),
            symbol: cand.c.symbol,
            direction: cand.c.direction,
            strategy: cand.c.strategy,
            entry: geo.entry,
            stop: geo.initialStop,
            initialStop: geo.initialStop,
            tp1: geo.tp1,
            tp2: geo.tp2,
            tp3: geo.tp3,
            leverage: geo.leverage,
            marginUsd: cfg.paperMarginUsd,
            slDistPct: geo.slDistPct,
            rr: geo.rr,
            ttlMinutes: geo.ttlMinutes,
            t1rMin: null,
            scoreGap: Number(cand.gap.toFixed(1)),
            status: "OPEN",
            reachedTp: 0,
            maxPnlPercent: 0,
            pnlPercent: 0,
            pnlUsd: 0,
            outcome: null,
            closeNote: null,
            epoch: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ARM_EPOCH"],
            volPctile: null,
            capUsed: null,
            baseCap: null,
            gateReason: null
        };
        rows.push(cap);
        trimRows();
        markRails("SCORE", cand.c.symbol, cand.c.direction);
        void persist({
            k: "c",
            v: cap
        });
        try {
            const { fireEvent } = await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)");
            void fireEvent(null, cand.c.symbol, "ENGINE", "info", `NEAR-MISS CAPTURE [SCORE]: ${cand.c.direction} ${cand.c.symbol} ${cand.c.strategy} paper NM-${String(seq).padStart(4, "0")} — |score| ${Math.abs(cand.c.score).toFixed(0)} vs eff ${cand.c.effMin.toFixed(0)} (gap ${cand.gap.toFixed(1)}, band 0.85-1.0×) → paper ladder rr ${geo.rr} · zero live risk`).catch(()=>undefined);
        } catch  {
        /* terminal event best-effort */ }
    } catch  {
    /* fail-open */ }
}
function nearMissOpenCount() {
    let open = 0;
    for (const p of rows)if (!p.outcome) open++;
    return open;
}
async function nearMissSweep(priceMap) {
    try {
        if (rows.length === 0) return 0;
        const now = Date.now();
        let closed = 0;
        for (const p of rows){
            if (p.outcome) continue;
            const price = priceMap.get(p.symbol);
            if (!price) continue;
            const isLong = p.direction === "LONG";
            const hitSl = isLong ? price <= p.stop : price >= p.stop;
            const hitTp1 = isLong ? price >= p.tp1 : price <= p.tp1;
            const hitTp2 = isLong ? price >= p.tp2 : price <= p.tp2;
            const hitTp3 = isLong ? price >= p.tp3 : price <= p.tp3;
            if (hitSl) {
                closeCapture(p, "SL", movePctAt(p, p.stop), now, `stopped @ ${p.stop} (trailed)`);
                closed++;
            } else if (hitTp3) {
                p.reachedTp = 3;
                closeCapture(p, "TP3", movePctAt(p, p.tp3), now, `final target ${p.rr.toFixed(1)}R secured`);
                closed++;
            } else if (hitTp2 && p.reachedTp < 2) {
                p.reachedTp = 2;
                p.status = "TP2";
                p.stop = p.tp1; // trail to TP1 — +1R locked (engine semantics)
            } else if (hitTp1 && p.reachedTp < 1) {
                p.reachedTp = Math.max(p.reachedTp, 1);
                p.status = "TP1";
                p.stop = p.entry; // breakeven trail (engine semantics)
            } else if (now > p.at + p.ttlMinutes * 60_000) {
                closeCapture(p, "EXPIRED", movePctAt(p, price), now, `hypothetical barrier ${p.ttlMinutes}m elapsed at mark`);
                closed++;
            }
            p.maxPnlPercent = Math.max(p.maxPnlPercent, Number((movePctAt(p, price) * p.leverage).toFixed(2)));
        }
        return closed;
    } catch  {
        return 0;
    }
}
/** Tranche-aware close — identical math to the real resolver (v6.6) and SV
 * closePaper: rung ladders with trailing, tranche-weighted closes, fees. */ function closeCapture(p, status, exitMovePct, closedAt, note) {
    const rung = (px)=>movePctAt(p, px);
    const grossPct = p.reachedTp >= 1 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ladderWeightedMove"])([
        {
            weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp1,
            movePct: rung(p.tp1)
        },
        ...p.reachedTp >= 2 ? [
            {
                weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp2,
                movePct: rung(p.tp2)
            }
        ] : [],
        {
            weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].runner,
            movePct: status === "TP3" ? rung(p.tp3) : exitMovePct
        }
    ]) : exitMovePct;
    const heldMin = Math.max(0, (closedAt - p.at) / 60_000);
    const fb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(p.marginUsd, p.leverage, grossPct, heldMin);
    p.status = status;
    p.pnlPercent = Number(fb.netPct.toFixed(2));
    p.pnlUsd = Number(fb.netUsd.toFixed(3));
    p.outcome = {
        status,
        pnlPercent: p.pnlPercent,
        pnlUsd: p.pnlUsd,
        win: p.pnlPercent > 0 || p.reachedTp >= 1,
        closedAt
    };
    p.closeNote = note;
    void persist({
        k: "pc",
        v: {
            id: p.id,
            status: p.status,
            reachedTp: p.reachedTp,
            pnlPercent: p.pnlPercent,
            pnlUsd: p.pnlUsd,
            stop: p.stop,
            outcome: p.outcome,
            closeNote: note
        }
    });
}
// ── arms + state (API feed) ───────────────────────────────────
/** v10.14 — SQN-style R statistics on a settled paper cohort (msg 3920 spec):
 * R proxy = pnlPercent / (slDistPct × 100 × leverage) — margin-relative NET
 * over the levered 1R. SQN = √N × mean(R)/std(R) (population std); sqnTrim
 * drops the top/bottom 10% of the R series (outlier-hardened variant). All
 * null-safe: fewer than 5 settled rows → nulls. */ function sqnStats(caps) {
    const settled = caps.filter((r)=>r.outcome);
    if (settled.length < 5) return {
        sqn: null,
        sqnTrim: null,
        meanR: null,
        expPct: null
    };
    const rs = settled.map((r)=>r.slDistPct > 0 && r.leverage > 0 ? r.pnlPercent / (r.slDistPct * 100 * r.leverage) : 0);
    const n = rs.length;
    const mean = rs.reduce((a, b)=>a + b, 0) / n;
    const sd = Math.sqrt(rs.reduce((a, b)=>a + (b - mean) * (b - mean), 0) / n); // population (ddof 0)
    const sqn = sd > 0 ? Math.sqrt(n) * (mean / sd) : null;
    const sorted = [
        ...rs
    ].sort((a, b)=>a - b);
    const k = Math.floor(n * 0.1); // 10% trim each side
    const trim = k > 0 && n - 2 * k >= 5 ? sorted.slice(k, n - k) : sorted;
    const tm = trim.reduce((a, b)=>a + b, 0) / trim.length;
    const tsd = Math.sqrt(trim.reduce((a, b)=>a + (b - tm) * (b - tm), 0) / trim.length);
    const sqnTrim = tsd > 0 ? Math.sqrt(trim.length) * (tm / tsd) : null;
    const expPct = settled.reduce((a, r)=>a + (r.pnlPercent || 0), 0) / n;
    return {
        sqn: sqn === null ? null : Number(sqn.toFixed(2)),
        sqnTrim: sqnTrim === null ? null : Number(sqnTrim.toFixed(2)),
        meanR: Number(mean.toFixed(3)),
        expPct: Number(expPct.toFixed(2))
    };
}
function armRow(id, label, caps) {
    const settled = caps.filter((r)=>r.outcome).slice(-ROLLING); // most recent 30 settled
    const wins = settled.filter((r)=>r.outcome.win).length;
    const n = settled.length;
    const sq = sqnStats(settled);
    return {
        id,
        label,
        n,
        wins,
        winRatePct: n > 0 ? Number((wins / n * 100).toFixed(1)) : null,
        wilsonLB: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["wilsonLB"])(wins, n),
        netUsd: Number(settled.reduce((a, r)=>a + (r.pnlUsd || 0), 0).toFixed(2)),
        target: 30,
        epoch: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ARM_EPOCH"],
        sqn: sq.sqn,
        sqnTrim: sq.sqnTrim,
        meanR: sq.meanR,
        expPct: sq.expPct
    };
}
async function nearMissState() {
    await load();
    const dk = dayKey();
    const gateArm = armRow("nm-gate", "NEAR-MISS · gate-blocked cohort (memory-gate suppressed, hypothetical admission)", rows.filter((r)=>r.tier === "GATE"));
    const gateReady = gateArm.n >= 30;
    return {
        ts: Date.now(),
        epoch: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ARM_EPOCH"],
        caps: {
            dailyScore: dayCount.get(`SCORE|${dk}`) ?? 0,
            dailyBarrier: dayCount.get(`BARRIER|${dk}`) ?? 0,
            dailyGate: dayCount.get(`GATE|${dk}`) ?? 0,
            dailyCap: DAILY_CAP_PER_TIER,
            dedupMin: DEDUP_MS / 60_000,
            maxOpenPerTier: MAX_OPEN_PER_TIER,
            bandMult: BARRIER_BAND_MULT
        },
        arms: [
            armRow("nm-score", "NEAR-MISS · score band 0.85-1.0×effMin (paper, hypothetical admission)", rows.filter((r)=>r.tier === "SCORE")),
            armRow("nm-barrier", "NEAR-MISS · barrier band t1r (cap, 1.5×cap] (paper, hypothetical 1.5×cap barrier — cap is regime-adaptive when volBarrierAdaptive=1)", rows.filter((r)=>r.tier === "BARRIER")),
            gateArm
        ],
        open: {
            score: rows.filter((r)=>r.tier === "SCORE" && !r.outcome).length,
            barrier: rows.filter((r)=>r.tier === "BARRIER" && !r.outcome).length,
            gate: rows.filter((r)=>r.tier === "GATE" && !r.outcome).length
        },
        gateDecision: {
            n: gateArm.n,
            expPct: gateArm.expPct,
            sqn: gateArm.sqn,
            sqnTrim: gateArm.sqnTrim,
            ready: gateReady,
            verdict: !gateReady ? null : (gateArm.expPct ?? 0) > 0 ? "FILE_KNOB_ADJUST" : "KEEP_GATE"
        },
        recent: [
            ...rows
        ].sort((a, b)=>b.at - a.at).slice(0, 20).map((r)=>({
                ...r
            }))
    };
}
async function nearMissReady() {
    await load();
}
}),
"[project]/src/lib/vol-percentile.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "adaptiveBarrierCap",
    ()=>adaptiveBarrierCap,
    "realizedVolPctile",
    ()=>realizedVolPctile
]);
// ── v10.14 REGIME-ADAPTIVE BARRIER CAP — realized-vol percentile (server-only) ──
// SUPERVISOR proposal 2026-09-19T06:51Z (terminal thought, phase=propose),
// operator APPROVE 2026-09-19T08:56Z bridge msg 861802419
// («پیشنهادات سوپروایزر رو کامل و مهندسی انجام بده»).
//
// WHY: both RAW-CAL issuance droughts (139min + 141min) had the identical
// signature — sweep healthy (best |score| 68 vs MIN_SCORE 35) while 100% of
// the blocks were vol-scaled-barrier t1r 724-4932m vs the FIXED 240m cap.
// In compression regimes the barrier math says "slow" and the cap kills every
// candidate — yet the cohort's best trade (GUSDT BREAKOUT TP3 +95.2%) is
// exactly a compression-expansion capture. Literature (validated via web
// search 2026-09-19): Lopez de Prado's triple-barrier vertical barrier is
// widely critiqued as a fixed-time constant; practitioners set it from
// holding-time / vol distribution percentiles; volatility compression
// precedes expansion.
//
// MECHANISM (exact proposal formula):
//   volPctile = realized-vol percentile of the symbol vs its own 30d history
//   cap_m     = base                                    if volPctile >= 30
//             = clamp(base*(1 + 2*(30-volPctile)/30), base, 3*base) otherwise
//   (base 240 → ceiling 720m at volPctile 0, linear in between — the proposal
//   hard-codes [240, 720]; 3×base reproduces that at the default knob and
//   stays coherent if the operator ever moves volBarrierCapMin.)
//
// FAIL-OPEN POLICY: any fetch/math failure → null → the caller falls back to
// the FIXED base cap (exact pre-change behavior). A null volPctile NEVER
// widens the cap. Results cached 30min per symbol (the regime is a slow
// variable; the deploy path must not pay a klines round-trip per evaluation),
// failures cached 5min so a Binance hiccup cannot hammer the feed.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
;
const CACHE_TTL_MS = 30 * 60_000; // 30min — regime is a slow variable
const FAIL_TTL_MS = 5 * 60_000; // 5min — backoff after a failed fetch
const BARS_1H = 720; // 30d of hourly bars (single ≤1000-limit request)
const SIGMA_WINDOW = 24; // realized-vol window = 24h of hourly returns
const MIN_SAMPLES = 200; // need a real distribution to rank against
const cache = new Map(); // symbol → {at, volPctile}
function stdev(xs) {
    const n = xs.length;
    if (n < 2) return 0;
    const m = xs.reduce((a, b)=>a + b, 0) / n;
    const v = xs.reduce((a, b)=>a + (b - m) * (b - m), 0) / n; // population (ddof 0)
    return Math.sqrt(v);
}
async function realizedVolPctile(symbol) {
    const hit = cache.get(symbol);
    if (hit && Date.now() - hit.at < (hit.volPctile === null ? FAIL_TTL_MS : CACHE_TTL_MS)) return hit.volPctile;
    try {
        const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchKlines"])(symbol, "1h", BARS_1H);
        if (!candles || candles.length < SIGMA_WINDOW + MIN_SAMPLES) throw new Error(`insufficient history ${candles?.length ?? 0}`);
        const rets = [];
        for(let i = 1; i < candles.length; i++){
            const prev = candles[i - 1].close;
            if (prev > 0) rets.push((candles[i].close - prev) / prev);
        }
        // rolling 24h realized vol at each hourly step
        const vols = [];
        for(let i = SIGMA_WINDOW; i < rets.length; i++)vols.push(stdev(rets.slice(i - SIGMA_WINDOW, i)));
        if (vols.length < MIN_SAMPLES) throw new Error(`insufficient vol samples ${vols.length}`);
        const cur = vols[vols.length - 1];
        if (!(cur > 0)) throw new Error("degenerate current vol");
        let below = 0;
        for (const v of vols)if (v <= cur) below++;
        const pct = below / vols.length * 100;
        cache.set(symbol, {
            at: Date.now(),
            volPctile: pct
        });
        return pct;
    } catch  {
        cache.set(symbol, {
            at: Date.now(),
            volPctile: null
        });
        return null;
    }
}
function adaptiveBarrierCap(baseCap, volPctile) {
    if (!(volPctile >= 0) || !(volPctile <= 100)) return baseCap; // fail-closed
    if (volPctile >= 30) return baseCap;
    const relaxed = baseCap * (1 + 2 * (30 - volPctile) / 30);
    return Math.min(baseCap * 3, Math.max(baseCap, relaxed));
}
}),
"[project]/src/lib/research-shadow.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RESEARCH_PARAMS",
    ()=>RESEARCH_PARAMS,
    "buildResearchLadder",
    ()=>buildResearchLadder,
    "journalResearchShadowDeploy",
    ()=>journalResearchShadowDeploy,
    "researchShadowSummary",
    ()=>researchShadowSummary,
    "settleResearchShadow",
    ()=>settleResearchShadow
]);
// ── FlowRadar Neo v8.4 R5 RESEARCH-SHADOW (server-only) ──
// Module-performance audit 2026-09-11: the flow-factor research produced an
// optimum the live gate CONTRADICTS — slAtr 1.2 (live 1.8), rrScale 1.15
// (live 0.75), BE-trail OFF (live ON). Flipping the live book to unproven
// parameters would be reckless; keeping the contradictory ones without an
// experiment would be blind. The engineering compromise is a SHADOW A/B:
//   · every deployment journals a research-aligned ladder next to the live one
//   · at settle time a 1m-candle replay scores BOTH geometries with the SAME
//     runner-only model (first touch of stop vs final target, close at the
//     settling mark if neither touches; fees excluded — symmetric across arms)
//   · verdicts append to db/research-shadow/{deploy,settle}.ndjson
// The ledger answers "would the research params have beaten the live book?"
// with real market paths — the adoption evidence the R6-style gate needs.
// No Prisma schema change (restore post-mortem rule): file-backed journal.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
;
;
;
const RESEARCH_PARAMS = {
    slAtrMult: 1.2,
    rrScale: 1.15,
    beTrailPct: 0
};
const DIR = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"])(process.cwd(), "db", "research-shadow");
function jline(file, obj) {
    try {
        (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"])(DIR, {
            recursive: true
        });
        (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["appendFileSync"])((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"])(DIR, file), JSON.stringify(obj) + "\n");
    } catch  {
    /* best-effort telemetry */ }
}
function buildResearchLadder(entry, isLong, atrPct, slMult, volGeoSlMult, rawUnscaledRR) {
    const slDistPct = Math.min(5, Math.max(0.7, RESEARCH_PARAMS.slAtrMult * atrPct * slMult * volGeoSlMult)) / 100;
    const rr = Number(Math.min(4.2, Math.max(1.8, rawUnscaledRR * RESEARCH_PARAMS.rrScale)).toFixed(1));
    const risk = entry * slDistPct;
    const stop = isLong ? entry - risk : entry + risk;
    const tp3 = isLong ? entry + risk * rr : entry - risk * rr;
    return {
        slDistPct: Number((slDistPct * 100).toFixed(3)),
        rr,
        stop: Number(stop.toFixed(stop > 100 ? 2 : 6)),
        tp3: Number(tp3.toFixed(tp3 > 100 ? 2 : 6))
    };
}
function journalResearchShadowDeploy(rec) {
    jline("deploy.ndjson", rec);
}
/** R× pnl for one arm: stop → −1R · final target → +rr R · neither → mark R. */ function pnlR(exit, rr) {
    return exit === "SL" ? -1 : exit === "TP3" ? rr : 0; // MARK resolved below as passthrough
}
async function settleResearchShadow(input) {
    try {
        const deployFile = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"])(DIR, "deploy.ndjson");
        if (!(0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["existsSync"])(deployFile)) return;
        const lines = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(deployFile, "utf8").trim().split("\n");
        let rec = null;
        for(let i = lines.length - 1; i >= 0; i--){
            try {
                const r = JSON.parse(lines[i]);
                if (r.serial === input.serial) {
                    rec = r;
                    break;
                }
            } catch  {
            /* skip torn line */ }
        }
        if (!rec) return; // deployed before R5 went live — nothing to settle
        const spanMin = Math.ceil((input.closedAt.getTime() - input.createdAt.getTime()) / 60_000) + 2;
        const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(input.symbol, "1m", Math.min(1000, Math.max(60, spanMin + 5))).catch(()=>[]);
        if (!candles || candles.length === 0) return;
        const inWindow = candles.filter((c)=>c.openTime >= input.createdAt.getTime() - 60_000 && c.openTime <= input.closedAt.getTime() + 60_000);
        if (inWindow.length === 0) return;
        const isLong = input.direction === "LONG";
        // first-touch walk (1m granularity): SL and TP3 checked on the same candle —
        // a candle spanning both resolves CONSERVATIVELY to SL (pessimistic for both arms)
        const firstTouch = (stop, tp3, rr)=>{
            for (const c of inWindow){
                const hitSl = isLong ? c.low <= stop : c.high >= stop;
                const hitTp = isLong ? c.high >= tp3 : c.low <= tp3;
                if (hitSl) return {
                    exit: "SL",
                    pnlR: -1
                };
                if (hitTp) return {
                    exit: "TP3",
                    pnlR: rr
                };
            }
            const last = inWindow[inWindow.length - 1];
            const move = (last.close - input.entry) / input.entry * (isLong ? 1 : -1);
            const riskDist = Math.abs(input.entry - stop) / input.entry || 0.0001; // fractional 1R distance
            return {
                exit: "MARK",
                pnlR: Number((move / riskDist).toFixed(2))
            };
        };
        const liveT = firstTouch(input.live.stop, input.live.tp3, input.live.rr);
        const resT = firstTouch(rec.research.stop, rec.research.tp3, rec.research.rr);
        const verdict = {
            serial: input.serial,
            symbol: input.symbol,
            direction: input.direction,
            finalStatus: input.finalStatus,
            settledAt: new Date().toISOString(),
            candles: inWindow.length,
            live: {
                exit: liveT.exit,
                pnlR: liveT.exit === "MARK" ? liveT.pnlR : pnlR(liveT.exit, input.live.rr)
            },
            research: {
                exit: resT.exit,
                pnlR: resT.exit === "MARK" ? resT.pnlR : pnlR(resT.exit, rec.research.rr)
            },
            deltaR: Number(((resT.exit === "MARK" ? resT.pnlR : pnlR(resT.exit, rec.research.rr)) - (liveT.exit === "MARK" ? liveT.pnlR : pnlR(liveT.exit, input.live.rr))).toFixed(2)),
            model: "runner-only · 1m first-touch · SL-pessimistic · fees-excluded"
        };
        jline("settle.ndjson", verdict);
    } catch  {
    /* telemetry must never break settlement */ }
}
function researchShadowSummary() {
    const file = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"])(DIR, "settle.ndjson");
    const empty = {
        settled: 0,
        researchWins: 0,
        liveWins: 0,
        ties: 0,
        sumDeltaR: 0,
        avgDeltaR: null,
        byExit: {}
    };
    if (!(0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["existsSync"])(file)) return empty;
    try {
        const rows = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(file, "utf8").trim().split("\n").map((l)=>JSON.parse(l));
        const byExit = {};
        let sum = 0;
        let rw = 0;
        let lw = 0;
        let ties = 0;
        for (const r of rows){
            sum += r.deltaR;
            if (r.deltaR > 0.05) rw++;
            else if (r.deltaR < -0.05) lw++;
            else ties++;
            const k = `${r.live.exit}→${r.research.exit}`;
            byExit[k] = (byExit[k] ?? 0) + 1;
        }
        return {
            settled: rows.length,
            researchWins: rw,
            liveWins: lw,
            ties,
            sumDeltaR: Number(sum.toFixed(2)),
            avgDeltaR: rows.length ? Number((sum / rows.length).toFixed(3)) : null,
            byExit
        };
    } catch  {
        return empty;
    }
}
}),
"[project]/src/lib/governor.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGovernorState",
    ()=>getGovernorState,
    "maybeAutoGovernor",
    ()=>maybeAutoGovernor,
    "runGovernorCycle",
    ()=>runGovernorCycle,
    "setGovernorConfig",
    ()=>setGovernorConfig
]);
// ── NEXUS//SIGNALS AI GOVERNOR (server-only, v6.0) ──
// The LLM analyst as an INDEPENDENT decision-maker wired into the system core:
// every cycle it receives a fully GROUNDED telemetry bundle (prices, regimes,
// flow coverage, realized memory, learner verdicts, gate state, open risk) and
// returns strict JSON decisions. The core validates every decision against the
// existing clamps, applies it, and audits it as an ENGINE event + log ring.
// The governor can NEVER break the honesty contract — it only tunes the same
// clamped tunables an operator has, and can trigger the history learner.
//
// ── v6.0 FULL AUTONOMY (operator mandate: «هیچ حالت دستی برای یادگیری و
// استقرار نباید باشه») — the governor is PERMANENTLY ENGAGED: the manual
// toggle/POST endpoints are gone, `enabled` is forced true, and the only
// triggers are the autonomous scheduler + supervisor nudges. Deployment
// control is agent-controlled, clamped, and audited — never hand-driven.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$calibration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/calibration.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/backtest.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/triggers.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/regime.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ttl$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ttl-gate.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
const KEY = "governor";
const KEY_LOG = "governor.log";
const KEY_HYST = "governor.hysteresis";
const LOG_CAP = 24;
// v6.2 GOVERNOR HYSTERESIS (architecture review P2):
// Two autonomous actuators (LLM decisions, drought relief, supervisor quality
// valve) can fight over the same knob cycle-after-cycle — the observed
// pathology was MIN_SCORE being ratcheted up by quality drift then forced
// down by drought relief within a single hour, oscillating the deployment
// pipeline. Every knob now carries a cooldown: once changed, it cannot be
// changed AGAIN (to a different value) for 90 minutes. Safety relief always
// fires (lockout beats thrash), but it records into the same map so the
// quality valve cannot immediately undo it.
// v6.3: the DYNAMIC RISK knobs (SL ATR multiple, RR scale, regime guard) join
// the same hysteresis domain — one flip-flopping risk profile is worse than none.
const KNOB_COOLDOWN_MS = 90 * 60_000;
const HYST_ACTIONS = new Set([
    "set_min_score",
    "set_flow_veto",
    "set_flow_shortlist",
    "set_universe",
    "set_ttl_extend_max",
    "set_ttl_extend_minutes",
    "set_ttl_near_tp",
    "set_sl_atr_mult",
    "set_rr_scale",
    "set_regime_guard",
    "set_max_active",
    "set_risk_per_trade"
]);
async function getHysteresis() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY_HYST
            }
        });
        if (row) return JSON.parse(row.value);
    } catch  {
    /* fresh */ }
    return {};
}
async function putHysteresis(map) {
    // keep only live entries so the row never grows
    const live = Object.fromEntries(Object.entries(map).filter(([, v])=>Date.now() - v.at < 7 * 86_400_000));
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY_HYST
        },
        create: {
            key: KEY_HYST,
            value: JSON.stringify(live)
        },
        update: {
            value: JSON.stringify(live)
        }
    });
}
function knobCooling(hyst, action) {
    const rec = hyst[action];
    if (!rec) return {
        cooling: false,
        minsLeft: 0
    };
    const elapsed = Date.now() - rec.at;
    return elapsed < KNOB_COOLDOWN_MS ? {
        cooling: true,
        minsLeft: Math.ceil((KNOB_COOLDOWN_MS - elapsed) / 60_000)
    } : {
        cooling: false,
        minsLeft: 0
    };
}
const DEFAULTS = {
    enabled: true,
    intervalMin: 45,
    maxActions: 2,
    cycles: 0,
    lastRunAt: null
};
async function getGovernorState() {
    let cfg = {
        ...DEFAULTS
    };
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) cfg = {
            ...cfg,
            ...JSON.parse(row.value)
        };
    } catch  {
    /* defaults */ }
    // v6.0: the governor is PERMANENTLY ENGAGED — a stale persisted `enabled:
    // false` (pre-autonomy era) can never put it back on manual standby.
    cfg.enabled = true;
    let log = [];
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY_LOG
            }
        });
        if (row) log = JSON.parse(row.value);
    } catch  {
    /* empty */ }
    return {
        ...cfg,
        running: cycleInFlight,
        log
    };
}
async function setGovernorConfig(patch) {
    const cur = await getGovernorState();
    const next = {
        ...cur,
        enabled: true,
        intervalMin: patch.intervalMin ? Math.min(240, Math.max(10, patch.intervalMin)) : cur.intervalMin,
        maxActions: patch.maxActions ? Math.min(3, Math.max(1, patch.maxActions)) : cur.maxActions
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
    return {
        ...next,
        running: cycleInFlight,
        log: cur.log
    };
}
// ── deploy-rate probe — the anti-lockup sensor ──
// v5.2: the governor ratcheting MIN_SCORE to the clamp ceiling produced a
// 12h signal drought (0 deploys). Every cycle now MEASURES deployment flow and
// (a) reports it to the LLM, (b) blocks raises on tiny samples, (c) forces a
// step-down when the engine has been silent too long. Signals must flow.
async function deployRate() {
    const since = new Date(Date.now() - 6 * 3600_000);
    const [recent, last] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                createdAt: {
                    gte: since
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findFirst({
            orderBy: {
                createdAt: "desc"
            },
            select: {
                createdAt: true
            }
        })
    ]);
    return {
        deploys6h: recent,
        hoursSinceLast: last ? (Date.now() - new Date(last.createdAt).getTime()) / 3600_000 : null
    };
}
const MIN_SCORE_RELIEF_FLOOR = 42; // engine never locks itself above this
const EVIDENCE_MIN_SETTLED = 8; // raises need at least this many settled outcomes
const MIN_SCORE_QUALITY_CEILING = 45; // supervisor never tightens above this
const SUPERVISOR_TRAILING_N = 15; // trailing settled window for WR drift
const SUPERVISOR_WR_FLOOR = 15; // below this → quality drift
// ── grounded telemetry bundle — every line is a MEASURED number ──
async function buildGovernorContext() {
    const [gate, cal, bt, learned, learnerAuto, flow, bus, regimeTel] = await Promise.all([
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$calibration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCalibration"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getBacktest"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["learnedGateAllows"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getLearnerAutoState"])(),
        Promise.resolve((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFlowStatus"])()),
        Promise.resolve((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTriggerBusSummary"])()),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRegimeTelemetry"])()
    ]);
    const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            status: true,
            strategy: true,
            pnlPercent: true,
            reachedTp: true,
            marginUsd: true,
            tags: true
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 200
    });
    // v5.4 TP-proven WR — TP1/TP2/TP3 touches are wins (matches analytics)
    const realizedWr = settled.length ? settled.filter((s)=>s.pnlPercent > 0 || s.reachedTp >= 1).length / settled.length * 100 : 0;
    // v6.3 RISK LEDGER inputs — stop-rate + bucket USD so the LLM tunes SL/RR from evidence
    const slSigs = settled.filter((s)=>s.status === "SL");
    const tpSigs = settled.filter((s)=>s.status === "TP3");
    const stopRate = settled.length ? slSigs.length / settled.length * 100 : null;
    const slNetUsd = slSigs.reduce((a, s)=>a + s.marginUsd * s.pnlPercent / 100, 0);
    const tp3NetUsd = tpSigs.reduce((a, s)=>a + s.marginUsd * s.pnlPercent / 100, 0);
    // v6.3 STRATEGY LEDGER — net expectancy per strategy (profit-first telemetry)
    const stratAcc = new Map();
    for (const s of settled){
        const c = stratAcc.get(s.strategy ?? "?") ?? {
            n: 0,
            pct: 0,
            usd: 0
        };
        c.n++;
        c.pct += s.pnlPercent;
        c.usd += s.marginUsd * s.pnlPercent / 100;
        stratAcc.set(s.strategy ?? "?", c);
    }
    const strategyLedger = [
        ...stratAcc.entries()
    ].map(([strategy, c])=>({
            strategy,
            n: c.n,
            expectancy: Number((c.pct / c.n).toFixed(2)),
            netUsd: Number(c.usd.toFixed(2))
        })).sort((a, b)=>b.netUsd - a.netUsd);
    const open = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "ACTIVE",
                    "TP1",
                    "TP2"
                ]
            }
        },
        select: {
            symbol: true,
            direction: true,
            confidence: true,
            pnlPercent: true,
            serial: true
        },
        take: 8
    });
    const assets = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
        orderBy: {
            volume24h: "desc"
        },
        take: 10
    });
    const rate = await deployRate();
    const ttlTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ttl$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTtlTelemetry"])();
    const expiredPost = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.groupBy({
        by: [
            "afterlife"
        ],
        _count: true,
        where: {
            status: "EXPIRED"
        }
    });
    const expPost = Object.fromEntries(expiredPost.map((r)=>[
            r.afterlife ?? "none",
            r._count
        ]));
    const expTotal = Object.values(expPost).reduce((a, b)=>a + b, 0);
    const expWon = (expPost["TP1_HIT"] ?? 0) + (expPost["TP2_HIT"] ?? 0) + (expPost["TP3_HIT"] ?? 0);
    const lines = [
        "TELEMETRY BUNDLE (all numbers measured — none invented):",
        // v6.3: the clamp table grounds every knob request — requesting outside a
        // legal range wastes an action (the MIN_SCORE-constancy root cause)
        `0. CLAMPS (hard ranges the core enforces — request values INSIDE these): ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["describeClamps"])()}`,
        `1. GATES: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["describeGate"])(gate)}`,
        `2. REALIZED MEMORY: ${settled.length} settled live signals, realized WR ${realizedWr.toFixed(1)}%, NET expectancy ${(settled.reduce((a, s)=>a + s.pnlPercent, 0) / Math.max(1, settled.length)).toFixed(2)}%/trade`,
        `3. LEARNED GATE: ${learned.allowed ? "AUTO-DEPLOY ALLOWED" : "AUTO-DEPLOY SUPPRESSED"} — ${learned.reason}`,
        bt ? `4. BACKTEST LEARNER (last replay ${bt.ranAt.slice(0, 16)}Z): n=${bt.n}, WR ${bt.winRate}%, Wilson-LB ${bt.wilsonLB}%, expectancy ${bt.avgNetPct}%/trade NET, equity $${bt.equityEnd} — verdict: ${bt.verdict}` : "4. BACKTEST LEARNER: no replay stored yet",
        `5. LEARNER SCHEDULER: ${learnerAuto.enabled ? `auto every ${learnerAuto.intervalHours}h` : "auto disabled"}, last run ${learnerAuto.lastRunAt ?? "never"}, running=${learnerAuto.running}`,
        `6. CALIBRATION: ${cal.status} (${cal.settled}/${cal.target} settled), rows=${cal.rows.length} — v6.3 weights derive from NET-PNL expectancy (avg %/trade per factor), not raw win rate`,
        `7. FLOW COVERAGE: ${flow.covered} symbols live (CVD/OI/funding/crowd measured per symbol)`,
        `8. TRIGGER BUS: ${JSON.stringify(bus.counts)} — L1 sweeps act as event-driven candidate spawns`,
        `8b. DEPLOY RATE / CAPACITY: ${rate.deploys6h} signals deployed in last 6h${rate.hoursSinceLast !== null ? `, last deploy ${rate.hoursSinceLast.toFixed(1)}h ago` : ", none ever"} — open ${open.length}/${gate.maxActive} capacity slots (set_max_active owns the cap). 0 deploys WITH free slots means the engine is LOCKED, loosen gates rather than raise them; 0 deploys AT capacity is normal, not a lockup`,
        `8c. TTL-GATE (dynamic expiry): policy +${gate.ttlExtendMinutes}m ×≤${gate.ttlExtendMax} near-TP band ${gate.ttlNearTpPct}% — granted ${ttlTel.extended} extensions → TP ${ttlTel.tpAfter} / SL ${ttlTel.slAfter} / re-expired ${ttlTel.reExpired}, $${ttlTel.capturedUsd} captured · DENIED ${ttlTel.denied} expiries (${ttlTel.deniedNearTp} with next TP inside 2× band — if this stays high while post-mortem wins, widen the band via set_ttl_near_tp) · EXPIRED post-mortem: ${expWon}/${expTotal} would have hit TP within 48h after TTL (${expTotal ? Math.round(expWon / Math.max(1, expTotal) * 100) : 0}%) — tune set_ttl_extend_max/minutes/set_ttl_near_tp from this evidence`,
        // v6.3 REGIME LEDGER — realized per-regime outcomes so the guard level is evidence-tuned
        `8d. REGIME LEDGER (realized outcomes per regime, guard L${gate.regimeGuard}): ${Object.entries(regimeTel).length ? Object.entries(regimeTel).map(([r, c])=>`${r} n=${c.n} WR=${c.n ? Math.round(c.wins / c.n * 100) : 0}% $${c.pnlUsd >= 0 ? "+" : ""}${c.pnlUsd.toFixed(2)}`).join(" · ") : "warming up (no closes yet)"} — v9.4 ASYMMETRIC semantics (EQ-100): guard L1+ rules CHOP direction-split — SHORT admitted through the tax ladder (ledger +$40.49 W41+42), LONG hard-vetoed (ledger −$108.09 W41+42 / −$111.22 Oct), BREAKOUT/MOMENTUM vetoed; L2 additionally adds BTC-spillover + vol MR veto. Do NOT soften to L0 to "un-veto" CHOP LONGs — L0 re-opens the book's worst losing cohort; only L0 with fresh positive CHOP-LONG evidence justifies it`,
        // v6.3 RISK LEDGER — stop-rate + bucket USD so SL distance / RR scale are evidence-tuned
        `8e. RISK LEDGER: stop-rate ${stopRate !== null ? `${stopRate.toFixed(0)}% (${slSigs.length}/${settled.length} settled died at SL)` : "no settles yet"}, SL bucket $${slNetUsd.toFixed(2)} vs full-TP bucket $${tp3NetUsd.toFixed(2)} — stops now ${gate.slAtrMult}×ATR, ladder scale ×${gate.rrScale.toFixed(2)}. High stop-rate + heavy SL bleed → widen via set_sl_atr_mult; trades dying of TIME with rare stops → tighten. TP3 conversion ${tpSigs.length}/${settled.length} — greedy targets (rare TP3, SL-dominant) → trim via set_rr_scale`,
        // v6.3 PROFIT-FIRST STRATEGY LEDGER — expectancy per strategy (win rate lies:
        // a 28% WR strategy bleeding −13%/trade and a 54% WR one printing +8%/trade
        // can share the same "WR" narrative; net PNL cannot)
        `8f. STRATEGY LEDGER (net expectancy per strategy — profit is the criterion, not win count): ${strategyLedger.length ? strategyLedger.map((r)=>`${r.strategy} n=${r.n} exp ${r.expectancy >= 0 ? "+" : ""}${r.expectancy}%/trade $${r.netUsd >= 0 ? "+" : ""}${r.netUsd.toFixed(0)}`).join(" · ") : "no settles yet"} — negative-expectancy strategies should be suppressed/tightened (the memory gate auto-suppresses below −2%/trade over n≥12)`,
        open.length ? `9. OPEN RISK: ${open.map((o)=>`NX-${String(o.serial).padStart(4, "0")} ${o.symbol} ${o.direction} ${o.pnlPercent >= 0 ? "+" : ""}${o.pnlPercent.toFixed(1)}%`).join(" · ")}` : "9. OPEN RISK: no open signals",
        `10. UNIVERSE: ${assets.map((a)=>`${a.symbol} ${a.change24h >= 0 ? "+" : ""}${a.change24h.toFixed(1)}%${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekRegime"])(a.symbol) ? `[${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekRegime"])(a.symbol).regime}]` : ""}`).join(", ")}`
    ];
    // v8.4.3 VERDICT-CORE WIRING (operator: «چرا از نتایج Verdict core استفاده
    // نمیشه؟») — the deep-learn findings now ground the governor's tuning context:
    // each cycle reads the latest lessons from the gate-journal research desk so
    // knob decisions can weigh the core's own pattern findings. Dynamic import —
    // verdict.ts dynamically imports engine.ts which imports this module.
    try {
        const { getVerdictCoreState } = await __turbopack_context__.A("[project]/src/lib/verdict.ts [app-route] (ecmascript, async loader)");
        const vc = await getVerdictCoreState();
        if (vc.lastRunAt) {
            const top = vc.lessons.slice(0, 3).map((l)=>`${l.pattern} → ${l.action} (conf ${l.confidence}%, ${l.label})`).join(" · ");
            lines.push(`11. VERDICT-CORE LESSONS (deep-learn over the gate journal, cycle #${vc.runs} @ ${vc.lastRunAt.slice(0, 16)}Z): ${top || "no lessons stored yet"} — these are the core's own recurring confirm/reject patterns; weigh them in your tuning rationale alongside the ledgers above`);
        }
    } catch  {}
    // v9.1 CENTRAL-INTELLIGENCE EXTENSIONS (operator mandate 2026-09-13) — the
    // governor must KNOW about the two new authority layers before it tunes:
    // radar direct-authority deploys and the RAW-CAL capture cohort (both ride
    // OUTSIDE the generic quality gates, so the governor must not read their
    // settles as evidence about the gate threshold itself).
    try {
        const { readPersistedPumpPerformance } = await __turbopack_context__.A("[project]/src/lib/pump-performance.ts [app-route] (ecmascript, async loader)");
        const { rawCalStatus } = await __turbopack_context__.A("[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)");
        const [pp, rc] = await Promise.all([
            readPersistedPumpPerformance(),
            rawCalStatus()
        ]);
        if (pp) {
            const k = pp.perKind.map((r)=>`${r.kind} ${r.success}/${r.resolved} (${r.successRatePct}%)`).join(" · ");
            lines.push(`12. PUMP/DUMP RADAR JOURNAL: ${pp.headline} per-kind: ${k}; 24h declared ${pp.window24h.declared}; radar-spawned signals ${pp.totals.spawnedSignals} — radar deploys carry DIRECT AUTHORITY (evidence conviction ≥78, engine quality gates bypassed); judge the radar cohort by its own ledger, not the MIN_SCORE gate`);
        }
        const raw13 = `13. RAW-CAL CAPTURE: ${rc.armed ? `ARMED — unfiltered RAW-CAL records issue every ≥${rc.spacingMin}min (open ${rc.openRaw}/${rc.maxOpen}, lifetime ${rc.issuedTotal}, settled ${rc.settledRaw}${rc.rawWinRatePct !== null ? `, WR ${rc.rawWinRatePct}%` : ""})` : "OFF"} — the EPOCH-2 book is ${rc.settledN}/${rc.target} settled; while ARMED, EXCLUDE RAW-CAL-tagged settles from gate-quality reasoning (they sample rejected flows by design) and expect the R6 calibration lift at n≥${rc.target}`;
        // v9.3 sample-quality gate — the governor also knows whether the raw cohort
        // is HEALTHY enough for the R6 recalibration to rest on (advisory only)
        try {
            const { computeRawcalQuality } = await __turbopack_context__.A("[project]/src/lib/rawcal-quality.ts [app-route] (ecmascript, async loader)");
            const q = await computeRawcalQuality();
            lines.push(`${raw13} · SAMPLE QUALITY ${q.gate.verdict}: healthy ${q.healthyPct ?? "—"}% (floor ${q.gate.healthFloor}), informative ${q.informativePct ?? "—"}%, snapshots ${q.snapshotPct ?? "—"}%${q.warnings.length ? `, watch: ${q.warnings[0]}` : ", no issues"}`);
        } catch  {
            lines.push(raw13);
        }
    } catch  {}
    return lines.join("\n");
}
/** Rule-based fallback when the neural link is down — still grounded, still clamped. */ function heuristicDecisions(bt, realizedWr, settledCount, gateMinScore, gate, stopRate, slNetUsd) {
    // v6.3: stop-bleed heuristic — when nearly half of settles die at the stop
    // AND the SL bucket is the dominant USD bleed, widen the ATR multiple one notch.
    if (stopRate !== null && stopRate >= 45 && slNetUsd <= -20 && gate.slAtrMult < 2.1) {
        return [
            {
                action: "set_sl_atr_mult",
                value: Number(Math.min(2.5, gate.slAtrMult + 0.25).toFixed(2)),
                rationale: `HEURISTIC: stop-rate ${stopRate.toFixed(0)}% with SL bucket $${slNetUsd.toFixed(2)} — noise is taking trades out, widening stops ${gate.slAtrMult}→${Math.min(2.5, gate.slAtrMult + 0.25).toFixed(2)}×ATR`
            }
        ];
    }
    if (bt && bt.n >= 20 && bt.wilsonLB < 30 && gateMinScore > 25) {
        return [
            {
                action: "set_min_score",
                value: Math.max(25, gateMinScore - 3),
                rationale: `HEURISTIC: backtest Wilson-LB ${bt.wilsonLB}% <30 with n=${bt.n} — tighten threshold is wrong direction, loosen minScore to admit higher-quality grid only if flow confirms`
            }
        ];
    }
    if (settledCount >= 10 && realizedWr < 25 && gateMinScore < 55) {
        return [
            {
                action: "set_min_score",
                value: Math.min(60, gateMinScore + 5),
                rationale: `HEURISTIC: realized WR ${realizedWr.toFixed(0)}% over ${settledCount} settled <25% — raise MIN_SCORE to filter marginal confluence`
            }
        ];
    }
    if (!bt || Date.now() - new Date(bt.ranAt).getTime() > 12 * 3600_000) {
        return [
            {
                action: "run_backtest",
                rationale: "HEURISTIC: learner evidence stale (>12h) — refresh the replayed-history mean"
            }
        ];
    }
    return [
        {
            action: "no_op",
            rationale: `HEURISTIC: no dominant signal to act on — WR ${realizedWr.toFixed(0)}%, gates ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["describeGate"])(gate)}`
        }
    ];
}
let cycleInFlight = false;
// v8.4.1 N2 (operator mandate «هوش غیرفعال شده رو فعال و پایدار کن»): the
// supervisor fires a governor cycle every ~2min and each one attempted an LLM
// call — ~30 calls/h of background pressure against a provider that is
// throttling (429). Doctrine: the operator tier comes first. The governor now
// attempts the MODEL at most once per 15min; between attempts the designed
// rule-based heuristic speaks (still grounded, still clamped, honestly
// labeled). Decision capability is unchanged — only the LLM burn is spaced.
const GOVERNOR_LLM_MIN_SPACING_MS = 15 * 60_000;
let lastGovernorLlmAt = 0;
async function runGovernorCycle(trigger = "auto") {
    if (cycleInFlight) return {
        ok: false,
        summary: "governor cycle already running"
    };
    cycleInFlight = true;
    try {
        const [gateBefore, bt] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getBacktest"])()
        ]);
        const context = await buildGovernorContext();
        const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                status: {
                    in: [
                        "TP1",
                        "TP2",
                        "TP3",
                        "SL",
                        "EXPIRED",
                        "CLOSED"
                    ]
                }
            },
            orderBy: {
                createdAt: "desc"
            },
            select: {
                status: true,
                pnlPercent: true,
                reachedTp: true,
                marginUsd: true,
                tags: true
            },
            take: 200
        });
        const realizedWr = settled.length ? settled.filter((s)=>s.pnlPercent > 0 || s.reachedTp >= 1).length / settled.length * 100 : 0;
        // v6.3 RISK LEDGER inputs for the heuristic fallback (stop-bleed rule)
        const slSigs = settled.filter((s)=>s.status === "SL");
        const stopRate = settled.length ? slSigs.length / settled.length * 100 : null;
        const slNetUsd = slSigs.reduce((a, s)=>a + s.marginUsd * s.pnlPercent / 100, 0);
        // v5.3: dynamic import — if the AI bridge is broken, the governor still runs
        // on its rule-based heuristic instead of crashing the whole engine chain.
        let rawDecisions;
        let label;
        if (Date.now() - lastGovernorLlmAt < GOVERNOR_LLM_MIN_SPACING_MS) {
            rawDecisions = heuristicDecisions(bt, realizedWr, settled.length, gateBefore.minScore, gateBefore, stopRate, slNetUsd);
            label = "HEURISTIC";
        } else {
            lastGovernorLlmAt = Date.now(); // the attempt itself consumes budget — failures count too
            try {
                const { aiGovernorDecisions } = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)");
                const r = await aiGovernorDecisions(context, heuristicDecisions(bt, realizedWr, settled.length, gateBefore.minScore, gateBefore, stopRate, slNetUsd));
                rawDecisions = r.decisions;
                label = r.label;
            } catch (bridgeErr) {
                console.error("[governor] AI bridge unavailable — heuristic fallback", bridgeErr);
                rawDecisions = heuristicDecisions(bt, realizedWr, settled.length, gateBefore.minScore, gateBefore, stopRate, slNetUsd);
                label = "HEURISTIC";
            }
        }
        // ── evidence gate (v5.2): raising MIN_SCORE on a tiny settled sample is
        // overfitting to noise — it was exactly this loop that locked the engine
        // at MIN_SCORE 60 for 12h on n=2. Raises need ≥8 settled outcomes.
        // ── v6.7 BO-EXP TRIAL FREEZE (operator directive 2026-09-08): while the
        // BREAKOUT conditional trial runs (breakoutGuard=1, <20 BO-EXP settles),
        // set_min_score and set_flow_veto are LOCKED against governor writes. The
        // operator approved MIN_SCORE 50 and the governor re-loosened it to 38
        // within the hour — entry-quality knobs stay operator-owned until the
        // trial verdict so the A/B cohort stays uncontaminated. AUTO-RELIEF and
        // the SUPERVISOR valve below respect the same freeze.
        const boExpSettled = settled.filter((s)=>s.tags.split(",").includes("BO-EXP")).length;
        const trialFreeze = gateBefore.breakoutGuard === 1 && boExpSettled < 20;
        if (trialFreeze) console.log(`[GOVERNOR] BO-EXP trial freeze ACTIVE — minScore/flowVeto locked (BO-EXP settles: ${boExpSettled}/20)`);
        const rate = await deployRate();
        const decisions = rawDecisions.map((d)=>d.action === "set_min_score" && typeof d.value === "number" && d.value > gateBefore.minScore && settled.length < EVIDENCE_MIN_SETTLED ? {
                ...d,
                action: "no_op",
                value: undefined,
                rationale: `BLOCKED (evidence gate): raise to ${d.value} rejected — only ${settled.length}/8 settled outcomes; sample too small to justify tightening`
            } : trialFreeze && (d.action === "set_min_score" || d.action === "set_flow_veto") ? {
                ...d,
                action: "no_op",
                value: undefined,
                rationale: `BLOCKED (BO-EXP trial freeze): ${d.action} locked while the BREAKOUT conditional trial runs (${boExpSettled}/20 settled) — operator owns entry-quality knobs until the verdict`
            } : d);
        // validate + apply with EXISTING clamps + v6.2 hysteresis (flip-flop protection)
        const applied = [];
        let appliedCount = 0;
        const cfg = await getGovernorState();
        const hyst = await getHysteresis();
        // v6.2.1 operator request: HYSTERESIS state must be visible in the log at
        // every cycle — which knobs are cooling and for how long.
        const coolingNow = Object.entries(hyst).filter(([, v])=>Date.now() - v.at < KNOB_COOLDOWN_MS);
        console.log(`[GOVERNOR-HYSTERESIS] cycle #${cfg.cycles + 1} (${new Date().toISOString().slice(11, 19)}Z) — ${coolingNow.length === 0 ? "no knobs in cooldown" : coolingNow.map(([k, v])=>`${k} ${Math.ceil((KNOB_COOLDOWN_MS - (Date.now() - v.at)) / 60_000)}m left`).join(", ")}`);
        for (const d of decisions.slice(0, cfg.maxActions)){
            let ok = false;
            let appliedVal;
            try {
                if (HYST_ACTIONS.has(d.action) && typeof d.value === "number") {
                    const { cooling, minsLeft } = knobCooling(hyst, d.action);
                    if (cooling) {
                        console.log(`[GOVERNOR-HYSTERESIS] BLOCKED ${d.action} → ${d.value} — ${minsLeft}m left of 90min cooldown (flip-flop protection)`);
                        applied.push({
                            action: d.action,
                            value: d.value,
                            rationale: `BLOCKED (hysteresis): ${d.action} changed <${minsLeft}m ago — flip-flop protection holds the knob for the rest of its 90min cooldown · ${d.rationale}`,
                            applied: false
                        });
                        continue;
                    }
                }
                if (d.action === "set_min_score" && typeof d.value === "number") {
                    // v8.4.2 OPERATOR PIN — «ثابت نگه دار»: while minScorePinned=1 the
                    // governor may NOT retune the entry threshold in either direction.
                    const pinnedNow = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])()).minScorePinned === 1;
                    if (pinnedNow) {
                        const live = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])()).minScore;
                        console.log(`[GOVERNOR] set_min_score → ${d.value} SUPPRESSED — OPERATOR PIN active (minScore fixed at ${live} by bridge mandate 2026-09-12)`);
                        applied.push({
                            action: d.action,
                            value: d.value,
                            rationale: `BLOCKED (OPERATOR PIN): minScore is operator-owned and fixed at ${live} — bridge mandate 2026-09-12 «آستانه ورود ... و ثابت نگه دار». Only an explicit operator mandate may move it.`,
                            applied: false
                        });
                        continue;
                    }
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        minScore: d.value
                    });
                    appliedVal = next.minScore;
                    ok = true;
                } else if (d.action === "set_flow_veto" && typeof d.value === "number") {
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        flowVetoScore: d.value
                    });
                    appliedVal = next.flowVetoScore;
                    ok = true;
                } else if (d.action === "set_flow_shortlist" && typeof d.value === "number") {
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        flowShortlist: d.value
                    });
                    appliedVal = next.flowShortlist;
                    ok = true;
                } else if (d.action === "set_universe" && typeof d.value === "number") {
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        universeSize: d.value
                    });
                    appliedVal = next.universeSize;
                    ok = true;
                } else if (d.action === "set_ttl_extend_max" && typeof d.value === "number") {
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        ttlExtendMax: d.value
                    });
                    appliedVal = next.ttlExtendMax;
                    ok = true;
                } else if (d.action === "set_ttl_extend_minutes" && typeof d.value === "number") {
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        ttlExtendMinutes: d.value
                    });
                    appliedVal = next.ttlExtendMinutes;
                    ok = true;
                } else if (d.action === "set_ttl_near_tp" && typeof d.value === "number") {
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        ttlNearTpPct: d.value
                    });
                    appliedVal = next.ttlNearTpPct;
                    ok = true;
                } else if (d.action === "set_sl_atr_mult" && typeof d.value === "number") {
                    // v6.3 DYNAMIC RISK — stop distance in ATR multiples (governor-owned)
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        slAtrMult: d.value
                    });
                    appliedVal = next.slAtrMult;
                    ok = true;
                } else if (d.action === "set_rr_scale" && typeof d.value === "number") {
                    // v6.3 DYNAMIC RISK — scales every computed R:R ladder
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        rrScale: d.value
                    });
                    appliedVal = next.rrScale;
                    ok = true;
                } else if (d.action === "set_regime_guard" && typeof d.value === "number") {
                    // v6.3 REGIME FILTER HARDENING level (0 soft · 1 chop veto · 2 full guard)
                    // v13.0 OPERATOR PIN (trace 1a1c1ecd9694a129, 2026-11-09) — while regimeGuardPinned=1
                    // the governor may NOT move regimeGuard. Evidence: the governor silently re-hardened
                    // regimeGuard 0→2 after the operator's 2026-11-06 «تمام گیتهای ورودی را باز کن» order
                    // opened it — REGIME then vetoed 496 candidates in 6h and signal issuance stalled 6.2h
                    // (last serial NX-3495 before the audit). Operator orders are supreme (minScore PIN
                    // precedent v8.4.2). Unpin requires an explicit operator mandate.
                    const rgPinned = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])()).regimeGuardPinned === 1;
                    if (rgPinned) {
                        const live = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])()).regimeGuard;
                        console.log(`[GOVERNOR] set_regime_guard → ${d.value} SUPPRESSED — OPERATOR PIN active (regimeGuard fixed at L${live} by operator orders 2026-11-06 «تمام گیتهای ورودی را باز کن» + 2026-11-09 audit trace 1a1c1ecd9694a129)`);
                        applied.push({
                            action: d.action,
                            value: d.value,
                            rationale: `BLOCKED (OPERATOR PIN): regimeGuard is operator-owned and fixed at L${live} — standing order 2026-11-06 «تمام گیتهای ورودی را باز کن» + audit order 2026-11-09 trace 1a1c1ecd9694a129. Only an explicit operator mandate may move or unpin it.`,
                            applied: false
                        });
                        continue;
                    }
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        regimeGuard: d.value
                    });
                    appliedVal = next.regimeGuard;
                    ok = true;
                } else if (d.action === "set_max_active" && typeof d.value === "number") {
                    // v6.3 DYNAMIC RISK — position capacity (max concurrent open signals)
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        maxActive: d.value
                    });
                    appliedVal = next.maxActive;
                    ok = true;
                } else if (d.action === "set_risk_per_trade" && typeof d.value === "number") {
                    // v6.3 DYNAMIC RISK — margin sizing scale on confidence-sized margin
                    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        riskPerTrade: d.value
                    });
                    appliedVal = next.riskPerTrade;
                    ok = true;
                } else if (d.action === "run_backtest") {
                    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["runBacktest"])({
                        label: "GOVERNOR REQUEST"
                    }).then((r)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `AI GOVERNOR requested replay done — ${r.n} trades, Wilson-LB ${r.wilsonLB}%`)).catch(()=>undefined);
                    ok = true;
                } else if (d.action === "run_autotune") {
                    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["runAutotune"])().then((r)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `AI GOVERNOR requested auto-tune done — ${r.adopted ? "weights ADOPTED" : "baseline kept"} (Δ${r.delta >= 0 ? "+" : ""}${r.delta})`)).catch(()=>undefined);
                    ok = true;
                }
            } catch  {
                ok = false;
            }
            if (ok && HYST_ACTIONS.has(d.action) && typeof appliedVal === "number") {
                hyst[d.action] = {
                    at: Date.now(),
                    from: null,
                    to: appliedVal
                };
                console.log(`[GOVERNOR-HYSTERESIS] APPLIED ${d.action} → ${appliedVal} — cooldown armed for 90min`);
            }
            if (ok) appliedCount++;
            applied.push({
                action: d.action,
                value: d.value,
                rationale: d.rationale,
                applied: ok
            });
        }
        await putHysteresis(hyst);
        const gatesAfterApplied = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
        // ── anti-lockup relief valve (v5.2): if the engine deployed NOTHING in
        // the last 6h and MIN_SCORE sits above the relief floor, force a step-down
        // and audit it. The governor may never seal the deployment pipeline shut.
        if (!trialFreeze && !gatesAfterApplied.minScorePinned && rate.deploys6h === 0 && gatesAfterApplied.minScore > MIN_SCORE_RELIEF_FLOOR) {
            const relieved = Math.max(MIN_SCORE_RELIEF_FLOOR, gatesAfterApplied.minScore - 6);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                minScore: relieved
            });
            const hyst = await getHysteresis();
            hyst.set_min_score = {
                at: Date.now(),
                from: gatesAfterApplied.minScore,
                to: relieved
            };
            await putHysteresis(hyst);
            console.log(`[GOVERNOR-HYSTERESIS] AUTO-RELIEF bypass on set_min_score ${gatesAfterApplied.minScore}→${relieved} — cooldown re-armed (lockout beats thrash)`);
            applied.push({
                action: "set_min_score",
                value: relieved,
                rationale: `AUTO-RELIEF: 0 deploys in 6h with MIN_SCORE ${gatesAfterApplied.minScore} — engine locked, stepping down to ${relieved} so candidates reach the gates again (safety valve bypasses hysteresis but records the change)`,
                applied: true
            });
            appliedCount++;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `AI GOVERNOR AUTO-RELIEF: signal drought detected — MIN_SCORE ${gatesAfterApplied.minScore}→${relieved}`).catch(()=>undefined);
        }
        // ── SUPERVISOR quality valve (v5.3): the MIRROR of auto-relief. A drought
        // is not the only failure mode — over-trading low-quality signals is the
        // other (realized case: 28 deploys at WR 9% while MIN_SCORE sat at the 20
        // floor). When the trailing settled window shows WR < 15% over ≥12 settles
        // and MIN_SCORE is below the quality ceiling, step it UP and audit it.
        // v6.7: respects the BO-EXP trial freeze (minScore is operator-owned during
        // the trial — the advisor carries the quality decision instead).
        const trail = settled.slice(0, SUPERVISOR_TRAILING_N);
        const trailWr = trail.length >= 12 ? trail.filter((s)=>s.pnlPercent > 0).length / trail.length * 100 : null;
        if (trialFreeze && trailWr !== null && trailWr < SUPERVISOR_WR_FLOOR) {
            applied.push({
                action: "set_min_score",
                value: gatesAfterApplied.minScore,
                rationale: `SUPERVISOR raise suppressed by BO-EXP trial freeze (trailing WR ${trailWr.toFixed(0)}% < 15%) — quality decision deferred to the operator/advisor until the trial verdict`,
                applied: false
            });
        }
        if (!trialFreeze && trailWr !== null && trailWr < SUPERVISOR_WR_FLOOR && gatesAfterApplied.minScore < MIN_SCORE_QUALITY_CEILING) {
            // v8.4.2 OPERATOR PIN — the quality-raise valve must never fight the pin.
            if (gatesAfterApplied.minScorePinned) {
                applied.push({
                    action: "set_min_score",
                    value: gatesAfterApplied.minScore,
                    rationale: `SUPERVISOR raise SUPPRESSED — OPERATOR PIN active (minScore fixed at ${gatesAfterApplied.minScore} by bridge mandate 2026-09-12); trailing WR ${trailWr.toFixed(0)}% recorded for the operator to judge`,
                    applied: false
                });
            } else {
                const hyst = await getHysteresis();
                const { cooling, minsLeft } = knobCooling(hyst, "set_min_score");
                if (cooling) {
                    console.log(`[GOVERNOR-HYSTERESIS] SUPERVISOR raise BLOCKED — set_min_score cooling, ${minsLeft}m left (trailing WR ${trailWr.toFixed(0)}% < 15%)`);
                    applied.push({
                        action: "set_min_score",
                        value: gatesAfterApplied.minScore + 5,
                        rationale: `SUPERVISOR: trailing WR ${trailWr.toFixed(0)}% < 15% — raise REQUIRED but blocked by hysteresis for another ${minsLeft}m (flip-flop protection)`,
                        applied: false
                    });
                } else {
                    const raised = Math.min(MIN_SCORE_QUALITY_CEILING, gatesAfterApplied.minScore + 5);
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                        minScore: raised
                    });
                    hyst.set_min_score = {
                        at: Date.now(),
                        from: gatesAfterApplied.minScore,
                        to: raised
                    };
                    await putHysteresis(hyst);
                    console.log(`[GOVERNOR-HYSTERESIS] SUPERVISOR quality-raise APPLIED set_min_score ${gatesAfterApplied.minScore}→${raised} — cooldown re-armed`);
                    applied.push({
                        action: "set_min_score",
                        value: raised,
                        rationale: `SUPERVISOR: trailing WR ${trailWr.toFixed(0)}% over ${trail.length} settled < 15% — quality drift, stepping MIN_SCORE ${gatesAfterApplied.minScore}→${raised}`,
                        applied: true
                    });
                    appliedCount++;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `AI GOVERNOR SUPERVISOR: quality drift detected (trailing WR ${trailWr.toFixed(0)}%) — MIN_SCORE ${gatesAfterApplied.minScore}→${raised}`).catch(()=>undefined);
                }
            }
        }
        const gatesAfter = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
        const row = {
            at: new Date().toISOString(),
            trigger,
            label,
            gatesBefore: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["describeGate"])(gateBefore),
            gatesAfter: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["describeGate"])(gatesAfter),
            applied: appliedCount,
            decisions: applied
        };
        const state = await getGovernorState();
        const log = [
            row,
            ...state.log
        ].slice(0, LOG_CAP);
        const nextCfg = {
            ...state,
            cycles: state.cycles + 1,
            lastRunAt: row.at
        };
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY
            },
            create: {
                key: KEY,
                value: JSON.stringify(nextCfg)
            },
            update: {
                value: JSON.stringify(nextCfg)
            }
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: KEY_LOG
            },
            create: {
                key: KEY_LOG,
                value: JSON.stringify(log)
            },
            update: {
                value: JSON.stringify(log)
            }
        });
        for (const d of applied){
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `AI GOVERNOR (${trigger}, ${label}): ${d.action}${d.value !== undefined ? ` → ${d.value}` : ""} ${d.applied ? "APPLIED" : "rejected"} — ${d.rationale}`);
        }
        return {
            ok: true,
            summary: `${label} cycle: ${appliedCount}/${applied.length} decisions applied · ${gatesAfter.minScore !== gateBefore.minScore ? `MIN_SCORE ${gateBefore.minScore}→${gatesAfter.minScore}` : "gates unchanged"}`
        };
    } finally{
        cycleInFlight = false;
    }
}
// ── auto scheduler hook (called by engine tick) — v6.0: UNCONDITIONAL, the
// governor can no longer be disengaged; only the interval is configurable ──
let autoLastCheck = 0;
async function maybeAutoGovernor() {
    if (cycleInFlight) return;
    if (Date.now() - autoLastCheck < 60_000) return;
    autoLastCheck = Date.now();
    const cfg = await getGovernorState();
    if (cfg.lastRunAt && Date.now() - new Date(cfg.lastRunAt).getTime() < cfg.intervalMin * 60_000) return;
    void runGovernorCycle("auto").catch((err)=>console.error("[governor:auto]", err));
}
}),
"[project]/src/lib/stats.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildStats",
    ()=>buildStats,
    "pnlUsd",
    ()=>pnlUsd,
    "toSignalDTO",
    ()=>toSignalDTO
]);
// ── FlowRadar Neo stats builder (server-only) ──
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accounting.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ttl$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ttl-gate.ts [app-route] (ecmascript)");
// Task 65 SIZING-MODES — live margin sizing control state (pulse-cheap, 15s memo)
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sizing$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sizing.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$close$2d$all$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/close-all.ts [app-route] (ecmascript)"); // v11.5 global open-pnl close-all breaker
// v12.0 Task-45 Q2 — open-pnl SINGLE SOURCE OF TRUTH: the ACCOUNT bar reads the
// same tranche-aware settlement-safe number the close-all breaker reads.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$open$2d$pnl$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/open-pnl.ts [app-route] (ecmascript)");
;
;
;
;
;
;
const WIN_STATUSES = new Set([
    "TP1",
    "TP2",
    "TP3"
]);
const LOSS_STATUSES = new Set([
    "SL"
]);
/**
 * v5.4 TP-PROVEN WIN ACCOUNTING (operator request):
 * a signal counts as a WIN the moment it touches TP1/TP2/TP3 — even if it is
 * still running, stops out at breakeven afterwards, or expires later. The
 * `reachedTp` ledger column survives every terminal status, so the win-rate
 * process now measures the full TP ladder instead of only final outcomes.
 */ const isTpWin = (s)=>s.reachedTp >= 1 || WIN_STATUSES.has(s.status);
/** settled = closed OR TP-proven (an open signal that already banked TP1 belongs in the rate). */ const isSettledOrProven = (s)=>!!s.closedAt || s.reachedTp >= 1;
function pnlUsd(s) {
    return s.marginUsd * s.pnlPercent / 100;
}
/** Asia/Tehran fixed offset (UTC+03:30 — Iran abolished DST in 2022). */ const TZ_OFFSET_MIN = 210;
/** Shift a timestamp into Tehran-local wall time (then read UTC parts). */ function tzLocal(d) {
    return new Date(d.getTime() + TZ_OFFSET_MIN * 60_000);
}
function ledgerBucketOf(status) {
    if (status === "EXPIRED") return "expired";
    if (status === "SL") return "stop";
    if (status === "CLOSED") return "other";
    return "tp"; // TP1 | TP2 | TP3
}
// ── v11.1 TASK-56 LEDGER-AUDIT (operator: «NET EST PNL LEDGER را بررسی و
// راستی‌آزمایی کن») — settlement-status WHITELIST + clean-ledger filter.
// Forensic evidence: ledgerBucketOf("VOID") fell through to "tp", so the two
// PHANTOM-FEED-0930 VOID rows (NX-0884/0887, +99.8% phantom full-TPs) sat in
// the TP bucket and flipped the all-time ledger from the TRUE −163.6% EST /
// −$9.38 to a FAKE +36.0% EST / −$8.87. The ledger now excludes qualityFlag
// rows (v10.18 clean-ledger doctrine) and any non-settlement status, and the
// paper ACCOUNT keeps full history (balance continuity) — the split is
// surfaced via totals.excludedN + dataQuality counters.
function isoWeekKey(d) {
    const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
    const dayNum = (t.getUTCDay() + 6) % 7; // Mon=0 … Sun=6
    t.setUTCDate(t.getUTCDate() - dayNum + 3); // shift to this week's Thursday (ISO)
    const isoYear = t.getUTCFullYear();
    const jan4 = new Date(Date.UTC(isoYear, 0, 4));
    const week = 1 + Math.round(((t.getTime() - jan4.getTime()) / 86_400_000 - 3 + (jan4.getUTCDay() + 6) % 7) / 7);
    return `${isoYear}-W${String(week).padStart(2, "0")}`;
}
const LEDGER_SETTLEMENT_STATUSES = new Set([
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
]);
function emptyAccum() {
    return {
        expiredUsd: 0,
        tpUsd: 0,
        stopUsd: 0,
        otherUsd: 0,
        expiredN: 0,
        tpN: 0,
        stopN: 0,
        otherN: 0,
        estPct: 0
    };
}
function accumulate(acc, s) {
    const usd = pnlUsd(s);
    const b = ledgerBucketOf(s.status);
    acc[`${b}Usd`] += usd;
    acc[`${b}N`] += 1;
    acc.estPct += s.pnlPercent ?? 0; // v6.2: the ACTUAL result — no idealized norms
}
function toRow(key, label, acc) {
    const trades = acc.expiredN + acc.tpN + acc.stopN + acc.otherN;
    return {
        key,
        label,
        expiredUsd: Number(acc.expiredUsd.toFixed(2)),
        tpUsd: Number(acc.tpUsd.toFixed(2)),
        stopUsd: Number(acc.stopUsd.toFixed(2)),
        otherUsd: Number(acc.otherUsd.toFixed(2)),
        netUsd: Number((acc.expiredUsd + acc.tpUsd + acc.stopUsd + acc.otherUsd).toFixed(2)),
        expiredN: acc.expiredN,
        tpN: acc.tpN,
        stopN: acc.stopN,
        otherN: acc.otherN,
        estPnlPct: Number(acc.estPct.toFixed(1)),
        avgPct: trades ? Number((acc.estPct / trades).toFixed(1)) : 0
    };
}
function buildLedger(closedAll) {
    const now = Date.now();
    let excludedN = 0; // Task 56 audit: qualityFlag / non-settlement rows kept OUT of every bucket
    // v6.2: keys are ASIA/TEHRAN local calendar units (UTC+03:30 fixed) — the
    // daily boundary matches the operator's wall clock, per the architecture review.
    const windows = [
        {
            range: "daily",
            since: now - 30 * 86_400_000,
            keyFn: (d)=>tzLocal(d).toISOString().slice(0, 10),
            labelFn: (k)=>k.slice(5),
            cap: 30
        },
        {
            range: "weekly",
            since: now - 84 * 86_400_000,
            keyFn: (d)=>isoWeekKey(tzLocal(d)),
            labelFn: (k)=>k.slice(5),
            cap: 12
        },
        {
            range: "monthly",
            since: null,
            keyFn: (d)=>tzLocal(d).toISOString().slice(0, 7),
            labelFn: (k)=>k,
            cap: 12
        }
    ];
    const totalsAcc = emptyAccum();
    let ttlExtended = 0;
    const out = {
        daily: [],
        weekly: [],
        monthly: [],
        totals: {
            expiredUsd: 0,
            tpUsd: 0,
            stopUsd: 0,
            otherUsd: 0,
            netUsd: 0,
            expiredN: 0,
            tpN: 0,
            stopN: 0,
            otherN: 0,
            estPnlPct: 0,
            avgPct: 0,
            ttlExtended: 0,
            extCapturedUsd: 0,
            excludedN: 0
        }
    };
    for (const s of closedAll){
        // Task 56: clean-ledger + settlement whitelist — a VOID/integrity-flagged
        // row must never reach any bucket (the old fall-through made VOID a "tp")
        if (s.qualityFlag !== null || !LEDGER_SETTLEMENT_STATUSES.has(s.status)) {
            excludedN++;
            continue;
        }
        accumulate(totalsAcc, s);
        if (s.ttlExtensions > 0) ttlExtended++;
    }
    const totals = {
        expiredUsd: Number(totalsAcc.expiredUsd.toFixed(2)),
        tpUsd: Number(totalsAcc.tpUsd.toFixed(2)),
        stopUsd: Number(totalsAcc.stopUsd.toFixed(2)),
        otherUsd: Number(totalsAcc.otherUsd.toFixed(2)),
        netUsd: Number((totalsAcc.expiredUsd + totalsAcc.tpUsd + totalsAcc.stopUsd + totalsAcc.otherUsd).toFixed(2)),
        expiredN: totalsAcc.expiredN,
        tpN: totalsAcc.tpN,
        stopN: totalsAcc.stopN,
        otherN: totalsAcc.otherN,
        estPnlPct: Number(totalsAcc.estPct.toFixed(1)),
        avgPct: closedAll.length ? Number((totalsAcc.estPct / Math.max(1, closedAll.length - excludedN)).toFixed(1)) : 0,
        ttlExtended,
        extCapturedUsd: 0,
        excludedN
    };
    for (const w of windows){
        const maps = new Map();
        for (const s of closedAll){
            const t = s.closedAt ? new Date(s.closedAt) : null;
            if (!t) continue;
            if (w.since !== null && t.getTime() < w.since) continue;
            // Task 56: same clean-ledger guard on every daily/weekly/monthly bucket
            if (s.qualityFlag !== null || !LEDGER_SETTLEMENT_STATUSES.has(s.status)) continue;
            const key = w.keyFn(t);
            const acc = maps.get(key) ?? emptyAccum();
            accumulate(acc, s);
            maps.set(key, acc);
        }
        out[w.range] = [
            ...maps.keys()
        ].sort().slice(-w.cap).map((k)=>toRow(k, w.labelFn(k), maps.get(k)));
    }
    out.totals = totals;
    return out;
}
async function buildStats() {
    const weekAgo = new Date(Date.now() - 7 * 24 * 3600_000);
    // v10.18 CLEAN-LEDGER DOCTRINE (operator option A, 2026-09-24) — headline
    // analytics exclude qualityFlag rows (DEGEN_STOP / INVERTED_STOP /
    // RESTORE_CATCHUP — reserved classes for genuine ledger-integrity events).
    // Forensic note: the v10.18 audit found ZERO historical rows qualifying
    // (the 200 entry==SL rows are legit BE-trail exits; the +pnl "SL" rows are
    // legit TP1-trails) — the filter is a permanent anti-poisoning rail. The
    // paper ACCOUNT keeps full history (balance continuity); ANALYTICS stay
    // clean and the dataQuality counters surface what was excluded.
    const signals = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            createdAt: {
                gte: weekAgo
            },
            qualityFlag: null
        },
        orderBy: {
            createdAt: "asc"
        }
    });
    const closed = signals.filter((s)=>s.closedAt);
    const settledOrProven = signals.filter(isSettledOrProven);
    const wins = settledOrProven.filter(isTpWin);
    const losses = closed.filter((s)=>LOSS_STATUSES.has(s.status) && !isTpWin(s));
    const expired = closed.filter((s)=>s.status === "EXPIRED");
    const active = signals.filter((s)=>!s.closedAt);
    const totalPnlUsd = closed.reduce((acc, s)=>acc + pnlUsd(s), 0);
    const dayAgo = new Date(Date.now() - 24 * 3600_000);
    const pnl24hUsd = closed.filter((s)=>s.closedAt && s.closedAt >= dayAgo).reduce((acc, s)=>acc + pnlUsd(s), 0);
    const sortedByPnl = [
        ...closed
    ].sort((a, b)=>pnlUsd(b) - pnlUsd(a));
    const best = sortedByPnl[0];
    const worst = sortedByPnl[sortedByPnl.length - 1];
    // streak (scan closed newest → oldest)
    const closedDesc = [
        ...closed
    ].sort((a, b)=>(b.closedAt?.getTime() ?? 0) - (a.closedAt?.getTime() ?? 0));
    let streak = {
        type: "win",
        count: 0
    };
    if (closedDesc.length) {
        const firstWin = isTpWin(closedDesc[0]);
        streak.type = firstWin ? "win" : "loss";
        for (const s of closedDesc){
            const isW = isTpWin(s);
            const isL = LOSS_STATUSES.has(s.status) && !isTpWin(s);
            if (streak.type === "win" && isW) streak.count++;
            else if (streak.type === "loss" && isL) streak.count++;
            else break;
        }
    }
    // ── equity curve by day ─────────────────────────────────────────────
    // v11.5 DAY-BOUNDARY ALIGNMENT (operator mandate 2026-10-12: «ساعت و تاریخ
    // روزهای جدید با ساعت سیستم یکی باشد»). Truth-audit finding: this curve
    // keyed rows by the RAW UTC day (toISOString) while the NET EST PNL LEDGER
    // buckets by ASIA/TEHRAN local days (the operator's device system clock —
    // V641 dashboard-clock doctrine). A row closed at 20:30Z+ was therefore
    // shown on the PREVIOUS day label in EQUITY CURVE while DAILY PNL already
    // called it the new day — the exact "new day hour/date ≠ system clock"
    // mismatch the operator reported. Both modules now share ONE boundary:
    // the operator's local (Asia/Tehran, fixed UTC+03:30) calendar day.
    const byDay = new Map();
    for (const s of closed){
        if (!s.closedAt) continue;
        const key = tzLocal(s.closedAt).toISOString().slice(0, 10);
        byDay.set(key, (byDay.get(key) ?? 0) + pnlUsd(s));
    }
    const days = [
        ...byDay.keys()
    ].sort();
    let cum = 0;
    const equityCurve = days.map((d)=>{
        const daily = byDay.get(d) ?? 0;
        cum += daily;
        return {
            date: d.slice(5),
            cum: Number(cum.toFixed(2)),
            daily: Number(daily.toFixed(2))
        };
    });
    // by symbol — TP-proven accounting (settled-or-proven in the denominator)
    const symMap = new Map();
    for (const s of settledOrProven){
        const e = symMap.get(s.symbol) ?? {
            count: 0,
            wins: 0,
            pnl: 0
        };
        e.count++;
        if (isTpWin(s)) e.wins++;
        e.pnl += pnlUsd(s);
        symMap.set(s.symbol, e);
    }
    const bySymbol = [
        ...symMap.entries()
    ].map(([symbol, e])=>({
            symbol,
            ...e,
            pnl: Number(e.pnl.toFixed(2))
        })).sort((a, b)=>b.pnl - a.pnl);
    // direction
    const byDirection = {
        long: signals.filter((s)=>s.direction === "LONG").length,
        short: signals.filter((s)=>s.direction === "SHORT").length
    };
    // timeframe — TP-proven accounting
    const tfMap = new Map();
    for (const s of settledOrProven){
        const e = tfMap.get(s.timeframe) ?? {
            count: 0,
            wins: 0,
            pnl: 0
        };
        e.count++;
        if (isTpWin(s)) e.wins++;
        e.pnl += pnlUsd(s);
        tfMap.set(s.timeframe, e);
    }
    const tfOrder = [
        "5m",
        "15m",
        "1h",
        "4h"
    ];
    const byTimeframe = tfOrder.filter((tf)=>tfMap.has(tf)).map((tf)=>{
        const e = tfMap.get(tf);
        return {
            timeframe: tf,
            ...e,
            pnl: Number(e.pnl.toFixed(2))
        };
    });
    // strategy — TP-proven accounting
    const stMap = new Map();
    for (const s of settledOrProven){
        const e = stMap.get(s.strategy) ?? {
            count: 0,
            wins: 0,
            pnl: 0,
            conf: 0
        };
        e.count++;
        if (isTpWin(s)) e.wins++;
        e.pnl += pnlUsd(s);
        e.conf += s.confidence;
        stMap.set(s.strategy, e);
    }
    const byStrategy = [
        ...stMap.entries()
    ].map(([strategy, e])=>({
            strategy,
            count: e.count,
            wins: e.wins,
            pnl: Number(e.pnl.toFixed(2)),
            avgConfidence: Math.round(e.conf / Math.max(1, e.count))
        }));
    // confidence buckets
    const buckets = [
        {
            bucket: "60-70",
            min: 60,
            max: 70
        },
        {
            bucket: "70-80",
            min: 70,
            max: 80
        },
        {
            bucket: "80-90",
            min: 80,
            max: 90
        },
        {
            bucket: "90+",
            min: 90,
            max: 101
        }
    ];
    const confidenceBuckets = buckets.map((b)=>{
        const inB = settledOrProven.filter((s)=>s.confidence >= b.min && s.confidence < b.max);
        const w = inB.filter(isTpWin).length;
        return {
            bucket: b.bucket,
            count: inB.length,
            wins: w,
            winRate: inB.length ? Math.round(w / inB.length * 100) : 0
        };
    });
    // ── v5.4 TP FUNNEL — ladder depth analytics (TP1 → TP2 → full TP3 vs SL/EXPIRED) ──
    const tp3Closed = closed.filter((s)=>s.status === "TP3");
    const tp1Hits = signals.filter((s)=>s.reachedTp >= 1).length;
    const tp2Hits = signals.filter((s)=>s.reachedTp >= 2).length;
    const tpFunnel = {
        settledOrProven: settledOrProven.length,
        tp1Hits,
        tp2Hits,
        tp3FullWins: tp3Closed.length,
        slLosses: closed.filter((s)=>s.status === "SL").length,
        expired: expired.length,
        tp1Rate: settledOrProven.length ? Number((tp1Hits / settledOrProven.length * 100).toFixed(1)) : 0,
        tp2Rate: settledOrProven.length ? Number((tp2Hits / settledOrProven.length * 100).toFixed(1)) : 0,
        fullTpRate: closed.length ? Number((tp3Closed.length / closed.length * 100).toFixed(1)) : 0,
        avgRrFullWins: tp3Closed.length ? Number((tp3Closed.reduce((a, s)=>a + s.riskReward, 0) / tp3Closed.length).toFixed(2)) : 0,
        avgConfFullWins: tp3Closed.length ? Math.round(tp3Closed.reduce((a, s)=>a + s.confidence, 0) / tp3Closed.length) : 0,
        avgHoldTp3Min: tp3Closed.length ? Math.round(tp3Closed.reduce((a, s)=>a + (s.closedAt && s.createdAt ? (s.closedAt.getTime() - s.createdAt.getTime()) / 60_000 : 0), 0) / tp3Closed.length) : 0
    };
    // 2026-09-17 operator audit fix: equityCurve.cum is cumulative PnL (relative
    // to the $100 start), so the raw reduce returned 0 whenever the account was
    // net-negative → STREAK card showed "peak equity $0.00". Peak ACCOUNT equity
    // = start balance + best cumulative PnL on the curve (start itself = 0 cum,
    // so a never-in-profit account peaks at exactly the start balance).
    const peakEquity = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ACCOUNT_START_USD"] + equityCurve.reduce((m, p)=>Math.max(m, p.cum), 0);
    // ── Paper account ($100 start, NET accounting, fee-aware) ──
    const START_BALANCE = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ACCOUNT_START_USD"];
    const [openSignals, assets, ttlTel] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
            select: {
                symbol: true,
                price: true,
                source: true,
                updatedAt: true
            }
        }),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ttl$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTtlTelemetry"])()
    ]);
    // NOTE (Task 56): NO qualityFlag filter here — the paper ACCOUNT keeps full
    // history (v10.18 doctrine); buildLedger applies its own clean-ledger guard.
    const allTimeClosed = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            closedAt: {
                not: null
            }
        },
        select: {
            marginUsd: true,
            pnlPercent: true,
            feeUsd: true,
            swapUsd: true,
            entryPrice: true,
            direction: true,
            leverage: true,
            createdAt: true,
            closedAt: true,
            status: true,
            stopLoss: true,
            reachedTp: true,
            ttlExtensions: true,
            qualityFlag: true
        }
    });
    const realizedAllTime = allTimeClosed.reduce((acc, s)=>acc + s.marginUsd * s.pnlPercent / 100, 0);
    const feesPaidAllTime = allTimeClosed.reduce((acc, s)=>acc + s.feeUsd + s.swapUsd, 0);
    // v12.0 — ONE open-pnl formula for the bar and the breaker (open-pnl.ts):
    // unrealizedPnl = bankable NET (tranche-aware mark, settlement-safe rows only
    // — mirror of the engine's settlementUnsafe: live-sourced & ≤120s fresh).
    // unrealizedPnlAllRows keeps the legacy full-margin current-price sum (every
    // priced row, unsafe included) so the historical overstatement stays visible.
    const assetMap = new Map(assets.map((a)=>[
            a.symbol,
            a
        ]));
    const book = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$open$2d$pnl$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["openBookNet"])(openSignals.flatMap((s)=>{
        const a = assetMap.get(s.symbol);
        if (!a) return [];
        return [
            {
                signal: s,
                price: a.price,
                safe: a.source === "live" && Date.now() - a.updatedAt.getTime() <= 120_000
            }
        ];
    }), Date.now());
    const unrealized = book.bankableUsd;
    const unrealizedAllRows = book.allRowsUsd;
    let exposureUsd = 0;
    for (const s of openSignals)exposureUsd += s.marginUsd;
    const balance = Number((START_BALANCE + realizedAllTime).toFixed(2));
    const equity = Number((balance + unrealized).toFixed(2));
    const account = {
        startBalance: START_BALANCE,
        balance,
        equity,
        unrealizedPnl: Number(unrealized.toFixed(2)),
        // v12.0 — legacy full-margin current-price sum over ALL priced rows (incl.
        // banked-tranche re-pricing + settlement-unsafe rows). Kept visible so the
        // gap vs the bankable number the breaker reads is auditable at a glance.
        unrealizedPnlAllRows: Number(unrealizedAllRows.toFixed(2)),
        unsafeOpenRows: book.skipped.length,
        exposureUsd: Number(exposureUsd.toFixed(2)),
        freeMargin: Number((equity - exposureUsd).toFixed(2)),
        marginUsedPct: equity > 0 ? Number((exposureUsd / equity * 100).toFixed(1)) : 0,
        openPositions: openSignals.length,
        feesPaid: Number(feesPaidAllTime.toFixed(3)),
        // v11.5 — the operator's book-level profit-lock (close-all at Σ open NET
        // pnl ≥ target) — the AccountBar badge reads enabled/target/trigger count.
        closeAll: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$close$2d$all$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCloseAllState"])().then((c)=>({
                enabled: c.enabled,
                targetUsd: c.targetUsd,
                lastTriggeredAt: c.lastTriggeredAt,
                triggerCount: c.triggerCount
            })).catch(()=>null)
    };
    // ── EXPIRED afterlife stats (Bug 5 — شفافیت چرخه عمر) ──
    const expiredAll = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: "EXPIRED"
        },
        select: {
            afterlife: true,
            maxPostPnlPercent: true
        }
    });
    const afterlife = {
        tracking: expiredAll.filter((s)=>s.afterlife === "TRACKING").length,
        tp1: expiredAll.filter((s)=>s.afterlife === "TP1_HIT").length,
        tp2: expiredAll.filter((s)=>s.afterlife === "TP2_HIT").length,
        tp3: expiredAll.filter((s)=>s.afterlife === "TP3_HIT").length,
        sl: expiredAll.filter((s)=>s.afterlife === "SL_HIT").length,
        flat: expiredAll.filter((s)=>s.afterlife === "FLAT").length,
        avgPostMfe: expiredAll.length ? Number((expiredAll.reduce((a, s)=>a + s.maxPostPnlPercent, 0) / expiredAll.length).toFixed(2)) : 0,
        wouldHaveWonPct: expiredAll.length ? Number((expiredAll.filter((s)=>[
                "TP1_HIT",
                "TP2_HIT",
                "TP3_HIT"
            ].includes(s.afterlife ?? "")).length / expiredAll.length * 100).toFixed(0)) : 0
    };
    // ── v9.0 LIFECYCLE AUDIT (operator request 2026-09-12) ──
    // Lifetime counters for the Session Stats rows the 120-event terminal window
    // used to erase: BE_TRAIL / TTL_EXTENDED are counted from SignalEvent, the
    // AFTERLIFE row now carries tracking + RESOLVED outcomes, and the BE-trail
    // arm efficacy is measured end-to-end (rescued vs fee-only vs stopped).
    // 30s memo keeps the extra queries off the hot 5s pulse path.
    const lifecycle = await buildLifecycleStats();
    // ── v6.1 NET EST PNL LEDGER — all-time bucketed EXPIRED/TP/STOP realized NET usd
    const pnlLedger = buildLedger(allTimeClosed);
    // Task 56 hardening: lifecycle.ttlCapturedUsd is DB-exact math (extWinners
    // reduce) and survives restarts — the runtime telemetry resets to 0 on every
    // recycle, which used to zero the ledger's extension capture after reboot.
    pnlLedger.totals.extCapturedUsd = Number((lifecycle.ttlCapturedUsd || ttlTel.capturedUsd).toFixed(2));
    // EPOCH-2 hardening (operator bug report «Session Stats داده های اشتباهی دارد»):
    // ttlTelemetry is a MONOTONIC global counter that can outlive signal resets —
    // with the ledger empty it previously injected phantom TTL_EXT grants (58 vs 00
    // created). The per-signal ledger is the display truth; telemetry may only RAISE
    // the count when the ledger itself already shows extension activity.
    if (ttlTel.extended > pnlLedger.totals.ttlExtended && pnlLedger.totals.ttlExtended > 0) {
        pnlLedger.totals.ttlExtended = ttlTel.extended;
    }
    // ── v10.18 DATA-QUALITY TRANSPARENCY — what the clean ledger excludes ──
    const flagGroups = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.groupBy({
        by: [
            "qualityFlag"
        ],
        where: {
            qualityFlag: {
                not: null
            }
        },
        _count: {
            _all: true
        }
    });
    const flagCount = (f)=>flagGroups.find((g)=>g.qualityFlag === f)?._count._all ?? 0;
    const dataQuality = {
        excludedTotal: flagGroups.reduce((a, g)=>a + g._count._all, 0),
        degenStop: flagCount("DEGEN_STOP"),
        invertedStop: flagCount("INVERTED_STOP"),
        restoreCatchup: flagCount("RESTORE_CATCHUP"),
        phantomFeed: flagCount("PHANTOM-FEED-0930")
    };
    // ── TASK-40 ALL-TIME SPLIT (2026-09-27, operator bug «WIN/LOSS SPLIT هم
    // داده از دست میدهد») ──────────────────────────────────────────────
    // The headline counters above are a ROLLING 7-DAY window (createdAt >=
    // weekAgo): rows age out hourly, so wins/losses/expired/winRate DECREASE on
    // their own even with zero data loss — the operator read the shrinkage as
    // reset/corruption. This block applies the SAME TP-proven win semantics
    // (reachedTp ≥ 1 or a TP-status) and the SAME clean-ledger discipline
    // (qualityFlag null) over the FULL table: monotonic, restart-proof,
    // time-proof. Four indexed counts — pulse-safe.
    const [atWins, atPureLosses, atExpired, atSettled] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                qualityFlag: null,
                OR: [
                    {
                        reachedTp: {
                            gte: 1
                        }
                    },
                    {
                        status: {
                            in: [
                                "TP1",
                                "TP2",
                                "TP3"
                            ]
                        }
                    }
                ]
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                qualityFlag: null,
                status: "SL",
                reachedTp: 0
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                qualityFlag: null,
                status: "EXPIRED"
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                qualityFlag: null,
                OR: [
                    {
                        closedAt: {
                            not: null
                        }
                    },
                    {
                        reachedTp: {
                            gte: 1
                        }
                    }
                ]
            }
        })
    ]);
    const allTimeSplit = {
        wins: atWins,
        losses: atPureLosses,
        expired: atExpired,
        settled: atSettled,
        winRate: atSettled ? Math.round(atWins / atSettled * 100) : 0
    };
    return {
        totalSignals: signals.length,
        activeCount: active.length,
        wins: wins.length,
        losses: losses.length,
        expired: expired.length,
        winRate: settledOrProven.length ? Math.round(wins.length / settledOrProven.length * 100) : 0,
        totalPnlUsd: Number(totalPnlUsd.toFixed(2)),
        pnl24hUsd: Number(pnl24hUsd.toFixed(2)),
        avgPnlPercent: closed.length ? Number((closed.reduce((a, s)=>a + s.pnlPercent, 0) / closed.length).toFixed(2)) : 0,
        bestTrade: best ? {
            symbol: best.symbol,
            pnlPercent: best.pnlPercent,
            pnlUsd: Number(pnlUsd(best).toFixed(2))
        } : null,
        worstTrade: worst ? {
            symbol: worst.symbol,
            pnlPercent: worst.pnlPercent,
            pnlUsd: Number(pnlUsd(worst).toFixed(2))
        } : null,
        streak,
        avgRiskReward: signals.length ? Number((signals.reduce((a, s)=>a + s.riskReward, 0) / signals.length).toFixed(2)) : 0,
        avgConfidence: signals.length ? Math.round(signals.reduce((a, s)=>a + s.confidence, 0) / signals.length) : 0,
        totalVolumeUsd: signals.reduce((a, s)=>a + s.marginUsd, 0),
        equityCurve,
        bySymbol,
        byDirection,
        byTimeframe,
        byStrategy,
        confidenceBuckets,
        peakEquity: Number(peakEquity.toFixed(2)),
        account,
        afterlife,
        dataQuality,
        allTimeSplit,
        lifecycle,
        tpFunnel,
        pnlLedger,
        sizing: await sizingStats().then(({ cfg, consecSl })=>({
                mode: cfg.mode,
                flatBase: cfg.flatBase,
                antiBase: cfg.antiBase,
                decay: cfg.decay,
                floor: cfg.floor,
                consecCap: cfg.consecCap,
                consecSl
            }))
    };
}
// ── v9.0 LIFECYCLE AUDIT builder (30s memo — pulse-safe) ──────────────
let lcMemo = null;
const LC_MEMO_MS = 30_000;
// Task 65: sizing read memo — 1 PK read + 1 take-60 walk per 15s, not per pulse
let szMemo = null;
const SZ_MEMO_MS = 15_000;
async function readSizing() {
    const cfg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sizing$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getSizingConfig"])();
    const consecSl = cfg.mode === "ANTI_MARTINGALE" ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sizing$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getConsecutiveSlCount"])(cfg) : 0;
    return {
        cfg,
        consecSl
    };
}
async function sizingStats() {
    if (szMemo && Date.now() - szMemo.at < SZ_MEMO_MS) return szMemo.v;
    const v = await readSizing();
    szMemo = {
        at: Date.now(),
        v
    };
    return v;
}
async function buildLifecycleStats() {
    if (lcMemo && Date.now() - lcMemo.at < LC_MEMO_MS) return lcMemo.v;
    try {
        const [beTrail, beTrailGroups, ttlExtEvents, extAgg, extSigGroups, lifetimeSignals, tp1Hits, tp2Hits, tp3ClosedN, tp3AfterlifeN, slN, expiredN] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.count({
                where: {
                    type: "BE_TRAIL"
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.groupBy({
                by: [
                    "signalId"
                ],
                where: {
                    type: "BE_TRAIL"
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.count({
                where: {
                    type: "TTL_EXTENDED"
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.aggregate({
                _sum: {
                    ttlExtensions: true
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.groupBy({
                by: [
                    "id"
                ],
                where: {
                    ttlExtensions: {
                        gt: 0
                    }
                }
            }),
            // v10.3 TRUE-LIFETIME session stats — straight DB aggregates over ALL rows
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count(),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    reachedTp: {
                        gte: 1
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    reachedTp: {
                        gte: 2
                    }
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: "TP3"
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    afterlife: "TP3_HIT"
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: "SL"
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
                where: {
                    status: "EXPIRED"
                }
            })
        ]);
        const beSignalIds = beTrailGroups.map((g)=>g.signalId).filter((x)=>!!x);
        const beSigs = beSignalIds.length ? await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                id: {
                    in: beSignalIds
                }
            },
            select: {
                status: true,
                reachedTp: true,
                pnlPercent: true,
                closedAt: true
            }
        }) : [];
        const rescued = beSigs.filter((s)=>s.reachedTp >= 1 || s.closedAt && s.pnlPercent > 0).length;
        const feeOnly = beSigs.filter((s)=>s.closedAt && s.reachedTp === 0 && s.pnlPercent <= 0 && s.pnlPercent > -1).length;
        const stopped = beSigs.filter((s)=>s.closedAt && s.reachedTp === 0 && s.pnlPercent <= -1).length;
        const extIds = extSigGroups.map((g)=>g.id);
        // NET usd captured by extended signals = Σ(margin × pnlPercent/100) over the
        // TP-proven subset — one small findMany keeps the math exact, not approximated.
        const extWinners = extIds.length ? await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                id: {
                    in: extIds
                },
                reachedTp: {
                    gte: 1
                }
            },
            select: {
                marginUsd: true,
                pnlPercent: true
            }
        }) : [];
        const ttlCapturedUsd = extWinners.reduce((a, s)=>a + s.marginUsd * s.pnlPercent / 100, 0);
        const tracking = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: "EXPIRED",
                afterlife: "TRACKING"
            }
        });
        const resolved = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: "EXPIRED",
                afterlife: {
                    in: [
                        "TP1_HIT",
                        "TP2_HIT",
                        "TP3_HIT",
                        "SL_HIT",
                        "FLAT"
                    ]
                }
            }
        });
        const v = {
            beTrail,
            beTrailSignals: beSignalIds.length,
            beTrailRescued: rescued,
            beTrailFeeOnly: feeOnly,
            beTrailStopped: stopped,
            ttlExtendedEvents: ttlExtEvents,
            ttlExtendedGrants: extAgg._sum.ttlExtensions ?? 0,
            ttlSignalsWithExt: extIds.length,
            ttlCapturedUsd: Number(ttlCapturedUsd.toFixed(2)),
            afterlifeResolved: resolved,
            afterlifeTracking: tracking,
            afterlifeTotal: resolved + tracking,
            learningWired: true,
            lifetimeSignals,
            tp1HitsLifetime: tp1Hits,
            tp2HitsLifetime: tp2Hits,
            tp3HitsLifetime: tp3ClosedN + tp3AfterlifeN,
            slLifetime: slN,
            expiredLifetime: expiredN
        };
        lcMemo = {
            at: Date.now(),
            v
        };
        return v;
    } catch  {
        // honest zero-state on transient DB hiccups — the panel must not NaN
        return {
            beTrail: 0,
            beTrailSignals: 0,
            beTrailRescued: 0,
            beTrailFeeOnly: 0,
            beTrailStopped: 0,
            ttlExtendedEvents: 0,
            ttlExtendedGrants: 0,
            ttlSignalsWithExt: 0,
            ttlCapturedUsd: 0,
            afterlifeResolved: 0,
            afterlifeTracking: 0,
            afterlifeTotal: 0,
            learningWired: false,
            lifetimeSignals: 0,
            tp1HitsLifetime: 0,
            tp2HitsLifetime: 0,
            tp3HitsLifetime: 0,
            slLifetime: 0,
            expiredLifetime: 0
        };
    }
}
function toSignalDTO(s) {
    let factors = null;
    if (s.factorsJson) {
        try {
            factors = JSON.parse(s.factorsJson);
        } catch  {
            factors = null;
        }
    }
    let flow = null;
    if (s.flowJson) {
        try {
            const raw = JSON.parse(s.flowJson);
            flow = {
                verdict: raw.verdict,
                score: raw.score,
                reasons: raw.reasons ?? [],
                oiWeight: raw.oiWeight ?? 1,
                coverage: raw.coverage,
                blind: raw.blind,
                metrics: {
                    oiDelta10m: raw.metrics.oiDelta10m ?? null,
                    oiDelta1h: raw.metrics.oiDelta1h ?? null,
                    oiValueUsd: raw.metrics.oiValueUsd ?? null,
                    cvdNetPctOfVol: raw.metrics.cvdNetPctOfVol ?? null,
                    takerRatio: raw.metrics.takerRatio ?? null,
                    takerMean: raw.metrics.takerMean ?? null,
                    crowdLongShort: raw.metrics.crowdLongShort ?? null,
                    crowdLongPct: raw.metrics.crowdLongPct ?? null,
                    funding8h: raw.metrics.funding8h ?? null
                }
            };
        } catch  {
            flow = null;
        }
    }
    return {
        ...s,
        direction: s.direction === "SHORT" ? "SHORT" : "LONG",
        status: s.status,
        tags: s.tags ? Array.from(new Set(s.tags.split(",").filter(Boolean))) : [],
        factors,
        flow,
        afterlife: s.afterlife ?? null,
        afterlifeAt: s.afterlifeAt?.toISOString() ?? null,
        maxPostPnlPercent: s.maxPostPnlPercent ?? 0,
        expiresAt: s.expiresAt.toISOString(),
        createdAt: s.createdAt.toISOString(),
        closedAt: s.closedAt?.toISOString() ?? null,
        notesUpdatedAt: s.notesUpdatedAt?.toISOString() ?? null
    };
}
}),
"[project]/src/lib/tp3-lab.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildTp3Lab",
    ()=>buildTp3Lab,
    "getDeepLearnState",
    ()=>getDeepLearnState,
    "maybeAutoDeepLearn",
    ()=>maybeAutoDeepLearn,
    "runDeepLearnCycle",
    ()=>runDeepLearnCycle
]);
// ── FlowRadar Neo TP3 DEEP-LAB + DEEP-LEARN LOOP (server-only, v5.4) ──
// Operator request: full-TP (TP3) signals get their OWN calculator with a
// deeper learning cycle, and both full-TP + stopped-out signals go through an
// LLM research Q&A ("why did this win big / why did this die?"). The resulting
// lessons are persisted, broadcast to the event feed, injected into every AI
// agent's grounding (chat / governor / card briefs), and audited in EngineSetting.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
// v8.2 GATE GAUGE — the central core studies the LIVE confirm/reject ledger
// (boundary-band verdicts + hard blocks with their full reason payload)
// alongside the terminal outcomes, so lessons attribute RESULTS to REASONS.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-journal.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sv-telemetry.ts [app-route] (ecmascript)"); // v10.2 — the core studies its own feed wiring
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — the core studies the GOVERNOR FOUR-PACK journal
;
;
;
;
;
function tagList(s) {
    return (s.tags ?? "").split(",").filter(Boolean);
}
function topN(counter, n) {
    return [
        ...counter.entries()
    ].sort((a, b)=>b[1] - a[1]).slice(0, n);
}
/** Parse the regime tag out of the deployment tags (REGIME-*). */ function regimeOf(tags) {
    return tags.find((t)=>t.startsWith("REGIME-")) ?? null;
}
/** Case-file mapper — module scope so both buildTp3Lab and runDeepLearnCycle share it. */ function toCase(s) {
    let votes = null;
    if (s.factorsJson) {
        try {
            const parsed = JSON.parse(s.factorsJson);
            votes = parsed.map((v)=>({
                    factor: String(v.factor ?? "?"),
                    vote: Number(v.vote ?? 0)
                }));
        } catch  {
            votes = null;
        }
    }
    let flowVerdict = null;
    let flowScore = null;
    if (s.flowJson) {
        try {
            const f = JSON.parse(s.flowJson);
            flowVerdict = f.verdict ?? null;
            flowScore = typeof f.score === "number" ? f.score : null;
        } catch  {
        /* keep nulls */ }
    }
    const tags = tagList(s);
    return {
        serial: s.serial,
        symbol: s.symbol,
        direction: s.direction,
        strategy: s.strategy,
        outcome: s.status === "TP3" ? "TP3_FULL" : "SL",
        confidence: s.confidence,
        riskReward: s.riskReward,
        timeframe: s.timeframe,
        holdMinutes: s.closedAt && s.createdAt ? Math.round((s.closedAt.getTime() - s.createdAt.getTime()) / 60_000) : 0,
        reachedTp: s.reachedTp,
        maxPnlPercent: s.maxPnlPercent,
        netPnlPercent: s.pnlPercent,
        flowVerdict,
        flowScore,
        regimeTag: regimeOf(tags),
        tags,
        factorVotes: votes,
        occurredAt: (s.closedAt ?? s.createdAt).toISOString()
    };
}
async function buildTp3Lab(windowDays = 14) {
    const since = new Date(Date.now() - windowDays * 24 * 3600_000);
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP3",
                    "SL"
                ]
            },
            closedAt: {
                gte: since
            }
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const full = rows.filter((s)=>s.status === "TP3");
    const stopped = rows.filter((s)=>s.status === "SL");
    const cases = rows.map(toCase);
    const fullCases = cases.filter((c)=>c.outcome === "TP3_FULL");
    const stoppedCases = cases.filter((c)=>c.outcome === "SL");
    const countTags = (list)=>{
        const m = new Map();
        for (const c of list)for (const t of c.tags)if (!t.startsWith("REGIME-")) m.set(t, (m.get(t) ?? 0) + 1);
        return topN(m, 4);
    };
    const countStrategy = (list)=>{
        const m = {};
        for (const c of list)m[c.strategy] = (m[c.strategy] ?? 0) + 1;
        return m;
    };
    const countSymbols = (list)=>{
        const m = new Map();
        for (const c of list)m.set(c.symbol, (m.get(c.symbol) ?? 0) + 1);
        return topN(m, 4);
    };
    const avg = (nums)=>nums.length ? nums.reduce((a, b)=>a + b, 0) / nums.length : 0;
    const fullTp = {
        count: fullCases.length,
        ratePct: rows.length ? Number((fullCases.length / rows.length * 100).toFixed(1)) : 0,
        avgConfidence: Math.round(avg(fullCases.map((c)=>c.confidence))),
        avgRr: Number(avg(fullCases.map((c)=>c.riskReward)).toFixed(2)),
        avgHoldMin: Math.round(avg(fullCases.map((c)=>c.holdMinutes))),
        flowConfirmShare: fullCases.length ? Number((fullCases.filter((c)=>c.flowVerdict === "CONFIRMS").length / fullCases.length * 100).toFixed(0)) : 0,
        topTags: countTags(fullCases),
        topSymbols: countSymbols(fullCases),
        byStrategy: countStrategy(fullCases)
    };
    const stoppedStats = {
        count: stoppedCases.length,
        avgConfidence: Math.round(avg(stoppedCases.map((c)=>c.confidence))),
        avgHoldMin: Math.round(avg(stoppedCases.map((c)=>c.holdMinutes))),
        flowConflictShare: stoppedCases.length ? Number((stoppedCases.filter((c)=>c.flowVerdict === "CONFLICTS").length / stoppedCases.length * 100).toFixed(0)) : 0,
        topTags: countTags(stoppedCases),
        byStrategy: countStrategy(stoppedCases)
    };
    const confDelta = fullTp.avgConfidence - stoppedStats.avgConfidence;
    const rrDelta = Number((fullTp.avgRr - avg(stoppedCases.map((c)=>c.riskReward))).toFixed(2));
    const contrast = {
        confDelta,
        rrDelta,
        note: fullCases.length && stoppedCases.length ? `full-TP winners deployed at ${confDelta >= 0 ? "+" : ""}${confDelta} conviction vs stop-outs, with ${rrDelta >= 0 ? "+" : ""}${rrDelta} wider targets — winners ran ${fullTp.avgHoldMin}m avg vs ${stoppedStats.avgHoldMin}m for losers` : "not enough TP3/SL pairs in the window for a contrast read"
    };
    return {
        windowDays,
        fullTp,
        stopped: stoppedStats,
        contrast,
        recentCases: cases.slice(0, 10)
    };
}
const RING_CAP = 12;
const PERSIST_KEY = "deep-learn";
const MIN_INTERVAL_MS = 30 * 60_000; // autonomous cycle every ~30min
const state = {
    lastRunAt: null,
    runs: 0,
    casesLearned: 0,
    lessons: [],
    lastQuestion: null,
    lastAnswer: null,
    label: "IDLE"
};
let restored = false;
async function persistState() {
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: PERSIST_KEY
            },
            create: {
                key: PERSIST_KEY,
                value: JSON.stringify(state)
            },
            update: {
                value: JSON.stringify(state)
            }
        });
    } catch  {
    /* non-fatal */ }
}
async function getDeepLearnState() {
    await restoreState();
    return {
        ...state
    };
}
async function restoreState() {
    if (restored) return;
    restored = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: PERSIST_KEY
            }
        });
        if (!row) return;
        const v = JSON.parse(row.value);
        if ((v.runs ?? 0) > state.runs) {
            state.lastRunAt = v.lastRunAt ?? null;
            state.runs = v.runs ?? 0;
            state.casesLearned = v.casesLearned ?? 0;
            state.lessons = v.lessons ?? [];
            state.lastQuestion = v.lastQuestion ?? null;
            state.lastAnswer = v.lastAnswer ?? null;
            state.label = v.label ?? "IDLE";
        }
    } catch  {
    /* fresh start */ }
}
/** Compact, audit-grade case file — the ONLY facts the LLM may reason over. */ function caseFile(c) {
    const flow = c.flowVerdict ? `${c.flowVerdict} ${c.flowScore !== null ? `${c.flowScore >= 0 ? "+" : ""}${c.flowScore}/25` : ""}` : "n/a";
    const votes = c.factorVotes && c.factorVotes.length ? c.factorVotes.map((v)=>`${v.factor}${v.vote >= 0 ? "+" : ""}${v.vote}`).join(",") : "n/a";
    return [
        `NX-${String(c.serial).padStart(4, "0")} ${c.symbol} ${c.direction} ${c.strategy} ${c.timeframe} → ${c.outcome}`,
        `conf ${c.confidence} · RR ${c.riskReward} · held ${c.holdMinutes}m · ladder ${c.reachedTp}/3 · maxPnl ${c.maxPnlPercent.toFixed(1)}% · net ${c.netPnlPercent.toFixed(1)}%`,
        `flow ${flow} · regime ${c.regimeTag ?? "n/a"} · tags ${c.tags.join(",") || "n/a"} · votes ${votes}`
    ].join(" | ");
}
async function runDeepLearnCycle(force = false) {
    await restoreState();
    if (!force && state.lastRunAt && Date.now() - new Date(state.lastRunAt).getTime() < MIN_INTERVAL_MS) {
        return {
            ran: false,
            learned: 0,
            reason: "throttled (30min)"
        };
    }
    const since = state.lastRunAt ? new Date(state.lastRunAt) : new Date(Date.now() - 48 * 3600_000);
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP3",
                    "SL"
                ]
            },
            closedAt: {
                gt: since
            }
        },
        orderBy: {
            closedAt: "asc"
        },
        take: 8
    });
    if (rows.length === 0) {
        state.lastRunAt = new Date().toISOString();
        await persistState();
        return {
            ran: false,
            learned: 0,
            reason: "no new TP3/SL outcomes since last cycle"
        };
    }
    const lab = await buildTp3Lab(14);
    // v8.2 GATE GAUGE — live reason ledger for the core (boundary band + blocks)
    const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateJournalForCore"])(12, 8);
    // v8.2 SHADOW-VETO Phase 0 — the core's own fence adjudications + A/B arms
    const shadow = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["shadowVetoForCore"])(6).catch(()=>({
            narrative: "SHADOW-VETO: unavailable this cycle.",
            verdictFiles: []
        }));
    // v10.2 SV-TELEMETRY — arm feed wiring narrative (best-effort, never blocks)
    const svTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["svTelemetryNarrative"])().catch(()=>"SV-TELEMETRY: unavailable this cycle.");
    // v10.8 FOUR-PACK journal — governance module verdicts in the research grounding
    const fpTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fourpackNarrative"])().catch(()=>"FOUR-PACK: unavailable this cycle.");
    const gateGrounding = [
        `GATE JOURNAL (live, 12h): ${gate.narrative}`,
        ...gate.boundaryFiles.slice(0, 8).map((l)=>`BOUNDARY VERDICT: ${l}`),
        ...gate.blockFiles.map((l)=>`GATE BLOCK: ${l}`),
        `SHADOW-VETO: ${shadow.narrative}`,
        `SV-TELEMETRY: ${svTel}`,
        `FOUR-PACK: ${fpTel}`,
        ...shadow.verdictFiles.slice(0, 6).map((l)=>`SHADOW ADJUDICATION: ${l}`)
    ].join("\n");
    const tp3Cases = rows.filter((r)=>r.status === "TP3").map(toCase);
    const slCases = rows.filter((r)=>r.status === "SL").map(toCase);
    const allCases = [
        ...tp3Cases,
        ...slCases
    ].map(caseFile).join("\n");
    const question = [
        `RESEARCH QUESTIONS for this cycle (${tp3Cases.length} full-TP, ${slCases.length} stopped-out):`,
        "1. What did the full-TP winners share at deploy time (confluence votes, flow verdict, regime, conviction, R:R) that let them run the whole ladder?",
        "2. What did the stopped-out trades show that should have been a warning?",
        "3. Which single, measurable behaviour change would most improve the next 20 deployments?",
        // v8.2 GATE GAUGE — reason-level research question fed by the live journal
        "4. GATE JOURNAL (below): the boundary band (gap −8..0 from the effective threshold) is where confirm and reject blur — which boundary reasons (thr modifiers, opposing votes, hard blocks) actually predicted later TP3 vs SL outcomes, and which gate modifier deserves tightening or loosening on that measured evidence?",
        // v8.2 SHADOW-VETO — the core's own adjudication quality
        "5. SHADOW-VETO (below): your own veto-only adjudications at the fence are now outcome-tracked — are your VETO calls landing on trades that lose and your TRADE calls on trades that win? Cite the A/B arms (real-keep / real-veto / paper-keep / paper-veto) with their Wilson-LB numbers; if any arm has <30 settled outcomes, say the evidence is still forming — never extrapolate from thin arms."
    ].join(" ");
    const grounding = [
        "TP3 LAB CONTRAST (measured, 14d): " + lab.contrast.note,
        `FULL-TP profile: n=${lab.fullTp.count} rate ${lab.fullTp.ratePct}% avgConf ${lab.fullTp.avgConfidence} avgRR ${lab.fullTp.avgRr} flow-CONFIRMS ${lab.fullTp.flowConfirmShare}% tags ${lab.fullTp.topTags.map(([t, n])=>`${t}×${n}`).join(",") || "n/a"}`,
        `STOP-OUT profile: n=${lab.stopped.count} avgConf ${lab.stopped.avgConfidence} held ${lab.stopped.avgHoldMin}m flow-CONFLICTS ${lab.stopped.flowConflictShare}% tags ${lab.stopped.topTags.map(([t, n])=>`${t}×${n}`).join(",") || "n/a"}`,
        "CASE FILES:",
        allCases,
        // v8.2 GATE JOURNAL — the reasons layer the boundary band lives on
        gateGrounding
    ].join("\n");
    const { aiDeepLearn } = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)");
    const result = await aiDeepLearn(grounding, question, lab);
    // persist lessons (newest first, ring-capped)
    const at = new Date().toISOString();
    const lessons = result.lessons.map((l)=>({
            at,
            scope: l.scope,
            pattern: String(l.pattern).slice(0, 240),
            evidence: String(l.evidence).slice(0, 300),
            action: String(l.action).slice(0, 240),
            confidence: Math.max(0, Math.min(100, Math.round(Number(l.confidence) || 60))),
            label: result.label
        }));
    state.lessons = [
        ...lessons,
        ...state.lessons
    ].slice(0, RING_CAP);
    state.lastQuestion = question.slice(0, 600);
    state.lastAnswer = String(result.hypothesis ?? "").slice(0, 2400);
    state.lastRunAt = at;
    state.runs++;
    state.casesLearned += rows.length;
    state.label = result.label;
    await persistState();
    // broadcast the strongest lesson to the terminal feed (audited)
    const lead = lessons[0];
    if (lead) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.create({
            data: {
                signalId: null,
                symbol: null,
                type: "ENGINE",
                level: "ai",
                message: `AI DEEP-LEARN #${state.runs}: studied ${rows.length} terminal outcomes (${tp3Cases.length} full-TP / ${slCases.length} stopped) — [${lead.scope}] ${lead.pattern} → ${lead.action} (${lead.label}, conf ${lead.confidence}%) · lesson stored to agent memory`
            }
        });
    }
    return {
        ran: true,
        learned: rows.length
    };
}
async function maybeAutoDeepLearn() {
    try {
        await runDeepLearnCycle(false);
    } catch (err) {
        console.error("[deep-learn]", err);
    }
}
}),
"[project]/src/lib/analyst-context.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildAnalystGrounding",
    ()=>buildAnalystGrounding
]);
// ── FlowRadar//AI ANALYST — live grounding bundle (server-only, v5.2) ──
// Root-cause fix for "analyst answers are vague and based on stale data":
// every chat request now receives a FRESH measured telemetry bundle built
// from the same sources the engine itself reads — prices, flow matrix,
// open risk, realized memory, gates, liquidation feed, trigger bus.
// No static snapshots. No training-data guesses. Every number is live.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/flow.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/triggers.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/regime.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/liquidations.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/governor.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/backtest.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stats$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/stats.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$tp3$2d$lab$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/tp3-lab.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$verdict$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/verdict.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volOnset$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/volOnset.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const CACHE_TTL = 8_000;
let cache = null;
async function buildAnalystGrounding() {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.bundle;
    const bundle = await buildFresh();
    cache = {
        at: Date.now(),
        bundle
    };
    return bundle;
}
async function buildFresh() {
    const now = new Date().toISOString().replace("T", " ").slice(0, 16) + " UTC";
    try {
        const [assets, gate, governor, bt, liqStatus, bus, stats, tp3Lab, deepLearn, onsetBoard, onsetTs, verdictCore] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findMany({
                orderBy: {
                    volume24h: "desc"
                },
                take: 8
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGovernorState"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$backtest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getBacktest"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$liquidations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getLiquidationStatus"])(),
            Promise.resolve((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTriggerBusSummary"])()),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stats$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["buildStats"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$tp3$2d$lab$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["buildTp3Lab"])(14).catch(()=>null),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$tp3$2d$lab$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDeepLearnState"])(),
            // VOL-ONSET grounding — deadline-guarded so a cold board rebuild never
            // stalls the chat (the board itself answers stale after its own 12s cap)
            Promise.race([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volOnset$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getOnsetBoard"])(),
                new Promise((res)=>setTimeout(()=>res(null), 9_000))
            ]).catch(()=>null),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$volOnset$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["onsetTagStats"])().catch(()=>null),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$verdict$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVerdictCoreState"])().catch(()=>null)
        ]);
        const acct = stats.account;
        // flow metrics for the top-8 liquid symbols (same path the gate reads)
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureFlow"])(assets.map((a)=>a.symbol));
        const flowRows = await Promise.all(assets.map(async (a)=>({
                sym: a.symbol,
                m: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchFlowMetrics"])(a.symbol)
            })));
        const flowStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$flow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getFlowStatus"])();
        // open + settled risk
        const [open, settled] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
                where: {
                    status: {
                        in: [
                            "ACTIVE",
                            "TP1",
                            "TP2"
                        ]
                    }
                },
                select: {
                    serial: true,
                    symbol: true,
                    direction: true,
                    confidence: true,
                    pnlPercent: true,
                    entryPrice: true
                },
                orderBy: {
                    createdAt: "desc"
                },
                take: 6
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
                where: {
                    status: {
                        in: [
                            "TP1",
                            "TP2",
                            "TP3",
                            "SL",
                            "EXPIRED",
                            "CLOSED"
                        ]
                    }
                },
                select: {
                    serial: true,
                    symbol: true,
                    direction: true,
                    status: true,
                    pnlPercent: true,
                    createdAt: true
                },
                orderBy: {
                    createdAt: "desc"
                },
                take: 5
            })
        ]);
        // operator journal → analyst (closes the operator→AI feedback loop:
        // notes written on signal cards were previously write-only for the AI)
        const journal = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                operatorNotes: {
                    not: ""
                }
            },
            select: {
                serial: true,
                symbol: true,
                operatorNotes: true,
                notesUpdatedAt: true
            },
            orderBy: {
                notesUpdatedAt: "desc"
            },
            take: 5
        }).catch(()=>[]);
        const lines = [
            `═══ LIVE TELEMETRY — ${now} (grounding: every number below is MEASURED right now; cite ONLY these numbers, never invent or rely on training data) ═══`,
            `MARKET: ${assets.map((a)=>`${a.symbol} $${a.price >= 1000 ? a.price.toFixed(0) : a.price.toPrecision(5)} ${a.change24h >= 0 ? "+" : ""}${a.change24h.toFixed(2)}%${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekRegime"])(a.symbol) ? ` [${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekRegime"])(a.symbol).regime}]` : ""}`).join(" · ")}`,
            flowRows.length ? `ORDER FLOW (CVD net % of vol / taker buy-ratio / OI Δ1h / funding 8h / crowd L/S): ${flowRows.filter((r)=>r.m !== null).map((r)=>{
                // FlowMetrics fields are all number|null — coerce honestly to 0 for display
                const cvd = r.m.cvdNetPctOfVol ?? 0;
                const tk = r.m.takerRatio ?? 0;
                const oi = r.m.oiDelta1h ?? 0;
                const fund = (r.m.funding8h ?? 0) * 100;
                const crowd = r.m.crowdLongShort ?? 0;
                return `${r.sym} cvd ${cvd >= 0 ? "+" : ""}${cvd.toFixed(1)}% · tk ${tk.toFixed(2)} · oiΔ1h ${oi >= 0 ? "+" : ""}${oi.toFixed(1)}% · fund ${fund.toFixed(3)}% · crowd ${crowd.toFixed(2)}`;
            }).join(" | ")}` : "ORDER FLOW: measuring…",
            `FLOW COVERAGE: ${flowStatus.covered} symbols measured live`,
            liqStatus ? `LIQUIDATION FEED: ${liqStatus.online ? "online" : "offline"}${liqStatus.dataStalled ? " (stream stalled — no live cascade data)" : ""}` : "LIQUIDATION FEED: offline (sandbox stream blocked — say so if asked about cascades)",
            open.length ? `OPEN SIGNALS: ${open.map((o)=>`NX-${String(o.serial).padStart(4, "0")} ${o.symbol} ${o.direction} entry ${o.entryPrice} now ${o.pnlPercent >= 0 ? "+" : ""}${o.pnlPercent.toFixed(2)}% (conf ${o.confidence})`).join(" · ")}` : "OPEN SIGNALS: none — engine deployed nothing yet (gates open since last relief)",
            settled.length ? `LAST SETTLED: ${settled.map((s)=>`NX-${String(s.serial).padStart(4, "0")} ${s.symbol} ${s.direction} → ${s.status} ${s.pnlPercent >= 0 ? "+" : ""}${s.pnlPercent.toFixed(2)}%`).join(" · ")}` : "LAST SETTLED: no history yet",
            `ENGINE GATES: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["describeGate"])(gate)}`,
            `ACCOUNT (SIM): balance $${acct.balance.toFixed(2)} · equity $${acct.equity.toFixed(2)} · open ${acct.openPositions} · exposure $${acct.exposureUsd.toFixed(2)} · fees paid $${acct.feesPaid.toFixed(2)}`,
            bt ? `BACKTEST MEMORY: n=${bt.n} WR ${bt.winRate}% Wilson-LB ${bt.wilsonLB}% expectancy ${bt.avgNetPct}%/trade — ${bt.verdict}` : "BACKTEST MEMORY: no replay yet",
            tp3Lab ? `TP3 DEEP-LAB (14d): full-TP ${tp3Lab.fullTp.count}/${tp3Lab.fullTp.count + tp3Lab.stopped.count} (${tp3Lab.fullTp.ratePct}%) avgConf ${tp3Lab.fullTp.avgConfidence} avgRR ${tp3Lab.fullTp.avgRr} vs stop-outs avgConf ${tp3Lab.stopped.avgConfidence} — ${tp3Lab.contrast.note}` : "TP3 DEEP-LAB: measuring…",
            deepLearn.lessons.length ? `DEEP-LEARN LESSONS (apply these, newest first): ${deepLearn.lessons.slice(0, 3).map((l)=>`[${l.scope}] ${l.pattern} → ${l.action}`).join(" | ")}` : "DEEP-LEARN LESSONS: none yet — research desk cycles after TP3/SL outcomes settle",
            governor.log[0] ? `GOVERNOR LAST CYCLE: ${governor.log[0].at.slice(0, 16)}Z ${governor.log[0].gatesAfter}` : "GOVERNOR: no cycle yet",
            verdictCore?.lastAnswer ? `VERDICT-CORE (gate-journal deep-learn, ${verdictCore.runs} cycles, ${verdictCore.lastRunAt ? verdictCore.lastRunAt.slice(0, 16) + "Z" : "n/a"}): ${verdictCore.lastAnswer.slice(0, 420)}${verdictCore.lessons[0] ? ` · TOP LESSON: ${verdictCore.lessons[0].pattern} → ${verdictCore.lessons[0].action}` : ""}` : "VERDICT-CORE: no learning cycle yet — the gate journal (confirm/reject reasons at the decision border) accrues automatically",
            `GATE JOURNAL: the deploy gate journals every confirm/reject verdict with its full reason payload (v8.2) — cite it when asked WHY signals pass or fail`,
            onsetBoard ? `VOL-ONSET RADAR (15m eruption bars ≥5× trailing median — LEADING view, recency-decay ranked): ${onsetBoard.rows.filter((r)=>r.hot).length} hot · ${onsetBoard.rows.length ? onsetBoard.rows.slice(0, 3).map((r)=>`${r.symbol} ${r.direction} score ${r.score} erupted ${r.minutesSince}m ago ×${r.displacementX.toFixed(1)} ft ${r.followThroughPct >= 0 ? "+" : ""}${r.followThroughPct.toFixed(1)}%${r.hot ? " HOT" : ""}`).join(" | ") : "no eruption bars in trailing 24h (quiet tape)"}${onsetTs ? ` — LEARNING: settled ${onsetTs.settledTotal}, tagged ${onsetTs.tagged.n} (WR ${onsetTs.tagged.winRatePct ?? "—"}%, avg net ${onsetTs.tagged.avgNetPct ?? "—"}%) vs rest ${onsetTs.rest.n} (WR ${onsetTs.rest.winRatePct ?? "—"}%, avg net ${onsetTs.rest.avgNetPct ?? "—"}%)` : ""}` : "VOL-ONSET RADAR: measuring (board rebuilding — do not invent numbers)",
            `TRIGGER BUS: ${JSON.stringify(bus.counts)} events measured`,
            journal.length ? `OPERATOR JOURNAL (operator's own notes — acknowledge and respect them when relevant): ${journal.map((j)=>`NX-${String(j.serial).padStart(4, "0")} ${j.symbol}: “${(j.operatorNotes ?? "").slice(0, 90)}”`).join(" · ")}` : "OPERATOR JOURNAL: no notes yet"
        ];
        const recentEvents = (bus.last ?? []).slice(0, 4);
        if (recentEvents.length) {
            lines.push(`LATEST TRIGGERS: ${recentEvents.map((e)=>`[${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$triggers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LAYER_LABEL"][e.layer] ?? e.layer}] ${e.symbol}`).join(" · ")}`);
        }
        return lines.join("\n");
    } catch (err) {
        console.error("[analyst-context]", err);
        return `═══ LIVE TELEMETRY — ${now} ═══\n(grounding partially unavailable: telemetry builder errored — answer generally and SAY the live feed is degraded rather than inventing numbers)`;
    }
}
}),
];

//# sourceMappingURL=src_lib_917cd0f4._.js.map