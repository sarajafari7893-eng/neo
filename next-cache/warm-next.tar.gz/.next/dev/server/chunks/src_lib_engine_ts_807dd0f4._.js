module.exports = [
"[project]/src/lib/engine.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ebed90ed._.js",
  "server/chunks/src_lib_engine_ts_a868ea96._.js",
  "server/chunks/src_lib_99e156e4._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__8d16f881._.js",
  "server/chunks/[externals]__ce07bf7f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/engine.ts [instrumentation] (ecmascript)");
    });
});
}),
];