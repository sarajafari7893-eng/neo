module.exports = [
"[project]/node_modules/z-ai-web-dev-sdk/dist/index.js [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__8a7b0083._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/z-ai-web-dev-sdk/dist/index.js [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/supervisor.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_bd2c2b1f._.js",
  "server/chunks/[root-of-the-server]__f29d6ab9._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/supervisor.ts [instrumentation] (ecmascript)");
    });
});
}),
"[project]/src/lib/verdict.ts [instrumentation] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__6488a181._.js",
  "server/chunks/[root-of-the-server]__ea4c1ab6._.js",
  "server/chunks/[externals]_@prisma_client_c5ee037a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/verdict.ts [instrumentation] (ecmascript)");
    });
});
}),
];