module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[externals]/node:fs [external] (node:fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs", () => require("node:fs"));

module.exports = mod;
}),
"[externals]/node:readline [external] (node:readline, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:readline", () => require("node:readline"));

module.exports = mod;
}),
"[project]/src/lib/seq-stop.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo v10.11 SEQ-STOP — ALWAYS-VALID SEQUENTIAL EARLY DECISION ──
// SUPERVISOR proposal 2026-09-17 14:55Z, operator APPROVE via bridge 2026-09-17
// 17:50Z («پیشنهادات سوپروایزر رو کامل و مهندسی انجام بده + گزارشات»).
//
// WHY (SUPERVISOR audit 1455Z): the shadow-veto promotion gate waits for
// n=30 settled per real arm. Three measured problems with waiting:
//   (1) LATENCY — epoch fill pace ≈ 5.2 settles/day → the gate lands in
//       ~3.5 days; a decisive answer may exist much earlier.
//   (2) WINDOW FRAGILITY — the rolling-30 paper-keep cohort swung 13W/+$1.48
//       → 8W/−$10.32 (−$11.8) inside 4h: a decision taken exactly at fill
//       samples one arbitrary slice of a moving window anyway.
//   (3) SELECTION BIAS — the paper-veto arm is structurally 0/30 in shadow
//       mode (it can only fill once veto authority exists), so "wait for all
//       arms" silently means "decide with the counterfactual arm missing".
// SEQ-STOP adds a SEQUENTIAL STOPPING RULE on top of the fixed-n gate: the
// evaluation may stop EARLY (PROMOTE-EARLY / ABORT-EARLY) the moment the
// evidence crosses an always-valid boundary, with the type-I error spent
// across looks by an O'Brien-Fleming spending function (conservative early,
// full α only at t=1). Waiting for n=30 remains the fallback path — the
// fixed gate is UNCHANGED; the sequential rule only ADDS an earlier,
// statistically disciplined exit.
//
// STATISTIC: two-proportion z on the REAL arms,
//   d̂ = p_keep − p_veto   (positive ⇒ the would-veto cohort performs WORSE
//   than the would-keep cohort ⇒ blocking those trades adds value),
//   SE = sqrt( p̄(1−p̄)(1/n_keep + 1/n_veto) )   (pooled; H0: p_keep = p_veto),
//   z = d̂ / SE,  information fraction t = (n_keep + n_veto) / (2·PLANNED_MAX_N).
// BOUNDARY (O'Brien-Fleming spending, two-sided, α = 0.05):
//   c(t) = z_{α/2} / √t ;   α_spent(t) = 2 − 2Φ(c(t))
//   → |z| ≥ c(t) stops the trial in the direction of the sign of z.
//   PROMOTE-EARLY: z ≥ +c(t) AND would-veto net < 0 (economic concordance,
//     mirrors the fixed gate's "net must be negative" criterion).
//   ABORT-EARLY:   z ≤ −c(t) AND would-veto net > 0 (the veto instinct is
//     measurably counterproductive → refresh/retire, never promote).
//   CONTINUE: otherwise.
// GUARDRAILS: no stop before MIN_ARM_N=12 settled per arm (sub-significant
// mini-windows must not end a 60-trade trial); SE floor to reject degenerate
// p̄∈{0,1}; fail-CONTINUE on any malformed input (this module must never
// throw into the promotion path).
//
// Validation (2026-09-17, independent numerical mirror): t=0.4 → c=3.099,
// α=0.00194 · t=0.5 → c=2.772 · t=2/3 → c=2.400 · t=1.0 → c=1.960, α=0.05.
__turbopack_context__.s([
    "SEQ_STOP",
    ()=>SEQ_STOP,
    "ofAlphaSpent",
    ()=>ofAlphaSpent,
    "ofBoundary",
    ()=>ofBoundary,
    "seqStopEvaluate",
    ()=>seqStopEvaluate
]);
const SEQ_STOP = {
    MIN_ARM_N: 12,
    PLANNED_MAX_N: 30,
    ALPHA: 0.05
};
const Z_ALPHA_2 = 1.959963984540054; // z_{0.025} two-sided 95%
/** Abramowitz-Stegun 7.1.26 erf (|ε| ≤ 1.5e-7) — no external deps. */ function erf(x) {
    const s = x < 0 ? -1 : 1;
    const a = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * a);
    const y = 1 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-a * a);
    return s * y;
}
function phi(z) {
    return 0.5 * (1 + erf(z / Math.SQRT2));
}
function ofBoundary(t) {
    const tc = Math.min(1, Math.max(1e-6, t));
    return Z_ALPHA_2 / Math.sqrt(tc);
}
function ofAlphaSpent(t) {
    return Math.max(0, Math.min(1, 2 * (1 - phi(ofBoundary(t)))));
}
function seqStopEvaluate(keep, veto) {
    const base = {
        state: "CONTINUE",
        z: null,
        boundary: null,
        infoFrac: null,
        alphaSpent: null,
        dPct: null,
        minNMet: false,
        detail: "",
        checkedAt: Date.now()
    };
    try {
        const nK = Math.max(0, Math.floor(Number(keep?.n) || 0));
        const nV = Math.max(0, Math.floor(Number(veto?.n) || 0));
        const wK = Math.min(nK, Math.max(0, Math.floor(Number(keep?.wins) || 0)));
        const wV = Math.min(nV, Math.max(0, Math.floor(Number(veto?.wins) || 0)));
        const netV = Number(veto?.netUsd) || 0;
        const t = (nK + nV) / (2 * SEQ_STOP.PLANNED_MAX_N);
        const boundary = ofBoundary(t);
        const alphaSpent = ofAlphaSpent(t);
        const minNMet = nK >= SEQ_STOP.MIN_ARM_N && nV >= SEQ_STOP.MIN_ARM_N;
        const info = {
            boundary,
            infoFrac: Number(Math.min(1, t).toFixed(3)),
            alphaSpent: Number(alphaSpent.toFixed(5)),
            minNMet
        };
        if (nK < 2 || nV < 2) {
            return {
                ...base,
                ...info,
                detail: `seq-stop CONTINUE — cohorts still warming (keep ${nK}, veto ${nV}; no test before n≥2 per arm)`
            };
        }
        const pK = wK / nK;
        const pV = wV / nV;
        const d = pK - pV; // + ⇒ veto cohort worse ⇒ promote side
        const pBar = (wK + wV) / (nK + nV);
        const se = Math.sqrt(pBar * (1 - pBar) * (1 / nK + 1 / nV));
        if (!Number.isFinite(se) || se < 1e-4) {
            return {
                ...base,
                ...info,
                dPct: Number((d * 100).toFixed(1)),
                detail: `seq-stop CONTINUE — degenerate pooled rate (p̄=${pBar.toFixed(3)}), statistic undefined`
            };
        }
        const z = d / se;
        const dPct = Number((d * 100).toFixed(1));
        if (!minNMet) {
            return {
                ...base,
                ...info,
                z: Number(z.toFixed(3)),
                dPct,
                detail: `seq-stop CONTINUE — z=${z.toFixed(2)} vs c(t)=${boundary.toFixed(2)} at t=${Math.min(1, t).toFixed(2)}, but min-n guard active (need ≥${SEQ_STOP.MIN_ARM_N} per arm; have keep ${nK}, veto ${nV})`
            };
        }
        if (z >= boundary) {
            if (netV < 0) {
                return {
                    ...base,
                    ...info,
                    state: "PROMOTE-EARLY",
                    z: Number(z.toFixed(3)),
                    dPct,
                    detail: `seq-stop PROMOTE-EARLY (always-valid, OF α=${alphaSpent.toFixed(4)} at t=${Math.min(1, t).toFixed(2)}): would-veto cohort WR is ${Math.abs(dPct).toFixed(1)}pp BELOW would-keep (z=${z.toFixed(2)} ≥ c=${boundary.toFixed(2)}) with net $${netV.toFixed(2)} < 0 — blocking those trades adds measured value; early decision justified`
                };
            }
            return {
                ...base,
                ...info,
                z: Number(z.toFixed(3)),
                dPct,
                detail: `seq-stop CONTINUE — WR boundary crossed (${z.toFixed(2)} ≥ ${boundary.toFixed(2)}) but economic guard fails (would-veto net $${netV.toFixed(2)} ≥ 0): rate separation without concordant PnL is not promotion evidence`
            };
        }
        if (z <= -boundary) {
            if (netV > 0) {
                return {
                    ...base,
                    ...info,
                    state: "ABORT-EARLY",
                    z: Number(z.toFixed(3)),
                    dPct,
                    detail: `seq-stop ABORT-EARLY (always-valid, OF α=${alphaSpent.toFixed(4)} at t=${Math.min(1, t).toFixed(2)}): would-veto cohort WR is ${dPct.toFixed(1)}pp ABOVE would-keep (z=${z.toFixed(2)} ≤ −c=${(-boundary).toFixed(2)}) with net $${netV.toFixed(2)} > 0 — the veto instinct is counterproductive; recommend epoch refresh / adjudicator re-tune, never promote this evidence`
                };
            }
            return {
                ...base,
                ...info,
                z: Number(z.toFixed(3)),
                dPct,
                detail: `seq-stop CONTINUE — abort-side boundary touched (${z.toFixed(2)} ≤ ${(-boundary).toFixed(2)}) but economic guard fails (would-veto net $${netV.toFixed(2)} ≤ 0): mixed signal, keep collecting`
            };
        }
        return {
            ...base,
            ...info,
            z: Number(z.toFixed(3)),
            dPct,
            detail: `seq-stop CONTINUE — z=${z.toFixed(2)} inside (−${boundary.toFixed(2)}, +${boundary.toFixed(2)}) at t=${Math.min(1, t).toFixed(2)} (α spent ${alphaSpent.toFixed(4)}); keep=${nK}, veto=${nV} settled`
        };
    } catch (e) {
        return {
            ...base,
            detail: `seq-stop CONTINUE — evaluation error suppressed: ${e instanceof Error ? e.message : String(e)}`
        };
    }
}
}),
"[project]/src/lib/db.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[project]/src/lib/gate-settings.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "describeClamps",
    ()=>describeClamps,
    "describeGate",
    ()=>describeGate,
    "gateClamps",
    ()=>gateClamps,
    "getGateSettings",
    ()=>getGateSettings,
    "putGateSettings",
    ()=>putGateSettings
]);
// ── NEXUS//SIGNALS operator gate tunables (server-only) ──
// Persisted in EngineSetting, clamped to safe ranges, every change auditable.
// v5.1: adds UNIVERSE SIZE — how much of the USDT-M futures market the
// flow scanner tracks (the operator's answer to "scan domain too low").
// v6.3 (operator mandate: dynamic risk management): adds the RISK PROFILE
// knobs the AI governor owns — slAtrMult (stop distance in ATR multiples),
// rrScale (scales the computed R:R ladder) and regimeGuard (regime-filter
// hardening level). MIN_SCORE itself is no longer a flat constant: the
// regime ruling contributes a per-candidate threshold adjustment so the
// EFFECTIVE threshold adapts to the market the candidate lives in.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
// v6.3: minScore floor lowered 20→12 — measured pathology: the LLM governor
// requested 15 for 20+ consecutive cycles while the clamp silently pinned the
// knob at 20 (the operator-visible "MIN_SCORE is constant" behavior). The
// floor is a clamp, not policy — the evidence gate + hysteresis remain the
// real anti-noise protection.
const CLAMPS = {
    dlConfFloor: [
        0,
        1,
        0
    ],
    maxLevCap: [
        1,
        50,
        20
    ],
    minScore: [
        12,
        60,
        35
    ],
    minScorePinned: [
        0,
        1,
        0
    ],
    flowShortlist: [
        1,
        6,
        3
    ],
    flowVetoScore: [
        4,
        25,
        8
    ],
    universeSize: [
        12,
        64,
        40
    ],
    ttlExtendMax: [
        0,
        3,
        1
    ],
    ttlExtendMinutes: [
        15,
        240,
        60
    ],
    ttlNearTpPct: [
        0.3,
        5,
        1.5
    ],
    slAtrMult: [
        0.8,
        2.5,
        1.5
    ],
    rrScale: [
        0.75,
        1.35,
        1.0
    ],
    tp1RMult: [
        0.3,
        1,
        0.55
    ],
    regimeGuard: [
        0,
        2,
        1
    ],
    regimeGuardPinned: [
        0,
        1,
        1
    ],
    maxActive: [
        2,
        8,
        5
    ],
    riskPerTrade: [
        0.5,
        1.5,
        1.0
    ],
    beTrailPct: [
        0,
        40,
        10
    ],
    shortSizeMult: [
        0.3,
        1,
        1.0
    ],
    breakoutGuard: [
        0,
        2,
        0
    ],
    onsetRetestGuard: [
        0,
        1,
        1
    ],
    chaseThrAdj: [
        0,
        15,
        6
    ],
    leveredRiskCap: [
        10,
        100,
        25
    ],
    shortGuard: [
        0,
        2,
        2
    ],
    beArmMovePct: [
        0,
        10,
        1.5
    ],
    beArmRMult: [
        0,
        1,
        0.5
    ],
    beBankFrac: [
        0,
        0.5,
        0.25
    ],
    earlyExitGuard: [
        0,
        1,
        1
    ],
    earlyExitFrac: [
        0.3,
        0.9,
        0.5
    ],
    earlyExitR: [
        0,
        1,
        0.45
    ],
    decisiveFilter: [
        0,
        2,
        1
    ],
    decisiveErMin: [
        0,
        1,
        0.12
    ],
    volBarrier: [
        0,
        1,
        1
    ],
    volBarrierMult: [
        1.0,
        2.0,
        1.3
    ],
    volBarrierCapMin: [
        60,
        360,
        240
    ],
    volBarrierAdaptive: [
        0,
        1,
        1
    ],
    researchShadow: [
        0,
        1,
        1
    ],
    dislocationGate: [
        0,
        1,
        1
    ],
    dislocationWarnBps: [
        20,
        200,
        50
    ],
    dislocationSkipBps: [
        50,
        500,
        150
    ],
    probeDeploys: [
        0,
        1,
        1
    ]
};
const KEY = "gate";
let cache = null;
const CACHE_TTL = 15_000;
function clampAll(raw) {
    return {
        dlConfFloor: Math.min(CLAMPS.dlConfFloor[1], Math.max(CLAMPS.dlConfFloor[0], raw.dlConfFloor ?? CLAMPS.dlConfFloor[2])),
        maxLevCap: Math.min(CLAMPS.maxLevCap[1], Math.max(CLAMPS.maxLevCap[0], Math.round(raw.maxLevCap ?? CLAMPS.maxLevCap[2]))),
        minScore: Math.min(CLAMPS.minScore[1], Math.max(CLAMPS.minScore[0], raw.minScore ?? CLAMPS.minScore[2])),
        minScorePinned: Math.min(CLAMPS.minScorePinned[1], Math.max(CLAMPS.minScorePinned[0], Math.round(raw.minScorePinned ?? CLAMPS.minScorePinned[2]))),
        flowShortlist: Math.min(CLAMPS.flowShortlist[1], Math.max(CLAMPS.flowShortlist[0], raw.flowShortlist ?? CLAMPS.flowShortlist[2])),
        flowVetoScore: Math.min(CLAMPS.flowVetoScore[1], Math.max(CLAMPS.flowVetoScore[0], raw.flowVetoScore ?? CLAMPS.flowVetoScore[2])),
        universeSize: Math.min(CLAMPS.universeSize[1], Math.max(CLAMPS.universeSize[0], Math.round(raw.universeSize ?? CLAMPS.universeSize[2]))),
        ttlExtendMax: Math.min(CLAMPS.ttlExtendMax[1], Math.max(CLAMPS.ttlExtendMax[0], Math.round(raw.ttlExtendMax ?? CLAMPS.ttlExtendMax[2]))),
        ttlExtendMinutes: Math.min(CLAMPS.ttlExtendMinutes[1], Math.max(CLAMPS.ttlExtendMinutes[0], Math.round(raw.ttlExtendMinutes ?? CLAMPS.ttlExtendMinutes[2]))),
        ttlNearTpPct: Math.min(CLAMPS.ttlNearTpPct[1], Math.max(CLAMPS.ttlNearTpPct[0], raw.ttlNearTpPct ?? CLAMPS.ttlNearTpPct[2])),
        slAtrMult: Math.min(CLAMPS.slAtrMult[1], Math.max(CLAMPS.slAtrMult[0], raw.slAtrMult ?? CLAMPS.slAtrMult[2])),
        rrScale: Math.min(CLAMPS.rrScale[1], Math.max(CLAMPS.rrScale[0], raw.rrScale ?? CLAMPS.rrScale[2])),
        tp1RMult: Math.min(CLAMPS.tp1RMult[1], Math.max(CLAMPS.tp1RMult[0], raw.tp1RMult ?? CLAMPS.tp1RMult[2])),
        regimeGuard: Math.min(CLAMPS.regimeGuard[1], Math.max(CLAMPS.regimeGuard[0], Math.round(raw.regimeGuard ?? CLAMPS.regimeGuard[2]))),
        regimeGuardPinned: Math.min(CLAMPS.regimeGuardPinned[1], Math.max(CLAMPS.regimeGuardPinned[0], Math.round(raw.regimeGuardPinned ?? CLAMPS.regimeGuardPinned[2]))),
        maxActive: Math.min(CLAMPS.maxActive[1], Math.max(CLAMPS.maxActive[0], Math.round(raw.maxActive ?? CLAMPS.maxActive[2]))),
        riskPerTrade: Math.min(CLAMPS.riskPerTrade[1], Math.max(CLAMPS.riskPerTrade[0], raw.riskPerTrade ?? CLAMPS.riskPerTrade[2])),
        beTrailPct: Math.min(CLAMPS.beTrailPct[1], Math.max(CLAMPS.beTrailPct[0], raw.beTrailPct ?? CLAMPS.beTrailPct[2])),
        shortSizeMult: Math.min(CLAMPS.shortSizeMult[1], Math.max(CLAMPS.shortSizeMult[0], raw.shortSizeMult ?? CLAMPS.shortSizeMult[2])),
        breakoutGuard: Math.min(CLAMPS.breakoutGuard[1], Math.max(CLAMPS.breakoutGuard[0], Math.round(raw.breakoutGuard ?? CLAMPS.breakoutGuard[2]))),
        onsetRetestGuard: Math.min(CLAMPS.onsetRetestGuard[1], Math.max(CLAMPS.onsetRetestGuard[0], Math.round(raw.onsetRetestGuard ?? CLAMPS.onsetRetestGuard[2]))),
        chaseThrAdj: Math.min(CLAMPS.chaseThrAdj[1], Math.max(CLAMPS.chaseThrAdj[0], raw.chaseThrAdj ?? CLAMPS.chaseThrAdj[2])),
        leveredRiskCap: Math.min(CLAMPS.leveredRiskCap[1], Math.max(CLAMPS.leveredRiskCap[0], raw.leveredRiskCap ?? CLAMPS.leveredRiskCap[2])),
        shortGuard: Math.min(CLAMPS.shortGuard[1], Math.max(CLAMPS.shortGuard[0], Math.round(raw.shortGuard ?? CLAMPS.shortGuard[2]))),
        beArmMovePct: Math.min(CLAMPS.beArmMovePct[1], Math.max(CLAMPS.beArmMovePct[0], raw.beArmMovePct ?? CLAMPS.beArmMovePct[2])),
        beArmRMult: Math.min(CLAMPS.beArmRMult[1], Math.max(CLAMPS.beArmRMult[0], raw.beArmRMult ?? CLAMPS.beArmRMult[2])),
        beBankFrac: Math.min(CLAMPS.beBankFrac[1], Math.max(CLAMPS.beBankFrac[0], raw.beBankFrac ?? CLAMPS.beBankFrac[2])),
        earlyExitGuard: Math.min(CLAMPS.earlyExitGuard[1], Math.max(CLAMPS.earlyExitGuard[0], Math.round(raw.earlyExitGuard ?? CLAMPS.earlyExitGuard[2]))),
        earlyExitFrac: Math.min(CLAMPS.earlyExitFrac[1], Math.max(CLAMPS.earlyExitFrac[0], raw.earlyExitFrac ?? CLAMPS.earlyExitFrac[2])),
        earlyExitR: Math.min(CLAMPS.earlyExitR[1], Math.max(CLAMPS.earlyExitR[0], raw.earlyExitR ?? CLAMPS.earlyExitR[2])),
        decisiveFilter: Math.min(CLAMPS.decisiveFilter[1], Math.max(CLAMPS.decisiveFilter[0], Math.round(raw.decisiveFilter ?? CLAMPS.decisiveFilter[2]))),
        decisiveErMin: Math.min(CLAMPS.decisiveErMin[1], Math.max(CLAMPS.decisiveErMin[0], raw.decisiveErMin ?? CLAMPS.decisiveErMin[2])),
        volBarrier: Math.min(CLAMPS.volBarrier[1], Math.max(CLAMPS.volBarrier[0], Math.round(raw.volBarrier ?? CLAMPS.volBarrier[2]))),
        volBarrierMult: Math.min(CLAMPS.volBarrierMult[1], Math.max(CLAMPS.volBarrierMult[0], raw.volBarrierMult ?? CLAMPS.volBarrierMult[2])),
        volBarrierCapMin: Math.min(CLAMPS.volBarrierCapMin[1], Math.max(CLAMPS.volBarrierCapMin[0], Math.round(raw.volBarrierCapMin ?? CLAMPS.volBarrierCapMin[2]))),
        volBarrierAdaptive: Math.min(CLAMPS.volBarrierAdaptive[1], Math.max(CLAMPS.volBarrierAdaptive[0], Math.round(raw.volBarrierAdaptive ?? CLAMPS.volBarrierAdaptive[2]))),
        researchShadow: Math.min(CLAMPS.researchShadow[1], Math.max(CLAMPS.researchShadow[0], Math.round(raw.researchShadow ?? CLAMPS.researchShadow[2]))),
        dislocationGate: Math.min(CLAMPS.dislocationGate[1], Math.max(CLAMPS.dislocationGate[0], Math.round(raw.dislocationGate ?? CLAMPS.dislocationGate[2]))),
        dislocationWarnBps: Math.min(CLAMPS.dislocationWarnBps[1], Math.max(CLAMPS.dislocationWarnBps[0], raw.dislocationWarnBps ?? CLAMPS.dislocationWarnBps[2])),
        dislocationSkipBps: Math.min(CLAMPS.dislocationSkipBps[1], Math.max(CLAMPS.dislocationSkipBps[0], raw.dislocationSkipBps ?? CLAMPS.dislocationSkipBps[2])),
        probeDeploys: Math.min(CLAMPS.probeDeploys[1], Math.max(CLAMPS.probeDeploys[0], Math.round(raw.probeDeploys ?? CLAMPS.probeDeploys[2])))
    };
}
async function getGateSettings() {
    if (cache && Date.now() - cache.at < CACHE_TTL) return cache.value;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        const value = row ? clampAll(JSON.parse(row.value)) : clampAll({});
        cache = {
            at: Date.now(),
            value
        };
        return value;
    } catch  {
        return clampAll({});
    }
}
async function putGateSettings(next) {
    // merge against CURRENT stored values — a partial update must never reset
    // untouched keys back to defaults (governor applies decisions one at a time)
    const cur = await getGateSettings();
    const value = clampAll({
        ...cur,
        ...next
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify(value)
        },
        update: {
            value: JSON.stringify(value)
        }
    });
    cache = {
        at: Date.now(),
        value
    };
    return value;
}
function describeGate(g) {
    const ttlGate = g.ttlExtendMax > 0 ? `+${g.ttlExtendMinutes}m ×≤${g.ttlExtendMax} @${g.ttlNearTpPct}%` : "OFF";
    const beTrail = g.beArmRMult > 0 ? `R×${g.beArmRMult.toFixed(2)}${g.beTrailPct > 0 ? `+${g.beTrailPct}%NET` : ""}+${g.beArmMovePct}%px` : g.beTrailPct > 0 ? `+${g.beTrailPct}%NET` : "OFF";
    const beBank = g.beBankFrac > 0 ? `BANK ${Math.round(g.beBankFrac * 100)}%` : "NO-BANK";
    const boGuard = g.breakoutGuard === 0 ? "OFF" : g.breakoutGuard === 1 ? "HALF-SIZE" : "VETO";
    const sg = g.shortGuard === 0 ? "OFF" : g.shortGuard === 1 ? "HTF-ALIGN" : "VETO";
    const early = g.earlyExitGuard ? `${Math.round(g.earlyExitFrac * 100)}%TTL@${g.earlyExitR.toFixed(2)}R` : "OFF";
    const dec = g.decisiveFilter === 0 ? "OFF" : g.decisiveFilter === 1 ? "ON×0.85" : "STRICT";
    const vb = g.volBarrier ? `ON×${g.volBarrierMult.toFixed(2)}@≤${g.volBarrierCapMin}m${g.volBarrierAdaptive ? `-ADAPTIVE(→${3 * g.volBarrierCapMin}m@p0)` : ""}` : "OFF";
    return `MIN_SCORE ${g.minScore}${g.minScorePinned ? " [PINNED]" : ""}(+dynamic thrAdj) · DECISIVE ${dec}@ER≥${g.decisiveErMin.toFixed(2)} · VOL-BARRIER ${vb} · FLOW-SHORTLIST ${g.flowShortlist} · FLOW-VETO ≤−${g.flowVetoScore} · UNIVERSE ${g.universeSize} · TTL-GATE ${ttlGate} · SL ${g.slAtrMult}×ATR · RR×${g.rrScale.toFixed(2)} · TP1 ${g.tp1RMult.toFixed(2)}R · REGIME-GUARD L${g.regimeGuard} · CAP ${g.maxActive} · RISK ×${g.riskPerTrade.toFixed(2)} · BE-TRAIL ${beTrail}·${beBank} · SHORT-GUARD ${sg} · EARLY-EXIT ${early} · R-SHADOW ${g.researchShadow ? "ON" : "OFF"} · G4-PROBE ${g.probeDeploys ? "ON@2h×0.5" : "OFF"} · SHORT-SIZE ×${g.shortSizeMult.toFixed(2)} · BREAKOUT-GUARD ${boGuard} · ONSET-RETEST ${g.onsetRetestGuard ? "ON@30%·CHASE+FADE" : "OFF"} · CHASE-ADJ +${g.chaseThrAdj} · RISK-CAP ${g.leveredRiskCap}% · DISLOCATION-GATE ${g.dislocationGate ? `ON@${g.dislocationWarnBps}/${g.dislocationSkipBps}bps` : "OFF"}`;
}
function describeClamps() {
    return Object.entries(CLAMPS).map(([k, [lo, hi, def]])=>`${k}[${lo}..${hi}]=${def}`).join(" ");
}
function gateClamps() {
    return CLAMPS;
}
}),
"[project]/src/lib/accounting.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo fee-aware accounting (pure, client-safe) ──
// Paper account starts at $100. Margin sized by confidence coefficient.
// NET PnL = gross move − round-trip taker commission − pro-rated funding swap.
__turbopack_context__.s([
    "ACCOUNT_START_USD",
    ()=>ACCOUNT_START_USD,
    "FUNDING_RATE_8H",
    ()=>FUNDING_RATE_8H,
    "LADDER_TRANCHES",
    ()=>LADDER_TRANCHES,
    "TAKER_FEE_RATE",
    ()=>TAKER_FEE_RATE,
    "confidenceMargin",
    ()=>confidenceMargin,
    "feeBreakdown",
    ()=>feeBreakdown,
    "ladderWeightedMove",
    ()=>ladderWeightedMove
]);
const ACCOUNT_START_USD = 100;
const TAKER_FEE_RATE = 0.0005; // Binance USDT-M taker, per side
const FUNDING_RATE_8H = 0.0001; // 0.01% / 8h baseline
function feeBreakdown(marginUsd, leverage, grossPct, minutesHeld) {
    const notionalUsd = marginUsd * leverage;
    const commissionUsd = notionalUsd * TAKER_FEE_RATE * 2;
    const swapUsd = notionalUsd * FUNDING_RATE_8H * (minutesHeld / 480);
    const grossUsd = notionalUsd * (grossPct / 100);
    const totalFeesUsd = commissionUsd + swapUsd;
    const netUsd = grossUsd - totalFeesUsd;
    const netPct = marginUsd > 0 ? netUsd / marginUsd * 100 : 0;
    return {
        notionalUsd,
        commissionUsd,
        swapUsd,
        totalFeesUsd,
        grossUsd,
        netUsd,
        netPct
    };
}
function confidenceMargin(confidence, equity, freeMargin) {
    const clamped = Math.min(96, Math.max(55, confidence));
    const pct = 0.02 + (clamped - 55) / (96 - 55) * 0.06; // 2%..8%
    let margin = equity * pct;
    margin = Math.max(1, Math.min(margin, equity * 0.1, freeMargin));
    return Number(margin.toFixed(2));
}
const LADDER_TRANCHES = {
    tp1: 0.5,
    tp2: 0.3,
    runner: 0.2
};
function ladderWeightedMove(tranches) {
    if (tranches.length === 0) return 0;
    const totalW = tranches.reduce((a, t)=>a + t.weight, 0);
    if (totalW <= 0) return 0;
    return tranches.reduce((a, t)=>a + t.weight * t.movePct, 0) / totalW;
}
}),
"[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "configureFapiGate",
    ()=>configureFapiGate,
    "effectiveBudgetPer60s",
    ()=>effectiveBudgetPer60s,
    "fapiBanActivity",
    ()=>fapiBanActivity,
    "fapiBanRemainingMs",
    ()=>fapiBanRemainingMs,
    "fapiEgressStatus",
    ()=>fapiEgressStatus,
    "fapiGateStats",
    ()=>fapiGateStats,
    "gateFetch",
    ()=>gateFetch,
    "isUnknownScopeKey",
    ()=>isUnknownScopeKey,
    "sampleEgressIp",
    ()=>sampleEgressIp
]);
// ── NEXUS//SIGNALS FAPI GATE (server-only, v10.24 — Task 34-a) ──────────────
// Process-wide WEIGHT-BASED token bucket for Binance USDT-M futures REST
// (fapi.binance.com). WHY: 9+ modules in the Next.js process each did their own
// uncoordinated fetch() to the same host and the trade mini-service added
// ~1800 weight/min on top → Binance answered with HTTP 418 IP-bans carrying
// stacked multi-hour "banned until <ms>" windows. This gate is the single
// choke-point every futures-REST call in THIS process must pass:
//
//   · WEIGHT BUDGET — rolling-60s sliding window, default 1100 weight/min
//     (fapi real limit is 2400/min per IP; ~2× headroom absorbs drift between
//     weight estimates and the ungated mini-service until Task 34-b).
//   · LANES — "critical" (engine price feed, trigger measurements) executes
//     immediately when tokens exist, with ONE small negative retry after
//     250ms when momentarily empty; "telemetry" (every rotating scanner/
//     sampler/board) is DROPPED (returns null) when tokens are missing —
//     no unbounded queues, no storm amplification. All callers are
//     null-tolerant by contract.
//   · GLOBAL BAN AWARENESS (refined for the multi-IP egress pool — measured
//     2026-09-26: the sandbox egress rotates across several IPs and Binance's
//     418 body NAMES the banned one: «IP(47.57.x.x) banned until <ms>», with
//     different pool IPs banned in different windows):
//       – 418/429 body naming an IP → PER-IP ban record (capped now+35min),
//         the request's weight is REFUNDED (ban responses carry no weight
//         cost) and the call RETRIES (≤2, 120ms apart) — the pool usually
//         rotates onto a clean IP, so one unlucky draw never starves the app.
//       – ALL retries land on banned IPs → one unlucky draw too many: arm a
//         SHORT 60s global block, and only when that happens 3 times IN A ROW
//         (no successful call between) treat the pool as saturated and arm the
//         full zero-network window min(worst ban end, now+35min). A single
//         clean 2xx resets the streak — self-healing probes.
//       – 418/429 body WITHOUT a parseable IP (unknown scope — the classic
//         single-IP case): arm the global zero-network window immediately —
//         "banned until X" → min(X, now+35min); unparseable 418 → 10min;
//         unparseable 429 → 2min.
//       – While the global window is live, gateFetch returns null INSTANTLY —
//         zero network calls, so a live ban can never be extended by us.
//   · SINGLE-FLIGHT — one shared request per (host,path) while in flight and
//     for a 2s result window, so multiple modules asking the same endpoint
//     inside one tick share one weight spend.
//   · HOST AWARENESS — default host fapi.binance.com, optional alt host
//     (fapi1) for the market-feed availability ladder; bans/weight are
//     per-IP so both hosts share the SAME budget and ban state.
//
// NEVER THROWS: gateFetch returns parsed JSON or null on any failure.
// State lives on globalThis so Turbopack's dev module-graph duplication
// (route graph vs engine graph) still shares ONE process-wide bucket.
//
// SPOT (api.binance.com) and mirror-plane hosts (v14.0 Binance-only) must
// NOT pass through here — futures fapi host only.
//
// ── v12.0 EGRESS/IP MANAGER (Task 44-②, operator order «مدیریت egress/IP
// برای رفع بن fapi») ──────────────────────────────────────────────────────────
// Measured 2026-10-18: the sandbox egress is a rotating NAT pool and Binance
// bans POOL IPs with LONG windows (three named IPs banned until 10-18 19:47Z /
// 22:37Z / 10-19 13:26Z — each plain request is a lottery draw). Three new
// weapons:
//   1. EGRESS SAMPLER — api.ipify.org probe (3.5s timeout, 120s cache,
//      single-flight, never throws) tells us WHICH pool IP a draw exited from.
//   2. ROTATION-AWARE EARLY PROBE — while a global ban window is live, ONE
//      critical-lane call per 120s may bypass the silence IF the sampled IP is
//      clean: the moment the pool rotates, the window LIFTS instantly instead
//      of waiting out the 35min cap. A failed probe costs nothing (banned
//      responses carry no weight) and keeps the window armed.
//   3. BAN-LEDGER PERSISTENCE — named-IP ban records survive process
//      restarts (.data/fapi-gate/bans.json, 30s debounced) so a recycle no
//      longer re-learns the minefield by burning fresh probes.
//
// v10.25 (Task 41, operator order «بایننس ای پی را بلاک نکرده باشد و قابل
// جایگزینی باشد»): the host is env-swappable WITHOUT a code change — if fapi
// is ever hard-blocked (451/region/grey-list, not just a timed 418), set
// NEXUS_FAPI_HOST in .env to a reachable futures-mirror and restart the app.
// Default stays the canonical host. Downstream replaceability ladder is
// already layered: fapi-gate (this) → SPOT-MIRROR aggTrade WS → spot REST
// klines/price fallback → Binance-only liq lanes (v14.0).
//
// ── v14.2 BAN-AWARE RECOVERY PACER (operator order «توصیه‌ها را کامل و مهندسی
// انجام بده», trace 1a1a15fb6bc0bd75 — audit rec #3 «throttle REST بن-آگاه»,
// NX-3247 forensics fc143950) ───────────────────────────────────────────────
// WHY: the old budget was FLAT — the instant a ban window expired the full
// 1100 weight/min came back at once, every starved scanner refilled its
// rotation in the same minute, and the pool re-saturated into a fresh 418
// spiral (measured 10-19: 11:58Z→12:34Z→13:09Z pause spiral). The pacer:
//   · RECOVERY RAMP — for 10min after a global ban window ends, the effective
//     budget ramps 25%→100% linearly. Early recovery minutes carry the
//     CRITICAL lane first (engine price feed / triggers), telemetry scanners
//     stretch back out gradually instead of stampeding.
//   · POOL-DISTRESS CAP — while ≥2 named egress IPs sit inside live ban
//     windows (the 10-18 measurement: 3 named IPs banned simultaneously),
//     the effective budget is capped at 50% — fewer lottery draws, less ban
//     pressure, named-IP evidence stays intel-shaped.
// CRITICAL lane keeps its negative retry; the floor (200/min) is the same
// clamp configureFapiGate enforces, so the pacer can never zero the plane.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
;
const FAPI_HOST = process.env.NEXUS_FAPI_HOST?.trim().replace(/\/+$/, "") || "https://fapi.binance.com";
const DEFAULT_TIMEOUT_MS = 6500;
const WINDOW_MS = 60_000;
const DEFAULT_BUDGET = 1100; // real fapi limit 2400/min per IP — headroom by design
const BAN_CAP_MS = 35 * 60_000; // never record a ban window longer than 35min even if Binance claims hours
// v12.6.1 — mixed-pool era: an UNPARSEABLE 418 is evidence of ONE banned draw,
// not a pool-wide ban (measured 2026-10-20 19:32Z: boot's first draw 418'd
// unparseable while 6/10 fresh connections succeeded — the old 10min arm
// locked the whole app out of a majority-clean pool). 2min + the streak
// escalation ladder covers true saturation.
const BAN_418_DEFAULT_MS = 2 * 60_000; // unparseable 418 → short backoff (was 10min — pool-starvation lesson)
const BAN_429_DEFAULT_MS = 2 * 60_000; // unparseable 429 → short warning backoff
const CRITICAL_RETRY_MS = 250; // the "small negative retry" for the critical lane
const SF_RESULT_MS = 2_000; // single-flight result sharing window
const SF_MAP_CAP = 512;
const SPEND_CAP = 4096; // defensive cap on window entries (~worst-case small-weight bursts)
const BAN_RETRIES = 3; // extra attempts after a named-IP ban (pool rotation)
// v12.6.2 ESCALATING RETRY CADENCE: the NAT egress mapping rotates over ~30s
// (measured 2026-10-20 19:41Z: keep-alive 6×418 → 30s later 6×200), so three
// retries 120ms apart shared ONE doomed mapping. Spacing the retries across
// it (120ms → 2s → 8s) lets draws 2-4 land on a rotated mapping — higher
// per-call success, fewer 60s short blocks. Worst added latency ~10s on a
// banned stretch; the ladder still escalates to the 60s block on failure.
const BAN_RETRY_DELAYS_MS = [
    120,
    2_000,
    8_000
];
const POOL_BLOCK_SHORT_MS = 60_000; // all-retries-banned → short block, let the pool rotate
const POOL_STREAK_FOR_LONG_BLOCK = 3; // consecutive all-banned calls ⇒ pool saturated
const IP_BAN_MAP_CAP = 16;
// ── v12.0 egress manager constants ──
const EGRESS_SAMPLE_TTL_MS = 120_000; // ipify cache — one draw sample per 2min
const EGRESS_TIMEOUT_MS = 3_500;
const PROBE_COOLDOWN_MS = 120_000; // one early-probe attempt per 2min while a window is live
const BAN_PERSIST_DIR = `${process.cwd()}/.data/fapi-gate`;
const BAN_PERSIST_PATH = `${BAN_PERSIST_DIR}/bans.json`;
const BAN_PERSIST_DEBOUNCE_MS = 30_000;
// v14.2 ban-aware recovery pacer
const PACER_RECOVERY_MS = 10 * 60_000; // post-ban ramp window (25%→100%)
const PACER_RAMP_FLOOR = 0.25; // budget fraction at the first recovery minute
const PACER_DISTRESS_CAP = 0.5; // budget cap while ≥2 named IPs are banned live
const PACER_MIN_BUDGET = 200; // same clamp floor as configureFapiGate
// globalThis singleton — survives Turbopack dev module-graph duplication
const g = globalThis;
const state = g.__nexusFapiGate ?? (g.__nexusFapiGate = {
    budgetPer60s: DEFAULT_BUDGET,
    banUntil: 0,
    spend: [],
    windowSum: 0,
    inflight: new Map(),
    ipBans: new Map(),
    recentBanEvents: [],
    allBanStreak: 0,
    aimdFactor: 1,
    lastBanEventAt: 0,
    lastAimdRecoverAt: 0,
    sampledIp: null,
    sampledAt: 0,
    lastBannedIp: null,
    lastProbeAt: 0,
    stats: {
        attempted: 0,
        allowed: 0,
        droppedBudget: 0,
        droppedBan: 0,
        lastBanUntil: 0,
        singleFlightShared: 0,
        retriesAfterBan: 0,
        probesIssued: 0,
        probeLifts: 0,
        effectiveBudgetPer60s: DEFAULT_BUDGET
    }
});
function isUnknownScopeKey(key) {
    return !/^\d{1,3}(\.\d{1,3}){3}$/.test(key); // anything that is not an IPv4 literal ("_pool", hostnames…)
}
try {
    const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
    const nowMs = Date.now();
    let unknownMax = 0;
    let named = 0;
    for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
        if (typeof until !== "number" || until <= nowMs) continue;
        if (isUnknownScopeKey(key)) {
            if (until > unknownMax) unknownMax = until;
        } else {
            state.ipBans.set(key, until);
            named++;
        }
    }
    if (unknownMax > state.banUntil) {
        state.banUntil = unknownMax;
        console.log(`[fapi-gate] v12.6 restored UNKNOWN-SCOPE pool ban from disk — silence armed until ${new Date(unknownMax).toISOString()}`);
    }
    if (state.ipBans.size > 0) {
        // v12.6: named-IP records are INTEL only — no global arm at boot. The
        // first gateFetch takes the lottery draw; a banned draw retries around
        // the named IP (pool rotation) exactly like any other 418.
        console.log(`[fapi-gate] v12.6 restored ${named} named-IP ban record(s) as intel (no global arm — majority-clean pool policy)`);
    }
} catch  {}
let banPersistTimer = null;
function persistBans() {
    if (banPersistTimer) return;
    banPersistTimer = setTimeout(()=>{
        banPersistTimer = null;
        try {
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"])(BAN_PERSIST_DIR, {
                recursive: true
            });
            const nowMs = Date.now();
            const ipBans = {};
            // v12.1 TASK-49 — READ-MERGE-WRITE: mini-services write their own 418
            // discoveries (incl. "_pool" unknown-scope markers with REAL ends) to
            // this same file. Blindly overwriting with state-only data DELETED a
            // 15:20Z pool ban mid-storm (2026-10-19) — never shorten/lose foreign
            // entries: merge disk first, then overlay ours, keep live only.
            try {
                const disk = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
                for (const [ip, until] of Object.entries(disk?.ipBans ?? {})){
                    if (typeof until === "number" && until > nowMs) ipBans[ip] = until;
                }
            } catch  {
            /* no ledger yet */ }
            for (const [ip, until] of state.ipBans)if (until > nowMs) ipBans[ip] = Math.max(ipBans[ip] ?? 0, until);
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["writeFileSync"])(BAN_PERSIST_PATH, JSON.stringify({
                savedAt: new Date().toISOString(),
                ipBans
            }, null, 1));
        } catch  {}
    }, BAN_PERSIST_DEBOUNCE_MS);
}
// ── v12.0 egress IP sampler (which pool IP did this draw exit from?) ──
let egressInflight = null;
async function sampleEgressIp() {
    if (state.sampledIp && Date.now() - state.sampledAt < EGRESS_SAMPLE_TTL_MS) return state.sampledIp;
    if (egressInflight) return egressInflight;
    egressInflight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const t = setTimeout(()=>ctrl.abort(), EGRESS_TIMEOUT_MS);
            const res = await fetch("https://api.ipify.org?format=json", {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(t);
            if (!res.ok) return null;
            const j = await res.json();
            const ip = typeof j.ip === "string" && j.ip ? j.ip : null;
            if (ip) {
                state.sampledIp = ip;
                state.sampledAt = Date.now();
            }
            return ip;
        } catch  {
            return null; // sampler down — never blocks the gate (fail-open)
        } finally{
            egressInflight = null;
        }
    })();
    return egressInflight;
}
function fapiEgressStatus() {
    const now = Date.now();
    const bannedIps = [];
    for (const [ip, until] of state.ipBans)if (until > now) bannedIps.push({
        ip,
        until,
        remainingMs: until - now
    });
    bannedIps.sort((a, b)=>b.until - a.until);
    return {
        banUntil: state.banUntil,
        banRemainingMs: Math.max(0, state.banUntil - now),
        sampledIp: state.sampledIp,
        sampledAt: state.sampledAt || null,
        lastBannedIp: state.lastBannedIp,
        bannedIps,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        lastProbeAt: state.lastProbeAt
    };
}
function configureFapiGate(opts) {
    if (opts?.budgetPer60s !== undefined) {
        const b = Math.max(200, Math.min(2300, Math.round(opts.budgetPer60s)));
        state.budgetPer60s = b;
    }
}
function fapiBanRemainingMs() {
    return Math.max(0, state.banUntil - Date.now());
}
function fapiBanActivity() {
    const now = Date.now();
    const globalRemainingMs = Math.max(0, state.banUntil - now);
    const namedLiveIps = namedLiveBanCount(now);
    if (globalRemainingMs > 0) {
        return {
            active: true,
            reason: `fapi GLOBAL ban window live — ${Math.round(globalRemainingMs / 1000)}s left`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    if (namedLiveIps >= 2) {
        return {
            active: true,
            reason: `fapi pool distress — ${namedLiveIps} named egress IPs inside live ban windows`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    return {
        active: false,
        reason: null,
        globalRemainingMs,
        namedLiveIps,
        effectiveBudgetPer60s: effectiveBudgetPer60s()
    };
}
function fapiGateStats() {
    const now = Date.now();
    pruneWindow(now);
    let bannedIps = 0;
    for (const [, until] of state.ipBans)if (until > now) bannedIps++;
    return {
        attempted: state.stats.attempted,
        allowed: state.stats.allowed,
        droppedBudget: state.stats.droppedBudget,
        droppedBan: state.stats.droppedBan,
        lastBanUntil: state.stats.lastBanUntil,
        budgetPer60s: state.budgetPer60s,
        usedLast60s: state.windowSum,
        singleFlightShared: state.stats.singleFlightShared,
        banRemainingMs: fapiBanRemainingMs(),
        bannedPoolIps: bannedIps,
        retriesAfterBan: state.stats.retriesAfterBan,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        effectiveBudgetPer60s: effectiveBudgetPer60s(),
        aimdFactor: Number(state.aimdFactor.toFixed(3))
    };
}
// ── weight table (Binance USDT-M futures documented weights) ────────────────
// klines ~2 (limit≤100) · depth 2-5-10 by limit · aggTrades 20 · trades 20 ·
// ticker/24hr 1 per-symbol / 40 full-universe · premiumIndex 1 per-symbol /
// 10 all-markers · futures/data/* 1 (openInterestHist, L/S ratios, basis…) ·
// exchangeInfo 1 · ping/time 1 · unknown default 5 (conservative).
function resolveWeight(path) {
    const qIdx = path.indexOf("?");
    const ep = (qIdx === -1 ? path : path.slice(0, qIdx)).replace(/^\//, "").replace(/\/+$/, "");
    const query = qIdx === -1 ? "" : path.slice(qIdx + 1);
    const limit = ()=>{
        const m = /[?&]limit=(\d+)/.exec(query);
        return m ? Number(m[1]) : null;
    };
    switch(ep){
        case "fapi/v1/ping":
        case "fapi/v1/time":
        case "fapi/v1/exchangeInfo":
            return 1;
        case "fapi/v1/klines":
            {
                const l = limit() ?? 500;
                return l <= 100 ? 2 : l <= 499 ? 5 : 10;
            }
        case "fapi/v1/depth":
            {
                const l = limit() ?? 100;
                return l <= 100 ? 2 : l <= 500 ? 5 : 10;
            }
        case "fapi/v1/aggTrades":
        case "fapi/v1/trades":
            return 20;
        case "fapi/v1/ticker/24hr":
            return /[?&]symbol=/.test(query) ? 1 : 40;
        case "fapi/v1/premiumIndex":
            return /[?&]symbol=/.test(query) ? 1 : 10;
        default:
            if (ep.startsWith("futures/data/")) return 1; // openInterestHist / L-S ratios / basis family
            return 5; // unknown → conservative default (covers fapi/v1/fundingRate etc.)
    }
}
function pruneWindow(now) {
    const cutoff = now - WINDOW_MS;
    while(state.spend.length > 0 && state.spend[0].at <= cutoff){
        const e = state.spend.shift();
        state.windowSum -= e.w;
    }
    if (state.spend.length > SPEND_CAP) {
        // defensive: drop the oldest half rather than grow unbounded
        const keep = state.spend.slice(Math.floor(state.spend.length / 2));
        let sum = 0;
        for (const e of keep)sum += e.w;
        state.spend = keep;
        state.windowSum = sum;
    }
}
/** Reserve `weight` from the rolling window. Returns the spend entry (for refunds) or null. */ // ── v14.2 BAN-AWARE RECOVERY PACER ────────────────────────────────────────
// The ONLY budget the rolling window spends against. A flat budget after a
// ban ended = instant re-saturation stampede (the 10-19 spiral); the pacer
// gives the pool a 10min ramp and caps telemetry while the pool shows live
// distress. Global-window minutes are NOT handled here (gateFetch drops
// everything while the window is live) — the pacer shapes the BEFORE
// (distress) and AFTER (recovery) of each ban episode.
function namedLiveBanCount(now) {
    let n = 0;
    for (const [, until] of state.ipBans)if (until > now) n++;
    return n;
}
// ── v14.3 ROLLING-CYCLE AIMD PACER (chapter-7 item ② «backoff واقعی», operator
// mandate trace 1a1a8ea4186c6571) — the missing third leg of the v14.2 pacer.
// Measured failure mode (engineering report NX3247+LIVE): the 3-IP egress pool
// rides a ROLLING ~20min ban cycle — bans expire, the full budget floods back
// instantly (named-IP bans never armed the global window ⇒ no ramp), the pool
// re-saturates in the same minute and re-bans. Fix: an AIMD shed factor that
// DECREASES multiplicatively on every named-IP ban event (×0.7, floor 0.25) and
// recovers ADDITIVELY during clean minutes (+0.05/min, cap 1.0). Sustained ban
// churn ⇒ progressively quieter pool without any operator tuning; a genuinely
// healthy pool heals back to full budget in ~15 clean minutes.
const AIMD_DROP = 0.7;
const AIMD_FLOOR = 0.25;
const AIMD_RECOVER_PER_MIN = 0.05;
function recoverAimd(now) {
    if (state.aimdFactor >= 1) {
        state.lastAimdRecoverAt = now;
        return;
    }
    if (state.lastBanEventAt === 0) return;
    const anchor = Math.max(state.lastAimdRecoverAt, state.lastBanEventAt);
    const cleanMin = Math.floor((now - anchor) / 60_000);
    if (cleanMin <= 0) return;
    state.aimdFactor = Math.min(1, state.aimdFactor + cleanMin * AIMD_RECOVER_PER_MIN);
    state.lastAimdRecoverAt = now;
}
function noteAimdBanEvent(now) {
    recoverAimd(now);
    state.aimdFactor = Math.max(AIMD_FLOOR, state.aimdFactor * AIMD_DROP);
    state.lastBanEventAt = now;
    state.lastAimdRecoverAt = now;
}
function effectiveBudgetPer60s() {
    const now = Date.now();
    let factor = 1;
    recoverAimd(now); // v14.3 — additive clean-minute recovery before clamping
    factor = Math.min(factor, state.aimdFactor);
    // POOL DISTRESS — ≥2 named egress IPs inside live ban windows: cap telemetry.
    if (namedLiveBanCount(now) >= 2) factor = Math.min(factor, PACER_DISTRESS_CAP);
    // RECOVERY RAMP — 10min linear 25%→100% after the last global window ends.
    if (state.banUntil > 0) {
        const sinceBan = now - state.banUntil;
        if (sinceBan >= 0 && sinceBan < PACER_RECOVERY_MS) {
            factor = Math.min(factor, PACER_RAMP_FLOOR + (1 - PACER_RAMP_FLOOR) * (sinceBan / PACER_RECOVERY_MS));
        }
    }
    return Math.max(PACER_MIN_BUDGET, Math.round(state.budgetPer60s * factor));
}
function takeWeight(weight) {
    const now = Date.now();
    pruneWindow(now);
    if (state.windowSum + weight > effectiveBudgetPer60s()) return null;
    const entry = {
        at: now,
        w: weight
    };
    state.spend.push(entry);
    state.windowSum += weight;
    return entry;
}
/** 418/429 responses carry no weight cost — give the reservation back. */ function refundWeight(entry) {
    if (!entry) return;
    const idx = state.spend.indexOf(entry);
    if (idx === -1) return; // already pruned out of the window (its cost is gone too)
    state.spend.splice(idx, 1);
    state.windowSum -= entry.w;
}
function armGlobalBan(until) {
    if (until > state.banUntil) {
        state.banUntil = until;
        state.stats.lastBanUntil = until;
    }
}
/** Record a 418/429 body. Returns { ip, until } when the body NAMES the banned egress IP. */ function noteBanBody(status, body) {
    const now = Date.now();
    const named = /IP\(([\d.]+)\)\s*banned until (\d+)/i.exec(body);
    if (named) {
        const ip = named[1];
        // v12.1 TASK-49: the LEDGER carries Binance's REAL end (sanity-capped 24h) —
        // the cosmetic +35min cap only applies to the global silence window below.
        // Capping the ledger made the early probe fire at a fake expiry and the
        // resulting 418 contact re-escalated the real ban (11:58→12:34→13:09 spiral).
        const realUntil = Math.min(Number(named[2]), now + 24 * 60_000);
        const until = Math.min(realUntil, now + BAN_CAP_MS);
        state.ipBans.set(ip, realUntil);
        state.lastBannedIp = ip;
        persistBans(); // v12.0 — named-IP ban ledger survives restarts (30s debounce)
        if (state.ipBans.size > IP_BAN_MAP_CAP) {
            // evict the soonest-expiring record
            let oldestKey = null;
            let oldestVal = Infinity;
            for (const [k, v] of state.ipBans)if (v < oldestVal) {
                oldestVal = v;
                oldestKey = k;
            }
            if (oldestKey) state.ipBans.delete(oldestKey);
        }
        state.recentBanEvents.push({
            at: now,
            ip
        });
        if (state.recentBanEvents.length > 64) state.recentBanEvents.splice(0, state.recentBanEvents.length - 64);
        noteAimdBanEvent(now); // v14.3 — every named-IP ban deepens the rolling-cycle shed
        return {
            ip,
            until
        };
    }
    const untilMatch = /banned until (\d+)/i.exec(body);
    if (untilMatch) {
        armGlobalBan(Math.min(Number(untilMatch[1]), now + BAN_CAP_MS)); // unknown scope — assume it's us
        return null;
    }
    // unparseable body — conservative defaults (taxonomy precedent for 418)
    armGlobalBan(now + (status === 429 ? BAN_429_DEFAULT_MS : BAN_418_DEFAULT_MS));
    return null;
}
/** Every retry landed on a (named) banned IP — escalate the global silence window. */ function escalatePoolBlock(worstNamedUntil) {
    const now = Date.now();
    state.allBanStreak++;
    if (state.allBanStreak >= POOL_STREAK_FOR_LONG_BLOCK) {
        // repeated independent evidence — the egress pool is saturated: full
        // zero-network window, capped at 35min, then a fresh probe self-heals.
        armGlobalBan(Math.min(worstNamedUntil, now + BAN_CAP_MS));
        state.allBanStreak = 0;
    } else {
        armGlobalBan(now + POOL_BLOCK_SHORT_MS);
    }
}
function pruneInflight(now) {
    for (const [k, e] of state.inflight){
        if (e.settled && now - e.startedAt >= SF_RESULT_MS) state.inflight.delete(k);
    }
}
function delay(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}
/**
 * THE gate body. Resolves parsed JSON, or null on: live IP ban, weight-budget
 * shed, HTTP failure, timeout, or parse error. Never throws, never queues.
 */ async function executeGated(path, opts) {
    const lane = opts?.priority ?? "telemetry";
    const weight = Math.max(1, Math.round(opts?.weight ?? resolveWeight(path)));
    const timeoutMs = opts?.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    let entry = takeWeight(weight);
    if (!entry) {
        if (lane !== "critical") {
            state.stats.droppedBudget++;
            return null; // telemetry: drop instead of queueing a storm
        }
        await delay(CRITICAL_RETRY_MS); // one small negative retry
        entry = takeWeight(weight);
        if (!entry) {
            state.stats.droppedBudget++;
            return null;
        }
    }
    const host = opts?.host ?? FAPI_HOST;
    let attempt = 0;
    while(true){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        let res;
        try {
            // v12.6.1 CONNECTION-RECYCLE (measured 2026-10-20 19:41Z, bun runtime):
            // a keep-alive fetch POOLS one TCP flow ⇒ ONE egress IP for its whole
            // life — a pinned-banned connection turned 231 gate calls into 0 allowed
            // while 6/10 fresh connections succeeded. `Connection: close` = a fresh
            // NAT lottery draw per request; the TLS cost (~60ms) is trivial next to
            // the starvation it prevents.
            res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store",
                headers: {
                    Connection: "close"
                }
            });
        } catch  {
            return null; // timeout/abort/network — weight may have been consumed, keep the reservation
        } finally{
            clearTimeout(timer);
        }
        if (res.ok) {
            const text = await res.text().catch(()=>"");
            if (!text) return null; // empty 200 — nothing to invent
            state.stats.allowed++;
            state.allBanStreak = 0; // a clean 2xx proves the pool still serves us
            try {
                return JSON.parse(text);
            } catch  {
                return null;
            }
        }
        if (res.status === 418 || res.status === 429) {
            const body = await res.text().catch(()=>"");
            refundWeight(entry); // banned responses carry no weight cost
            entry = null;
            const named = noteBanBody(res.status, body);
            if (opts?.singleProbe) return null; // v12.0 early probe — single attempt, window stays armed
            if (!named) return null; // unknown-scope ban — global zero-network window already armed
            if (attempt >= BAN_RETRIES) {
                escalatePoolBlock(named.until);
                return null;
            }
            attempt++;
            state.stats.retriesAfterBan++;
            await delay(BAN_RETRY_DELAYS_MS[Math.min(attempt - 1, BAN_RETRY_DELAYS_MS.length - 1)]); // span the NAT rotation window
            entry = takeWeight(weight);
            if (!entry) {
                state.stats.droppedBudget++;
                return null;
            }
            continue;
        }
        return null; // other non-ok status — honest null, no retry
    }
}
/** v12.1 TASK-49 — a recorded ban counts ONLY while its real end is in the future. */ function isIpBanned(ip, now) {
    if (!ip) return false;
    return (state.ipBans.get(ip) ?? 0) > now;
}
// v12.1 TASK-49 — SHARED LEDGER REFRESH: trade-service / price-ws write their
// own 418 discoveries (with REAL ends) to the same bans.json. Merge live disk
// entries into state every 30s (extend-only). v12.6 scope split: UNKNOWN-SCOPE
// entries extend the global silence (pool-suspect evidence); NAMED-IP entries
// merge into ipBans as intel only — a majority-clean pool must not be
// blacked out because one pool member drew a ban.
let lastLedgerCheckAt = 0;
function refreshLedgerOnce() {
    const nowMs = Date.now();
    lastLedgerCheckAt = nowMs;
    try {
        const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
        let unknownMax = 0;
        for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
            if (typeof until !== "number" || until <= nowMs) continue;
            if (isUnknownScopeKey(key)) {
                if (until > unknownMax) unknownMax = until;
                continue;
            }
            if (until > (state.ipBans.get(key) ?? 0)) state.ipBans.set(key, until);
        }
        // unknown-scope knowledge extends the global silence window (extend-only)
        if (unknownMax > state.banUntil) {
            state.banUntil = unknownMax;
            console.log(`[fapi-gate] v12.6 ledger refresh — UNKNOWN-SCOPE pool ban extends silence until ${new Date(unknownMax).toISOString()}`);
        }
    } catch  {
    /* ledger gone/unreadable — keep in-memory state */ }
}
try {
    const refresh = setInterval(refreshLedgerOnce, 30_000);
    if (typeof refresh.unref === "function") refresh.unref();
} catch  {
/* non-blocking env — skip refresh */ }
async function gateFetch(path, opts) {
    state.stats.attempted++;
    const now = Date.now();
    // v12.1 TASK-49 — LAZY LEDGER GUARD: the instant our global window expires,
    // re-check the shared ledger (throttled to one disk read / 15s) BEFORE any
    // network call — closes the poke-gap where the window died but the refresh
    // interval hadn't fired yet. While the pool is ledger-banned, zero pokes.
    if (now >= state.banUntil && now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
    if (now < state.banUntil) state.stats.droppedBan++; // ledger re-armed the window — shed instantly
    // GLOBAL BAN AWARENESS — while a global ban window is live, zero network calls
    // …except the v12.0 ROTATION-AWARE EARLY PROBE: one critical-lane attempt per
    // PROBE_COOLDOWN_MS when the sampled egress IP is clean — the pool rotates,
    // so the window can be LIFTED the moment a clean draw appears instead of
    // waiting out the full 35min cap. A failed probe keeps the window armed.
    if (now < state.banUntil) {
        state.stats.droppedBan++;
        const canProbe = (opts?.priority ?? "telemetry") === "critical" && now - state.lastProbeAt >= PROBE_COOLDOWN_MS;
        if (!canProbe) return null;
        // v12.1 TASK-49 — LEDGER FRESHNESS BEFORE PROBE: state may hold a cosmetic
        // cap while the disk carries a longer REAL end another process discovered.
        // A probe fired on stale state pokes a still-banned pool and re-escalates.
        // Re-read the ledger (15s throttle) and re-arm BEFORE the probe decision.
        if (now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
        if (now < state.banUntil) return null; // ledger extended the silence — no probe
        state.lastProbeAt = now;
        const ip = await sampleEgressIp();
        // v12.1 TASK-49: expiry-aware check — a recorded ban whose real end passed
        // no longer blocks the probe (the old .has() kept ghost entries armed).
        if (!ip || isIpBanned(ip, now)) return null; // sampled draw is banned/unknown — stay silent
        state.stats.probesIssued++;
        const probeResult = await executeGated(path, {
            ...opts,
            singleProbe: true
        });
        if (probeResult !== null) {
            state.banUntil = 0; // clean draw proved the pool rotated — lift instantly
            state.allBanStreak = 0;
            state.stats.probeLifts++;
            console.log(`[fapi-gate] v12.0 ban window LIFTED early — egress rotated to clean IP ${ip}`);
        }
        return probeResult;
    }
    // SINGLE-FLIGHT per (host,path): share the request while it is in flight and
    // for a 2s result window — concurrent module askers pay the weight once.
    const key = `${opts?.host ?? FAPI_HOST}${path}`;
    const existing = state.inflight.get(key);
    if (existing) {
        const age = now - existing.startedAt;
        if (!existing.settled || age < SF_RESULT_MS) {
            state.stats.singleFlightShared++;
            return existing.promise;
        }
        state.inflight.delete(key);
    }
    if (state.inflight.size >= SF_MAP_CAP) pruneInflight(now);
    const promise = executeGated(path, opts);
    const entry = {
        startedAt: now,
        settled: false,
        promise
    };
    state.inflight.set(key, entry);
    void promise.catch(()=>null) // executeGated never rejects — belt & suspenders
    .finally(()=>{
        entry.settled = true;
    });
    return promise;
}
}),
"[project]/src/lib/price-armor.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── NEXUS//SIGNALS PRICE-ARMOR (v12.0 · Task 44-① — write-side phantom anchor) ──
// Operator order 2026-10-18: «ترمیم writer فید (خنثی‌سازی anchor فانتوم سمت
// نوشتن، نه فقط deploy)»
//
// FORENSIC ROOT (Task 45/44, hard evidence): Binance serves ZOMBIE spot
// listings — XMRUSDT spot answers lastPrice=118.70 with bidPrice=0 AND
// askPrice=0 (empty order book, frozen delisting-era print) while the real
// perp trades ~592. The v10.16 spot-overlay fallback (fetchTickers) trusted
// that print as source:"live" whenever fapi was IP-banned → the engine WROTE
// 118.7 into MarketAsset and PricePoint → NX-2736/2744 phantom stops (Task 43).
// The v11.9 PHANTOM-FEED gate catches this at DEPLOY time; this module kills
// the class at WRITE time — the tape itself must never carry phantom prints.
//
// Three writer-side weapons:
//   1. ZOMBIE-TICKER REJECTION — a ticker with a two-sided-empty book
//      (bid=0 && ask=0) is not a market; never a terminal price.
//   2. CROSS-PLANE DIVERGENCE GUARD — a spot-overlay quote deviating >10%
//      from the last live-verified perp anchor (or from the venue consensus)
//      is refused as a terminal source (perp↔spot basis is normally <1%;
//      real crashes are fapi/consensus-sourced and unaffected).
//   3. ANCHOR-LOCKED SIM DRIFT — the sim fallback drifts around the last
//      LIVE-verified price (not around MarketAsset.price, which a platform
//      restore can rewind to an era value — the 118.7 anchor class), with a
//      hard ±0.25% excursion cap, and sim ticks NEVER reach PricePoint /
//      tick-archive (a gap in the tape is honest; a phantom print is poison).
//
// Pure + client-safe. Consumers: market-feed (zombie filter), engine writer
// (resolveTerminalPrice), verify scripts (offline decision tests).
/** A ticker that has no two-sided market is a zombie/halted listing. */ __turbopack_context__.s([
    "REWIND_DETECT_PCT",
    ()=>REWIND_DETECT_PCT,
    "SIM_DRIFT_CAP_PCT",
    ()=>SIM_DRIFT_CAP_PCT,
    "SPOT_PERP_DIVERGENCE_PCT",
    ()=>SPOT_PERP_DIVERGENCE_PCT,
    "isTradeableTicker",
    ()=>isTradeableTicker,
    "resolveTerminalPrice",
    ()=>resolveTerminalPrice
]);
function isTradeableTicker(t) {
    const bid = Number(t.bidPrice ?? 0);
    const ask = Number(t.askPrice ?? 0);
    if (!Number.isFinite(bid) || !Number.isFinite(ask)) return true; // fields absent (some planes) → cannot disprove
    return !(bid === 0 && ask === 0);
}
const SPOT_PERP_DIVERGENCE_PCT = 10;
const REWIND_DETECT_PCT = 5;
const SIM_DRIFT_CAP_PCT = 0.25;
const rnd = ()=>Math.random();
function resolveTerminalPrice(inp, jitter = rnd) {
    const { tPrice, tZombie, tSpotOverlay, consMedian, consVenues, anchor, storedPrice } = inp;
    const out = {
        next: 0,
        liveNow: false,
        priceClass: "frozen",
        zombieRejected: false,
        rewound: false
    };
    // ① consensus (≥2 venues, robust median) — always trusted, wins over ticker
    if (consVenues >= 2 && consMedian && consMedian > 0) {
        return {
            ...out,
            next: consMedian,
            liveNow: true,
            priceClass: "live-consensus"
        };
    }
    // ② ticker — but only a tradeable one; the cross-plane divergence guard is
    // SPOT-OVERLAY-ONLY (fapi perp prints are the market itself — a real crash
    // must pass; an overlay quote deviating >10% from the perp truth is zombie-adjacent)
    if (tPrice && tPrice > 0 && !tZombie) {
        let reject = false;
        if (tSpotOverlay) {
            if (consMedian && consMedian > 0 && Math.abs(tPrice - consMedian) / consMedian * 100 > SPOT_PERP_DIVERGENCE_PCT) reject = true;
            if (!reject && anchor && anchor > 0 && Math.abs(tPrice - anchor) / anchor * 100 > SPOT_PERP_DIVERGENCE_PCT) reject = true;
        }
        if (!reject) return {
            ...out,
            next: tPrice,
            liveNow: true,
            priceClass: "live-ticker"
        };
        out.zombieRejected = true;
    } else if (tPrice && tPrice > 0 && tZombie) {
        out.zombieRejected = true;
    }
    // ③ sim drift — ANCHOR-LOCKED: drift around the last live-verified price.
    const base = anchor && anchor > 0 ? anchor : storedPrice;
    if (base > 0) {
        if (anchor && anchor > 0 && storedPrice > 0 && Math.abs(storedPrice - anchor) / anchor * 100 > REWIND_DETECT_PCT) out.rewound = true;
        const walk = base * (1 + (jitter() - 0.5) * 0.001);
        // excursion cap keeps a long outage from walking the sim price away
        const capped = Math.max(base * (1 - SIM_DRIFT_CAP_PCT / 100), Math.min(base * (1 + SIM_DRIFT_CAP_PCT / 100), walk));
        out.next = capped;
        out.liveNow = false;
        out.priceClass = "sim-drift";
        return out;
    }
    // ④ nothing sane — freeze (caller keeps the previous stored price untouched)
    out.next = 0;
    out.priceClass = "frozen";
    return out;
}
}),
"[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noteSpotHostThrottle",
    ()=>noteSpotHostThrottle,
    "spotHostReady",
    ()=>spotHostReady,
    "spotHostsReady",
    ()=>spotHostsReady,
    "spotLadderJson",
    ()=>spotLadderJson
]);
// ── NEXUS//SIGNALS spot-host gate (v13.2.1 SPOT-BAN-BACKOFF) ────────────────
// Completes the v13.2 SPOT-HOST LADDER: the ladder could DETECT a 418/429
// (fall through to the next rung) but had NO per-host backoff, so every tick
// re-poked the banned host first — wasting weight and keeping ban pressure
// alive. Live evidence 2026-10-25T00:48Z: data-api.binance.vision flapped
// 429/418 at x-mbx-used-weight-1m: 467 with retry-after: 889s while fapi
// served 200 @73ms (separate ban pools per host confirmed).
//
// Contract (read-only, zero data invention):
//   · 418 → host silent for retry-after seconds (capped 15min)
//   · 429 → soft 60s pause (retry-after respected when present)
//   · ladders ask spotHostsReady() and skip mid-ban hosts → traffic
//     auto-redistributes to the healthy rung and slides back on expiry.
//   · globalThis dedupe — Turbopack can instantiate per-route bundles; the
//     engine tick loop and /api routes MUST share one ban map (fbStats pattern).
const CAP_MS = 15 * 60_000;
const g = globalThis;
g.__nexusSpotHostGate ??= {
    bannedUntil: {}
};
const S = g.__nexusSpotHostGate;
function spotHostReady(host, now = Date.now()) {
    return (S.bannedUntil[host] ?? 0) <= now;
}
function spotHostsReady(hosts, now = Date.now()) {
    return hosts.filter((h)=>spotHostReady(h, now));
}
function noteSpotHostThrottle(host, status, headers) {
    const now = Date.now();
    let ms = status === 418 ? CAP_MS : 60_000;
    const ra = Number(headers.get("retry-after"));
    if (Number.isFinite(ra) && ra > 0) ms = Math.min(ra * 1000, CAP_MS);
    const prev = S.bannedUntil[host] ?? 0;
    if (prev < now + 1000) {
        console.warn(`[spot-host-gate] ${host} → ${status} — leg silent ${Math.round(ms / 1000)}s (weight1m=${headers.get("x-mbx-used-weight-1m") ?? "?"})`);
    }
    S.bannedUntil[host] = Math.max(prev, now + ms);
}
async function spotLadderJson(path, hosts, timeoutMs = 8000) {
    for (const host of spotHostsReady(hosts)){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        try {
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                noteSpotHostThrottle(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) continue;
            return await res.json();
        } catch  {
            continue;
        } finally{
            clearTimeout(timer);
        }
    }
    return null;
}
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[project]/src/lib/market-feed.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FUTURES_FAPI",
    ()=>FUTURES_FAPI,
    "fetchFuturesKlines",
    ()=>fetchFuturesKlines,
    "fetchFuturesPoolStats",
    ()=>fetchFuturesPoolStats,
    "fetchFuturesSymbols",
    ()=>fetchFuturesSymbols,
    "fetchFuturesUniverse",
    ()=>fetchFuturesUniverse,
    "fetchKlines",
    ()=>fetchKlines,
    "fetchTickers",
    ()=>fetchTickers,
    "futwsQuoteMap",
    ()=>futwsQuoteMap,
    "getFeedStatus",
    ()=>getFeedStatus,
    "getFutwsStatus",
    ()=>getFutwsStatus,
    "markFeedOk",
    ()=>markFeedOk
]);
// ── FlowRadar Neo live market feed (server-only) ──
// Binance REST client: USDT-M FUTURES tickers (primary) + spot overlay for
// spot-only listings + futures universe + klines.
// v10.16 P1 FUTURES PRICE UNIFICATION: perp signals must settle on perp
// prices — /fapi/v1 is now the PRIMARY ticker source; SPOT is only overlaid
// for universe symbols the futures response does not carry, and those rows
// stay source:"live". If BOTH fail the caller's sim fallback is unchanged.
// Resilience ladder: LIVE → STALE (≤5min grace) → SIMULATED drift.
// v10.24 Task 34-a FAPI GATE: every futures (fapi) REST call now goes through
// the process-wide weight gate (src/lib/fapi-gate.ts) — budget, global IP-ban
// awareness and single-flight. SPOT calls (api.binance.com) stay direct —
// they have their own separate IP budget.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)"); // v13.4 spot-print liveness probe
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$price$2d$armor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/price-armor.ts [app-route] (ecmascript)"); // v12.0 Task 44-① zombie-ticker rejection at the feed layer
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [app-route] (ecmascript)");
;
;
;
// v13.3 BINANCE-LADDER (trace 1a184429d4bd0d05, restored 1a1849f647778885) —
// full official spot-REST set per binance-spot-api-docs: vision (dedicated
// market-data pool) → api-gcp (official GCP mirror, 200 6/6 @59ms 2026-10-28)
// → api1-4 mirrors → api last. Per-host 418/429 backoff via spot-host-gate.
const BINANCE_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
const FAPI = "https://fapi.binance.com";
// dual-host failover for the futures REST plane — fapi is the ONLY official
// USDT-M futures REST host: fapi1.binance.com probed 2026-10-25 = HTTP 302
// redirect (not an API host) → removed as a dead rung.
const FAPI_HOSTS = [
    "https://fapi.binance.com"
];
const TIMEOUT_MS = 6500;
;
const feedStatus = {
    source: "LIVE",
    lastOkAt: null,
    latencyMs: null,
    consecutiveFailures: 0,
    host: null,
    fallbackVenue: null
};
// v12.5 — throttled telemetry for the fallback rungs (one line / 10min max)
let lastFallbackEventAt = 0;
// ── v13.4 SPOT-PRINT-LIVENESS (trace 1a1849f647778885 — operator mandate:
// «سیستم کاملا از دیتای زنده و لحظه‌ای بایننس استفاده کند») ──────────────────
// price-ws (:3003) owns the hours-proven Binance spot !miniTicker@arr WS and
// pushes ~400 genuine live Binance spot prints into .data/spotws-quotes.json
// EVERY 3s — and since v13.4 it writes the file DIRECTLY (survives app
// restarts). getFeedStatus() recognizes that plane: fresh prints (≤90s,
// exchange timestamps) = LIVE with host labeled spot-ws-ring. 3s memo keeps
// the hot pulse path cheap; REST truth stays in charge when prints age out.
const SPOTWS_FILE = ".data/spotws-quotes.json";
const SPOTWS_FRESH_MS = 90_000;
let spotwsProbe = {
    at: 0,
    fresh: false,
    printAt: null,
    rows: 0
};
// ── v13.5 FUTWS-LIVENESS (trace 1a184d8bbb826f0d) — .data/futws-quotes.json
// is written DIRECTLY by price-ws :3003 every 3s from the futures bookTicker
// ring (43 liquid perps after the v13.5.1 ring repair — 5 entries were
// spot-named/dead and printed zero frames, best bid/ask → mid). Fresh file (≤90s payload) = the
// Binance FUTURES plane is exchange-pushed live: source stays LIVE through
// app restarts, REST pool bans and boot windows, and fetchTickers overlays
// those mids as perp-native quotes (see fetchTickers rung 2). 3s memo keeps
// the hot pulse path cheap.
const FUTWS_FILE = ".data/futws-quotes.json";
const FUTWS_FRESH_MS = 90_000;
let futwsProbe = {
    at: 0,
    fresh: false,
    printAt: null,
    rows: []
};
function futwsLiveness() {
    const now = Date.now();
    if (now - futwsProbe.at < 3_000) return futwsProbe;
    futwsProbe = {
        at: now,
        fresh: false,
        printAt: null,
        rows: []
    };
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(FUTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const rows = Array.isArray(j.rows) ? j.rows : [];
        const payloadAt = Number(j.at) || 0;
        if (payloadAt > 0 && now - payloadAt < FUTWS_FRESH_MS + 10_000 && rows.length > 0) {
            futwsProbe = {
                at: now,
                fresh: true,
                printAt: payloadAt,
                rows
            };
        }
    } catch  {
    /* file missing/unreadable → not fresh; REST truth stays in charge */ }
    return futwsProbe;
}
function getFutwsStatus() {
    const p = futwsLiveness();
    return {
        fresh: p.fresh,
        rows: p.rows.length,
        ageMs: p.printAt ? Date.now() - p.printAt : null
    };
}
function futwsQuoteMap() {
    const out = new Map();
    const p = futwsLiveness();
    if (!p.fresh) return out;
    const now = Date.now();
    for (const r of p.rows){
        if (!r || !r.s || !(r.m > 0)) continue;
        if (now - (r.t ?? 0) > 30_000) continue;
        out.set(r.s, {
            bid: r.b,
            ask: r.a,
            mid: r.m,
            t: r.t
        });
    }
    return out;
}
function spotPrintLiveness() {
    const now = Date.now();
    if (now - spotwsProbe.at < 3_000) return spotwsProbe;
    spotwsProbe = {
        at: now,
        fresh: false,
        printAt: null,
        rows: 0
    };
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(SPOTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const rows = Array.isArray(j.rows) ? j.rows : [];
        const payloadAt = Number(j.at) || 0;
        if (payloadAt > 0 && now - payloadAt < SPOTWS_FRESH_MS + 10_000 && rows.length > 0) {
            spotwsProbe = {
                at: now,
                fresh: true,
                printAt: payloadAt,
                rows: rows.length
            };
        }
    } catch  {
    /* file missing/unreadable → not fresh; REST truth stays in charge */ }
    return spotwsProbe;
}
// v14.3 TICKER-WEIGHT-DETENTE (operator trace 1a1c1ecd9694a129, 2026-11-09) —
// the spot REST overlay used to pull the FULL /api/v3/ticker/24hr board
// (weight 200) on EVERY engine tick (3.5s) while fapi was banned, because the
// futws ring (43 mids) never covers the whole 64-symbol universe. Measured
// fallout: ~11,400+ spot weight/min → family-wide 418 ("IP banned until …",
// host weight1m counters 13,5K–16,1K observed) — which is what kept the
// BINANCE-SPOT / BINANCE-GCP consensus planes dead and the EXCHANGE CONSENSUS
// card unstable even while the WS planes were healthy. New ladder inside
// fetchTickers: rung 2.5 = THIS map (real Binance spot prints pushed by
// price-ws :3003 every 3s — ~439 symbols, ZERO REST weight); rung 3 = REST
// pull ONLY for symbols still missing AND proven spot-listed (membership
// oracle = this file), via the ?symbols= filter (weight 4). Futures-only
// microcaps were NEVER in the spot response (the old full-board pull filtered
// them out locally) — they stay honestly missing, no invented data. If the
// print file is unreadable (price-ws down), rung 3 falls back to the legacy
// full-board pull (old behavior, old weight) so the overlay never goes dark.
function spotwsPrintMap() {
    const out = new Map();
    const now = Date.now();
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(SPOTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const payloadAt = Number(j.at) || 0;
        if (!(payloadAt > 0) || now - payloadAt > SPOTWS_FRESH_MS + 10_000) return out; // stale file — rung skips honestly
        for (const r of Array.isArray(j.rows) ? j.rows : []){
            const sym = String(r?.s ?? "").toUpperCase();
            const p = Number(r?.p);
            const t = Number(r?.t);
            if (!sym.endsWith("USDT") || !(p > 0) || !(t > 0) || now - t > SPOTWS_FRESH_MS) continue;
            out.set(sym, p);
        }
    } catch  {
    /* file missing/unreadable → empty map; legacy rung covers */ }
    return out;
}
function getFeedStatus() {
    // v13.5 — futures bookTicker ring FIRST: a live Binance FUTURES plane beats
    // the spot mirror in the host label (operator mandate «دیتای زندهٔ بایننس
    // فیوچرز»); both files come from the same price-ws :3003 process.
    const futws = futwsLiveness();
    if (futws.fresh) {
        const FUT_HOST = "fut-ws-book + spot-ws-ring (price-ws :3003)";
        if (feedStatus.host !== FUT_HOST) {
            feedStatus.host = FUT_HOST;
            feedStatus.fallbackVenue = null; // native Binance futures plane — no fallback
        }
        // v14.3 STALE-DATA-DEPLOY-FIX (trace 1a1c1ecd9694a129): the reset used to fire
        // only on HOST CHANGE — meanwhile every banned REST rung tick incremented
        // consecutiveFailures, so after a few minutes failures≥3 flagged the feed
        // "stale" in the deploy gate (engine.ts feedStalePre) while the exchange was
        // pushing live prints every 3s. Raw evidence: failures=78 with lastOkAt 2s
        // fresh, RAW-CAL refused with STALE_DATA for 6h (last serial NX-3495).
        // WS-fresh ⇒ LIVE, full stop: REST-failure streaks are superseded data-path
        // noise, not staleness. The counter still tells the truth whenever NO WS
        // plane is fresh (the stale path below keeps accumulating it).
        feedStatus.consecutiveFailures = 0;
        feedStatus.source = "LIVE";
        if (!feedStatus.lastOkAt || Date.now() - feedStatus.lastOkAt > 20_000) feedStatus.lastOkAt = futws.printAt ?? Date.now();
        return {
            ...feedStatus
        };
    }
    const spotws = spotPrintLiveness();
    if (spotws.fresh) {
        // live Binance spot prints ≤90s old — the feed IS live regardless of the
        // REST poller's in-memory state (app restarts, pool bans, boot windows).
        // The host label PREFERS the Binance ring whenever it is fresh — the
        // operator's mandate is «دیتای زندهٔ بایننس»; a fallback REST rung must
        // not mask the Binance plane printing every 3s.
        if (feedStatus.host !== "spot-ws-ring (price-ws :3003)") {
            feedStatus.host = "spot-ws-ring (price-ws :3003)";
            feedStatus.fallbackVenue = "SPOT-MIRROR";
        }
        feedStatus.consecutiveFailures = 0; // v14.3 — same WS-fresh ⇒ LIVE rule as the futws branch above
        feedStatus.source = "LIVE";
        if (!feedStatus.lastOkAt || Date.now() - feedStatus.lastOkAt > 20_000) feedStatus.lastOkAt = spotws.printAt ?? Date.now();
        return {
            ...feedStatus
        };
    }
    if (feedStatus.lastOkAt && feedStatus.source !== "SIMULATED") {
        const age = Date.now() - feedStatus.lastOkAt;
        if (age > 5 * 60_000) return {
            ...feedStatus,
            source: "SIMULATED"
        };
        if (age > 20_000 && feedStatus.source === "LIVE") return {
            ...feedStatus,
            source: "STALE"
        };
    }
    return {
        ...feedStatus
    };
}
function markFeedOk(host) {
    feedStatus.lastOkAt = Date.now();
    feedStatus.latencyMs = null; // non-fapi rung — latency not comparable
    feedStatus.host = host;
    feedStatus.consecutiveFailures = 0;
    // DATA-REVIVAL — honest sourcing: name the Binance plane that actually fed the feed
    feedStatus.fallbackVenue = host.includes("futws") ? "FUTWS-RING" : host.includes("binance.vision") ? "SPOT-MIRROR" : feedStatus.fallbackVenue;
    if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
}
async function fetchJson(path, hosts = BINANCE_HOSTS) {
    let lastErr;
    const ready = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["spotHostsReady"])(hosts); // v13.2.1 — mid-ban hosts are skipped, traffic slides to the healthy rung
    if (ready.length === 0) throw new Error(`spot-host-gate: all hosts mid-ban for ${path}`);
    for (const host of ready){
        const t0 = Date.now();
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["noteSpotHostThrottle"])(host, res.status, res.headers);
                throw new Error(`${host}${path} → ${res.status} (gate armed)`);
            }
            if (!res.ok) throw new Error(`${host}${path} → ${res.status}`);
            const json = await res.json();
            feedStatus.lastOkAt = Date.now();
            feedStatus.latencyMs = Date.now() - t0;
            feedStatus.consecutiveFailures = 0;
            feedStatus.host = host.replace("https://", "");
            feedStatus.fallbackVenue = null; // Binance plane healthy — no fallback active
            if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
            return json;
        } catch (err) {
            lastErr = err;
            feedStatus.consecutiveFailures++;
        }
    }
    throw lastErr;
}
async function fetchTickers(symbols) {
    const out = new Map();
    const want = new Set(symbols);
    // v12.0 price-armor — zombie filter on BOTH planes: a halted/delisted
    // listing (empty book) must never masquerade as a live terminal price.
    const zombie = (t)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$price$2d$armor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isTradeableTicker"])(t);
    try {
        const all = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
            priority: "critical",
            weight: 40
        }); // full-universe ticker — heavy, gated
        for (const t of all)if (want.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
            ...t,
            plane: "fapi"
        });
    } catch  {
    /* fall through to the spot overlay below */ }
    const missing = symbols.filter((s)=>!out.has(s));
    // v13.5 FUTWS OVERLAY rung — the live Binance futures bookTicker mid from
    // price-ws :3003. When the fapi board is throttled/banned but the WS ring
    // is printing (it is REST-weight-free), missing symbols get a PERP-NATIVE
    // live price instead of sliding to the spot overlay (basis) or the ring.
    if (missing.length > 0) {
        const fut = futwsQuoteMap();
        for (const s of missing){
            const q = fut.get(s);
            if (!q) continue;
            const t = {
                symbol: s,
                lastPrice: String(q.mid),
                priceChangePercent: "0",
                highPrice: String(q.mid),
                lowPrice: String(q.mid),
                quoteVolume: "0",
                bidPrice: String(q.bid),
                askPrice: String(q.ask),
                plane: "futws"
            };
            if (!zombie(t)) out.set(s, t);
        }
    }
    const stillMissingAfterFutws = symbols.filter((s)=>!out.has(s));
    if (stillMissingAfterFutws.length > 0) {
        // v14.3 rung 2.5 — spotws print file: real Binance spot prints (zero REST
        // weight) cover spot-listed misses before any REST contact is made.
        const spotws = spotwsPrintMap();
        for (const s of stillMissingAfterFutws){
            const p = spotws.get(s);
            if (p === undefined) continue;
            const t = {
                symbol: s,
                lastPrice: String(p),
                priceChangePercent: "0",
                highPrice: String(p),
                lowPrice: String(p),
                quoteVolume: "0",
                plane: "spot"
            };
            if (!zombie(t)) out.set(s, t);
        }
    }
    const stillMissingAfterSpotws = symbols.filter((s)=>!out.has(s));
    if (stillMissingAfterSpotws.length > 0) {
        try {
            // v14.3 rung 3 — REST, oracle-gated: only symbols still missing AND
            // present in the spotws membership file are requested (?symbols= filter,
            // weight 4 instead of the 200-weight full board). Symbols missing from
            // BOTH the futws ring and the spotws file are futures-only microcaps the
            // spot board could never price — the old code burned weight 200 to learn
            // exactly that. No spotws file at all (price-ws down) → legacy full-board
            // fallback so the overlay never goes dark.
            const spotws = spotwsPrintMap();
            const restWant = stillMissingAfterSpotws.filter((s)=>spotws.has(s)).slice(0, 100);
            if (restWant.length > 0) {
                const q = `?symbols=${encodeURIComponent(JSON.stringify(restWant))}`;
                const spot = await fetchJson(`/api/v3/ticker/24hr${q}`);
                for (const t of spot)if (want.has(t.symbol) && !out.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
                    ...t,
                    plane: "spot"
                });
            } else if (spotws.size === 0 && spotPrintLiveness().fresh === false) {
                const spot = await fetchJson("/api/v3/ticker/24hr");
                for (const t of spot)if (want.has(t.symbol) && !out.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
                    ...t,
                    plane: "spot"
                });
            }
        } catch  {
        /* fallback rung below */ }
    }
    // v14.0 BINANCE-ONLY — the v12.5 cross-venue mirror rung is retired. After
    // the futws ring + the spot overlay, futures-only tickers missing from both
    // stay honestly missing when fapi is banned (no invented data, no foreign
    // venue) — the caller falls back to sim drift exactly as documented.
    return out;
}
// identical response mapping for both kline planes (v10.16 — single mapper)
function mapKlines(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5])
        }));
}
async function fetchKlines(symbol, interval, limit) {
    try {
        const spot = await fetchJson(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
        if (spot.length) return mapKlines(spot);
    } catch  {
    /* fapi rung below */ }
    try {
        const perp = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
            priority: "critical"
        });
        if (perp && perp.length) return mapKlines(perp);
    } catch  {
    /* honest failure below */ }
    throw new Error(`fetchKlines: all Binance rungs failed for ${symbol} ${interval}`);
}
async function fetchFuturesKlines(symbol, interval, limit) {
    try {
        const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
            priority: "critical"
        });
        if (raw && raw.length) return mapKlines(raw);
    } catch  {
    /* spot rung below */ }
    try {
        const spot = await fetchJson(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
        if (spot.length) return mapKlines(spot);
    } catch  {
    /* honest failure below */ }
    throw new Error(`fetchFuturesKlines: all Binance rungs failed for ${symbol} ${interval}`);
}
// ── futures-only universe (R15) ───────────────────────────────
const STABLE_BASES = new Set([
    "USDC",
    "FDUSD",
    "TUSD",
    "BUSD",
    "DAI",
    "USDP",
    "EUR",
    "AEUR",
    "USDE",
    "USDS",
    "USR",
    "USDX",
    "USDTB",
    "USD1",
    "USTC",
    "U",
    "RLUSD",
    "PAXG"
]);
const LEVERAGED = /(UP|DOWN|BULL|BEAR)USDT$/;
function isStablePrice(p) {
    return p > 0.985 && p < 1.015;
}
async function fetchFuturesUniverse(n) {
    const tickers = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
        priority: "critical",
        weight: 40
    });
    return tickers.filter((t)=>t.symbol.endsWith("USDT")).filter((t)=>!LEVERAGED.test(t.symbol)).map((t)=>({
            symbol: t.symbol,
            quoteVolume: Number(t.quoteVolume),
            lastPrice: Number(t.lastPrice)
        })).filter((r)=>r.quoteVolume > 1_000_000 && !isStablePrice(r.lastPrice) && !STABLE_BASES.has(r.symbol.replace("USDT", ""))).sort((a, b)=>b.quoteVolume - a.quoteVolume).slice(0, n);
}
async function fetchFuturesSymbols() {
    const info = await fetchJsonFapi("/fapi/v1/exchangeInfo", {
        priority: "critical",
        weight: 1
    });
    return new Set(info.symbols.filter((s)=>s.contractType === "PERPETUAL" && s.status === "TRADING" && s.quoteAsset === "USDT").map((s)=>s.symbol));
}
let poolCache = null;
const POOL_TTL = 15 * 60_000;
// v5.2 TASK-53: persist the last good board so an app restart during an fapi
// ban doesn't zero the POOL readout (23:14Z boot with the ban live did exactly
// that — lastPoolSize seeded from nothing while the ban starved both rungs).
const POOL_FILE = ".data/pool-stats.json";
const POOL_PERSIST_MAX_AGE = 24 * 60 * 60_000;
function persistPool(value) {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const fs = __turbopack_context__.r("[externals]/fs [external] (fs, cjs)");
        fs.writeFileSync(POOL_FILE, JSON.stringify(value), "utf8");
    } catch  {
    /* best-effort telemetry — never a gate */ }
}
function persistedPool() {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const fs = __turbopack_context__.r("[externals]/fs [external] (fs, cjs)");
        const raw = JSON.parse(fs.readFileSync(POOL_FILE, "utf8"));
        if (!raw || typeof raw.totalUsdtPerps !== "number") return null;
        if (Date.now() - new Date(raw.measuredAt).getTime() > POOL_PERSIST_MAX_AGE) return null;
        return {
            ...raw,
            source: "PERSISTED"
        };
    } catch  {
        return null;
    }
}
async function fetchFuturesPoolStats() {
    if (poolCache && Date.now() - poolCache.at < POOL_TTL) return poolCache.value;
    try {
        const tickers = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
            priority: "telemetry",
            weight: 40
        }); // 15min-cached board stat — sheddable
        const usdtPerps = tickers.filter((t)=>t.symbol.endsWith("USDT") && !LEVERAGED.test(t.symbol));
        const value = {
            totalUsdtPerps: usdtPerps.length,
            liquidPool: usdtPerps.filter((t)=>Number(t.quoteVolume) > 1_000_000 && !isStablePrice(Number(t.lastPrice)) && !STABLE_BASES.has(t.symbol.replace("USDT", ""))).length,
            measuredAt: new Date().toISOString(),
            source: "BINANCE-FAPI"
        };
        poolCache = {
            at: Date.now(),
            value
        };
        persistPool(value);
        return value;
    } catch  {
        // fapi banned/unreachable — persisted board (Task 53, v14.0)
        const saved = persistedPool();
        if (saved) {
            poolCache = {
                at: Date.now(),
                value: saved
            };
            return saved;
        }
        return poolCache?.value ?? {
            totalUsdtPerps: 0,
            liquidPool: 0,
            measuredAt: new Date().toISOString(),
            source: "BINANCE-FAPI"
        };
    }
}
const FUTURES_FAPI = FAPI;
// ── v10.24 Task 34-a — gated futures fetch (fapi plane ONLY) ───────────────
// Same contract as fetchJson (resolve JSON or THROW) so every existing caller
// keeps its exact semantics; failures just become MORE common under weight
// pressure / IP bans — by design (callers are throw-tolerant with fallbacks).
// Walks FAPI_HOSTS through the gate: bans/weight are per-IP, so the alt host
// shares the same budget/ban state (a ban nulls the alt attempt instantly).
async function fetchJsonFapi(path, opts) {
    let lastErr;
    for (const host of FAPI_HOSTS){
        const t0 = Date.now();
        const json = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
            ...opts,
            host
        });
        if (json !== null) {
            feedStatus.lastOkAt = Date.now();
            feedStatus.latencyMs = Date.now() - t0;
            feedStatus.consecutiveFailures = 0;
            feedStatus.host = host.replace("https://", "");
            feedStatus.fallbackVenue = null; // Binance plane healthy — no fallback active
            if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
            return json;
        }
        feedStatus.consecutiveFailures++;
        lastErr = new Error(`fapi ${path} unavailable via ${host}`);
    }
    throw lastErr;
}
}),
"[project]/src/lib/indicators.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── FlowRadar Neo quant library (pure, client-safe) ──
// EMA / RSI / MACD / ATR / Bollinger / swing levels + 6-factor confluence scorer.
__turbopack_context__.s([
    "atr",
    ()=>atr,
    "bollingerPercentB",
    ()=>bollingerPercentB,
    "buildSnapshot",
    ()=>buildSnapshot,
    "ema",
    ()=>ema,
    "formatPrice",
    ()=>formatPrice,
    "macdHist",
    ()=>macdHist,
    "rsi",
    ()=>rsi,
    "scoreConfluence",
    ()=>scoreConfluence,
    "sma",
    ()=>sma
]);
function ema(values, period) {
    if (values.length === 0) return [];
    const k = 2 / (period + 1);
    const out = [
        values[0]
    ];
    for(let i = 1; i < values.length; i++)out.push(values[i] * k + out[i - 1] * (1 - k));
    return out;
}
function sma(values, period) {
    if (values.length === 0) return 0;
    const slice = values.slice(-period);
    return slice.reduce((a, b)=>a + b, 0) / slice.length;
}
function rsi(closes, period = 14) {
    if (closes.length < period + 1) return 50;
    let gain = 0;
    let loss = 0;
    for(let i = 1; i <= period; i++){
        const d = closes[i] - closes[i - 1];
        if (d >= 0) gain += d;
        else loss -= d;
    }
    let avgG = gain / period;
    let avgL = loss / period;
    for(let i = period + 1; i < closes.length; i++){
        const d = closes[i] - closes[i - 1];
        avgG = (avgG * (period - 1) + Math.max(0, d)) / period;
        avgL = (avgL * (period - 1) + Math.max(0, -d)) / period;
    }
    if (avgL === 0) return 100;
    const rs = avgG / avgL;
    return 100 - 100 / (1 + rs);
}
function macdHist(closes) {
    if (closes.length < 35) return {
        hist: 0,
        prev: 0
    };
    const e12 = ema(closes, 12);
    const e26 = ema(closes, 26);
    const line = e12.map((v, i)=>v - e26[i]);
    const signal = ema(line, 9);
    return {
        hist: line[line.length - 1] - signal[signal.length - 1],
        prev: line[line.length - 2] - signal[signal.length - 2]
    };
}
function atr(candles, period = 14) {
    if (candles.length < 2) return 0;
    let a = 0;
    let n = 0;
    for(let i = Math.max(1, candles.length - period); i < candles.length; i++){
        const c = candles[i];
        const p = candles[i - 1];
        const tr = Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
        a += tr;
        n++;
    }
    return n === 0 ? 0 : a / n;
}
function bollingerPercentB(closes, period = 20, mult = 2) {
    if (closes.length < period) return 0.5;
    const slice = closes.slice(-period);
    const mean = slice.reduce((a, b)=>a + b, 0) / period;
    const sd = Math.sqrt(slice.reduce((a, b)=>a + (b - mean) ** 2, 0) / period);
    const upper = mean + mult * sd;
    const lower = mean - mult * sd;
    if (upper === lower) return 0.5;
    return (closes[closes.length - 1] - lower) / (upper - lower);
}
function buildSnapshot(symbol, candles) {
    if (candles.length < 40) return null;
    const closes = candles.map((c)=>c.close);
    const price = closes[closes.length - 1];
    const e9 = ema(closes, 9);
    const e21 = ema(closes, 21);
    const emaFast = e9[e9.length - 1];
    const emaSlow = e21[e21.length - 1];
    const spreadPct = (emaFast - emaSlow) / emaSlow * 100;
    const r = rsi(closes);
    const rPrev = rsi(closes.slice(0, -1));
    const m = macdHist(closes);
    const a = atr(candles);
    const atrPct = a / price * 100;
    const percentB = bollingerPercentB(closes);
    const window = candles.slice(-21, -1); // exclude in-progress candle
    const rangeHigh = Math.max(...window.map((c)=>c.high));
    const rangeLow = Math.min(...window.map((c)=>c.low));
    const rangePos = rangeHigh === rangeLow ? 0.5 : (price - rangeLow) / (rangeHigh - rangeLow);
    // volume ratio: last COMPLETED candle vs SMA20 volume (partial-candle bias suppressed)
    const completed = candles.slice(-21, -1);
    const lastCompleted = completed[completed.length - 1];
    const volSma = completed.reduce((s, c)=>s + c.volume, 0) / completed.length;
    const volRatio = volSma === 0 ? 1 : lastCompleted.volume / volSma;
    return {
        symbol,
        price,
        emaFast,
        emaSlow,
        emaSpreadPct: spreadPct,
        rsi: r,
        rsiPrev: rPrev,
        macdHist: m.hist,
        macdHistPrev: m.prev,
        atrPct,
        percentB,
        rangeHigh,
        rangeLow,
        rangePos,
        volRatio,
        trendPct: a === 0 ? 0 : (emaFast - emaSlow) / a * 100
    };
}
const BASE_WEIGHTS = {
    "EMA STACK": 25,
    "MACD MOMENTUM": 15,
    "RSI POSITION": 15,
    "RANGE BREAKOUT": 20,
    "BOLLINGER EXTREME": 8,
    "VOLUME CONFIRM": 8
};
function scoreConfluence(snap, weights) {
    const votes = [];
    const w = (f)=>{
        const base = BASE_WEIGHTS[f] ?? 1;
        const cal = weights?.[f];
        return base * (typeof cal === "number" ? Math.min(1.25, Math.max(0.75, cal)) : 1);
    };
    const cal = !!weights && Object.keys(BASE_WEIGHTS).some((f)=>typeof weights[f] === "number");
    // 1. EMA stack (trend)
    const trendVote = snap.emaSpreadPct > 0 ? 1 : -1;
    const trendMag = Math.min(1, Math.abs(snap.trendPct) / 1.2);
    votes.push({
        factor: "EMA STACK",
        vote: Number((trendVote * w("EMA STACK") * (0.4 + 0.6 * trendMag)).toFixed(2)),
        detail: `EMA9 ${snap.emaSpreadPct >= 0 ? "+" : ""}${snap.emaSpreadPct.toFixed(3)}% vs EMA21 · trend ${snap.trendPct.toFixed(2)}×ATR`
    });
    // 2. MACD momentum
    const expanding = Math.abs(snap.macdHist) > Math.abs(snap.macdHistPrev);
    const macdVote = snap.macdHist > 0 ? 1 : -1;
    votes.push({
        factor: "MACD MOMENTUM",
        vote: Number((macdVote * w("MACD MOMENTUM") * (expanding ? 1 : 0.5)).toFixed(2)),
        detail: `hist ${snap.macdHist.toFixed(snap.price > 100 ? 2 : 4)} ${expanding ? "expanding" : "fading"}`
    });
    // 3. RSI position (trend-follow + mean-revert hybrid)
    if (snap.rsi >= 70) votes.push({
        factor: "RSI POSITION",
        vote: Number((-0.6 * w("RSI POSITION")).toFixed(2)),
        detail: `RSI ${snap.rsi.toFixed(1)} overbought — mean-revert pressure`
    });
    else if (snap.rsi <= 30) votes.push({
        factor: "RSI POSITION",
        vote: Number((0.6 * w("RSI POSITION")).toFixed(2)),
        detail: `RSI ${snap.rsi.toFixed(1)} oversold — mean-revert pressure`
    });
    else if (snap.rsi > 55 && snap.rsiPrev <= 55) votes.push({
        factor: "RSI POSITION",
        vote: Number((0.7 * w("RSI POSITION")).toFixed(2)),
        detail: `RSI ${snap.rsiPrev.toFixed(1)}→${snap.rsi.toFixed(1)} crossed above midline`
    });
    else if (snap.rsi < 45 && snap.rsiPrev >= 45) votes.push({
        factor: "RSI POSITION",
        vote: Number((-0.7 * w("RSI POSITION")).toFixed(2)),
        detail: `RSI ${snap.rsiPrev.toFixed(1)}→${snap.rsi.toFixed(1)} crossed below midline`
    });
    else votes.push({
        factor: "RSI POSITION",
        vote: Number(((snap.rsi - 50) / 50 * 0.5 * w("RSI POSITION")).toFixed(2)),
        detail: `RSI ${snap.rsi.toFixed(1)} neutral-drift · slope ${(snap.rsi - snap.rsiPrev).toFixed(1)}`
    });
    // 4. Range breakout (20-bar)
    if (snap.rangePos >= 0.98) votes.push({
        factor: "RANGE BREAKOUT",
        vote: Number(w("RANGE BREAKOUT").toFixed(2)),
        detail: `at 20-bar high ${snap.rangeHigh.toFixed(snap.price > 100 ? 1 : 4)} — breakout side`
    });
    else if (snap.rangePos <= 0.02) votes.push({
        factor: "RANGE BREAKOUT",
        vote: Number((-w("RANGE BREAKOUT")).toFixed(2)),
        detail: `at 20-bar low ${snap.rangeLow.toFixed(snap.price > 100 ? 1 : 4)} — breakdown side`
    });
    else if (snap.rangePos > 0.72) votes.push({
        factor: "RANGE BREAKOUT",
        vote: Number((0.55 * w("RANGE BREAKOUT")).toFixed(2)),
        detail: `upper quartile of 20-bar range (${(snap.rangePos * 100).toFixed(0)}%)`
    });
    else if (snap.rangePos < 0.28) votes.push({
        factor: "RANGE BREAKOUT",
        vote: Number((-0.55 * w("RANGE BREAKOUT")).toFixed(2)),
        detail: `lower quartile of 20-bar range (${(snap.rangePos * 100).toFixed(0)}%)`
    });
    else votes.push({
        factor: "RANGE BREAKOUT",
        vote: 0,
        detail: `mid-range (${(snap.rangePos * 100).toFixed(0)}%) — no edge`
    });
    // 5. Bollinger extreme
    if (snap.percentB >= 1) votes.push({
        factor: "BOLLINGER EXTREME",
        vote: Number((-0.5 * w("BOLLINGER EXTREME")).toFixed(2)),
        detail: `%B ${snap.percentB.toFixed(2)} above upper band — stretched`
    });
    else if (snap.percentB <= 0) votes.push({
        factor: "BOLLINGER EXTREME",
        vote: Number((0.5 * w("BOLLINGER EXTREME")).toFixed(2)),
        detail: `%B ${snap.percentB.toFixed(2)} below lower band — stretched`
    });
    else votes.push({
        factor: "BOLLINGER EXTREME",
        vote: 0,
        detail: `%B ${snap.percentB.toFixed(2)} inside bands`
    });
    // 6. Volume confirm
    if (snap.volRatio > 1.4) {
        const dir = snap.emaSpreadPct >= 0 ? 1 : -1;
        votes.push({
            factor: "VOLUME CONFIRM",
            vote: Number((dir * w("VOLUME CONFIRM")).toFixed(2)),
            detail: `volume ${snap.volRatio.toFixed(2)}× SMA20 — participation confirms ${dir > 0 ? "buyers" : "sellers"}`
        });
    } else votes.push({
        factor: "VOLUME CONFIRM",
        vote: 0,
        detail: `volume ${snap.volRatio.toFixed(2)}× SMA20 — unremarkable`
    });
    const rawScore = Math.max(-100, Math.min(100, votes.reduce((a, v)=>a + v.vote, 0)));
    const score = Math.round(rawScore);
    const direction = score >= 0 ? "LONG" : "SHORT";
    // strategy classification from factor fingerprint
    let strategy = "AI-SWING";
    const trendDom = Math.abs(votes[0].vote) >= 12;
    const breakout = Math.abs(votes[3].vote) >= 10;
    const volSpike = snap.volRatio > 1.4;
    if (breakout && volSpike) strategy = "BREAKOUT";
    else if (Math.abs(snap.percentB - 0.5) > 0.42 && Math.abs(snap.rsi - 50) < 12) strategy = "MEAN-REVERT";
    else if (trendDom && snap.atrPct > 0.55 && Math.abs(snap.trendPct) > 0.9) strategy = "AI-SWING";
    else if (Math.abs(rawScore) >= 30 && volSpike) strategy = "MOMENTUM";
    else if (Math.abs(rawScore) >= 18 && snap.atrPct < 0.55) strategy = "AI-SCALP";
    const volBonus = snap.volRatio > 1.4 ? 4 : 0;
    const confidence = Math.round(Math.min(96, Math.max(55, 55 + 0.42 * Math.abs(score) + volBonus)));
    return {
        score,
        direction,
        strategy,
        confidence,
        votes,
        rawScore,
        calibrated: cal
    };
}
function formatPrice(p) {
    return p >= 1000 ? p.toFixed(1) : p >= 1 ? p.toFixed(4) : p.toFixed(6);
}
}),
"[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ARM_EPOCH",
    ()=>ARM_EPOCH,
    "closeRealOutcomes",
    ()=>closeRealOutcomes,
    "getShadowVetoConfig",
    ()=>getShadowVetoConfig,
    "getShadowVetoState",
    ()=>getShadowVetoState,
    "linkRealDeploy",
    ()=>linkRealDeploy,
    "maybeAutoPromote",
    ()=>maybeAutoPromote,
    "offerFenceAdjudication",
    ()=>offerFenceAdjudication,
    "patternVetoEvidence",
    ()=>patternVetoEvidence,
    "promotionEvidence",
    ()=>promotionEvidence,
    "resetShadowEvidence",
    ()=>resetShadowEvidence,
    "retroLinkRealDeploys",
    ()=>retroLinkRealDeploys,
    "saveShadowVetoConfig",
    ()=>saveShadowVetoConfig,
    "shadowArmFeedDiagnostics",
    ()=>shadowArmFeedDiagnostics,
    "shadowArms",
    ()=>shadowArms,
    "shadowArmsCompletion",
    ()=>shadowArmsCompletion,
    "shadowPaperCount",
    ()=>shadowPaperCount,
    "shadowPaperSweep",
    ()=>shadowPaperSweep,
    "shadowPipelineDiag",
    ()=>shadowPipelineDiag,
    "shadowVetoDeployGate",
    ()=>shadowVetoDeployGate,
    "shadowVetoForCore",
    ()=>shadowVetoForCore,
    "shadowVetoObserve",
    ()=>shadowVetoObserve,
    "shadowVetoReady",
    ()=>shadowVetoReady,
    "shadowVetoRefresh",
    ()=>shadowVetoRefresh,
    "syncCohortFreeze",
    ()=>syncCohortFreeze,
    "wilsonLB",
    ()=>wilsonLB,
    "wilsonUB",
    ()=>wilsonUB
]);
// ── FlowRadar Neo v8.2 SHADOW-VETO — AI-core PHASE 0 (server-only) ──
// Operator mandate 2026-09-09: «قدم بعدی پیشنهادی رو کامل و مهندسی انجام بده»
// — the suggested next step from the AI-core usefulness doctrine
// (OP-AUDIT-TERMINAL-0908 ④ + OP-GATE-GAUGE-0908): a TIERED- AUTHORITY second
// opinion at the deploy gate, fully instrumented before it ever gains power.
//
//   Phase 0 (THIS): shadow mode — the adjudicator reviews every candidate in
//   the fence window (hair-thin passes gap 0..+3, near-miss rejects gap
//   −8..0), its verdicts are journaled, and BOTH sides of the fence are
//   outcome-tracked:
//     · PASS-side verdicts link to the REAL deployed trade (the would-veto
//       cohort keeps trading — that is the counterfactual evidence).
//     · REJECT-side TRADE verdicts open PAPER trades with engine-identical
//       geometry — the "would-have-won" ledger for fence rejects.
//   Phase 1 (gated): veto mode — unlockable ONLY on measured evidence
//   (≥30 settled per arm + Wilson-LB separation + negative veto-cohort PnL).
//   In veto mode a fresh VETO verdict blocks the deploy (fail-open: stale or
//   missing verdict → deploy proceeds) and the blocked trade is paper-tracked
//   so revocation pressure stays measurable.
//   Phase 1.5 (THIS, operator mandate 2026-10-04 «چرا فیلتر عملکردی اثبات‌شده‌ای
//   براش نمی‌زاری؟ چرا بازوها را سالم و کامل تغذیه نمی‌کنی؟»): PATTERN-VETO —
//   the GLOBAL promotion gate is deadlocked on whole-cohort evidence (the AI
//   core is roughly break-even on the fence as a whole), but the core may still
//   carry REAL veto value on SPECIFIC sub-populations. PATTERN-VETO grants
//   scoped veto authority per (strategy|direction) cell ONLY when that cell's
//   settled evidence PROVES the edge: n≥8 per side + 15pp WR separation +
//   Wilson-UB95(veto) < WR(keep) + negative would-veto net. In shadow mode a
//   fresh MODEL VETO verdict on a PROVEN pattern blocks the deploy (fail-open,
//   paper-tracked) — and every block feeds the paper-veto arm, which was
//   STRUCTURALLY starved (0/30) because it can only fill from veto-mode blocks.
//   This is the performance-proven filter the operator ordered: authority
//   flows from the ledger, per cell, revocable by evidence moving the other way.
//
// Division of labour: gate-journal.ts = capture · verdict.ts = learning ·
// THIS module = the adjudicator + outcome closure + A/B evidence. Zero SQLite
// writes for records (memory rings + .data/shadow-veto.jsonl); only the
// rarely-written config persists in EngineSetting (verdictcore.state pattern).
// Fail-open everywhere: this module must never throw into the deploy path.
//
// v10.19 FULL ACTIVATION (operator mandate 2026-09-24 «Shadow veto را کامل فعال کن»):
//   (1) LINK-DELTA REBUILD (lost v10.17, restored): hydration now MERGES
//       duplicate verdict records — the JSONL re-persists a verdict when its
//       state upgrades (serial bind / outcome closure / orphan sweep), but the
//       old first-record-wins hydration silently reverted linked verdicts to
//       unlinked on every restart (the real-veto 17→12 regression).
//   (2) ORPHAN SWEEP: the retro-link sweep now stamps verdicts whose fence
//       window closed with NO bindable deploy as swept orphans (sweptAt).
//       Forensic 2026-09-24: 84% of the stale backlog was structural orphan
//       (candidate adjudicated, deploy refused downstream) — counting them as
//       leaks DEADLOCKED the v10.16 promotion gate forever. The gate now
//       counts ACTIVE leaks only.
//   (3) mode=veto activated by OPERATOR MANDATE (audited force — arms were
//       27/30 + 12/30, evidence not yet full; veto stays fail-open, MODEL-
//       verdict-only, revocable, paper-tracked).
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$readline__$5b$external$5d$__$28$node$3a$readline$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:readline [external] (node:readline, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$seq$2d$stop$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/seq-stop.ts [app-route] (ecmascript)"); // v10.11 SEQ-STOP (operator APPROVE 2026-09-17)
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accounting.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indicators.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
// ── storage (mirrors gate-journal: rings + JSONL, zero SQLite) ──
const VERDICT_CAP = 600;
// TASK-40 (operator bug report 2026-09-27: «بازوها پر میشوند ولی مجدد داده ها از
// دست میرود»): PAPER_CAP=60 served TWO 30-settled windows (paper-keep REJECT/
// TRADE + paper-veto PASS/VETO) plus open inventory — any new paper evicted
// settled evidence the arms still needed. 160 lets both full windows coexist
// with open counterfactuals; ring objects are tiny, cost is negligible.
const PAPER_CAP = 160;
// TASK-40 CORE FIX — replay-phase trim suppression. Forensic replay of
// .data/shadow-veto.jsonl reproduced the operator's arms collapse EXACTLY
// (RK 20→2, RV 9→1 after restarts): hydrate() ingested oldest→newest while
// trimVerdicts/trimPapers ran on EVERY ingest — the settled records the
// rolling-30 arms need were cannibalized mid-replay, and the later "o" delta
// records then orphaned (their base verdict was already evicted). Evidence:
// with trim active the exact module replay yields RK=1/RV=4 (== live), with
// trim deferred RK=30/RV=17. Trims are suppressed until the FULL journal
// replay completes, then run ONCE. Steady-state (post-boot) trims unchanged.
let replayTrimSuppressed = true;
const ARM_EPOCH = "E-20260915"; // opened at the v10.6 observeCapture regime
const ROLLING_WINDOW = 30; // v10.10 — per-arm evidence window (most-recent settled)
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "shadow-veto.jsonl");
const FILE_MAX_BYTES = 6 * 1024 * 1024;
const verdicts = [];
const papers = [];
let persisted = 0;
let hydrating = null;
let seq = 0;
// v8.2.1 INGEST DISCIPLINE — Turbopack can run TWO module instances (old engine
// closure + freshly compiled routes) that BOTH adjudicate and write this JSONL
// with independent seq counters (length-derived seq caused id reuse: SV/PP-0039
// written twice). All ingestion therefore goes through id-unique + candidate-
// collapse gates so rings stay honest no matter how many instances write.
const seenIds = new Set();
const INGEST_COLLAPSE_MS = 10 * 60_000; // same candidate adjudicated twice within 10min = cross-instance duplicate
const settledArchive = new Map();
function archiveVerdict(v, merge = false) {
    let e = settledArchive.get(v.id);
    if (!e) {
        if (merge) return;
        e = {
            kind: "real",
            side: v.side,
            verdict: v.verdict,
            strategy: v.strategy ?? null,
            direction: v.direction ?? null,
            epoch: v.epoch ?? null,
            capture: isCaptureOrigin(v),
            outcome: v.outcome ?? null
        };
        settledArchive.set(v.id, e);
    }
    if (!e.outcome && v.outcome) e.outcome = v.outcome;
    // v11.0 — upgrade records also backfill the pattern dimensions
    if (!e.strategy && v.strategy) e.strategy = v.strategy;
    if (!e.direction && v.direction) e.direction = v.direction;
}
function archivePaper(p) {
    const e = settledArchive.get(p.id);
    if (e) {
        if (!e.outcome && p.outcome) e.outcome = p.outcome;
        return;
    }
    settledArchive.set(p.id, {
        kind: "paper",
        originSide: p.originSide,
        originVerdict: p.originVerdict,
        strategy: p.strategy ?? null,
        direction: p.direction ?? null,
        epoch: p.epoch ?? null,
        capture: false,
        outcome: p.outcome ?? null
    });
}
/** Rolling-30 settled arm rows FROM THE ARCHIVE — classification at ingest
 * time, outcomes merged from v/o (real) and p/pc (paper) records. */ function archiveArm(rows) {
    const settled = rows.filter((e)=>e.outcome);
    settled.sort((a, b)=>(b.outcome.closedAt || 0) - (a.outcome.closedAt || 0));
    return armOf(settled.slice(0, ROLLING_WINDOW).map((e)=>({
            pnlPercent: e.outcome.pnlPercent,
            pnlUsd: e.outcome.pnlUsd,
            win: e.outcome.win
        })));
}
function archivePaperRows() {
    return [
        ...settledArchive.values()
    ].filter((e)=>e.kind === "paper" && e.epoch);
}
function maxIdSeq(list) {
    let max = 0;
    for (const r of list){
        const m = /^S[VP]-(\d+)$/.exec(r.id);
        if (m) max = Math.max(max, Number(m[1]));
    }
    return max;
}
function ingestVerdict(v) {
    if (!v || typeof v.id !== "string") return false;
    // v10.19 LINK-DELTA REBUILD (restored lost v10.17): the JSONL re-persists a
    // verdict whenever its state UPGRADES (linkRealDeploy binds the serial, the
    // outcome sweep closes it, the orphan sweep stamps it). First-record-wins
    // hydration silently DROPPED those upgrades — every restart reverted linked-
    // but-unsettled verdicts back to unlinked (the real-veto 17→12 regression
    // after the 2026-09-21 restarts). Duplicate ids now MERGE their upgrade
    // fields into the already-ingested record, order-independent.
    if (seenIds.has(v.id)) {
        const ex = verdicts.find((x)=>x.id === v.id);
        if (ex) {
            if (ex.serial === null && v.serial !== null) ex.serial = v.serial;
            if (!ex.outcome && v.outcome) ex.outcome = v.outcome;
            if (ex.sweptAt === undefined && v.sweptAt !== undefined) ex.sweptAt = v.sweptAt;
        }
        archiveVerdict(v, true); // TASK-40: upgrade records also update the archive
        return false;
    }
    v.audit = v.audit ?? null; // normalize legacy records
    // collapse cross-instance duplicate adjudications of the same candidate —
    // scan backwards to the candidate's latest record; inside the window = dupe
    for(let i = verdicts.length - 1; i >= 0; i--){
        const x = verdicts[i];
        if (x.symbol === v.symbol && x.direction === v.direction) {
            if (Math.abs(x.at - v.at) < INGEST_COLLAPSE_MS) return false;
            break;
        }
    }
    seenIds.add(v.id);
    verdicts.push(v);
    archiveVerdict(v); // TASK-40: every ingested verdict is archived (trim-proof)
    trimVerdicts(); // Task 34-2: evidence-safety eviction (was: blind oldest-first splice)
    return true;
}
/**
 * Task 34-2 (2026-09-26, operator mandate «RAW-CAL تا تکمیل بازوهای Shadow veto»):
 * VERDICT_CAP eviction was a blind oldest-first splice — it silently dropped
 * linked-but-UNSETTLED verdicts (46 of them, 09-15..09-23, signals settled in
 * the DB while their arm outcome never closed). The real arms then starved
 * (real-keep stuck 20/30, real-veto 9/30) with zero observability because
 * closeRealOutcomes saw `pending.length === 0` in memory. Mirrors trimPapers
 * doctrine: a SETTLED/resolved record can always be re-derived from the
 * rotated journal, but OPEN evidence evicted mid-flight is lost forever.
 * Resolved = outcome closed, OR unlinked-forever (orphan-swept with no serial).
 */ function trimVerdicts() {
    if ("TURBOPACK compile-time truthy", 1) return; // TASK-40: no mid-replay eviction — see flag doc
    //TURBOPACK unreachable
    ;
    let overflow;
    let i;
}
function ingestPaper(p) {
    if (!p || typeof p.id !== "string") return false;
    if (seenIds.has(p.id)) {
        archivePaper(p); // TASK-40: re-persisted paper may carry an inline outcome upgrade
        return false;
    }
    seenIds.add(p.id);
    papers.push(p);
    archivePaper(p);
    trimPapers();
    return true;
}
/** v10.7 FIFO cap with evidence-safety — evict oldest SETTLED papers first;
 * only when the ring is all-OPEN (degenerate burst) fall back to oldest-first.
 * A settled record can always be re-derived from the rotated journal, but a
 * live counterfactual evicted mid-flight is lost evidence forever. */ function trimPapers() {
    if ("TURBOPACK compile-time truthy", 1) return; // TASK-40: no mid-replay eviction — see flag doc
    //TURBOPACK unreachable
    ;
    let overflow;
    let i;
}
// v8.2.1 SPLIT-BRAIN COUNTERMEASURE (mirrors gate-journal.ts) — Turbopack dev
// compiles one module instance PER ROUTE; the engine's instance adjudicates +
// writes the JSONL while a freshly-compiled read route would otherwise show a
// frozen/empty view forever. readPos-tailing keeps every reader live.
let readPos = 0;
let hydratedAt = 0;
let refreshing = null;
let lastRefreshAt = 0;
const REFRESH_MIN_INTERVAL_MS = 10_000;
const REFRESH_MAX_BITE = 512 * 1024;
const DEFAULT_CONFIG = {
    mode: "shadow",
    windowPass: 3,
    windowReject: -8,
    budgetPerHour: 12,
    minSpacingMs: 90_000,
    dedupMs: 30 * 60_000,
    cacheTtlMs: 8 * 60_000,
    paperMarginUsd: 5,
    autoPromote: true,
    observeCapture: true,
    patternVeto: true
};
const CONFIG_KEY = "shadowveto.config";
let configCache = null;
let configLoadedAt = 0;
async function hydrate() {
    if (hydrating) return hydrating;
    hydrating = (async ()=>{
        try {
            // TASK-40 (2026-09-27, operator bug «بازوها پر میشوند ولی مجدد داده‌ها از
            // دست میرود و کاهش پیدا می‌کند»): hydrate previously ingested ONLY the last
            // 3000 journal lines. With the live journal at ~5.1k lines, every restart
            // dropped the older verdicts — and crucially the OUTCOME records ("o"/"pc")
            // whose base record had scrolled out of the window — so the REAL arms
            // collapsed after each boot (observed live: real-keep 30→2, real-veto
            // 30→1 after the 09-25..09-27 restart waves; offline replay of the FULL
            // journal proves both arms hold a complete rolling-30 cohort). The journal
            // is rotation-capped at 6MB, so FULL ingestion is bounded; the .old
            // rotation ring (when present) is ingested FIRST so upgrade-merge
            // (ingestVerdict) and outcome application (applyOutcomeRecord /
            // applyPaperClose) see correct oldest→newest chronology.
            // MEMORY (Task-39 lesson): the first cut did one readFile + one giant
            // split — a multi-MB transient spike exactly during the boot+compile
            // window, which pushed the 09:46 boot over the edge into a kernel
            // OOM-kill. Ingestion is now STREAMED line-by-line (64KB readahead):
            // peak memory = one journal line, event loop yields naturally between
            // stream chunks, and evidence completeness is unchanged.
            const ingestJournalLine = (line)=>{
                if (!line) return;
                try {
                    const rec = JSON.parse(line);
                    if (rec.k === "v") ingestVerdict(rec.v);
                    else if (rec.k === "p") ingestPaper(rec.v);
                    else if (rec.k === "o") applyOutcomeRecord(rec.v);
                    else if (rec.k === "pc") applyPaperClose(rec.v);
                } catch  {
                /* torn line */ }
            };
            const ingestJournalStreamed = async (filePath)=>{
                try {
                    const rl = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$readline__$5b$external$5d$__$28$node$3a$readline$2c$__cjs$29$__["createInterface"])({
                        input: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["createReadStream"])(filePath, {
                            encoding: "utf8"
                        }),
                        crlfDelay: Infinity
                    });
                    for await (const line of rl)ingestJournalLine(line);
                } catch  {
                /* missing ring (no rotation yet) or unreadable — cold for this ring only */ }
            };
            await ingestJournalStreamed(`${FILE}.old`); // rotation ring — OLDER records first
            await ingestJournalStreamed(FILE);
            if (verdicts.length || papers.length) {
                // v8.2.1 — seq MUST derive from the MAX id on disk (length-derived seq
                // reused ids when two module instances wrote with independent counters)
                seq = Math.max(maxIdSeq(verdicts), maxIdSeq(papers));
            }
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            persisted = st?.size ?? 0;
            readPos = st?.size ?? 0;
            hydratedAt = Date.now();
            // dedup continuity across instance swaps — a fresh instance must not
            // instantly re-adjudicate what another instance just adjudicated
            for (const v of verdicts){
                const key = `${v.symbol}|${v.direction}`;
                const prev = lastAdjAt.get(key) ?? 0;
                if (v.at > prev) lastAdjAt.set(key, v.at);
            }
            if ((st?.size ?? 0) > FILE_MAX_BYTES) {
                // v10.6.1 persist-guard (operator APPROVE 2026-09-18): rotation is the
                // destructive rewrite — if a fresher boot just rotated, resync our
                // counters from disk instead of renaming over its rotation.
                const { persistGuardOk, persistWatermark, serializePersist } = await __turbopack_context__.A("[project]/src/lib/persist-guard.ts [app-route] (ecmascript, async loader)");
                await serializePersist("shadow-veto-journal", async ()=>{
                    if (!await persistGuardOk("shadow-veto-journal")) {
                        const fresh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
                        persisted = Math.min(fresh?.size ?? 0, FILE_MAX_BYTES);
                        readPos = fresh?.size ?? 0;
                        return;
                    }
                    await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
                    await persistWatermark("shadow-veto-journal");
                    persisted = 0;
                    readPos = 0;
                });
            }
        } catch (e) {
            // TASK-40: journaling must never break the engine, but a SILENT hydrate
            // failure used to leave empty rings that later persists could not repair
            // (shadow-veto only appends). Make the failure observable in dev.log.
            console.error("[shadow-veto] hydrate failed (rings cold, journal untouched):", e);
        }
    })();
    return hydrating;
}
async function persist(rec) {
    try {
        const line = JSON.stringify(rec) + "\n";
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(FILE, line, "utf8");
        persisted += line.length;
        readPos += line.length; // our own bytes are already in the rings
        if (persisted > FILE_MAX_BYTES) {
            // v10.6.1 persist-guard: serialize rotation + re-stat before renaming so
            // concurrent writers (or a stale generation) never clobber a fresh file.
            const { persistGuardOk, persistWatermark, serializePersist } = await __turbopack_context__.A("[project]/src/lib/persist-guard.ts [app-route] (ecmascript, async loader)");
            await serializePersist("shadow-veto-journal", async ()=>{
                const cur = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
                if ((cur?.size ?? 0) <= FILE_MAX_BYTES) {
                    // someone else already rotated — just resync our counters
                    persisted = Math.min(cur?.size ?? 0, FILE_MAX_BYTES);
                    readPos = cur?.size ?? 0;
                    return;
                }
                if (!await persistGuardOk("shadow-veto-journal")) {
                    const fresh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
                    persisted = Math.min(fresh?.size ?? 0, FILE_MAX_BYTES);
                    readPos = fresh?.size ?? 0;
                    return;
                }
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
                await persistWatermark("shadow-veto-journal");
                persisted = 0;
                readPos = 0;
            });
        }
    } catch  {
    /* non-fatal */ }
}
async function shadowVetoReady() {
    await hydrate();
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
            recursive: true
        });
    } catch  {
    /* exists */ }
}
async function shadowVetoRefresh(maxAgeMs = REFRESH_MIN_INTERVAL_MS) {
    if (Date.now() - lastRefreshAt < maxAgeMs) return;
    if (refreshing) return refreshing;
    refreshing = (async ()=>{
        try {
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            if (!st) return;
            if (st.size < readPos) readPos = 0; // rotated
            if (st.size === readPos) return;
            const len = Math.min(st.size - readPos, REFRESH_MAX_BITE);
            const fh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(FILE, "r").catch(()=>null);
            if (!fh) return;
            try {
                const buf = Buffer.alloc(len);
                const { bytesRead } = await fh.read(buf, 0, len, readPos);
                let text = buf.toString("utf8", 0, bytesRead);
                const lastNl = text.lastIndexOf("\n");
                if (lastNl === -1) return; // partial line — wait for the writer
                text = text.slice(0, lastNl + 1);
                readPos += Buffer.byteLength(text, "utf8");
                for (const line of text.split("\n")){
                    if (!line) continue;
                    try {
                        const rec = JSON.parse(line);
                        if (rec.k === "v") {
                            const v = rec.v;
                            const m = /^SV-(\d+)$/.exec(v.id ?? "");
                            if (ingestVerdict(v) && m) seq = Math.max(seq, Number(m[1]));
                        } else if (rec.k === "p") {
                            ingestPaper(rec.v);
                        } else if (rec.k === "o") applyOutcomeRecord(rec.v);
                        else if (rec.k === "pc") applyPaperClose(rec.v);
                    } catch  {
                    /* torn line */ }
                }
                hydratedAt = Date.now();
            } finally{
                await fh.close().catch(()=>undefined);
            }
        } catch  {
        /* non-fatal */ } finally{
            lastRefreshAt = Date.now();
        }
    })().finally(()=>{
        refreshing = null;
    });
    return refreshing;
}
function applyOutcomeRecord(rec) {
    const v = [
        ...verdicts
    ].reverse().find((x)=>x.id === rec.id);
    if (v && !v.outcome) v.outcome = rec.outcome;
    const ae = settledArchive.get(rec.id); // TASK-40: the archive never misses an outcome, even if the base verdict was ring-evicted
    if (ae && !ae.outcome) ae.outcome = rec.outcome;
}
function applyPaperClose(rec) {
    const p = [
        ...papers
    ].reverse().find((x)=>x.id === rec.id);
    if (p && !p.outcome) {
        p.status = rec.status;
        p.reachedTp = rec.reachedTp;
        p.pnlPercent = rec.pnlPercent;
        p.pnlUsd = rec.pnlUsd;
        p.stop = rec.stop;
        p.outcome = rec.outcome;
        p.closeNote = rec.closeNote;
    }
    const ae = settledArchive.get(rec.id); // TASK-40
    if (ae && !ae.outcome) ae.outcome = rec.outcome;
}
async function getShadowVetoConfig(force = false) {
    if (!force && configCache && Date.now() - configLoadedAt < 15_000) return configCache;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: CONFIG_KEY
            }
        });
        if (row) {
            const parsed = JSON.parse(row.value);
            configCache = {
                mode: [
                    "off",
                    "shadow",
                    "veto"
                ].includes(parsed.mode) ? parsed.mode : DEFAULT_CONFIG.mode,
                windowPass: Number.isFinite(parsed.windowPass) ? Math.max(0, Math.min(10, parsed.windowPass)) : DEFAULT_CONFIG.windowPass,
                windowReject: Number.isFinite(parsed.windowReject) ? Math.max(-30, Math.min(0, parsed.windowReject)) : DEFAULT_CONFIG.windowReject,
                budgetPerHour: Number.isFinite(parsed.budgetPerHour) ? Math.max(2, Math.min(40, parsed.budgetPerHour)) : DEFAULT_CONFIG.budgetPerHour,
                minSpacingMs: Number.isFinite(parsed.minSpacingMs) ? Math.max(30_000, parsed.minSpacingMs) : DEFAULT_CONFIG.minSpacingMs,
                dedupMs: Number.isFinite(parsed.dedupMs) ? Math.max(5 * 60_000, parsed.dedupMs) : DEFAULT_CONFIG.dedupMs,
                cacheTtlMs: Number.isFinite(parsed.cacheTtlMs) ? Math.max(60_000, parsed.cacheTtlMs) : DEFAULT_CONFIG.cacheTtlMs,
                paperMarginUsd: Number.isFinite(parsed.paperMarginUsd) ? Math.max(1, Math.min(20, parsed.paperMarginUsd)) : DEFAULT_CONFIG.paperMarginUsd,
                autoPromote: typeof parsed.autoPromote === "boolean" ? parsed.autoPromote : DEFAULT_CONFIG.autoPromote,
                observeCapture: typeof parsed.observeCapture === "boolean" ? parsed.observeCapture : DEFAULT_CONFIG.observeCapture,
                patternVeto: typeof parsed.patternVeto === "boolean" ? parsed.patternVeto : DEFAULT_CONFIG.patternVeto
            };
        } else configCache = {
            ...DEFAULT_CONFIG
        };
    } catch  {
        configCache = configCache ?? {
            ...DEFAULT_CONFIG
        };
    }
    configLoadedAt = Date.now();
    return configCache;
}
async function saveShadowVetoConfig(patch) {
    const cur = await getShadowVetoConfig(true);
    const next = {
        ...cur,
        ...patch
    };
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: CONFIG_KEY
        },
        create: {
            key: CONFIG_KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
    configCache = next;
    configLoadedAt = Date.now();
    return next;
}
function wilsonLB(wins, n) {
    if (n <= 0) return null;
    const z = 1.96;
    const p = wins / n;
    const denom = 1 + z * z / n;
    const centre = p + z * z / (2 * n);
    const spread = z * Math.sqrt((p * (1 - p) + z * z / (4 * n)) / n);
    return Math.max(0, (centre - spread) / denom * 100);
}
function wilsonUB(wins, n) {
    if (n <= 0) return null;
    const z = 1.96;
    const p = wins / n;
    const denom = 1 + z * z / n;
    const centre = p + z * z / (2 * n);
    const spread = z * Math.sqrt((p * (1 - p) + z * z / (4 * n)) / n);
    return Math.min(100, (centre + spread) / denom * 100);
}
// ── budget / dedup state ──────────────────────────────────────
const callStamps = [];
let lastCallAt = 0;
const lastAdjAt = new Map();
const verdictCache = new Map(); // symbol|direction → latest
let pendingCount = 0;
const MAX_PENDING = 3;
function withinBudget(cfg) {
    const now = Date.now();
    while(callStamps.length && now - callStamps[0] > 3600_000)callStamps.shift();
    if (callStamps.length >= cfg.budgetPerHour) return false;
    if (now - lastCallAt < cfg.minSpacingMs) return false;
    return true;
}
async function offerFenceAdjudication(batch) {
    try {
        const cfg = await getShadowVetoConfig();
        if (cfg.mode === "off" || batch.length === 0 || pendingCount >= MAX_PENDING) return;
        await shadowVetoReady();
        const now = Date.now();
        // closest-to-gate first so the budget buys the most informative verdicts
        const fence = batch.map((c)=>({
                c,
                gap: Math.abs(c.score) - c.effMin
            })).filter(({ c, gap })=>c.passed ? gap >= 0 && gap <= cfg.windowPass : gap < 0 && gap >= cfg.windowReject).sort((a, b)=>Math.abs(a.gap) - Math.abs(b.gap));
        for (const { c, gap } of fence){
            const key = `${c.symbol}|${c.direction}`;
            const last = lastAdjAt.get(key) ?? 0;
            if (now - last < cfg.dedupMs) continue;
            const cached = verdictCache.get(key);
            if (cached && now - cached.at < cfg.cacheTtlMs) continue; // fresh verdict already in place
            lastAdjAt.set(key, now);
            pendingCount++;
            void runAdjudication(c, c.passed ? "PASS" : "REJECT", gap).catch(()=>undefined).finally(()=>{
                pendingCount = Math.max(0, pendingCount - 1);
            });
        }
    } catch  {
    /* never break the scan */ }
}
async function runAdjudication(c, side, gap) {
    const cfg = await getShadowVetoConfig(true);
    if (cfg.mode === "off") return;
    if (!withinBudget(cfg)) return;
    callStamps.push(Date.now());
    lastCallAt = Date.now();
    await adjudicateCore(c, side, gap, cfg); // origin defaults to "fence" — the normal gate-fence path
}
/** v10.6 CAPTURE-OBSERVE (operator mandate «پرشدن بازوهای shadow-veto را سرعت و بهبود ببخش»،
 * 2026-09-15). ROOT CAUSE of the REAL-arm starvation: RAW-CAL capture deploys run
 * with bypassQuality=true, which SKIPS the entire shadow-veto deploy path — so 113
 * capture issues produced ZERO pass-side verdicts and real-keep froze at 9/30
 * (n-keep is the binding promotion criterion). observe(): an OBSERVE-ONLY
 * adjudication on every capture deploy — side PASS (the trade IS deploying),
 * verdict NEVER vetoes (capture authority untouched), linked to the real serial
 * by the existing linkRealDeploy → settle → closeRealOutcomes chain. Every
 * capture settle now lands in the real-keep / real-veto A/B arms. Budget-honest:
 * shares the LLM accounting (callStamps) with a small observe headroom, spaced
 * by minSpacingMs; capture cadence (~12min spacing) keeps it ≈3-5 calls/h. */ let lastObserveAt = 0;
async function shadowVetoObserve(ctx) {
    try {
        const cfg = await getShadowVetoConfig(true);
        if (cfg.mode === "off" || !cfg.observeCapture) return;
        await shadowVetoReady();
        const now = Date.now();
        if (now - lastObserveAt < cfg.minSpacingMs) return;
        const key = `${ctx.symbol}|${ctx.direction}`;
        const cached = verdictCache.get(key);
        if (cached && now - cached.at < cfg.cacheTtlMs && cached.side === "PASS" && cached.serial === null) return; // fresh unlinked verdict — linkRealDeploy will bind it
        lastObserveAt = now;
        callStamps.push(now);
        lastCallAt = now;
        await adjudicateCore({
            symbol: ctx.symbol,
            direction: ctx.direction,
            strategy: ctx.strategy,
            score: ctx.score,
            effMin: ctx.effMin,
            baseMin: 0,
            thr: ctx.thr,
            confirms: ctx.confirms,
            opposes: ctx.opposes,
            notes: ctx.notes,
            source: ctx.source,
            passed: true
        }, "PASS", ctx.gap, cfg, " [CAPTURE-OBSERVE]", "capture");
    } catch  {
    /* observe must never break the deploy */ }
}
async function adjudicateCore(c, side, gap, cfg, tag = "", origin = "fence") {
    const { aiShadowAdjudication } = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)");
    const res = await aiShadowAdjudication({
        symbol: c.symbol,
        direction: c.direction,
        strategy: c.strategy,
        side,
        gap,
        score: c.score,
        effMin: c.effMin,
        thr: c.thr,
        confirms: c.confirms,
        opposes: c.opposes,
        notes: c.notes
    });
    seq++;
    const rec = {
        id: `SV-${String(seq).padStart(4, "0")}`,
        at: Date.now(),
        symbol: c.symbol,
        direction: c.direction,
        strategy: c.strategy,
        side,
        gap,
        score: c.score,
        effMin: c.effMin,
        thr: c.thr,
        verdict: res.verdict,
        confidence: res.confidence,
        reason: `${res.reason}${tag}`,
        label: res.label,
        audit: res.audit ?? null,
        source: c.source,
        serial: null,
        outcome: null,
        epoch: ARM_EPOCH,
        origin
    };
    verdicts.push(rec);
    seenIds.add(rec.id); // id-discipline: this instance's live verdicts are also "seen"
    if (verdicts.length > VERDICT_CAP) verdicts.splice(0, verdicts.length - VERDICT_CAP);
    verdictCache.set(`${c.symbol}|${c.direction}`, rec);
    void persist({
        k: "v",
        v: rec
    });
    // v8.2.1 — an audited HALLUCINATION is an operator-visible event (rate-bounded
    // by the adjudication budget itself; this path only fires on VIOLATION)
    if (res.audit?.verdict === "VIOLATION") {
        await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, c.symbol, "ENGINE", "warn", `SHADOW-VETO ${rec.id}: model verdict DISCARDED — grounding violation (${res.audit.unmatched.length} citations not in evidence bundle). Heuristic adjudication used instead.`)).catch(()=>undefined);
    }
    // REJECT-side TRADE verdict = the core disagrees with the numeric gate →
    // open the counterfactual paper trade (the would-have-won ledger).
    if (side === "REJECT" && res.verdict === "TRADE") void openPaperTrade(rec, cfg.paperMarginUsd).catch(()=>undefined);
    // rate-limited audit event so the operator sees the core speaking
    if (side === "REJECT" && res.verdict === "TRADE" || side === "PASS" && res.verdict === "VETO") {
        const pos = side === "PASS" ? "hair-thin pass" : `fence reject gap ${gap.toFixed(1)}`;
        const msg = `SHADOW-VETO ${rec.id}: ${c.symbol} ${c.direction} (${pos}) → ${res.verdict} @ ${res.confidence}% — ${res.reason}`;
        await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, c.symbol, "ENGINE", "ai", msg)).catch(()=>undefined);
    }
}
async function shadowVetoDeployGate(ctx) {
    const failOpen = {
        veto: false,
        verdictId: null,
        reason: null,
        mode: "shadow"
    };
    try {
        const cfg = await getShadowVetoConfig();
        failOpen.mode = cfg.mode;
        // v11.0 PATTERN-VETO — in shadow mode the gate wakes up ONLY as the scoped
        // authority (cfg.patternVeto): same freshness/label discipline as the global
        // gate, but the block fires only when the candidate's (strategy|direction)
        // cell is PROVEN by the settled evidence. mode=off or patternVeto=false →
        // shadow mode stays exactly as dormant at deploy time as before v11.0.
        if (cfg.mode === "off" || ctx.gap > cfg.windowPass) return failOpen;
        const globalVeto = cfg.mode === "veto";
        const patternScoped = !globalVeto && cfg.patternVeto === true;
        if (!globalVeto && !patternScoped) return failOpen;
        await shadowVetoReady();
        const key = `${ctx.symbol}|${ctx.direction}`;
        const cached = verdictCache.get(key);
        const fresh = cached && Date.now() - cached.at < cfg.cacheTtlMs && cached.side === "PASS";
        if (!fresh || !cached) {
            // pre-warm for the next evaluation of this fence candidate
            void offerFenceAdjudication([
                {
                    symbol: ctx.symbol,
                    direction: ctx.direction,
                    strategy: ctx.strategy,
                    score: ctx.score,
                    effMin: ctx.effMin,
                    baseMin: 0,
                    thr: ctx.thr,
                    confirms: ctx.confirms,
                    opposes: ctx.opposes,
                    notes: ctx.notes,
                    source: ctx.source,
                    passed: true
                }
            ]);
            return failOpen;
        }
        // v8.4.1 HARD GUARD — only MODEL verdicts may ever block a real deploy.
        // Heuristic verdicts are honest fallbacks (429 storms, grounding violations)
        // but a deterministic net-vote sign must never veto real capital. Fail-open.
        if (cached.label !== "MODEL") {
            void offerFenceAdjudication([
                {
                    symbol: ctx.symbol,
                    direction: ctx.direction,
                    strategy: ctx.strategy,
                    score: ctx.score,
                    effMin: ctx.effMin,
                    baseMin: 0,
                    thr: ctx.thr,
                    confirms: ctx.confirms,
                    opposes: ctx.opposes,
                    notes: ctx.notes,
                    source: ctx.source,
                    passed: true
                }
            ]);
            return failOpen;
        }
        if (cached.verdict !== "VETO") return failOpen;
        // v11.0 PATTERN-VETO — scoped authority check: the candidate's cell must be
        // PROVEN (n≥8/side · 15pp WR sep · Wilson-UB95(veto) < WR(keep) · net<0) or
        // the deploy proceeds untouched (fail-open). This is the performance-
        // proven filter: authority flows from the ledger per cell, not globally.
        let scoped = false;
        if (patternScoped) {
            scoped = provenPatternSet().has(`${cached.strategy}|${cached.direction}`);
            if (!scoped) return failOpen;
        }
        // VETO fires — record the block + the counterfactual paper trade
        const geo = await paperGeometry(ctx.symbol, ctx.direction, ctx.strategy, ctx.entryPrice).catch(()=>null);
        if (!geo) return failOpen;
        seq++;
        const paper = newPaperShell(`PP-${String(seq).padStart(4, "0")}`, cached, cfg, geo);
        papers.push(paper);
        trimPapers();
        void persist({
            k: "p",
            v: paper
        });
        return {
            veto: true,
            verdictId: cached.id,
            reason: `${scoped ? `PATTERN-VETO [${cached.strategy}|${cached.direction}] ` : ""}${cached.label} ${cached.confidence}% — ${cached.reason}`,
            mode: cfg.mode
        };
    } catch  {
        return failOpen;
    }
}
async function linkRealDeploy(serial, symbol, direction) {
    try {
        if (!serial) return;
        await shadowVetoReady();
        const key = `${symbol}|${direction}`;
        const now = Date.now();
        const candidate = [
            ...verdicts
        ].reverse().find((v)=>`${v.symbol}|${v.direction}` === key && v.side === "PASS" && v.serial === null && now - v.at < 15 * 60_000);
        if (candidate) {
            candidate.serial = serial;
            void persist({
                k: "v",
                v: candidate
            });
        }
    } catch  {
    /* linkage must never break the deploy */ }
}
const SETTLED = [
    "TP1",
    "TP2",
    "TP3",
    "SL",
    "EXPIRED",
    "CLOSED"
];
async function retroLinkRealDeploys() {
    try {
        await shadowVetoReady();
        const unlinked = verdicts.filter((v)=>v.side === "PASS" && v.serial === null);
        if (unlinked.length === 0) return 0;
        const taken = new Set(verdicts.filter((v)=>v.serial !== null).map((v)=>v.serial));
        // v10.16 — look back far enough to reach the OLDEST unlinked verdict's
        // deploy window (±90min), bounded at 7 days so the query stays cheap.
        const oldestUnlinked = unlinked.reduce((a, v)=>Math.min(a, v.at), Date.now());
        const sinceMs = Math.max(Date.now() - 7 * 24 * 3600_000, oldestUnlinked - 90 * 60_000);
        const sigs = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
            where: {
                createdAt: {
                    gte: new Date(sinceMs)
                }
            },
            select: {
                serial: true,
                symbol: true,
                direction: true,
                createdAt: true
            },
            orderBy: {
                createdAt: "desc"
            },
            take: 400
        });
        let bound = 0;
        // v10.19 ORPHAN SWEEP — coverage bounds of the fetch (take-400 desc): when
        // the query returns its FULL take, the oldest fetched row bounds coverage;
        // otherwise the query reaches sinceMs. A verdict is only stampable as an
        // orphan when its ENTIRE ±90min fence window lies inside covered ground —
        // absence is then PROOF no deploy ever existed, not a fetch artifact.
        const coverageLower = sigs.length === 400 && sigs.length > 0 ? sigs[sigs.length - 1].createdAt.getTime() : sinceMs;
        let swept = 0;
        for (const v of unlinked){
            let anyInWindow = false; // v10.19 — a matching deploy exists (even if claimed)
            let best = null;
            for (const s of sigs){
                if (s.symbol !== v.symbol || s.direction !== v.direction) continue;
                const dt = v.at - s.createdAt.getTime(); // <0 = verdict pre-warmed the deploy, >0 = fence batch after it
                // v10.16 — match window widened 15min→90min (both sides) so edge-born
                // verdicts and the >24h stale backlog can bind their own trades.
                if (dt < -90 * 60_000 || dt > 90 * 60_000) continue;
                anyInWindow = true;
                if (taken.has(s.serial)) continue;
                if (!best || Math.abs(dt) < Math.abs(best.dt)) best = {
                    serial: s.serial,
                    dt
                };
            }
            if (best) {
                v.serial = best.serial;
                taken.add(best.serial);
                void persist({
                    k: "v",
                    v
                });
                bound++;
            } else if (v.sweptAt === undefined && v.at + 90 * 60_000 < Date.now() && // fence window fully closed — a late deploy can no longer arrive
            v.at - 90 * 60_000 >= coverageLower && // window fully inside the query reach
            !anyInWindow // no same-symbol|direction deploy existed at all → structural orphan, promotion-inert
            ) {
                v.sweptAt = Date.now();
                void persist({
                    k: "v",
                    v
                });
                swept++;
            }
        }
        if (swept > 0) console.log(`[shadow-veto] retro-link: bound=${bound} swept-orphans=${swept}`);
        return bound;
    } catch (e) {
        // Task 34-2: silent fail-open hid the retro-link stall (28 unlinked PASS
        // in 24h with bound=0) — same observability lesson as closeRealOutcomes.
        console.error("[shadow-veto] retroLinkRealDeploys failed", e);
        return 0; // evidence plumbing must never throw into the tick
    }
}
async function closeRealOutcomes() {
    try {
        await shadowVetoReady();
        const pending = verdicts.filter((v)=>v.serial !== null && v.outcome === null);
        if (pending.length === 0) return 0;
        let closed = 0;
        for (const v of pending.slice(-40)){
            const sig = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findFirst({
                where: {
                    serial: v.serial
                },
                select: {
                    status: true,
                    pnlPercent: true,
                    marginUsd: true,
                    reachedTp: true,
                    closedAt: true
                }
            });
            if (!sig) continue;
            if (!SETTLED.includes(sig.status)) continue;
            const pnlUsd = sig.marginUsd * sig.pnlPercent / 100;
            v.outcome = {
                status: sig.status,
                pnlPercent: sig.pnlPercent,
                pnlUsd: Number(pnlUsd.toFixed(3)),
                win: sig.pnlPercent > 0 || sig.reachedTp >= 1,
                closedAt: sig.closedAt?.getTime() ?? Date.now()
            };
            // TASK-40: persist the FULL verdict record, not the "o" delta — a
            // self-contained record survives ring eviction and rotation: on the next
            // boot its replay re-creates the settled verdict even if the base "v"
            // fell outside the ingested window (the old "o"-only write orphaned
            // closures whose base had been evicted → arms starved after restarts).
            // The "o" handler stays for legacy journal lines.
            void persist({
                k: "v",
                v
            });
            closed++;
        }
        return closed;
    } catch (e) {
        // Task 34-2: silent fail-open hid a 3-day arms starvation (46 unclosed
        // outcomes) — the closure loop must at least leave a forensic trace.
        console.error("[shadow-veto] closeRealOutcomes failed", e);
        return 0;
    }
}
// ── paper engine (engine-identical accounting, honest PAPER label) ──
const TTL_BY_STRATEGY = {
    "AI-SCALP": [
        60,
        120
    ],
    "MEAN-REVERT": [
        90,
        180
    ],
    MOMENTUM: [
        90,
        180
    ],
    BREAKOUT: [
        90,
        180
    ],
    "AI-SWING": [
        240,
        480
    ]
};
const RR_BASE = {
    "AI-SCALP": 2.1,
    "MEAN-REVERT": 2.4,
    MOMENTUM: 2.8,
    BREAKOUT: 3.1,
    "AI-SWING": 3.4
};
/** Base geometry for paper trades: slAtrMult × ATR stop (no regime/vol/flow
 * drivers — those are deploy-time only), levered-risk-capped leverage, base RR.
 * Direction-aware. Documented simplification: the paper arm measures
 * DIRECTIONAL edge at the fence, not perfect PnL replication. */ async function paperGeometry(symbol, direction, strategy, entryOverride) {
    const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
    const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetchKlines"])(symbol, "15m", 160).catch(()=>null);
    const snap = candles ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indicators$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["buildSnapshot"])(symbol, candles) : null;
    const entry = entryOverride ?? snap?.price ?? 0;
    if (!entry) throw new Error("no price");
    const atrPct = snap?.atrPct ?? 1.5;
    const slDistPct = Math.min(5, Math.max(0.7, gate.slAtrMult * atrPct)) / 100;
    const levRaw = Math.round(Math.min(20, Math.max(5, 60 / (slDistPct * 100))));
    const leverage = gate.leveredRiskCap > 0 && slDistPct * 100 * levRaw > gate.leveredRiskCap ? Math.max(5, Math.floor(gate.leveredRiskCap / (slDistPct * 100))) : levRaw;
    const rr = RR_BASE[strategy] ?? 2.6;
    const tp2Mult = Math.min(2.2, Math.max(1.5, 1.2 + rr * 0.22));
    const [ttlMin, ttlMax] = TTL_BY_STRATEGY[strategy] ?? [
        90,
        180
    ];
    const isLong = direction === "LONG";
    const risk = entry * slDistPct;
    const fx = (v)=>Number(v.toFixed(entry > 100 ? 2 : 6));
    return {
        entry: fx(entry),
        initialStop: fx(isLong ? entry - risk : entry + risk),
        stop: fx(isLong ? entry - risk : entry + risk),
        tp1: fx(isLong ? entry + risk : entry - risk),
        tp2: fx(isLong ? entry + risk * tp2Mult : entry - risk * tp2Mult),
        tp3: fx(isLong ? entry + risk * rr : entry - risk * rr),
        leverage,
        slDistPct,
        rr,
        ttlMinutes: Math.round(ttlMin + Math.random() * (ttlMax - ttlMin))
    };
}
function newPaperShell(id, verdict, cfg, geo) {
    return {
        id,
        verdictId: verdict.id,
        originSide: verdict.side,
        originVerdict: verdict.verdict,
        at: Date.now(),
        symbol: verdict.symbol,
        direction: verdict.direction,
        strategy: verdict.strategy,
        entry: geo.entry,
        stop: geo.stop,
        initialStop: geo.initialStop,
        tp1: geo.tp1,
        tp2: geo.tp2,
        tp3: geo.tp3,
        leverage: geo.leverage,
        marginUsd: cfg.paperMarginUsd,
        slDistPct: geo.slDistPct,
        rr: geo.rr,
        ttlMinutes: geo.ttlMinutes,
        status: "OPEN",
        reachedTp: 0,
        maxPnlPercent: 0,
        pnlPercent: 0,
        pnlUsd: 0,
        outcome: null,
        closeNote: null,
        epoch: ARM_EPOCH
    };
}
/** Open the counterfactual paper trade for a REJECT-side TRADE verdict. */ async function openPaperTrade(verdict, paperMarginUsd) {
    try {
        void paperMarginUsd;
        const cfg = await getShadowVetoConfig();
        const asset = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].marketAsset.findUnique({
            where: {
                symbol: verdict.symbol
            },
            select: {
                price: true
            }
        });
        if (!asset?.price) return;
        const geo = await paperGeometry(verdict.symbol, verdict.direction, verdict.strategy, asset.price);
        seq++;
        const paper = newPaperShell(`PP-${String(seq).padStart(4, "0")}`, verdict, cfg, geo);
        papers.push(paper);
        trimPapers();
        void persist({
            k: "p",
            v: paper
        });
    } catch  {
    /* paper must never break anything */ }
}
const movePctAt = (p, px)=>(px - p.entry) / p.entry * (p.direction === "LONG" ? 1 : -1) * 100;
function shadowPaperCount() {
    let open = 0;
    for (const p of papers)if (!p.outcome) open++;
    return open;
}
async function shadowPaperSweep(priceMap) {
    try {
        if (papers.length === 0) return 0;
        const now = Date.now();
        let closed = 0;
        for (const p of papers){
            if (p.outcome) continue;
            const price = priceMap.get(p.symbol);
            if (!price) continue;
            const isLong = p.direction === "LONG";
            const hitSl = isLong ? price <= p.stop : price >= p.stop;
            const hitTp1 = isLong ? price >= p.tp1 : price <= p.tp1;
            const hitTp2 = isLong ? price >= p.tp2 : price <= p.tp2;
            const hitTp3 = isLong ? price >= p.tp3 : price <= p.tp3;
            if (hitSl) {
                closePaper(p, "SL", movePctAt(p, p.stop), now, `stopped @ ${p.stop} (trailed)`);
                closed++;
            } else if (hitTp3) {
                p.reachedTp = 3;
                closePaper(p, "TP3", movePctAt(p, p.tp3), now, `final target ${p.rr.toFixed(1)}R secured`);
                closed++;
            } else if (hitTp2 && p.reachedTp < 2) {
                p.reachedTp = 2;
                p.status = "TP2";
                p.stop = p.tp1; // trail to TP1 — +1R locked (engine semantics)
            } else if (hitTp1 && p.reachedTp < 1) {
                p.reachedTp = Math.max(p.reachedTp, 1);
                p.status = "TP1";
                p.stop = p.entry; // breakeven trail (engine semantics)
            } else if (now > p.at + p.ttlMinutes * 60_000) {
                closePaper(p, "EXPIRED", movePctAt(p, price), now, `TTL ${p.ttlMinutes}m elapsed at mark`);
                closed++;
            }
            // track MFE
            p.maxPnlPercent = Math.max(p.maxPnlPercent, Number((movePctAt(p, price) * p.leverage).toFixed(2)));
        }
        return closed;
    } catch  {
        return 0;
    }
}
/** Tranche-aware close — identical math to the real resolver (v6.6). */ function closePaper(p, status, exitMovePct, closedAt, note) {
    const rung = (px)=>movePctAt(p, px);
    const grossPct = p.reachedTp >= 1 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ladderWeightedMove"])([
        {
            weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp1,
            movePct: rung(p.tp1)
        },
        ...p.reachedTp >= 2 ? [
            {
                weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].tp2,
                movePct: rung(p.tp2)
            }
        ] : [],
        {
            weight: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LADDER_TRANCHES"].runner,
            movePct: status === "TP3" ? rung(p.tp3) : exitMovePct
        }
    ]) : exitMovePct;
    const heldMin = Math.max(0, (closedAt - p.at) / 60_000);
    const fb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accounting$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["feeBreakdown"])(p.marginUsd, p.leverage, grossPct, heldMin);
    p.status = status;
    p.pnlPercent = Number(fb.netPct.toFixed(2));
    p.pnlUsd = Number(fb.netUsd.toFixed(3));
    p.outcome = {
        status,
        pnlPercent: p.pnlPercent,
        pnlUsd: p.pnlUsd,
        win: p.pnlPercent > 0 || p.reachedTp >= 1,
        closedAt
    };
    p.closeNote = note;
    void persist({
        k: "pc",
        v: {
            id: p.id,
            status: p.status,
            reachedTp: p.reachedTp,
            pnlPercent: p.pnlPercent,
            pnlUsd: p.pnlUsd,
            stop: p.stop,
            outcome: p.outcome,
            closeNote: note
        }
    });
}
// ── arms + promotion evidence ─────────────────────────────────
/**
 * v10.16 CAPTURE-ORIGIN PROVENANCE (audit 4-f) — is this verdict a RAW-CAL
 * capture-observe adjudication? Records created after the v10.16 stamp carry
 * the explicit `origin: "capture"` field; legacy records (born between v10.6
 * and the stamp, before the field existed) are identified by the
 * "[CAPTURE-OBSERVE]" reason suffix the observe path has appended to EVERY
 * capture adjudication since v10.6 (adjudicateCore's `tag` parameter).
 * Anything else — including un-stamped pre-v10.6 records — is fence evidence.
 */ function isCaptureOrigin(v) {
    return v.origin === "capture" || v.origin === undefined && typeof v.reason === "string" && v.reason.includes("[CAPTURE-OBSERVE]");
}
function armOf(rows) {
    const wins = rows.filter((r)=>r.win).length;
    return {
        n: rows.length,
        wins,
        netUsd: Number(rows.reduce((a, r)=>a + r.pnlUsd, 0).toFixed(2))
    };
}
/** v10.7 ARM-EPOCH COHORTS → v10.10 REGIME-ALIGNED ROLLING-30 COHORTS →
 * v10.16 FENCE-ORIGIN ONLY (audit 4-f). Each arm reports its MOST-RECENT
 * ROLLING_WINDOW (30) settled, epoch-STAMPED outcomes (any stamp — a stale row
 * ages out as 30 fresher settles slide past it). v10.16: capture-observe
 * verdicts are EXCLUDED from BOTH real arms — they adjudicate RAW-CAL deploys
 * that ran with ALL quality gates bypassed (baseMin 0, passed:true), so they
 * are observe-only instrumentation on a NON-FENCE cohort; counting them let
 * promotion evidence accrue on rows the fence never judged (contaminated
 * real-keep 19/30 live). Filtering here feeds shadowArms() → promotionEvidence
 * → COHORT-FREEZE from one honest source: n/WR/net are computed over
 * fence-origin rows only, and the existing n-minimum criteria in
 * promotionEvidence then demand a FULL fence cohort before any promotion.
 * Legacy (un-stamped) non-capture records remain in the rings for
 * audit/history and still feed the feed-diagnostics + aggregate stats, but
 * they still never vote (v10.7 hygiene preserved): a pre-v10.6 regime must
 * never outvote the live one. */ function lastSettled(rows, k) {
    return rows.filter((r)=>r.outcome).sort((a, b)=>b.outcome.closedAt - a.outcome.closedAt).slice(0, k);
}
/** v10.11 LIVE real-arm aggregates (pre-freeze overlay) — the truth the
 * COHORT-FREEZE snapshot is taken FROM and what monitoring compares against.
 * v10.16 — fence-origin only (see lastSettled doc): capture-origin verdicts
 * never enter the promotion cohorts. */ function liveRealArmAggregates() {
    // TASK-40: read from the SETTLED-EVIDENCE ARCHIVE (journal-backed), not the
    // VERDICT_CAP ring — ring trim evicts settled PASS rows first (by design),
    // which starved these aggregates after every boot. The archive mirrors the
    // full journal, so the rolling-30 cohorts are stable across restarts.
    const realPass = [
        ...settledArchive.values()
    ].filter((e)=>e.kind === "real" && e.side === "PASS" && e.epoch && !e.capture);
    return {
        keep: archiveArm(realPass.filter((e)=>e.verdict === "TRADE")),
        veto: archiveArm(realPass.filter((e)=>e.verdict === "VETO"))
    };
}
function shadowArms() {
    const live = liveRealArmAggregates();
    // v10.11 COHORT-FREEZE: once a decision-grade snapshot exists for the current
    // epoch, the REAL arms read the FROZEN aggregates (append-only, unfreezable
    // except by epoch rotation or revocation pressure) — the rolling window can
    // no longer re-sample under an open decision. Live values stay observable via
    // getShadowVetoState().armsLive.
    const frozen = cohortFreeze && cohortFreeze.epoch === ARM_EPOCH ? cohortFreeze : null;
    const realKeep = frozen ? {
        ...frozen.realKeep
    } : live.keep;
    const realVeto = frozen ? {
        ...frozen.realVeto
    } : live.veto;
    // TASK-40: paper arms also read the archive — ring trim must never shrink them
    const paperKeep = archiveArm(archivePaperRows().filter((e)=>e.originSide === "REJECT" && e.originVerdict === "TRADE"));
    const paperVeto = archiveArm(archivePaperRows().filter((e)=>e.originSide === "PASS" && e.originVerdict === "VETO"));
    const mk = (id, label, a, target)=>({
            id,
            label,
            n: a.n,
            wins: a.wins,
            winRatePct: a.n ? Number((a.wins / a.n * 100).toFixed(1)) : null,
            wilsonLB: wilsonLB(a.wins, a.n),
            netUsd: a.netUsd,
            target
        });
    return [
        mk("real-keep", "REAL · core said TRADE", realKeep, 30),
        mk("real-veto", "REAL · core said VETO (still traded)", realVeto, 30),
        mk("paper-keep", "PAPER · reject the core would trade", paperKeep, 30),
        mk("paper-veto", "PAPER · pass the core blocked", paperVeto, 30)
    ].map((r)=>({
            ...r,
            epoch: ARM_EPOCH,
            ...frozen && (r.id === "real-keep" || r.id === "real-veto") ? {
                frozenAt: frozen.frozenAt
            } : {}
        }));
}
const PATTERN_MIN_N = 8; // per side — below this a cell cannot speak
const PATTERN_MIN_SEP_PP = 15; // observed WR separation (keep − veto)
function patternVetoEvidence() {
    const cells = new Map();
    for (const e of settledArchive.values()){
        if (e.kind !== "real" || e.side !== "PASS" || !e.epoch || e.capture || !e.outcome) continue;
        if (!e.strategy || !e.direction) continue; // legacy row — pattern-inert
        const key = `${e.strategy}|${e.direction}`;
        if (!cells.has(key)) cells.set(key, {
            keep: [],
            veto: []
        });
        const cell = cells.get(key);
        const row = {
            win: e.outcome.win,
            usd: e.outcome.pnlUsd
        };
        if (e.verdict === "TRADE") cell.keep.push(row);
        else if (e.verdict === "VETO") cell.veto.push(row);
    }
    const rows = [];
    for (const [pattern, cell] of [
        ...cells.entries()
    ].sort((a, b)=>a[0].localeCompare(b[0]))){
        const nK = cell.keep.length;
        const nV = cell.veto.length;
        const wK = cell.keep.filter((r)=>r.win).length;
        const wV = cell.veto.filter((r)=>r.win).length;
        const wrK = nK ? 100 * wK / nK : null;
        const wrV = nV ? 100 * wV / nV : null;
        const netK = Number(cell.keep.reduce((a, r)=>a + r.usd, 0).toFixed(2));
        const netV = Number(cell.veto.reduce((a, r)=>a + r.usd, 0).toFixed(2));
        const ubV = wilsonUB(wV, nV);
        const okN = nK >= PATTERN_MIN_N && nV >= PATTERN_MIN_N;
        const okSep = wrK !== null && wrV !== null && wrK - wrV >= PATTERN_MIN_SEP_PP;
        const okUB = ubV !== null && wrK !== null && ubV < wrK;
        const okNet = netV < 0;
        const proven = okN && okSep && okUB && okNet;
        const f1 = (x)=>x === null ? "n/a" : `${x.toFixed(1)}%`;
        rows.push({
            pattern,
            nKeep: nK,
            wrKeep: wrK === null ? null : Number(wrK.toFixed(1)),
            netKeep: netK,
            nVeto: nV,
            wrVeto: wrV === null ? null : Number(wrV.toFixed(1)),
            netVeto: netV,
            ubVeto: ubV === null ? null : Number(ubV.toFixed(1)),
            proven,
            detail: `n veto/keep ${nV}/${nK} · wr ${f1(wrV)}/${f1(wrK)} · UB95 ${f1(ubV)} · net $${netV}/$${netK} · ${okN ? "✓n" : "✗n"}${okSep ? " ✓sep" : " ✗sep"}${okUB ? " ✓ub" : " ✗ub"}${okNet ? " ✓net" : " ✗net"}`
        });
    }
    return {
        rows,
        proven: rows.filter((r)=>r.proven).map((r)=>r.pattern)
    };
}
/** Deploy-gate lookup — the exact source the scoped authority consults. */ function provenPatternSet() {
    return new Set(patternVetoEvidence().proven);
}
const FREEZE_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "sv-cohort-freeze.json");
let cohortFreeze = null;
let cohortFreezeLoaded = false;
async function loadCohortFreeze() {
    if (cohortFreezeLoaded) return;
    cohortFreezeLoaded = true;
    try {
        const raw = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(FREEZE_FILE, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.frozenAt === "number" && typeof parsed.epoch === "string") {
            if (parsed.epoch !== ARM_EPOCH) {
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FREEZE_FILE, `${FREEZE_FILE}.prev-epoch`).catch(()=>undefined); // epoch rotation → evidence re-opens
                cohortFreeze = null;
                return;
            }
            cohortFreeze = parsed;
        }
    } catch  {
        cohortFreeze = null; // no snapshot yet — normal
    }
}
async function syncCohortFreeze() {
    try {
        await loadCohortFreeze();
        const live = liveRealArmAggregates();
        // revocation unfreeze: frozen evidence + live paper-veto pressure → re-open
        if (cohortFreeze && cohortFreeze.epoch === ARM_EPOCH) {
            const pv = archiveArm(archivePaperRows().filter((e)=>e.originSide === "PASS" && e.originVerdict === "VETO")); // TASK-40: archive-backed
            const pvLB = wilsonLB(pv.wins, pv.n);
            if (pv.n >= 15 && (pvLB ?? 0) >= 55 && pv.netUsd > 0) {
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FREEZE_FILE, `${FREEZE_FILE}.revoked-${Date.now()}`).catch(()=>undefined);
                cohortFreeze = null;
            }
            return cohortFreeze;
        }
        // creation: decision-grade evidence gate
        if (!cohortFreeze) {
            const seq = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$seq$2d$stop$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["seqStopEvaluate"])({
                wins: live.keep.wins,
                n: live.keep.n,
                netUsd: live.keep.netUsd
            }, {
                wins: live.veto.wins,
                n: live.veto.n,
                netUsd: live.veto.netUsd
            });
            const fill = live.keep.n >= ROLLING_WINDOW && live.veto.n >= ROLLING_WINDOW;
            const seqTerminal = seq.state === "PROMOTE-EARLY" || seq.state === "ABORT-EARLY";
            if (fill || seqTerminal) {
                const snapshot = {
                    epoch: ARM_EPOCH,
                    frozenAt: Date.now(),
                    reason: fill ? "FILL" : "SEQ-STOP",
                    seqState: seq.state,
                    realKeep: {
                        ...live.keep
                    },
                    realVeto: {
                        ...live.veto
                    }
                };
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
                    recursive: true
                });
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["writeFile"])(FREEZE_FILE, JSON.stringify(snapshot, null, 1), "utf8");
                cohortFreeze = snapshot;
            }
        }
        return cohortFreeze;
    } catch  {
        return cohortFreeze; // fail-open: freeze is an integrity layer, not a dependency
    }
}
function promotionEvidence(arms) {
    const realKeep = arms[0];
    const realVeto = arms[1];
    const paperVeto = arms[3];
    const both = realKeep.n >= 30 && realVeto.n >= 30;
    // v10.11 SEQ-STOP — the sequential early-decision layer (always-valid, OF
    // alpha-spending). It computes on the SAME arms the fixed gate sees (frozen
    // when a COHORT-FREEZE exists): a PROMOTE-EARLY state satisfies promotion
    // WITHOUT waiting for n=30 (min-n guard 12/arm inside), ABORT-EARLY vetoes
    // the hypothesis outright, CONTINUE leaves the fixed gate as sole path.
    const sequential = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$seq$2d$stop$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["seqStopEvaluate"])({
        wins: realKeep.wins,
        n: realKeep.n,
        netUsd: realKeep.netUsd
    }, {
        wins: realVeto.wins,
        n: realVeto.n,
        netUsd: realVeto.netUsd
    });
    const okN = (a)=>a.n >= 30 || a.n >= 20 && (a.wilsonLB ?? 0) >= 50;
    const nDetail = (role, a)=>{
        const fast = a.n >= 20 && a.n < 30 && (a.wilsonLB ?? 0) >= 50;
        return `rolling-30 ${role} cohort ${a.n}/30${a.n >= 20 && a.n < 30 ? ` (fast path n≥20 + LB≥50%: ${fast ? "MET" : "unmet — LB " + (a.wilsonLB !== null ? a.wilsonLB.toFixed(1) : "n/a") + "%"})` : ""}`;
    };
    const criteria = [
        {
            id: "n-veto",
            ok: okN(realVeto),
            detail: nDetail("would-veto", realVeto)
        },
        {
            id: "n-keep",
            ok: okN(realKeep),
            detail: nDetail("would-keep", realKeep)
        },
        {
            id: "wr-sep",
            ok: both && (realVeto.wilsonLB ?? 0) < (realKeep.wilsonLB ?? 100),
            detail: `Wilson-LB veto ${realVeto.wilsonLB !== null ? `${realVeto.wilsonLB.toFixed(1)}%` : "n/a"} < keep ${realKeep.wilsonLB !== null ? `${realKeep.wilsonLB.toFixed(1)}%` : "n/a"} (95% separation)`
        },
        {
            id: "net",
            ok: realVeto.netUsd < 0,
            detail: `would-veto cohort net $${realVeto.netUsd.toFixed(2)} (must be negative)`
        }
    ];
    const legacyReady = criteria.every((c)=>c.ok);
    const ready = legacyReady || sequential.state === "PROMOTE-EARLY";
    criteria.push({
        id: "seq-stop",
        ok: sequential.state === "PROMOTE-EARLY",
        detail: `${sequential.detail}${legacyReady ? " — legacy gate already satisfied, sequential is confirmatory" : ""}`
    });
    const revPressure = paperVeto.n >= 15 && (paperVeto.wilsonLB ?? 0) >= 55 && paperVeto.netUsd > 0;
    return {
        ready,
        criteria,
        sequential,
        revocation: {
            pressure: revPressure,
            detail: revPressure ? `blocked-pass counterfactuals are winning without the veto (n=${paperVeto.n}, LB ${paperVeto.wilsonLB.toFixed(1)}%, net $${paperVeto.netUsd.toFixed(2)}) — consider demoting to shadow` : `no revocation pressure (paper-veto n=${paperVeto.n}/15, LB ${paperVeto.wilsonLB !== null ? `${paperVeto.wilsonLB.toFixed(1)}%` : "n/a"}, net $${paperVeto.netUsd.toFixed(2)})`
        }
    };
}
// ── v9.3 AUTO-PROMOTION WATCHDOG (operator mandate ج) ─────────
// The evidence gate (promotionEvidence) was always the ONLY sanctioned path to
// mode=veto, but it required an operator/API flip AFTER the arms filled — so a
// fully-qualified evidence stack sat idle. This watchdog closes that loop:
// every engine tick batch it re-checks the promotion criteria and, the moment
// ALL of them pass (n≥30/30 settled per arm + Wilson-LB95 separation + negative
// would-veto cohort net), flips mode shadow→veto ITSELF. The criteria are
// UNCHANGED — automation removes the latency, never the evidence. Reversible:
// revocation pressure (paper-veto arm winning without the veto) is reported on
// every promotion event so the operator/governor can demote.
let lastPromoteCheckAt = 0;
let lastBacklogBlockLogAt = 0; // v10.16 — rate-limit the audited block event (30min)
async function maybeAutoPromote() {
    const cfg = await getShadowVetoConfig(true);
    if (cfg.mode === "veto") return {
        promoted: false,
        detail: "already in veto mode"
    };
    if (!cfg.autoPromote) return {
        promoted: false,
        detail: "auto-promotion disabled by config"
    };
    if (Date.now() - lastPromoteCheckAt < 5 * 60_000) return {
        promoted: false,
        detail: "throttled"
    };
    lastPromoteCheckAt = Date.now();
    await shadowVetoReady();
    await shadowVetoRefresh(0); // judge on fresh rings, never a stale bite
    await syncCohortFreeze(); // v10.11 — freeze decision-grade evidence before judging; read frozen when present
    const ev = promotionEvidence(shadowArms());
    if (!ev.ready) return {
        promoted: false,
        detail: `evidence not ready (${ev.criteria.map((c)=>`${c.id}:${c.ok ? "✓" : "✗"}`).join(" ")})`
    };
    // ── v10.16 PROMOTION BACKLOG GATE (audit 4-f) → v10.19 ACTIVE-LEAK SCOPING —
    // evidence-ready is not enough while the REAL-arm feed is under-linked.
    // v10.19: unlinkedPassStale counts ACTIVE leaks only (stale unlinked, not
    // swept-orphan, within link reach). Structural orphans (fence candidates
    // whose deploy was refused downstream — 84% of the historic backlog per the
    // 2026-09-24 forensic) and aged-out verdicts are promotion-inert; counting
    // them deadlocked this gate permanently (201 “stale” → never clearable).
    // Block >10 ACTIVE leaks, audited via the existing fireEvent pattern
    // (rate-limited — the block can persist for hours).
    const backlog = shadowPipelineDiag().unlinkedPassStale;
    if (backlog > 10) {
        const blockDetail = `SHADOW-VETO AUTO-PROMOTION BLOCKED (v10.19 backlog gate) — REAL-arm ACTIVE feed leak: ${backlog} unlinked PASS verdict(s) within link reach (> 10). Evidence could be reading an under-linked cohort; promotion deferred until retro-link drains the backlog.`;
        if (Date.now() - lastBacklogBlockLogAt > 30 * 60_000) {
            lastBacklogBlockLogAt = Date.now();
            await __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)").then((m)=>m.fireEvent(null, null, "ENGINE", "warn", blockDetail)).catch(()=>undefined);
        }
        return {
            promoted: false,
            detail: blockDetail
        };
    }
    await saveShadowVetoConfig({
        mode: "veto"
    });
    const detail = `SHADOW-VETO AUTO-PROMOTION — all evidence criteria met: ${ev.criteria.map((c)=>`${c.detail} ✓`).join(" · ")} → mode=VETO ACTIVE (real veto authority, fail-open, revocable; revocation pressure: ${ev.revocation.pressure ? "YES — monitor paper-veto arm" : "none"}).`;
    return {
        promoted: true,
        detail
    };
}
async function getShadowVetoState() {
    await shadowVetoReady();
    await shadowVetoRefresh(); // stay live across module-instance splits
    const cfg = await getShadowVetoConfig();
    await syncCohortFreeze(); // v10.11 — create/refresh the decision-grade snapshot before evidence is read
    const modelN = verdicts.filter((v)=>v.label === "MODEL").length;
    const audited = verdicts.filter((v)=>v.label === "MODEL" && v.audit !== null);
    const groundedN = audited.filter((v)=>v.audit.verdict !== "VIOLATION").length;
    const auditViolations = verdicts.filter((v)=>v.audit?.verdict === "VIOLATION").length;
    const rejectSideVerdicts = verdicts.filter((v)=>v.side === "REJECT");
    const gateAgreement = rejectSideVerdicts.filter((v)=>v.verdict === "VETO").length;
    const arms = shadowArms();
    const pv = patternVetoEvidence(); // v11.0 — the proven-performance filter's live evidence
    // v10.11 — unfrozen live view for monitoring (identical to arms when no freeze exists)
    const liveAgg = liveRealArmAggregates();
    const frozen = cohortFreeze && cohortFreeze.epoch === ARM_EPOCH ? cohortFreeze : null;
    const armsLive = frozen ? arms.map((a)=>a.id === "real-keep" ? {
            ...a,
            ...liveAgg.keep,
            winRatePct: liveAgg.keep.n ? Number((liveAgg.keep.wins / liveAgg.keep.n * 100).toFixed(1)) : null,
            wilsonLB: wilsonLB(liveAgg.keep.wins, liveAgg.keep.n),
            frozenAt: undefined
        } : a.id === "real-veto" ? {
            ...a,
            ...liveAgg.veto,
            winRatePct: liveAgg.veto.n ? Number((liveAgg.veto.wins / liveAgg.veto.n * 100).toFixed(1)) : null,
            wilsonLB: wilsonLB(liveAgg.veto.wins, liveAgg.veto.n),
            frozenAt: undefined
        } : a) : arms;
    const now = Date.now();
    while(callStamps.length && now - callStamps[0] > 3600_000)callStamps.shift();
    // v10.21.2 RECENCY TRUTH (operator finding: window-aggregated MODEL SHARE masked
    // the 401 outage — 78% share over a week-old ring while every fresh call was
    // heuristic). The dashboard shows both: window share + last-24h share + link age.
    const dayAgo = now - 86_400_000;
    const w24 = verdicts.filter((v)=>v.at >= dayAgo);
    const w24Model = w24.filter((v)=>v.label === "MODEL").length;
    const lastModelAt = verdicts.reduce((a, v)=>v.label === "MODEL" && v.at > a ? v.at : a, 0);
    const lastVerdictAt = verdicts.reduce((a, v)=>v.at > a ? v.at : a, 0);
    return {
        armEpoch: ARM_EPOCH,
        config: cfg,
        stats: {
            total: verdicts.length,
            passSide: verdicts.filter((v)=>v.side === "PASS").length,
            rejectSide: rejectSideVerdicts.length,
            vetoCount: verdicts.filter((v)=>v.verdict === "VETO").length,
            tradeCount: verdicts.filter((v)=>v.verdict === "TRADE").length,
            modelSharePct: verdicts.length ? Number((modelN / verdicts.length * 100).toFixed(1)) : null,
            modelGroundedPct: audited.length ? Number((groundedN / audited.length * 100).toFixed(1)) : null,
            avgConfidence: verdicts.length ? Number((verdicts.reduce((a, v)=>a + v.confidence, 0) / verdicts.length).toFixed(1)) : null,
            gateAgreement,
            paperOpen: papers.filter((p)=>!p.outcome).length,
            paperSettled: papers.filter((p)=>p.outcome).length,
            recent24h: {
                n: w24.length,
                modelSharePct: w24.length ? Number((w24Model / w24.length * 100).toFixed(1)) : null,
                lastModelAgeH: lastModelAt ? Number(((now - lastModelAt) / 3_600_000).toFixed(1)) : null,
                lastVerdictAgeH: lastVerdictAt ? Number(((now - lastVerdictAt) / 3_600_000).toFixed(1)) : null
            }
        },
        arms,
        armsLive,
        cohortFreeze: frozen,
        promotion: promotionEvidence(arms),
        patternVeto: {
            enabled: cfg.patternVeto === true,
            proven: pv.proven,
            rows: pv.rows
        },
        recent: [
            ...verdicts
        ].sort((a, b)=>b.at - a.at).slice(0, 14),
        paper: [
            ...papers
        ].sort((a, b)=>b.at - a.at).slice(0, 10),
        health: {
            verdicts: verdicts.length,
            papers: papers.length,
            fileKB: Math.round(persisted / 1024),
            pending: pendingCount,
            callsLastHour: callStamps.length,
            auditViolations,
            hydratedAt
        }
    };
}
async function shadowVetoForCore(maxVerdicts = 6) {
    await shadowVetoReady();
    await shadowVetoRefresh(0); // grounding consumers always see fresh rings
    const cfg = await getShadowVetoConfig();
    const arms = shadowArms();
    const pv = patternVetoEvidence();
    const promo = promotionEvidence(arms);
    const frozen = cohortFreeze && cohortFreeze.epoch === ARM_EPOCH ? cohortFreeze : null; // v10.11
    const rej = verdicts.filter((v)=>v.side === "REJECT");
    const agreement = rej.length ? Math.round(rej.filter((v)=>v.verdict === "VETO").length / rej.length * 100) : null;
    const audited = verdicts.filter((v)=>v.label === "MODEL" && v.audit !== null);
    const groundedN = audited.filter((v)=>v.audit.verdict !== "VIOLATION").length;
    const verdictFiles = verdicts.slice(-maxVerdicts).reverse().map((v)=>`${new Date(v.at).toISOString()} ${v.symbol} ${v.direction} ${v.side === "PASS" ? "hair-pass" : "fence-reject"} gap ${v.gap.toFixed(1)} → ${v.verdict} @${v.confidence}% [${v.label}${v.audit ? `·audit:${v.audit.verdict}` : ""}] ${v.reason.slice(0, 120)}${v.outcome ? ` → settled ${v.outcome.status} ${v.outcome.pnlPercent >= 0 ? "+" : ""}${v.outcome.pnlPercent}%` : ""}`);
    const narrative = [
        `SHADOW-VETO (AI-core Phase 0, mode ${cfg.mode}): ${verdicts.length} adjudications — ${verdicts.filter((v)=>v.side === "PASS").length} hair-thin passes / ${rej.length} fence rejects; ${verdicts.filter((v)=>v.verdict === "VETO").length} VETO vs ${verdicts.filter((v)=>v.verdict === "TRADE").length} TRADE; fence-reject agreement with the numeric gate ${agreement !== null ? `${agreement}%` : "n/a"}.`,
        `GROUNDING AUDIT: ${audited.length} MODEL verdicts audited number-by-number against their evidence bundles — ${groundedN} grounded, ${audited.length - groundedN} violations (violations are DISCARDED, the deterministic heuristic speaks instead; audit rate will lag legacy verdicts which predate the instrument).`,
        `A/B arms (rolling-30 settled, tag ${ARM_EPOCH}, win-rate / Wilson-LB95 / net): real-keep ${fmtArm(arms[0])} · real-veto ${fmtArm(arms[1])} · paper-keep ${fmtArm(arms[2])} · paper-veto ${fmtArm(arms[3])}. Cohorts are regime-aligned rolling-30 (v10.10 REGIME-ALIGNED SHADOW COHORTS) — legacy un-stamped regimes never vote.`,
        `Promotion to veto mode ${promo.ready ? "EVIDENCE-READY" : "not ready"} (${promo.criteria.map((c)=>`${c.id}:${c.ok ? "✓" : "✗"}`).join(" ")}). ${promo.revocation.detail}.`,
        `SEQ-STOP (v10.11 always-valid early decision): ${promo.sequential.detail}. COHORT-FREEZE: ${frozen ? `REAL arms FROZEN since ${new Date(frozen.frozenAt).toISOString()} (${frozen.reason}); live recompute is monitoring-only` : "no snapshot — evidence window still open"}.`,
        `PATTERN-VETO (v11.0 scoped authority in shadow mode): ${pv.proven.length ? `PROVEN cells [${pv.proven.join(", ")}] — fresh MODEL vetoes on these cells BLOCK deploys (paper-tracked)` : "no proven cell yet — the filter stays fail-open until a (strategy|direction) cell proves n≥8/side + 15pp sep + UB95<keep-WR + negative net"}. Per-cell cohorts: ${pv.rows.slice(0, 6).map((r)=>`${r.pattern}(${r.detail})`).join(" · ")}.`,
        "DOCTRINE: veto-only, fail-open, revocable, GROUNDED (no veto voice may rest on ungrounded reasoning). Paper arms use base geometry (slAtrMult×ATR stop, base RR) — directional-edge evidence, not PnL replication."
    ].join(" ");
    return {
        narrative,
        verdictFiles
    };
}
function fmtArm(a) {
    if (a.n === 0) return "n=0";
    return `n=${a.n} wr=${a.winRatePct}% lb=${a.wilsonLB !== null ? a.wilsonLB.toFixed(1) : "n/a"}% net=$${a.netUsd}`;
}
function shadowArmFeedDiagnostics(mode, starveMs = 12 * 3600_000) {
    const now = Date.now();
    const lastAnyVerdictAt = verdicts.reduce((a, v)=>Math.max(a, v.at), 0);
    const quietAdjudicator = lastAnyVerdictAt === 0 || now - lastAnyVerdictAt > starveMs;
    const diag = (id, feedSource, fedRows)=>{
        const lastFedAt = fedRows.reduce((a, r)=>Math.max(a, r.at), 0);
        const settledRows = fedRows.filter((r)=>r.outcome);
        const lastSettledAt = settledRows.reduce((a, r)=>Math.max(a, r.outcome.closedAt), 0);
        const neverFed = fedRows.length === 0;
        const starved = mode !== "off" && !neverFed && now - lastFedAt > starveMs;
        let starveDetail = null;
        if (neverFed) {
            starveDetail = "feed wired, awaiting first qualifying record (disagreement/fence events are rare by design)";
        } else if (starved) {
            starveDetail = quietAdjudicator ? `whole adjudicator quiet — no fence candidates in window (last verdict ${lastAnyVerdictAt ? agoShort(now - lastAnyVerdictAt) : "never"})` : `arm-specific starvation — adjudicator active (last verdict ${agoShort(now - lastAnyVerdictAt)}) but nothing entered this arm in ${agoShort(now - lastFedAt)}`;
        }
        return {
            id,
            feedSource,
            fed: fedRows.length,
            open: fedRows.length - settledRows.length,
            settled: settledRows.length,
            lastFedAt,
            lastSettledAt,
            neverFed,
            starved,
            starveDetail
        };
    };
    return [
        diag("real-keep", "hair-thin PASS → core TRADE → real serial link → real settle", verdicts.filter((v)=>v.side === "PASS" && v.verdict === "TRADE").map((v)=>({
                at: v.at,
                outcome: v.outcome
            }))),
        diag("real-veto", "hair-thin PASS → core VETO → real trade still deploys (counterfactual) → real settle", verdicts.filter((v)=>v.side === "PASS" && v.verdict === "VETO").map((v)=>({
                at: v.at,
                outcome: v.outcome
            }))),
        diag("paper-keep", "fence REJECT → core TRADE → paper ledger (would-have-won) → paper sweep", papers.filter((p)=>p.originSide === "REJECT" && p.originVerdict === "TRADE").map((p)=>({
                at: p.at,
                outcome: p.outcome
            }))),
        diag("paper-veto", "hair-thin PASS → core VETO blocks deploy → paper track (revocation pressure)", papers.filter((p)=>p.originSide === "PASS" && p.originVerdict === "VETO").map((p)=>({
                at: p.at,
                outcome: p.outcome
            })))
    ];
}
function agoShort(ms) {
    const s = Math.max(0, Math.round(ms / 1000));
    if (s < 60) return `${s}s`;
    if (s < 3600) return `${Math.round(s / 60)}m`;
    if (s < 86400) return `${Math.round(s / 3600)}h`;
    return `${Math.round(s / 86400)}d`;
}
const ARM_COMPLETION_TARGET = 30; // mirrors the promotion criteria (rolling-30 full cohort)
/**
 * Task 34-2 — ARMS COMPLETION PROBE with CROSS-PROCESS SNAPSHOT MERGE.
 * The shadow-veto state lives in per-process memory rings (VERDICT_CAP) fed
 * by the journal tail; the SENTINEL service (:3030) is the long-lived arms
 * publisher and writes .data/shadow-veto-latest.json every few minutes. A
 * freshly-restarted Next.js instance can legitimately show FEWER settled rows
 * per arm than the published snapshot (journal rotation trims old outcome
 * records). Honest merge: per arm take the LARGER evidence view of the two —
 * both derive from the same journal, and a rolling-30 cohort never shrinks
 * because a process restarted. Read-only, fail-soft.
 */ async function publishedArmsSnapshot() {
    try {
        const { readFile } = await __turbopack_context__.A("[externals]/node:fs/promises [external] (node:fs/promises, cjs, async loader)");
        const raw = await readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "shadow-veto-latest.json"), "utf8");
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed.arms)) return [];
        return parsed.arms.filter((a)=>a && typeof a.id === "string").map((a)=>({
                id: a.id,
                label: a.label ?? a.id,
                n: Number(a.n ?? 0) || 0,
                wins: 0,
                winRatePct: null,
                wilsonLB: null,
                netUsd: 0,
                target: Number(a.target ?? ARM_COMPLETION_TARGET) || ARM_COMPLETION_TARGET,
                epoch: "snapshot"
            }));
    } catch  {
        return []; // snapshot missing/unreadable — memory view alone is used
    }
}
async function shadowArmsCompletion(mode) {
    try {
        const [memoryArms, snapshotArms] = await Promise.all([
            Promise.resolve(shadowArms()),
            publishedArmsSnapshot()
        ]);
        const snapById = new Map(snapshotArms.map((a)=>[
                a.id,
                a
            ]));
        const merged = memoryArms.map((a)=>{
            const snap = snapById.get(a.id);
            return snap && snap.n > a.n ? {
                ...a,
                n: snap.n,
                target: Math.max(a.target, snap.target)
            } : a;
        });
        // an arm present ONLY in the snapshot (defensive — id set evolution)
        for (const snap of snapshotArms){
            if (!merged.some((a)=>a.id === snap.id)) merged.push(snap);
        }
        const rows = merged.map((a)=>{
            // paper-veto arm feeds only when the adjudicator BLOCKS a deploy —
            // structurally impossible in shadow mode (fail-open observe-only)
            const waived = a.id === "paper-veto" && mode === "shadow";
            const target = Math.max(a.target || ARM_COMPLETION_TARGET, 1);
            return {
                id: a.id,
                label: a.label,
                n: a.n,
                target,
                fillPct: Math.min(100, Math.round(a.n / target * 100)),
                complete: a.n >= target,
                waived
            };
        });
        const active = rows.filter((r)=>!r.waived);
        const allComplete = active.length > 0 && active.every((r)=>r.complete);
        const pendingDeficit = active.reduce((sum, r)=>sum + Math.max(0, r.target - r.n), 0);
        const note = allComplete ? "all real shadow-veto arms complete — capture bar may lift" : `real arms incomplete (${active.filter((r)=>!r.complete).map((r)=>`${r.id} ${r.n}/${r.target}`).join(", ")}) — AI CALIBRATION bar stays active (operator mandate 2026-09-26)`;
        return {
            arms: rows,
            allComplete,
            pendingDeficit,
            note
        };
    } catch  {
        // fail-open with HONEST unknown: never claim completion we cannot prove
        return {
            arms: [],
            allComplete: false,
            pendingDeficit: 0,
            note: "arms probe unavailable — treated as INCOMPLETE (fail-closed for the capture bar)"
        };
    }
}
function shadowPipelineDiag() {
    const now = Date.now();
    const d24 = now - 24 * 3600_000;
    const REACH_MS = 7 * 24 * 3600_000 + 90 * 60_000; // retro-link query reach (7d bound + 90min pre-warm margin)
    const unlinked = verdicts.filter((v)=>v.side === "PASS" && v.serial === null);
    return {
        unlinkedPass24h: unlinked.filter((v)=>now - v.at <= 24 * 3600_000).length,
        // v10.19 — ACTIVE leak = stale, unlinked, NOT swept-orphan, still within
        // link reach. Structural orphans and aged-out verdicts are counted
        // separately so the promotion backlog gate measures UNDER-LINKING (fixable
        // evidence loss), not the inherent orphan rate of fence adjudication
        // (2026-09-24 forensic: 235 orphans vs 44 true leaks in the stale backlog).
        unlinkedPassStale: unlinked.filter((v)=>now - v.at > 24 * 3600_000 && v.sweptAt === undefined && now - v.at <= REACH_MS).length,
        unlinkedPassOrphan: unlinked.filter((v)=>v.sweptAt !== undefined).length,
        unlinkedPassAged: unlinked.filter((v)=>now - v.at > 24 * 3600_000 && v.sweptAt === undefined && now - v.at > REACH_MS).length,
        pendingRealOutcomes: verdicts.filter((v)=>v.serial !== null && v.outcome === null).length,
        pendingPapers: papers.filter((p)=>!p.outcome).length,
        lastVerdictAt: verdicts.reduce((a, v)=>Math.max(a, v.at), 0),
        lastPaperOpenAt: papers.reduce((a, p)=>Math.max(a, p.at), 0),
        verdicts24h: verdicts.filter((v)=>v.at >= d24).length,
        papers24h: papers.filter((p)=>p.at >= d24).length
    };
}
async function resetShadowEvidence() {
    await shadowVetoReady();
    verdicts.length = 0;
    papers.length = 0;
    settledArchive.clear(); // TASK-40: archive is evidence — reset it with the rings
    verdictCache.clear();
    lastAdjAt.clear();
    callStamps.length = 0;
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old.${Date.now()}`).catch(()=>undefined);
        persisted = 0;
    } catch  {
    /* non-fatal */ }
}
}),
"[project]/src/lib/stableflow.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BOARD_FRESH_MS",
    ()=>BOARD_FRESH_MS,
    "DATA_DIR",
    ()=>DATA_DIR,
    "DEPEG_MUTE_PCT",
    ()=>DEPEG_MUTE_PCT,
    "DEPEG_WARN_PCT",
    ()=>DEPEG_WARN_PCT,
    "MINTBURN_USD",
    ()=>MINTBURN_USD,
    "REGIME_OFF_PCT",
    ()=>REGIME_OFF_PCT,
    "REGIME_ON_PCT",
    ()=>REGIME_ON_PCT,
    "depegMuted",
    ()=>depegMuted,
    "getStableBoard",
    ()=>getStableBoard,
    "getStableBoardSync",
    ()=>getStableBoardSync,
    "isBoardFresh",
    ()=>isBoardFresh,
    "maybePersistStableFlow",
    ()=>maybePersistStableFlow,
    "parseBoard",
    ()=>parseBoard,
    "readRecentStableEvents",
    ()=>readRecentStableEvents,
    "stableRegimeVerdict",
    ()=>stableRegimeVerdict
]);
// ── NEXUS//SIGNALS — v11.0 STABLECOIN FLOW LIB (server-only) ────────────────
// Family-E substrate shared by: engine gates (DEPEG-MUTE / STABLE-REGIME),
// shadow-veto telemetry, /api/stableflow, and the TG digest.
//
// SOURCE OF TRUTH: the stable-feed mini-service (:3017) polls DefiLlama
// (free, no key, no AI — IRAN-VPS compatible) and atomically writes
//   .data/stable-feed/board.json        — the live regime board
//   .data/stable-feed/events.jsonl      — MINTBURN / DEPEG / REGIME events
//   .data/stable-feed/backfill/*.json   — daily history (~9y, backtest substrate)
// The app NEVER talks to DefiLlama and NEVER blocks on the service: reads are
// file-only, cached 10s, and every failure degrades to null (fail-open with
// honest nulls — gates stay silent when the substrate is absent).
//
// DB doctrine: mini-services never write SQLite. maybePersistStableFlow()
// (called from the engine tick rail, 15min throttle) mirrors LIVE snapshots
// and events into StableFlowEvent via Prisma — deduped by watermark query.
//
// Doctrines encoded here:
//   · DEPEG-MUTE — |pegDev| ≥ 1% on ANY tracked stable = systemic liquidity
//     emergency → refuse new deploys fail-closed (tail-risk protection,
//     near-zero false-positive cost; the USDC-May2023 class of event).
//   · STABLE-REGIME — SHADOW ONLY: a RISK-OFF contraction is journaled as a
//     would-block so the shadow arms can ground-truth it; enforcement is a
//     separate operator decision (EngineSetting "stableflow.regimeGate").
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
;
;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "stable-feed");
const BOARD_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "board.json");
const EVENTS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "events.jsonl");
const DEPEG_MUTE_PCT = 1.0; // systemic emergency — enforced
const DEPEG_WARN_PCT = 0.5; // event-level only
const REGIME_ON_PCT = 0.5; // 7d total-supply growth = risk-on
const REGIME_OFF_PCT = -0.5; // 7d total-supply contraction = risk-off
const MINTBURN_USD = 150e6; // |Δ24h| per asset worth an event row
const BOARD_FRESH_MS = 40 * 60_000; // board older than this = stale
function parseBoard(raw) {
    if (!raw) return null;
    try {
        const b = JSON.parse(raw);
        if (typeof b?.at !== "number" || !Array.isArray(b?.assets)) return null;
        return b;
    } catch  {
        return null;
    }
}
function isBoardFresh(b) {
    return !!b && Date.now() - b.at < BOARD_FRESH_MS;
}
function depegMuted(b) {
    if (!b) return {
        muted: false,
        reason: "no stable board"
    };
    const worst = b.assets.map((a)=>({
            asset: a.asset,
            dev: a.pegDevPct
        })).filter((x)=>x.dev !== null && Math.abs(x.dev) >= DEPEG_MUTE_PCT).sort((x, y)=>Math.abs(y.dev) - Math.abs(x.dev))[0];
    if (!worst) return {
        muted: false,
        reason: "peg ok"
    };
    return {
        muted: true,
        reason: `${worst.asset} peg deviation ${worst.dev >= 0 ? "+" : ""}${worst.dev.toFixed(2)}% (≥ ±${DEPEG_MUTE_PCT}%) — systemic stablecoin liquidity emergency`
    };
}
function stableRegimeVerdict(b, direction) {
    if (b.regime === "RISK-OFF") {
        return {
            flag: direction === "LONG",
            note: `stable regime RISK-OFF (${b.regimeReason}) — LONG deploys are the flagged cohort`
        };
    }
    if (b.regime === "RISK-ON" && direction === "SHORT") {
        return {
            flag: false,
            note: `stable regime RISK-ON (${b.regimeReason}) — SHORT telemetry-only`
        };
    }
    return {
        flag: false,
        note: `stable regime ${b.regime}`
    };
}
// ── cached board reader (file-only, 10s TTL, fail-open) ─────────────────────
let boardCache = {
    at: 0,
    board: null
};
function getStableBoardSync() {
    if (Date.now() - boardCache.at < 10_000) return boardCache.board;
    let board = null;
    try {
        board = parseBoard((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BOARD_FILE, "utf8"));
    } catch  {
        board = null; // service absent / not booted yet — honest null
    }
    boardCache = {
        at: Date.now(),
        board
    };
    return board;
}
async function getStableBoard() {
    return getStableBoardSync();
}
function readRecentStableEvents(limit = 50) {
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(EVENTS_FILE, "utf8").trim();
        if (!raw) return [];
        const lines = raw.split("\n").slice(-limit);
        const out = [];
        for (const l of lines){
            try {
                out.push(JSON.parse(l));
            } catch  {
            /* skip torn line */ }
        }
        return out;
    } catch  {
        return [];
    }
}
// ── DB persistence (app-side; Prisma owns writes) ───────────────────────────
// Mirrors the service's board + recent events into StableFlowEvent. Watermark
// = MAX(ts) per source, so restarts never duplicate rows. Honest-null: any
// failure returns a quiet {ok:false} — never breaks the engine tick.
const PERSIST_MIN_MS = 15 * 60_000;
let lastPersistAt = 0;
let persisting = null;
async function maybePersistStableFlow(force = false) {
    if (!force && Date.now() - lastPersistAt < PERSIST_MIN_MS) return {
        ok: true,
        detail: "throttled"
    };
    if (persisting) return persisting;
    persisting = (async ()=>{
        try {
            const board = getStableBoardSync();
            if (!board || !isBoardFresh(board)) return {
                ok: false,
                detail: "no fresh board"
            };
            // watermark: newest LIVE snapshot ts already persisted
            const wm = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].stableFlowEvent.findFirst({
                where: {
                    source: "LIVE",
                    kind: "SNAPSHOT"
                },
                orderBy: {
                    ts: "desc"
                },
                select: {
                    ts: true
                }
            });
            const wmMs = wm?.ts ? new Date(wm.ts).getTime() : 0;
            if (board.at <= wmMs) return {
                ok: true,
                detail: "board already persisted"
            };
            const rows = [];
            const pct = (v)=>v === null ? null : Math.round(v * 1000) / 1000;
            // exact USD delta from a % move: Δ = mcap × (1 − 1/(1+pct/100))
            const usdFromPct = (mcap, p)=>mcap !== null && p !== null ? Math.round(mcap * (1 - 1 / (1 + p / 100))) : undefined;
            for (const a of board.assets){
                rows.push({
                    ts: new Date(board.at),
                    source: "LIVE",
                    kind: "SNAPSHOT",
                    asset: a.asset,
                    mcapUsd: a.mcapUsd ?? undefined,
                    delta1hUsd: usdFromPct(a.mcapUsd, a.delta1hPct),
                    delta24hUsd: a.delta24hUsd ?? usdFromPct(a.mcapUsd, a.delta24hPct),
                    delta7dUsd: usdFromPct(a.mcapUsd, a.delta7dPct),
                    pegDevPct: pct(a.pegDevPct) ?? undefined
                });
            }
            rows.push({
                ts: new Date(board.at),
                source: "LIVE",
                kind: "SNAPSHOT",
                asset: "TOTAL",
                mcapUsd: board.totalMcapUsd ?? undefined,
                delta24hUsd: usdFromPct(board.totalMcapUsd, board.totalDelta24hPct),
                delta7dUsd: usdFromPct(board.totalMcapUsd, board.totalDelta7dPct),
                regime: board.regime,
                note: board.regimeReason
            });
            // NOTE: Prisma 6 SQLite has no skipDuplicates — the watermark above is
            // the dedup guarantee (single app process + wmMs guard make this safe).
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].stableFlowEvent.createMany({
                data: rows
            });
            // events since the watermark — mirrored with kind preserved
            const evs = readRecentStableEvents(30).filter((e)=>e.ts > wmMs && e.ts <= Date.now());
            if (evs.length > 0) {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].stableFlowEvent.createMany({
                    data: evs.map((e)=>({
                            ts: new Date(e.ts),
                            source: "LIVE",
                            kind: e.kind,
                            asset: e.asset,
                            note: e.text.slice(0, 240)
                        }))
                });
            }
            lastPersistAt = Date.now();
            return {
                ok: true,
                detail: `persisted ${rows.length} snapshots + ${evs.length} events (wm ${new Date(wmMs).toISOString()})`
            };
        } catch (e) {
            return {
                ok: false,
                detail: String(e).slice(0, 120)
            };
        } finally{
            persisting = null;
        }
    })();
    return persisting;
}
}),
"[project]/src/lib/sv-telemetry.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "captureSvTelemetry",
    ()=>captureSvTelemetry,
    "ensureFreshSvTelemetry",
    ()=>ensureFreshSvTelemetry,
    "getSvTelemetry",
    ()=>getSvTelemetry,
    "svTelemetryNarrative",
    ()=>svTelemetryNarrative
]);
// ── FlowRadar Neo v10.2 SV-TELEMETRY HUB (server-only) ──────────
// Operator mandate 2026-09-15: «عملکرد و وضعیت Shadow veto را پیگیری کن تا
// داده‌های مورد نیاز به تمام بازوها سیم‌کشی و ارسال شود و بصورت جیسون فایل
// ذخیره و قابل بازیابی و استفاده باشد»
//
// One consolidated, versioned JSON document that tracks the shadow-veto
// subsystem end-to-end and is written to disk so EVERY consumer can retrieve
// and use it:
//   · per-arm feed wiring audit (real-keep / real-veto / paper-keep /
//     paper-veto): who feeds each arm, last fed/settled, starvation flags
//   · pipeline leak counters (real-link leaks, closure backlog, sweep state)
//   · wiring checks (adjudicator / real-link / closure / sweep / LLM)
//   · A/B arms + promotion evidence + config + health (live rings)
//   · history ring (compact samples, 24h) + alert ring with push delivery
//
// Storage: .data/shadow-veto-telemetry.json — atomic writes (tmp+rename),
// bounded size, survives rotation. Retrieval: GET /api/ai/shadow-veto/
// telemetry (serve or download) or read the file directly. Freshness: the
// engine tick calls captureSvTelemetry() every tick (self-throttled 10min),
// GET calls ensureFreshSvTelemetry() (15min staleness budget), POST forces.
//
// Push path: new alerts are fired to the operator relay + engine event tape
// (per-alert 6h cooldown) — data is not only stored, it is SENT. Fail-open
// everywhere: telemetry must never throw into the engine tick.
//
// NOTE (parallel-agent merge 2026-09-15): a second agent briefly shipped an
// overlapping tracker module and retired it to keep ONE capture pipeline.
// THIS module is the canonical SV telemetry surface — do not add a second
// snapshot builder; extend this one.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stableflow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/stableflow.ts [app-route] (ecmascript)"); // v11.0 family-E substrate
;
;
;
;
// ── storage ───────────────────────────────────────────────────
const TEL_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const TEL_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(TEL_DIR, "shadow-veto-telemetry.json");
const HISTORY_CAP = 144; // 24h at 10min cadence
const ALERT_CAP = 24;
const CAPTURE_MIN_INTERVAL_MS = 10 * 60_000;
const PUSH_COOLDOWN_MS = 6 * 3600_000;
let lastCaptureAt = 0;
let capturing = null;
let cached = null;
let writes = 0;
function agoShort(ms) {
    const s = Math.max(0, Math.round(ms / 1000));
    if (s < 60) return `${s}s`;
    if (s < 3600) return `${Math.round(s / 60)}m`;
    if (s < 86400) return `${Math.round(s / 3600)}h`;
    return `${Math.round(s / 86400)}d`;
}
async function readStore() {
    try {
        const buf = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(TEL_FILE, "utf8");
        const parsed = JSON.parse(buf);
        if (parsed && parsed.schemaVersion === 1) return parsed;
        return null;
    } catch  {
        return null;
    }
}
async function writeStore(snap) {
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(TEL_DIR, {
            recursive: true
        });
        // v10.6.1 persist-guard (operator APPROVE): serialize snapshot writes and
        // stamp the monotonic watermark so a stale module generation can never
        // regress the snapshot with an older derived view.
        const { persistWatermark, serializePersist } = await __turbopack_context__.A("[project]/src/lib/persist-guard.ts [app-route] (ecmascript, async loader)");
        await serializePersist("sv-telemetry", async ()=>{
            const tmp = `${TEL_FILE}.tmp`;
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["writeFile"])(tmp, JSON.stringify(snap), "utf8");
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(tmp, TEL_FILE); // atomic — readers never see a torn file
            await persistWatermark("sv-telemetry");
            writes++;
        });
    } catch  {
    /* non-fatal — telemetry must never break the engine */ }
}
// ── arm merge: live arm numbers × feed diagnostics ────────────
function mergeArms(arms, feeds) {
    const byId = new Map(feeds.map((f)=>[
            f.id,
            f
        ]));
    return arms.map((a)=>{
        const f = byId.get(a.id);
        return {
            id: a.id,
            label: a.label,
            feedSource: f?.feedSource ?? "n/a",
            n: a.n,
            target: a.target,
            fillPct: Math.min(100, Number((a.n / a.target * 100).toFixed(1))),
            wins: a.wins,
            winRatePct: a.winRatePct,
            wilsonLB: a.wilsonLB,
            netUsd: a.netUsd,
            fed: f?.fed ?? 0,
            open: f?.open ?? 0,
            settled: f?.settled ?? 0,
            lastFedAt: f?.lastFedAt ?? 0,
            lastSettledAt: f?.lastSettledAt ?? 0,
            neverFed: f?.neverFed ?? true,
            starved: f?.starved ?? false,
            starveDetail: f?.starveDetail ?? null
        };
    });
}
// ── alert evaluation (delta vs previous snapshot) ─────────────
function evaluateAlerts(prev, next) {
    const now = Date.now();
    const prevById = new Map((prev?.alerts ?? []).map((a)=>[
            a.id,
            a
        ]));
    const out = [];
    const push = (id, level, text)=>{
        const p = prevById.get(id);
        // re-arm only after the cooldown; unchanged alerts keep their original at
        if (p && now - p.at < PUSH_COOLDOWN_MS) {
            out.push(p);
            return;
        }
        out.push({
            id,
            at: now,
            level,
            text,
            delivered: false
        });
    };
    if (next.mode !== "off") {
        // arm starvation — only for arms that HAVE been fed before (never-fed is
        // the wired-but-idle state, not a fault; it is visible, not pushed)
        for (const a of next.arms){
            if (a.starved) {
                push(`arm-starve:${a.id}`, "warn", `SHADOW-VETO arm feed starved — ${a.id} (${a.label}): nothing new for ${agoShort(now - a.lastFedAt)} while adjudicator active. ${a.starveDetail ?? ""}`);
            }
            // never-fed REAL arms while adjudication is flowing deserve one info
            if (a.neverFed && a.id.startsWith("real") && next.wiring.pipeline.verdicts24h > 0) {
                push(`arm-idle:${a.id}`, "info", `SHADOW-VETO arm idle — ${a.id} never fed, yet ${next.wiring.pipeline.verdicts24h} verdicts in 24h. Feed is wired; qualifying records (fence events) just have not occurred.`);
            }
        }
        // REAL-arm link leak — v10.19: ACTIVE leaks only (stale unlinked, not swept
        // orphan, within reach). Orphans/aged are structural, promotion-inert.
        const prevStale = prev?.wiring.pipeline.unlinkedPassStale ?? 0;
        if (next.wiring.pipeline.unlinkedPassStale > prevStale) {
            push("link-leak", "warn", `SHADOW-VETO REAL-arm ACTIVE link leak — ${next.wiring.pipeline.unlinkedPassStale} unlinked PASS verdict(s) within link reach (was ${prevStale}). Evidence may be under-linked; retro-link sweep + orphan stamping (v10.19) keep this count honest.`);
        }
        // closure backlog — linked verdicts waiting for the settlement sweep
        if (next.wiring.pipeline.pendingRealOutcomes > 5) {
            push("closure-backlog", "warn", `SHADOW-VETO closure backlog — ${next.wiring.pipeline.pendingRealOutcomes} linked verdicts awaiting outcome closure (sweep closes 40/round every 40 ticks).`);
        }
    }
    // promotion readiness edge — announced once per transition
    if (next.promotion.ready && prev && !prev.promotion.ready) {
        push("promotion-ready", "info", "SHADOW-VETO promotion evidence gate now READY (arms filled with Wilson-LB separation + negative would-veto net). Auto-promotion watchdog will flip mode=veto on its next check.");
    }
    // keep recent prev alerts this capture no longer re-evaluates (ring continuity)
    for (const a of prev?.alerts ?? []){
        if (!out.some((x)=>x.id === a.id) && now - a.at < 24 * 3600_000) out.push(a);
    }
    return out.sort((a, b)=>b.at - a.at).slice(0, ALERT_CAP);
}
async function deliverNewAlerts(alerts) {
    const fresh = alerts.filter((a)=>!a.delivered);
    if (fresh.length === 0) return;
    for (const a of fresh){
        a.delivered = true; // mark first — delivery is best-effort, never retried into spam
        try {
            const [engine, notify] = await Promise.all([
                __turbopack_context__.A("[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)"),
                __turbopack_context__.A("[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)")
            ]);
            void engine.fireEvent(null, null, "SYSTEM", a.level === "warn" ? "warn" : "info", a.text).catch(()=>undefined);
            await notify.sendDirect(a.text).catch(()=>undefined);
        } catch  {
        /* push is best-effort */ }
    }
}
async function captureSvTelemetry(force = false) {
    if (!force && Date.now() - lastCaptureAt < CAPTURE_MIN_INTERVAL_MS) return cached ?? await readStore();
    if (capturing) return capturing;
    capturing = (async ()=>{
        const t0 = Date.now();
        try {
            const s = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getShadowVetoState"])(); // refreshes rings + config (cached) — no direct DB hits here
            const pipeline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["shadowPipelineDiag"])();
            const feeds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["shadowArmFeedDiagnostics"])(s.config.mode);
            const arms = mergeArms(s.arms, feeds);
            const llmMod = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)").catch(()=>null);
            const llm = llmMod ? llmMod.llmHealth() : {
                cooling: false,
                cooldownRemainsMs: 0,
                consecutive429: 0,
                lastOkAt: null
            };
            const lastVerdictAgo = pipeline.lastVerdictAt ? Date.now() - pipeline.lastVerdictAt : Infinity;
            const wiring = {
                adjudicator: {
                    ok: pipeline.lastVerdictAt === 0 || lastVerdictAgo < 24 * 3600_000,
                    detail: pipeline.lastVerdictAt === 0 ? "no adjudications yet (wired, awaiting first fence candidate)" : `last verdict ${agoShort(lastVerdictAgo)} · budget ${s.health.callsLastHour}/${s.config.budgetPerHour}·h · pending ${s.health.pending}`
                },
                realLink: {
                    ok: pipeline.unlinkedPassStale === 0,
                    detail: pipeline.unlinkedPassStale === 0 ? `link integrity OK — ${pipeline.unlinkedPass24h} recent within reach · ${pipeline.unlinkedPassOrphan} swept orphan(s) · ${pipeline.unlinkedPassAged} aged out (v10.19)` : `${pipeline.unlinkedPassStale} ACTIVE link leak(s) — stale unlinked PASS verdict(s) with reachable deploys (orphans swept: ${pipeline.unlinkedPassOrphan} · aged out: ${pipeline.unlinkedPassAged})`
                },
                outcomeClosure: {
                    ok: pipeline.pendingRealOutcomes <= 5,
                    detail: `${pipeline.pendingRealOutcomes} linked verdict(s) awaiting settlement closure (sweep every 40 ticks, batch 40)`
                },
                paperSweep: {
                    ok: true,
                    detail: `${pipeline.pendingPapers} paper position(s) open · ${s.stats.paperSettled} settled · last paper opened ${pipeline.lastPaperOpenAt ? agoShort(Date.now() - pipeline.lastPaperOpenAt) : "never"}`
                },
                llm: {
                    ok: !llm.cooling,
                    cooling: llm.cooling,
                    consecutive429: llm.consecutive429,
                    detail: llm.cooling ? `429 budget shield active ${Math.ceil(llm.cooldownRemainsMs / 1000)}s (MODEL verdicts parked, heuristic speaks)` : llm.consecutive429 > 0 ? `link recovering (×${llm.consecutive429} 429s)` : "LLM link healthy"
                },
                pipeline
            };
            const prev = cached ?? await readStore();
            const alerts = evaluateAlerts(prev, {
                ...emptyShell(),
                mode: s.config.mode,
                arms,
                promotion: s.promotion,
                wiring
            });
            // history sample — replace near-duplicate (multi-instance double capture)
            const hist = (prev?.history ?? []).filter((h)=>t0 - h.t > 5 * 60_000);
            hist.push({
                t: t0,
                mode: s.config.mode,
                verdicts: s.health.verdicts,
                papers: s.health.papers,
                arms: arms.map((a)=>({
                        id: a.id,
                        n: a.n,
                        netUsd: a.netUsd,
                        winRatePct: a.winRatePct
                    }))
            });
            const snap = {
                schemaVersion: 1,
                capturedAt: t0,
                captureMs: Date.now() - t0,
                mode: s.config.mode,
                config: s.config,
                // v11.0 family-E: stablecoin regime board (stable-feed :3017 → file
                // read, cached). Honest null when the substrate hasn't booted yet.
                stable: (()=>{
                    try {
                        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stableflow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getStableBoardSync"])();
                    } catch  {
                        return null;
                    }
                })(),
                stats: s.stats,
                arms,
                wiring,
                promotion: s.promotion,
                health: s.health,
                store: {
                    file: ".data/shadow-veto-telemetry.json",
                    fileKB: 0,
                    historySamples: hist.length,
                    lastCaptureAt: t0,
                    writes: writes + 1
                },
                alerts: alerts.slice(0, ALERT_CAP),
                history: hist.slice(-HISTORY_CAP)
            };
            snap.store.fileKB = Math.round(JSON.stringify(snap).length / 1024);
            await writeStore(snap);
            cached = snap;
            lastCaptureAt = t0;
            void deliverNewAlerts(snap.alerts).catch(()=>undefined); // push path — fire and forget
            return snap;
        } catch  {
            return null; // telemetry must never break the engine tick
        } finally{
            capturing = null;
        }
    })();
    return capturing;
}
function emptyShell() {
    // minimal shape so evaluateAlerts can be called before the full snapshot exists
    return {
        schemaVersion: 1,
        capturedAt: 0,
        captureMs: 0,
        mode: "shadow",
        config: {},
        stable: null,
        stats: {
            total: 0,
            passSide: 0,
            rejectSide: 0,
            vetoCount: 0,
            tradeCount: 0,
            modelSharePct: null,
            modelGroundedPct: null,
            avgConfidence: null,
            gateAgreement: 0,
            paperOpen: 0,
            paperSettled: 0,
            recent24h: {
                n: 0,
                modelSharePct: null,
                lastModelAgeH: null,
                lastVerdictAgeH: null
            }
        },
        arms: [],
        wiring: {
            adjudicator: {
                ok: true,
                detail: ""
            },
            realLink: {
                ok: true,
                detail: ""
            },
            outcomeClosure: {
                ok: true,
                detail: ""
            },
            paperSweep: {
                ok: true,
                detail: ""
            },
            llm: {
                ok: true,
                cooling: false,
                consecutive429: 0,
                detail: ""
            },
            pipeline: {
                unlinkedPass24h: 0,
                unlinkedPassStale: 0,
                unlinkedPassOrphan: 0,
                unlinkedPassAged: 0,
                pendingRealOutcomes: 0,
                pendingPapers: 0,
                lastVerdictAt: 0,
                lastPaperOpenAt: 0,
                verdicts24h: 0,
                papers24h: 0
            }
        },
        promotion: {
            ready: false,
            criteria: [],
            revocation: {
                pressure: false,
                detail: ""
            },
            sequential: {
                state: "CONTINUE",
                z: null,
                boundary: null,
                infoFrac: null,
                alphaSpent: null,
                dPct: null,
                minNMet: false,
                detail: "",
                checkedAt: 0
            }
        },
        health: {
            verdicts: 0,
            papers: 0,
            fileKB: 0,
            pending: 0,
            callsLastHour: 0,
            auditViolations: 0,
            hydratedAt: 0
        },
        store: {
            file: TEL_FILE,
            fileKB: 0,
            historySamples: 0,
            lastCaptureAt: 0,
            writes: 0
        },
        alerts: [],
        history: []
    };
}
async function getSvTelemetry() {
    if (cached && cached.capturedAt >= lastCaptureAt) {
        const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(TEL_FILE).catch(()=>null);
        if (st && st.mtimeMs <= cached.capturedAt + 5_000) return cached;
    }
    const fromDisk = await readStore();
    if (fromDisk) cached = fromDisk;
    return fromDisk;
}
async function ensureFreshSvTelemetry() {
    const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(TEL_FILE).catch(()=>null);
    if (!st) return captureSvTelemetry(true);
    if (Date.now() - st.mtimeMs > 15 * 60_000) return await captureSvTelemetry(false) ?? getSvTelemetry();
    return getSvTelemetry();
}
async function svTelemetryNarrative() {
    const snap = await ensureFreshSvTelemetry();
    if (!snap) return "SV-TELEMETRY: unavailable this cycle.";
    const armsLine = snap.arms.map((a)=>`${a.id} ${a.n}/${a.target}${a.neverFed ? " (idle)" : a.starved ? " STARVED" : ` fed ${agoShort(Date.now() - a.lastFedAt)} ago`}`).join(" · ");
    const wires = [
        snap.wiring.adjudicator,
        snap.wiring.realLink,
        snap.wiring.outcomeClosure,
        snap.wiring.paperSweep
    ];
    const bad = wires.filter((w)=>!w.ok).length;
    const openAlerts = snap.alerts.filter((a)=>Date.now() - a.at < PUSH_COOLDOWN_MS).length;
    return `SV-TELEMETRY: wiring ${bad === 0 ? "ALL-OK" : `${bad} check(s) failing`} · ${armsLine} · alerts open ${openAlerts} · snapshot ${agoShort(Date.now() - snap.capturedAt)} ago (.data/shadow-veto-telemetry.json v${snap.schemaVersion}).`;
}
}),
"[project]/src/app/api/ai/shadow-veto/telemetry/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sv-telemetry.ts [app-route] (ecmascript)");
;
;
const dynamic = "force-dynamic";
async function GET(req) {
    try {
        const url = new URL(req.url);
        const download = url.searchParams.get("download") === "1";
        const withHistory = url.searchParams.get("history") === "1";
        const raw = url.searchParams.get("raw") === "1";
        const snap = raw ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getSvTelemetry"])() : await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureFreshSvTelemetry"])();
        if (!snap) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "telemetry store empty — first capture pending (engine tick or POST {force:true} creates it)"
            }, {
                status: 503
            });
        }
        const payload = withHistory || download ? snap : {
            ...snap,
            history: []
        };
        if (download) {
            const d = new Date(snap.capturedAt).toISOString().slice(0, 10);
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](JSON.stringify(payload, null, 2), {
                headers: {
                    "Content-Type": "application/json; charset=utf-8",
                    "Content-Disposition": `attachment; filename="shadow-veto-telemetry-${d}.json"`,
                    "Cache-Control": "no-store"
                }
            });
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(payload, {
            headers: {
                "Cache-Control": "no-store"
            }
        });
    } catch (err) {
        console.error("[sv-telemetry] GET error", err);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "sv-telemetry retrieval failure"
        }, {
            status: 500
        });
    }
}
async function POST(req) {
    try {
        const body = await req.json().catch(()=>({}));
        const snap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["captureSvTelemetry"])(body.force === true);
        if (!snap) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            error: "capture failed — see server log"
        }, {
            status: 500
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: true,
            snapshot: snap
        }, {
            headers: {
                "Cache-Control": "no-store"
            }
        });
    } catch (err) {
        console.error("[sv-telemetry] POST error", err);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            error: "sv-telemetry capture failure"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__30cafb84._.js.map