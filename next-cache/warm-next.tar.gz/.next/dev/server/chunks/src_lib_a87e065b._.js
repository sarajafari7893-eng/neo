module.exports = [
"[project]/src/lib/gate-journal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "gateJournalForCore",
    ()=>gateJournalForCore,
    "gateJournalHealth",
    ()=>gateJournalHealth,
    "gateJournalReady",
    ()=>gateJournalReady,
    "gateJournalRefresh",
    ()=>gateJournalRefresh,
    "gateLive",
    ()=>gateLive,
    "gateRecentBlocks",
    ()=>gateRecentBlocks,
    "gateRecentDeploys",
    ()=>gateRecentDeploys,
    "gateStats",
    ()=>gateStats,
    "recordGateBlock",
    ()=>recordGateBlock,
    "recordGateDeploy",
    ()=>recordGateDeploy,
    "recordGateSamples",
    ()=>recordGateSamples
]);
// ── FlowRadar Neo GATE JOURNAL + GAUGE ENGINE (server-only, v8.2) ──
// Operator mandate (2026-09-08): «یک موتور گیج اضافه کن تا بصورت زنده داده
// هایی که به مرز تایید یا رد شدن سیگنال میرسند را نشان دهد و جورنال را به
// هسته مرکزی برای یادگیری عمیق از دلایل ارسال کند».
//
// Every deploy-signal() threshold verdict is journaled here with its FULL
// reason payload: the signed confluence votes (confirm vs oppose), every
// threshold modifier (regime / BTC-spill / chase / MTF-board / liq-heat),
// the effective threshold it faced, and the distance-to-gate. Hard gate
// blocks (memory/strategy/learned/flow/onset-retest/risk-cluster) and
// actual deployments are recorded too — so the boundary band between
// CONFIRM and REJECT becomes a measurable, learnable dataset instead of
// a one-line 409 error.
//
// Storage: in-memory rings (fast, capped) + append-only JSONL
// (.data/gate-journal.jsonl) so history survives dev recompiles and
// restarts, and the central AI core can be fed the exact same records.
// No SQLite writes — the single-writer discipline stays untouched.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
;
;
// ── storage ───────────────────────────────────────────────────
const SAMPLE_CAP = 8000;
const BLOCK_CAP = 800;
const DEPLOY_CAP = 300;
const BOUNDARY_DEDUP_MS = 60_000; // per symbol|direction — boundary state persists tick after tick
const REJECT_DEDUP_MS = 150_000;
const PASS_DEDUP_MS = 60_000; // PASS verdicts change slowly too — keep the ring dense with boundary data
const BLOCK_DEDUP_MS = 120_000;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "gate-journal.jsonl");
const FILE_MAX_BYTES = 8 * 1024 * 1024;
const samples = [];
const blocks = [];
const deploys = [];
const lastAccepted = new Map();
let persisted = 0;
let hydrating = null;
// v8.2.1 SPLIT-BRAIN COUNTERMEASURE — Turbopack dev compiles one module
// instance PER ROUTE: the engine tick's instance writes the JSONL while a
// freshly-compiled read route starts with EMPTY rings and (before this fix)
// never hydrated, because hydration was only triggered from write paths.
// readPos tracks how many bytes of the JSONL this instance has already
// ingested, so reads can TAIL the file incrementally no matter which
// instance is doing the writing (including our own — persist() advances
// readPos so records we wrote ourselves are never re-ingested).
let readPos = 0;
let hydratedAt = 0; // epoch ms of the last successful hydrate/refresh — 0 = cold rings
let refreshing = null;
let lastRefreshAt = 0;
const REFRESH_MIN_INTERVAL_MS = 10_000;
const REFRESH_MAX_BITE = 512 * 1024; // bounded bite per refresh
const seenSerials = new Set(); // deploy serials ingested (hydrate + refresh) — cross-instance deploy dedupe
async function hydrate() {
    if (hydrating) return hydrating;
    hydrating = (async ()=>{
        try {
            const buf = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(FILE, "utf8").catch(()=>"");
            if (!buf) return;
            const lines = buf.split("\n").filter(Boolean);
            const tail = lines.slice(-6000); // bounded restore
            for (const line of tail){
                try {
                    const rec = JSON.parse(line);
                    if (rec.k === "s" && samples.length < SAMPLE_CAP) samples.push(rec.v);
                    else if (rec.k === "b" && blocks.length < BLOCK_CAP) blocks.push(rec.v);
                    else if (rec.k === "d" && deploys.length < DEPLOY_CAP) deploys.push(rec.v);
                } catch  {
                /* skip torn line */ }
            }
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            persisted = st?.size ?? 0;
            // the whole file has been consumed (tail kept) — mark the read position
            readPos = st?.size ?? 0;
            hydratedAt = Date.now();
            // prime the dedup map from the hydrated history so a freshly-compiled
            // instance does not instantly re-accept everything another instance
            // journaled seconds ago (dedup continuity across instance swaps)
            for (const s of samples){
                const key = `${s.symbol}|${s.direction}|${s.band}`;
                const prev = lastAccepted.get(key) ?? 0;
                if (s.at > prev) lastAccepted.set(key, s.at);
            }
            for (const b of blocks){
                const key = `${b.gate}|${b.symbol ?? "*"}`;
                const prev = lastAccepted.get(key) ?? 0;
                if (b.at > prev) lastAccepted.set(key, b.at);
            }
            for (const d of deploys)if (d.serial > 0) seenSerials.add(d.serial);
            if ((st?.size ?? 0) > FILE_MAX_BYTES) {
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
                persisted = 0; // (was a stale-size bug: rotation must reset the counter)
                readPos = 0;
            }
        } catch  {
        /* fresh start — journaling must never break the engine */ }
    })();
    return hydrating;
}
async function persist(rec) {
    try {
        const line = JSON.stringify(rec) + "\n";
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(FILE, line, "utf8");
        persisted += line.length;
        readPos += line.length; // our own bytes are already in the rings — never re-ingest
        if (persisted > FILE_MAX_BYTES) {
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
            persisted = 0;
            readPos = 0;
        }
    } catch  {
    /* non-fatal */ }
}
async function gateJournalReady() {
    await hydrate();
    try {
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
            recursive: true
        });
    } catch  {
    /* exists */ }
}
async function gateJournalRefresh(maxAgeMs = REFRESH_MIN_INTERVAL_MS) {
    if (Date.now() - lastRefreshAt < maxAgeMs) return;
    if (refreshing) return refreshing;
    refreshing = (async ()=>{
        try {
            // VERDICT-CORE audit 2026-11-05 — COLD-GENERATION READ FIX: hydrate() only
            // ran on WRITE paths, so a freshly-compiled read generation started with
            // readPos=0 and tailed the file's OLDEST bytes (11-03 history) — 12h-window
            // stats came back EMPTY and the core wrote "journal is empty" (observed live
            // on cycle #1412's first POST). Hydrate cold generations here (once, single-
            // flight, readPos=file-size) so the first refresh already sees the freshest
            // 6000-line history. Warm generations (hydratedAt>0) are untouched — re-running
            // hydrate on them would re-push tail records into the rings.
            if (hydratedAt === 0) await hydrate();
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            if (!st) return;
            if (st.size < readPos) readPos = 0; // rotated — restart the tail on the fresh file
            if (st.size === readPos) return;
            const len = Math.min(st.size - readPos, REFRESH_MAX_BITE);
            const fh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(FILE, "r").catch(()=>null);
            if (!fh) return;
            try {
                const buf = Buffer.alloc(len);
                const { bytesRead } = await fh.read(buf, 0, len, readPos);
                let text = buf.toString("utf8", 0, bytesRead);
                const lastNl = text.lastIndexOf("\n");
                if (lastNl === -1) return; // partial line at the tail — wait for the writer
                text = text.slice(0, lastNl + 1); // only consume COMPLETE lines
                readPos += Buffer.byteLength(text, "utf8");
                for (const line of text.split("\n")){
                    if (!line) continue;
                    try {
                        const rec = JSON.parse(line);
                        if (rec.k === "s") {
                            const s = rec.v;
                            // v8.2.1 ingest discipline — a SECOND module instance may write the
                            // same verdict; apply the exact same dedup rule as recordGateSamples
                            // so rings/stats stay honest no matter the writer
                            const key = `${s.symbol}|${s.direction}|${s.band}`;
                            const interval = s.band === "BOUNDARY" ? BOUNDARY_DEDUP_MS : s.band === "REJECT" ? REJECT_DEDUP_MS : PASS_DEDUP_MS;
                            const last = lastAccepted.get(key) ?? 0;
                            if (interval && s.at - last < interval) continue;
                            lastAccepted.set(key, s.at);
                            samples.push(s);
                            if (samples.length > SAMPLE_CAP) samples.splice(0, samples.length - SAMPLE_CAP);
                        } else if (rec.k === "b") {
                            const b = rec.v;
                            const key = `${b.gate}|${b.symbol ?? "*"}`;
                            if (b.at - (lastAccepted.get(key) ?? 0) < BLOCK_DEDUP_MS) continue;
                            lastAccepted.set(key, b.at);
                            blocks.push(b);
                            if (blocks.length > BLOCK_CAP) blocks.splice(0, blocks.length - BLOCK_CAP);
                        } else if (rec.k === "d") {
                            const d = rec.v;
                            if (d.serial > 0 && seenSerials.has(d.serial)) continue; // duplicate deploy from another instance
                            if (d.serial > 0) seenSerials.add(d.serial);
                            deploys.push(d);
                            if (deploys.length > DEPLOY_CAP) deploys.splice(0, deploys.length - DEPLOY_CAP);
                        }
                    } catch  {
                    /* torn line */ }
                }
                hydratedAt = Date.now();
            } finally{
                await fh.close().catch(()=>undefined);
            }
        } catch  {
        /* non-fatal — reads must never break */ } finally{
            lastRefreshAt = Date.now();
        }
    })().finally(()=>{
        refreshing = null;
    });
    return refreshing;
}
// ── recording ─────────────────────────────────────────────────
function bandOf(gap, passed) {
    if (passed) return "PASS";
    return gap >= -8 ? "BOUNDARY" : "REJECT";
}
async function recordGateSamples(batch) {
    if (batch.length === 0) return;
    await hydrate();
    const now = Date.now();
    let bestGap = Infinity;
    let bestIdx = -1;
    const enriched = batch.map((b, i)=>{
        const gap = Math.abs(b.score) - b.effMin;
        if (Math.abs(gap) < bestGap) {
            bestGap = Math.abs(gap);
            bestIdx = i;
        }
        return {
            ...b,
            at: now,
            gap,
            band: bandOf(gap, b.passed)
        };
    });
    for(let i = 0; i < enriched.length; i++){
        const s = enriched[i];
        const key = `${s.symbol}|${s.direction}|${s.band}`;
        const interval = s.band === "BOUNDARY" ? BOUNDARY_DEDUP_MS : s.band === "REJECT" ? REJECT_DEDUP_MS : PASS_DEDUP_MS;
        const last = lastAccepted.get(key) ?? 0;
        if (interval && now - last < interval) continue;
        lastAccepted.set(key, now);
        const rec = {
            at: s.at,
            symbol: s.symbol,
            direction: s.direction,
            strategy: s.strategy,
            score: s.score,
            effMin: s.effMin,
            baseMin: s.baseMin,
            gap: s.gap,
            band: s.band,
            thr: s.thr,
            confirms: s.confirms,
            opposes: s.opposes,
            notes: s.notes,
            source: s.source,
            best: i === bestIdx
        };
        samples.push(rec);
        if (samples.length > SAMPLE_CAP) samples.splice(0, samples.length - SAMPLE_CAP);
        void persist({
            k: "s",
            v: rec
        });
    }
}
async function recordGateBlock(b) {
    await hydrate();
    const now = Date.now();
    const key = `${b.gate}|${b.symbol ?? "*"}`;
    if (now - (lastAccepted.get(key) ?? 0) < BLOCK_DEDUP_MS) return;
    lastAccepted.set(key, now);
    const rec = {
        ...b,
        at: now
    };
    blocks.push(rec);
    if (blocks.length > BLOCK_CAP) blocks.splice(0, blocks.length - BLOCK_CAP);
    void persist({
        k: "b",
        v: rec
    });
}
async function recordGateDeploy(d) {
    await hydrate();
    const rec = {
        ...d,
        at: Date.now()
    };
    deploys.push(rec);
    if (deploys.length > DEPLOY_CAP) deploys.splice(0, deploys.length - DEPLOY_CAP);
    void persist({
        k: "d",
        v: rec
    });
}
function gateLive(limit = 16) {
    const latest = new Map();
    for (const s of samples)latest.set(`${s.symbol}|${s.direction}`, s); // rings are append-ordered
    const rank = (b)=>b === "BOUNDARY" ? 0 : b === "PASS" ? 1 : 2;
    return [
        ...latest.values()
    ].sort((a, b)=>rank(a.band) - rank(b.band) || Math.abs(a.gap) - Math.abs(b.gap)).slice(0, limit);
}
function gateStats(windowHours = 6) {
    const since = Date.now() - windowHours * 3600_000;
    const win = samples.filter((s)=>s.at >= since);
    const byBand = {
        PASS: 0,
        BOUNDARY: 0,
        REJECT: 0
    };
    for (const s of win)byBand[s.band]++;
    const agg = (list, pick)=>{
        const m = new Map();
        for (const s of list)for (const f of pick(s)){
            const e = m.get(f.factor) ?? {
                n: 0,
                sum: 0,
                last: null
            };
            e.n++;
            e.sum += f.vote;
            if (f.detail) e.last = f.detail;
            m.set(f.factor, e);
        }
        return m;
    };
    const toAgg = (m)=>[
            ...m.entries()
        ].map(([factor, e])=>({
                factor,
                count: e.n,
                avgVote: Number((e.sum / e.n).toFixed(2)),
                lastDetail: e.last
            })).sort((a, b)=>b.count - a.count);
    const confirmAgg = toAgg(agg(win, (s)=>s.confirms));
    const opposeAgg = toAgg(agg(win, (s)=>s.opposes));
    const thrNames = [
        "regime",
        "spill",
        "chase",
        "mtf",
        "liq",
        "lesson"
    ];
    const thrModifiers = thrNames.map((name)=>{
        const vals = win.map((s)=>s.thr[name]).filter((v)=>v !== undefined && v !== 0);
        return {
            name,
            count: vals.length,
            avg: vals.length ? Number((vals.reduce((a, b)=>a + b, 0) / vals.length).toFixed(2)) : 0
        };
    }).filter((t)=>t.count > 0);
    const blockMap = new Map();
    for (const b of blocks){
        if (b.at < since) continue;
        const e = blockMap.get(b.gate) ?? {
            count: 0,
            lastReason: b.reason
        };
        e.count++;
        e.lastReason = b.reason;
        blockMap.set(b.gate, e);
    }
    const deploysWin = deploys.filter((d)=>d.at >= since);
    const boundaryN = byBand.BOUNDARY;
    return {
        windowHours,
        samples: win.length,
        byBand,
        boundary: boundaryN > 0 ? {
            avgGap: Number((win.filter((s)=>s.band === "BOUNDARY").reduce((a, s)=>a + s.gap, 0) / boundaryN).toFixed(2)),
            worstGap: Math.max(...win.filter((s)=>s.band === "BOUNDARY").map((s)=>s.gap)),
            sharePct: Number((boundaryN / Math.max(1, win.length) * 100).toFixed(1))
        } : null,
        confirmReasons: confirmAgg.slice(0, 6),
        opposeReasons: opposeAgg.slice(0, 6),
        thrModifiers,
        blocks: [
            ...blockMap.entries()
        ].map(([gate, e])=>({
                gate,
                count: e.count,
                lastReason: e.lastReason
            })).sort((a, b)=>b.count - a.count),
        deploys: deploysWin.length,
        avgDeployScore: deploysWin.length ? Number((deploysWin.reduce((a, d)=>a + Math.abs(d.score), 0) / deploysWin.length).toFixed(1)) : null,
        blocksRingSize: blocks.length,
        blocksRingSaturated: blocks.length >= BLOCK_CAP
    };
}
function gateRecentBlocks(limit = 8) {
    return blocks.slice(-limit).reverse();
}
function gateRecentDeploys(limit = 6) {
    return deploys.slice(-limit).reverse();
}
function gateJournalHealth() {
    return {
        samples: samples.length,
        blocks: blocks.length,
        deploys: deploys.length,
        fileKB: Math.round(persisted / 1024),
        hydratedAt
    };
}
async function gateJournalForCore(windowHours = 12, maxBoundary = 8) {
    await gateJournalReady(); // hydrate cold generations BEFORE tailing (audit 2026-11-05: read-path emptiness fix)
    await gateJournalRefresh(0); // grounding consumers always see fresh rings
    const stats = gateStats(windowHours);
    const nearGate = samples.filter((s)=>s.at >= Date.now() - windowHours * 3600_000 && s.band === "BOUNDARY").sort((a, b)=>b.at - a.at).slice(0, maxBoundary);
    const boundaryFiles = nearGate.map((s)=>{
        const conf = s.confirms.map((f)=>`${f.factor}${f.vote >= 0 ? "+" : ""}${f.vote}`).join(",") || "n/a";
        const opp = s.opposes.map((f)=>`${f.factor}${f.vote >= 0 ? "+" : ""}${f.vote}`).join(",") || "n/a";
        const thr = Object.entries(s.thr).filter(([, v])=>v !== 0).map(([k, v])=>`${k}${v > 0 ? "+" : ""}${v}`).join(" ") || "none";
        return `${new Date(s.at).toISOString()} ${s.symbol} ${s.direction} ${s.strategy} score ${s.score.toFixed(1)} vs eff ${s.effMin} (gap ${s.gap >= 0 ? "+" : ""}${s.gap.toFixed(1)}) · thr mods: ${thr} · confirms: ${conf} · opposes: ${opp}`;
    });
    const blockFiles = gateRecentBlocks(6).map((b)=>`${new Date(b.at).toISOString()} ${b.gate}${b.symbol ? ` ${b.symbol}` : ""} — ${b.reason.slice(0, 140)}`);
    const topConfirm = stats.confirmReasons[0];
    const topOppose = stats.opposeReasons[0];
    const narrative = [
        `${stats.samples} threshold verdicts in ${windowHours}h: ${stats.byBand.PASS} passed, ${stats.byBand.BOUNDARY} landed in the boundary band (gap −8..0, ${stats.boundary?.sharePct ?? 0}% of evaluations, avg gap ${stats.boundary?.avgGap ?? "n/a"}), ${stats.byBand.REJECT} rejected outright.`,
        `Dominant confirm factor: ${topConfirm ? `${topConfirm.factor} (×${topConfirm.count}, avg ${topConfirm.avgVote})` : "n/a"}. Dominant oppose factor: ${topOppose ? `${topOppose.factor} (×${topOppose.count}, avg ${topOppose.avgVote})` : "n/a"}.`,
        `Threshold modifiers live: ${stats.thrModifiers.map((t)=>`${t.name}×${t.count} avg ${t.avg >= 0 ? "+" : ""}${t.avg}`).join(" · ") || "none"}.`,
        `Hard blocks: ${stats.blocks.map((b)=>`${b.gate}×${b.count}`).join(" · ") || "none"}.${stats.blocksRingSaturated ? ` [BLOCK-RING SATURATED at ${stats.blocksRingSize} — these counts are the newest ~${stats.blocksRingSize} accepted records only (≈60-90min of churn), NOT the full ${windowHours}h census; single-key gates (MEMORY) are dedup-compressed while multi-symbol gates (REGIME) fan out — treat as recent-churn snapshot]` : ""} Deployed: ${stats.deploys}${stats.avgDeployScore !== null ? ` (avg |score| ${stats.avgDeployScore})` : ""}.`
    ].join(" ");
    return {
        narrative,
        stats,
        boundaryFiles,
        blockFiles,
        boundarySamples: nearGate
    };
}
}),
"[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fourpackNarrative",
    ()=>fourpackNarrative,
    "fourpackRefresh",
    ()=>fourpackRefresh,
    "getFourPackDoc",
    ()=>getFourPackDoc,
    "getFourPackTail",
    ()=>getFourPackTail,
    "recordFourPack",
    ()=>recordFourPack
]);
// ── FlowRadar Neo v10.8 — FOUR-PACK GOVERNANCE JOURNAL (server-only) ────────
// Operator mandate (2026-09-15/16): the GOVERNOR MODULES FOUR-PACK (R1
// RISK-GOVERNOR · R2 TIME-GOVERNOR · R5 UI-CANARY · R6 SENIOR-REVIEW) keeps
// its verdicts as small in-memory rings buried inside each module's own
// EngineSetting blob. This module gives the pack ONE retrievable, auditable
// JSON journal doctrine — the same discipline the gate-journal (v8.2) and
// sv-telemetry (v10.2) already follow:
//   · append-only JSONL  .data/fourpack-journal.jsonl  (6MB rotate → .old)
//   · atomic latest-file .data/fourpack-latest.json    (tmp→rename)
//   · in-memory ring (fast reads) + tail-ingest hydration so Turbopack's
//     per-route module split-brain never shows a stale journal.
// Supervision verdict (delivered to operator): the four modules are
// deterministic, shadow-first, clamped and audited — they do NOT need a new
// autonomous agent/central-intelligence control loop on top. What they needed
// is THIS: a machine-readable doctrine file the central AI core (verdict-core
// / tp3-lab grounding) and the operator (download) can both study.
//
// Dependency-free (node:fs only) — the module writers call recordFourPack();
// read routes call fourpackRefresh() then getFourPackTail()/getFourPackDoc().
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
;
;
const RING_CAP = 600;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data");
const FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "fourpack-journal.jsonl");
const FILE_MAX_BYTES = 6 * 1024 * 1024;
const LATEST = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(DATA_DIR, "fourpack-latest.json");
const ring = [];
let persisted = 0;
let readPos = 0;
let hydratedAt = 0;
let hydrating = null;
let refreshing = null;
let lastRefreshAt = 0;
const REFRESH_MIN_INTERVAL_MS = 10_000;
const REFRESH_MAX_BITE = 256 * 1024;
const MODULES = [
    "r1-risk-governor",
    "r2-time-governor",
    "r5-ui-canary",
    "r6-senior-review",
    "ops-supervisor",
    "mode"
];
async function hydrate() {
    if (hydrating) return hydrating;
    hydrating = (async ()=>{
        try {
            const buf = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(FILE, "utf8").catch(()=>"");
            if (buf) {
                const lines = buf.split("\n").filter(Boolean);
                for (const line of lines.slice(-RING_CAP)){
                    try {
                        const rec = JSON.parse(line);
                        if (rec?.v?.at && ring.length < RING_CAP) ring.push(rec.v);
                    } catch  {
                    /* torn line */ }
                }
            }
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            persisted = st?.size ?? 0;
            readPos = st?.size ?? 0;
            hydratedAt = Date.now();
            if ((st?.size ?? 0) > FILE_MAX_BYTES) {
                await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
                persisted = 0;
                readPos = 0;
            }
        } catch  {
        /* fresh start — journaling must never break the engine */ }
    })();
    return hydrating;
}
async function fourpackRefresh(maxAgeMs = REFRESH_MIN_INTERVAL_MS) {
    await hydrate();
    if (Date.now() - lastRefreshAt < maxAgeMs) return;
    if (refreshing) return refreshing;
    refreshing = (async ()=>{
        try {
            const st = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["stat"])(FILE).catch(()=>null);
            if (!st) return;
            if (st.size < readPos) readPos = 0; // rotated
            if (st.size === readPos) return;
            const len = Math.min(st.size - readPos, REFRESH_MAX_BITE);
            const fh = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["open"])(FILE, "r").catch(()=>null);
            if (!fh) return;
            try {
                const buf = Buffer.alloc(len);
                const { bytesRead } = await fh.read(buf, 0, len, readPos);
                let text = buf.toString("utf8", 0, bytesRead);
                const lastNl = text.lastIndexOf("\n");
                if (lastNl === -1) return;
                text = text.slice(0, lastNl + 1);
                readPos += Buffer.byteLength(text, "utf8");
                for (const line of text.split("\n")){
                    if (!line) continue;
                    try {
                        const rec = JSON.parse(line);
                        if (rec?.v?.at) {
                            ring.push(rec.v);
                            if (ring.length > RING_CAP) ring.splice(0, ring.length - RING_CAP);
                        }
                    } catch  {
                    /* torn line */ }
                }
                hydratedAt = Date.now();
            } finally{
                await fh.close().catch(()=>undefined);
            }
        } catch  {
        /* non-fatal */ } finally{
            lastRefreshAt = Date.now();
        }
    })().finally(()=>{
        refreshing = null;
    });
    return refreshing;
}
function health() {
    const counts = {};
    const lastAt = {};
    for (const m of MODULES){
        counts[m] = 0;
        lastAt[m] = 0;
    }
    for (const e of ring){
        counts[e.module] = (counts[e.module] ?? 0) + 1;
        if (e.at > (lastAt[e.module] ?? 0)) lastAt[e.module] = e.at;
    }
    return {
        counts,
        lastAt,
        fileBytes: persisted,
        rotated: false
    };
}
async function writeLatest() {
    try {
        const last = {};
        for (const m of MODULES){
            const evs = ring.filter((e)=>e.module === m);
            last[m] = evs.length ? evs[evs.length - 1] : null;
        }
        const doc = {
            schemaVersion: 1,
            at: Date.now(),
            health: health(),
            last
        };
        const tmp = `${LATEST}.tmp`;
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["writeFile"])(tmp, JSON.stringify(doc), "utf8");
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(tmp, LATEST).catch(async ()=>{
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(LATEST, "").catch(()=>undefined);
        });
    } catch  {
    /* non-fatal */ }
}
async function recordFourPack(module, kind, line, data, verdict) {
    try {
        await hydrate();
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["mkdir"])(DATA_DIR, {
            recursive: true
        }).catch(()=>undefined);
        const ev = {
            at: Date.now(),
            module,
            kind,
            verdict: verdict ?? null,
            line: line.slice(0, 400),
            data
        };
        ring.push(ev);
        if (ring.length > RING_CAP) ring.splice(0, ring.length - RING_CAP);
        const rec = JSON.stringify({
            k: module,
            v: ev
        }) + "\n";
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["appendFile"])(FILE, rec, "utf8");
        persisted += rec.length;
        readPos += rec.length; // our own bytes — never re-ingest
        if (persisted > FILE_MAX_BYTES) {
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["rename"])(FILE, `${FILE}.old`).catch(()=>undefined);
            persisted = 0;
            readPos = 0;
        }
        void writeLatest();
    } catch  {
    /* journaling must never break a governor cycle */ }
}
async function getFourPackTail(limit = 60) {
    await fourpackRefresh();
    return ring.slice(-limit).reverse();
}
async function getFourPackDoc(limit = 500) {
    await fourpackRefresh();
    return {
        schemaVersion: 1,
        generatedAt: new Date().toISOString(),
        health: health(),
        events: ring.slice(-limit).reverse()
    };
}
async function fourpackNarrative() {
    await fourpackRefresh();
    if (!ring.length) return "FOUR-PACK: journal empty — governor modules have not cycled yet this boot.";
    const parts = [];
    for (const m of [
        "r1-risk-governor",
        "r2-time-governor",
        "r5-ui-canary",
        "r6-senior-review"
    ]){
        const last = [
            ...ring
        ].reverse().find((e)=>e.module === m);
        if (last) {
            const ago = Math.round((Date.now() - last.at) / 60_000);
            parts.push(`${m}:${last.kind}${last.verdict ? `=${last.verdict}` : ""} (${ago}m ago) ${last.line}`);
        } else {
            parts.push(`${m}: no journal event yet`);
        }
    }
    return `FOUR-PACK JOURNAL (${ring.length} events): ${parts.join(" | ")}`;
}
}),
"[project]/src/lib/tp3-lab.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildTp3Lab",
    ()=>buildTp3Lab,
    "getDeepLearnState",
    ()=>getDeepLearnState,
    "maybeAutoDeepLearn",
    ()=>maybeAutoDeepLearn,
    "runDeepLearnCycle",
    ()=>runDeepLearnCycle
]);
// ── FlowRadar Neo TP3 DEEP-LAB + DEEP-LEARN LOOP (server-only, v5.4) ──
// Operator request: full-TP (TP3) signals get their OWN calculator with a
// deeper learning cycle, and both full-TP + stopped-out signals go through an
// LLM research Q&A ("why did this win big / why did this die?"). The resulting
// lessons are persisted, broadcast to the event feed, injected into every AI
// agent's grounding (chat / governor / card briefs), and audited in EngineSetting.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
// v8.2 GATE GAUGE — the central core studies the LIVE confirm/reject ledger
// (boundary-band verdicts + hard blocks with their full reason payload)
// alongside the terminal outcomes, so lessons attribute RESULTS to REASONS.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-journal.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sv-telemetry.ts [app-route] (ecmascript)"); // v10.2 — the core studies its own feed wiring
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — the core studies the GOVERNOR FOUR-PACK journal
;
;
;
;
;
function tagList(s) {
    return (s.tags ?? "").split(",").filter(Boolean);
}
function topN(counter, n) {
    return [
        ...counter.entries()
    ].sort((a, b)=>b[1] - a[1]).slice(0, n);
}
/** Parse the regime tag out of the deployment tags (REGIME-*). */ function regimeOf(tags) {
    return tags.find((t)=>t.startsWith("REGIME-")) ?? null;
}
/** Case-file mapper — module scope so both buildTp3Lab and runDeepLearnCycle share it. */ function toCase(s) {
    let votes = null;
    if (s.factorsJson) {
        try {
            const parsed = JSON.parse(s.factorsJson);
            votes = parsed.map((v)=>({
                    factor: String(v.factor ?? "?"),
                    vote: Number(v.vote ?? 0)
                }));
        } catch  {
            votes = null;
        }
    }
    let flowVerdict = null;
    let flowScore = null;
    if (s.flowJson) {
        try {
            const f = JSON.parse(s.flowJson);
            flowVerdict = f.verdict ?? null;
            flowScore = typeof f.score === "number" ? f.score : null;
        } catch  {
        /* keep nulls */ }
    }
    const tags = tagList(s);
    return {
        serial: s.serial,
        symbol: s.symbol,
        direction: s.direction,
        strategy: s.strategy,
        outcome: s.status === "TP3" ? "TP3_FULL" : "SL",
        confidence: s.confidence,
        riskReward: s.riskReward,
        timeframe: s.timeframe,
        holdMinutes: s.closedAt && s.createdAt ? Math.round((s.closedAt.getTime() - s.createdAt.getTime()) / 60_000) : 0,
        reachedTp: s.reachedTp,
        maxPnlPercent: s.maxPnlPercent,
        netPnlPercent: s.pnlPercent,
        flowVerdict,
        flowScore,
        regimeTag: regimeOf(tags),
        tags,
        factorVotes: votes,
        occurredAt: (s.closedAt ?? s.createdAt).toISOString()
    };
}
async function buildTp3Lab(windowDays = 14) {
    const since = new Date(Date.now() - windowDays * 24 * 3600_000);
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP3",
                    "SL"
                ]
            },
            closedAt: {
                gte: since
            }
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 120
    });
    const full = rows.filter((s)=>s.status === "TP3");
    const stopped = rows.filter((s)=>s.status === "SL");
    const cases = rows.map(toCase);
    const fullCases = cases.filter((c)=>c.outcome === "TP3_FULL");
    const stoppedCases = cases.filter((c)=>c.outcome === "SL");
    const countTags = (list)=>{
        const m = new Map();
        for (const c of list)for (const t of c.tags)if (!t.startsWith("REGIME-")) m.set(t, (m.get(t) ?? 0) + 1);
        return topN(m, 4);
    };
    const countStrategy = (list)=>{
        const m = {};
        for (const c of list)m[c.strategy] = (m[c.strategy] ?? 0) + 1;
        return m;
    };
    const countSymbols = (list)=>{
        const m = new Map();
        for (const c of list)m.set(c.symbol, (m.get(c.symbol) ?? 0) + 1);
        return topN(m, 4);
    };
    const avg = (nums)=>nums.length ? nums.reduce((a, b)=>a + b, 0) / nums.length : 0;
    const fullTp = {
        count: fullCases.length,
        ratePct: rows.length ? Number((fullCases.length / rows.length * 100).toFixed(1)) : 0,
        avgConfidence: Math.round(avg(fullCases.map((c)=>c.confidence))),
        avgRr: Number(avg(fullCases.map((c)=>c.riskReward)).toFixed(2)),
        avgHoldMin: Math.round(avg(fullCases.map((c)=>c.holdMinutes))),
        flowConfirmShare: fullCases.length ? Number((fullCases.filter((c)=>c.flowVerdict === "CONFIRMS").length / fullCases.length * 100).toFixed(0)) : 0,
        topTags: countTags(fullCases),
        topSymbols: countSymbols(fullCases),
        byStrategy: countStrategy(fullCases)
    };
    const stoppedStats = {
        count: stoppedCases.length,
        avgConfidence: Math.round(avg(stoppedCases.map((c)=>c.confidence))),
        avgHoldMin: Math.round(avg(stoppedCases.map((c)=>c.holdMinutes))),
        flowConflictShare: stoppedCases.length ? Number((stoppedCases.filter((c)=>c.flowVerdict === "CONFLICTS").length / stoppedCases.length * 100).toFixed(0)) : 0,
        topTags: countTags(stoppedCases),
        byStrategy: countStrategy(stoppedCases)
    };
    const confDelta = fullTp.avgConfidence - stoppedStats.avgConfidence;
    const rrDelta = Number((fullTp.avgRr - avg(stoppedCases.map((c)=>c.riskReward))).toFixed(2));
    const contrast = {
        confDelta,
        rrDelta,
        note: fullCases.length && stoppedCases.length ? `full-TP winners deployed at ${confDelta >= 0 ? "+" : ""}${confDelta} conviction vs stop-outs, with ${rrDelta >= 0 ? "+" : ""}${rrDelta} wider targets — winners ran ${fullTp.avgHoldMin}m avg vs ${stoppedStats.avgHoldMin}m for losers` : "not enough TP3/SL pairs in the window for a contrast read"
    };
    return {
        windowDays,
        fullTp,
        stopped: stoppedStats,
        contrast,
        recentCases: cases.slice(0, 10)
    };
}
const RING_CAP = 12;
const PERSIST_KEY = "deep-learn";
const MIN_INTERVAL_MS = 30 * 60_000; // autonomous cycle every ~30min
const state = {
    lastRunAt: null,
    runs: 0,
    casesLearned: 0,
    lessons: [],
    lastQuestion: null,
    lastAnswer: null,
    label: "IDLE"
};
let restored = false;
async function persistState() {
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
            where: {
                key: PERSIST_KEY
            },
            create: {
                key: PERSIST_KEY,
                value: JSON.stringify(state)
            },
            update: {
                value: JSON.stringify(state)
            }
        });
    } catch  {
    /* non-fatal */ }
}
async function getDeepLearnState() {
    await restoreState();
    return {
        ...state
    };
}
async function restoreState() {
    if (restored) return;
    restored = true;
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: PERSIST_KEY
            }
        });
        if (!row) return;
        const v = JSON.parse(row.value);
        if ((v.runs ?? 0) > state.runs) {
            state.lastRunAt = v.lastRunAt ?? null;
            state.runs = v.runs ?? 0;
            state.casesLearned = v.casesLearned ?? 0;
            state.lessons = v.lessons ?? [];
            state.lastQuestion = v.lastQuestion ?? null;
            state.lastAnswer = v.lastAnswer ?? null;
            state.label = v.label ?? "IDLE";
        }
    } catch  {
    /* fresh start */ }
}
/** Compact, audit-grade case file — the ONLY facts the LLM may reason over. */ function caseFile(c) {
    const flow = c.flowVerdict ? `${c.flowVerdict} ${c.flowScore !== null ? `${c.flowScore >= 0 ? "+" : ""}${c.flowScore}/25` : ""}` : "n/a";
    const votes = c.factorVotes && c.factorVotes.length ? c.factorVotes.map((v)=>`${v.factor}${v.vote >= 0 ? "+" : ""}${v.vote}`).join(",") : "n/a";
    return [
        `NX-${String(c.serial).padStart(4, "0")} ${c.symbol} ${c.direction} ${c.strategy} ${c.timeframe} → ${c.outcome}`,
        `conf ${c.confidence} · RR ${c.riskReward} · held ${c.holdMinutes}m · ladder ${c.reachedTp}/3 · maxPnl ${c.maxPnlPercent.toFixed(1)}% · net ${c.netPnlPercent.toFixed(1)}%`,
        `flow ${flow} · regime ${c.regimeTag ?? "n/a"} · tags ${c.tags.join(",") || "n/a"} · votes ${votes}`
    ].join(" | ");
}
async function runDeepLearnCycle(force = false) {
    await restoreState();
    if (!force && state.lastRunAt && Date.now() - new Date(state.lastRunAt).getTime() < MIN_INTERVAL_MS) {
        return {
            ran: false,
            learned: 0,
            reason: "throttled (30min)"
        };
    }
    const since = state.lastRunAt ? new Date(state.lastRunAt) : new Date(Date.now() - 48 * 3600_000);
    const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP3",
                    "SL"
                ]
            },
            closedAt: {
                gt: since
            }
        },
        orderBy: {
            closedAt: "asc"
        },
        take: 8
    });
    if (rows.length === 0) {
        state.lastRunAt = new Date().toISOString();
        await persistState();
        return {
            ran: false,
            learned: 0,
            reason: "no new TP3/SL outcomes since last cycle"
        };
    }
    const lab = await buildTp3Lab(14);
    // v8.2 GATE GAUGE — live reason ledger for the core (boundary band + blocks)
    const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateJournalForCore"])(12, 8);
    // v8.2 SHADOW-VETO Phase 0 — the core's own fence adjudications + A/B arms
    const shadow = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$shadow$2d$veto$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["shadowVetoForCore"])(6).catch(()=>({
            narrative: "SHADOW-VETO: unavailable this cycle.",
            verdictFiles: []
        }));
    // v10.2 SV-TELEMETRY — arm feed wiring narrative (best-effort, never blocks)
    const svTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sv$2d$telemetry$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["svTelemetryNarrative"])().catch(()=>"SV-TELEMETRY: unavailable this cycle.");
    // v10.8 FOUR-PACK journal — governance module verdicts in the research grounding
    const fpTel = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fourpackNarrative"])().catch(()=>"FOUR-PACK: unavailable this cycle.");
    const gateGrounding = [
        `GATE JOURNAL (live, 12h): ${gate.narrative}`,
        ...gate.boundaryFiles.slice(0, 8).map((l)=>`BOUNDARY VERDICT: ${l}`),
        ...gate.blockFiles.map((l)=>`GATE BLOCK: ${l}`),
        `SHADOW-VETO: ${shadow.narrative}`,
        `SV-TELEMETRY: ${svTel}`,
        `FOUR-PACK: ${fpTel}`,
        ...shadow.verdictFiles.slice(0, 6).map((l)=>`SHADOW ADJUDICATION: ${l}`)
    ].join("\n");
    const tp3Cases = rows.filter((r)=>r.status === "TP3").map(toCase);
    const slCases = rows.filter((r)=>r.status === "SL").map(toCase);
    const allCases = [
        ...tp3Cases,
        ...slCases
    ].map(caseFile).join("\n");
    const question = [
        `RESEARCH QUESTIONS for this cycle (${tp3Cases.length} full-TP, ${slCases.length} stopped-out):`,
        "1. What did the full-TP winners share at deploy time (confluence votes, flow verdict, regime, conviction, R:R) that let them run the whole ladder?",
        "2. What did the stopped-out trades show that should have been a warning?",
        "3. Which single, measurable behaviour change would most improve the next 20 deployments?",
        // v8.2 GATE GAUGE — reason-level research question fed by the live journal
        "4. GATE JOURNAL (below): the boundary band (gap −8..0 from the effective threshold) is where confirm and reject blur — which boundary reasons (thr modifiers, opposing votes, hard blocks) actually predicted later TP3 vs SL outcomes, and which gate modifier deserves tightening or loosening on that measured evidence?",
        // v8.2 SHADOW-VETO — the core's own adjudication quality
        "5. SHADOW-VETO (below): your own veto-only adjudications at the fence are now outcome-tracked — are your VETO calls landing on trades that lose and your TRADE calls on trades that win? Cite the A/B arms (real-keep / real-veto / paper-keep / paper-veto) with their Wilson-LB numbers; if any arm has <30 settled outcomes, say the evidence is still forming — never extrapolate from thin arms."
    ].join(" ");
    const grounding = [
        "TP3 LAB CONTRAST (measured, 14d): " + lab.contrast.note,
        `FULL-TP profile: n=${lab.fullTp.count} rate ${lab.fullTp.ratePct}% avgConf ${lab.fullTp.avgConfidence} avgRR ${lab.fullTp.avgRr} flow-CONFIRMS ${lab.fullTp.flowConfirmShare}% tags ${lab.fullTp.topTags.map(([t, n])=>`${t}×${n}`).join(",") || "n/a"}`,
        `STOP-OUT profile: n=${lab.stopped.count} avgConf ${lab.stopped.avgConfidence} held ${lab.stopped.avgHoldMin}m flow-CONFLICTS ${lab.stopped.flowConflictShare}% tags ${lab.stopped.topTags.map(([t, n])=>`${t}×${n}`).join(",") || "n/a"}`,
        "CASE FILES:",
        allCases,
        // v8.2 GATE JOURNAL — the reasons layer the boundary band lives on
        gateGrounding
    ].join("\n");
    const { aiDeepLearn } = await __turbopack_context__.A("[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)");
    const result = await aiDeepLearn(grounding, question, lab);
    // persist lessons (newest first, ring-capped)
    const at = new Date().toISOString();
    const lessons = result.lessons.map((l)=>({
            at,
            scope: l.scope,
            pattern: String(l.pattern).slice(0, 240),
            evidence: String(l.evidence).slice(0, 300),
            action: String(l.action).slice(0, 240),
            confidence: Math.max(0, Math.min(100, Math.round(Number(l.confidence) || 60))),
            label: result.label
        }));
    state.lessons = [
        ...lessons,
        ...state.lessons
    ].slice(0, RING_CAP);
    state.lastQuestion = question.slice(0, 600);
    state.lastAnswer = String(result.hypothesis ?? "").slice(0, 2400);
    state.lastRunAt = at;
    state.runs++;
    state.casesLearned += rows.length;
    state.label = result.label;
    await persistState();
    // broadcast the strongest lesson to the terminal feed (audited)
    const lead = lessons[0];
    if (lead) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signalEvent.create({
            data: {
                signalId: null,
                symbol: null,
                type: "ENGINE",
                level: "ai",
                message: `AI DEEP-LEARN #${state.runs}: studied ${rows.length} terminal outcomes (${tp3Cases.length} full-TP / ${slCases.length} stopped) — [${lead.scope}] ${lead.pattern} → ${lead.action} (${lead.label}, conf ${lead.confidence}%) · lesson stored to agent memory`
            }
        });
    }
    return {
        ran: true,
        learned: rows.length
    };
}
async function maybeAutoDeepLearn() {
    try {
        await runDeepLearnCycle(false);
    } catch (err) {
        console.error("[deep-learn]", err);
    }
}
}),
];

//# sourceMappingURL=src_lib_a87e065b._.js.map