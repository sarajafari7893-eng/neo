module.exports = [
"[project]/src/lib/ai.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/_8645af84._.js",
  "server/chunks/[root-of-the-server]__9cf9b63b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/ai.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/analyst-context.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__352695cc._.js",
  "server/chunks/src_lib_engine_ts_0bd90ac0._.js",
  "server/chunks/src_lib_3731a140._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__087147ff._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/analyst-context.ts [app-route] (ecmascript)");
    });
});
}),
];