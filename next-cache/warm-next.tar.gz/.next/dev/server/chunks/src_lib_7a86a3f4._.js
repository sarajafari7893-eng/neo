module.exports = [
"[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/raw-cal.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/engine.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__fb7a4dc0._.js",
  "server/chunks/src_lib_engine_ts_0bd90ac0._.js",
  "server/chunks/src_lib_73c7439f._.js",
  "server/chunks/src_config_engine-flags_json_878641d8._.js",
  "server/chunks/[externals]__e9d33ea9._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/engine.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__9c8ae4f1._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/notify.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/shadow-veto.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__ba99f3bf._.js",
  "server/chunks/[root-of-the-server]__c0496b44._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/shadow-veto.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/calibration.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_calibration_ts_ceb54a0a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/calibration.ts [app-route] (ecmascript)");
    });
});
}),
];