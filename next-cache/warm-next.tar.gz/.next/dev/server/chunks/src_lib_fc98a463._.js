module.exports = [
"[project]/src/lib/risk-governor.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getRiskGovernorState",
    ()=>getRiskGovernorState,
    "maybeRunRiskGovernor",
    ()=>maybeRunRiskGovernor,
    "runRiskGovernor",
    ()=>runRiskGovernor
]);
// ── FlowRadar Neo v9.6 — RISK GOVERNOR (R1, shadow-first, server-only) ──────
// Operator-approved module #1 (roadmap R1, mandate 2026-09-15: «اجرای چهار
// ماژول را مهندسی شده و کامل انجام بده»). Evidence base (block-2 answer,
// TG msg 2004):
//   · CHOP regime holds nearly all realized loss (−$31 of −$33 tracked),
//   · risk 0.5x → end-equity 90.28 vs 80.56 with DD 9.74 (price replay),
//   · leverage 10-15x worst de-leveraged (−0.475%/x), lev cap 10x ⇒ +3.94,
//   · last-20-settle slope drives the drawdown protocol.
//
// CONTRACT (shadow-first doctrine — approved design):
//   · SHADOW: computes a verdict every cycle, journals it, audits verdict
//     FLIPS as ENGINE events, and queues at most ONE AdvisorProposal per 24h
//     once a recommendation persists 2 consecutive cycles. Nothing is applied.
//   · ENGAGED (explicit operator toggle in AI CORE): applies ONLY through the
//     existing clamped gate-settings channel (riskPerTrade, leveredRiskCap),
//     at most one application per 6h, always audited. The engine deploy path
//     is NEVER touched by this module.
//
// Deterministic math — no LLM call, fail-open everywhere.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$risk$2d$overlay$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/risk-overlay.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/regime.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$vol$2d$forecast$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/vol-forecast.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — FOUR-PACK JSON journal doctrine
;
;
;
;
;
;
;
const KEY = "riskgovernor.state";
const CYCLE_MIN_MS = 60 * 60_000; // hourly shadow cycle
const APPLY_MIN_GAP_MS = 6 * 3600_000; // ENGAGED: ≥6h between applications
const PROPOSAL_MIN_GAP_MS = 24 * 3600_000; // SHADOW: ≤1 proposal/day
const PERSIST_FOR_PROPOSAL = 2; // recommendation must hold 2 consecutive cycles
const JOURNAL_CAP = 14;
const LEV_EVIDENCE_CAP = 15; // leveredRiskCap evidence target (10-15x band)
const LEV_HARD_CAP = 10; // absolute evidence bar for heavy-defensive
const EMPTY = {
    at: 0,
    cycles: 0,
    lastRunAt: null,
    verdict: "STANDARD",
    sizeMult: 1,
    reasons: [],
    inputs: {
        equity: 0,
        drawdownPct: 0,
        regimeBtc: null,
        atrPct: null,
        atrTone: "UNKNOWN",
        chop: null,
        slope20: null,
        gateRiskPerTrade: 1,
        gateLeveredRiskCap: 25
    },
    streak: 0,
    lastProposalAt: null,
    lastApplied: null,
    journal: []
};
function clampNum(v, lo, hi) {
    return Math.min(hi, Math.max(lo, Math.round(v * 100) / 100));
}
async function getState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) return {
            ...EMPTY,
            ...JSON.parse(row.value),
            inputs: {
                ...EMPTY.inputs,
                ...JSON.parse(row.value).inputs ?? {}
            }
        };
    } catch  {
    /* fresh */ }
    return {
        ...EMPTY
    };
}
async function putState(next) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
}
// ── evidence gathering (read-only) ──────────────────────────────────────────
async function atrPctile() {
    try {
        const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$vol$2d$forecast$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getKlines15m"])("BTCUSDT");
        if (!candles || candles.length < 40) return {
            atrPct: null,
            tone: "UNKNOWN"
        };
        const closed = candles.slice(0, -1);
        const trs = [];
        for(let i = 1; i < closed.length; i++){
            const c = closed[i];
            const p = closed[i - 1];
            const tr = Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
            if (p.close > 0) trs.push(tr / p.close);
        }
        const win = trs.slice(-14);
        if (!win.length) return {
            atrPct: null,
            tone: "UNKNOWN"
        };
        const atr = win.reduce((a, b)=>a + b, 0) / win.length * 100;
        const tone = atr > 2.5 ? "HIGH" : atr < 1.2 ? "LOW" : "NORMAL";
        return {
            atrPct: Number(atr.toFixed(2)),
            tone
        };
    } catch  {
        return {
            atrPct: null,
            tone: "UNKNOWN"
        };
    }
}
async function gatherInputs() {
    const [risk, gate, chopTele, atr] = await Promise.all([
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$risk$2d$overlay$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRiskState"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: "regime.telemetry"
            }
        }).catch(()=>null),
        atrPctile()
    ]);
    let chop = null;
    try {
        const tel = JSON.parse(chopTele?.value ?? "{}");
        const c = tel["CHOP"];
        if (c && c.n > 0) chop = {
            n: c.n,
            pnlUsd: c.pnlUsd,
            wr: Number((c.wins / c.n * 100).toFixed(1))
        };
    } catch  {
    /* fresh */ }
    const since = new Date(Date.now() - 30 * 86_400_000);
    const last20 = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            closedAt: {
                gte: since
            }
        },
        select: {
            pnlPercent: true,
            marginUsd: true,
            reachedTp: true
        },
        orderBy: {
            closedAt: "desc"
        },
        take: 20
    });
    let pnl = 0;
    let wins = 0;
    for (const s of last20){
        pnl += s.marginUsd * s.pnlPercent / 100;
        if (s.reachedTp >= 1) wins++;
    }
    const btc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$regime$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["peekRegime"])("BTCUSDT");
    return {
        inputs: {
            equity: risk.state.equity,
            drawdownPct: risk.state.drawdownPct,
            regimeBtc: btc?.regime ?? null,
            atrPct: atr.atrPct,
            atrTone: atr.tone,
            chop,
            slope20: last20.length ? {
                n: last20.length,
                pnlUsd: Number(pnl.toFixed(2)),
                wins
            } : null,
            gateRiskPerTrade: gate.riskPerTrade,
            gateLeveredRiskCap: gate.leveredRiskCap
        },
        regimeIsChop: btc?.regime === "CHOP"
    };
}
// ── verdict math (deterministic) ────────────────────────────────────────────
function decide(inputs, regimeIsChop) {
    const reasons = [];
    let defensive = 0;
    let heavy = 0;
    if (inputs.drawdownPct >= 7) {
        heavy++;
        reasons.push(`drawdown ${inputs.drawdownPct}% ≥ 7% — heavy throttle band (risk-overlay)`);
    } else if (inputs.drawdownPct >= 3) {
        defensive++;
        reasons.push(`drawdown ${inputs.drawdownPct}% ≥ 3% — throttle band (risk-overlay)`);
    }
    if (inputs.slope20 && inputs.slope20.n >= 10) {
        if (inputs.slope20.pnlUsd <= -10) {
            heavy++;
            reasons.push(`last ${inputs.slope20.n} settles sum ${inputs.slope20.pnlUsd <= 0 ? "" : "+"}$${inputs.slope20.pnlUsd} ≤ −$10 — drawdown protocol`);
        } else if (inputs.slope20.pnlUsd <= -4) {
            defensive++;
            reasons.push(`last ${inputs.slope20.n} settles sum ${inputs.slope20.pnlUsd <= 0 ? "" : "+"}$${inputs.slope20.pnlUsd} — soft bleed`);
        }
    }
    if (inputs.chop && inputs.chop.n >= 10 && inputs.chop.pnlUsd < 0 && (regimeIsChop || inputs.regimeBtc === null)) {
        defensive++;
        reasons.push(`CHOP book: ${inputs.chop.n} settles, ${inputs.chop.wr}% win, net $${inputs.chop.pnlUsd}${regimeIsChop ? " — BTC regime is CHOP right now" : ""}`);
    }
    if (regimeIsChop) {
        defensive++;
        reasons.push("BTC regime CHOP — the regime that holds nearly all realized loss");
    }
    if (inputs.atrTone === "HIGH") {
        defensive++;
        reasons.push(`BTC 15m ATR ${inputs.atrPct}% — high-vol tone (stop inflation risk)`);
    }
    if (defensive === 0 && heavy === 0) {
        // offense requires a clean bill: positive slope + shallow DD + trend regime
        const slopeOk = inputs.slope20 && inputs.slope20.n >= 10 && inputs.slope20.pnlUsd >= 4;
        const trendOk = inputs.regimeBtc === "TREND_UP" || inputs.regimeBtc === "TREND_DOWN";
        if (slopeOk && trendOk && inputs.drawdownPct < 1) {
            return {
                verdict: "OFFENSIVE",
                sizeMult: 1.15,
                reasons: [
                    `last ${inputs.slope20.n} settles +$${inputs.slope20.pnlUsd} with ${inputs.regimeBtc} regime and DD ${inputs.drawdownPct}% — measured offense (×1.15, inside clamps)`
                ]
            };
        }
        return {
            verdict: "STANDARD",
            sizeMult: 1,
            reasons: [
                "book clean — no defensive trigger; baseline sizing"
            ]
        };
    }
    if (heavy > 0) return {
        verdict: "HEAVY-DEFENSIVE",
        sizeMult: 0.5,
        reasons
    };
    return {
        verdict: "DEFENSIVE",
        sizeMult: 0.75,
        reasons
    };
}
// ── proposal / application helpers ──────────────────────────────────────────
async function knobHasPending(knob) {
    const recent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.findMany({
        where: {
            knob
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 3
    });
    return recent.some((p)=>p.status === "PENDING");
}
async function queueProposal(knob, proposedValue, rationale, evidence) {
    if (await knobHasPending(knob)) return false;
    const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
    const [lo, hi] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateClamps"])()[knob];
    const target = clampNum(proposedValue, lo, hi);
    if (Math.abs(target - gate[knob]) < 0.01) return false;
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.create({
        data: {
            cycle: -1,
            kind: "KNOB_ADJUST",
            knob,
            currentValue: gate[knob],
            proposedValue: target,
            direction: target < gate[knob] ? "TIGHTEN" : "LOOSEN",
            rationale,
            evidence: JSON.stringify({
                source: "risk-governor",
                ...evidence
            })
        }
    });
    return true;
}
async function runRiskGovernor(mode) {
    const prev = await getState();
    const { inputs, regimeIsChop } = await gatherInputs();
    const { verdict, sizeMult, reasons } = decide(inputs, regimeIsChop);
    const state = {
        at: Date.now(),
        cycles: prev.cycles + 1,
        lastRunAt: new Date().toISOString(),
        verdict,
        sizeMult,
        reasons,
        inputs,
        streak: verdict === prev.verdict && verdict !== "STANDARD" ? prev.streak + 1 : verdict !== "STANDARD" ? 1 : 0,
        lastProposalAt: prev.lastProposalAt,
        lastApplied: prev.lastApplied,
        journal: [
            {
                at: new Date().toISOString(),
                verdict,
                sizeMult,
                line: reasons[0] ?? "baseline"
            },
            ...prev.journal
        ].slice(0, JOURNAL_CAP)
    };
    // verdict-flip audit (both modes — evidence honesty)
    const flipped = verdict !== prev.verdict && prev.cycles > 0;
    if (flipped) {
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `RISK GOVERNOR verdict ${prev.verdict} → ${verdict} (sizeMult ×${sizeMult}) — ${reasons[0] ?? ""}`).catch(()=>undefined);
    }
    // v10.8 journal doctrine — every cycle lands in the retrievable JSON journal
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordFourPack"])("r1-risk-governor", flipped ? "flip" : "cycle", reasons[0] ?? "baseline sizing", {
        cycles: state.cycles,
        streak: state.streak,
        drawdownPct: inputs.drawdownPct,
        slope20PnlUsd: inputs.slope20?.pnlUsd ?? null,
        regimeBtc: inputs.regimeBtc,
        mode
    }, verdict).catch(()=>undefined);
    if (mode === "SHADOW") {
        const canPropose = !state.lastProposalAt || Date.now() - new Date(state.lastProposalAt).getTime() >= PROPOSAL_MIN_GAP_MS;
        if (canPropose && state.streak >= PERSIST_FOR_PROPOSAL) {
            let queued = false;
            if (verdict === "HEAVY-DEFENSIVE" && inputs.gateLeveredRiskCap > LEV_EVIDENCE_CAP) {
                queued = await queueProposal("leveredRiskCap", LEV_EVIDENCE_CAP, `RISK GOVERNOR ${verdict} persistent (${state.streak} cycles): DD ${inputs.drawdownPct}%, slope ${inputs.slope20?.pnlUsd ?? "?"}$ — trim levered risk cap to the 10-15x evidence band (de-leverage −0.475%/x)`, {
                    verdict,
                    streak: state.streak,
                    drawdownPct: inputs.drawdownPct,
                    slope20: inputs.slope20,
                    atrPct: inputs.atrPct
                });
            } else if (verdict === "HEAVY-DEFENSIVE" || verdict === "DEFENSIVE") {
                const target = clampNum(1 * sizeMult, 0.5, 1.5);
                if (target < inputs.gateRiskPerTrade) {
                    queued = await queueProposal("riskPerTrade", target, `RISK GOVERNOR ${verdict} persistent (${state.streak} cycles): ${reasons.slice(0, 2).join("; ")} — size ×${inputs.gateRiskPerTrade.toFixed(2)}→×${target.toFixed(2)} (0.5x replay: end 90.28, DD 9.74)`, {
                        verdict,
                        streak: state.streak,
                        sizeMult,
                        drawdownPct: inputs.drawdownPct,
                        slope20: inputs.slope20
                    });
                }
            }
            if (queued) {
                state.lastProposalAt = new Date().toISOString();
                void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordFourPack"])("r1-risk-governor", "proposal", `${verdict} persistent (${state.streak}) — clamped proposal queued`, {
                    streak: state.streak,
                    verdict
                }, verdict).catch(()=>undefined);
            }
        }
    } else {
        // ENGAGED — apply through the clamped channel, ≥6h gap, audited
        const gapOk = !state.lastApplied || Date.now() - new Date(state.lastApplied.at).getTime() >= APPLY_MIN_GAP_MS;
        if (gapOk && verdict !== "STANDARD") {
            const gate = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
            const targetRisk = clampNum(1 * sizeMult, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateClamps"])().riskPerTrade[0], (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateClamps"])().riskPerTrade[1]);
            if (Math.abs(gate.riskPerTrade - targetRisk) >= 0.05) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                    riskPerTrade: targetRisk
                });
                state.lastApplied = {
                    at: new Date().toISOString(),
                    knob: "riskPerTrade",
                    from: gate.riskPerTrade,
                    to: targetRisk
                };
                void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `RISK GOVERNOR ENGAGED: riskPerTrade ×${gate.riskPerTrade.toFixed(2)}→×${targetRisk.toFixed(2)} (verdict ${verdict}) — audited, clamped`).catch(()=>undefined);
                void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordFourPack"])("r1-risk-governor", "apply", `ENGAGED applied riskPerTrade ×${gate.riskPerTrade.toFixed(2)}→×${targetRisk.toFixed(2)} (verdict ${verdict})`, {
                    knob: "riskPerTrade",
                    from: gate.riskPerTrade,
                    to: targetRisk
                }, verdict).catch(()=>undefined);
            } else if (verdict === "HEAVY-DEFENSIVE" && gate.leveredRiskCap > LEV_EVIDENCE_CAP) {
                const capTarget = Math.min(gate.leveredRiskCap, LEV_HARD_CAP);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
                    leveredRiskCap: capTarget
                });
                state.lastApplied = {
                    at: new Date().toISOString(),
                    knob: "leveredRiskCap",
                    from: gate.leveredRiskCap,
                    to: capTarget
                };
                void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `RISK GOVERNOR ENGAGED: leveredRiskCap ${gate.leveredRiskCap}→${capTarget} — evidence band enforcement, audited`).catch(()=>undefined);
                void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordFourPack"])("r1-risk-governor", "apply", `ENGAGED applied leveredRiskCap ${gate.leveredRiskCap}→${capTarget} (evidence band)`, {
                    knob: "leveredRiskCap",
                    from: gate.leveredRiskCap,
                    to: capTarget
                }, verdict).catch(()=>undefined);
            }
        }
    }
    await putState(state);
    return state;
}
async function getRiskGovernorState() {
    return getState();
}
let lastRun = 0;
async function maybeRunRiskGovernor(mode) {
    if (Date.now() - lastRun < CYCLE_MIN_MS) return;
    lastRun = Date.now();
    await runRiskGovernor(mode).catch(()=>undefined);
}
}),
"[project]/src/lib/time-governor.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getTimeGovernorState",
    ()=>getTimeGovernorState,
    "maybeRunTimeGovernor",
    ()=>maybeRunTimeGovernor,
    "runTimeGovernor",
    ()=>runTimeGovernor,
    "tehranHourOf",
    ()=>tehranHourOf
]);
// ── FlowRadar Neo v9.6 — TIME GOVERNOR (R2, shadow-first, server-only) ──────
// Operator-approved module #2 (roadmap R2, mandate 2026-09-15). Evidence base
// (block-2 answer, TG msg 2004):
//   · worst Tehran hours 00/03/04/11/12/15 ≈ −$15 combined,
//   · prime hours 01-02 are the book's best window,
//   · prime-hours-only what-if ≈ +$18.15 on the replayed ledger.
//
// CONTRACT (shadow-first doctrine):
//   · Builds a 24-hour (Asia/Tehran, fixed UTC+03:30) realized-performance
//     table from the settled ledger over a 45-day window, tiers each hour
//     TOXIC / PRIME / NEUTRAL / THIN, and attaches a size weight per hour.
//   · SHADOW: compute + journal + audit; the verdict feeds the Daily
//     Senior-Review digest. Hour-of-day filtering has NO existing gate knob,
//     so it can never silently alter the engine — wiring it into the deploy
//     path is explicitly gated on a separate operator decision (documented in
//     the AI CORE card and proposals are NOT queued for it).
//   · ENGAGED: marks the weights ACTIVE in the module verdict + audited event;
//     still no deploy-path mutation (honest shadow doctrine).
//
// Deterministic — no LLM call, fail-open everywhere.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — FOUR-PACK JSON journal doctrine
;
;
;
const KEY = "timegovernor.state";
const CYCLE_MIN_MS = 6 * 3600_000; // ledger moves slowly — 6h cadence
const TEHRAN_OFFSET_H = 3.5; // Iran = UTC+03:30 fixed (no DST since 2022)
const WINDOW_DAYS = 45;
const MIN_N = 8; // minimum settles before an hour may be tiered
const WEIGHT_CAPS = {
    toxic: 0.5,
    prime: 1.1
};
const EMPTY = {
    at: 0,
    cycles: 0,
    lastRunAt: null,
    windowDays: WINDOW_DAYS,
    hourly: [],
    toxicHours: [],
    primeHours: [],
    estUpliftUsd: 0,
    bookPnlUsd: 0,
    line: "not run yet",
    journal: []
};
function tehranHourOf(d) {
    return Math.floor((d.getUTCHours() + d.getUTCMinutes() / 60 + TEHRAN_OFFSET_H) % 24);
}
async function getState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) return {
            ...EMPTY,
            ...JSON.parse(row.value)
        };
    } catch  {
    /* fresh */ }
    return {
        ...EMPTY
    };
}
async function putState(next) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
}
async function runTimeGovernor() {
    const prev = await getState();
    const since = new Date(Date.now() - WINDOW_DAYS * 86_400_000);
    const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            },
            closedAt: {
                gte: since
            }
        },
        select: {
            closedAt: true,
            pnlPercent: true,
            marginUsd: true,
            reachedTp: true
        }
    });
    const buckets = new Map();
    let bookPnl = 0;
    for (const s of settled){
        if (!s.closedAt) continue;
        const usd = s.marginUsd * s.pnlPercent / 100;
        bookPnl += usd;
        const h = tehranHourOf(s.closedAt);
        const b = buckets.get(h) ?? {
            n: 0,
            wins: 0,
            pnl: 0,
            pct: 0
        };
        b.n++;
        if (s.reachedTp >= 1) b.wins++;
        b.pnl += usd;
        b.pct += s.pnlPercent;
        buckets.set(h, b);
    }
    const hourly = [];
    for(let h = 0; h < 24; h++){
        const b = buckets.get(h);
        if (!b || b.n === 0) {
            hourly.push({
                h,
                n: 0,
                wins: 0,
                pnlUsd: 0,
                expectancyPct: 0,
                wr: 0,
                tier: "THIN",
                weight: 1
            });
            continue;
        }
        const exp = b.pct / b.n;
        const wr = b.wins / b.n * 100;
        let tier = "NEUTRAL";
        let weight = 1;
        if (b.n < MIN_N) tier = "THIN";
        else if (b.pnl < 0 && exp <= -1) {
            tier = "TOXIC";
            weight = WEIGHT_CAPS.toxic;
        } else if (b.pnl > 0 && exp >= 1) {
            tier = "PRIME";
            weight = WEIGHT_CAPS.prime;
        }
        hourly.push({
            h,
            n: b.n,
            wins: b.wins,
            pnlUsd: Number(b.pnl.toFixed(2)),
            expectancyPct: Number(exp.toFixed(2)),
            wr: Number(wr.toFixed(1)),
            tier,
            weight
        });
    }
    hourly.sort((a, b)=>a.h - b.h);
    const toxicHours = hourly.filter((c)=>c.tier === "TOXIC").map((c)=>c.h);
    const primeHours = hourly.filter((c)=>c.tier === "PRIME").map((c)=>c.h);
    const toxicBleed = hourly.filter((c)=>c.tier === "TOXIC").reduce((a, c)=>a + c.pnlUsd, 0);
    // v10.8 sign fix — est. uplift = the bleed AVOIDED by throttling toxic hours to
    // ×0.5: toxicBleed is negative, so the avoided half is positive (+$X.XX).
    const estUplift = Number((-toxicBleed * (1 - WEIGHT_CAPS.toxic)).toFixed(2));
    const line = toxicHours.length || primeHours.length ? `TOXIC Tehran hours [${toxicHours.map((h)=>String(h).padStart(2, "0")).join(",")}] bleed $${toxicBleed.toFixed(2)} · PRIME [${primeHours.map((h)=>String(h).padStart(2, "0")).join(",")}] · weight cap ×${WEIGHT_CAPS.toxic}—×${WEIGHT_CAPS.prime} · est. uplift +$${estUplift}` : `no tiered hour yet (n ≥ ${MIN_N} per hour required) — book ${settled.length} settles in window`;
    const state = {
        at: Date.now(),
        cycles: prev.cycles + 1,
        lastRunAt: new Date().toISOString(),
        windowDays: WINDOW_DAYS,
        hourly,
        toxicHours,
        primeHours,
        estUpliftUsd: estUplift,
        bookPnlUsd: Number(bookPnl.toFixed(2)),
        line,
        journal: [
            {
                at: new Date().toISOString(),
                line
            },
            ...prev.journal
        ].slice(0, 8)
    };
    // audit on tier-flip only (both modes)
    const prevKey = `${prev.toxicHours.join(",")}|${prev.primeHours.join(",")}`;
    const nextKey = `${toxicHours.join(",")}|${primeHours.join(",")}`;
    if (prev.cycles > 0 && prevKey !== nextKey) {
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `TIME GOVERNOR tiers changed — ${line}`).catch(()=>undefined);
    }
    // v10.8 journal doctrine — every cycle + tier-flip lands in the JSON journal
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordFourPack"])("r2-time-governor", prev.cycles > 0 && prevKey !== nextKey ? "flip" : "cycle", line, {
        toxicHours,
        primeHours,
        estUpliftUsd: estUplift,
        bookPnlUsd: Number(bookPnl.toFixed(2)),
        settles: settled.length
    }).catch(()=>undefined);
    await putState(state);
    return state;
}
async function getTimeGovernorState() {
    return getState();
}
let lastRun = 0;
async function maybeRunTimeGovernor() {
    if (Date.now() - lastRun < CYCLE_MIN_MS) return;
    lastRun = Date.now();
    await runTimeGovernor().catch(()=>undefined);
}
}),
"[project]/src/lib/ui-canary.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCanaryState",
    ()=>getCanaryState,
    "maybeRunCanary",
    ()=>maybeRunCanary,
    "runCanary",
    ()=>runCanary
]);
// ── FlowRadar Neo v9.6 — UI-CANARY (R5, shadow-first, server-only) ──────────
// Operator-approved module #3 (roadmap R5, mandate 2026-09-15). The operator
// asked for a VLM visual supervisor; the approved scope is a LIGHTER
// black-box watchdog: probe the dashboard's own data surfaces end-to-end
// (HTTP + payload-shape validation), grade a verdict, journal it, and escalate
// ONLY on persistent failure. This is the "canary in the cage" — cheap, loud
// when it must be, silent otherwise.
//
// CONTRACT:
//   · SHADOW: probes every ~15min (internally throttled), journals a ring of
//     snapshots, fires an ENGINE event ONLY on a verdict flip, never pages.
//   · ENGAGED: additionally pages Telegram (sendDirect, no '<' chars) after
//     3 consecutive RED verdicts, ≥6h between pages.
//   · Probes hit 127.0.0.1 (self) so no external dependency is added; every
//     probe is timeout-guarded (4s) and fail-open.
//
// Deterministic — no LLM call.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$notify$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/notify.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — FOUR-PACK JSON journal doctrine
;
;
;
;
const KEY = "uicanary.state";
const CYCLE_MIN_MS = 15 * 60_000;
const TIMEOUT_MS = 4_000;
const RED_PAGE_STREAK = 3;
const PAGE_MIN_GAP_MS = 6 * 3600_000;
const HISTORY_CAP = 24;
const EMPTY = {
    at: 0,
    cycles: 0,
    lastRunAt: null,
    probes: [],
    verdict: "GREEN",
    redStreak: 0,
    lastFlipAt: null,
    lastPageAt: null,
    history: [],
    line: "not run yet"
};
/** Probe table — the dashboard's load-bearing data surfaces. */ const PROBE_TABLE = [
    {
        name: "PULSE",
        path: "/api/pulse",
        shape: (j)=>!!j && typeof j === "object" && "stats" in j
    },
    {
        name: "RAWCAL",
        path: "/api/rawcal",
        shape: (j)=>!!j && typeof j === "object" && "armed" in j
    },
    {
        name: "FLOWS",
        path: "/api/flows",
        shape: ()=>true
    },
    {
        name: "AI-MEMORY",
        path: "/api/ai/memory",
        shape: ()=>true
    },
    {
        name: "BRIDGE",
        path: "/api/bridge/inbox",
        shape: ()=>true
    }
];
async function getState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) return {
            ...EMPTY,
            ...JSON.parse(row.value)
        };
    } catch  {
    /* fresh */ }
    return {
        ...EMPTY
    };
}
async function putState(next) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
}
function baseUrl() {
    const port = process.env.PORT || "3000";
    return `http://127.0.0.1:${port}`;
}
async function probeOne(p) {
    const t0 = Date.now();
    try {
        const res = await fetch(`${baseUrl()}${p.path}`, {
            cache: "no-store",
            signal: AbortSignal.timeout(TIMEOUT_MS)
        });
        const latencyMs = Date.now() - t0;
        let shapeOk = false;
        if (res.ok) {
            try {
                shapeOk = p.shape(await res.json());
            } catch  {
                shapeOk = false;
            }
        }
        return {
            name: p.name,
            path: p.path,
            ok: res.ok,
            status: res.status,
            latencyMs,
            shapeOk,
            err: res.ok ? shapeOk ? null : "shape" : `HTTP ${res.status}`
        };
    } catch (e) {
        return {
            name: p.name,
            path: p.path,
            ok: false,
            status: 0,
            latencyMs: Date.now() - t0,
            shapeOk: false,
            err: e instanceof Error ? e.message.slice(0, 60) : "fetch failed"
        };
    }
}
async function runCanary(mode) {
    const prev = await getState();
    const probes = [];
    for (const p of PROBE_TABLE)probes.push(await probeOne(p));
    const failed = probes.filter((x)=>!x.ok || !x.shapeOk);
    const maxLat = Math.max(0, ...probes.map((x)=>x.latencyMs));
    let verdict;
    if (failed.length === 0 && maxLat < 1500) verdict = "GREEN";
    else if (probes.find((x)=>x.name === "PULSE" && (!x.ok || !x.shapeOk)) || failed.length >= 2) verdict = "RED";
    else verdict = "AMBER";
    const bad = failed.map((x)=>`${x.name}(${x.err ?? "?"})`).join(", ");
    const line = verdict === "GREEN" ? `all ${probes.length} surfaces ok, max latency ${maxLat}ms` : `${verdict}: ${bad || `slow ${maxLat}ms`}`;
    const flipped = verdict !== prev.verdict;
    const redStreak = verdict === "RED" ? prev.redStreak + 1 : 0;
    const state = {
        at: Date.now(),
        cycles: prev.cycles + 1,
        lastRunAt: new Date().toISOString(),
        probes,
        verdict,
        redStreak,
        lastFlipAt: flipped ? new Date().toISOString() : prev.lastFlipAt,
        lastPageAt: prev.lastPageAt,
        history: [
            {
                at: new Date().toISOString(),
                verdict
            },
            ...prev.history
        ].slice(0, HISTORY_CAP),
        line
    };
    if (flipped && prev.cycles > 0) {
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, verdict === "RED" ? "SYSTEM" : "ENGINE", verdict === "GREEN" ? "success" : "warn", `UI-CANARY verdict ${prev.verdict} → ${verdict} — ${line}`).catch(()=>undefined);
    }
    // v10.8 journal doctrine — every probe pass + flip lands in the JSON journal
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordFourPack"])("r5-ui-canary", flipped ? "flip" : "cycle", line, {
        maxLatencyMs: maxLat,
        failed: failed.length,
        probes: probes.map((x)=>({
                name: x.name,
                ok: x.ok && x.shapeOk,
                latencyMs: x.latencyMs
            }))
    }, verdict).catch(()=>undefined);
    if (mode === "ENGAGED" && redStreak >= RED_PAGE_STREAK) {
        const gapOk = !state.lastPageAt || Date.now() - new Date(state.lastPageAt).getTime() >= PAGE_MIN_GAP_MS;
        if (gapOk) {
            const txt = `UI-CANARY RED x${redStreak} — ${line}. Probes: ${probes.map((x)=>`${x.name} ${x.ok && x.shapeOk ? "ok" : "FAIL"}`).join(", ")}. Dashboard data plane degraded — check dev.log.`;
            const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$notify$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sendDirect"])(txt).catch(()=>({
                    ok: false
                }));
            if (r.ok) {
                state.lastPageAt = new Date().toISOString();
                void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordFourPack"])("r5-ui-canary", "page", `Telegram page sent — RED x${redStreak}: ${line}`, {
                    redStreak
                }, verdict).catch(()=>undefined);
            }
        }
    }
    await putState(state);
    return state;
}
async function getCanaryState() {
    return getState();
}
let lastRun = 0;
async function maybeRunCanary(mode) {
    if (Date.now() - lastRun < CYCLE_MIN_MS) return;
    lastRun = Date.now();
    await runCanary(mode).catch(()=>undefined);
}
}),
"[project]/src/lib/advisor.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "advisorCaptionBlock",
    ()=>advisorCaptionBlock,
    "advisorSnapshot",
    ()=>advisorSnapshot,
    "decideProposal",
    ()=>decideProposal,
    "forceRunAdvisor",
    ()=>forceRunAdvisor,
    "gatherLedgerStats",
    ()=>gatherLedgerStats,
    "maybeRunAdvisor",
    ()=>maybeRunAdvisor,
    "runAdvisorCycle",
    ()=>runAdvisorCycle
]);
// ── FlowRadar Neo v6.6 AI ADVISOR LOOP (server-only) ────────────────────────
// Operator mandate (2026-09-07, Q3): the engine core could not reach the
// calibration conclusions on its own — the governor only tunes numeric knobs,
// it cannot invent NEW filtering policy or judge a guard trial. The advisor
// closes that loop, exactly as the operator specified:
//   1. READ the realized ledger (strategies, regimes, TTL telemetry, trials)
//      on a fixed cadence (6h, deterministic — no LLM call needed);
//   2. PROPOSE evidence-grounded changes — existing gate knobs ONLY, always
//      inside the hard clamps, each carrying its measured evidence;
//   3. WAIT for operator approval (AI CORE advisor panel / API / Telegram);
//   4. APPLY only after an explicit APPROVE — via the same putGateSettings
//      channel the governor uses, clamped and audited as an ENGINE event;
//   5. LEARN from rejections — two consecutive REJECTs on one knob put it on a
//      7-day cooldown so the advisor cannot nag.
// The advisor NEVER applies anything on its own — «بدون اجازه» is a hard
// invariant, enforced by making approve an explicit operator action.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ttl$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ttl-gate.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$notify$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/notify.ts [app-route] (ecmascript)");
;
;
;
;
;
const ADVISOR_STATE_KEY = "advisor.state";
const CYCLE_INTERVAL_MS = 6 * 3600_000; // 4 evidence cycles/day — the 00:00 Tehran daily report carries the queue
const STALE_PENDING_MS = 7 * 86_400_000; // unanswered proposals expire after 7 days
const REJECT_COOLDOWN_MS = 7 * 86_400_000; // 2 consecutive rejects → knob frozen 7 days
const APPLIED_QUIET_MS = 72 * 3600_000; // after an apply, give the knob 72h before re-proposing
const MAX_PROPOSALS_PER_CYCLE = 2;
const MIN_BUCKET_N = 12; // minimum settled rows before a strategy rule may fire
const BO_EXP_TARGET_N = 20; // BREAKOUT trial verdict threshold (approved spec)
const EMPTY_STATE = {
    cycles: 0,
    lastRunAt: null,
    lastBoExpVerdictAt: null
};
async function getState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: ADVISOR_STATE_KEY
            }
        });
        if (!row) return {
            ...EMPTY_STATE
        };
        return {
            ...EMPTY_STATE,
            ...JSON.parse(row.value)
        };
    } catch  {
        return {
            ...EMPTY_STATE
        };
    }
}
async function putState(next) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: ADVISOR_STATE_KEY
        },
        create: {
            key: ADVISOR_STATE_KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
}
async function gatherLedgerStats() {
    const settled = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.findMany({
        where: {
            status: {
                in: [
                    "TP1",
                    "TP2",
                    "TP3",
                    "SL",
                    "EXPIRED",
                    "CLOSED"
                ]
            }
        },
        select: {
            strategy: true,
            direction: true,
            pnlPercent: true,
            marginUsd: true,
            reachedTp: true,
            tags: true,
            closedAt: true
        },
        orderBy: {
            closedAt: "desc"
        }
    });
    const byStrat = new Map();
    let shortN = 0;
    let shortPnl = 0;
    let shortPct = 0;
    const monthAgo = Date.now() - 30 * 86_400_000;
    for (const s of settled){
        const usd = s.marginUsd * s.pnlPercent / 100;
        const win = s.reachedTp >= 1;
        const b = byStrat.get(s.strategy) ?? {
            n: 0,
            wins: 0,
            pnl: 0,
            pct: 0
        };
        b.n++;
        if (win) b.wins++;
        b.pnl += usd;
        b.pct += s.pnlPercent;
        byStrat.set(s.strategy, b);
        if (s.direction === "SHORT" && s.closedAt && s.closedAt.getTime() >= monthAgo) {
            shortN++;
            shortPnl += usd;
            shortPct += s.pnlPercent;
        }
    }
    const strategies = [
        ...byStrat.entries()
    ].map(([strategy, b])=>({
            strategy,
            n: b.n,
            wins: b.wins,
            pnlUsd: Number(b.pnl.toFixed(2)),
            expectancyPct: Number((b.pct / Math.max(1, b.n)).toFixed(2))
        })).sort((a, b)=>a.pnlUsd - b.pnlUsd);
    // BREAKOUT trial cohort (breakoutGuard=1 arm) — tags contain BO-EXP
    const expRows = settled.filter((s)=>s.tags.split(",").includes("BO-EXP"));
    let grossWin = 0;
    let grossLoss = 0;
    for (const s of expRows){
        const usd = s.marginUsd * s.pnlPercent / 100;
        if (usd >= 0) grossWin += usd;
        else grossLoss += Math.abs(usd);
    }
    const ttl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ttl$2d$gate$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTtlTelemetry"])();
    const last20 = settled.slice(0, 20);
    return {
        settled: settled.length,
        strategies,
        shortBook: {
            n: shortN,
            pnlUsd: Number(shortPnl.toFixed(2)),
            expectancyPct: shortN ? Number((shortPct / shortN).toFixed(2)) : 0
        },
        boExp: {
            n: expRows.length,
            wins: expRows.filter((s)=>s.reachedTp >= 1).length,
            pnlUsd: Number((grossWin - grossLoss).toFixed(2)),
            pf: grossLoss > 0 ? Number((grossWin / grossLoss).toFixed(2)) : grossWin > 0 ? 99 : null
        },
        ttl,
        last20PnlUsd: Number(last20.reduce((a, s)=>a + s.marginUsd * s.pnlPercent / 100, 0).toFixed(2)),
        gate: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])()
    };
}
function inClamp(knob, v) {
    const [lo, hi] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateClamps"])()[knob];
    return Math.min(hi, Math.max(lo, Math.round(v * 100) / 100));
}
function draftProposals(st) {
    const drafts = [];
    const clamps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateClamps"])();
    // RULE 1 — BREAKOUT trial verdict (operator-approved experiment window):
    // ≥20 BO-EXP settles with PF ≤ 1.2 → propose restoring the veto (breakoutGuard 2).
    if (st.gate.breakoutGuard === 1 && st.boExp.n >= BO_EXP_TARGET_N && st.boExp.pf !== null && st.boExp.pf <= 1.2) {
        drafts.push({
            knob: "breakoutGuard",
            proposedValue: 2,
            direction: "TIGHTEN",
            rationale: `BREAKOUT conditional trial FAILED its window — ${st.boExp.n} settles, PF ${st.boExp.pf} ≤ 1.2 (net ${st.boExp.pnlUsd >= 0 ? "+" : ""}$${st.boExp.pnlUsd}); restore full veto`,
            evidence: {
                trial: "BO-EXP",
                n: st.boExp.n,
                pf: st.boExp.pf,
                pnlUsd: st.boExp.pnlUsd,
                wins: st.boExp.wins,
                window: `PF>1.2 over ≥${BO_EXP_TARGET_N}`
            }
        });
    }
    // RULE 2 — strategy bleed: a strategy with ≥12 settles and expectancy < −2%/trade
    // tightens the BASE threshold (the regime thrAdj already adds per-candidate surcharge).
    const worst = st.strategies.find((s)=>s.n >= MIN_BUCKET_N && s.expectancyPct < -2);
    if (worst && st.gate.minScore < clamps.minScore[1]) {
        drafts.push({
            knob: "minScore",
            proposedValue: inClamp("minScore", st.gate.minScore + 5),
            direction: "TIGHTEN",
            rationale: `worst strategy ${worst.strategy}: expectancy ${worst.expectancyPct}%/trade over ${worst.n} settles — admit only higher-confluence setups (+5 MIN_SCORE)`,
            evidence: {
                strategy: worst.strategy,
                n: worst.n,
                expectancyPct: worst.expectancyPct,
                pnlUsd: worst.pnlUsd,
                wins: worst.wins
            }
        });
    }
    // RULE 3 — SHORT book still bleeding (30d window, ≥20 shorts) → shave size further.
    if (st.shortBook.n >= 20 && st.shortBook.pnlUsd < 0 && st.shortBook.expectancyPct < -1.5 && st.gate.shortSizeMult > clamps.shortSizeMult[0]) {
        drafts.push({
            knob: "shortSizeMult",
            proposedValue: inClamp("shortSizeMult", st.gate.shortSizeMult - 0.1),
            direction: "TIGHTEN",
            rationale: `SHORT book 30d: ${st.shortBook.n} settles, ${st.shortBook.expectancyPct}%/trade, net ${st.shortBook.pnlUsd >= 0 ? "+" : ""}$${st.shortBook.pnlUsd} — cut size ×${st.gate.shortSizeMult.toFixed(2)}→×${inClamp("shortSizeMult", st.gate.shortSizeMult - 0.1).toFixed(2)}`,
            evidence: st.shortBook
        });
    }
    // RULE 4 — TTL near-TP pain: many denials where the next TP sat just outside
    // the band AND extensions that ran mostly to TP → widen the band +0.5.
    if (st.ttl.denied >= 8 && st.ttl.deniedNearTp / st.ttl.denied >= 0.4 && st.ttl.tpAfter >= st.ttl.slAfter && st.gate.ttlNearTpPct < clamps.ttlNearTpPct[1]) {
        drafts.push({
            knob: "ttlNearTpPct",
            proposedValue: inClamp("ttlNearTpPct", st.gate.ttlNearTpPct + 0.5),
            direction: "LOOSEN",
            rationale: `${st.ttl.denied} expiry denials, ${st.ttl.deniedNearTp} with next TP inside 2× band (${Math.round(100 * st.ttl.deniedNearTp / st.ttl.denied)}%), extended trades resolve TP ${st.ttl.tpAfter} vs SL ${st.ttl.slAfter} — widen band +0.5%`,
            evidence: {
                denied: st.ttl.denied,
                deniedNearTp: st.ttl.deniedNearTp,
                tpAfter: st.ttl.tpAfter,
                slAfter: st.ttl.slAfter,
                capturedUsd: st.ttl.capturedUsd
            }
        });
    }
    // RULE 5 — rolling drawdown: last 20 settles ≤ −$10 → de-risk the sizing knob.
    if (st.last20PnlUsd <= -10 && st.gate.riskPerTrade > clamps.riskPerTrade[0]) {
        drafts.push({
            knob: "riskPerTrade",
            proposedValue: inClamp("riskPerTrade", st.gate.riskPerTrade - 0.15),
            direction: "TIGHTEN",
            rationale: `last 20 settles sum ${st.last20PnlUsd >= 0 ? "+" : ""}$${st.last20PnlUsd} — drawdown protocol shrinks margin sizing ×${st.gate.riskPerTrade.toFixed(2)}→×${inClamp("riskPerTrade", st.gate.riskPerTrade - 0.15).toFixed(2)}`,
            evidence: {
                last20PnlUsd: st.last20PnlUsd,
                riskPerTrade: st.gate.riskPerTrade
            }
        });
    }
    return drafts;
}
/** A knob is blocked when a PENDING proposal exists, a fresh APPLY is still
 * settling (72h), or two consecutive REJECTs triggered the 7-day cooldown.
 * v10.6 (operator unpin mandate 2026-09-15): REJECTs that were PROCEDURAL
 * (blocked by the operator PIN — applyNote carries "OPERATOR PIN") no longer
 * count toward the anti-flap cooldown. The cooldown exists so the advisor
 * cannot nag after the OPERATOR judged a proposal on its evidence; a PIN block
 * is not such a judgment — it is the old mandate speaking. Without this, an
 * unpinned minScore would stay silently frozen until ~09-22 for rejects the
 * operator never evidentially made. */ async function knobBlocked(knob) {
    const recent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.findMany({
        where: {
            knob
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 6
    });
    if (recent.some((p)=>p.status === "PENDING")) return true;
    const evidential = (p)=>!(p.status === "REJECTED" && (p.applyNote ?? "").includes("OPERATOR PIN"));
    const last = recent.find((p)=>evidential(p));
    if (last?.decidedAt) {
        if (last.status === "APPLIED" && Date.now() - last.decidedAt.getTime() < APPLIED_QUIET_MS) return true;
        if (last.status === "REJECTED") {
            const rejects = recent.filter((p)=>p.status === "REJECTED" && evidential(p));
            const twoConsecutive = rejects.length >= 2 && rejects[0].decidedAt && rejects[1].decidedAt;
            if (twoConsecutive && rejects[0].decidedAt && Date.now() - rejects[0].decidedAt.getTime() < REJECT_COOLDOWN_MS) return true;
        }
    }
    return false;
}
async function expireStale() {
    const cutoff = new Date(Date.now() - STALE_PENDING_MS);
    const r = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.updateMany({
        where: {
            status: "PENDING",
            createdAt: {
                lt: cutoff
            }
        },
        data: {
            status: "EXPIRED",
            decidedAt: new Date()
        }
    });
    return r.count;
}
async function runAdvisorCycle() {
    const state = await getState();
    const st = await gatherLedgerStats();
    const drafts = draftProposals(st);
    let queued = 0;
    let skipped = 0;
    for (const d of drafts){
        if (queued >= MAX_PROPOSALS_PER_CYCLE) break;
        if (d.proposedValue === st.gate[d.knob]) continue; // already at the proposed value
        if (await knobBlocked(d.knob)) {
            skipped++;
            continue;
        }
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.create({
            data: {
                cycle: state.cycles + 1,
                kind: "KNOB_ADJUST",
                knob: d.knob,
                currentValue: st.gate[d.knob],
                proposedValue: d.proposedValue,
                direction: d.direction,
                rationale: d.rationale,
                evidence: JSON.stringify(d.evidence),
                status: "PENDING"
            }
        });
        queued++;
    }
    // BREAKOUT trial PASSING announcement (no knob change — informational, 1/day)
    if (st.gate.breakoutGuard === 1 && st.boExp.n >= BO_EXP_TARGET_N && st.boExp.pf !== null && st.boExp.pf > 1.2 && (!state.lastBoExpVerdictAt || Date.now() - state.lastBoExpVerdictAt > 86_400_000)) {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `AI ADVISOR: BREAKOUT conditional trial PASSING — ${st.boExp.n} BO-EXP settles, PF ${st.boExp.pf} > 1.2 (net +$${st.boExp.pnlUsd}); half-size regime-conditioned deployments stay active`);
        state.lastBoExpVerdictAt = Date.now();
    }
    const expired = await expireStale();
    const nextState = {
        cycles: state.cycles + 1,
        lastRunAt: new Date().toISOString(),
        lastBoExpVerdictAt: state.lastBoExpVerdictAt
    };
    await putState(nextState);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", queued > 0 ? "ai" : "info", `AI ADVISOR cycle #${nextState.cycles}: ${queued} proposal${queued === 1 ? "" : "s"} queued (${skipped} knob${skipped === 1 ? "" : "s"} on cooldown/dedup, ${expired} stale expired) — awaiting OPERATOR approval in AI CORE · ledger: ${st.settled} settled, last-20 ${st.last20PnlUsd >= 0 ? "+" : ""}$${st.last20PnlUsd}`);
    return {
        cycle: nextState.cycles,
        queued,
        skipped,
        stats: st
    };
}
async function maybeRunAdvisor() {
    try {
        const state = await getState();
        if (state.lastRunAt && Date.now() - new Date(state.lastRunAt).getTime() < CYCLE_INTERVAL_MS) return;
        await runAdvisorCycle();
    } catch (e) {
        console.error("[advisor] cycle failed:", e);
    }
}
async function forceRunAdvisor() {
    const r = await runAdvisorCycle();
    return {
        cycle: r.cycle,
        queued: r.queued,
        skipped: r.skipped
    };
}
async function decideProposal(id, approve) {
    const p = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.findUnique({
        where: {
            id
        }
    });
    if (!p) return {
        ok: false,
        error: "proposal not found"
    };
    if (p.status !== "PENDING") return {
        ok: false,
        error: `proposal is ${p.status} — only PENDING can be decided`
    };
    if (!approve) {
        const updated = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.update({
            where: {
                id
            },
            data: {
                status: "REJECTED",
                decidedAt: new Date()
            }
        });
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "info", `AI ADVISOR: proposal #${p.cycle} REJECTED by operator — ${p.knob} ${p.currentValue}→${p.proposedValue} stays untouched (rejection cooldown armed)`);
        void notifyDecision(updated).catch(()=>undefined);
        return {
            ok: true,
            proposal: updated
        };
    }
    const clamps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateClamps"])();
    // v8.4.2 OPERATOR PIN — «ثابت نگه دار»: a pinned minScore is operator-owned.
    // Even an advisor proposal approval may not move it; the operator must lift
    // the pin first (explicit bridge mandate → audited script).
    if (p.knob === "minScore" && (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])()).minScorePinned === 1) {
        const live = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])()).minScore;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.update({
            where: {
                id
            },
            data: {
                status: "REJECTED",
                decidedAt: new Date(),
                applyNote: `OPERATOR PIN active — minScore fixed at ${live} (bridge mandate 2026-09-12); unpin required before any change`
            }
        });
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "info", `AI ADVISOR: proposal #${p.cycle} BLOCKED by OPERATOR PIN — minScore is fixed at ${live} (bridge mandate 2026-09-12 «و ثابت نگه دار»); the operator must lift the pin first`);
        return {
            ok: false,
            error: `minScore is PINNED at ${live} by operator mandate — unpin first`
        };
    }
    // v10.9 APPLY-GUARD (SUPERVISOR proposal 19:08Z, operator-approved 2026-09-15
    // «دستورات سوپروایزر را کامل و مهندسی انجام بده»): config-drift check-before-
    // apply. A proposal is a delta from the live value AT PROPOSAL TIME — if the
    // live knob moved since, applying the stale delta lands on the wrong
    // end-state (real case: cycle-39 proposed 30→35 while live had already moved
    // to 38 = accidental LOOSEN). Re-check live at apply; auto-reject on drift.
    const liveNow = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGateSettings"])();
    const liveKnob = liveNow[p.knob];
    if (typeof liveKnob === "number" && liveKnob !== p.currentValue) {
        const updated = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.update({
            where: {
                id
            },
            data: {
                status: "REJECTED",
                decidedAt: new Date(),
                applyNote: `APPLY-GUARD: live ${p.knob}=${liveKnob} drifted from proposal base ${p.currentValue} — stale proposal auto-rejected (check-before-apply); re-propose from current value`
            }
        });
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "info", `AI ADVISOR: proposal #${p.cycle} AUTO-REJECTED by APPLY-GUARD — live ${p.knob}=${liveKnob} vs proposal base ${p.currentValue} (stale delta would misapply); nothing touched`);
        void notifyDecision(updated).catch(()=>undefined);
        return {
            ok: false,
            error: `stale proposal — live ${p.knob} is ${liveKnob}, proposal based on ${p.currentValue}`
        };
    }
    const [lo, hi] = clamps[p.knob] ?? [
        p.proposedValue,
        p.proposedValue
    ];
    const clampedValue = Math.min(hi, Math.max(lo, p.proposedValue));
    const next = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["putGateSettings"])({
        [p.knob]: clampedValue
    });
    const updated = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.update({
        where: {
            id
        },
        data: {
            status: "APPLIED",
            decidedAt: new Date(),
            appliedAt: new Date(),
            applyNote: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["describeGate"])(next)
        }
    });
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "ENGINE", "ai", `AI ADVISOR: proposal #${p.cycle} APPROVED by operator — ${p.knob} ${p.currentValue}→${clampedValue} applied via governor channel · ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["describeGate"])(next)}`);
    void notifyDecision(updated).catch(()=>undefined);
    return {
        ok: true,
        proposal: updated
    };
}
async function notifyDecision(p) {
    const line = p.status === "APPLIED" ? `✅ ADVISOR APPLY: ${p.knob} ${p.currentValue}→${p.proposedValue} (${p.direction})` : `❌ ADVISOR REJECTED: ${p.knob} ${p.currentValue}→${p.proposedValue} stays`;
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$notify$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sendDirect"])(line);
}
async function advisorSnapshot() {
    const [state, proposals, stats] = await Promise.all([
        getState(),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.findMany({
            orderBy: {
                createdAt: "desc"
            },
            take: 20
        }),
        gatherLedgerStats()
    ]);
    const pending = proposals.filter((p)=>p.status === "PENDING");
    return {
        state,
        pendingCount: pending.length,
        proposals,
        experiment: {
            guard: stats.gate.breakoutGuard,
            cohortN: stats.boExp.n,
            pf: stats.boExp.pf,
            pnlUsd: stats.boExp.pnlUsd,
            targetN: BO_EXP_TARGET_N,
            threshold: 1.2,
            verdict: stats.boExp.n < BO_EXP_TARGET_N ? "COLLECTING" : stats.boExp.pf !== null && stats.boExp.pf > 1.2 ? "PASSING" : "FAILING"
        },
        stats: {
            settled: stats.settled,
            last20PnlUsd: stats.last20PnlUsd,
            strategies: stats.strategies,
            shortBook: stats.shortBook
        }
    };
}
async function advisorCaptionBlock() {
    try {
        const pending = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.findMany({
            where: {
                status: "PENDING"
            },
            orderBy: {
                createdAt: "desc"
            },
            take: 2
        });
        if (pending.length === 0) return "🧠 <b>AI ADVISOR</b>: no pending proposals — calibration queue empty";
        const lines = pending.map((p)=>`• <b>${p.direction}</b> ${p.knob.replace(/([A-Z])/g, " $1").toLowerCase()}: ${p.currentValue}→${p.proposedValue}`);
        return `🧠 <b>AI ADVISOR</b> — ${pending.length} proposal${pending.length > 1 ? "s" : ""} awaiting your APPROVE (AI CORE panel):\n${lines.join("\n")}`;
    } catch  {
        return "";
    }
}
}),
"[project]/src/lib/senior-review.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSeniorReviewState",
    ()=>getSeniorReviewState,
    "maybeRunSeniorReview",
    ()=>maybeRunSeniorReview,
    "runSeniorReview",
    ()=>runSeniorReview
]);
// ── FlowRadar Neo v9.6 — DAILY SENIOR-REVIEW (R6, nightly agent) ────────────
// Operator-approved module #4 (roadmap R6, mandate 2026-09-15): a 24h
// senior-engineer agent that runs ONCE per Tehran night, after the 00:00
// daily report, and produces a STRUCTURED AUDIT of the whole desk:
//   1. READ: ledger stats (strategies / short book / TTL / last-20), RAW-CAL
//      campaign state, the three sibling shadow modules (risk-governor,
//      time-governor, ui-canary), pump-radar performance digest, advisor
//      queue pressure.
//   2. PROPOSE: at most 3 PENDING AdvisorProposals per run — evidence-backed
//      knob changes through the SAME blocked/proposal channel the advisor
//      uses (pending guard, cooldowns respected) — never applied by itself.
//   3. REPORT: one Telegram digest (no '<' chars) + audited ENGINE event.
// Read-only toward the engine core; clamps enforced via gateClamps().
//
// Deterministic — no LLM call; the "senior engineer" here is the measured
// evidence itself.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/gate-settings.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$notify$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/notify.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$advisor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/advisor.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fourpack-journal.ts [app-route] (ecmascript)"); // v10.8 — FOUR-PACK JSON journal doctrine
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$risk$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/risk-governor.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$time$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/time-governor.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ui$2d$canary$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ui-canary.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const KEY = "seniorreview.state";
const MAX_PROPOSALS = 3;
const APPLIED_QUIET_MS = 72 * 3600_000;
const REJECT_COOLDOWN_MS = 7 * 86_400_000;
const EMPTY = {
    at: 0,
    cycles: 0,
    lastRunAt: null,
    lastDayKey: null,
    report: null,
    tg: null
};
function tehranNow() {
    const t = new Date(Date.now() + 3.5 * 3600_000);
    return {
        hour: t.getUTCHours(),
        dayKey: `${t.getUTCFullYear()}-${String(t.getUTCMonth() + 1).padStart(2, "0")}-${String(t.getUTCDate()).padStart(2, "0")}`
    };
}
async function getState() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: KEY
            }
        });
        if (row) return {
            ...EMPTY,
            ...JSON.parse(row.value)
        };
    } catch  {
    /* fresh */ }
    return {
        ...EMPTY
    };
}
async function putState(next) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: KEY
        },
        create: {
            key: KEY,
            value: JSON.stringify(next)
        },
        update: {
            value: JSON.stringify(next)
        }
    });
}
// ── proposal channel (advisor-compatible guards, local implementation) ──────
async function knobBlocked(knob) {
    const recent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.findMany({
        where: {
            knob
        },
        orderBy: {
            createdAt: "desc"
        },
        take: 4
    });
    if (recent.some((p)=>p.status === "PENDING")) return true;
    const last = recent.find((p)=>p.status === "APPLIED" || p.status === "REJECTED");
    if (last?.decidedAt) {
        if (last.status === "APPLIED" && Date.now() - last.decidedAt.getTime() < APPLIED_QUIET_MS) return true;
        if (last.status === "REJECTED") {
            const rejects = recent.filter((p)=>p.status === "REJECTED");
            const two = rejects.length >= 2 && rejects[0].decidedAt && rejects[1].decidedAt;
            if (two && rejects[0].decidedAt && Date.now() - rejects[0].decidedAt.getTime() < REJECT_COOLDOWN_MS) return true;
        }
    }
    return false;
}
function clamped(knob, v) {
    const [lo, hi] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateClamps"])()[knob];
    return Math.min(hi, Math.max(lo, Math.round(v * 100) / 100));
}
function draftFromEvidence(st, risk) {
    const drafts = [];
    const gate = st.gate;
    const clamps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$gate$2d$settings$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateClamps"])();
    // A — worst strategy bleed (≥12 settles, exp < −2%/trade) → admit higher confluence only
    const worst = st.strategies.find((s)=>s.n >= 12 && s.expectancyPct < -2);
    if (worst && gate.minScore < clamps.minScore[1]) {
        drafts.push({
            knob: "minScore",
            proposedValue: clamped("minScore", gate.minScore + 5),
            rationale: `senior-review: worst strategy ${worst.strategy} expectancy ${worst.expectancyPct}%/trade over ${worst.n} settles — MIN_SCORE +5 admits only higher-confluence setups`,
            evidence: {
                strategy: worst.strategy,
                n: worst.n,
                expectancyPct: worst.expectancyPct,
                pnlUsd: worst.pnlUsd
            }
        });
    }
    // B — SHORT book bleed (≥20 settles in 30d) → shave size further
    if (st.shortBook.n >= 20 && st.shortBook.pnlUsd < 0 && st.shortBook.expectancyPct < -1.5 && gate.shortSizeMult > clamps.shortSizeMult[0]) {
        drafts.push({
            knob: "shortSizeMult",
            proposedValue: clamped("shortSizeMult", gate.shortSizeMult - 0.1),
            rationale: `senior-review: SHORT book 30d ${st.shortBook.n} settles, ${st.shortBook.expectancyPct}%/trade, net $${st.shortBook.pnlUsd} — size ×${gate.shortSizeMult.toFixed(2)}→×${clamped("shortSizeMult", gate.shortSizeMult - 0.1).toFixed(2)}`,
            evidence: st.shortBook
        });
    }
    // C — drawdown protocol on the last-20 slope
    if (st.last20PnlUsd <= -10 && gate.riskPerTrade > clamps.riskPerTrade[0]) {
        drafts.push({
            knob: "riskPerTrade",
            proposedValue: clamped("riskPerTrade", gate.riskPerTrade - 0.15),
            rationale: `senior-review: last 20 settles ${st.last20PnlUsd <= 0 ? "" : "+"}$${st.last20PnlUsd} — drawdown protocol shrinks sizing ×${gate.riskPerTrade.toFixed(2)}→×${clamped("riskPerTrade", gate.riskPerTrade - 0.15).toFixed(2)}`,
            evidence: {
                last20PnlUsd: st.last20PnlUsd,
                riskPerTrade: gate.riskPerTrade
            }
        });
    }
    // D — risk-governor heavy-defensive persistent → levered risk cap to the evidence band
    if (risk && risk.verdict === "HEAVY-DEFENSIVE" && risk.streak >= 2 && gate.leveredRiskCap > 15) {
        drafts.push({
            knob: "leveredRiskCap",
            proposedValue: 15,
            rationale: `senior-review: risk-governor HEAVY-DEFENSIVE ×${risk.streak} cycles (DD ${risk.inputs.drawdownPct}%, slope ${risk.inputs.slope20?.pnlUsd ?? "?"}$) — trim levered risk cap ${gate.leveredRiskCap} → 15 (10-15x evidence band)`,
            evidence: {
                verdict: risk.verdict,
                streak: risk.streak,
                drawdownPct: risk.inputs.drawdownPct,
                atrPct: risk.inputs.atrPct
            }
        });
    }
    return drafts;
}
async function runSeniorReview() {
    const prev = await getState();
    const sections = [];
    const proposalsQueued = [];
    const skippedKnobs = [];
    // 1 — ledger
    const st = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$advisor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gatherLedgerStats"])();
    const worst = st.strategies.find((s)=>s.n >= 12 && s.expectancyPct < -2) ?? null;
    sections.push({
        title: "LEDGER",
        lines: [
            `settled ${st.settled} · last-20 ${st.last20PnlUsd >= 0 ? "+" : ""}$${st.last20PnlUsd} · SHORT 30d ${st.shortBook.n} / ${st.shortBook.pnlUsd >= 0 ? "+" : ""}$${st.shortBook.pnlUsd} (${st.shortBook.expectancyPct}%/trade)`,
            worst ? `worst strategy ${worst.strategy}: ${worst.expectancyPct}%/trade over ${worst.n} = $${worst.pnlUsd}` : "no strategy bucket below −2%/trade"
        ]
    });
    // 2 — RAW-CAL
    const dayAgo = new Date(Date.now() - 86_400_000);
    const [open, settled24] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: [
                        "ACTIVE",
                        "TP1",
                        "TP2"
                    ]
                },
                tags: {
                    contains: "RAW-CAL"
                }
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].signal.count({
            where: {
                status: {
                    in: [
                        "TP1",
                        "TP2",
                        "TP3",
                        "SL",
                        "EXPIRED",
                        "CLOSED"
                    ]
                },
                tags: {
                    contains: "RAW-CAL"
                },
                closedAt: {
                    gte: dayAgo
                }
            }
        })
    ]);
    const rawcalNote = `RAW-CAL: ${open} open · ${settled24} settled in 24h`;
    sections.push({
        title: "RAW-CAL",
        lines: [
            rawcalNote
        ]
    });
    // 3 — sibling modules
    const [risk, time, canary] = await Promise.all([
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$risk$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRiskGovernorState"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$time$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTimeGovernorState"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ui$2d$canary$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCanaryState"])()
    ]);
    if (risk.cycles > 0) {
        sections.push({
            title: "RISK GOVERNOR",
            lines: [
                `verdict ${risk.verdict} ×${risk.sizeMult} (streak ${risk.streak}) — ${risk.reasons[0] ?? "baseline"}`
            ]
        });
    }
    if (time.cycles > 0) {
        sections.push({
            title: "TIME GOVERNOR",
            lines: [
                time.line
            ]
        });
    }
    if (canary.cycles > 0) {
        sections.push({
            title: "UI-CANARY",
            lines: [
                `${canary.verdict} — ${canary.line}`
            ]
        });
    }
    // 3.5 — sentinel (v10.21.2): operator finding «چرا به گزارش خطای System Sentinel
    // توجه نمیشه؟» — the sentinel's steady-state verdicts were consumed by NOBODY
    // (files only; pages fire only on the verdict flip; the night audit never read
    // it). Now the nightly audit reads .data/sentinel/latest.json best-effort.
    let sentinel = null;
    try {
        const raw = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(process.cwd(), ".data", "sentinel", "latest.json"), "utf8");
        const j = JSON.parse(raw);
        if (j.verdict) {
            const down = (j.services ?? []).filter((s)=>!s.up).map((s)=>s.label ?? "?");
            const anomalies = (j.anomalies ?? []).slice(0, 3).map((a)=>`${a.sev ?? "?"}: ${a.msg ?? "?"}`);
            sections.push({
                title: "SENTINEL",
                lines: [
                    `verdict ${j.verdict}${anomalies.length ? ` — ${anomalies.join(" · ")}` : " — no anomalies"}`,
                    down.length ? `services DOWN: ${down.join(", ")}` : `all ${j.services?.length ?? 0} services up`
                ]
            });
            sentinel = {
                verdict: j.verdict,
                anomalies: (j.anomalies ?? []).length,
                servicesDown: down.length
            };
        }
    } catch  {
    /* sentinel never ran — fail-open, the audit must not break */ }
    // 3.6 — FUTURES TAXONOMY (v10.22, operator mandate «جمع‌آوری داده → ذخیره →
    // یادگیری → بهترین فیلتر»): the night audit now reads the five-family store
    // + edge study, so the operator sees collection maturity and the current
    // best-filter candidate in every nightly Telegram report. Best-effort,
    // fail-open — a cold store must never break the audit.
    let futures = null;
    try {
        const m = await __turbopack_context__.A("[project]/src/lib/futures-taxonomy.ts [app-route] (ecmascript, async loader)");
        const edge = await m.buildFuturesEdge();
        const qLine = edge.quadrantStudy.map((q)=>`${q.quadrant.replace(/^Q(\d)_.*/, "Q$1")} ${q.verdict} ${q.meanFwd1h >= 0 ? "+" : ""}${q.meanFwd1h}% (n=${q.n})`).join(" · ");
        const lines = [
            `store ${edge.rowsScanned} rows · settled fwd1h ${edge.settledRows}/${edge.maturity.target} (${edge.maturity.progressPct}%)`,
            qLine || "quadrant study: no settled rows yet",
            edge.bestFilter ? `best filter [${edge.bestFilter.source}] ${edge.bestFilter.filter} — edge ${edge.bestFilter.edge} (n=${edge.bestFilter.n}, ${edge.bestFilter.confidence})` : `best filter: COLLECTING (${edge.maturity.settled}/${edge.maturity.target} settled)`,
            edge.attribution.joined > 0 ? `signal attribution: ${edge.attribution.joined} settled signals joined to quadrant context` : "signal attribution: waiting for settled signals"
        ];
        sections.push({
            title: "FUTURES TAXONOMY",
            lines
        });
        futures = {
            rows: edge.rowsScanned,
            settled: edge.settledRows,
            bestFilter: edge.bestFilter ? `${edge.bestFilter.filter} (${edge.bestFilter.edge})` : null,
            quadrantTop: edge.quadrantStudy.length ? edge.quadrantStudy.map((q)=>`${q.quadrant}:${q.meanFwd1h}`).join(",") : null
        };
    } catch  {
    /* futures module never ran — fail-open */ }
    // 3.7 — TELEGRAM INTAKE (v10.23, operator finding «پل تلگرام پیام های ارسالی
    // به محیط سندباکس را نمی خواند»): operator Telegram messages were ingested +
    // LLM-answered but never reached the engineering agent — they died silently
    // in the transcript. The v8.4 ops-intake queue now feeds the night audit:
    // every open item is listed here so an unread operator mandate can never
    // rot for a full day again. Best-effort, fail-open.
    let telegramIntake = null;
    try {
        const { readOpenTasks, countOpenTasks } = await __turbopack_context__.A("[project]/src/lib/telegram-bridge.ts [app-route] (ecmascript, async loader)");
        const openTasks = readOpenTasks(5);
        const open = countOpenTasks();
        sections.push({
            title: "TELEGRAM INTAKE",
            lines: [
                open === 0 ? "queue empty — every operator message picked up" : `${open} OPEN task(s) waiting for the agent`,
                ...openTasks.map((t)=>`${t.id}: ${t.text.slice(0, 90)}${t.text.length > 90 ? "…" : ""}`)
            ]
        });
        telegramIntake = {
            open,
            oldestAgeH: openTasks.length ? Math.round((Date.now() - openTasks[0].ts) / 3_600_000 * 10) / 10 : 0
        };
    } catch  {
    /* bridge module cold — fail-open */ }
    // 4 — proposals (≤3, advisor-compatible guards)
    const drafts = draftFromEvidence(st, risk.cycles > 0 ? risk : null);
    for (const d of drafts){
        if (proposalsQueued.length >= MAX_PROPOSALS) break;
        if (await knobBlocked(d.knob)) {
            skippedKnobs.push(d.knob);
            continue;
        }
        const target = clamped(d.knob, d.proposedValue);
        if (Math.abs(target - st.gate[d.knob]) < 0.01) continue;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.create({
            data: {
                cycle: -1,
                kind: "KNOB_ADJUST",
                knob: d.knob,
                currentValue: st.gate[d.knob],
                proposedValue: target,
                direction: target < st.gate[d.knob] ? "TIGHTEN" : "LOOSEN",
                rationale: d.rationale,
                evidence: JSON.stringify({
                    source: "senior-review",
                    ...d.evidence
                })
            }
        });
        proposalsQueued.push({
            knob: d.knob,
            from: st.gate[d.knob],
            to: target,
            rationale: d.rationale
        });
    }
    const pendingCount = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].advisorProposal.count({
        where: {
            status: "PENDING"
        }
    });
    sections.push({
        title: "PROPOSALS",
        lines: [
            proposalsQueued.length ? `${proposalsQueued.length} queued: ${proposalsQueued.map((p)=>`${p.knob} ${p.from}→${p.to}`).join(" · ")}` : "no new proposal (guards/cooldowns)",
            skippedKnobs.length ? `skipped (pending/cooldown): ${skippedKnobs.join(", ")}` : `advisor queue: ${pendingCount} PENDING`
        ]
    });
    const report = {
        at: new Date().toISOString(),
        ledger: {
            settled: st.settled,
            last20PnlUsd: st.last20PnlUsd,
            shortBook: st.shortBook,
            worst: worst ? {
                strategy: worst.strategy,
                n: worst.n,
                expectancyPct: worst.expectancyPct,
                pnlUsd: worst.pnlUsd
            } : null
        },
        rawcal: {
            open,
            settled24h: settled24,
            note: rawcalNote
        },
        sentinel,
        futures,
        telegramIntake,
        riskGovernor: risk.cycles > 0 ? {
            verdict: risk.verdict,
            sizeMult: risk.sizeMult,
            streak: risk.streak
        } : null,
        timeGovernor: time.cycles > 0 ? {
            toxicHours: time.toxicHours,
            primeHours: time.primeHours,
            estUpliftUsd: time.estUpliftUsd
        } : null,
        canary: canary.cycles > 0 ? {
            verdict: canary.verdict,
            line: canary.line
        } : null,
        proposalsQueued,
        skippedKnobs
    };
    const state = {
        at: Date.now(),
        cycles: prev.cycles + 1,
        lastRunAt: new Date().toISOString(),
        lastDayKey: tehranNow().dayKey,
        report,
        tg: null
    };
    // 5 — audit + Telegram digest
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "SYSTEM", "ai", `SENIOR-REVIEW night audit complete — ${sections.map((s)=>s.title).join(" / ")}${proposalsQueued.length ? ` · ${proposalsQueued.length} proposal(s) queued` : ""}`).catch(()=>undefined);
    // v10.8 journal doctrine — the nightly audit is a first-class journal event
    void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fourpack$2d$journal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["recordFourPack"])("r6-senior-review", "audit", `night audit — ${sections.map((s)=>s.title).join(" / ")}${proposalsQueued.length ? ` · ${proposalsQueued.length} proposal(s) queued: ${proposalsQueued.map((p)=>`${p.knob} ${p.from}→${p.to}`).join(", ")}` : " · no new proposal"}`, {
        settled: st.settled,
        last20PnlUsd: st.last20PnlUsd,
        proposalsQueued,
        skippedKnobs,
        riskGovernor: risk.cycles > 0 ? risk.verdict : null,
        canary: canary.cycles > 0 ? canary.verdict : null
    }).catch(()=>undefined);
    const tgLines = [
        "FlowRadar Neo — SENIOR REVIEW (nightly audit)",
        ""
    ];
    for (const s of sections)tgLines.push(`${s.title}:`, ...s.lines.map((l)=>`· ${l}`), "");
    tgLines.push("Approve/reject in AI CORE advisor panel or via Telegram.");
    const tg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$notify$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sendDirect"])(tgLines.join("\n")).catch((e)=>({
            ok: false,
            error: e instanceof Error ? e.message : "tg failed"
        }));
    state.tg = {
        ok: tg.ok,
        error: tg.ok ? null : tg.error ?? "failed"
    };
    await putState(state);
    return state;
}
async function getSeniorReviewState() {
    return getState();
}
/** Nightly window check — runs once per Tehran day, after the 00:00 report. */ let checking = false;
async function maybeRunSeniorReview() {
    if (checking) return;
    checking = true;
    try {
        const { hour, dayKey } = tehranNow();
        // window: 00:00–05:59 Tehran, once per day key
        if (hour >= 6) return;
        const state = await getState();
        if (state.lastDayKey === dayKey) return;
        await runSeniorReview();
    } catch  {
    /* fail-open — the nightly audit must never break the tick */ } finally{
        checking = false;
    }
}
}),
"[project]/src/lib/shadow-modules.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MODULES",
    ()=>MODULES,
    "getMode",
    ()=>getMode,
    "getShadowModulesSnapshot",
    ()=>getShadowModulesSnapshot,
    "maybeRunShadowModules",
    ()=>maybeRunShadowModules,
    "putMode",
    ()=>putMode,
    "runModuleNow",
    ()=>runModuleNow
]);
// ── FlowRadar Neo v10.0 — SHADOW MODULES REGISTRY (server-only) ─────────────
// Single registry + scheduler for the four operator-approved modules
// (mandate 2026-09-15: «اجرای چهار ماژول را مهندسی شده و کامل انجام بده»):
//   · R1 RISK GOVERNOR  — sizing verdict by regime/vol/drawdown slope, CHOP
//     bleed + 0.5x replay + 10-15x de-leverage evidence; SHADOW journals and
//     queues clamped AdvisorProposals / ENGAGED applies via the clamped gate
//     channel (≥6h apart, audited).
//   · R2 TIME GOVERNOR  — Tehran-hour realized table, TOXIC/PRIME tiers with
//     size weights (×0.5–×1.1); honest-shadow advisory (no hour knob exists —
//     deploy-path wiring is a separate operator decision).
//   · R5 UI-CANARY      — black-box probes of pulse / rawcal / flows /
//     ai-memory / bridge with payload-shape checks; ENGAGED pages Telegram
//     after 3 consecutive RED verdicts.
//   · R6 SENIOR-REVIEW  — nightly Tehran audit agent; ≤3 advisor-compatible
//     PENDING proposals per run + one Telegram digest; always read-only.
//
// The operator authority mode is ONE global switch (EngineSetting
// "governor-modules.mode", default SHADOW) — /api/governors + the
// GOVERNOR MODULES card and the engine rail below all read the same key.
// Shadow-first doctrine: modules never touch the engine deploy path.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$risk$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/risk-governor.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$time$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/time-governor.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ui$2d$canary$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ui-canary.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$senior$2d$review$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/senior-review.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript) <locals>");
;
;
;
;
;
;
const MODE_KEY = "governor-modules.mode";
const MODULES = [
    {
        id: "risk-governor",
        label: "RISK GOVERNOR",
        roadmap: "R1",
        desc: "Sizing verdict by regime × volatility × drawdown slope. CHOP bleed, 0.5x replay and the 10-15x de-leverage band are the grounding evidence.",
        engagedEffect: "applies riskPerTrade (and heavy-defense leveredRiskCap trim) through the clamped gate channel, ≥6h apart, audited"
    },
    {
        id: "time-governor",
        label: "TIME GOVERNOR",
        roadmap: "R2",
        desc: "24h Tehran realized-performance table with TOXIC/PRIME tiers and per-hour size weights (×0.5–×1.1).",
        engagedEffect: "weights marked ACTIVE in the verdict + senior-review digest; deploy-path hour wiring stays operator-gated (no hour knob exists)"
    },
    {
        id: "ui-canary",
        label: "UI-CANARY",
        roadmap: "R5",
        desc: "Lightweight visual watchdog: black-box probes of the dashboard data plane with payload-shape validation.",
        engagedEffect: "pages Telegram after 3 consecutive RED verdicts (≥6h between pages)"
    },
    {
        id: "senior-review",
        label: "SENIOR-REVIEW",
        roadmap: "R6",
        desc: "Nightly Tehran audit agent: ledger + RAW-CAL + the three sibling modules, queues ≤3 evidence-backed AdvisorProposals.",
        engagedEffect: "always read-only; its proposals flow through the standard advisor approve/reject channel"
    }
];
async function getMode() {
    try {
        const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.findUnique({
            where: {
                key: MODE_KEY
            }
        });
        if (row && JSON.parse(row.value).mode === "ENGAGED") return "ENGAGED";
    } catch  {
    /* default SHADOW */ }
    return "SHADOW";
}
async function putMode(mode) {
    const prev = await getMode();
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].engineSetting.upsert({
        where: {
            key: MODE_KEY
        },
        create: {
            key: MODE_KEY,
            value: JSON.stringify({
                mode,
                at: Date.now()
            })
        },
        update: {
            value: JSON.stringify({
                mode,
                at: Date.now()
            })
        }
    });
    if (prev !== mode) {
        const label = mode === "ENGAGED" ? MODULES.map((m)=>m.id === "senior-review" ? null : m.label).filter(Boolean).join("/") : "SHADOW-FIRST";
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fireEvent"])(null, null, "SYSTEM", mode === "ENGAGED" ? "success" : "info", `SHADOW MODULES authority → ${mode} by operator — ${label} ${mode === "ENGAGED" ? "empowered (clamped, audited)" : "observe-and-propose only"}`).catch(()=>undefined);
    }
}
async function getShadowModulesSnapshot() {
    const [mode, riskGovernor, timeGovernor, canary, seniorReview] = await Promise.all([
        getMode(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$risk$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRiskGovernorState"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$time$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTimeGovernorState"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ui$2d$canary$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCanaryState"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$senior$2d$review$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getSeniorReviewState"])()
    ]);
    return {
        mode,
        riskGovernor,
        timeGovernor,
        canary,
        seniorReview
    };
}
// ── scheduler (engine tick entry — fire-and-forget) ─────────────────────────
let running = false;
async function maybeRunShadowModules() {
    if (running) return;
    running = true;
    try {
        const mode = await getMode();
        await Promise.allSettled([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ui$2d$canary$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["maybeRunCanary"])(mode),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$risk$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["maybeRunRiskGovernor"])(mode),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$time$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["maybeRunTimeGovernor"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$senior$2d$review$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["maybeRunSeniorReview"])()
        ]);
    } catch  {
    /* never break the tick */ } finally{
        running = false;
    }
}
async function runModuleNow(id) {
    const mode = await getMode();
    switch(id){
        case "risk-governor":
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$risk$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["runRiskGovernor"])(mode);
            return {
                ok: true
            };
        case "time-governor":
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$time$2d$governor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["runTimeGovernor"])();
            return {
                ok: true
            };
        case "ui-canary":
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ui$2d$canary$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["runCanary"])(mode);
            return {
                ok: true
            };
        case "senior-review":
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$senior$2d$review$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["runSeniorReview"])();
            return {
                ok: true
            };
        default:
            return {
                ok: false,
                error: "unknown module"
            };
    }
}
}),
];

//# sourceMappingURL=src_lib_fc98a463._.js.map