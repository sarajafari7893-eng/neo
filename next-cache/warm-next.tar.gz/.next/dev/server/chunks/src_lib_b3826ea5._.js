module.exports = [
"[project]/src/lib/raw-cal.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_lib_7c56381c._.js",
  "server/chunks/[root-of-the-server]__7c418860._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/raw-cal.ts [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/notify.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__9c8ae4f1._.js",
  "server/chunks/[externals]_sharp_6b522068._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/lib/notify.ts [app-route] (ecmascript)");
    });
});
}),
];