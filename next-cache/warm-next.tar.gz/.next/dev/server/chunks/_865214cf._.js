module.exports = [
"[project]/node_modules/z-ai-web-dev-sdk/dist/index.js [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__fdc7b6b3._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/z-ai-web-dev-sdk/dist/index.js [app-route] (ecmascript)");
    });
});
}),
"[project]/src/lib/verdict.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/lib/verdict.ts [app-route] (ecmascript)");
    });
});
}),
];