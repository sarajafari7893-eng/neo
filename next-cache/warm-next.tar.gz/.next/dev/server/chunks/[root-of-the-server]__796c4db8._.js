module.exports = [
"[project]/src/lib/db.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)");
;
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$29$__["PrismaClient"]({
    log: [
        'warn',
        'error'
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = db;
// ── v6.2 SQLite durability/perf pragmas (architecture review P2: WAL) ──
// The engine writes on every 4s tick (prices, price points, events) while
// readers poll continuously; the default rollback journal serializes writers
// against readers and occasionally surfaces "database is locked". WAL mode
// allows concurrent readers with a single writer. Applied once per process,
// best-effort — a failure here must never take the pulse down.
if (!globalForPrisma.__nexusPragmasApplied) {
    globalForPrisma.__nexusPragmasApplied = true;
    void (async ()=>{
        try {
            await db.$queryRawUnsafe('PRAGMA journal_mode=WAL;');
            // NB: SQLite PRAGMAs RETURN a row, so every one must go through
            // $queryRawUnsafe — $executeRawUnsafe rejects statements that return
            // results ("Execute returned results, which is not allowed in SQLite").
            await db.$queryRawUnsafe('PRAGMA synchronous=NORMAL;');
            await db.$queryRawUnsafe('PRAGMA busy_timeout=5000;');
            console.log('[db] SQLite pragmas applied — journal_mode=WAL, synchronous=NORMAL, busy_timeout=5000');
        } catch (e) {
            console.error('[db] pragma application failed (continuing with defaults):', e);
        }
    })();
}
}),
"[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "configureFapiGate",
    ()=>configureFapiGate,
    "effectiveBudgetPer60s",
    ()=>effectiveBudgetPer60s,
    "fapiBanActivity",
    ()=>fapiBanActivity,
    "fapiBanRemainingMs",
    ()=>fapiBanRemainingMs,
    "fapiEgressStatus",
    ()=>fapiEgressStatus,
    "fapiGateStats",
    ()=>fapiGateStats,
    "gateFetch",
    ()=>gateFetch,
    "isUnknownScopeKey",
    ()=>isUnknownScopeKey,
    "sampleEgressIp",
    ()=>sampleEgressIp
]);
// ── NEXUS//SIGNALS FAPI GATE (server-only, v10.24 — Task 34-a) ──────────────
// Process-wide WEIGHT-BASED token bucket for Binance USDT-M futures REST
// (fapi.binance.com). WHY: 9+ modules in the Next.js process each did their own
// uncoordinated fetch() to the same host and the trade mini-service added
// ~1800 weight/min on top → Binance answered with HTTP 418 IP-bans carrying
// stacked multi-hour "banned until <ms>" windows. This gate is the single
// choke-point every futures-REST call in THIS process must pass:
//
//   · WEIGHT BUDGET — rolling-60s sliding window, default 1100 weight/min
//     (fapi real limit is 2400/min per IP; ~2× headroom absorbs drift between
//     weight estimates and the ungated mini-service until Task 34-b).
//   · LANES — "critical" (engine price feed, trigger measurements) executes
//     immediately when tokens exist, with ONE small negative retry after
//     250ms when momentarily empty; "telemetry" (every rotating scanner/
//     sampler/board) is DROPPED (returns null) when tokens are missing —
//     no unbounded queues, no storm amplification. All callers are
//     null-tolerant by contract.
//   · GLOBAL BAN AWARENESS (refined for the multi-IP egress pool — measured
//     2026-09-26: the sandbox egress rotates across several IPs and Binance's
//     418 body NAMES the banned one: «IP(47.57.x.x) banned until <ms>», with
//     different pool IPs banned in different windows):
//       – 418/429 body naming an IP → PER-IP ban record (capped now+35min),
//         the request's weight is REFUNDED (ban responses carry no weight
//         cost) and the call RETRIES (≤2, 120ms apart) — the pool usually
//         rotates onto a clean IP, so one unlucky draw never starves the app.
//       – ALL retries land on banned IPs → one unlucky draw too many: arm a
//         SHORT 60s global block, and only when that happens 3 times IN A ROW
//         (no successful call between) treat the pool as saturated and arm the
//         full zero-network window min(worst ban end, now+35min). A single
//         clean 2xx resets the streak — self-healing probes.
//       – 418/429 body WITHOUT a parseable IP (unknown scope — the classic
//         single-IP case): arm the global zero-network window immediately —
//         "banned until X" → min(X, now+35min); unparseable 418 → 10min;
//         unparseable 429 → 2min.
//       – While the global window is live, gateFetch returns null INSTANTLY —
//         zero network calls, so a live ban can never be extended by us.
//   · SINGLE-FLIGHT — one shared request per (host,path) while in flight and
//     for a 2s result window, so multiple modules asking the same endpoint
//     inside one tick share one weight spend.
//   · HOST AWARENESS — default host fapi.binance.com, optional alt host
//     (fapi1) for the market-feed availability ladder; bans/weight are
//     per-IP so both hosts share the SAME budget and ban state.
//
// NEVER THROWS: gateFetch returns parsed JSON or null on any failure.
// State lives on globalThis so Turbopack's dev module-graph duplication
// (route graph vs engine graph) still shares ONE process-wide bucket.
//
// SPOT (api.binance.com) and mirror-plane hosts (v14.0 Binance-only) must
// NOT pass through here — futures fapi host only.
//
// ── v12.0 EGRESS/IP MANAGER (Task 44-②, operator order «مدیریت egress/IP
// برای رفع بن fapi») ──────────────────────────────────────────────────────────
// Measured 2026-10-18: the sandbox egress is a rotating NAT pool and Binance
// bans POOL IPs with LONG windows (three named IPs banned until 10-18 19:47Z /
// 22:37Z / 10-19 13:26Z — each plain request is a lottery draw). Three new
// weapons:
//   1. EGRESS SAMPLER — api.ipify.org probe (3.5s timeout, 120s cache,
//      single-flight, never throws) tells us WHICH pool IP a draw exited from.
//   2. ROTATION-AWARE EARLY PROBE — while a global ban window is live, ONE
//      critical-lane call per 120s may bypass the silence IF the sampled IP is
//      clean: the moment the pool rotates, the window LIFTS instantly instead
//      of waiting out the 35min cap. A failed probe costs nothing (banned
//      responses carry no weight) and keeps the window armed.
//   3. BAN-LEDGER PERSISTENCE — named-IP ban records survive process
//      restarts (.data/fapi-gate/bans.json, 30s debounced) so a recycle no
//      longer re-learns the minefield by burning fresh probes.
//
// v10.25 (Task 41, operator order «بایننس ای پی را بلاک نکرده باشد و قابل
// جایگزینی باشد»): the host is env-swappable WITHOUT a code change — if fapi
// is ever hard-blocked (451/region/grey-list, not just a timed 418), set
// NEXUS_FAPI_HOST in .env to a reachable futures-mirror and restart the app.
// Default stays the canonical host. Downstream replaceability ladder is
// already layered: fapi-gate (this) → SPOT-MIRROR aggTrade WS → spot REST
// klines/price fallback → Binance-only liq lanes (v14.0).
//
// ── v14.2 BAN-AWARE RECOVERY PACER (operator order «توصیه‌ها را کامل و مهندسی
// انجام بده», trace 1a1a15fb6bc0bd75 — audit rec #3 «throttle REST بن-آگاه»,
// NX-3247 forensics fc143950) ───────────────────────────────────────────────
// WHY: the old budget was FLAT — the instant a ban window expired the full
// 1100 weight/min came back at once, every starved scanner refilled its
// rotation in the same minute, and the pool re-saturated into a fresh 418
// spiral (measured 10-19: 11:58Z→12:34Z→13:09Z pause spiral). The pacer:
//   · RECOVERY RAMP — for 10min after a global ban window ends, the effective
//     budget ramps 25%→100% linearly. Early recovery minutes carry the
//     CRITICAL lane first (engine price feed / triggers), telemetry scanners
//     stretch back out gradually instead of stampeding.
//   · POOL-DISTRESS CAP — while ≥2 named egress IPs sit inside live ban
//     windows (the 10-18 measurement: 3 named IPs banned simultaneously),
//     the effective budget is capped at 50% — fewer lottery draws, less ban
//     pressure, named-IP evidence stays intel-shaped.
// CRITICAL lane keeps its negative retry; the floor (200/min) is the same
// clamp configureFapiGate enforces, so the pacer can never zero the plane.
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
;
const FAPI_HOST = process.env.NEXUS_FAPI_HOST?.trim().replace(/\/+$/, "") || "https://fapi.binance.com";
const DEFAULT_TIMEOUT_MS = 6500;
const WINDOW_MS = 60_000;
const DEFAULT_BUDGET = 1100; // real fapi limit 2400/min per IP — headroom by design
const BAN_CAP_MS = 35 * 60_000; // never record a ban window longer than 35min even if Binance claims hours
// v12.6.1 — mixed-pool era: an UNPARSEABLE 418 is evidence of ONE banned draw,
// not a pool-wide ban (measured 2026-10-20 19:32Z: boot's first draw 418'd
// unparseable while 6/10 fresh connections succeeded — the old 10min arm
// locked the whole app out of a majority-clean pool). 2min + the streak
// escalation ladder covers true saturation.
const BAN_418_DEFAULT_MS = 2 * 60_000; // unparseable 418 → short backoff (was 10min — pool-starvation lesson)
const BAN_429_DEFAULT_MS = 2 * 60_000; // unparseable 429 → short warning backoff
const CRITICAL_RETRY_MS = 250; // the "small negative retry" for the critical lane
const SF_RESULT_MS = 2_000; // single-flight result sharing window
const SF_MAP_CAP = 512;
const SPEND_CAP = 4096; // defensive cap on window entries (~worst-case small-weight bursts)
const BAN_RETRIES = 3; // extra attempts after a named-IP ban (pool rotation)
// v12.6.2 ESCALATING RETRY CADENCE: the NAT egress mapping rotates over ~30s
// (measured 2026-10-20 19:41Z: keep-alive 6×418 → 30s later 6×200), so three
// retries 120ms apart shared ONE doomed mapping. Spacing the retries across
// it (120ms → 2s → 8s) lets draws 2-4 land on a rotated mapping — higher
// per-call success, fewer 60s short blocks. Worst added latency ~10s on a
// banned stretch; the ladder still escalates to the 60s block on failure.
const BAN_RETRY_DELAYS_MS = [
    120,
    2_000,
    8_000
];
const POOL_BLOCK_SHORT_MS = 60_000; // all-retries-banned → short block, let the pool rotate
const POOL_STREAK_FOR_LONG_BLOCK = 3; // consecutive all-banned calls ⇒ pool saturated
const IP_BAN_MAP_CAP = 16;
// ── v12.0 egress manager constants ──
const EGRESS_SAMPLE_TTL_MS = 120_000; // ipify cache — one draw sample per 2min
const EGRESS_TIMEOUT_MS = 3_500;
const PROBE_COOLDOWN_MS = 120_000; // one early-probe attempt per 2min while a window is live
const BAN_PERSIST_DIR = `${process.cwd()}/.data/fapi-gate`;
const BAN_PERSIST_PATH = `${BAN_PERSIST_DIR}/bans.json`;
const BAN_PERSIST_DEBOUNCE_MS = 30_000;
// v14.2 ban-aware recovery pacer
const PACER_RECOVERY_MS = 10 * 60_000; // post-ban ramp window (25%→100%)
const PACER_RAMP_FLOOR = 0.25; // budget fraction at the first recovery minute
const PACER_DISTRESS_CAP = 0.5; // budget cap while ≥2 named IPs are banned live
const PACER_MIN_BUDGET = 200; // same clamp floor as configureFapiGate
// globalThis singleton — survives Turbopack dev module-graph duplication
const g = globalThis;
const state = g.__nexusFapiGate ?? (g.__nexusFapiGate = {
    budgetPer60s: DEFAULT_BUDGET,
    banUntil: 0,
    spend: [],
    windowSum: 0,
    inflight: new Map(),
    ipBans: new Map(),
    recentBanEvents: [],
    allBanStreak: 0,
    aimdFactor: 1,
    lastBanEventAt: 0,
    lastAimdRecoverAt: 0,
    sampledIp: null,
    sampledAt: 0,
    lastBannedIp: null,
    lastProbeAt: 0,
    stats: {
        attempted: 0,
        allowed: 0,
        droppedBudget: 0,
        droppedBan: 0,
        lastBanUntil: 0,
        singleFlightShared: 0,
        retriesAfterBan: 0,
        probesIssued: 0,
        probeLifts: 0,
        effectiveBudgetPer60s: DEFAULT_BUDGET
    }
});
function isUnknownScopeKey(key) {
    return !/^\d{1,3}(\.\d{1,3}){3}$/.test(key); // anything that is not an IPv4 literal ("_pool", hostnames…)
}
try {
    const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
    const nowMs = Date.now();
    let unknownMax = 0;
    let named = 0;
    for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
        if (typeof until !== "number" || until <= nowMs) continue;
        if (isUnknownScopeKey(key)) {
            if (until > unknownMax) unknownMax = until;
        } else {
            state.ipBans.set(key, until);
            named++;
        }
    }
    if (unknownMax > state.banUntil) {
        state.banUntil = unknownMax;
        console.log(`[fapi-gate] v12.6 restored UNKNOWN-SCOPE pool ban from disk — silence armed until ${new Date(unknownMax).toISOString()}`);
    }
    if (state.ipBans.size > 0) {
        // v12.6: named-IP records are INTEL only — no global arm at boot. The
        // first gateFetch takes the lottery draw; a banned draw retries around
        // the named IP (pool rotation) exactly like any other 418.
        console.log(`[fapi-gate] v12.6 restored ${named} named-IP ban record(s) as intel (no global arm — majority-clean pool policy)`);
    }
} catch  {}
let banPersistTimer = null;
function persistBans() {
    if (banPersistTimer) return;
    banPersistTimer = setTimeout(()=>{
        banPersistTimer = null;
        try {
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["mkdirSync"])(BAN_PERSIST_DIR, {
                recursive: true
            });
            const nowMs = Date.now();
            const ipBans = {};
            // v12.1 TASK-49 — READ-MERGE-WRITE: mini-services write their own 418
            // discoveries (incl. "_pool" unknown-scope markers with REAL ends) to
            // this same file. Blindly overwriting with state-only data DELETED a
            // 15:20Z pool ban mid-storm (2026-10-19) — never shorten/lose foreign
            // entries: merge disk first, then overlay ours, keep live only.
            try {
                const disk = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
                for (const [ip, until] of Object.entries(disk?.ipBans ?? {})){
                    if (typeof until === "number" && until > nowMs) ipBans[ip] = until;
                }
            } catch  {
            /* no ledger yet */ }
            for (const [ip, until] of state.ipBans)if (until > nowMs) ipBans[ip] = Math.max(ipBans[ip] ?? 0, until);
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["writeFileSync"])(BAN_PERSIST_PATH, JSON.stringify({
                savedAt: new Date().toISOString(),
                ipBans
            }, null, 1));
        } catch  {}
    }, BAN_PERSIST_DEBOUNCE_MS);
}
// ── v12.0 egress IP sampler (which pool IP did this draw exit from?) ──
let egressInflight = null;
async function sampleEgressIp() {
    if (state.sampledIp && Date.now() - state.sampledAt < EGRESS_SAMPLE_TTL_MS) return state.sampledIp;
    if (egressInflight) return egressInflight;
    egressInflight = (async ()=>{
        try {
            const ctrl = new AbortController();
            const t = setTimeout(()=>ctrl.abort(), EGRESS_TIMEOUT_MS);
            const res = await fetch("https://api.ipify.org?format=json", {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(t);
            if (!res.ok) return null;
            const j = await res.json();
            const ip = typeof j.ip === "string" && j.ip ? j.ip : null;
            if (ip) {
                state.sampledIp = ip;
                state.sampledAt = Date.now();
            }
            return ip;
        } catch  {
            return null; // sampler down — never blocks the gate (fail-open)
        } finally{
            egressInflight = null;
        }
    })();
    return egressInflight;
}
function fapiEgressStatus() {
    const now = Date.now();
    const bannedIps = [];
    for (const [ip, until] of state.ipBans)if (until > now) bannedIps.push({
        ip,
        until,
        remainingMs: until - now
    });
    bannedIps.sort((a, b)=>b.until - a.until);
    return {
        banUntil: state.banUntil,
        banRemainingMs: Math.max(0, state.banUntil - now),
        sampledIp: state.sampledIp,
        sampledAt: state.sampledAt || null,
        lastBannedIp: state.lastBannedIp,
        bannedIps,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        lastProbeAt: state.lastProbeAt
    };
}
function configureFapiGate(opts) {
    if (opts?.budgetPer60s !== undefined) {
        const b = Math.max(200, Math.min(2300, Math.round(opts.budgetPer60s)));
        state.budgetPer60s = b;
    }
}
function fapiBanRemainingMs() {
    return Math.max(0, state.banUntil - Date.now());
}
function fapiBanActivity() {
    const now = Date.now();
    const globalRemainingMs = Math.max(0, state.banUntil - now);
    const namedLiveIps = namedLiveBanCount(now);
    if (globalRemainingMs > 0) {
        return {
            active: true,
            reason: `fapi GLOBAL ban window live — ${Math.round(globalRemainingMs / 1000)}s left`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    if (namedLiveIps >= 2) {
        return {
            active: true,
            reason: `fapi pool distress — ${namedLiveIps} named egress IPs inside live ban windows`,
            globalRemainingMs,
            namedLiveIps,
            effectiveBudgetPer60s: effectiveBudgetPer60s()
        };
    }
    return {
        active: false,
        reason: null,
        globalRemainingMs,
        namedLiveIps,
        effectiveBudgetPer60s: effectiveBudgetPer60s()
    };
}
function fapiGateStats() {
    const now = Date.now();
    pruneWindow(now);
    let bannedIps = 0;
    for (const [, until] of state.ipBans)if (until > now) bannedIps++;
    return {
        attempted: state.stats.attempted,
        allowed: state.stats.allowed,
        droppedBudget: state.stats.droppedBudget,
        droppedBan: state.stats.droppedBan,
        lastBanUntil: state.stats.lastBanUntil,
        budgetPer60s: state.budgetPer60s,
        usedLast60s: state.windowSum,
        singleFlightShared: state.stats.singleFlightShared,
        banRemainingMs: fapiBanRemainingMs(),
        bannedPoolIps: bannedIps,
        retriesAfterBan: state.stats.retriesAfterBan,
        probesIssued: state.stats.probesIssued,
        probeLifts: state.stats.probeLifts,
        effectiveBudgetPer60s: effectiveBudgetPer60s(),
        aimdFactor: Number(state.aimdFactor.toFixed(3))
    };
}
// ── weight table (Binance USDT-M futures documented weights) ────────────────
// klines ~2 (limit≤100) · depth 2-5-10 by limit · aggTrades 20 · trades 20 ·
// ticker/24hr 1 per-symbol / 40 full-universe · premiumIndex 1 per-symbol /
// 10 all-markers · futures/data/* 1 (openInterestHist, L/S ratios, basis…) ·
// exchangeInfo 1 · ping/time 1 · unknown default 5 (conservative).
function resolveWeight(path) {
    const qIdx = path.indexOf("?");
    const ep = (qIdx === -1 ? path : path.slice(0, qIdx)).replace(/^\//, "").replace(/\/+$/, "");
    const query = qIdx === -1 ? "" : path.slice(qIdx + 1);
    const limit = ()=>{
        const m = /[?&]limit=(\d+)/.exec(query);
        return m ? Number(m[1]) : null;
    };
    switch(ep){
        case "fapi/v1/ping":
        case "fapi/v1/time":
        case "fapi/v1/exchangeInfo":
            return 1;
        case "fapi/v1/klines":
            {
                const l = limit() ?? 500;
                return l <= 100 ? 2 : l <= 499 ? 5 : 10;
            }
        case "fapi/v1/depth":
            {
                const l = limit() ?? 100;
                return l <= 100 ? 2 : l <= 500 ? 5 : 10;
            }
        case "fapi/v1/aggTrades":
        case "fapi/v1/trades":
            return 20;
        case "fapi/v1/ticker/24hr":
            return /[?&]symbol=/.test(query) ? 1 : 40;
        case "fapi/v1/premiumIndex":
            return /[?&]symbol=/.test(query) ? 1 : 10;
        default:
            if (ep.startsWith("futures/data/")) return 1; // openInterestHist / L-S ratios / basis family
            return 5; // unknown → conservative default (covers fapi/v1/fundingRate etc.)
    }
}
function pruneWindow(now) {
    const cutoff = now - WINDOW_MS;
    while(state.spend.length > 0 && state.spend[0].at <= cutoff){
        const e = state.spend.shift();
        state.windowSum -= e.w;
    }
    if (state.spend.length > SPEND_CAP) {
        // defensive: drop the oldest half rather than grow unbounded
        const keep = state.spend.slice(Math.floor(state.spend.length / 2));
        let sum = 0;
        for (const e of keep)sum += e.w;
        state.spend = keep;
        state.windowSum = sum;
    }
}
/** Reserve `weight` from the rolling window. Returns the spend entry (for refunds) or null. */ // ── v14.2 BAN-AWARE RECOVERY PACER ────────────────────────────────────────
// The ONLY budget the rolling window spends against. A flat budget after a
// ban ended = instant re-saturation stampede (the 10-19 spiral); the pacer
// gives the pool a 10min ramp and caps telemetry while the pool shows live
// distress. Global-window minutes are NOT handled here (gateFetch drops
// everything while the window is live) — the pacer shapes the BEFORE
// (distress) and AFTER (recovery) of each ban episode.
function namedLiveBanCount(now) {
    let n = 0;
    for (const [, until] of state.ipBans)if (until > now) n++;
    return n;
}
// ── v14.3 ROLLING-CYCLE AIMD PACER (chapter-7 item ② «backoff واقعی», operator
// mandate trace 1a1a8ea4186c6571) — the missing third leg of the v14.2 pacer.
// Measured failure mode (engineering report NX3247+LIVE): the 3-IP egress pool
// rides a ROLLING ~20min ban cycle — bans expire, the full budget floods back
// instantly (named-IP bans never armed the global window ⇒ no ramp), the pool
// re-saturates in the same minute and re-bans. Fix: an AIMD shed factor that
// DECREASES multiplicatively on every named-IP ban event (×0.7, floor 0.25) and
// recovers ADDITIVELY during clean minutes (+0.05/min, cap 1.0). Sustained ban
// churn ⇒ progressively quieter pool without any operator tuning; a genuinely
// healthy pool heals back to full budget in ~15 clean minutes.
const AIMD_DROP = 0.7;
const AIMD_FLOOR = 0.25;
const AIMD_RECOVER_PER_MIN = 0.05;
function recoverAimd(now) {
    if (state.aimdFactor >= 1) {
        state.lastAimdRecoverAt = now;
        return;
    }
    if (state.lastBanEventAt === 0) return;
    const anchor = Math.max(state.lastAimdRecoverAt, state.lastBanEventAt);
    const cleanMin = Math.floor((now - anchor) / 60_000);
    if (cleanMin <= 0) return;
    state.aimdFactor = Math.min(1, state.aimdFactor + cleanMin * AIMD_RECOVER_PER_MIN);
    state.lastAimdRecoverAt = now;
}
function noteAimdBanEvent(now) {
    recoverAimd(now);
    state.aimdFactor = Math.max(AIMD_FLOOR, state.aimdFactor * AIMD_DROP);
    state.lastBanEventAt = now;
    state.lastAimdRecoverAt = now;
}
function effectiveBudgetPer60s() {
    const now = Date.now();
    let factor = 1;
    recoverAimd(now); // v14.3 — additive clean-minute recovery before clamping
    factor = Math.min(factor, state.aimdFactor);
    // POOL DISTRESS — ≥2 named egress IPs inside live ban windows: cap telemetry.
    if (namedLiveBanCount(now) >= 2) factor = Math.min(factor, PACER_DISTRESS_CAP);
    // RECOVERY RAMP — 10min linear 25%→100% after the last global window ends.
    if (state.banUntil > 0) {
        const sinceBan = now - state.banUntil;
        if (sinceBan >= 0 && sinceBan < PACER_RECOVERY_MS) {
            factor = Math.min(factor, PACER_RAMP_FLOOR + (1 - PACER_RAMP_FLOOR) * (sinceBan / PACER_RECOVERY_MS));
        }
    }
    return Math.max(PACER_MIN_BUDGET, Math.round(state.budgetPer60s * factor));
}
function takeWeight(weight) {
    const now = Date.now();
    pruneWindow(now);
    if (state.windowSum + weight > effectiveBudgetPer60s()) return null;
    const entry = {
        at: now,
        w: weight
    };
    state.spend.push(entry);
    state.windowSum += weight;
    return entry;
}
/** 418/429 responses carry no weight cost — give the reservation back. */ function refundWeight(entry) {
    if (!entry) return;
    const idx = state.spend.indexOf(entry);
    if (idx === -1) return; // already pruned out of the window (its cost is gone too)
    state.spend.splice(idx, 1);
    state.windowSum -= entry.w;
}
function armGlobalBan(until) {
    if (until > state.banUntil) {
        state.banUntil = until;
        state.stats.lastBanUntil = until;
    }
}
/** Record a 418/429 body. Returns { ip, until } when the body NAMES the banned egress IP. */ function noteBanBody(status, body) {
    const now = Date.now();
    const named = /IP\(([\d.]+)\)\s*banned until (\d+)/i.exec(body);
    if (named) {
        const ip = named[1];
        // v12.1 TASK-49: the LEDGER carries Binance's REAL end (sanity-capped 24h) —
        // the cosmetic +35min cap only applies to the global silence window below.
        // Capping the ledger made the early probe fire at a fake expiry and the
        // resulting 418 contact re-escalated the real ban (11:58→12:34→13:09 spiral).
        const realUntil = Math.min(Number(named[2]), now + 24 * 60_000);
        const until = Math.min(realUntil, now + BAN_CAP_MS);
        state.ipBans.set(ip, realUntil);
        state.lastBannedIp = ip;
        persistBans(); // v12.0 — named-IP ban ledger survives restarts (30s debounce)
        if (state.ipBans.size > IP_BAN_MAP_CAP) {
            // evict the soonest-expiring record
            let oldestKey = null;
            let oldestVal = Infinity;
            for (const [k, v] of state.ipBans)if (v < oldestVal) {
                oldestVal = v;
                oldestKey = k;
            }
            if (oldestKey) state.ipBans.delete(oldestKey);
        }
        state.recentBanEvents.push({
            at: now,
            ip
        });
        if (state.recentBanEvents.length > 64) state.recentBanEvents.splice(0, state.recentBanEvents.length - 64);
        noteAimdBanEvent(now); // v14.3 — every named-IP ban deepens the rolling-cycle shed
        return {
            ip,
            until
        };
    }
    const untilMatch = /banned until (\d+)/i.exec(body);
    if (untilMatch) {
        armGlobalBan(Math.min(Number(untilMatch[1]), now + BAN_CAP_MS)); // unknown scope — assume it's us
        return null;
    }
    // unparseable body — conservative defaults (taxonomy precedent for 418)
    armGlobalBan(now + (status === 429 ? BAN_429_DEFAULT_MS : BAN_418_DEFAULT_MS));
    return null;
}
/** Every retry landed on a (named) banned IP — escalate the global silence window. */ function escalatePoolBlock(worstNamedUntil) {
    const now = Date.now();
    state.allBanStreak++;
    if (state.allBanStreak >= POOL_STREAK_FOR_LONG_BLOCK) {
        // repeated independent evidence — the egress pool is saturated: full
        // zero-network window, capped at 35min, then a fresh probe self-heals.
        armGlobalBan(Math.min(worstNamedUntil, now + BAN_CAP_MS));
        state.allBanStreak = 0;
    } else {
        armGlobalBan(now + POOL_BLOCK_SHORT_MS);
    }
}
function pruneInflight(now) {
    for (const [k, e] of state.inflight){
        if (e.settled && now - e.startedAt >= SF_RESULT_MS) state.inflight.delete(k);
    }
}
function delay(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}
/**
 * THE gate body. Resolves parsed JSON, or null on: live IP ban, weight-budget
 * shed, HTTP failure, timeout, or parse error. Never throws, never queues.
 */ async function executeGated(path, opts) {
    const lane = opts?.priority ?? "telemetry";
    const weight = Math.max(1, Math.round(opts?.weight ?? resolveWeight(path)));
    const timeoutMs = opts?.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    let entry = takeWeight(weight);
    if (!entry) {
        if (lane !== "critical") {
            state.stats.droppedBudget++;
            return null; // telemetry: drop instead of queueing a storm
        }
        await delay(CRITICAL_RETRY_MS); // one small negative retry
        entry = takeWeight(weight);
        if (!entry) {
            state.stats.droppedBudget++;
            return null;
        }
    }
    const host = opts?.host ?? FAPI_HOST;
    let attempt = 0;
    while(true){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        let res;
        try {
            // v12.6.1 CONNECTION-RECYCLE (measured 2026-10-20 19:41Z, bun runtime):
            // a keep-alive fetch POOLS one TCP flow ⇒ ONE egress IP for its whole
            // life — a pinned-banned connection turned 231 gate calls into 0 allowed
            // while 6/10 fresh connections succeeded. `Connection: close` = a fresh
            // NAT lottery draw per request; the TLS cost (~60ms) is trivial next to
            // the starvation it prevents.
            res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store",
                headers: {
                    Connection: "close"
                }
            });
        } catch  {
            return null; // timeout/abort/network — weight may have been consumed, keep the reservation
        } finally{
            clearTimeout(timer);
        }
        if (res.ok) {
            const text = await res.text().catch(()=>"");
            if (!text) return null; // empty 200 — nothing to invent
            state.stats.allowed++;
            state.allBanStreak = 0; // a clean 2xx proves the pool still serves us
            try {
                return JSON.parse(text);
            } catch  {
                return null;
            }
        }
        if (res.status === 418 || res.status === 429) {
            const body = await res.text().catch(()=>"");
            refundWeight(entry); // banned responses carry no weight cost
            entry = null;
            const named = noteBanBody(res.status, body);
            if (opts?.singleProbe) return null; // v12.0 early probe — single attempt, window stays armed
            if (!named) return null; // unknown-scope ban — global zero-network window already armed
            if (attempt >= BAN_RETRIES) {
                escalatePoolBlock(named.until);
                return null;
            }
            attempt++;
            state.stats.retriesAfterBan++;
            await delay(BAN_RETRY_DELAYS_MS[Math.min(attempt - 1, BAN_RETRY_DELAYS_MS.length - 1)]); // span the NAT rotation window
            entry = takeWeight(weight);
            if (!entry) {
                state.stats.droppedBudget++;
                return null;
            }
            continue;
        }
        return null; // other non-ok status — honest null, no retry
    }
}
/** v12.1 TASK-49 — a recorded ban counts ONLY while its real end is in the future. */ function isIpBanned(ip, now) {
    if (!ip) return false;
    return (state.ipBans.get(ip) ?? 0) > now;
}
// v12.1 TASK-49 — SHARED LEDGER REFRESH: trade-service / price-ws write their
// own 418 discoveries (with REAL ends) to the same bans.json. Merge live disk
// entries into state every 30s (extend-only). v12.6 scope split: UNKNOWN-SCOPE
// entries extend the global silence (pool-suspect evidence); NAMED-IP entries
// merge into ipBans as intel only — a majority-clean pool must not be
// blacked out because one pool member drew a ban.
let lastLedgerCheckAt = 0;
function refreshLedgerOnce() {
    const nowMs = Date.now();
    lastLedgerCheckAt = nowMs;
    try {
        const raw = JSON.parse((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(BAN_PERSIST_PATH, "utf8"));
        let unknownMax = 0;
        for (const [key, until] of Object.entries(raw?.ipBans ?? {})){
            if (typeof until !== "number" || until <= nowMs) continue;
            if (isUnknownScopeKey(key)) {
                if (until > unknownMax) unknownMax = until;
                continue;
            }
            if (until > (state.ipBans.get(key) ?? 0)) state.ipBans.set(key, until);
        }
        // unknown-scope knowledge extends the global silence window (extend-only)
        if (unknownMax > state.banUntil) {
            state.banUntil = unknownMax;
            console.log(`[fapi-gate] v12.6 ledger refresh — UNKNOWN-SCOPE pool ban extends silence until ${new Date(unknownMax).toISOString()}`);
        }
    } catch  {
    /* ledger gone/unreadable — keep in-memory state */ }
}
try {
    const refresh = setInterval(refreshLedgerOnce, 30_000);
    if (typeof refresh.unref === "function") refresh.unref();
} catch  {
/* non-blocking env — skip refresh */ }
async function gateFetch(path, opts) {
    state.stats.attempted++;
    const now = Date.now();
    // v12.1 TASK-49 — LAZY LEDGER GUARD: the instant our global window expires,
    // re-check the shared ledger (throttled to one disk read / 15s) BEFORE any
    // network call — closes the poke-gap where the window died but the refresh
    // interval hadn't fired yet. While the pool is ledger-banned, zero pokes.
    if (now >= state.banUntil && now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
    if (now < state.banUntil) state.stats.droppedBan++; // ledger re-armed the window — shed instantly
    // GLOBAL BAN AWARENESS — while a global ban window is live, zero network calls
    // …except the v12.0 ROTATION-AWARE EARLY PROBE: one critical-lane attempt per
    // PROBE_COOLDOWN_MS when the sampled egress IP is clean — the pool rotates,
    // so the window can be LIFTED the moment a clean draw appears instead of
    // waiting out the full 35min cap. A failed probe keeps the window armed.
    if (now < state.banUntil) {
        state.stats.droppedBan++;
        const canProbe = (opts?.priority ?? "telemetry") === "critical" && now - state.lastProbeAt >= PROBE_COOLDOWN_MS;
        if (!canProbe) return null;
        // v12.1 TASK-49 — LEDGER FRESHNESS BEFORE PROBE: state may hold a cosmetic
        // cap while the disk carries a longer REAL end another process discovered.
        // A probe fired on stale state pokes a still-banned pool and re-escalates.
        // Re-read the ledger (15s throttle) and re-arm BEFORE the probe decision.
        if (now - lastLedgerCheckAt >= 15_000) refreshLedgerOnce();
        if (now < state.banUntil) return null; // ledger extended the silence — no probe
        state.lastProbeAt = now;
        const ip = await sampleEgressIp();
        // v12.1 TASK-49: expiry-aware check — a recorded ban whose real end passed
        // no longer blocks the probe (the old .has() kept ghost entries armed).
        if (!ip || isIpBanned(ip, now)) return null; // sampled draw is banned/unknown — stay silent
        state.stats.probesIssued++;
        const probeResult = await executeGated(path, {
            ...opts,
            singleProbe: true
        });
        if (probeResult !== null) {
            state.banUntil = 0; // clean draw proved the pool rotated — lift instantly
            state.allBanStreak = 0;
            state.stats.probeLifts++;
            console.log(`[fapi-gate] v12.0 ban window LIFTED early — egress rotated to clean IP ${ip}`);
        }
        return probeResult;
    }
    // SINGLE-FLIGHT per (host,path): share the request while it is in flight and
    // for a 2s result window — concurrent module askers pay the weight once.
    const key = `${opts?.host ?? FAPI_HOST}${path}`;
    const existing = state.inflight.get(key);
    if (existing) {
        const age = now - existing.startedAt;
        if (!existing.settled || age < SF_RESULT_MS) {
            state.stats.singleFlightShared++;
            return existing.promise;
        }
        state.inflight.delete(key);
    }
    if (state.inflight.size >= SF_MAP_CAP) pruneInflight(now);
    const promise = executeGated(path, opts);
    const entry = {
        startedAt: now,
        settled: false,
        promise
    };
    state.inflight.set(key, entry);
    void promise.catch(()=>null) // executeGated never rejects — belt & suspenders
    .finally(()=>{
        entry.settled = true;
    });
    return promise;
}
}),
"[project]/src/lib/price-armor.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ── NEXUS//SIGNALS PRICE-ARMOR (v12.0 · Task 44-① — write-side phantom anchor) ──
// Operator order 2026-10-18: «ترمیم writer فید (خنثی‌سازی anchor فانتوم سمت
// نوشتن، نه فقط deploy)»
//
// FORENSIC ROOT (Task 45/44, hard evidence): Binance serves ZOMBIE spot
// listings — XMRUSDT spot answers lastPrice=118.70 with bidPrice=0 AND
// askPrice=0 (empty order book, frozen delisting-era print) while the real
// perp trades ~592. The v10.16 spot-overlay fallback (fetchTickers) trusted
// that print as source:"live" whenever fapi was IP-banned → the engine WROTE
// 118.7 into MarketAsset and PricePoint → NX-2736/2744 phantom stops (Task 43).
// The v11.9 PHANTOM-FEED gate catches this at DEPLOY time; this module kills
// the class at WRITE time — the tape itself must never carry phantom prints.
//
// Three writer-side weapons:
//   1. ZOMBIE-TICKER REJECTION — a ticker with a two-sided-empty book
//      (bid=0 && ask=0) is not a market; never a terminal price.
//   2. CROSS-PLANE DIVERGENCE GUARD — a spot-overlay quote deviating >10%
//      from the last live-verified perp anchor (or from the venue consensus)
//      is refused as a terminal source (perp↔spot basis is normally <1%;
//      real crashes are fapi/consensus-sourced and unaffected).
//   3. ANCHOR-LOCKED SIM DRIFT — the sim fallback drifts around the last
//      LIVE-verified price (not around MarketAsset.price, which a platform
//      restore can rewind to an era value — the 118.7 anchor class), with a
//      hard ±0.25% excursion cap, and sim ticks NEVER reach PricePoint /
//      tick-archive (a gap in the tape is honest; a phantom print is poison).
//
// Pure + client-safe. Consumers: market-feed (zombie filter), engine writer
// (resolveTerminalPrice), verify scripts (offline decision tests).
/** A ticker that has no two-sided market is a zombie/halted listing. */ __turbopack_context__.s([
    "REWIND_DETECT_PCT",
    ()=>REWIND_DETECT_PCT,
    "SIM_DRIFT_CAP_PCT",
    ()=>SIM_DRIFT_CAP_PCT,
    "SPOT_PERP_DIVERGENCE_PCT",
    ()=>SPOT_PERP_DIVERGENCE_PCT,
    "isTradeableTicker",
    ()=>isTradeableTicker,
    "resolveTerminalPrice",
    ()=>resolveTerminalPrice
]);
function isTradeableTicker(t) {
    const bid = Number(t.bidPrice ?? 0);
    const ask = Number(t.askPrice ?? 0);
    if (!Number.isFinite(bid) || !Number.isFinite(ask)) return true; // fields absent (some planes) → cannot disprove
    return !(bid === 0 && ask === 0);
}
const SPOT_PERP_DIVERGENCE_PCT = 10;
const REWIND_DETECT_PCT = 5;
const SIM_DRIFT_CAP_PCT = 0.25;
const rnd = ()=>Math.random();
function resolveTerminalPrice(inp, jitter = rnd) {
    const { tPrice, tZombie, tSpotOverlay, consMedian, consVenues, anchor, storedPrice } = inp;
    const out = {
        next: 0,
        liveNow: false,
        priceClass: "frozen",
        zombieRejected: false,
        rewound: false
    };
    // ① consensus (≥2 venues, robust median) — always trusted, wins over ticker
    if (consVenues >= 2 && consMedian && consMedian > 0) {
        return {
            ...out,
            next: consMedian,
            liveNow: true,
            priceClass: "live-consensus"
        };
    }
    // ② ticker — but only a tradeable one; the cross-plane divergence guard is
    // SPOT-OVERLAY-ONLY (fapi perp prints are the market itself — a real crash
    // must pass; an overlay quote deviating >10% from the perp truth is zombie-adjacent)
    if (tPrice && tPrice > 0 && !tZombie) {
        let reject = false;
        if (tSpotOverlay) {
            if (consMedian && consMedian > 0 && Math.abs(tPrice - consMedian) / consMedian * 100 > SPOT_PERP_DIVERGENCE_PCT) reject = true;
            if (!reject && anchor && anchor > 0 && Math.abs(tPrice - anchor) / anchor * 100 > SPOT_PERP_DIVERGENCE_PCT) reject = true;
        }
        if (!reject) return {
            ...out,
            next: tPrice,
            liveNow: true,
            priceClass: "live-ticker"
        };
        out.zombieRejected = true;
    } else if (tPrice && tPrice > 0 && tZombie) {
        out.zombieRejected = true;
    }
    // ③ sim drift — ANCHOR-LOCKED: drift around the last live-verified price.
    const base = anchor && anchor > 0 ? anchor : storedPrice;
    if (base > 0) {
        if (anchor && anchor > 0 && storedPrice > 0 && Math.abs(storedPrice - anchor) / anchor * 100 > REWIND_DETECT_PCT) out.rewound = true;
        const walk = base * (1 + (jitter() - 0.5) * 0.001);
        // excursion cap keeps a long outage from walking the sim price away
        const capped = Math.max(base * (1 - SIM_DRIFT_CAP_PCT / 100), Math.min(base * (1 + SIM_DRIFT_CAP_PCT / 100), walk));
        out.next = capped;
        out.liveNow = false;
        out.priceClass = "sim-drift";
        return out;
    }
    // ④ nothing sane — freeze (caller keeps the previous stored price untouched)
    out.next = 0;
    out.priceClass = "frozen";
    return out;
}
}),
"[project]/src/lib/spot-host-gate.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noteSpotHostThrottle",
    ()=>noteSpotHostThrottle,
    "spotHostReady",
    ()=>spotHostReady,
    "spotHostsReady",
    ()=>spotHostsReady,
    "spotLadderJson",
    ()=>spotLadderJson
]);
// ── NEXUS//SIGNALS spot-host gate (v13.2.1 SPOT-BAN-BACKOFF) ────────────────
// Completes the v13.2 SPOT-HOST LADDER: the ladder could DETECT a 418/429
// (fall through to the next rung) but had NO per-host backoff, so every tick
// re-poked the banned host first — wasting weight and keeping ban pressure
// alive. Live evidence 2026-10-25T00:48Z: data-api.binance.vision flapped
// 429/418 at x-mbx-used-weight-1m: 467 with retry-after: 889s while fapi
// served 200 @73ms (separate ban pools per host confirmed).
//
// Contract (read-only, zero data invention):
//   · 418 → host silent for retry-after seconds (capped 15min)
//   · 429 → soft 60s pause (retry-after respected when present)
//   · ladders ask spotHostsReady() and skip mid-ban hosts → traffic
//     auto-redistributes to the healthy rung and slides back on expiry.
//   · globalThis dedupe — Turbopack can instantiate per-route bundles; the
//     engine tick loop and /api routes MUST share one ban map (fbStats pattern).
const CAP_MS = 15 * 60_000;
const g = globalThis;
g.__nexusSpotHostGate ??= {
    bannedUntil: {}
};
const S = g.__nexusSpotHostGate;
function spotHostReady(host, now = Date.now()) {
    return (S.bannedUntil[host] ?? 0) <= now;
}
function spotHostsReady(hosts, now = Date.now()) {
    return hosts.filter((h)=>spotHostReady(h, now));
}
function noteSpotHostThrottle(host, status, headers) {
    const now = Date.now();
    let ms = status === 418 ? CAP_MS : 60_000;
    const ra = Number(headers.get("retry-after"));
    if (Number.isFinite(ra) && ra > 0) ms = Math.min(ra * 1000, CAP_MS);
    const prev = S.bannedUntil[host] ?? 0;
    if (prev < now + 1000) {
        console.warn(`[spot-host-gate] ${host} → ${status} — leg silent ${Math.round(ms / 1000)}s (weight1m=${headers.get("x-mbx-used-weight-1m") ?? "?"})`);
    }
    S.bannedUntil[host] = Math.max(prev, now + ms);
}
async function spotLadderJson(path, hosts, timeoutMs = 8000) {
    for (const host of spotHostsReady(hosts)){
        const ctrl = new AbortController();
        const timer = setTimeout(()=>ctrl.abort(), timeoutMs);
        try {
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                noteSpotHostThrottle(host, res.status, res.headers);
                continue;
            }
            if (!res.ok) continue;
            return await res.json();
        } catch  {
            continue;
        } finally{
            clearTimeout(timer);
        }
    }
    return null;
}
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[project]/src/lib/market-feed.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FUTURES_FAPI",
    ()=>FUTURES_FAPI,
    "fetchFuturesKlines",
    ()=>fetchFuturesKlines,
    "fetchFuturesPoolStats",
    ()=>fetchFuturesPoolStats,
    "fetchFuturesSymbols",
    ()=>fetchFuturesSymbols,
    "fetchFuturesUniverse",
    ()=>fetchFuturesUniverse,
    "fetchKlines",
    ()=>fetchKlines,
    "fetchTickers",
    ()=>fetchTickers,
    "futwsQuoteMap",
    ()=>futwsQuoteMap,
    "getFeedStatus",
    ()=>getFeedStatus,
    "getFutwsStatus",
    ()=>getFutwsStatus,
    "markFeedOk",
    ()=>markFeedOk
]);
// ── FlowRadar Neo live market feed (server-only) ──
// Binance REST client: USDT-M FUTURES tickers (primary) + spot overlay for
// spot-only listings + futures universe + klines.
// v10.16 P1 FUTURES PRICE UNIFICATION: perp signals must settle on perp
// prices — /fapi/v1 is now the PRIMARY ticker source; SPOT is only overlaid
// for universe symbols the futures response does not carry, and those rows
// stay source:"live". If BOTH fail the caller's sim fallback is unchanged.
// Resilience ladder: LIVE → STALE (≤5min grace) → SIMULATED drift.
// v10.24 Task 34-a FAPI GATE: every futures (fapi) REST call now goes through
// the process-wide weight gate (src/lib/fapi-gate.ts) — budget, global IP-ban
// awareness and single-flight. SPOT calls (api.binance.com) stay direct —
// they have their own separate IP budget.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)"); // v13.4 spot-print liveness probe
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$price$2d$armor$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/price-armor.ts [instrumentation] (ecmascript)"); // v12.0 Task 44-① zombie-ticker rejection at the feed layer
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [instrumentation] (ecmascript)");
;
;
;
// v13.3 BINANCE-LADDER (trace 1a184429d4bd0d05, restored 1a1849f647778885) —
// full official spot-REST set per binance-spot-api-docs: vision (dedicated
// market-data pool) → api-gcp (official GCP mirror, 200 6/6 @59ms 2026-10-28)
// → api1-4 mirrors → api last. Per-host 418/429 backoff via spot-host-gate.
const BINANCE_HOSTS = [
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
]; // v13.3 ladder + api-gcp
const FAPI = "https://fapi.binance.com";
// dual-host failover for the futures REST plane — fapi is the ONLY official
// USDT-M futures REST host: fapi1.binance.com probed 2026-10-25 = HTTP 302
// redirect (not an API host) → removed as a dead rung.
const FAPI_HOSTS = [
    "https://fapi.binance.com"
];
const TIMEOUT_MS = 6500;
;
const feedStatus = {
    source: "LIVE",
    lastOkAt: null,
    latencyMs: null,
    consecutiveFailures: 0,
    host: null,
    fallbackVenue: null
};
// v12.5 — throttled telemetry for the fallback rungs (one line / 10min max)
let lastFallbackEventAt = 0;
// ── v13.4 SPOT-PRINT-LIVENESS (trace 1a1849f647778885 — operator mandate:
// «سیستم کاملا از دیتای زنده و لحظه‌ای بایننس استفاده کند») ──────────────────
// price-ws (:3003) owns the hours-proven Binance spot !miniTicker@arr WS and
// pushes ~400 genuine live Binance spot prints into .data/spotws-quotes.json
// EVERY 3s — and since v13.4 it writes the file DIRECTLY (survives app
// restarts). getFeedStatus() recognizes that plane: fresh prints (≤90s,
// exchange timestamps) = LIVE with host labeled spot-ws-ring. 3s memo keeps
// the hot pulse path cheap; REST truth stays in charge when prints age out.
const SPOTWS_FILE = ".data/spotws-quotes.json";
const SPOTWS_FRESH_MS = 90_000;
let spotwsProbe = {
    at: 0,
    fresh: false,
    printAt: null,
    rows: 0
};
// ── v13.5 FUTWS-LIVENESS (trace 1a184d8bbb826f0d) — .data/futws-quotes.json
// is written DIRECTLY by price-ws :3003 every 3s from the futures bookTicker
// ring (43 liquid perps after the v13.5.1 ring repair — 5 entries were
// spot-named/dead and printed zero frames, best bid/ask → mid). Fresh file (≤90s payload) = the
// Binance FUTURES plane is exchange-pushed live: source stays LIVE through
// app restarts, REST pool bans and boot windows, and fetchTickers overlays
// those mids as perp-native quotes (see fetchTickers rung 2). 3s memo keeps
// the hot pulse path cheap.
const FUTWS_FILE = ".data/futws-quotes.json";
const FUTWS_FRESH_MS = 90_000;
let futwsProbe = {
    at: 0,
    fresh: false,
    printAt: null,
    rows: []
};
function futwsLiveness() {
    const now = Date.now();
    if (now - futwsProbe.at < 3_000) return futwsProbe;
    futwsProbe = {
        at: now,
        fresh: false,
        printAt: null,
        rows: []
    };
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(FUTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const rows = Array.isArray(j.rows) ? j.rows : [];
        const payloadAt = Number(j.at) || 0;
        if (payloadAt > 0 && now - payloadAt < FUTWS_FRESH_MS + 10_000 && rows.length > 0) {
            futwsProbe = {
                at: now,
                fresh: true,
                printAt: payloadAt,
                rows
            };
        }
    } catch  {
    /* file missing/unreadable → not fresh; REST truth stays in charge */ }
    return futwsProbe;
}
function getFutwsStatus() {
    const p = futwsLiveness();
    return {
        fresh: p.fresh,
        rows: p.rows.length,
        ageMs: p.printAt ? Date.now() - p.printAt : null
    };
}
function futwsQuoteMap() {
    const out = new Map();
    const p = futwsLiveness();
    if (!p.fresh) return out;
    const now = Date.now();
    for (const r of p.rows){
        if (!r || !r.s || !(r.m > 0)) continue;
        if (now - (r.t ?? 0) > 30_000) continue;
        out.set(r.s, {
            bid: r.b,
            ask: r.a,
            mid: r.m,
            t: r.t
        });
    }
    return out;
}
function spotPrintLiveness() {
    const now = Date.now();
    if (now - spotwsProbe.at < 3_000) return spotwsProbe;
    spotwsProbe = {
        at: now,
        fresh: false,
        printAt: null,
        rows: 0
    };
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(SPOTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const rows = Array.isArray(j.rows) ? j.rows : [];
        const payloadAt = Number(j.at) || 0;
        if (payloadAt > 0 && now - payloadAt < SPOTWS_FRESH_MS + 10_000 && rows.length > 0) {
            spotwsProbe = {
                at: now,
                fresh: true,
                printAt: payloadAt,
                rows: rows.length
            };
        }
    } catch  {
    /* file missing/unreadable → not fresh; REST truth stays in charge */ }
    return spotwsProbe;
}
// v14.3 TICKER-WEIGHT-DETENTE (operator trace 1a1c1ecd9694a129, 2026-11-09) —
// the spot REST overlay used to pull the FULL /api/v3/ticker/24hr board
// (weight 200) on EVERY engine tick (3.5s) while fapi was banned, because the
// futws ring (43 mids) never covers the whole 64-symbol universe. Measured
// fallout: ~11,400+ spot weight/min → family-wide 418 ("IP banned until …",
// host weight1m counters 13,5K–16,1K observed) — which is what kept the
// BINANCE-SPOT / BINANCE-GCP consensus planes dead and the EXCHANGE CONSENSUS
// card unstable even while the WS planes were healthy. New ladder inside
// fetchTickers: rung 2.5 = THIS map (real Binance spot prints pushed by
// price-ws :3003 every 3s — ~439 symbols, ZERO REST weight); rung 3 = REST
// pull ONLY for symbols still missing AND proven spot-listed (membership
// oracle = this file), via the ?symbols= filter (weight 4). Futures-only
// microcaps were NEVER in the spot response (the old full-board pull filtered
// them out locally) — they stay honestly missing, no invented data. If the
// print file is unreadable (price-ws down), rung 3 falls back to the legacy
// full-board pull (old behavior, old weight) so the overlay never goes dark.
function spotwsPrintMap() {
    const out = new Map();
    const now = Date.now();
    try {
        const raw = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["readFileSync"])(SPOTWS_FILE, "utf8");
        const j = JSON.parse(raw);
        const payloadAt = Number(j.at) || 0;
        if (!(payloadAt > 0) || now - payloadAt > SPOTWS_FRESH_MS + 10_000) return out; // stale file — rung skips honestly
        for (const r of Array.isArray(j.rows) ? j.rows : []){
            const sym = String(r?.s ?? "").toUpperCase();
            const p = Number(r?.p);
            const t = Number(r?.t);
            if (!sym.endsWith("USDT") || !(p > 0) || !(t > 0) || now - t > SPOTWS_FRESH_MS) continue;
            out.set(sym, p);
        }
    } catch  {
    /* file missing/unreadable → empty map; legacy rung covers */ }
    return out;
}
function getFeedStatus() {
    // v13.5 — futures bookTicker ring FIRST: a live Binance FUTURES plane beats
    // the spot mirror in the host label (operator mandate «دیتای زندهٔ بایننس
    // فیوچرز»); both files come from the same price-ws :3003 process.
    const futws = futwsLiveness();
    if (futws.fresh) {
        const FUT_HOST = "fut-ws-book + spot-ws-ring (price-ws :3003)";
        if (feedStatus.host !== FUT_HOST) {
            feedStatus.host = FUT_HOST;
            feedStatus.fallbackVenue = null; // native Binance futures plane — no fallback
        }
        // v14.3 STALE-DATA-DEPLOY-FIX (trace 1a1c1ecd9694a129): the reset used to fire
        // only on HOST CHANGE — meanwhile every banned REST rung tick incremented
        // consecutiveFailures, so after a few minutes failures≥3 flagged the feed
        // "stale" in the deploy gate (engine.ts feedStalePre) while the exchange was
        // pushing live prints every 3s. Raw evidence: failures=78 with lastOkAt 2s
        // fresh, RAW-CAL refused with STALE_DATA for 6h (last serial NX-3495).
        // WS-fresh ⇒ LIVE, full stop: REST-failure streaks are superseded data-path
        // noise, not staleness. The counter still tells the truth whenever NO WS
        // plane is fresh (the stale path below keeps accumulating it).
        feedStatus.consecutiveFailures = 0;
        feedStatus.source = "LIVE";
        if (!feedStatus.lastOkAt || Date.now() - feedStatus.lastOkAt > 20_000) feedStatus.lastOkAt = futws.printAt ?? Date.now();
        return {
            ...feedStatus
        };
    }
    const spotws = spotPrintLiveness();
    if (spotws.fresh) {
        // live Binance spot prints ≤90s old — the feed IS live regardless of the
        // REST poller's in-memory state (app restarts, pool bans, boot windows).
        // The host label PREFERS the Binance ring whenever it is fresh — the
        // operator's mandate is «دیتای زندهٔ بایننس»; a fallback REST rung must
        // not mask the Binance plane printing every 3s.
        if (feedStatus.host !== "spot-ws-ring (price-ws :3003)") {
            feedStatus.host = "spot-ws-ring (price-ws :3003)";
            feedStatus.fallbackVenue = "SPOT-MIRROR";
        }
        feedStatus.consecutiveFailures = 0; // v14.3 — same WS-fresh ⇒ LIVE rule as the futws branch above
        feedStatus.source = "LIVE";
        if (!feedStatus.lastOkAt || Date.now() - feedStatus.lastOkAt > 20_000) feedStatus.lastOkAt = spotws.printAt ?? Date.now();
        return {
            ...feedStatus
        };
    }
    if (feedStatus.lastOkAt && feedStatus.source !== "SIMULATED") {
        const age = Date.now() - feedStatus.lastOkAt;
        if (age > 5 * 60_000) return {
            ...feedStatus,
            source: "SIMULATED"
        };
        if (age > 20_000 && feedStatus.source === "LIVE") return {
            ...feedStatus,
            source: "STALE"
        };
    }
    return {
        ...feedStatus
    };
}
function markFeedOk(host) {
    feedStatus.lastOkAt = Date.now();
    feedStatus.latencyMs = null; // non-fapi rung — latency not comparable
    feedStatus.host = host;
    feedStatus.consecutiveFailures = 0;
    // DATA-REVIVAL — honest sourcing: name the Binance plane that actually fed the feed
    feedStatus.fallbackVenue = host.includes("futws") ? "FUTWS-RING" : host.includes("binance.vision") ? "SPOT-MIRROR" : feedStatus.fallbackVenue;
    if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
}
async function fetchJson(path, hosts = BINANCE_HOSTS) {
    let lastErr;
    const ready = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["spotHostsReady"])(hosts); // v13.2.1 — mid-ban hosts are skipped, traffic slides to the healthy rung
    if (ready.length === 0) throw new Error(`spot-host-gate: all hosts mid-ban for ${path}`);
    for (const host of ready){
        const t0 = Date.now();
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(()=>ctrl.abort(), TIMEOUT_MS);
            const res = await fetch(`${host}${path}`, {
                signal: ctrl.signal,
                cache: "no-store"
            });
            clearTimeout(timer);
            if (res.status === 418 || res.status === 429) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["noteSpotHostThrottle"])(host, res.status, res.headers);
                throw new Error(`${host}${path} → ${res.status} (gate armed)`);
            }
            if (!res.ok) throw new Error(`${host}${path} → ${res.status}`);
            const json = await res.json();
            feedStatus.lastOkAt = Date.now();
            feedStatus.latencyMs = Date.now() - t0;
            feedStatus.consecutiveFailures = 0;
            feedStatus.host = host.replace("https://", "");
            feedStatus.fallbackVenue = null; // Binance plane healthy — no fallback active
            if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
            return json;
        } catch (err) {
            lastErr = err;
            feedStatus.consecutiveFailures++;
        }
    }
    throw lastErr;
}
async function fetchTickers(symbols) {
    const out = new Map();
    const want = new Set(symbols);
    // v12.0 price-armor — zombie filter on BOTH planes: a halted/delisted
    // listing (empty book) must never masquerade as a live terminal price.
    const zombie = (t)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$price$2d$armor$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["isTradeableTicker"])(t);
    try {
        const all = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
            priority: "critical",
            weight: 40
        }); // full-universe ticker — heavy, gated
        for (const t of all)if (want.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
            ...t,
            plane: "fapi"
        });
    } catch  {
    /* fall through to the spot overlay below */ }
    const missing = symbols.filter((s)=>!out.has(s));
    // v13.5 FUTWS OVERLAY rung — the live Binance futures bookTicker mid from
    // price-ws :3003. When the fapi board is throttled/banned but the WS ring
    // is printing (it is REST-weight-free), missing symbols get a PERP-NATIVE
    // live price instead of sliding to the spot overlay (basis) or the ring.
    if (missing.length > 0) {
        const fut = futwsQuoteMap();
        for (const s of missing){
            const q = fut.get(s);
            if (!q) continue;
            const t = {
                symbol: s,
                lastPrice: String(q.mid),
                priceChangePercent: "0",
                highPrice: String(q.mid),
                lowPrice: String(q.mid),
                quoteVolume: "0",
                bidPrice: String(q.bid),
                askPrice: String(q.ask),
                plane: "futws"
            };
            if (!zombie(t)) out.set(s, t);
        }
    }
    const stillMissingAfterFutws = symbols.filter((s)=>!out.has(s));
    if (stillMissingAfterFutws.length > 0) {
        // v14.3 rung 2.5 — spotws print file: real Binance spot prints (zero REST
        // weight) cover spot-listed misses before any REST contact is made.
        const spotws = spotwsPrintMap();
        for (const s of stillMissingAfterFutws){
            const p = spotws.get(s);
            if (p === undefined) continue;
            const t = {
                symbol: s,
                lastPrice: String(p),
                priceChangePercent: "0",
                highPrice: String(p),
                lowPrice: String(p),
                quoteVolume: "0",
                plane: "spot"
            };
            if (!zombie(t)) out.set(s, t);
        }
    }
    const stillMissingAfterSpotws = symbols.filter((s)=>!out.has(s));
    if (stillMissingAfterSpotws.length > 0) {
        try {
            // v14.3 rung 3 — REST, oracle-gated: only symbols still missing AND
            // present in the spotws membership file are requested (?symbols= filter,
            // weight 4 instead of the 200-weight full board). Symbols missing from
            // BOTH the futws ring and the spotws file are futures-only microcaps the
            // spot board could never price — the old code burned weight 200 to learn
            // exactly that. No spotws file at all (price-ws down) → legacy full-board
            // fallback so the overlay never goes dark.
            const spotws = spotwsPrintMap();
            const restWant = stillMissingAfterSpotws.filter((s)=>spotws.has(s)).slice(0, 100);
            if (restWant.length > 0) {
                const q = `?symbols=${encodeURIComponent(JSON.stringify(restWant))}`;
                const spot = await fetchJson(`/api/v3/ticker/24hr${q}`);
                for (const t of spot)if (want.has(t.symbol) && !out.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
                    ...t,
                    plane: "spot"
                });
            } else if (spotws.size === 0 && spotPrintLiveness().fresh === false) {
                const spot = await fetchJson("/api/v3/ticker/24hr");
                for (const t of spot)if (want.has(t.symbol) && !out.has(t.symbol) && !zombie(t)) out.set(t.symbol, {
                    ...t,
                    plane: "spot"
                });
            }
        } catch  {
        /* fallback rung below */ }
    }
    // v14.0 BINANCE-ONLY — the v12.5 cross-venue mirror rung is retired. After
    // the futws ring + the spot overlay, futures-only tickers missing from both
    // stay honestly missing when fapi is banned (no invented data, no foreign
    // venue) — the caller falls back to sim drift exactly as documented.
    return out;
}
// identical response mapping for both kline planes (v10.16 — single mapper)
function mapKlines(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5])
        }));
}
async function fetchKlines(symbol, interval, limit) {
    try {
        const spot = await fetchJson(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
        if (spot.length) return mapKlines(spot);
    } catch  {
    /* fapi rung below */ }
    try {
        const perp = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
            priority: "critical"
        });
        if (perp && perp.length) return mapKlines(perp);
    } catch  {
    /* honest failure below */ }
    throw new Error(`fetchKlines: all Binance rungs failed for ${symbol} ${interval}`);
}
async function fetchFuturesKlines(symbol, interval, limit) {
    try {
        const raw = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, {
            priority: "critical"
        });
        if (raw && raw.length) return mapKlines(raw);
    } catch  {
    /* spot rung below */ }
    try {
        const spot = await fetchJson(`/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
        if (spot.length) return mapKlines(spot);
    } catch  {
    /* honest failure below */ }
    throw new Error(`fetchFuturesKlines: all Binance rungs failed for ${symbol} ${interval}`);
}
// ── futures-only universe (R15) ───────────────────────────────
const STABLE_BASES = new Set([
    "USDC",
    "FDUSD",
    "TUSD",
    "BUSD",
    "DAI",
    "USDP",
    "EUR",
    "AEUR",
    "USDE",
    "USDS",
    "USR",
    "USDX",
    "USDTB",
    "USD1",
    "USTC",
    "U",
    "RLUSD",
    "PAXG"
]);
const LEVERAGED = /(UP|DOWN|BULL|BEAR)USDT$/;
function isStablePrice(p) {
    return p > 0.985 && p < 1.015;
}
async function fetchFuturesUniverse(n) {
    const tickers = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
        priority: "critical",
        weight: 40
    });
    return tickers.filter((t)=>t.symbol.endsWith("USDT")).filter((t)=>!LEVERAGED.test(t.symbol)).map((t)=>({
            symbol: t.symbol,
            quoteVolume: Number(t.quoteVolume),
            lastPrice: Number(t.lastPrice)
        })).filter((r)=>r.quoteVolume > 1_000_000 && !isStablePrice(r.lastPrice) && !STABLE_BASES.has(r.symbol.replace("USDT", ""))).sort((a, b)=>b.quoteVolume - a.quoteVolume).slice(0, n);
}
async function fetchFuturesSymbols() {
    const info = await fetchJsonFapi("/fapi/v1/exchangeInfo", {
        priority: "critical",
        weight: 1
    });
    return new Set(info.symbols.filter((s)=>s.contractType === "PERPETUAL" && s.status === "TRADING" && s.quoteAsset === "USDT").map((s)=>s.symbol));
}
let poolCache = null;
const POOL_TTL = 15 * 60_000;
// v5.2 TASK-53: persist the last good board so an app restart during an fapi
// ban doesn't zero the POOL readout (23:14Z boot with the ban live did exactly
// that — lastPoolSize seeded from nothing while the ban starved both rungs).
const POOL_FILE = ".data/pool-stats.json";
const POOL_PERSIST_MAX_AGE = 24 * 60 * 60_000;
function persistPool(value) {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const fs = __turbopack_context__.r("[externals]/fs [external] (fs, cjs)");
        fs.writeFileSync(POOL_FILE, JSON.stringify(value), "utf8");
    } catch  {
    /* best-effort telemetry — never a gate */ }
}
function persistedPool() {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const fs = __turbopack_context__.r("[externals]/fs [external] (fs, cjs)");
        const raw = JSON.parse(fs.readFileSync(POOL_FILE, "utf8"));
        if (!raw || typeof raw.totalUsdtPerps !== "number") return null;
        if (Date.now() - new Date(raw.measuredAt).getTime() > POOL_PERSIST_MAX_AGE) return null;
        return {
            ...raw,
            source: "PERSISTED"
        };
    } catch  {
        return null;
    }
}
async function fetchFuturesPoolStats() {
    if (poolCache && Date.now() - poolCache.at < POOL_TTL) return poolCache.value;
    try {
        const tickers = await fetchJsonFapi("/fapi/v1/ticker/24hr", {
            priority: "telemetry",
            weight: 40
        }); // 15min-cached board stat — sheddable
        const usdtPerps = tickers.filter((t)=>t.symbol.endsWith("USDT") && !LEVERAGED.test(t.symbol));
        const value = {
            totalUsdtPerps: usdtPerps.length,
            liquidPool: usdtPerps.filter((t)=>Number(t.quoteVolume) > 1_000_000 && !isStablePrice(Number(t.lastPrice)) && !STABLE_BASES.has(t.symbol.replace("USDT", ""))).length,
            measuredAt: new Date().toISOString(),
            source: "BINANCE-FAPI"
        };
        poolCache = {
            at: Date.now(),
            value
        };
        persistPool(value);
        return value;
    } catch  {
        // fapi banned/unreachable — persisted board (Task 53, v14.0)
        const saved = persistedPool();
        if (saved) {
            poolCache = {
                at: Date.now(),
                value: saved
            };
            return saved;
        }
        return poolCache?.value ?? {
            totalUsdtPerps: 0,
            liquidPool: 0,
            measuredAt: new Date().toISOString(),
            source: "BINANCE-FAPI"
        };
    }
}
const FUTURES_FAPI = FAPI;
// ── v10.24 Task 34-a — gated futures fetch (fapi plane ONLY) ───────────────
// Same contract as fetchJson (resolve JSON or THROW) so every existing caller
// keeps its exact semantics; failures just become MORE common under weight
// pressure / IP bans — by design (callers are throw-tolerant with fallbacks).
// Walks FAPI_HOSTS through the gate: bans/weight are per-IP, so the alt host
// shares the same budget/ban state (a ban nulls the alt attempt instantly).
async function fetchJsonFapi(path, opts) {
    let lastErr;
    for (const host of FAPI_HOSTS){
        const t0 = Date.now();
        const json = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(path, {
            ...opts,
            host
        });
        if (json !== null) {
            feedStatus.lastOkAt = Date.now();
            feedStatus.latencyMs = Date.now() - t0;
            feedStatus.consecutiveFailures = 0;
            feedStatus.host = host.replace("https://", "");
            feedStatus.fallbackVenue = null; // Binance plane healthy — no fallback active
            if (feedStatus.source !== "LIVE") feedStatus.source = "LIVE";
            return json;
        }
        feedStatus.consecutiveFailures++;
        lastErr = new Error(`fapi ${path} unavailable via ${host}`);
    }
    throw lastErr;
}
}),
"[project]/src/lib/futures-snapshot-settle.ts [instrumentation] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FWD_HORIZONS",
    ()=>FWD_HORIZONS,
    "HORIZON_WINDOW",
    ()=>HORIZON_WINDOW,
    "KlineCache",
    ()=>KlineCache,
    "fetchRangedKlines",
    ()=>fetchRangedKlines,
    "horizonWindowMs",
    ()=>horizonWindowMs,
    "klinePriceRecent",
    ()=>klinePriceRecent,
    "pct3",
    ()=>pct3,
    "resolveHorizonPrice",
    ()=>resolveHorizonPrice,
    "settlePendingFuturesSnapshots",
    ()=>settlePendingFuturesSnapshots
]);
// ── FlowRadar FWD-SETTLE (P0-b, FWD-SETTLE-20261025) ────────────────────────
// Revival of the dead forward-return settle loop. Forensics (2026-10-25):
//   · VolCauseEvent.fwd2h/6h: settlePendingVolCauses() (lib/volCause.ts) had
//     exactly ONE caller — GET /api/vol-cause — which is only fetched by the
//     dashboard VolCauseCard. When AiCoreSection swapped the sensor cards for
//     the (unconditional) SensorBusDormantStrip (~09-19), the polls stopped and
//     the loop died: 0 settled rows in the 10/10→now window.
//   · FuturesSnapshot.fwd15m/1h/4h: settleFuturesForwards() (futures-taxonomy)
//     settles from SIBLING snapshot rows only, ordered oldest-first with no
//     fallback price rung — the sparse-era head rows can never resolve, so the
//     300-row batch permanently clogs (head-of-line blocking) and nothing
//     newer ever settles.
// This module provides:
//   1. settlePendingFuturesSnapshots() — a resilient cadence settle for
//      FuturesSnapshot (batch 200, ts < now−4h, 120s throttle, per-row
//      try/catch, sibling → PricePoint → kline-ladder rungs, skip-floor guard
//      so a permanently unfetchable head can never clog the queue).
//   2. Shared price-resolution kit (KlineCache + resolveHorizonPrice) reused
//      by scripts/backfill-fwd-settle.ts for the one-off VolCauseEvent +
//      FuturesSnapshot backlog settle.
// Kline sources (honest ladder, graceful failure): fapi (same weight-gate the
// engine uses, ban-aware, never throws) → SPOT-MIRROR (api.binance.com /
// data-api.binance.vision — separate ban pool). v14.0 Binance-only: if all
// egress rungs fail the row simply stays pending and the failure is counted.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/market-feed.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fapi-gate.ts [instrumentation] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/spot-host-gate.ts [instrumentation] (ecmascript)");
;
;
;
;
const FWD_HORIZONS = {
    m15: 15 * 60_000,
    h1: 3_600_000,
    h4: 4 * 3_600_000
};
const HORIZON_WINDOW = {
    m15: [
        10 * 60_000,
        25 * 60_000
    ],
    h1: [
        55 * 60_000,
        85 * 60_000
    ],
    h4: [
        225 * 60_000,
        300 * 60_000
    ]
};
const INTERVAL_MS = {
    "15m": 900_000,
    "1h": 3_600_000,
    "4h": 4 * 3_600_000
};
// v13.2.3 (trace 1a170bba02dff781): vision first + api1-4 mid rungs (probed 200 on 2026-10-25), api last (403 from this egress).
const SPOT_HOSTS = [
    "https://data-api.binance.vision",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
    "https://api.binance.com"
];
const PAGE_MAX = 1000; // spot page cap (fapi caps at 1500, we stay at 1000)
const PAGES_PER_ENSURE = 6; // bounded paging per ensure() call
function mapBinanceRaw(raw) {
    return raw.map((k)=>({
            openTime: Number(k[0]),
            open: Number(k[1]),
            high: Number(k[2]),
            low: Number(k[3]),
            close: Number(k[4]),
            volume: Number(k[5])
        }));
}
function pct3(base, later) {
    return Number(((later - base) / base * 100).toFixed(3));
}
async function fetchRangedKlines(symbol, interval, startMs, endMs) {
    // rung 1 — fapi via the process-wide weight gate (ban-aware, returns null instead of throwing)
    const fapi = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fapi$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["gateFetch"])(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&startTime=${startMs}&endTime=${endMs}&limit=${PAGE_MAX}`, {
        priority: "telemetry"
    }).catch(()=>null);
    if (fapi && fapi.length > 0) return {
        candles: mapBinanceRaw(fapi),
        source: "FAPI"
    };
    // rung 2 — SPOT-MIRROR (separate rate/ban pool from fapi)
    // v13.2.1 — per-host 418/429 backoff via the shared spot-host gate.
    const spot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$spot$2d$host$2d$gate$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["spotLadderJson"])(`/api/v3/klines?symbol=${symbol}&interval=${interval}&startTime=${startMs}&endTime=${endMs}&limit=${PAGE_MAX}`, SPOT_HOSTS);
    if (spot && spot.length > 0) return {
        candles: mapBinanceRaw(spot),
        source: "SPOT-MIRROR"
    };
    // v14.0 — Binance-only: both REST rungs failed → honest null (row stays pending).
    return null;
}
class KlineCache {
    spans = new Map();
    egressCalls = 0;
    sources = new Map();
    note(source) {
        this.sources.set(source, (this.sources.get(source) ?? 0) + 1);
    }
    async ensure(symbol, interval, startMs, endMs) {
        const key = `${symbol}|${interval}`;
        const span = this.spans.get(key);
        if (span && span.from <= startMs && span.to >= endMs) return; // already covered
        const wantFrom = span ? Math.max(span.to, startMs) : startMs; // extend forward only
        let cursor = wantFrom;
        let acc = span ? span.candles : [];
        let source = span?.source ?? "NONE";
        for(let p = 0; p < PAGES_PER_ENSURE && cursor < endMs; p++){
            const page = await fetchRangedKlines(symbol, interval, cursor, endMs);
            this.egressCalls++;
            if (!page || page.candles.length === 0) break; // graceful — keep what we have
            source = page.source;
            this.note(source);
            acc = acc.concat(page.candles);
            const lastOpen = page.candles[page.candles.length - 1].openTime;
            const step = INTERVAL_MS[interval] ?? 3_600_000;
            if (lastOpen + step <= cursor) break; // no forward progress
            cursor = lastOpen + step;
            if (page.candles.length < PAGE_MAX) break;
        }
        // de-dupe + sort
        const seen = new Set();
        acc = acc.filter((c)=>seen.has(c.openTime) ? false : (seen.add(c.openTime), true)).sort((a, b)=>a.openTime - b.openTime);
        this.spans.set(key, {
            from: span ? span.from : startMs,
            to: Math.max(span?.to ?? 0, cursor),
            candles: acc,
            source
        });
    }
    // price AT tMs — same containment convention as volCause.priceAt (open ≤ t < open+period → that candle's close)
    priceAt(symbol, interval, tMs) {
        const span = this.spans.get(`${symbol}|${interval}`);
        if (!span) return null;
        const step = INTERVAL_MS[interval] ?? 3_600_000;
        const c = span.candles.find((k)=>k.openTime <= tMs && k.openTime + step > tMs);
        return c ? {
            price: c.close,
            source: span.source
        } : null;
    }
    covered(symbol, interval, tMs) {
        const span = this.spans.get(`${symbol}|${interval}`);
        return !!span && span.from <= tMs && tMs <= span.to;
    }
}
// ── sibling rung — same-venue snapshot price (egress-free) ──────────────────
async function siblingPrice(symbol, tMs, winMinMs, winMaxMs) {
    const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findFirst({
        where: {
            symbol,
            ts: {
                gte: new Date(tMs + winMinMs),
                lte: new Date(tMs + winMaxMs)
            }
        },
        orderBy: {
            ts: "asc"
        },
        select: {
            price: true
        }
    });
    return row ? row.price : null;
}
// ── PricePoint rung — the app's own WS price archive (price-ws :3003) ───────
async function pricePointAt(symbol, tMs, winMinMs, winMaxMs) {
    const row = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].pricePoint.findFirst({
        where: {
            symbol,
            createdAt: {
                gte: new Date(tMs + winMinMs),
                lte: new Date(tMs + winMaxMs)
            }
        },
        orderBy: {
            createdAt: "asc"
        },
        select: {
            price: true
        }
    });
    return row ? row.price : null;
}
function horizonWindowMs(horizonMs) {
    const canonical = {
        [FWD_HORIZONS.m15]: HORIZON_WINDOW.m15,
        [FWD_HORIZONS.h1]: HORIZON_WINDOW.h1,
        [FWD_HORIZONS.h4]: HORIZON_WINDOW.h4
    };
    return canonical[horizonMs] ?? [
        Math.round(horizonMs * 0.9),
        Math.round(horizonMs * 1.4)
    ];
}
async function resolveHorizonPrice(basePrice, symbol, tMs, horizon, opts = {}) {
    const horizonMs = typeof horizon === "number" ? horizon : FWD_HORIZONS[horizon];
    const [winMin, winMax] = horizonWindowMs(horizonMs);
    const none = (notes)=>({
            pct: null,
            source: "NONE",
            rungNotes: notes
        });
    const out = (price, source, notes)=>price !== null && basePrice > 0 ? {
            pct: pct3(basePrice, price),
            source,
            rungNotes: notes
        } : none(`${notes} ${source}:bad-base`);
    const notes = [];
    try {
        if (opts.useSibling) {
            const p = await siblingPrice(symbol, tMs, winMin, winMax).catch(()=>null);
            notes.push(`sibling:${p !== null ? "hit" : "miss"}`);
            if (p !== null) return out(p, "SIBLING", notes.join(" "));
        }
        if (opts.usePricePoint) {
            const p = await pricePointAt(symbol, tMs, winMin, winMax).catch(()=>null);
            notes.push(`pricepoint:${p !== null ? "hit" : "miss"}`);
            if (p !== null) return out(p, "PRICEPOINT", notes.join(" "));
        }
        const kit = opts.kit;
        if (kit) {
            // 1h candles for EVERY horizon — a 1h candle containing t+h closes within
            // (h, h+1h]; 4h candles would smear the 4h horizon by up to 4h.
            const interval = "1h";
            await kit.ensure(symbol, interval, tMs, tMs + horizonMs + INTERVAL_MS[interval]);
            const hit = kit.priceAt(symbol, interval, tMs + horizonMs);
            notes.push(`kit:${hit ? hit.source : "miss"}`);
            if (hit) return out(hit.price, hit.source, notes.join(" "));
            return none(notes.join(" "));
        }
        // no cache provided (one-off callers) — reuse volCause's exact fetch helper
        const recent = await klinePriceRecent(symbol, tMs + horizonMs, horizonMs);
        notes.push(`recent:${recent ? recent.source : "miss"}`);
        if (recent) return out(recent.price, recent.source, notes.join(" "));
        return none(notes.join(" "));
    } catch (e) {
        return none(`${notes.join(" ")} error:${e instanceof Error ? e.message : String(e)}`);
    }
}
// ── cadence settle for FuturesSnapshot (P0-b) ───────────────────────────────
const SETTLE_THROTTLE_MS = 120_000;
const BATCH = 200;
let lastSettleAt = 0;
let settleRunning = false;
// Skip-floor guard: if an entire batch resolves nothing (all egress rungs down
// for those symbols), advance the floor past the batch so the queue can never
// head-of-line block again (the exact failure mode that killed
// settleFuturesForwards). Rows below the floor stay honestly unsettled.
let skipFloorTs = 0;
async function settlePendingFuturesSnapshots() {
    const empty = {
        settled: 0,
        failed: 0,
        scanned: 0,
        sources: {},
        floorAdvanced: false
    };
    if (settleRunning || Date.now() - lastSettleAt < SETTLE_THROTTLE_MS) return empty;
    settleRunning = true;
    lastSettleAt = Date.now();
    try {
        const now = Date.now();
        const where = {
            ts: {
                lt: new Date(now - 4 * 3_600_000),
                gt: new Date(skipFloorTs)
            },
            OR: [
                {
                    fwd15mPct: null
                },
                {
                    fwd1hPct: null
                },
                {
                    fwd4hPct: null
                }
            ]
        };
        const pending = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.findMany({
            where,
            orderBy: {
                ts: "asc"
            },
            take: BATCH
        });
        if (pending.length === 0) return empty;
        const kit = new KlineCache();
        const sources = {};
        let settled = 0;
        let failed = 0;
        let maxTs = 0;
        for (const row of pending){
            maxTs = Math.max(maxTs, row.ts.getTime());
            try {
                const data = {};
                const want = [];
                if (row.fwd15mPct === null) want.push("m15");
                if (row.fwd1hPct === null) want.push("h1");
                if (row.fwd4hPct === null) want.push("h4");
                for (const h of want){
                    const r = await resolveHorizonPrice(row.price, row.symbol, row.ts.getTime(), h, {
                        useSibling: true,
                        usePricePoint: true,
                        kit
                    });
                    if (r.pct !== null) {
                        sources[r.source] = (sources[r.source] ?? 0) + 1;
                        if (h === "m15") data.fwd15mPct = r.pct;
                        else if (h === "h1") data.fwd1hPct = r.pct;
                        else data.fwd4hPct = r.pct;
                    }
                }
                if (Object.keys(data).length > 0) {
                    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["db"].futuresSnapshot.update({
                        where: {
                            id: row.id
                        },
                        data
                    });
                    settled++;
                } else {
                    failed++;
                }
            } catch  {
                failed++; // one bad row must never kill the batch
            }
        }
        let floorAdvanced = false;
        if (settled === 0 && failed > 0 && maxTs > 0) {
            skipFloorTs = maxTs; // unblock the queue — honest: those rows stay unsettled
            floorAdvanced = true;
        }
        return {
            settled,
            failed,
            scanned: pending.length,
            sources,
            floorAdvanced
        };
    } catch  {
        return empty;
    } finally{
        settleRunning = false;
    }
}
async function klinePriceRecent(symbol, tMs, spanMs) {
    const limit = Math.min(200, Math.max(2, Math.ceil(spanMs / 3_600_000) + 2));
    try {
        const candles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$market$2d$feed$2e$ts__$5b$instrumentation$5d$__$28$ecmascript$29$__["fetchFuturesKlines"])(symbol, "1h", limit);
        const c = candles.find((k)=>k.openTime <= tMs && k.openTime + 3_600_000 > tMs);
        return c ? {
            price: c.close,
            source: "FAPI-LADDER"
        } : null;
    } catch  {
        return null;
    }
}
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs, [project]/node_modules/@prisma/client)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client-2c3a283f134fdcb6", () => require("@prisma/client-2c3a283f134fdcb6"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__796c4db8._.js.map