module.exports = [
"[project]/.next-internal/server/app/api/internal/spotws-quotes/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_internal_spotws-quotes_route_actions_d2909c58.js.map