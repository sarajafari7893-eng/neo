var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/shadow-veto/telemetry/route.js")
R.c("server/chunks/[root-of-the-server]__6be915ca._.js")
R.c("server/chunks/[root-of-the-server]__30cafb84._.js")
R.c("server/chunks/[root-of-the-server]__486c52ee._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_shadow-veto_telemetry_route_actions_49ec569d.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/ai/shadow-veto/telemetry/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/ai/shadow-veto/telemetry/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
