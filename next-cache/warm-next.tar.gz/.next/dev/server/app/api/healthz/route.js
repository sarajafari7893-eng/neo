var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/healthz/route.js")
R.c("server/chunks/[root-of-the-server]__748ca3cf._.js")
R.c("server/chunks/[root-of-the-server]__95767b9f._.js")
R.c("server/chunks/_next-internal_server_app_api_healthz_route_actions_cede21ba.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/healthz/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/healthz/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
