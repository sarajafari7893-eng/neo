var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/rawcal/route.js")
R.c("server/chunks/src_lib_7a86a3f4._.js")
R.c("server/chunks/[root-of-the-server]__03dbc6fb._.js")
R.c("server/chunks/[root-of-the-server]__3fb51005._.js")
R.c("server/chunks/_next-internal_server_app_api_rawcal_route_actions_e22bccae.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/rawcal/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/rawcal/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
