var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/internal/flow-refresh/route.js")
R.c("server/chunks/src_lib_engine_ts_bc2d7ca3._.js")
R.c("server/chunks/[root-of-the-server]__34c5aeb6._.js")
R.c("server/chunks/[root-of-the-server]__1d95db64._.js")
R.c("server/chunks/_next-internal_server_app_api_internal_flow-refresh_route_actions_51a41722.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/internal/flow-refresh/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/internal/flow-refresh/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
