(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/terminal/GoldenLaneCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GoldenLaneCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ── Task 79 GOLDEN-LANE CARD (operator mandate 2026-10-05) ─────────────────
// The pre-registered paper evaluation of the Task-78 Golden Formula v1.0 and
// the R6-EDGE challenger, rendered live from /api/golden-lane. Doctrine path:
// 7d PAPER → (operator APPROVE) → live $2 → day-30 re-run. Kill-switches and
// rails are shown at all times — the operator must see the safety rails as
// prominently as the numbers.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const PHASE_STYLE = {
    PAPER: {
        chip: "bg-amber-500/15 text-amber-300 border-amber-500/30",
        label: "PAPER"
    },
    "PROMOTE-CANDIDATE": {
        chip: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
        label: "PROMOTE ✓"
    },
    EXTEND: {
        chip: "bg-sky-500/15 text-sky-300 border-sky-500/30",
        label: "EXTEND"
    },
    ABSTAIN: {
        chip: "bg-zinc-500/15 text-zinc-300 border-zinc-500/30",
        label: "ABSTAIN"
    },
    KILLED: {
        chip: "bg-rose-500/15 text-rose-300 border-rose-500/30",
        label: "KILLED"
    }
};
function usd(v, digits = 2) {
    if (v === null || v === undefined) return "—";
    return `${v >= 0 ? "+" : "−"}$${Math.abs(v).toFixed(digits)}`;
}
function LanePanel({ lane, margin }) {
    const ph = PHASE_STYLE[lane.phase];
    const killKeys = Object.entries(lane.kills).filter(([, v])=>v).map(([k])=>k);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-lg border border-white/5 bg-black/20 p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[13px] font-semibold text-zinc-100",
                        children: lane.name
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `rounded border px-1.5 py-0.5 text-[10px] font-bold tracking-wide ${ph.chip}`,
                        children: ph.label
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    killKeys.map((k)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "rounded border border-rose-500/40 bg-rose-500/10 px-1.5 py-0.5 text-[10px] font-bold text-rose-300",
                            children: [
                                k,
                                " TRIPPED"
                            ]
                        }, k, true, {
                            fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 text-[11px] leading-relaxed text-zinc-400",
                children: lane.detail
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 grid grid-cols-3 gap-2 text-center sm:grid-cols-6",
                children: [
                    {
                        k: "match",
                        v: String(lane.matched),
                        tone: ""
                    },
                    {
                        k: "settled",
                        v: String(lane.settled),
                        tone: ""
                    },
                    {
                        k: "open",
                        v: String(lane.open),
                        tone: ""
                    },
                    {
                        k: "wr",
                        v: lane.winRatePct !== null ? `${lane.winRatePct}%` : "—",
                        tone: ""
                    },
                    {
                        k: `net @ $${margin}`,
                        v: usd(lane.net2),
                        tone: lane.net2 > 0 ? "text-emerald-300" : lane.net2 < 0 ? "text-rose-300" : "text-zinc-100"
                    },
                    {
                        k: "avg/trade",
                        v: usd(lane.avgNet2, 3),
                        tone: lane.avgNet2 !== null && lane.avgNet2 > 0 ? "text-emerald-300" : lane.avgNet2 !== null && lane.avgNet2 < 0 ? "text-rose-300" : "text-zinc-100"
                    }
                ].map((x)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded bg-white/[0.03] px-1 py-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `text-[13px] font-bold ${x.tone || "text-zinc-100"}`,
                                children: x.v
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 55,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-[9px] uppercase tracking-wide text-zinc-500",
                                children: x.k
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 56,
                                columnNumber: 13
                            }, this)
                        ]
                    }, x.k, true, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-zinc-500",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "rails: day ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                className: lane.dailyStopBreached ? "text-rose-300" : "text-zinc-300",
                                children: usd(lane.todayNet2)
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 63,
                                columnNumber: 22
                            }, this),
                            " / stop −$5",
                            lane.dailyStopBreached ? " ⚠" : ""
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "week ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                className: lane.weeklyStopBreached ? "text-rose-300" : "text-zinc-300",
                                children: usd(lane.weekNet2)
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 67,
                                columnNumber: 16
                            }, this),
                            " / stop −$10",
                            lane.weeklyStopBreached ? " ⚠" : ""
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "best/worst day ",
                            usd(lane.bestDay),
                            " / ",
                            usd(lane.worstDay)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "K1..K4 ",
                            killKeys.length ? killKeys.join("·") : "armed"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            lane.recent.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 max-h-28 overflow-y-auto rounded bg-black/30 p-1.5 [scrollbar-width:thin]",
                children: lane.recent.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between gap-2 px-1 py-0.5 text-[10px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "truncate text-zinc-400",
                                children: [
                                    "NX-",
                                    String(m.serial).padStart(4, "0"),
                                    " · ",
                                    m.symbol,
                                    " ",
                                    m.direction === "LONG" ? "▲" : "▼",
                                    " · ",
                                    m.strategy,
                                    " · h",
                                    m.tehranHour,
                                    " · tp1 ",
                                    m.tp1DistPct.toFixed(2),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 80,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `shrink-0 font-mono font-bold ${m.net2 === null ? "text-zinc-500" : m.net2 >= 0 ? "text-emerald-300" : "text-rose-300"}`,
                                children: [
                                    m.status,
                                    " ",
                                    usd(m.net2, 3)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 83,
                                columnNumber: 15
                            }, this)
                        ]
                    }, `${m.lane}:${m.signalId}`, true, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 79,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 77,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c = LanePanel;
function GoldenLaneCard() {
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [err, setErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const pull = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "GoldenLaneCard.useCallback[pull]": async ()=>{
            try {
                const res = await fetch("/api/golden-lane", {
                    cache: "no-store"
                });
                if (res.ok) {
                    setData(await res.json());
                    setErr(null);
                } else {
                    setErr(`HTTP ${res.status}`);
                }
            } catch  {
                setErr("network");
            }
        }
    }["GoldenLaneCard.useCallback[pull]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GoldenLaneCard.useEffect": ()=>{
            // deferred first pull — keeps the effect body free of synchronous setState
            const first = setTimeout({
                "GoldenLaneCard.useEffect.first": ()=>void pull()
            }["GoldenLaneCard.useEffect.first"], 0);
            const id = setInterval({
                "GoldenLaneCard.useEffect.id": ()=>void pull()
            }["GoldenLaneCard.useEffect.id"], 15_000);
            return ({
                "GoldenLaneCard.useEffect": ()=>{
                    clearTimeout(first);
                    clearInterval(id);
                }
            })["GoldenLaneCard.useEffect"];
        }
    }["GoldenLaneCard.useEffect"], [
        pull
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        className: "lg:col-span-12",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "Golden lane // فرمول طلایی v1.0 — لِین Paper پیش‌ثبت‌شده"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 124,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 125,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            err && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-terminal text-[9px] text-rose-300",
                                children: err
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                lineNumber: 128,
                                columnNumber: 19
                            }, this),
                            data?.lanes.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                    tone: l.phase === "PROMOTE-CANDIDATE" ? "violet" : l.phase === "KILLED" ? "magenta" : l.phase === "PAPER" ? "amber" : "muted",
                                    children: [
                                        l.id.toUpperCase(),
                                        " · ",
                                        l.phase
                                    ]
                                }, l.id, true, {
                                    fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 127,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mb-3 text-[11px] leading-relaxed text-zinc-400",
                children: data ? `پنجرهٔ ۷روزه از ${new Date(data.windowStart).toLocaleString("fa-IR", {
                    timeZone: "Asia/Tehran",
                    dateStyle: "short",
                    timeStyle: "short"
                })} · مارجین $${data.marginUsd} · ریل‌ها: روزانه −$${Math.abs(data.dailyStop)} / هفتگی −$${Math.abs(data.weeklyStop)} · مسیر دکترین: paper ← تایید اپراتور ← live $2 ← re-run روز ۳۰` : "در حال اتصال به لِین…"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this),
            data?.tampered && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2 rounded border border-rose-500/40 bg-rose-500/10 px-2 py-1 text-[11px] text-rose-300",
                children: "⚠ TAMPER flag — فایل پیش‌ثبت با کانفیگ فعلی نخواند؛ پیکربندی بازرسی شود"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 144,
                columnNumber: 9
            }, this),
            data?.lastError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2 rounded border border-amber-500/30 bg-amber-500/10 px-2 py-1 text-[11px] text-amber-300",
                children: [
                    "sync error: ",
                    data.lastError
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 146,
                columnNumber: 27
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 gap-3 xl:grid-cols-2",
                children: [
                    data?.lanes.map((lane)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanePanel, {
                            lane: lane,
                            margin: data.marginUsd
                        }, lane.id, false, {
                            fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                            lineNumber: 150,
                            columnNumber: 11
                        }, this)),
                    !data && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bento h-40 animate-pulse xl:col-span-2"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                        lineNumber: 152,
                        columnNumber: 19
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
                lineNumber: 148,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/GoldenLaneCard.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s(GoldenLaneCard, "HdYvyAlzYrECZp9ovwjYsSVB8EY=");
_c1 = GoldenLaneCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "LanePanel");
__turbopack_context__.k.register(_c1, "GoldenLaneCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/FlowScannerCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FlowScannerCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/radar.js [app-client] (ecmascript) <export default as Radar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
/* ── v8.0 FLOW SCANNER card — the multi-TF board, EPOCH-2 ──
 * Self-polls /api/flows (30s). Rows = symbols sorted by |netScore|; columns =
 * the four timeframes with their HTF weights. Cell tint encodes direction and
 * conviction; SWEEP/CHoCH prints get their own chips. Zero fetched → honest
 * "warming up" state (first sweep populates the board in ~2min). */ const TFS = [
    "4h",
    "1h",
    "15m",
    "5m"
];
const TF_WEIGHT = {
    "4h": "×0.35",
    "1h": "×0.30",
    "15m": "×0.20",
    "5m": "×0.15"
};
const NEON = "0, 255, 163";
const DANGER = "255, 77, 94";
function tint(score) {
    const a = Math.min(0.22, Math.abs(score) / 100 * 0.22 + 0.03);
    return score > 0 ? `rgba(${NEON}, ${a})` : `rgba(${DANGER}, ${a})`;
}
function structShort(s) {
    if (s === "RANGE") return "···";
    return s.replace("SWEEP_", "SWP ").replace("BOS_", "BOS ").replace("CHOH_", "CHoCH ");
}
function TfCell({ t }) {
    if (!t) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex h-11 items-center justify-center rounded-md border border-white/5 font-terminal text-[10px] text-ink-3",
            children: "—"
        }, void 0, false, {
            fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
            lineNumber: 31,
            columnNumber: 12
        }, this);
    }
    const biasText = t.bias === "LONG" ? "text-neon" : t.bias === "SHORT" ? "text-danger-neon" : "text-ink-2";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-11 flex-col items-center justify-center rounded-md border border-white/5 px-1 font-terminal leading-tight",
        style: {
            background: tint(t.score)
        },
        title: `${t.tf}: score ${t.score} · trend ${t.trend} · ${t.structure} · CVD ${t.cvdPct ?? "n/a"}% · volZ ${t.volZ ?? "n/a"}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `text-[11px] font-bold ${biasText}`,
                children: [
                    t.score > 0 ? "+" : "",
                    t.score
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[9px] tracking-wide text-ink-3",
                children: [
                    structShort(t.structure),
                    t.sweep ? " ⌁" : ""
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
_c = TfCell;
function SymbolRow({ r }) {
    const netText = r.netBias === "LONG" ? "text-neon" : r.netBias === "SHORT" ? "text-danger-neon" : "text-ink-2";
    const byTf = new Map(r.tfs.map((t)=>[
            t.tf,
            t
        ]));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-[92px_64px_1fr] items-center gap-2 rounded-lg px-1 py-1 transition hover:bg-white/[0.03]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-w-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "truncate font-terminal text-[11px] font-bold text-ink",
                        children: r.symbol.replace("USDT", "")
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-terminal text-[9px] text-ink-3",
                        children: [
                            r.oiDelta1h !== null ? `OI ${r.oiDelta1h >= 0 ? "+" : ""}${r.oiDelta1h.toFixed(1)}%/1h` : "OI n/a",
                            r.funding8h !== null ? ` · F ${r.funding8h >= 0 ? "+" : ""}${r.funding8h.toFixed(3)}%` : ""
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-start",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `font-terminal text-[12px] font-bold ${netText}`,
                        children: [
                            r.netScore > 0 ? "+" : "",
                            r.netScore
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `font-terminal text-[9px] tracking-wider ${netText}`,
                        children: r.netBias === "NEUTRAL" ? "FLAT" : `${r.netBias} ${r.alignment}/4`
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-4 gap-1.5",
                children: TFS.map((tf)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TfCell, {
                        t: byTf.get(tf)
                    }, tf, false, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 72,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                lineNumber: 70,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_c1 = SymbolRow;
function FlowScannerCard() {
    _s();
    const [board, setBoard] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FlowScannerCard.useEffect": ()=>{
            let alive = true;
            const pull = {
                "FlowScannerCard.useEffect.pull": async ()=>{
                    try {
                        const res = await fetch("/api/flows", {
                            cache: "no-store"
                        });
                        if (!res.ok) return;
                        const data = await res.json();
                        if (alive) setBoard(data);
                    } catch  {
                    /* next tick retries */ } finally{
                        if (alive) setLoaded(true);
                    }
                }
            }["FlowScannerCard.useEffect.pull"];
            void pull();
            const id = setInterval(pull, 30_000);
            return ({
                "FlowScannerCard.useEffect": ()=>{
                    alive = false;
                    clearInterval(id);
                }
            })["FlowScannerCard.useEffect"];
        }
    }["FlowScannerCard.useEffect"], []);
    const rows = board?.rows.slice(0, 12) ?? [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radar$3e$__["Radar"], {
                                className: "h-4 w-4 text-cyan-neon",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 111,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "Flow scanner // multi-TF board"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 112,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 113,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                tone: "cyan",
                                children: [
                                    board?.coverage ?? 0,
                                    " SYMBOLS"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 116,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "hidden font-terminal text-[9px] tracking-[0.14em] text-ink-3 sm:inline",
                                children: "HTF CARRIES THE BIAS — 4h ×0.35 · 1h ×0.30 · 15m ×0.20 · 5m ×0.15"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 117,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                lineNumber: 109,
                columnNumber: 7
            }, this),
            (!loaded || rows.length === 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-44 flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-cyan-neon/25",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radar$3e$__["Radar"], {
                        className: "h-5 w-5 animate-pulse text-cyan-neon/60",
                        "aria-hidden": true
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 123,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "label-tech",
                        children: "Scanner warming up — first sweep populates the board in ~2min"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 124,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                lineNumber: 122,
                columnNumber: 9
            }, this),
            rows.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-[92px_64px_1fr] gap-2 px-1 pb-1.5 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "symbol"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 131,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "net board"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 132,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-4 gap-1.5",
                                children: TFS.map((tf)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-center",
                                        children: [
                                            tf,
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-ink-3/60",
                                                children: TF_WEIGHT[tf]
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                                lineNumber: 136,
                                                columnNumber: 24
                                            }, this)
                                        ]
                                    }, tf, true, {
                                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                        lineNumber: 135,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 133,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 130,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-h-[340px] space-y-1 overflow-y-auto pr-1",
                        children: rows.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SymbolRow, {
                                r: r
                            }, r.symbol, false, {
                                fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                                lineNumber: 143,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 141,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 font-terminal text-[9px] leading-relaxed tracking-wide text-ink-3",
                        children: "BOS = break of structure (trend continuation) · CHoCH = change of character (reversal) · SWP = liquidity sweep (stop-run rejection) · ⌁ sweep print · closed bars only, no lookahead"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
                        lineNumber: 146,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/FlowScannerCard.tsx",
        lineNumber: 108,
        columnNumber: 5
    }, this);
}
_s(FlowScannerCard, "ftV8ts5GZE6QeFvRNDyqSoJwstE=");
_c2 = FlowScannerCard;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "TfCell");
__turbopack_context__.k.register(_c1, "SymbolRow");
__turbopack_context__.k.register(_c2, "FlowScannerCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/LiqDepthRadarCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LiqDepthRadarCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Flame$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/flame.js [app-client] (ecmascript) <export default as Flame>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
/* ── v8.1 P1 LIQ DEPTH RADAR — OI/funding board + liquidation heatmap ──
 * Operator mandate «P1 و P2 رو کامل اجرا کن». Two feeds, 45s poll:
 *   · /api/oi-funding — OI Δ15m/1h/4h + funding carry per symbol
 *   · /api/liq-heat   — VOLUME-MAPPED ESTIMATE clusters scaled by real OI
 * The heatmap stays honestly labeled ESTIMATE — no exchange publishes
 * leveraged-position maps; we project recent volume through the popular
 * leverage tiers and scale by real OI when the board has it. */ function fmtUsdM(v) {
    if (v === null) return "—";
    return v >= 1000 ? `$${(v / 1000).toFixed(1)}B` : `$${v.toFixed(1)}M`;
}
function pct(v, digits = 1) {
    return v === null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(digits)}%`;
}
function ClusterRow({ side, c, maxAbs }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2 font-terminal text-[10px] leading-tight",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `w-12 shrink-0 text-right tabular-nums ${side === "above" ? "text-neon" : "text-danger-neon"}`,
                children: [
                    side === "above" ? "↑" : "↓",
                    " ",
                    c ? `${Math.abs(c.distPct).toFixed(2)}%` : "—"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-1.5 flex-1 overflow-hidden rounded-full bg-white/5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `h-full rounded-full ${side === "above" ? "bg-neon" : "bg-danger-neon"}`,
                    style: {
                        width: c ? `${Math.max(6, Math.abs(c.distPct) / maxAbs * 100)}%` : "0%",
                        boxShadow: "0 0 6px currentColor",
                        opacity: 0.8
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `w-24 shrink-0 tabular-nums ${side === "above" ? "text-neon" : "text-danger-neon"}`,
                children: c ? `${fmtUsdM(c.estUsdM)} ${side === "above" ? "shorts" : "longs"}` : "no cluster"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c = ClusterRow;
function ClusterBar({ h }) {
    // nearest clusters above/below with distance bars — magnet visualization
    const maxAbs = Math.max(h.nearestBelow ? Math.abs(h.nearestBelow.distPct) : 0.01, h.nearestAbove ? Math.abs(h.nearestAbove.distPct) : 0.01, 0.01);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ClusterRow, {
                side: "above",
                c: h.nearestAbove,
                maxAbs: maxAbs
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ClusterRow, {
                side: "below",
                c: h.nearestBelow,
                maxAbs: maxAbs
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_c1 = ClusterBar;
function HeatRow({ h }) {
    const sym = h.symbol.replace("USDT", "");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-lg border border-white/5 bg-white/[0.015] px-2.5 py-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-1.5 flex items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-terminal text-[11px] font-bold text-ink",
                        children: sym
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-terminal text-[9px] text-ink-3",
                        children: [
                            "OI ",
                            fmtUsdM(h.oiUsdM),
                            " ",
                            h.oiScaled ? "" : "· UNSCALED"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ClusterBar, {
                h: h
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 69,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, this);
}
_c2 = HeatRow;
function OiRow({ r }) {
    const d1h = r.oiDelta1h;
    const up = d1h !== null && d1h >= 0;
    const fundHot = r.funding8h !== null && Math.abs(r.funding8h) >= 0.05;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-[76px_58px_58px_66px_52px] items-center gap-1.5 px-1 py-1 font-terminal text-[10px] tabular-nums transition hover:bg-white/[0.03]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "truncate font-bold text-ink",
                children: r.symbol.replace("USDT", "")
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: d1h === null ? "text-ink-3" : up ? "text-neon" : "text-danger-neon",
                title: "OI Δ 15m",
                children: pct(r.oiDelta15m)
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: d1h === null ? "text-ink-3" : up ? "text-neon" : "text-danger-neon",
                title: "OI Δ 1h",
                children: pct(d1h)
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: d1h === null ? "text-ink-3" : up ? "text-neon" : "text-danger-neon",
                title: "OI Δ 4h",
                children: pct(r.oiDelta4h)
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: r.funding8h === null ? "text-ink-3" : fundHot ? r.funding8h > 0 ? "text-amber-neon" : "text-cyan-neon" : "text-ink-2",
                title: `funding ${r.funding8h === null ? "n/a" : `${r.funding8h.toFixed(4)}%/8h`} — |≥0.05%| marks a crowded side`,
                children: r.funding8h === null ? "—" : `${r.funding8h >= 0 ? "+" : ""}${r.funding8h.toFixed(3)}`
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
        lineNumber: 79,
        columnNumber: 5
    }, this);
}
_c3 = OiRow;
function LiqDepthRadarCard() {
    _s();
    const [oi, setOi] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [heat, setHeat] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LiqDepthRadarCard.useEffect": ()=>{
            let alive = true;
            const pull = {
                "LiqDepthRadarCard.useEffect.pull": async ()=>{
                    try {
                        const [oiRes, heatRes] = await Promise.all([
                            fetch("/api/oi-funding", {
                                cache: "no-store"
                            }),
                            fetch("/api/liq-heat", {
                                cache: "no-store"
                            })
                        ]);
                        if (oiRes.ok) {
                            const d = await oiRes.json();
                            if (alive) setOi(d);
                        }
                        if (heatRes.ok) {
                            const d = await heatRes.json();
                            if (alive) setHeat(d);
                        }
                    } catch  {
                    /* next tick retries */ } finally{
                        if (alive) setLoaded(true);
                    }
                }
            }["LiqDepthRadarCard.useEffect.pull"];
            void pull();
            const id = setInterval(pull, 45_000);
            return ({
                "LiqDepthRadarCard.useEffect": ()=>{
                    alive = false;
                    clearInterval(id);
                }
            })["LiqDepthRadarCard.useEffect"];
        }
    }["LiqDepthRadarCard.useEffect"], []);
    const oiRows = oi?.rows.slice(0, 8) ?? [];
    const heatRows = heat?.rows.slice(0, 5) ?? [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Flame$3e$__["Flame"], {
                                className: "h-4 w-4 text-amber-neon",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 136,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "Liq depth radar // OI · funding · heat"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 137,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 138,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                        lineNumber: 135,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                        tone: "amber",
                        children: "P1 v8.1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                        lineNumber: 140,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 134,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-4 lg:grid-cols-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1.5 flex items-center justify-between px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "open interest board"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 147,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            oi?.coverage ?? 0,
                                            " symbols"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 148,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 146,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1 grid grid-cols-[76px_58px_58px_66px_52px] gap-1.5 px-1 font-terminal text-[9px] uppercase tracking-wider text-ink-3/70",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "symbol"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 151,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-right",
                                        children: "Δ15m"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 152,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-right",
                                        children: "Δ1h"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 153,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-right",
                                        children: "Δ4h"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 154,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-right",
                                        children: "fund"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 155,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 150,
                                columnNumber: 11
                            }, this),
                            oiRows.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-32 items-center justify-center rounded-lg border border-dashed border-amber-neon/25 font-terminal text-[10px] text-ink-3",
                                children: !loaded ? "connecting…" : "OI board warming — first sweep ~2min"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 158,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-h-[190px] space-y-0.5 overflow-y-auto pr-1",
                                children: oiRows.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OiRow, {
                                        r: r
                                    }, r.symbol, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 164,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 162,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1.5 px-1 font-terminal text-[9px] leading-relaxed text-ink-3",
                                children: "ΔOI rising while price stalls = fresh leverage pressing. fund ≥|0.05%| = crowded side paying carry."
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 168,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1.5 flex items-center justify-between px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "liq heat · nearest clusters"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 176,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                        tone: "muted",
                                        children: "ESTIMATE"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 177,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 175,
                                columnNumber: 11
                            }, this),
                            heatRows.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-32 items-center justify-center rounded-lg border border-dashed border-amber-neon/25 font-terminal text-[10px] text-ink-3",
                                children: !loaded ? "connecting…" : "heatmap warming — volume projection ~3min"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 180,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-h-[218px] space-y-1.5 overflow-y-auto pr-1",
                                children: heatRows.map((h)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HeatRow, {
                                        h: h
                                    }, h.symbol, false, {
                                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                        lineNumber: 186,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 184,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1.5 px-1 font-terminal text-[9px] leading-relaxed text-ink-3",
                                children: "Volume-mapped projection through 10×/25×/50× tiers, scaled by REAL OI when present. Clusters below = long-liq flush fuel (magnet ↓) · above = short-liq squeeze fuel (magnet ↑). Feeds the L3P pre-cascade trigger + deploy threshold."
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                                lineNumber: 190,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                        lineNumber: 174,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
                lineNumber: 143,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/LiqDepthRadarCard.tsx",
        lineNumber: 133,
        columnNumber: 5
    }, this);
}
_s(LiqDepthRadarCard, "cvkEO2HbdFgychJma1wnUNAdf6s=");
_c4 = LiqDepthRadarCard;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "ClusterRow");
__turbopack_context__.k.register(_c1, "ClusterBar");
__turbopack_context__.k.register(_c2, "HeatRow");
__turbopack_context__.k.register(_c3, "OiRow");
__turbopack_context__.k.register(_c4, "LiqDepthRadarCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/VolRiskCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VolRiskCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield-alert.js [app-client] (ecmascript) <export default as ShieldAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
/* ── v8.1 P2 VOL REGIME + RISK OVERLAY card ──
 * Two feeds, 45s poll:
 *   · /api/vol-forecast — EWMA(λ=0.94) + HAR-lite on closed 15m bars; regime =
 *     percentile vs the symbol's OWN trailing distribution (LOW/NORMAL/ELEVATED/EXTREME)
 *   · /api/risk — portfolio overlay: union-merge correlation clusters (|ρ|≥0.65),
 *     drawdown sizing (≥3% ×0.75 · ≥7% ×0.5), verdict OK/THROTTLE/BLOCK
 * Engine contract: regime scales stop ×0.9..×1.15 + RR ±0.2R (VOL-REGIME-* tags);
 * a new deployment joining a same-direction cluster ≥35% of equity is refused
 * on the auto path (RISK-CLUSTER BLOCK), operator-forced deploys half-size. */ const REGIME_CLS = {
    LOW: "text-cyan-neon",
    NORMAL: "text-ink-2",
    ELEVATED: "text-amber-neon",
    EXTREME: "text-danger-neon"
};
const REGIME_BAR = {
    LOW: "bg-cyan-neon",
    NORMAL: "bg-white/40",
    ELEVATED: "bg-amber-neon",
    EXTREME: "bg-danger-neon"
};
function VolRow({ r }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-[76px_54px_58px_1fr] items-center gap-1.5 px-1 py-1 font-terminal text-[10px] tabular-nums transition hover:bg-white/[0.03]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "truncate font-bold text-ink",
                children: r.symbol.replace("USDT", "")
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-ink-2",
                title: `EWMA(λ=0.94) forecast ${r.ewmaBarPct.toFixed(3)}%/15m`,
                children: [
                    r.ewma1hPct.toFixed(2),
                    "%"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-ink-3",
                title: `HAR-lite 6h blend ${r.har6hPct.toFixed(3)}%/15m`,
                children: [
                    r.har6hPct.toFixed(2),
                    "%"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-1 flex-1 overflow-hidden rounded-full bg-white/5",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `h-full rounded-full ${REGIME_BAR[r.regime]}`,
                            style: {
                                width: `${Math.max(4, r.percentile)}%`,
                                opacity: 0.85
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                            lineNumber: 44,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `w-[86px] text-right font-bold ${REGIME_CLS[r.regime]}`,
                        title: `ATR15m ${r.atr15mPct.toFixed(2)}% · self-pct ${r.percentile}% vs own trailing distribution`,
                        children: [
                            r.regime,
                            " ",
                            r.percentile,
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_c = VolRow;
function VolRiskCard() {
    _s();
    const [vol, setVol] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [risk, setRisk] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VolRiskCard.useEffect": ()=>{
            let alive = true;
            const pull = {
                "VolRiskCard.useEffect.pull": async ()=>{
                    try {
                        const [vRes, rRes] = await Promise.all([
                            fetch("/api/vol-forecast", {
                                cache: "no-store"
                            }),
                            fetch("/api/risk", {
                                cache: "no-store"
                            })
                        ]);
                        if (vRes.ok) {
                            const d = await vRes.json();
                            if (alive) setVol(d);
                        }
                        if (rRes.ok) {
                            const d = await rRes.json();
                            if (alive) setRisk(d);
                        }
                    } catch  {
                    /* next tick retries */ } finally{
                        if (alive) setLoaded(true);
                    }
                }
            }["VolRiskCard.useEffect.pull"];
            void pull();
            const id = setInterval(pull, 45_000);
            return ({
                "VolRiskCard.useEffect": ()=>{
                    alive = false;
                    clearInterval(id);
                }
            })["VolRiskCard.useEffect"];
        }
    }["VolRiskCard.useEffect"], []);
    const rows = vol?.rows.slice(0, 8) ?? [];
    const verdictTone = risk?.verdict === "BLOCK" ? "danger" : risk?.verdict === "THROTTLE" ? "amber" : "neon";
    const ddPct = risk?.drawdownPct ?? 0;
    const ddWidth = Math.min(100, ddPct / 10 * 100); // bar saturates at 10%
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__["ShieldAlert"], {
                                className: "h-4 w-4 text-violet-neon",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 95,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "Vol regime & risk overlay // forecast + exposure"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 96,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                        tone: "violet",
                        children: "P2 v8.1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                        lineNumber: 99,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-4 lg:grid-cols-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1.5 flex items-center justify-between px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "volatility forecast"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 106,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            vol?.coverage ?? 0,
                                            " symbols"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 107,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 105,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1 grid grid-cols-[76px_54px_58px_1fr] gap-1.5 px-1 font-terminal text-[9px] uppercase tracking-wider text-ink-3/70",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "symbol"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 110,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-right",
                                        children: "ewma 1h"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 111,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-right",
                                        children: "har 6h"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 112,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-right",
                                        children: "regime · self-pct"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 113,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 109,
                                columnNumber: 11
                            }, this),
                            rows.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-28 items-center justify-center rounded-lg border border-dashed border-violet-neon/25 font-terminal text-[10px] text-ink-3",
                                children: !loaded ? "connecting…" : "vol board warming — flow-cache bound"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 116,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-h-[150px] space-y-0.5 overflow-y-auto pr-1",
                                children: rows.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(VolRow, {
                                        r: r
                                    }, r.symbol, false, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 122,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1.5 px-1 font-terminal text-[9px] leading-relaxed text-ink-3",
                                children: "EWMA λ=0.94 + HAR-lite on closed 15m bars; regime = percentile vs the symbol's OWN trailing distribution. ELEVATED → stop ×1.05, RR −0.1R · EXTREME → ×1.15, −0.2R · LOW → ×0.9, +0.1R."
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 126,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1.5 flex items-center justify-between px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "risk overlay · open book"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 134,
                                        columnNumber: 13
                                    }, this),
                                    risk && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                        tone: verdictTone,
                                        children: risk.verdict
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 135,
                                        columnNumber: 22
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this),
                            !risk ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-28 items-center justify-center rounded-lg border border-dashed border-violet-neon/25 font-terminal text-[10px] text-ink-3",
                                children: !loaded ? "connecting…" : "risk state warming"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 138,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-3 gap-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "font-terminal text-[9px] uppercase tracking-wider text-ink-3",
                                                        children: "equity"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 145,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "font-terminal text-sm font-bold tabular-nums text-ink",
                                                        children: [
                                                            "$",
                                                            risk.equity.toFixed(2)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 146,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 144,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "font-terminal text-[9px] uppercase tracking-wider text-ink-3",
                                                        children: "exposure"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 149,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "font-terminal text-sm font-bold tabular-nums text-ink",
                                                        children: [
                                                            "$",
                                                            risk.exposureUsd.toFixed(2)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 150,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 148,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "font-terminal text-[9px] uppercase tracking-wider text-ink-3",
                                                        children: "size mult"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 153,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `font-terminal text-sm font-bold tabular-nums ${risk.sizeMult < 1 ? "text-amber-neon" : "text-neon"}`,
                                                        children: [
                                                            "×",
                                                            risk.sizeMult.toFixed(2)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 154,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 152,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 143,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between font-terminal text-[9px] uppercase tracking-wider text-ink-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: [
                                                            "drawdown from peak $",
                                                            risk.peakEquity.toFixed(2)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 160,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `tabular-nums font-bold ${ddPct >= 7 ? "text-danger-neon" : ddPct >= 3 ? "text-amber-neon" : "text-ink-2"}`,
                                                        children: [
                                                            ddPct.toFixed(2),
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 161,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 159,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-1 h-1.5 overflow-hidden rounded-full bg-white/5",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: `h-full rounded-full ${ddPct >= 7 ? "bg-danger-neon" : ddPct >= 3 ? "bg-amber-neon" : "bg-neon"}`,
                                                    style: {
                                                        width: `${Math.max(2, ddWidth)}%`,
                                                        boxShadow: "0 0 6px currentColor",
                                                        opacity: 0.85
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                    lineNumber: 164,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 163,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-0.5 font-terminal text-[9px] text-ink-3",
                                                children: [
                                                    "≥3% → ×0.75 · ≥7% → ×0.50 · worst correlated cluster ",
                                                    risk.worstClusterPct.toFixed(1),
                                                    "% of equity (cap 35%)"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 169,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 158,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mb-1 font-terminal text-[9px] uppercase tracking-wider text-ink-3",
                                                children: [
                                                    "correlation clusters · union-merge |ρ|≥0.65 · ",
                                                    risk.openCount,
                                                    " open"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 173,
                                                columnNumber: 17
                                            }, this),
                                            risk.clusters.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "rounded-lg border border-white/5 bg-white/[0.015] px-2 py-1.5 font-terminal text-[10px] text-ink-3",
                                                children: "no correlated open clusters — the book is structurally diversified"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 177,
                                                columnNumber: 19
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "max-h-[76px] space-y-1 overflow-y-auto pr-1",
                                                children: risk.clusters.map((c, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between rounded-lg border border-white/5 bg-white/[0.015] px-2 py-1 font-terminal text-[10px]",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "truncate text-ink-2",
                                                                children: c.symbols.map((s)=>s.replace("USDT", "")).join(" · ")
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                                lineNumber: 184,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `shrink-0 tabular-nums font-bold ${c.equityPct >= 35 ? "text-danger-neon" : "text-ink-2"}`,
                                                                children: [
                                                                    c.direction,
                                                                    " ",
                                                                    c.equityPct.toFixed(1),
                                                                    "% · ρ̄ ",
                                                                    c.corr.toFixed(2)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                                lineNumber: 185,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, i, true, {
                                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                        lineNumber: 183,
                                                        columnNumber: 23
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                                lineNumber: 181,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                        lineNumber: 172,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                                lineNumber: 142,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                        lineNumber: 132,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
                lineNumber: 102,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/VolRiskCard.tsx",
        lineNumber: 92,
        columnNumber: 5
    }, this);
}
_s(VolRiskCard, "UZceufrBV7XjWI+gnpacjkLJl4k=");
_c1 = VolRiskCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "VolRow");
__turbopack_context__.k.register(_c1, "VolRiskCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/GateGaugeCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GateGaugeCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Scale$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/scale.js [app-client] (ecmascript) <export default as Scale>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
/* ── v8.2 GATE GAUGE // SIGNAL AUDIT card ──
 * Feed: /api/ai/gauge (8s poll — in-memory journal, cheap).
 * Shows LIVE which candidates sit on the confirm/reject boundary: the needle
 * is the candidate's |adjScore|, the white tick is its EFFECTIVE threshold
 * (dynamic MIN_SCORE + regime/spill/chase/MTF/liq-heat modifiers), the amber
 * zone is the boundary band (gap −8..0). The reason ledgers aggregate the
 * journal (6h window) and the CORE FEED panel mirrors what the central
 * deep-learn loop received and concluded from those reasons. */ const BOUNDARY_W = 8; // gap −8..0 = boundary band (mirrors gate-journal bandOf)
const THR_META = [
    {
        key: "regime",
        label: "REG"
    },
    {
        key: "spill",
        label: "SPILL"
    },
    {
        key: "chase",
        label: "CHASE"
    },
    {
        key: "mtf",
        label: "MTF"
    },
    {
        key: "liq",
        label: "LIQ"
    }
];
const BAND_CLS = {
    PASS: "text-neon",
    BOUNDARY: "text-amber-neon",
    REJECT: "text-danger-neon"
};
const BAND_LABEL = {
    PASS: "CONFIRM",
    BOUNDARY: "ON THE FENCE",
    REJECT: "REJECT"
};
const SRC_LABEL = {
    "auto-scan": "SCAN",
    trigger: "TRG",
    forced: "OP",
    shadow: "SHD"
};
function ago(ts) {
    const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return `${s}s`;
    if (s < 3600) return `${Math.round(s / 60)}m`;
    return `${Math.round(s / 3600)}h`;
}
/* semicircle gauge geometry: 180°=left(0) → 0°=right(vmax) */ const CX = 92;
const CY = 86;
const R = 68;
function polar(r, deg) {
    const rad = deg * Math.PI / 180;
    return [
        CX + r * Math.cos(rad),
        CY - r * Math.sin(rad)
    ];
}
function arc(r, a0, a1) {
    const [x0, y0] = polar(r, a0);
    const [x1, y1] = polar(r, a1);
    const large = Math.abs(a0 - a1) > 180 ? 1 : 0;
    return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}
const valAng = (v, vmax)=>180 - Math.max(0, Math.min(1, v / vmax)) * 180;
function Gauge({ s }) {
    const abs = Math.abs(s.score);
    const vmax = Math.max(s.effMin, abs) * 1.2 + 6;
    const bndStart = Math.max(0, s.effMin - BOUNDARY_W);
    const aBnd = valAng(bndStart, vmax);
    const aGate = valAng(s.effMin, vmax);
    const aScore = valAng(abs, vmax);
    const [nx, ny] = polar(R - 15, aScore);
    const [tx0, ty0] = polar(R - 7, aGate);
    const [tx1, ty1] = polar(R + 7, aGate);
    const passing = s.gap >= 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                viewBox: "0 0 184 100",
                className: "w-full max-w-[220px]",
                role: "img",
                "aria-label": `Gate gauge ${s.symbol} score ${abs.toFixed(1)} vs effective threshold ${s.effMin}`,
                children: [
                    bndStart > 0.5 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: arc(R, 180, aBnd),
                        fill: "none",
                        stroke: "rgba(255,77,94,0.5)",
                        strokeWidth: "9",
                        strokeLinecap: "butt"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 88,
                        columnNumber: 28
                    }, this),
                    s.effMin > bndStart && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: arc(R, aBnd, aGate),
                        fill: "none",
                        stroke: "rgba(255,179,71,0.75)",
                        strokeWidth: "9",
                        strokeLinecap: "butt"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 89,
                        columnNumber: 33
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: arc(R, aGate, 0),
                        fill: "none",
                        stroke: "rgba(0,255,163,0.65)",
                        strokeWidth: "9",
                        strokeLinecap: "butt"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                        x1: tx0,
                        y1: ty0,
                        x2: tx1,
                        y2: ty1,
                        stroke: "white",
                        strokeWidth: "2",
                        opacity: "0.9"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                        x1: CX,
                        y1: CY,
                        x2: nx,
                        y2: ny,
                        stroke: passing ? "#00ffa3" : s.band === "BOUNDARY" ? "#ffb347" : "#ff4d5e",
                        strokeWidth: "2.5",
                        strokeLinecap: "round"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: CX,
                        cy: CY,
                        r: "4.5",
                        fill: "#0a0f0d",
                        stroke: passing ? "#00ffa3" : s.band === "BOUNDARY" ? "#ffb347" : "#ff4d5e",
                        strokeWidth: "2"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                        x: "14",
                        y: "98",
                        fontSize: "7",
                        fill: "rgba(159,180,171,0.7)",
                        fontFamily: "monospace",
                        children: "0"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                        x: "158",
                        y: "98",
                        fontSize: "7",
                        fill: "rgba(159,180,171,0.7)",
                        fontFamily: "monospace",
                        children: vmax.toFixed(0)
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 98,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 86,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "-mt-2 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-terminal text-[10px] uppercase tracking-[0.14em] text-ink-3",
                        children: "gap to gate"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `font-terminal text-2xl font-bold tabular-nums ${BAND_CLS[s.band]}`,
                        children: [
                            s.gap >= 0 ? "+" : "",
                            s.gap.toFixed(1)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-0.5 font-terminal text-[11px] font-bold",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: s.direction === "LONG" ? "text-neon" : "text-magenta-neon",
                                children: [
                                    s.symbol.replace("USDT", ""),
                                    " ",
                                    s.direction
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 107,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "ml-1.5 tabular-nums text-ink-2",
                                children: [
                                    "|",
                                    abs.toFixed(1),
                                    "| vs eff ",
                                    s.effMin
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-0.5 flex items-center justify-center gap-1.5 font-terminal text-[9px] uppercase tracking-wider",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `${BAND_CLS[s.band]} font-bold`,
                                children: BAND_LABEL[s.band]
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 113,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-ink-3",
                                children: [
                                    "· ",
                                    SRC_LABEL[s.source],
                                    " · ",
                                    ago(s.at),
                                    " ago"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 114,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 112,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
        lineNumber: 85,
        columnNumber: 5
    }, this);
}
_c = Gauge;
function ThrChips({ thr }) {
    const live = THR_META.filter((t)=>thr[t.key] !== 0);
    if (live.length === 0) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "text-ink-3",
        children: "—"
    }, void 0, false, {
        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
        lineNumber: 123,
        columnNumber: 33
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: live.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                title: `${t.label} threshold modifier ${thr[t.key] > 0 ? "+" : ""}${thr[t.key]} (${thr[t.key] > 0 ? "raises the gate — reject pressure" : "discount — confirm pressure"})`,
                className: `rounded border px-0.5 font-bold leading-4 ${thr[t.key] > 0 ? "border-[rgba(255,179,71,0.4)] text-amber-neon" : "border-[rgba(69,240,223,0.4)] text-cyan-neon"}`,
                children: [
                    t.label,
                    thr[t.key] > 0 ? "+" : "",
                    thr[t.key]
                ]
            }, t.key, true, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 127,
                columnNumber: 9
            }, this))
    }, void 0, false);
}
_c1 = ThrChips;
function RosterRow({ s }) {
    const conf = s.confirms[0];
    const opp = s.opposes[0];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-[64px_46px_50px_1fr_1fr_92px] items-center gap-1 px-1 py-1 font-terminal text-[10px] tabular-nums transition hover:bg-white/[0.03]",
        title: s.notes ?? undefined,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "truncate font-bold text-ink",
                children: s.symbol.replace("USDT", "")
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 146,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `font-bold ${s.direction === "LONG" ? "text-neon" : "text-magenta-neon"}`,
                children: s.direction === "LONG" ? "LNG" : "SHT"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 147,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-ink-2",
                children: [
                    Math.abs(s.score).toFixed(1),
                    "/",
                    s.effMin
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 148,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "truncate text-[9px] text-neon",
                title: conf ? `${conf.factor} ${conf.vote >= 0 ? "+" : ""}${conf.vote} — ${conf.detail ?? ""}` : undefined,
                children: conf ? `+ ${conf.factor.toLowerCase()} ${conf.vote}` : ""
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 151,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "truncate text-[9px] text-danger-neon",
                title: opp ? `${opp.factor} ${opp.vote} — ${opp.detail ?? ""}` : undefined,
                children: opp ? `− ${opp.factor.toLowerCase()} ${opp.vote}` : ""
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 154,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex justify-end gap-0.5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ThrChips, {
                    thr: s.thr
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                    lineNumber: 158,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 157,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
        lineNumber: 145,
        columnNumber: 5
    }, this);
}
_c2 = RosterRow;
function GateGaugeCard() {
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GateGaugeCard.useEffect": ()=>{
            let alive = true;
            const pull = {
                "GateGaugeCard.useEffect.pull": async ()=>{
                    try {
                        const res = await fetch("/api/ai/gauge", {
                            cache: "no-store"
                        });
                        if (res.ok) {
                            const d = await res.json();
                            if (alive) setData(d);
                        }
                    } catch  {
                    /* next tick retries */ } finally{
                        if (alive) setLoaded(true);
                    }
                }
            }["GateGaugeCard.useEffect.pull"];
            void pull();
            const id = setInterval(pull, 8_000);
            return ({
                "GateGaugeCard.useEffect": ()=>{
                    alive = false;
                    clearInterval(id);
                }
            })["GateGaugeCard.useEffect"];
        }
    }["GateGaugeCard.useEffect"], []);
    const top = data?.live[0] ?? null;
    const roster = data?.live.slice(0, 8) ?? [];
    const stats = data?.stats ?? null;
    const lesson = data?.core.lessons[0] ?? null;
    const bnd = stats?.boundary ?? null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Scale$3e$__["Scale"], {
                                className: "h-4 w-4 text-neon",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 201,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "Gate gauge // signal audit — confirm/reject boundary"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 202,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 203,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 200,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                        tone: "violet",
                        children: "v8.2 · JOURNAL → CORE"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 205,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 199,
                columnNumber: 7
            }, this),
            !data ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-40 items-center justify-center rounded-lg border border-dashed border-neon/25 font-terminal text-[10px] text-ink-3",
                children: !loaded ? "connecting…" : "journal warming — first scan verdicts land within ~15s"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 209,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid gap-4 lg:grid-cols-[240px_1fr]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: top ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Gauge, {
                                    s: top
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                    lineNumber: 216,
                                    columnNumber: 25
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex h-36 items-center justify-center font-terminal text-[10px] text-ink-3",
                                    children: "no verdicts yet this session"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                    lineNumber: 216,
                                    columnNumber: 45
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 216,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-1 flex items-center justify-between px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "at the gate · nearest verdicts first"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 221,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    "base MIN_SCORE ",
                                                    data.gate.minScore,
                                                    " + dynamic adj"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 222,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 220,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-1 grid grid-cols-[64px_46px_50px_1fr_1fr_92px] gap-1 px-1 font-terminal text-[9px] uppercase tracking-wider text-ink-3/70",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "symbol"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 227,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "dir"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 228,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "scr/eff"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 229,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "top confirm"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 230,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "top oppose"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 231,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-right",
                                                children: "thr mods"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 232,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 226,
                                        columnNumber: 15
                                    }, this),
                                    roster.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex h-24 items-center justify-center rounded-lg border border-dashed border-neon/20 font-terminal text-[10px] text-ink-3",
                                        children: "scan pass pending — roster fills on the next engine evaluation"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 235,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "max-h-[150px] space-y-0.5 overflow-y-auto pr-1",
                                        children: roster.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RosterRow, {
                                                s: s
                                            }, `${s.symbol}-${s.direction}`, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 239,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 237,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 px-1 font-terminal text-[9px] text-ink-3",
                                        children: [
                                            "Bands: CONFIRM (gap ≥ 0) · ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-amber-neon",
                                                children: "ON THE FENCE (−8..0 — the boundary band)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 244,
                                                columnNumber: 44
                                            }, this),
                                            " · REJECT (< −8). Thr mods: ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-amber-neon",
                                                children: "+ raises the gate"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 244,
                                                columnNumber: 156
                                            }, this),
                                            " (regime/spill/chase/MTF-conflict/liq-heat), ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-cyan-neon",
                                                children: "− discounts it"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 244,
                                                columnNumber: 259
                                            }, this),
                                            "."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 243,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 219,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 214,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid gap-3 md:grid-cols-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-white/8 bg-white/[0.02] p-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-1.5 font-terminal text-[9px] uppercase tracking-[0.14em] text-neon",
                                        children: "confirm ledger · 6h"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 252,
                                        columnNumber: 15
                                    }, this),
                                    (stats?.confirmReasons.length ?? 0) === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "py-3 text-center font-terminal text-[10px] text-ink-3",
                                        children: "no confirming votes journaled yet"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 254,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1",
                                        children: stats.confirmReasons.slice(0, 4).map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1.5 font-terminal text-[10px]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-[118px] truncate text-ink-2",
                                                        title: r.lastDetail ?? r.factor,
                                                        children: r.factor.toLowerCase()
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                        lineNumber: 259,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "h-1 flex-1 overflow-hidden rounded-full bg-white/5",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-full rounded-full bg-neon opacity-80",
                                                            style: {
                                                                width: `${Math.min(100, Math.abs(r.avgVote) * 45)}%`
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                            lineNumber: 263,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                        lineNumber: 262,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-14 text-right tabular-nums text-ink-3",
                                                        children: [
                                                            "×",
                                                            r.count,
                                                            " ",
                                                            r.avgVote >= 0 ? "+" : "",
                                                            r.avgVote
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                        lineNumber: 265,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, r.factor, true, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 258,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 256,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 251,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-white/8 bg-white/[0.02] p-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-1.5 font-terminal text-[9px] uppercase tracking-[0.14em] text-danger-neon",
                                        children: "reject ledger · 6h"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 276,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1",
                                        children: (stats?.opposeReasons.length ?? 0) === 0 && (stats?.blocks.length ?? 0) === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "py-3 text-center font-terminal text-[10px] text-ink-3",
                                            children: "nothing rejected this window"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                            lineNumber: 279,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                stats.opposeReasons.slice(0, 3).map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between font-terminal text-[10px]",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "truncate text-ink-2",
                                                                title: r.lastDetail ?? r.factor,
                                                                children: [
                                                                    "✕ ",
                                                                    r.factor.toLowerCase()
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                                lineNumber: 284,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "tabular-nums text-ink-3",
                                                                children: [
                                                                    "×",
                                                                    r.count,
                                                                    " avg ",
                                                                    r.avgVote
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                                lineNumber: 287,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, r.factor, true, {
                                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                        lineNumber: 283,
                                                        columnNumber: 23
                                                    }, this)),
                                                stats.blocks.slice(0, 3).map((b)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between font-terminal text-[10px]",
                                                        title: b.lastReason,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "truncate font-bold text-amber-neon",
                                                                children: [
                                                                    "▣ ",
                                                                    b.gate.toLowerCase()
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                                lineNumber: 294,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "tabular-nums text-ink-3",
                                                                children: [
                                                                    "×",
                                                                    b.count
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                                lineNumber: 295,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, b.gate, true, {
                                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                        lineNumber: 293,
                                                        columnNumber: 23
                                                    }, this))
                                            ]
                                        }, void 0, true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 277,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 275,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-violet-neon/25 bg-violet-neon/[0.04] p-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-1.5 flex items-center justify-between font-terminal text-[9px] uppercase tracking-[0.14em] text-violet-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "core feed · deep-learn"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 305,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    data.core.runs,
                                                    " runs"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 306,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 304,
                                        columnNumber: 15
                                    }, this),
                                    lesson ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1 font-terminal text-[10px] leading-relaxed",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-ink",
                                                title: lesson.pattern,
                                                children: [
                                                    lesson.pattern.slice(0, 110),
                                                    lesson.pattern.length > 110 ? "…" : ""
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 310,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-ink-2",
                                                title: lesson.action,
                                                children: [
                                                    "→ ",
                                                    lesson.action.slice(0, 110),
                                                    lesson.action.length > 110 ? "…" : ""
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 314,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-[9px] text-ink-3",
                                                children: [
                                                    lesson.label,
                                                    " · conf ",
                                                    lesson.confidence,
                                                    "% · ",
                                                    ago(new Date(lesson.at).getTime()),
                                                    " ago"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 309,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "py-3 text-center font-terminal text-[10px] text-ink-3",
                                        children: "journal streams to the core on the next deep-learn cycle (~30min cadence)"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 323,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 303,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 250,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap items-center gap-x-3 gap-y-1 px-1 font-terminal text-[9px] tabular-nums text-ink-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "window ",
                                    stats.windowHours,
                                    "h · ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-ink-2",
                                        children: stats.samples
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 331,
                                        columnNumber: 46
                                    }, this),
                                    " verdicts"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 330,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-neon",
                                children: [
                                    "CONFIRM ",
                                    stats.byBand.PASS
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 333,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-amber-neon",
                                children: [
                                    "FENCE ",
                                    stats.byBand.BOUNDARY,
                                    bnd ? ` (${bnd.sharePct}% · avg gap ${bnd.avgGap})` : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 334,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-danger-neon",
                                children: [
                                    "REJECT ",
                                    stats.byBand.REJECT
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 338,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "deploys ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-ink-2",
                                        children: stats.deploys
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 340,
                                        columnNumber: 23
                                    }, this),
                                    stats.avgDeployScore !== null ? ` (avg |score| ${stats.avgDeployScore})` : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 339,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "ml-auto flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            "journal ",
                                            data.health.samples,
                                            " rec · ",
                                            data.health.fileKB,
                                            "KB → .data/gate-journal.jsonl"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 344,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: data.health.hydratedAt > 0 ? "text-neon" : "text-amber-neon",
                                        title: data.health.hydratedAt > 0 ? `rings hydrated from the on-disk journal at ${new Date(data.health.hydratedAt).toISOString().slice(11, 19)} UTC (v8.2.1 split-brain fix: read-path hydration + tail refresh)` : "rings COLD — module instance has never hydrated; if this persists the journal file is missing",
                                        children: data.health.hydratedAt > 0 ? `hydrated ${new Date(data.health.hydratedAt).toISOString().slice(11, 19)}Z` : "rings COLD"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                        lineNumber: 347,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                                lineNumber: 343,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                        lineNumber: 329,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
                lineNumber: 213,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/GateGaugeCard.tsx",
        lineNumber: 198,
        columnNumber: 5
    }, this);
}
_s(GateGaugeCard, "/DQgM6Tbh0417M50Y4dWMWUlK54=");
_c3 = GateGaugeCard;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "Gauge");
__turbopack_context__.k.register(_c1, "ThrChips");
__turbopack_context__.k.register(_c2, "RosterRow");
__turbopack_context__.k.register(_c3, "GateGaugeCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/ShadowVetoCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ShadowVetoCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/activity.js [app-client] (ecmascript) <export default as Activity>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2d$circuit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BrainCircuit$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/brain-circuit.js [app-client] (ecmascript) <export default as BrainCircuit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gavel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gavel$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/gavel.js [app-client] (ecmascript) <export default as Gavel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield-check.js [app-client] (ecmascript) <export default as ShieldCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
/* ── v8.2 SHADOW-VETO // AI CORE PHASE 0 card ──
 * Feed: /api/ai/shadow-veto (8s poll — in-memory rings, cheap).
 * The tiered-authority second opinion at the deploy gate: the core
 * adjudicates every fence candidate (hair-thin passes gap 0..+3, near-miss
 * rejects gap −8..0) with a VETO-ONLY voice, both sides are outcome-tracked
 * (real linkage for passes, honest paper ledger for rejects), and promotion
 * to live veto power is gated on measured evidence (≥30 settled per arm +
 * Wilson-LB95 separation + negative veto-cohort PnL). Fail-open, revocable. */ const MODE_TONE = {
    off: "text-ink-3",
    shadow: "text-amber-neon",
    veto: "text-violet-neon"
};
const SIDE_CLS = {
    PASS: "text-neon",
    REJECT: "text-amber-neon"
};
function ago(ts) {
    const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return `${s}s`;
    if (s < 3600) return `${Math.round(s / 60)}m`;
    if (s < 86400) return `${Math.round(s / 3600)}h`;
    return `${Math.round(s / 86400)}d`;
}
function usd(v) {
    return `${v >= 0 ? "+" : "−"}$${Math.abs(v).toFixed(2)}`;
}
function ArmRow({ a }) {
    const pct = Math.min(100, a.n / a.target * 100);
    const critical = a.id === "real-veto";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-1 py-1.5",
        title: a.label,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-1.5 font-terminal text-[10px]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: `w-[178px] shrink-0 truncate font-bold ${critical ? "text-magenta-neon" : "text-ink-2"}`,
                    children: a.label
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                    lineNumber: 43,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-1 flex-1 overflow-hidden rounded-full bg-white/5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `h-full rounded-full ${critical ? "bg-magenta-neon" : "bg-neon"} opacity-80`,
                        style: {
                            width: `${pct}%`
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "w-12 shrink-0 text-right tabular-nums text-ink-3",
                    children: [
                        a.n,
                        "/",
                        a.target
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "w-14 shrink-0 text-right tabular-nums text-ink",
                    children: a.winRatePct !== null ? `${a.winRatePct}%` : "—"
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                    lineNumber: 50,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "w-16 shrink-0 text-right tabular-nums text-cyan-neon",
                    children: a.wilsonLB !== null ? `LB ${a.wilsonLB.toFixed(0)}%` : "—"
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: `w-14 shrink-0 text-right tabular-nums ${a.netUsd > 0 ? "text-neon" : a.netUsd < 0 ? "text-danger-neon" : "text-ink-3"}`,
                    children: a.n ? usd(a.netUsd) : "—"
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
            lineNumber: 42,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
_c = ArmRow;
function ShadowVetoCard() {
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [notice, setNotice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const pull = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShadowVetoCard.useCallback[pull]": async ()=>{
            try {
                const res = await fetch("/api/ai/shadow-veto", {
                    cache: "no-store"
                });
                if (res.ok) setData(await res.json());
            } catch  {
            /* next tick retries */ } finally{
                setLoaded(true);
            }
        }
    }["ShadowVetoCard.useCallback[pull]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ShadowVetoCard.useEffect": ()=>{
            void pull();
            const id = setInterval(pull, 8_000);
            return ({
                "ShadowVetoCard.useEffect": ()=>clearInterval(id)
            })["ShadowVetoCard.useEffect"];
        }
    }["ShadowVetoCard.useEffect"], [
        pull
    ]);
    const [cooldown, setCooldown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ShadowVetoCard.useEffect": ()=>{
            if (cooldown <= 0) return;
            const id = setInterval({
                "ShadowVetoCard.useEffect.id": ()=>setCooldown({
                        "ShadowVetoCard.useEffect.id": (c)=>Math.max(0, c - 1)
                    }["ShadowVetoCard.useEffect.id"])
            }["ShadowVetoCard.useEffect.id"], 1000);
            return ({
                "ShadowVetoCard.useEffect": ()=>clearInterval(id)
            })["ShadowVetoCard.useEffect"];
        }
    }["ShadowVetoCard.useEffect"], [
        cooldown
    ]);
    const handleResponse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShadowVetoCard.useCallback[handleResponse]": async (res, mode)=>{
            let errMsg = null;
            if (res.ok) {
                setNotice(`mode → ${mode.toUpperCase()}`);
            } else {
                try {
                    const body = await res.json();
                    errMsg = body.error ?? `HTTP ${res.status}`;
                    if (res.status === 429 && body.error?.includes("cooldown")) setCooldown(20);
                } catch  {
                    errMsg = `HTTP ${res.status}`;
                }
                setNotice(errMsg);
            }
            setBusy(false);
            setTimeout({
                "ShadowVetoCard.useCallback[handleResponse]": ()=>setNotice(null)
            }["ShadowVetoCard.useCallback[handleResponse]"], errMsg ? 6000 : 3500);
            void pull();
        }
    }["ShadowVetoCard.useCallback[handleResponse]"], [
        pull
    ]);
    const setMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShadowVetoCard.useCallback[setMode]": async (mode)=>{
            if (!data || busy) return;
            if (mode === "veto" && !data.promotion.ready) {
                const ok = window.confirm(`EVIDENCE GATE NOT MET\n\n${data.promotion.criteria.map({
                    "ShadowVetoCard.useCallback[setMode].ok": (c)=>`${c.ok ? "✓" : "✗"} ${c.detail}`
                }["ShadowVetoCard.useCallback[setMode].ok"]).join("\n")}\n\nForce veto mode anyway? The override is audited and revocable.`);
                if (!ok) return;
                setBusy(true);
                const res = await fetch("/api/ai/shadow-veto", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        mode,
                        force: true
                    })
                });
                await handleResponse(res, mode);
            } else {
                setBusy(true);
                const res = await fetch("/api/ai/shadow-veto", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        mode
                    })
                });
                await handleResponse(res, mode);
            }
        }
    }["ShadowVetoCard.useCallback[setMode]"], [
        data,
        busy,
        pull,
        handleResponse
    ]);
    const mode = data?.config.mode ?? "shadow";
    const arms = data?.arms ?? [];
    const recent = data?.recent.slice(0, 7) ?? [];
    const paper = data?.paper ?? [];
    const stats = data?.stats;
    // v8.4.1 N3 — manual neural-link probe: one minimal LLM call THROUGH the
    // 429 shield; success resets the shield instantly (MODEL verdicts resume).
    const [probing, setProbing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const runProbe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShadowVetoCard.useCallback[runProbe]": async ()=>{
            if (probing) return;
            setProbing(true);
            try {
                const res = await fetch("/api/ai/neural-link", {
                    method: "POST"
                });
                const body = await res.json();
                const msg = body.ok ? "neural probe OK — link restored, shield reset" : `probe: ${body.detail ?? "failed"}`;
                setNotice(msg);
                setTimeout({
                    "ShadowVetoCard.useCallback[runProbe]": ()=>setNotice(null)
                }["ShadowVetoCard.useCallback[runProbe]"], body.ok ? 4000 : 6500);
                void pull();
            } catch  {
                setNotice("probe failed — network error");
                setTimeout({
                    "ShadowVetoCard.useCallback[runProbe]": ()=>setNotice(null)
                }["ShadowVetoCard.useCallback[runProbe]"], 6500);
            } finally{
                setProbing(false);
            }
        }
    }["ShadowVetoCard.useCallback[runProbe]"], [
        probing,
        pull
    ]);
    // v10.2 SV-TELEMETRY HUB — arm feed wiring + JSON persistence visibility.
    // Light 30s poll (served straight from the persisted snapshot file).
    const [tel, setTel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [telLoaded, setTelLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [telBusy, setTelBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const pullTel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShadowVetoCard.useCallback[pullTel]": async ()=>{
            try {
                const res = await fetch("/api/ai/shadow-veto/telemetry", {
                    cache: "no-store"
                });
                if (res.ok) setTel(await res.json());
                else if (res.status === 503) setTel(null);
            } catch  {
            /* next tick retries */ } finally{
                setTelLoaded(true);
            }
        }
    }["ShadowVetoCard.useCallback[pullTel]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ShadowVetoCard.useEffect": ()=>{
            void pullTel();
            const id = setInterval(pullTel, 30_000);
            return ({
                "ShadowVetoCard.useEffect": ()=>clearInterval(id)
            })["ShadowVetoCard.useEffect"];
        }
    }["ShadowVetoCard.useEffect"], [
        pullTel
    ]);
    const runSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShadowVetoCard.useCallback[runSnapshot]": async ()=>{
            if (telBusy) return;
            setTelBusy(true);
            try {
                const res = await fetch("/api/ai/shadow-veto/telemetry", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        force: true
                    })
                });
                const body = await res.json().catch({
                    "ShadowVetoCard.useCallback[runSnapshot]": ()=>({})
                }["ShadowVetoCard.useCallback[runSnapshot]"]);
                setNotice(body.ok ? "telemetry snapshot captured → .data/shadow-veto-telemetry.json" : `snapshot failed: ${body.error ?? "unknown"}`);
                setTimeout({
                    "ShadowVetoCard.useCallback[runSnapshot]": ()=>setNotice(null)
                }["ShadowVetoCard.useCallback[runSnapshot]"], body.ok ? 4000 : 6500);
                await pullTel();
                void pull();
            } catch  {
                setNotice("telemetry snapshot failed — network error");
                setTimeout({
                    "ShadowVetoCard.useCallback[runSnapshot]": ()=>setNotice(null)
                }["ShadowVetoCard.useCallback[runSnapshot]"], 6500);
            } finally{
                setTelBusy(false);
            }
        }
    }["ShadowVetoCard.useCallback[runSnapshot]"], [
        telBusy,
        pullTel,
        pull
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2d$circuit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BrainCircuit$3e$__["BrainCircuit"], {
                                className: "h-4 w-4 text-violet-neon",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 204,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "Shadow veto // AI core phase 0 — tiered authority at the fence"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 205,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 206,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                        lineNumber: 203,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            notice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-terminal text-[9px] text-neon",
                                children: notice
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 209,
                                columnNumber: 22
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                tone: mode === "veto" ? "violet" : mode === "shadow" ? "amber" : "muted",
                                children: [
                                    "PHASE 0 · ",
                                    mode.toUpperCase()
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 210,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                        lineNumber: 208,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                lineNumber: 202,
                columnNumber: 7
            }, this),
            !data ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-40 items-center justify-center rounded-lg border border-dashed border-violet-neon/25 font-terminal text-[10px] text-ink-3",
                children: !loaded ? "connecting…" : "adjudicator warming — first fence verdicts land within ~2min"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                lineNumber: 215,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex overflow-hidden rounded-md border border-white/10",
                                children: [
                                    "off",
                                    "shadow",
                                    "veto"
                                ].map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>void setMode(m),
                                        disabled: busy || m === mode,
                                        "aria-pressed": m === mode,
                                        "aria-label": `set shadow-veto mode ${m}`,
                                        className: `px-3 py-1.5 font-terminal text-[10px] font-bold uppercase tracking-wider transition ${m === mode ? "bg-violet-neon/15 text-violet-neon" : "text-ink-3 hover:bg-white/5 hover:text-ink"} disabled:opacity-60`,
                                        children: m
                                    }, m, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 224,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 222,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-terminal text-[9px] text-ink-3",
                                children: cooldown > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-amber-neon",
                                    children: [
                                        "control cooldown ",
                                        cooldown,
                                        "s"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                    lineNumber: 238,
                                    columnNumber: 17
                                }, this) : mode === "shadow" ? "verdicts recorded · live flow untouched · fail-open" : mode === "veto" ? "veto-only authority active · blocked trades paper-tracked · revocable" : "adjudicator off"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 236,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "ml-auto flex items-center gap-1.5 font-terminal text-[9px] tabular-nums text-ink-3",
                                title: "LLM adjudication budget (rate-limited)",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {
                                        className: "h-3 w-3 text-neon",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 248,
                                        columnNumber: 15
                                    }, this),
                                    "budget ",
                                    data.health.callsLastHour,
                                    "/",
                                    data.config.budgetPerHour,
                                    "·h",
                                    data.health.pending > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-amber-neon",
                                        children: [
                                            "· ",
                                            data.health.pending,
                                            " in flight"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 250,
                                        columnNumber: 43
                                    }, this),
                                    data.llm && (data.llm.cooling || data.llm.consecutive429 > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>void runProbe(),
                                        disabled: probing,
                                        "aria-label": "probe the LLM link now",
                                        title: "fire one minimal LLM probe through the 429 shield — success resets the shield instantly (1 per 2min)",
                                        className: "rounded border border-violet-neon/40 px-1.5 py-0.5 font-bold text-violet-neon transition hover:bg-violet-neon/10 disabled:opacity-50",
                                        children: probing ? "PROBING…" : "PROBE"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 253,
                                        columnNumber: 17
                                    }, this),
                                    data.llm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `ml-1 rounded px-1.5 py-0.5 font-bold ${data.llm.cooling ? "bg-danger-neon/15 text-danger-neon" : data.llm.consecutive429 > 0 ? "bg-amber-neon/10 text-amber-neon" : "bg-neon/10 text-neon"}`,
                                        title: data.llm.cooling ? `429 budget shield active — background LLM parked ${Math.ceil(data.llm.cooldownRemainsMs / 1000)}s (operator tier protected)` : "LLM link healthy",
                                        children: data.llm.cooling ? `NEURAL LINK · 429 COOLDOWN ${Math.ceil(data.llm.cooldownRemainsMs / 1000)}s` : data.llm.consecutive429 > 0 ? `NEURAL LINK · RECOVERING (×${data.llm.consecutive429})` : "NEURAL LINK · OK"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 265,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 247,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                        lineNumber: 221,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-4 gap-2 sm:grid-cols-8",
                        children: [
                            {
                                label: "ADJUDICATED",
                                value: String(stats?.total ?? 0),
                                cls: "text-ink"
                            },
                            {
                                label: "HAIR-PASS",
                                value: String(stats?.passSide ?? 0),
                                cls: "text-neon"
                            },
                            {
                                label: "FENCE-REJ",
                                value: String(stats?.rejectSide ?? 0),
                                cls: "text-amber-neon"
                            },
                            {
                                label: "VETO VOICES",
                                value: String(stats?.vetoCount ?? 0),
                                cls: "text-magenta-neon"
                            },
                            {
                                label: "MODEL SHARE",
                                value: stats?.modelSharePct !== null && stats?.modelSharePct !== undefined ? `${stats.modelSharePct}%` : "—",
                                cls: "text-cyan-neon"
                            },
                            {
                                label: "MODEL 24H",
                                value: stats?.recent24h ? stats.recent24h.modelSharePct !== null ? `${stats.recent24h.modelSharePct}%` : "—" : "—",
                                cls: stats?.recent24h?.modelSharePct !== null && stats?.recent24h?.modelSharePct !== undefined && stats.recent24h.modelSharePct < 50 ? "text-amber-neon" : "text-neon"
                            },
                            {
                                label: "GROUNDED",
                                value: stats?.modelGroundedPct !== null && stats?.modelGroundedPct !== undefined ? `${stats.modelGroundedPct}%` : "—",
                                cls: stats?.modelGroundedPct !== null && stats?.modelGroundedPct !== undefined && stats.modelGroundedPct < 100 ? "text-amber-neon" : "text-neon"
                            },
                            {
                                label: "GATE AGREE",
                                value: stats && stats.rejectSide ? `${Math.round(stats.gateAgreement / stats.rejectSide * 100)}%` : "—",
                                cls: "text-ink"
                            }
                        ].map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5 text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "font-terminal text-[8px] uppercase tracking-[0.14em] text-ink-3",
                                        children: c.label
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 292,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `font-terminal text-sm font-bold tabular-nums ${c.cls}`,
                                        children: c.value
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 293,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, c.label, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 291,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                        lineNumber: 276,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-lg border border-white/8 bg-white/[0.02] p-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1 flex items-center justify-between px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gavel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gavel$3e$__["Gavel"], {
                                                className: "h-3 w-3 text-magenta-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 302,
                                                columnNumber: 17
                                            }, this),
                                            "A/B evidence arms · win rate / wilson-LB95 / net"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 301,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            "target ",
                                            arms[0]?.target ?? 30,
                                            " settled per arm"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 305,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 300,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "divide-y divide-white/5",
                                children: arms.map((a)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ArmRow, {
                                        a: a
                                    }, a.id, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 309,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 307,
                                columnNumber: 13
                            }, this),
                            mode !== "veto" && (arms.find((a)=>a.id === "paper-veto")?.n ?? 0) === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1.5 border-t border-white/5 px-1 pt-1.5 font-terminal text-[9px] leading-relaxed text-ink-3",
                                title: "paper-veto only fills when a core VETO actually BLOCKS a deploy: globally after promotion to veto mode, or (v11.0) on a PROVEN pattern cell while still in shadow. In shadow mode unblocked PASS+VETO verdicts still deploy → they feed real-veto.",
                                children: "paper-veto idle BY DESIGN — it fills when the core actually BLOCKS deploys: after global promotion, or (v11.0) on proven pattern cells below."
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 313,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-1.5 border-t border-white/5 px-1 pt-1.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap items-center gap-x-2 gap-y-0.5 font-terminal text-[9px]",
                                        children: [
                                            data.promotion.criteria.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `${c.ok ? "text-neon" : "text-ink-3"}`,
                                                    title: c.detail,
                                                    children: [
                                                        c.ok ? "✓" : "✗",
                                                        " ",
                                                        c.id
                                                    ]
                                                }, c.id, true, {
                                                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                    lineNumber: 320,
                                                    columnNumber: 19
                                                }, this)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `ml-auto font-bold ${data.promotion.ready ? "text-neon" : "text-ink-3"}`,
                                                children: data.promotion.ready ? "PROMOTION READY — veto mode unlockable" : "promotion not ready"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 324,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 318,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `mt-0.5 font-terminal text-[9px] ${data.promotion.revocation.pressure ? "text-amber-neon" : "text-ink-3"}`,
                                        title: data.promotion.revocation.detail,
                                        children: [
                                            data.promotion.revocation.pressure ? "⚠ revocation pressure — " : "",
                                            data.promotion.revocation.detail
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 326,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 317,
                                columnNumber: 13
                            }, this),
                            data.patternVeto && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-1.5 border-t border-white/5 px-1 pt-1.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap items-center gap-x-2 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-bold normal-case tracking-normal",
                                                children: "PATTERN-VETO"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 335,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: data.patternVeto.enabled ? "text-neon" : "text-ink-3",
                                                children: data.patternVeto.enabled ? "armed" : "off"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 336,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "ml-auto normal-case tracking-normal",
                                                children: data.patternVeto.proven.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-bold text-amber-neon",
                                                    children: [
                                                        "AUTHORITY ACTIVE: ",
                                                        data.patternVeto.proven.join(" · ")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                    lineNumber: 339,
                                                    columnNumber: 23
                                                }, this) : "no proven cell — fail-open until a cell passes the proof"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 337,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 334,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-0.5 space-y-0.5",
                                        children: data.patternVeto.rows.filter((r)=>r.proven || r.nVeto >= 3).slice(0, 4).map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between font-terminal text-[9px]",
                                                title: `${r.detail} — proof: n≥8/side · 15pp WR sep · Wilson-UB95(veto) < WR(keep) · net(veto) < 0`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `truncate font-bold ${r.proven ? "text-amber-neon" : "text-ink-2"}`,
                                                        children: r.pattern
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 351,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `shrink-0 tabular-nums ${r.proven ? "text-amber-neon" : "text-ink-3"}`,
                                                        children: [
                                                            "veto ",
                                                            r.nVeto,
                                                            " wr ",
                                                            r.wrVeto !== null ? `${r.wrVeto.toFixed(0)}%` : "—",
                                                            " / keep ",
                                                            r.nKeep,
                                                            " wr ",
                                                            r.wrKeep !== null ? `${r.wrKeep.toFixed(0)}%` : "—",
                                                            " · UB95 ",
                                                            r.ubVeto !== null ? `${r.ubVeto.toFixed(0)}%` : "—",
                                                            " ",
                                                            r.proven ? "· PROVEN" : ""
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 352,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, r.pattern, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 350,
                                                columnNumber: 23
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 345,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 333,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                        lineNumber: 299,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid gap-3 lg:grid-cols-[1fr_260px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                        children: "recent adjudications · veto-only voices"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 365,
                                        columnNumber: 15
                                    }, this),
                                    recent.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex h-24 items-center justify-center rounded-lg border border-dashed border-violet-neon/20 font-terminal text-[10px] text-ink-3",
                                        children: "no fence candidates adjudicated yet — verdicts appear as candidates touch the boundary band"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 367,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "max-h-[168px] space-y-0.5 overflow-y-auto pr-1",
                                        children: recent.map((v)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-[58px_40px_44px_46px_1fr] items-center gap-1 px-1 py-1 font-terminal text-[10px] tabular-nums transition hover:bg-white/[0.03]",
                                                title: `${v.label} · ${v.side === "PASS" ? "hair-thin pass" : "fence reject"} · source ${v.source}${v.audit ? ` · grounding audit ${v.audit.verdict} (cited ${v.audit.cited}, unmatched ${v.audit.unmatched.length})` : " · pre-audit instrument"}${v.outcome ? ` · settled ${v.outcome.status} ${v.outcome.pnlPercent >= 0 ? "+" : ""}${v.outcome.pnlPercent}%` : ""}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "truncate text-ink-3",
                                                        children: v.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 374,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `truncate font-bold ${v.direction === "LONG" ? "text-neon" : "text-magenta-neon"}`,
                                                        children: v.symbol.replace("USDT", "")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 375,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: SIDE_CLS[v.side],
                                                        children: v.side === "PASS" ? "hair✓" : "fence✗"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 376,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `rounded border px-1 text-center text-[9px] font-bold leading-4 ${v.verdict === "VETO" ? "border-[rgba(255,77,94,0.4)] text-danger-neon" : "border-[rgba(0,255,163,0.4)] text-neon"}`,
                                                        children: v.verdict
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 377,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "min-w-0 truncate text-[9px] text-ink-2",
                                                        title: v.reason,
                                                        children: [
                                                            v.audit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `mr-1 font-bold ${v.audit.verdict === "VIOLATION" ? "text-danger-neon" : v.audit.verdict === "SUSPECT" ? "text-amber-neon" : "text-neon/70"}`,
                                                                title: `grounding ${v.audit.verdict} — ${v.audit.cited} cited, ${v.audit.unmatched.length} unmatched`,
                                                                children: v.audit.verdict === "VIOLATION" ? "✗ungrounded→heuristic" : v.audit.verdict === "SUSPECT" ? "⚠" : "✓"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                                lineNumber: 380,
                                                                columnNumber: 27
                                                            }, this),
                                                            v.confidence,
                                                            "% · gap ",
                                                            v.gap >= 0 ? "+" : "",
                                                            v.gap.toFixed(1),
                                                            " · ",
                                                            v.reason
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 378,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, v.id, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 373,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 371,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 364,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-1 flex items-center justify-between font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "paper ledger · would-have-traded"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 396,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "tabular-nums",
                                                children: [
                                                    stats?.paperOpen ?? 0,
                                                    " open / ",
                                                    stats?.paperSettled ?? 0,
                                                    " settled"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 397,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 395,
                                        columnNumber: 15
                                    }, this),
                                    paper.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex h-24 items-center justify-center rounded-lg border border-dashed border-neon/20 font-terminal text-[10px] text-ink-3",
                                        children: "no counterfactual positions — opens when the core disagrees with a fence reject"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 402,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "max-h-[168px] space-y-0.5 overflow-y-auto pr-1",
                                        children: paper.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1.5 px-1 py-1 font-terminal text-[10px] tabular-nums transition hover:bg-white/[0.03]",
                                                title: `${p.id} · verdict ${p.verdictId} · entry ${p.entry} · SL ${p.stop.toFixed(p.entry > 100 ? 1 : 4)} · TP3 ${p.tp3.toFixed(p.entry > 100 ? 1 : 4)} · ${p.leverage}× · ${p.closeNote ?? (p.outcome ? "" : `running (MFE ${p.maxPnlPercent >= 0 ? "+" : ""}${p.maxPnlPercent}%)`)}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-10 shrink-0 truncate text-ink-3",
                                                        children: p.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 407,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-12 shrink-0 truncate font-bold ${p.direction === "LONG" ? "text-neon" : "text-magenta-neon"}`,
                                                        children: p.symbol.replace("USDT", "")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 408,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-14 shrink-0 ${p.outcome ? p.status === "SL" ? "text-danger-neon" : "text-neon" : "text-amber-neon"}`,
                                                        children: p.outcome ? p.status : "OPEN"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 409,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `ml-auto w-14 shrink-0 text-right ${p.pnlPercent > 0 ? "text-neon" : p.pnlPercent < 0 ? "text-danger-neon" : "text-ink-3"}`,
                                                        children: p.outcome ? `${p.pnlPercent >= 0 ? "+" : ""}${p.pnlPercent.toFixed(1)}%` : `TP ${p.reachedTp}/3`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 410,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-14 shrink-0 text-right text-ink-3",
                                                        children: p.outcome ? usd(p.pnlUsd) : ago(p.at)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 411,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, p.id, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 406,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 404,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 px-1 font-terminal text-[9px] leading-relaxed text-ink-3",
                                        children: [
                                            "Honesty contract: paper rows use ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-ink-2",
                                                children: "base geometry"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 417,
                                                columnNumber: 50
                                            }, this),
                                            " (slAtrMult×ATR stop, base RR, tranche ladder, real fee model) — directional-edge evidence at the fence, never presented as real PnL.",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: data.health.auditViolations > 0 ? "text-amber-neon" : "text-ink-2",
                                                title: "v8.2.1 grounding patch — every MODEL verdict is number-audited against its evidence bundle; violations are discarded and the heuristic speaks instead",
                                                children: [
                                                    "Grounding audit: every MODEL verdict number-checked — ",
                                                    data.health.auditViolations,
                                                    " violation",
                                                    data.health.auditViolations === 1 ? "" : "s",
                                                    " discarded."
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 418,
                                                columnNumber: 22
                                            }, this),
                                            " ",
                                            "Records → .data/shadow-veto.jsonl (",
                                            data.health.fileKB,
                                            "KB)."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 416,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 394,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                        lineNumber: 362,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-lg border border-white/8 bg-white/[0.02] p-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1.5 flex flex-wrap items-center justify-between gap-1.5 px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__["Activity"], {
                                                className: "h-3 w-3 text-cyan-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 428,
                                                columnNumber: 17
                                            }, this),
                                            "Telemetry hub · arm feed wiring",
                                            tel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "normal-case tracking-normal",
                                                title: new Date(tel.capturedAt).toLocaleString(),
                                                children: [
                                                    "· snapshot ",
                                                    ago(tel.capturedAt),
                                                    " ago"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 431,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 427,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1.5",
                                        children: [
                                            tel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "tabular-nums normal-case tracking-normal",
                                                title: `${tel.store.file} · ${tel.store.writes} atomic writes · capture ${tel.captureMs}ms · schemaVersion ${tel.schemaVersion}`,
                                                children: [
                                                    tel.store.file,
                                                    " · ",
                                                    tel.store.fileKB,
                                                    "KB · ",
                                                    tel.store.historySamples,
                                                    " samples"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 438,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>void runSnapshot(),
                                                disabled: telBusy,
                                                "aria-label": "capture telemetry snapshot now",
                                                title: "capture a fresh telemetry snapshot now (POST force — bypasses the 10min throttle)",
                                                className: "rounded border border-cyan-neon/40 px-1.5 py-0.5 font-bold text-cyan-neon transition hover:bg-cyan-neon/10 disabled:opacity-50",
                                                children: telBusy ? "…" : "SNAPSHOT"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 442,
                                                columnNumber: 17
                                            }, this),
                                            tel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "/api/ai/shadow-veto/telemetry?download=1",
                                                download: true,
                                                "aria-label": "download telemetry JSON",
                                                title: "download the consolidated telemetry JSON (schemaVersion 1 — retrievable and usable)",
                                                className: "flex items-center gap-1 rounded border border-white/15 px-1.5 py-0.5 font-bold text-ink-2 transition hover:bg-white/5 hover:text-ink",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                        className: "h-3 w-3",
                                                        "aria-hidden": true
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 459,
                                                        columnNumber: 21
                                                    }, this),
                                                    "JSON"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 452,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 436,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 426,
                                columnNumber: 13
                            }, this),
                            !tel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-14 items-center justify-center rounded-lg border border-dashed border-cyan-neon/20 font-terminal text-[10px] text-ink-3",
                                children: !telLoaded ? "reading telemetry store…" : "telemetry warming — first capture lands on the next engine tick or SNAPSHOT"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                lineNumber: 467,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 gap-1 sm:grid-cols-2",
                                        children: tel.arms.map((a)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1.5 rounded-md border border-white/5 bg-white/[0.02] px-1.5 py-1 font-terminal text-[10px] tabular-nums",
                                                title: `${a.feedSource}\n${a.neverFed ? "never fed — " : a.starved ? `STARVED — last fed ${ago(a.lastFedAt)} ago · ` : `last fed ${ago(a.lastFedAt)} ago · `}${a.starveDetail ?? ""}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `h-1.5 w-1.5 shrink-0 rounded-full ${a.starved ? "bg-danger-neon" : a.neverFed ? "bg-amber-neon/70" : "bg-neon"}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 479,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-20 shrink-0 truncate font-bold text-ink",
                                                        children: a.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 480,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-10 shrink-0 text-right text-ink-2",
                                                        children: [
                                                            a.n,
                                                            "/",
                                                            a.target
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 481,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "h-1 min-w-6 flex-1 overflow-hidden rounded-full bg-white/5",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: `h-full rounded-full ${a.id.startsWith("real") ? "bg-neon" : "bg-cyan-neon"} opacity-80`,
                                                            style: {
                                                                width: `${a.fillPct}%`
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                            lineNumber: 485,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 484,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-16 shrink-0 text-right ${a.neverFed ? "text-amber-neon" : a.starved ? "text-danger-neon" : "text-ink-3"}`,
                                                        children: a.neverFed ? "idle" : a.starved ? "STARVED" : `fed ${ago(a.lastFedAt)}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 487,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-14 shrink-0 text-right ${a.netUsd > 0 ? "text-neon" : a.netUsd < 0 ? "text-danger-neon" : "text-ink-3"}`,
                                                        children: a.n ? usd(a.netUsd) : "—"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                        lineNumber: 488,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, a.id, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 474,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 472,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 border-t border-white/5 px-1 pt-1.5 font-terminal text-[9px]",
                                        children: [
                                            [
                                                [
                                                    "ADJ",
                                                    tel.wiring.adjudicator
                                                ],
                                                [
                                                    "LINK",
                                                    tel.wiring.realLink
                                                ],
                                                [
                                                    "CLOSE",
                                                    tel.wiring.outcomeClosure
                                                ],
                                                [
                                                    "SWEEP",
                                                    tel.wiring.paperSweep
                                                ]
                                            ].map(([k, w])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: w.ok ? "text-neon" : "text-danger-neon",
                                                    title: w.detail,
                                                    children: [
                                                        w.ok ? "✓" : "✗",
                                                        " ",
                                                        k
                                                    ]
                                                }, k, true, {
                                                    fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                    lineNumber: 499,
                                                    columnNumber: 21
                                                }, this)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: tel.wiring.llm.ok ? "text-neon" : "text-amber-neon",
                                                title: tel.wiring.llm.detail,
                                                children: [
                                                    tel.wiring.llm.ok ? "✓" : "~",
                                                    " LLM"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 503,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "tabular-nums text-ink-3",
                                                title: `${tel.wiring.pipeline.unlinkedPassStale} ACTIVE link leak(s) (swept orphans ${tel.wiring.pipeline.unlinkedPassOrphan} · aged out ${tel.wiring.pipeline.unlinkedPassAged}) · ${tel.wiring.pipeline.pendingRealOutcomes} awaiting closure · ${tel.wiring.pipeline.verdicts24h} verdicts/24h · ${tel.wiring.pipeline.pendingPapers} papers open`,
                                                children: [
                                                    "leak ",
                                                    tel.wiring.pipeline.unlinkedPassStale,
                                                    " · closing ",
                                                    tel.wiring.pipeline.pendingRealOutcomes,
                                                    " · v24h ",
                                                    tel.wiring.pipeline.verdicts24h
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 506,
                                                columnNumber: 19
                                            }, this),
                                            tel.alerts.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `ml-auto rounded px-1.5 py-0.5 font-bold ${tel.alerts.some((a)=>a.level === "warn") ? "bg-amber-neon/10 text-amber-neon" : "bg-white/5 text-ink-3"}`,
                                                title: tel.alerts.map((a)=>`${a.level.toUpperCase()} · ${new Date(a.at).toISOString().slice(11, 16)}Z · ${a.text}`).join("\n"),
                                                children: [
                                                    tel.alerts.length,
                                                    " alert",
                                                    tel.alerts.length === 1 ? "" : "s"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                                lineNumber: 510,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                                        lineNumber: 492,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                        lineNumber: 425,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
                lineNumber: 219,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/ShadowVetoCard.tsx",
        lineNumber: 201,
        columnNumber: 5
    }, this);
}
_s(ShadowVetoCard, "o9rXIkIN5ayrddH3dHDbbD9PBSE=");
_c1 = ShadowVetoCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "ArmRow");
__turbopack_context__.k.register(_c1, "ShadowVetoCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/EntryLeversCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EntryLeversCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crosshair$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crosshair$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/crosshair.js [app-client] (ecmascript) <export default as Crosshair>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$refresh$2d$cw$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RefreshCw$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/refresh-cw.js [app-client] (ecmascript) <export default as RefreshCw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const LEVER_SHORT = {
    EXT: "EXTENSION",
    FLOW: "CROWD-FLOW",
    CAUSE: "CHASE-CAUSE",
    STALE: "STALE-FILL",
    SCALP: "SCALP-VALVE",
    LEVCAP: "LEV-CAP"
};
const MODE_TONE = {
    shadow: "text-amber-neon",
    enforce: "text-magenta-neon",
    off: "text-ink-3"
};
const MODE_ORDER = [
    "shadow",
    "enforce",
    "off"
];
function ago(ts) {
    const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return `${s}s`;
    if (s < 3600) return `${Math.round(s / 60)}m`;
    if (s < 86400) return `${Math.round(s / 3600)}h`;
    return `${Math.round(s / 86400)}d`;
}
function avgCls(v) {
    return v > 0.2 ? "text-neon" : v < -0.5 ? "text-danger-neon" : "text-amber-neon";
}
function LeverRow({ s, mode, pinned, target, onCycle, busy }) {
    const pct = Math.min(100, s.flagN / target * 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-1 py-1.5",
        title: s.gateNote,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-1.5 font-terminal text-[10px]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onCycle,
                    disabled: busy,
                    className: `w-[92px] shrink-0 truncate text-left font-bold hover:underline ${MODE_TONE[mode] ?? "text-ink-3"} disabled:opacity-50`,
                    title: `${LEVER_SHORT[s.lever]} — mode ${mode.toUpperCase()}${pinned ? " (operator-pinned)" : ""} (click to cycle shadow→enforce→off)`,
                    children: [
                        LEVER_SHORT[s.lever] ?? s.lever,
                        pinned ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "ml-1 text-[8px] text-cyan-neon",
                            children: "◈"
                        }, void 0, false, {
                            fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                            lineNumber: 78,
                            columnNumber: 21
                        }, this) : null
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                    lineNumber: 71,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: `w-[62px] shrink-0 text-[9px] ${MODE_TONE[mode] ?? "text-ink-3"}`,
                    children: mode.toUpperCase()
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-1 flex-1 overflow-hidden rounded-full bg-white/5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `h-full rounded-full opacity-80 ${s.gatePass ? "bg-magenta-neon" : "bg-neon"}`,
                        style: {
                            width: `${pct}%`
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                    lineNumber: 81,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "w-14 shrink-0 text-right tabular-nums text-ink-3",
                    title: `flagged settled rows / gate target (${target})`,
                    children: [
                        s.flagN,
                        "/",
                        target
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                    lineNumber: 84,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "w-10 shrink-0 text-right tabular-nums text-ink",
                    title: `fires in last 7d`,
                    children: [
                        s.fires7d,
                        "×7d"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                    lineNumber: 87,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "w-12 shrink-0 text-right tabular-nums text-ink-2",
                    title: "flagged cohort win rate",
                    children: s.flagN ? `${s.flagWr.toFixed(0)}%` : "—"
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                    lineNumber: 90,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: `w-14 shrink-0 text-right tabular-nums ${s.flagN ? avgCls(s.flagAvg) : "text-ink-3"}`,
                    title: "flagged cohort avg pnl% (margin-relative) vs unflagged base",
                    children: s.flagN ? s.flagAvg.toFixed(2) : "—"
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                    lineNumber: 93,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
            lineNumber: 70,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
        lineNumber: 69,
        columnNumber: 5
    }, this);
}
_c = LeverRow;
function EntryLeversCard() {
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const pull = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "EntryLeversCard.useCallback[pull]": async ()=>{
            try {
                const res = await fetch("/api/entry-levers", {
                    cache: "no-store"
                });
                if (res.ok) setData(await res.json());
            } catch  {
            /* transient */ } finally{
                setLoaded(true);
            }
        }
    }["EntryLeversCard.useCallback[pull]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EntryLeversCard.useEffect": ()=>{
            void pull();
            const t = setInterval({
                "EntryLeversCard.useEffect.t": ()=>void pull()
            }["EntryLeversCard.useEffect.t"], 30_000);
            return ({
                "EntryLeversCard.useEffect": ()=>clearInterval(t)
            })["EntryLeversCard.useEffect"];
        }
    }["EntryLeversCard.useEffect"], [
        pull
    ]);
    const cycle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "EntryLeversCard.useCallback[cycle]": async (lever, current)=>{
            const next = MODE_ORDER[(MODE_ORDER.indexOf(current) + 1) % MODE_ORDER.length];
            setBusy(true);
            try {
                const res = await fetch("/api/entry-levers", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        lever,
                        mode: next
                    })
                });
                const body = await res.json();
                if (!res.ok) __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(body.error ?? "mode change refused");
                else __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(`${lever} → ${next.toUpperCase()}`);
                await pull();
            } catch  {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("network error");
            } finally{
                setBusy(false);
            }
        }
    }["EntryLeversCard.useCallback[cycle]"], [
        pull
    ]);
    const st = data?.stats;
    const target = Number(data?.params.promoteMinN ?? 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crosshair$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crosshair$3e$__["Crosshair"], {
                                className: "h-4 w-4 text-violet-neon",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 149,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "Entry levers // late-entry shield — evidence-gated authority"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 150,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 151,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                tone: st?.perLever.some((l)=>data?.modes[l.lever] === "enforce") ? "violet" : "amber",
                                children: [
                                    st?.perLever.filter((l)=>data?.modes[l.lever] === "enforce").length ?? 0,
                                    " ENFORCING"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 154,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "ghost",
                                size: "icon",
                                className: "h-6 w-6",
                                onClick: ()=>void pull(),
                                "aria-label": "refresh entry levers",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$refresh$2d$cw$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RefreshCw$3e$__["RefreshCw"], {
                                    className: `h-3 w-3 ${loaded ? "" : "animate-spin"}`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                    lineNumber: 158,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 157,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                        lineNumber: 153,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                lineNumber: 147,
                columnNumber: 7
            }, this),
            !st ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-24 items-center justify-center rounded-lg border border-dashed border-violet-neon/25 font-terminal text-[10px] text-ink-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                        lineNumber: 165,
                        columnNumber: 11
                    }, this),
                    " ",
                    loaded ? "shield state unavailable" : "loading shield state…"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                lineNumber: 164,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 px-1 pb-1 font-terminal text-[9px] text-ink-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "WINDOW ",
                                    st.windowDays,
                                    "d · cohort n=",
                                    st.cohortN,
                                    " · WR ",
                                    st.cohortWr.toFixed(1),
                                    "% · avg ",
                                    st.cohortAvg.toFixed(2)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 170,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "ml-auto",
                                title: "promotion gate: n≥100 · flagged avg ≤ −0.5 · separation ≥ 0.5 · auto-demote on heal",
                                children: [
                                    "GATE n≥",
                                    target,
                                    " · avg≤−0.5 · sep≥0.5"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 173,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                        lineNumber: 169,
                        columnNumber: 11
                    }, this),
                    st.perLever.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LeverRow, {
                            s: l,
                            mode: data?.modes[l.lever] ?? "shadow",
                            pinned: !!data?.manual?.[l.lever],
                            target: target,
                            busy: busy,
                            onCycle: ()=>void cycle(l.lever, data?.modes[l.lever] ?? "shadow")
                        }, l.lever, false, {
                            fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                            lineNumber: 178,
                            columnNumber: 13
                        }, this)),
                    data?.autoNotes?.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-1 border-t border-white/5 pt-1.5 font-terminal text-[9px] text-ink-3",
                        children: data.autoNotes.slice(0, 2).map((n, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "truncate px-1",
                                children: [
                                    "⟡ ",
                                    n
                                ]
                            }, i, true, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 183,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                        lineNumber: 181,
                        columnNumber: 13
                    }, this) : null,
                    data?.journal?.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-0.5 font-terminal text-[9px] text-ink-3",
                        children: data.journal.slice(0, 2).map((j, i)=>{
                            const fired = j.fired?.map((f)=>f.lever).join(",") || "—";
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "truncate px-1",
                                children: [
                                    j.at ? ago(new Date(String(j.at)).getTime()) : "—",
                                    " · ",
                                    String(j.symbol ?? "?"),
                                    " · ",
                                    String(j.observe ?? false) === "true" ? "OBSERVE" : j.block ? `BLOCKED(${String(j.block)})` : "shadow-log",
                                    " · [",
                                    fired,
                                    "]"
                                ]
                            }, i, true, {
                                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                                lineNumber: 194,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                        lineNumber: 190,
                        columnNumber: 13
                    }, this) : null,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-1 pt-1 font-terminal text-[9px] leading-relaxed text-ink-3",
                        children: "Seven deterministic levers judge every deploy · shadow journal now, enforce ONLY on own-cohort evidence · click a lever to cycle its mode · forced/capture deploys are OBSERVE-ONLY · fail-open."
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                        lineNumber: 201,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
                lineNumber: 168,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/EntryLeversCard.tsx",
        lineNumber: 146,
        columnNumber: 5
    }, this);
}
_s(EntryLeversCard, "Hpen9uyNJGHCpKgCOSAKyL4xY8I=");
_c1 = EntryLeversCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "LeverRow");
__turbopack_context__.k.register(_c1, "EntryLeversCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/FuturesRadarCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FuturesRadarCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/radar.js [app-client] (ecmascript) <export default as Radar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
/* ── grid geometry: rows = price, cols = OI ── */ const QUADRANT_ORDER = [
    "Q1_FRESH_LONG",
    "Q2_SQUEEZE",
    "Q3_FRESH_SHORT",
    "Q4_CAPITULATION"
];
/* ── defensive formatters: null/undefined/non-finite → "—" (never NaN) ── */ function num(v, digits = 2) {
    return typeof v === "number" && Number.isFinite(v) ? v.toFixed(digits) : "—";
}
function pct(v, digits = 2) {
    return typeof v === "number" && Number.isFinite(v) ? `${v > 0 ? "+" : ""}${v.toFixed(digits)}%` : "—";
}
function pctPlain(v, digits = 1) {
    return typeof v === "number" && Number.isFinite(v) ? `${v.toFixed(digits)}%` : "—";
}
function usdCompact(v) {
    return typeof v === "number" && Number.isFinite(v) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtUsd"])(v) : "—";
}
function bps(v) {
    return typeof v === "number" && Number.isFinite(v) ? `${v > 0 ? "+" : ""}${v} bps` : "—";
}
function signCls(v) {
    if (typeof v !== "number" || !Number.isFinite(v) || v === 0) return "text-ink-3";
    return v > 0 ? "text-neon" : "text-danger-neon";
}
function confCls(c) {
    if (c === "HIGH") return "border-[rgba(0,255,163,0.4)] text-neon";
    if (c === "MEDIUM") return "border-[rgba(255,179,71,0.4)] text-amber-neon";
    return "border-white/15 text-ink-3"; /* LOW / COLLECTING */ 
}
function shortIso(iso) {
    if (!iso) return "—";
    const t = new Date(iso).getTime();
    return Number.isFinite(t) ? `${new Date(t).toISOString().slice(11, 16)}Z` : "—";
}
/* ── tiny building blocks ── */ function FamilyBadge({ letter }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "shrink-0 rounded border border-[rgba(178,107,255,0.35)] px-1 font-terminal text-[9px] font-bold leading-4 text-violet-neon",
        children: letter
    }, void 0, false, {
        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
        lineNumber: 171,
        columnNumber: 5
    }, this);
}
_c = FamilyBadge;
function ShimmerBar({ className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded bg-white/[0.05]", className),
        style: {
            backgroundImage: "linear-gradient(90deg, transparent, rgba(255,255,255,0.07), transparent)",
            backgroundSize: "200% 100%",
            animation: "shimmer 1.6s infinite"
        }
    }, void 0, false, {
        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
        lineNumber: 179,
        columnNumber: 5
    }, this);
}
_c1 = ShimmerBar;
function Skeleton() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        role: "status",
        "aria-label": "loading futures taxonomy",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "aria-hidden": true,
                className: "grid grid-cols-[14px_1fr_1fr] gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 194,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 195,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 196,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-12"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 197,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-24"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-24"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 199,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-12"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 200,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-24"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 201,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-24"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 202,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 193,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "aria-hidden": true,
                className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
                children: Array.from({
                    length: 4
                }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                        className: "h-16"
                    }, i, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 206,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 204,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ShimmerBar, {
                className: "h-24"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 209,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
        lineNumber: 192,
        columnNumber: 5
    }, this);
}
_c2 = Skeleton;
function AxisHead({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "aria-hidden": true,
        className: "flex items-center justify-center font-terminal text-[9px] font-bold uppercase tracking-[0.14em] text-ink-3",
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
        lineNumber: 216,
        columnNumber: 5
    }, this);
}
_c3 = AxisHead;
function AxisRow({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "aria-hidden": true,
        className: "flex items-center justify-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "font-terminal text-[8px] font-bold uppercase tracking-[0.2em] text-ink-3 [writing-mode:vertical-rl] rotate-180",
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
            lineNumber: 225,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
        lineNumber: 224,
        columnNumber: 5
    }, this);
}
_c4 = AxisRow;
function QuadrantCell({ id, meta, study, live, priceDelta1h, oiDelta1h }) {
    const label = (meta?.label ?? study?.label ?? id.replace(/^[^_]+_/, "")).toUpperCase();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        title: `${id.replace(/_/g, " ")}${meta?.meaning ? ` — ${meta.meaning}` : ""}${study ? ` · n ${study.n} · fwd1h ${pct(study.meanFwd1h)} · ${study.verdict}` : ""}`,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("min-w-0 rounded-lg border p-1.5", live ? "border-neon/60 bg-[rgb(var(--neon-rgb)/0.05)]" : "border-white/8 bg-white/[0.02]"),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "min-w-0 truncate font-terminal text-[10px] font-bold text-ink",
                        children: [
                            id.slice(0, 2),
                            " · ",
                            label
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 257,
                        columnNumber: 9
                    }, this),
                    live && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-auto shrink-0 rounded border border-[rgba(0,255,163,0.5)] px-1 font-terminal text-[8px] font-bold leading-4 text-neon",
                        children: "LIVE"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 261,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 256,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0.5 truncate font-terminal text-[9px] leading-snug text-ink-3",
                title: meta?.meaning,
                children: meta?.meaning ?? "—"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 266,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 font-terminal text-[9px] tabular-nums",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-ink-2",
                        children: [
                            "n ",
                            study ? study.n : "—"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 270,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-bold", study ? signCls(study.meanFwd1h) : "text-ink-3"),
                        children: pct(study?.meanFwd1h)
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 271,
                        columnNumber: 9
                    }, this),
                    study && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("ml-auto rounded border px-1 text-[8px] font-bold leading-4", study.verdict === "CONTINUES" ? "border-[rgba(0,255,163,0.4)] text-neon" : "border-[rgba(255,179,71,0.4)] text-amber-neon"),
                        children: study.verdict
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 273,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 269,
                columnNumber: 7
            }, this),
            live && (typeof priceDelta1h === "number" || typeof oiDelta1h === "number") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0.5 font-terminal text-[8px] tabular-nums text-ink-2",
                children: [
                    "Δ1h P ",
                    pct(priceDelta1h),
                    " · OI ",
                    pct(oiDelta1h)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 284,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
        lineNumber: 249,
        columnNumber: 5
    }, this);
}
_c5 = QuadrantCell;
function FamilyPanel({ letter, title, rows, dim, dimTip }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("min-w-0 rounded-lg border border-white/8 bg-white/[0.02] p-2", dim && "opacity-50"),
        title: dim ? dimTip : undefined,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-1 flex items-center gap-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FamilyBadge, {
                        letter: letter
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 308,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "min-w-0 truncate font-terminal text-[9px] font-bold uppercase tracking-[0.14em] text-ink-2",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 309,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 307,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-0.5",
                children: rows.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-baseline justify-between gap-2 font-terminal text-[10px] tabular-nums",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] uppercase tracking-wider text-ink-3",
                                children: r.k
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 314,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 font-bold", r.cls ?? "text-ink"),
                                children: r.v
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 315,
                                columnNumber: 13
                            }, this)
                        ]
                    }, r.k, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 313,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 311,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
        lineNumber: 306,
        columnNumber: 5
    }, this);
}
_c6 = FamilyPanel;
function FuturesRadarCard() {
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [err, setErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const pull = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FuturesRadarCard.useCallback[pull]": async ()=>{
            try {
                const res = await fetch("/api/futures", {
                    cache: "no-store"
                });
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                setData(await res.json());
                setErr(null);
            } catch  {
                setErr("feed unreachable — engine route or sampler down");
            }
        }
    }["FuturesRadarCard.useCallback[pull]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FuturesRadarCard.useEffect": ()=>{
            void pull();
            const id = setInterval(pull, 30_000);
            return ({
                "FuturesRadarCard.useEffect": ()=>clearInterval(id)
            })["FuturesRadarCard.useEffect"];
        }
    }["FuturesRadarCard.useEffect"], [
        pull
    ]);
    const anchor = data?.anchors?.[0];
    const edge = data?.edge ?? null;
    const studyByQ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FuturesRadarCard.useMemo[studyByQ]": ()=>new Map((edge?.quadrantStudy ?? []).map({
                "FuturesRadarCard.useMemo[studyByQ]": (s)=>[
                        s.quadrant,
                        s
                    ]
            }["FuturesRadarCard.useMemo[studyByQ]"]))
    }["FuturesRadarCard.useMemo[studyByQ]"], [
        edge
    ]);
    const leaders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FuturesRadarCard.useMemo[leaders]": ()=>[
                ...edge?.familyStudy ?? []
            ].sort({
                "FuturesRadarCard.useMemo[leaders]": (a, b)=>Math.abs(b.edge ?? 0) - Math.abs(a.edge ?? 0)
            }["FuturesRadarCard.useMemo[leaders]"]).slice(0, 6)
    }["FuturesRadarCard.useMemo[leaders]"], [
        edge
    ]);
    const worstCells = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FuturesRadarCard.useMemo[worstCells]": ()=>[
                ...edge?.attribution?.cells ?? []
            ].sort({
                "FuturesRadarCard.useMemo[worstCells]": (a, b)=>(a.avgPnl ?? 0) - (b.avgPnl ?? 0)
            }["FuturesRadarCard.useMemo[worstCells]"]).slice(0, 5)
    }["FuturesRadarCard.useMemo[worstCells]"], [
        edge
    ]);
    const liveQ = anchor?.quadrant1h ?? null;
    const tapeUp = data?.services?.tape?.connected ?? false;
    const liqUp = data?.services?.liq?.online ?? false;
    const counts = data?.counts;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radar$3e$__["Radar"], {
                                className: "h-4 w-4 text-violet-neon",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 369,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-terminal text-[13px] font-bold uppercase tracking-[0.14em] text-foreground",
                                                children: "FUTURES TAXONOMY"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 372,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 373,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 371,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "font-terminal text-[9px] tracking-[0.08em] text-ink-3",
                                        children: "5-FAMILY STORE → LEARN → BEST FILTER"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 375,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 370,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 368,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            err && data && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-terminal text-[9px] text-amber-neon",
                                children: "last poll failed — retrying"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 379,
                                columnNumber: 27
                            }, this),
                            edge?.maturity && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                tone: edge.maturity.progressPct >= 100 ? "neon" : "amber",
                                // Task 34-4 — honest breakdown: 672 of these rows came from the
                                // one-shot 14-day hourly BACKFILL; the LIVE sampler adds ~2 rows
                                // per 5min tick. The 720 bar is the settled-row maturity gate
                                // for bestFilter claims (n≥20 + sign agreement still required).
                                title: `settled forward-return rows ${edge.maturity.settled}/${edge.maturity.target} — backfill ${data?.counts?.backfill ?? "—"} + live ${data?.counts?.live ?? "—"} · spot-mirror keeps rows flowing during fapi bans`,
                                children: [
                                    "STORE ",
                                    edge.maturity.settled,
                                    "/",
                                    edge.maturity.target
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 381,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 378,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 367,
                columnNumber: 7
            }, this),
            !data ? err ? /* fetch error — compact amber line + retry (honest, no fake data) */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-2 rounded-lg border border-[rgba(255,179,71,0.35)] bg-amber-neon/[0.06] px-2.5 py-2.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "min-w-0 truncate font-terminal text-[10px] text-amber-neon",
                        children: [
                            "FUTURES FEED ERROR — ",
                            err
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 399,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>void pull(),
                        className: "shrink-0 rounded border border-amber-neon/50 px-2 py-0.5 font-terminal text-[9px] font-bold uppercase tracking-wider text-amber-neon transition hover:bg-amber-neon/10",
                        children: "Retry"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 400,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 398,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Skeleton, {}, void 0, false, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 409,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1 flex items-center gap-1.5 px-0.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FamilyBadge, {
                                        letter: "D"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 416,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "min-w-0 font-terminal text-[9px] font-bold uppercase tracking-[0.14em] text-ink-2",
                                        children: "OI × Price quadrant — fwd 1h stats"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 417,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-auto shrink-0 font-terminal text-[9px] tabular-nums text-ink-3",
                                        children: anchor?.symbol ?? "—"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 420,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 415,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-[14px_1fr_1fr] gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 424,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AxisHead, {
                                        children: "OI ↑"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 425,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AxisHead, {
                                        children: "OI ↓"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 426,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AxisRow, {
                                        children: "PRICE ↑"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 428,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QuadrantCell, {
                                        id: QUADRANT_ORDER[0],
                                        meta: data.quadrantMeta?.[QUADRANT_ORDER[0]],
                                        study: studyByQ.get(QUADRANT_ORDER[0]),
                                        live: liveQ === QUADRANT_ORDER[0],
                                        priceDelta1h: anchor?.priceDelta1h,
                                        oiDelta1h: anchor?.oiDelta1h
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 429,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QuadrantCell, {
                                        id: QUADRANT_ORDER[1],
                                        meta: data.quadrantMeta?.[QUADRANT_ORDER[1]],
                                        study: studyByQ.get(QUADRANT_ORDER[1]),
                                        live: liveQ === QUADRANT_ORDER[1],
                                        priceDelta1h: anchor?.priceDelta1h,
                                        oiDelta1h: anchor?.oiDelta1h
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 437,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AxisRow, {
                                        children: "PRICE ↓"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 446,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QuadrantCell, {
                                        id: QUADRANT_ORDER[2],
                                        meta: data.quadrantMeta?.[QUADRANT_ORDER[2]],
                                        study: studyByQ.get(QUADRANT_ORDER[2]),
                                        live: liveQ === QUADRANT_ORDER[2],
                                        priceDelta1h: anchor?.priceDelta1h,
                                        oiDelta1h: anchor?.oiDelta1h
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 447,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QuadrantCell, {
                                        id: QUADRANT_ORDER[3],
                                        meta: data.quadrantMeta?.[QUADRANT_ORDER[3]],
                                        study: studyByQ.get(QUADRANT_ORDER[3]),
                                        live: liveQ === QUADRANT_ORDER[3],
                                        priceDelta1h: anchor?.priceDelta1h,
                                        oiDelta1h: anchor?.oiDelta1h
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 455,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 422,
                                columnNumber: 13
                            }, this),
                            !liveQ && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1.5 px-1 font-terminal text-[9px] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-amber-neon",
                                        children: "WARMING"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 466,
                                        columnNumber: 17
                                    }, this),
                                    " — sampler self-heals after Binance IP-ban backoff"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 465,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 414,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FamilyPanel, {
                                letter: "A",
                                title: "Positioning",
                                rows: [
                                    {
                                        k: "FUND 8H",
                                        v: pct(anchor?.funding8h, 4),
                                        cls: signCls(anchor?.funding8h)
                                    },
                                    {
                                        k: "CROWD L/S",
                                        v: num(anchor?.crowdLS, 2)
                                    },
                                    {
                                        k: "TOP L/S",
                                        v: num(anchor?.topLS, 2)
                                    }
                                ],
                                dim: false
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 473,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FamilyPanel, {
                                letter: "B",
                                title: "Aggressor CVD",
                                rows: [
                                    {
                                        k: "CVD 15M",
                                        v: pct(anchor?.cvd15mPct, 1),
                                        cls: signCls(anchor?.cvd15mPct)
                                    },
                                    {
                                        k: "CVD 1H",
                                        v: pct(anchor?.cvd1hPct, 1),
                                        cls: signCls(anchor?.cvd1hPct)
                                    }
                                ],
                                dim: anchor?.cvd15mPct == null && anchor?.cvd1hPct == null,
                                dimTip: "aggressor trade tape unavailable — honest gap, no synthetic values"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 483,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FamilyPanel, {
                                letter: "C",
                                title: "Forced flow",
                                rows: [
                                    {
                                        k: "LIQ L · 10M",
                                        v: usdCompact(anchor?.liqLong10mUsd)
                                    },
                                    {
                                        k: "LIQ S · 10M",
                                        v: usdCompact(anchor?.liqShort10mUsd)
                                    },
                                    {
                                        k: "LIQ 1H",
                                        v: usdCompact(anchor?.liqUsd1h)
                                    }
                                ],
                                dim: anchor?.liqLong10mUsd == null && anchor?.liqShort10mUsd == null && anchor?.liqUsd1h == null,
                                dimTip: "liquidation feed unavailable — honest gap, no synthetic values"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 493,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FamilyPanel, {
                                letter: "E",
                                title: "Cross-plane",
                                rows: [
                                    {
                                        k: "FUND PRED",
                                        v: pct(anchor?.funding8h, 4),
                                        cls: signCls(anchor?.funding8h)
                                    },
                                    {
                                        k: "FUND STLD",
                                        v: pct(anchor?.fundingSettled, 4),
                                        cls: signCls(anchor?.fundingSettled)
                                    },
                                    {
                                        k: "SPREAD 8H",
                                        v: bps(anchor?.crossSpreadBps8h),
                                        cls: signCls(anchor?.crossSpreadBps8h)
                                    },
                                    ...typeof anchor?.oiUsdM === "number" && Number.isFinite(anchor.oiUsdM) ? [
                                        {
                                            k: "OI USD",
                                            v: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtUsd"])(anchor.oiUsdM * 1_000_000)
                                        }
                                    ] : []
                                ],
                                dim: false
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 504,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 472,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-lg border border-white/8 bg-white/[0.02] p-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1 flex flex-wrap items-center justify-between gap-1 px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Edge leaderboard — fwd 1h vs baseline"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 522,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "normal-case tracking-normal tabular-nums",
                                        children: [
                                            "baseline ",
                                            pct(edge?.baselineMeanFwd1h)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 523,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 521,
                                columnNumber: 13
                            }, this),
                            leaders.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-1 py-3 text-center font-terminal text-[10px] text-ink-3",
                                children: "no settled evidence yet — filters collecting"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 526,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-h-56 space-y-0.5 overflow-y-auto pr-1",
                                children: leaders.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 px-1 py-1 font-terminal text-[10px] tabular-nums transition hover:bg-white/[0.03]",
                                        title: `${r.filter} — ${r.rule} · ${r.thresholdNote} · family ${r.family}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-[110px] shrink-0 truncate font-bold text-ink",
                                                children: r.filter
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 535,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "min-w-0 flex-1 truncate text-ink-3",
                                                children: r.rule
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 536,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-8 shrink-0 text-right text-ink-2",
                                                children: r.n
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 537,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-14 shrink-0 text-right font-bold", signCls(r.edge)),
                                                children: pct(r.edge)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 538,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-10 shrink-0 text-right text-ink-2",
                                                children: pctPlain(r.winPct)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 539,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-[64px] shrink-0 rounded border px-1 text-center text-[8px] font-bold leading-4", confCls(r.confidence)),
                                                children: r.confidence
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 540,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, r.filter, true, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 530,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 528,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 520,
                        columnNumber: 11
                    }, this),
                    edge?.bestFilter ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-lg border border-violet-neon/30 bg-violet-neon/[0.05] px-2.5 py-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap items-center gap-x-2 gap-y-1 font-terminal text-[10px] tabular-nums",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                    tone: "violet",
                                    children: [
                                        "Best filter [",
                                        edge.bestFilter.source,
                                        "]"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                    lineNumber: 553,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-bold text-ink",
                                    children: edge.bestFilter.filter
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                    lineNumber: 554,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "min-w-0 flex-1 truncate text-ink-3",
                                    title: edge.bestFilter.rule,
                                    children: edge.bestFilter.rule
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                    lineNumber: 555,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-bold", signCls(edge.bestFilter.edge)),
                                    children: pct(edge.bestFilter.edge)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                    lineNumber: 558,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-ink-2",
                                    children: [
                                        "n ",
                                        edge.bestFilter.n
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                    lineNumber: 559,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded border px-1 text-[8px] font-bold leading-4", confCls(edge.bestFilter.confidence)),
                                    children: edge.bestFilter.confidence
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                    lineNumber: 560,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                            lineNumber: 552,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 551,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-lg border border-dashed border-white/10 px-2.5 py-2 font-terminal text-[10px] text-ink-3",
                        children: [
                            "BEST FILTER: COLLECTING — ",
                            edge?.maturity?.settled ?? 0,
                            "/",
                            edge?.maturity?.target ?? 0,
                            " settled forward returns"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 566,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        className: "rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                className: "flex cursor-pointer list-none items-center gap-2 px-1 font-terminal text-[9px] uppercase tracking-[0.14em] text-ink-3 [&::-webkit-details-marker]:hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Signal attribution — worst cohorts first"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 574,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-auto normal-case tracking-normal tabular-nums",
                                        children: [
                                            edge?.attribution?.joined ?? 0,
                                            " settled signals joined (±10m fence)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 575,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 573,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-1 space-y-0.5 border-t border-white/5 pt-1",
                                children: worstCells.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "px-1 py-2 font-terminal text-[10px] text-ink-3",
                                    children: "no settled signals joined yet"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                    lineNumber: 581,
                                    columnNumber: 17
                                }, this) : worstCells.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 px-1 py-1 font-terminal text-[10px] tabular-nums transition hover:bg-white/[0.03]",
                                        title: `${c.direction} issued in ${c.quadrant.replace(/_/g, " ")} context — avg ${pct(c.avgPnl)} levered net · median ${pct(c.medianPnl)}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-12 shrink-0 font-bold", c.direction === "LONG" ? "text-neon" : "text-magenta-neon"),
                                                children: c.direction
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 589,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "min-w-0 flex-1 truncate text-ink-2",
                                                children: c.quadrant.replace(/_/g, " ")
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 592,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-8 shrink-0 text-right text-ink-2",
                                                children: c.n
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 593,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-16 shrink-0 text-right font-bold", signCls(c.avgPnl)),
                                                children: pct(c.avgPnl)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 594,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-12 shrink-0 text-right text-ink-2",
                                                children: pctPlain(c.winPct)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                                lineNumber: 595,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, `${c.direction}-${c.quadrant}`, true, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 584,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 579,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 572,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap items-center gap-x-2 gap-y-0.5 border-t border-white/5 pt-2 font-terminal text-[9px] tabular-nums text-ink-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    counts?.total ?? 0,
                                    " rows (backfill ",
                                    counts?.backfill ?? 0,
                                    "/",
                                    counts?.live ?? 0,
                                    " live · settled1h ",
                                    counts?.settled1h ?? 0,
                                    " · 24h",
                                    " ",
                                    counts?.last24h ?? 0,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 604,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "aria-hidden": true,
                                children: "·"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 608,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "TAPE ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: tapeUp ? "text-neon" : "text-danger-neon",
                                        children: tapeUp ? "UP" : "DOWN"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 610,
                                        columnNumber: 20
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 609,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "LIQ ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: liqUp ? "text-neon" : "text-danger-neon",
                                        children: liqUp ? "UP" : "DOWN"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                        lineNumber: 613,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 612,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "backfill ",
                                    shortIso(data.backfill?.at)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                                lineNumber: 615,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                        lineNumber: 603,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
                lineNumber: 412,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/FuturesRadarCard.tsx",
        lineNumber: 365,
        columnNumber: 5
    }, this);
}
_s(FuturesRadarCard, "RMT6ZvK48RiBC24/rVMzCJ1itGo=");
_c7 = FuturesRadarCard;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7;
__turbopack_context__.k.register(_c, "FamilyBadge");
__turbopack_context__.k.register(_c1, "ShimmerBar");
__turbopack_context__.k.register(_c2, "Skeleton");
__turbopack_context__.k.register(_c3, "AxisHead");
__turbopack_context__.k.register(_c4, "AxisRow");
__turbopack_context__.k.register(_c5, "QuadrantCell");
__turbopack_context__.k.register(_c6, "FamilyPanel");
__turbopack_context__.k.register(_c7, "FuturesRadarCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/RawCalCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RawCalCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/activity.js [app-client] (ecmascript) <export default as Activity>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$compass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Compass$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/compass.js [app-client] (ecmascript) <export default as Compass>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flask$2d$conical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FlaskConical$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/flask-conical.js [app-client] (ecmascript) <export default as FlaskConical>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gauge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gauge$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/gauge.js [app-client] (ecmascript) <export default as Gauge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$microscope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Microscope$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/microscope.js [app-client] (ecmascript) <export default as Microscope>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$power$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Power$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/power.js [app-client] (ecmascript) <export default as Power>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Scale$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/scale.js [app-client] (ecmascript) <export default as Scale>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield-check.js [app-client] (ecmascript) <export default as ShieldCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trending-up.js [app-client] (ecmascript) <export default as TrendingUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TriangleAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-client] (ecmascript) <export default as TriangleAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ago(iso) {
    if (!iso) return "—";
    const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
    if (s < 60) return `${s}s`;
    if (s < 3600) return `${Math.round(s / 60)}m`;
    if (s < 86400) return `${Math.round(s / 3600)}h`;
    return `${Math.round(s / 86400)}d`;
}
function etaClock(iso) {
    if (!iso) return "—";
    try {
        return new Date(iso).toLocaleTimeString("en-GB", {
            hour: "2-digit",
            minute: "2-digit"
        });
    } catch  {
        return "—";
    }
}
/** Inline SVG book-growth sparkline (settled EPOCH-2 over the journal window). */ function GrowthSpark({ series }) {
    if (series.length < 2) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex h-9 items-center justify-center font-terminal text-[9px] text-ink-3",
            children: "BOOK CURVE WARMING — journal fills every 10min"
        }, void 0, false, {
            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
            lineNumber: 146,
            columnNumber: 7
        }, this);
    }
    const W = 100;
    const H = 26;
    // NaN guard (v9.4.2): journal rows can carry null/gap equity values — any
    // non-finite point would turn vMin/vMax into NaN and crash React children.
    const vs = series.map((p)=>p.v).filter((v)=>Number.isFinite(v));
    if (vs.length < 2) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex h-9 items-center justify-center font-terminal text-[9px] text-ink-3",
            children: "BOOK CURVE WARMING — journal fills every 10min"
        }, void 0, false, {
            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
            lineNumber: 158,
            columnNumber: 7
        }, this);
    }
    const vMin = Math.min(...vs);
    const vMax = Math.max(...vs);
    const span = Math.max(1, vMax - vMin);
    const pts = series.map((p, i)=>({
            x: i / (series.length - 1) * W,
            v: p.v
        })).filter((p)=>Number.isFinite(p.v)).map((p)=>{
        const y = H - (p.v - vMin) / span * (H - 4) - 2;
        return `${p.x.toFixed(1)},${y.toFixed(1)}`;
    });
    const area = `M0,${H} L${pts.join(" L")} L${W},${H} Z`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                viewBox: `0 0 ${W} ${H}`,
                preserveAspectRatio: "none",
                className: "h-9 w-full",
                "aria-hidden": true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: area,
                        fill: "url(#rawcalSparkFill)",
                        opacity: 0.35
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 177,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                        points: pts.join(" "),
                        fill: "none",
                        stroke: "var(--amber-neon)",
                        strokeWidth: 1.4,
                        vectorEffect: "non-scaling-stroke",
                        strokeLinejoin: "round"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 178,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                            id: "rawcalSparkFill",
                            x1: "0",
                            y1: "0",
                            x2: "0",
                            y2: "1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                    offset: "0%",
                                    stopColor: "var(--amber-neon)",
                                    stopOpacity: 0.8
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                    lineNumber: 181,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                    offset: "100%",
                                    stopColor: "var(--amber-neon)",
                                    stopOpacity: 0
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                    lineNumber: 182,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                            lineNumber: 180,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 179,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                lineNumber: 176,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "absolute left-0 top-0 font-terminal text-[8px] text-ink-3",
                children: vMin.toFixed(2)
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                lineNumber: 186,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "absolute right-0 top-0 font-terminal text-[8px] text-amber-neon",
                children: vMax.toFixed(2)
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                lineNumber: 187,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
        lineNumber: 175,
        columnNumber: 5
    }, this);
}
_c = GrowthSpark;
const GRADE_TONE = {
    A: "border-mint-neon/50 bg-mint-neon/10 text-mint-neon",
    B: "border-cyan-neon/50 bg-cyan-neon/10 text-cyan-neon",
    C: "border-amber-neon/50 bg-amber-neon/10 text-amber-neon",
    D: "border-danger-neon/50 bg-danger-neon/10 text-danger-neon",
    OFF: "border-white/10 bg-white/5 text-ink-3"
};
const GATE_TONE = {
    GREEN: "border-mint-neon/50 bg-mint-neon/10 text-mint-neon",
    AMBER: "border-amber-neon/50 bg-amber-neon/10 text-amber-neon",
    RED: "border-danger-neon/50 bg-danger-neon/10 text-danger-neon",
    WARMING: "border-white/10 bg-white/5 text-ink-3"
};
const CLS_TONE = {
    HEALTHY: "border-mint-neon/40 bg-mint-neon/10 text-mint-neon",
    REVIEW: "border-amber-neon/40 bg-amber-neon/10 text-amber-neon",
    CENSORED: "border-danger-neon/40 bg-danger-neon/10 text-danger-neon",
    PENDING: "border-white/10 bg-white/5 text-ink-3"
};
function RawCalCard() {
    _s();
    const [st, setSt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const pull = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RawCalCard.useCallback[pull]": async ()=>{
            try {
                const res = await fetch("/api/rawcal", {
                    cache: "no-store"
                });
                if (res.ok) setSt(await res.json());
            } catch  {
            /* next tick retries */ }
        }
    }["RawCalCard.useCallback[pull]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RawCalCard.useEffect": ()=>{
            void pull();
            const id = setInterval(pull, 10_000);
            return ({
                "RawCalCard.useEffect": ()=>clearInterval(id)
            })["RawCalCard.useEffect"];
        }
    }["RawCalCard.useEffect"], [
        pull
    ]);
    const act = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RawCalCard.useCallback[act]": async (action)=>{
            setBusy(true);
            try {
                const res = await fetch("/api/rawcal", {
                    method: "POST",
                    headers: {
                        "content-type": "application/json"
                    },
                    body: JSON.stringify({
                        action,
                        reason: action === "disarm" ? "operator command — return to filtered operation" : undefined
                    })
                });
                const json = await res.json();
                if (res.ok && json.ok) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(action === "arm" ? "RAW-CAL capture mode ARMED" : "RAW-CAL mode disarmed — filtered operation restored");
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(json.error ?? "rawcal action failed");
                }
            } catch  {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("rawcal action failed");
            } finally{
                setBusy(false);
                void pull();
            }
        }
    }["RawCalCard.useCallback[act]"], [
        pull
    ]);
    const pct = st ? Math.min(100, st.settledN / st.target * 100) : 0;
    const pace = st?.pace ?? null;
    const stallIssue = !!pace?.stalls.issueStallMin;
    const stallSettle = !!pace?.stalls.settleStallMin;
    const anyStall = stallIssue || stallSettle;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flask$2d$conical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FlaskConical$3e$__["FlaskConical"], {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("h-4 w-4", st?.armed ? "text-amber-neon" : "text-ink-3"),
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 268,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "RAW-CAL · Capture Mode — unfiltered calibration issuance"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 269,
                                columnNumber: 11
                            }, this),
                            st?.armed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 270,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 267,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                        tone: st?.armed ? "amber" : "muted",
                        glow: !!st?.armed,
                        children: st?.armed ? "ARMED — UNFILTERED" : "OFF — FILTERED"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 272,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                lineNumber: 266,
                columnNumber: 7
            }, this),
            !st ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex min-h-[120px] items-center justify-center font-terminal text-[10px] text-ink-3",
                children: "LOADING CAPTURE STATE…"
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                lineNumber: 277,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-w-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[11px] leading-relaxed text-ink-2",
                        children: st.armed ? "Unfiltered issuance is LIVE — every scan's best flow is recorded as a RAW-CAL signal (data capture + tracking + journaling to ENGINE MEMORY). Auto-cancels at the calibration bar." : "Filtered operation under central-intelligence command. Arm to issue unfiltered RAW-CAL records and accelerate the AI CALIBRATION bar."
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 281,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 font-terminal text-[10px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Scale$3e$__["Scale"], {
                                        className: "size-3 text-amber-neon",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 290,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-bold text-ink-2",
                                        children: "AI CALIBRATION BAR"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 291,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-auto tabular-nums text-ink",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                className: "text-amber-neon",
                                                children: st.settledN
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 293,
                                                columnNumber: 17
                                            }, this),
                                            "/",
                                            st.target,
                                            " settled · ",
                                            st.needed,
                                            " to go"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 292,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 289,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/8",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-full rounded-full bg-gradient-to-r from-amber-neon/70 to-amber-neon",
                                    style: {
                                        width: `${pct}%`
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                    lineNumber: 297,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 296,
                                columnNumber: 13
                            }, this),
                            pace && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 font-terminal text-[9px] text-ink-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            "PIPELINE+BOOK ≈ ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                className: "text-ink",
                                                children: pace.pipelineProjection
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 302,
                                                columnNumber: 35
                                            }, this),
                                            " (open EPOCH-2 will still settle)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 301,
                                        columnNumber: 17
                                    }, this),
                                    pace.meanSettleMin !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            "MEAN SETTLE ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                className: "text-ink",
                                                children: [
                                                    pace.meanSettleMin,
                                                    "m"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 306,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 305,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 300,
                                columnNumber: 15
                            }, this),
                            st.armsCompletion && st.armsCompletion.arms.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 rounded-lg border border-[rgba(178,107,255,0.22)] bg-[rgba(178,107,255,0.04)] px-2.5 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flask$2d$conical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FlaskConical$3e$__["FlaskConical"], {
                                                className: "size-3 text-violet-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-terminal text-[9px] font-bold uppercase tracking-[0.12em] text-ink-2",
                                                children: "BAR UNTIL SHADOW-VETO ARMS COMPLETE"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 319,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                tone: st.armsCompletion.allComplete ? "neon" : "violet",
                                                className: "ml-auto",
                                                children: st.armsCompletion.allComplete ? "ARMS COMPLETE" : `OPEN ${st.armsCompletion.pendingDeficit}`
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 322,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 317,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-1.5 grid grid-cols-2 gap-1.5 sm:grid-cols-4",
                                        children: st.armsCompletion.arms.map((a)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                title: `${a.id}${a.waived ? " — waived in shadow mode (fills only when veto-mode blocks deploys)" : a.complete ? " — complete" : " — feeding"}`,
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded border px-1.5 py-1", a.complete ? "border-[rgba(0,255,157,0.35)]" : a.waived ? "border-white/10 bg-white/[0.02]" : "border-[rgba(255,179,71,0.3)] bg-[rgba(255,179,71,0.04)]"),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-terminal text-[8px] font-bold uppercase tracking-[0.08em]", a.waived ? "text-ink-3" : a.complete ? "text-neon" : "text-amber-neon"),
                                                        children: a.id.replace("real-", "R·").replace("paper-", "P·")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 339,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-terminal text-xs font-bold tabular-nums", a.waived ? "text-ink-3" : "text-ink"),
                                                        children: [
                                                            a.n,
                                                            "/",
                                                            a.target,
                                                            a.waived && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "ml-1 text-[8px] font-normal",
                                                                children: "WV"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                                lineNumber: 344,
                                                                columnNumber: 38
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 342,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, a.id, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 331,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 329,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 316,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 288,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "label-tech truncate text-ink-3",
                                        children: "ISSUED"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 356,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-0.5 font-terminal text-base font-bold tabular-nums text-amber-neon",
                                        children: st.issuedTotal
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 357,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "font-terminal text-[9px] text-ink-3",
                                        children: [
                                            st.settledRaw,
                                            " settled · ",
                                            st.winsRaw,
                                            "✓",
                                            st.rawWinRatePct !== null ? ` · ${st.rawWinRatePct}%` : ""
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 358,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 355,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "label-tech truncate text-ink-3",
                                        children: "OPEN"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 361,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-0.5 font-terminal text-base font-bold tabular-nums text-ink",
                                        children: [
                                            st.openRaw,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-ink-3",
                                                children: [
                                                    "/",
                                                    st.maxOpen
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 362,
                                                columnNumber: 107
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 362,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "font-terminal text-[9px] text-ink-3",
                                        children: "cap rail"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 363,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 360,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "label-tech truncate text-ink-3",
                                        children: "LAST"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 366,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-0.5 font-terminal text-base font-bold tabular-nums text-ink",
                                        children: st.lastIssueSerial ? `NX-${String(st.lastIssueSerial).padStart(4, "0")}` : "—"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 367,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "font-terminal text-[9px] text-ink-3",
                                        children: [
                                            ago(st.lastIssueAt),
                                            " ago"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 368,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 365,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "label-tech truncate text-ink-3",
                                        children: "SPACING"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 371,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-0.5 font-terminal text-base font-bold tabular-nums text-ink",
                                        children: [
                                            "≥",
                                            st.spacingMin,
                                            "m"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 372,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "font-terminal text-[9px] text-ink-3",
                                        children: "anti-flood rail"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 373,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 370,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 354,
                        columnNumber: 11
                    }, this),
                    st.regimeSplit && st.regimeSplit.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 rounded-lg border border-[rgba(0,229,255,0.16)] bg-white/[0.02] p-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$compass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Compass$3e$__["Compass"], {
                                        className: "size-3 text-cyan-neon",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 384,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-terminal text-[9px] font-bold uppercase tracking-[0.12em] text-ink-2",
                                        children: "CAPTURE BOOK × REGIME — TRUST IS PER-REGIME"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 385,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                        tone: "muted",
                                        className: "ml-auto",
                                        children: "LAYER-0 VETO LIVE AT ISSUE"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 388,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 383,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-1.5 grid grid-cols-2 gap-1.5 sm:grid-cols-5",
                                children: st.regimeSplit.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        title: `${r.regime} — ${r.n} settled capture rows · WR ${r.winRatePct}% · net ${r.netUsd >= 0 ? "+" : ""}$${r.netUsd.toFixed(2)} on the $2-rescaled paper doctrine`,
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded border px-1.5 py-1", r.netUsd >= 0 ? "border-[rgba(0,255,157,0.28)]" : "border-[rgba(255,71,87,0.28)]"),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "truncate font-terminal text-[8px] font-bold uppercase tracking-[0.08em] text-ink-2",
                                                children: r.label
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 402,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-xs font-bold tabular-nums text-ink",
                                                children: [
                                                    r.n,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "ml-1 text-[8px] font-normal text-ink-3",
                                                        children: [
                                                            r.winRatePct,
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 405,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 403,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-terminal text-[9px] font-bold tabular-nums", r.netUsd >= 0 ? "text-neon" : "text-danger-neon"),
                                                children: [
                                                    r.netUsd >= 0 ? "+" : "",
                                                    "$",
                                                    r.netUsd.toFixed(2)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 407,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, r.regime, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 394,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 392,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1.5 font-terminal text-[9px] leading-relaxed text-ink-3",
                                children: "SETTLED RAW-CAL ROWS SPLIT BY THEIR BIRTH REGIME (N · WR · NET $) — A CHOP-HEAVY BOOK MUST NEVER BE READ AS A TREND VERDICT"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 413,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 382,
                        columnNumber: 13
                    }, this),
                    pace && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 rounded-lg border border-white/8 bg-white/[0.02] p-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap items-center justify-between gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 font-terminal text-[10px] font-bold text-ink-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gauge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gauge$3e$__["Gauge"], {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("size-3", anyStall ? "text-danger-neon" : "text-mint-neon"),
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 424,
                                                columnNumber: 19
                                            }, this),
                                            "PACE MONITOR — issuance rhythm · book growth"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 423,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded border px-1.5 py-0.5 font-terminal text-[9px] font-bold tracking-wider", GRADE_TONE[pace.cadenceGrade] ?? GRADE_TONE.OFF),
                                        title: `cadence grade ${pace.cadenceGrade} — A ≥3/h, B ≥1.5/h, C ≥0.5/h, D stalled`,
                                        children: [
                                            "CADENCE ",
                                            pace.cadenceGrade
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 427,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 422,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-md border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "label-tech truncate text-ink-3",
                                                children: "ISSUE/H"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 438,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-0.5 font-terminal text-sm font-bold tabular-nums text-ink",
                                                children: pace.issueRate3hPerH.toFixed(1)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 439,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-[9px] text-ink-3",
                                                children: [
                                                    "3h · arm ",
                                                    pace.issueRateSinceArmPerH.toFixed(1),
                                                    "/h"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 440,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 437,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-md border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "label-tech truncate text-ink-3",
                                                children: "SETTLE/H"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 443,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-0.5 font-terminal text-sm font-bold tabular-nums text-mint-neon",
                                                children: pace.settleRate3hPerH.toFixed(1)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 444,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-[9px] text-ink-3",
                                                children: [
                                                    "3h · 6h ",
                                                    pace.settleRate6hPerH.toFixed(1),
                                                    "/h"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 445,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 442,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-md border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "label-tech truncate text-ink-3",
                                                children: "OBS. SPACING"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 448,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-0.5 font-terminal text-sm font-bold tabular-nums text-ink",
                                                children: pace.observedSpacingMin.mean !== null ? `${pace.observedSpacingMin.mean}m` : "—"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 449,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-[9px] text-ink-3",
                                                children: [
                                                    pace.observedSpacingMin.samples,
                                                    " gaps ",
                                                    pace.observedSpacingMin.min !== null ? `· ${pace.observedSpacingMin.min}–${pace.observedSpacingMin.max}m` : ""
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 452,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 447,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-md border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "label-tech truncate text-ink-3",
                                                children: "ETA TO 100"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 455,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-0.5 font-terminal text-sm font-bold tabular-nums text-amber-neon",
                                                children: pace.etaHours !== null ? `${pace.etaHours >= 100 ? "99+" : pace.etaHours.toFixed(1)}h` : "N/A"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 456,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-[9px] text-ink-3",
                                                children: pace.etaSteadyHours != null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    title: "steady-state projection — raw cadence ∩ settle-throughput cap (open slots ÷ mean settle time)",
                                                    children: [
                                                        "SS ",
                                                        pace.etaSteadyHours >= 100 ? "99+" : pace.etaSteadyHours.toFixed(1),
                                                        "h @ ",
                                                        pace.steadyRatePerH ?? "—",
                                                        "/h"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                    lineNumber: 459,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: pace.etaAt ? `≈ ${etaClock(pace.etaAt)} local` : "no settle signal yet"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                    lineNumber: 463,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 457,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 454,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 436,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 rounded-md border border-white/8 bg-white/[0.02] px-2 pb-1.5 pt-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-1.5 font-terminal text-[9px] text-ink-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__["TrendingUp"], {
                                                className: "size-3 text-amber-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 472,
                                                columnNumber: 19
                                            }, this),
                                            "EPOCH-2 BOOK GROWTH ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "ml-auto",
                                                children: [
                                                    pace.journalRows,
                                                    " snapshots · 10min cadence"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 473,
                                                columnNumber: 39
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 471,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GrowthSpark, {
                                        series: pace.sparkline
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 475,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 470,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 font-terminal text-[9px]",
                                children: anyStall ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "rounded border border-danger-neon/40 bg-danger-neon/10 px-1.5 py-0.5 font-bold text-danger-neon",
                                            children: [
                                                stallIssue ? `ISSUE STALL ${pace.stalls.issueStallMin}m` : "",
                                                stallIssue && stallSettle ? " · " : "",
                                                stallSettle ? `SETTLE STALL ${pace.stalls.settleStallMin}m` : ""
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                            lineNumber: 482,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-ink-3",
                                            children: [
                                                "last block: ",
                                                pace.stalls.lastBlockNote ?? "—"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                            lineNumber: 487,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center gap-1 rounded border border-mint-neon/30 bg-mint-neon/5 px-1.5 py-0.5 font-bold text-mint-neon", st.armed && "animate-pulse"),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__["Activity"], {
                                            className: "size-2.5",
                                            "aria-hidden": true
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                            lineNumber: 491,
                                            columnNumber: 21
                                        }, this),
                                        st.armed ? "CADENCE NOMINAL — rails holding" : "MODE OFF — filtered command"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                    lineNumber: 490,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 479,
                                columnNumber: 15
                            }, this),
                            st.milestones && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 flex flex-wrap items-center gap-1.5 border-t border-white/5 pt-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "label-tech text-ink-3",
                                        children: "MILESTONES"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 500,
                                        columnNumber: 19
                                    }, this),
                                    st.milestones.steps.map((m)=>{
                                        const next = !m.fired && m.step === st.milestones.steps.find((x)=>!x.fired)?.step;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            title: m.fired ? `fired ${ago(m.at)} ago` : `pending — book at ${st.milestones?.settledE2 ?? "—"}`,
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded border px-1.5 py-0.5 font-terminal text-[9px] font-bold tabular-nums", m.fired ? "border-mint-neon/40 bg-mint-neon/10 text-mint-neon" : next ? "border-amber-neon/50 bg-amber-neon/10 text-amber-neon animate-pulse" : "border-white/10 bg-white/[0.03] text-ink-3"),
                                            children: [
                                                m.step,
                                                m.fired ? "✓" : ""
                                            ]
                                        }, m.step, true, {
                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                            lineNumber: 504,
                                            columnNumber: 23
                                        }, this);
                                    })
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 499,
                                columnNumber: 17
                            }, this),
                            st.blocks && st.blocks.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 max-h-16 overflow-y-auto border-t border-white/5 pt-1.5",
                                title: "recent issuance-block reasons",
                                children: st.blocks.slice(-4).reverse().map((b, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-baseline gap-2 font-terminal text-[8.5px] leading-relaxed text-ink-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "shrink-0 tabular-nums text-ink-3/70",
                                                children: [
                                                    ago(new Date(b.t).toISOString()),
                                                    " ago"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 529,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "truncate",
                                                children: b.note
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 530,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, `${b.t}-${i}`, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 528,
                                        columnNumber: 21
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 526,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 421,
                        columnNumber: 13
                    }, this),
                    st.quality && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 rounded-lg border border-white/8 bg-white/[0.02] p-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap items-center justify-between gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 font-terminal text-[10px] font-bold text-ink-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$microscope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Microscope$3e$__["Microscope"], {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("size-3", st.quality.gate.verdict === "RED" ? "text-danger-neon" : st.quality.gate.verdict === "WARMING" ? "text-ink-3" : "text-mint-neon"),
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 543,
                                                columnNumber: 19
                                            }, this),
                                            "SAMPLE QUALITY — R6 DATA HEALTH"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 542,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded border px-1.5 py-0.5 font-terminal text-[9px] font-bold tracking-wider", GATE_TONE[st.quality.gate.verdict] ?? GATE_TONE.WARMING),
                                        title: `R6 data-health gate — floor ${st.quality.gate.healthFloor}% healthy cohort`,
                                        children: [
                                            "GATE ",
                                            st.quality.gate.verdict
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 546,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 541,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 font-terminal text-[9px] leading-relaxed text-ink-3",
                                children: [
                                    "cohort ",
                                    st.quality.settledRaw,
                                    " settled / ",
                                    st.quality.issuedTotal,
                                    " issued (",
                                    st.quality.openRaw,
                                    " in flight) · ",
                                    st.quality.healthy,
                                    "✓ healthy · ",
                                    st.quality.review,
                                    "? review · ",
                                    st.quality.censored,
                                    "✗ censored"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 553,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 grid grid-cols-2 gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-md border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "label-tech truncate text-ink-3",
                                                children: "HEALTHY"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 560,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mt-0.5 font-terminal text-sm font-bold tabular-nums", st.quality.healthyPct === null ? "text-ink-3" : st.quality.healthyPct >= st.quality.gate.healthFloor ? "text-mint-neon" : st.quality.healthyPct >= 70 ? "text-amber-neon" : "text-danger-neon"),
                                                children: st.quality.healthyPct !== null ? `${st.quality.healthyPct}%` : "—"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 561,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-[9px] text-ink-3",
                                                children: [
                                                    "floor ",
                                                    st.quality.gate.healthFloor,
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 564,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 559,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-md border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "label-tech truncate text-ink-3",
                                                children: "INFORMATIVE"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 567,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-0.5 font-terminal text-sm font-bold tabular-nums text-ink",
                                                children: st.quality.informativePct !== null ? `${st.quality.informativePct}%` : "—"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 568,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-[9px] text-ink-3",
                                                children: [
                                                    "TP/SL proved · ",
                                                    st.quality.expiredNoTouch,
                                                    " censored"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 569,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 566,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-md border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "label-tech truncate text-ink-3",
                                                children: "SNAPSHOTS"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 572,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mt-0.5 font-terminal text-sm font-bold tabular-nums", st.quality.snapshotPct !== null && st.quality.snapshotPct < 80 ? "text-amber-neon" : "text-ink"),
                                                children: st.quality.snapshotPct !== null ? `${st.quality.snapshotPct}%` : "—"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 573,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-[9px] text-ink-3",
                                                children: "factors+flow+MTF kept"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 574,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 571,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-md border border-white/8 bg-white/[0.02] px-2 py-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "label-tech truncate text-ink-3",
                                                children: "COVERAGE"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 577,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-0.5 font-terminal text-sm font-bold tabular-nums text-ink",
                                                children: st.quality.longPct !== null ? `${st.quality.longPct}L/${st.quality.shortPct}S` : "—"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 578,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-terminal text-[9px] text-ink-3",
                                                children: [
                                                    st.quality.symbols,
                                                    " sym",
                                                    st.quality.topSymbolShare !== null ? ` · top ${st.quality.topSymbolShare}%` : ""
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 581,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 576,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 558,
                                columnNumber: 15
                            }, this),
                            st.quality.warnings.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 space-y-1",
                                children: st.quality.warnings.slice(0, 3).map((w, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start gap-1.5 font-terminal text-[9px] leading-relaxed text-amber-neon/90",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TriangleAlert$3e$__["TriangleAlert"], {
                                                className: "mt-0.5 size-2.5 shrink-0",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 590,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: w
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 591,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 589,
                                        columnNumber: 21
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 587,
                                columnNumber: 17
                            }, this),
                            st.quality.samples.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 max-h-44 overflow-y-auto rounded-md border border-white/8 bg-white/[0.02]",
                                title: "RAW-CAL samples — settled cohort first, then in-flight (score = integrity+plan+outcome+representativeness, 0-100)",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                    className: "w-full border-collapse font-terminal text-[9px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "border-b border-white/8 text-left text-ink-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-2 py-1 font-medium",
                                                        children: "SAMPLE"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 603,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-1 py-1 font-medium",
                                                        children: "SIDE"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 604,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-1 py-1 font-medium",
                                                        children: "STATUS"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 605,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-1 py-1 text-right font-medium",
                                                        children: "PNL"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 606,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-1 py-1 text-right font-medium",
                                                        children: "HELD"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 607,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-2 py-1 text-right font-medium",
                                                        children: "GRADE"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                        lineNumber: 608,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                lineNumber: 602,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                            lineNumber: 601,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            children: st.quality.samples.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "border-b border-white/5 last:border-0 text-ink-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-2 py-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "font-bold text-ink",
                                                                    children: [
                                                                        "NX-",
                                                                        String(s.serial).padStart(4, "0")
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                                    lineNumber: 615,
                                                                    columnNumber: 29
                                                                }, this),
                                                                " ",
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-ink-3",
                                                                    children: s.symbol
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                                    lineNumber: 616,
                                                                    columnNumber: 29
                                                                }, this),
                                                                s.flags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "ml-1 text-amber-neon/70",
                                                                    title: s.flags.join(" · "),
                                                                    children: [
                                                                        "⚑",
                                                                        s.flags.length
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                                    lineNumber: 617,
                                                                    columnNumber: 52
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                            lineNumber: 614,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-1 py-1 font-bold", s.direction === "LONG" ? "text-mint-neon" : "text-danger-neon"),
                                                            children: s.direction === "LONG" ? "L" : "S"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                            lineNumber: 619,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-1 py-1",
                                                            children: s.status
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                            lineNumber: 620,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-1 py-1 text-right tabular-nums", s.pnlPercent > 0 ? "text-mint-neon" : s.pnlPercent < 0 ? "text-danger-neon" : "text-ink-3"),
                                                            children: s.settled ? `${s.pnlPercent > 0 ? "+" : ""}${s.pnlPercent}%` : "—"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                            lineNumber: 621,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-1 py-1 text-right tabular-nums text-ink-3",
                                                            children: s.holdMin !== null ? `${s.holdMin}m` : s.settled ? "—" : "open"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                            lineNumber: 624,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-2 py-1 text-right",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-block rounded border px-1 py-0.5 text-[8.5px] font-bold tabular-nums", CLS_TONE[s.cls]),
                                                                title: `score ${s.score}/100 — HEALTHY ≥75, REVIEW ≥50, CENSORED <50`,
                                                                children: s.cls === "PENDING" ? "PEND" : s.score
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                                lineNumber: 626,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                            lineNumber: 625,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, s.serial, true, {
                                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                                    lineNumber: 613,
                                                    columnNumber: 25
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                            lineNumber: 611,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                    lineNumber: 600,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 599,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 flex flex-wrap items-center gap-x-2 gap-y-0.5 border-t border-white/5 pt-1.5 font-terminal text-[9px] leading-relaxed",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("size-2.5 shrink-0", st.quality.gate.verdict === "RED" ? "text-danger-neon" : "text-mint-neon"),
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 639,
                                        columnNumber: 17
                                    }, this),
                                    st.quality.gate.verdict === "WARMING" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-ink-3",
                                        children: "grading starts at the first raw settle — every settle re-scores the cohort"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 641,
                                        columnNumber: 19
                                    }, this) : st.quality.gate.blockers.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-danger-neon/90",
                                        children: [
                                            "BLOCKERS: ",
                                            st.quality.gate.blockers.join(" · ")
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 643,
                                        columnNumber: 19
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-mint-neon/80",
                                        children: "R6 recalibration may rest on this cohort — no blockers"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 645,
                                        columnNumber: 19
                                    }, this),
                                    st.quality.meanAbsPnl !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-auto text-ink-3",
                                        children: [
                                            "mean |pnl| ",
                                            st.quality.meanAbsPnl,
                                            "% · mean hold ",
                                            st.quality.meanHoldMin ?? "—",
                                            "m"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 647,
                                        columnNumber: 52
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 638,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 540,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 flex flex-wrap items-center gap-2",
                        children: [
                            st.armed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>void act("disarm"),
                                disabled: busy,
                                className: "inline-flex items-center gap-1.5 rounded-md border border-danger-neon/40 bg-danger-neon/10 px-3 py-2 font-terminal text-[10px] font-bold tracking-wider text-danger-neon transition hover:bg-danger-neon/20 disabled:opacity-50",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$power$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Power$3e$__["Power"], {
                                        className: "size-3",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 661,
                                        columnNumber: 17
                                    }, this),
                                    busy ? "DISARMING…" : "DISARM — RETURN TO FILTERED"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 656,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>void act("arm"),
                                disabled: busy,
                                className: "inline-flex items-center gap-1.5 rounded-md border border-amber-neon/40 bg-amber-neon/10 px-3 py-2 font-terminal text-[10px] font-bold tracking-wider text-amber-neon transition hover:bg-amber-neon/20 disabled:opacity-50",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flask$2d$conical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FlaskConical$3e$__["FlaskConical"], {
                                        className: "size-3",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                        lineNumber: 670,
                                        columnNumber: 17
                                    }, this),
                                    busy ? "ARMING…" : "ARM — ISSUE UNFILTERED RAW-CAL"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 665,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-terminal text-[9px] leading-relaxed text-ink-3",
                                children: st.armed ? `ARMED ${ago(st.armedAt)} AGO BY ${st.armedBy || "OPERATOR"}` : st.autoLiftAt ? `AUTO-LIFTED ${ago(st.autoLiftAt)} AGO — NEW CALIBRATION IN COMMAND` : st.disarmReason ? `DISARMED: ${st.disarmReason.slice(0, 60)}` : "IDLE"
                            }, void 0, false, {
                                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                                lineNumber: 674,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 654,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 font-terminal text-[9px] leading-relaxed tracking-[0.06em] text-ink-3",
                        children: "HONESTY RAILS STAY HARD (FEED-FRESH + SIM-PRICE BAN) · RAW RECORDS KEEP REAL FACTOR VOTES SO THE R6 RECALIBRATION AT N≥100 ATTRIBUTES OUTCOMES TO ACTUAL FACTORS"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                        lineNumber: 679,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/RawCalCard.tsx",
                lineNumber: 279,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/RawCalCard.tsx",
        lineNumber: 265,
        columnNumber: 5
    }, this);
}
_s(RawCalCard, "XD04S7UMFnnKgGxE2oLw+bOIJ7g=");
_c1 = RawCalCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "GrowthSpark");
__turbopack_context__.k.register(_c1, "RawCalCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/terminal/TerminalSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TerminalSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/activity.js [app-client] (ecmascript) <export default as Activity>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eraser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eraser$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eraser.js [app-client] (ecmascript) <export default as Eraser>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gauge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gauge$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/gauge.js [app-client] (ecmascript) <export default as Gauge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/link-2.js [app-client] (ecmascript) <export default as Link2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mouse$2d$pointer$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MousePointerClick$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/mouse-pointer-click.js [app-client] (ecmascript) <export default as MousePointerClick>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pause$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pause$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/pause.js [app-client] (ecmascript) <export default as Pause>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/play.js [app-client] (ecmascript) <export default as Play>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/radio.js [app-client] (ecmascript) <export default as Radio>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$waves$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Waves$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/waves.js [app-client] (ecmascript) <export default as Waves>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/shared/primitives.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$FlowScannerCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/FlowScannerCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$LiqDepthRadarCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/LiqDepthRadarCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$VolRiskCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/VolRiskCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$GateGaugeCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/GateGaugeCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$ShadowVetoCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/ShadowVetoCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$EntryLeversCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/EntryLeversCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$GoldenLaneCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/GoldenLaneCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$FuturesRadarCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/FuturesRadarCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$RawCalCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/terminal/RawCalCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/usePulse.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/ui.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const FILTERS = [
    {
        id: "ALL",
        label: "ALL"
    },
    {
        id: "AI",
        label: "AI"
    },
    {
        id: "TP",
        label: "TP HITS"
    },
    {
        id: "STOPS",
        label: "STOPS"
    },
    {
        id: "SYSTEM",
        label: "SYSTEM"
    }
];
const LEVEL_META = {
    ai: {
        tag: "◈ AI",
        cls: "text-violet-neon"
    },
    success: {
        tag: "✓",
        cls: "text-neon"
    },
    warn: {
        tag: "▲",
        cls: "text-amber-neon"
    },
    error: {
        tag: "✕",
        cls: "text-danger-neon"
    },
    info: {
        tag: "·",
        cls: "text-cyan-neon"
    }
};
const STAT_TYPES = [
    {
        type: "CREATED",
        bar: "bg-cyan-neon text-cyan-neon"
    },
    {
        type: "TP1",
        bar: "bg-neon text-neon"
    },
    {
        type: "TP2",
        bar: "bg-neon text-neon"
    },
    {
        type: "TP3",
        bar: "bg-neon text-neon"
    },
    {
        type: "SL",
        bar: "bg-danger-neon text-danger-neon"
    },
    {
        type: "TTL_EXPIRED",
        bar: "bg-amber-neon text-amber-neon"
    },
    {
        type: "TTL_EXTENDED",
        bar: "bg-cyan-neon text-cyan-neon"
    },
    {
        type: "BE_TRAIL",
        bar: "bg-cyan-neon text-cyan-neon"
    },
    {
        type: "AFTERLIFE",
        bar: "bg-violet-neon text-violet-neon"
    },
    {
        type: "TTL_EXT",
        bar: "bg-amber-neon text-amber-neon"
    }
];
const PROMPT_STATUS = [
    "monitoring liquidity pools…",
    "scanning orderflow…",
    "engine tick 5s"
];
/* v5.0 trigger-hierarchy display config */ const LAYER_CELLS = [
    {
        key: "L1_TAKER_SWEEP",
        label: "L1 SWEEP",
        tip: "Aggressive taker burst (aggTrades) — the fastest trigger",
        borderCls: "border-[rgb(var(--neon-rgb)/0.35)] bg-[rgb(var(--neon-rgb)/0.05)]",
        textCls: "text-neon"
    },
    {
        key: "L15_OBI_IMBALANCE",
        label: "L1.5 OBI",
        tip: "Order-book imbalance, spoof-guarded across 2 snapshots",
        borderCls: "border-[rgba(69,240,223,0.35)] bg-[rgba(69,240,223,0.05)]",
        textCls: "text-cyan-neon"
    },
    {
        key: "L2_VACUUM",
        label: "L2 VACUUM",
        tip: "Liquidity vacuum / wall within ±2% depth map",
        borderCls: "border-[rgba(255,179,71,0.35)] bg-[rgba(255,179,71,0.05)]",
        textCls: "text-amber-neon"
    },
    {
        key: "L3_LIQ_CASCADE",
        label: "L3 CASCADE",
        tip: "REAL forceOrder liquidation cascade — anti-cascade veto armed",
        borderCls: "border-[rgba(255,77,94,0.35)] bg-[rgba(255,77,94,0.05)]",
        textCls: "text-danger-neon"
    },
    {
        key: "L3P_LIQ_PRE",
        label: "L3P PRE",
        tip: "v8.1 predictive pre-cascade: price near a dense liq-heat cluster + OI still piling — the magnet warning BEFORE the cascade",
        borderCls: "border-[rgba(255,140,66,0.4)] bg-[rgba(255,140,66,0.06)]",
        textCls: "text-orange-400"
    },
    {
        key: "L35_CROWD_JUMP",
        label: "L3.5 CROWD",
        tip: "Leverage crowding: funding extreme + OI jump — size cut armed",
        borderCls: "border-[rgba(255,78,205,0.35)] bg-[rgba(255,78,205,0.05)]",
        textCls: "text-magenta-neon"
    },
    {
        key: "L4_MACRO",
        label: "L4 MACRO",
        tip: "Macro flows — honest data gap: OBSERVING, never fabricated",
        borderCls: "border-white/10 bg-white/[0.02]",
        textCls: "text-ink-2"
    }
];
const LAYER_SHORT = {
    L1_TAKER_SWEEP: "L1",
    L15_OBI_IMBALANCE: "L1.5",
    L2_VACUUM: "L2",
    L3_LIQ_CASCADE: "L3",
    L3P_LIQ_PRE: "L3P",
    L35_CROWD_JUMP: "L3.5",
    L4_MACRO: "L4"
};
const REGIME_CLS = {
    TREND_UP: "border-[rgb(var(--neon-rgb)/0.45)] text-neon",
    TREND_DOWN: "border-[rgba(255,78,205,0.45)] text-magenta-neon",
    CHOP: "border-[rgba(159,180,171,0.3)] text-ink-2",
    VOLATILE: "border-[rgba(255,179,71,0.45)] text-amber-neon"
};
const REGIME_BAR = {
    TREND_UP: "bg-neon text-neon",
    TREND_DOWN: "bg-magenta-neon text-magenta-neon",
    CHOP: "bg-white/30 text-white/30",
    VOLATILE: "bg-amber-neon text-amber-neon"
};
function matchesFilter(e, f) {
    switch(f){
        case "ALL":
            return true;
        case "AI":
            return e.level === "ai";
        case "TP":
            return e.type.startsWith("TP");
        case "STOPS":
            return e.type === "SL" || e.type === "TTL_EXPIRED";
        case "SYSTEM":
            return e.type === "SYSTEM" || e.type === "ENGINE" || e.type === "TTL_EXTENDED" || e.type === "BE_TRAIL";
    }
}
function pad2(n) {
    return String(n).padStart(2, "0");
}
function fmtUptime(ms) {
    const s = Math.max(0, Math.floor(ms / 1000));
    return `${pad2(Math.floor(s / 3600))}:${pad2(Math.floor(s % 3600 / 60))}:${pad2(s % 60)}`;
}
function TerminalSection() {
    _s();
    const mounted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMounted"])();
    const setOpenSignal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUi"])({
        "TerminalSection.useUi[setOpenSignal]": (s)=>s.setOpenSignal
    }["TerminalSection.useUi[setOpenSignal]"]);
    const now = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNow"])(1000);
    const deviceNow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeviceNow"])(1000);
    const { data: pulse } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"])(5000);
    const [filter, setFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("ALL");
    const [paused, setPaused] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [stick, setStick] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [clearAt, setClearAt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [statusIdx, setStatusIdx] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    /* session boot timestamp — never rendered pre-mount, so SSR/client delta is invisible */ const [bootTs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "TerminalSection.useState": ()=>Date.now()
    }["TerminalSection.useState"]);
    const scrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    /* deep event feed — newest N events, polled */ const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "events"
        ],
        queryFn: {
            "TerminalSection.useQuery": async ()=>{
                const res = await fetch("/api/events?limit=120", {
                    cache: "no-store"
                });
                if (!res.ok) throw new Error(`events ${res.status}`);
                return await res.json();
            }
        }["TerminalSection.useQuery"],
        refetchInterval: 5000
    });
    /* rotating fake prompt status — deterministic cycle */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TerminalSection.useEffect": ()=>{
            const id = setInterval({
                "TerminalSection.useEffect.id": ()=>setStatusIdx({
                        "TerminalSection.useEffect.id": (i)=>(i + 1) % PROMPT_STATUS.length
                    }["TerminalSection.useEffect.id"])
            }["TerminalSection.useEffect.id"], 3200);
            return ({
                "TerminalSection.useEffect": ()=>clearInterval(id)
            })["TerminalSection.useEffect"];
        }
    }["TerminalSection.useEffect"], []);
    /* ascending order — newest line renders at the bottom */ const sorted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TerminalSection.useMemo[sorted]": ()=>{
            const evts = data?.events ?? [];
            return [
                ...evts
            ].sort({
                "TerminalSection.useMemo[sorted]": (a, b)=>a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id)
            }["TerminalSection.useMemo[sorted]"]);
        }
    }["TerminalSection.useMemo[sorted]"], [
        data
    ]);
    const visible = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TerminalSection.useMemo[visible]": ()=>sorted.filter({
                "TerminalSection.useMemo[visible]": (e)=>clearAt ? new Date(e.createdAt).getTime() > clearAt : true
            }["TerminalSection.useMemo[visible]"])
    }["TerminalSection.useMemo[visible]"], [
        sorted,
        clearAt
    ]);
    const filtered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TerminalSection.useMemo[filtered]": ()=>visible.filter({
                "TerminalSection.useMemo[filtered]": (e)=>matchesFilter(e, filter)
            }["TerminalSection.useMemo[filtered]"])
    }["TerminalSection.useMemo[filtered]"], [
        visible,
        filter
    ]);
    /* autoscroll: stick to bottom unless user scrolled up or paused */ const handleScroll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TerminalSection.useCallback[handleScroll]": ()=>{
            const el = scrollRef.current;
            if (!el) return;
            const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 48;
            setStick(nearBottom);
        }
    }["TerminalSection.useCallback[handleScroll]"], []);
    const lastId = filtered.length > 0 ? filtered[filtered.length - 1].id : "";
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TerminalSection.useEffect": ()=>{
            const el = scrollRef.current;
            if (!el || paused || !stick) return;
            el.scrollTop = el.scrollHeight;
        }
    }["TerminalSection.useEffect"], [
        lastId,
        stick,
        paused
    ]);
    const resume = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TerminalSection.useCallback[resume]": ()=>{
            setStick(true);
            setPaused(false);
            const el = scrollRef.current;
            if (el) el.scrollTop = el.scrollHeight;
        }
    }["TerminalSection.useCallback[resume]"], []);
    const clearScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TerminalSection.useCallback[clearScreen]": ()=>{
            setClearAt(Date.now());
            setStick(true);
        }
    }["TerminalSection.useCallback[clearScreen]"], []);
    /* ── session stats: counts by type — stream buffer ∪ authoritative pulse stats
     (v5.2 accuracy fix: rows now read the ENGINE's own lifetime aggregates —
     CREATED = all signals ever · TP1/TP2/TP3 = lifetime rung hits incl. post-expiry
     afterlife · SL/EXPIRED = settled outcomes · AFTERLIFE = live post-expiry
     trackers. No more undercounting from current-status-only snapshots.)
     v9.0 LIFECYCLE AUDIT (operator request 2026-09-12): BE_TRAIL / TTL_EXTENDED
     rows previously read ONLY the 120-event terminal window — ENGINE chatter
     (16k+ rows) flushed them out within minutes and the counters collapsed to 0.
     They now carry lifetime DB counts from stats.lifecycle; AFTERLIFE now shows
     tracking + RESOLVED outcomes, not just the currently-tracking slice. */ const counts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TerminalSection.useMemo[counts]": ()=>{
            const map = new Map();
            for (const t of STAT_TYPES)map.set(t.type, 0);
            for (const e of visible)if (map.has(e.type)) map.set(e.type, (map.get(e.type) ?? 0) + 1);
            const s = pulse?.stats;
            const sigs = pulse?.signals ?? [];
            if (s) {
                // v10.3 TRUE-LIFETIME: CREATED/TP rungs/SL/EXPIRED read straight DB aggregates
                // over ALL rows (stats.lifecycle, 30s memo) — the old 7-day stats window +
                // 60-signal pulse slice dropped older activity and the rows went stale.
                map.set("CREATED", Math.max(map.get("CREATED") ?? 0, s.lifecycle.lifetimeSignals, s.totalSignals));
                map.set("SL", Math.max(map.get("SL") ?? 0, s.lifecycle.slLifetime, s.losses));
                map.set("TTL_EXPIRED", Math.max(map.get("TTL_EXPIRED") ?? 0, s.lifecycle.expiredLifetime, s.expired));
                map.set("TP1", Math.max(map.get("TP1") ?? 0, s.lifecycle.tp1HitsLifetime));
                map.set("TP2", Math.max(map.get("TP2") ?? 0, s.lifecycle.tp2HitsLifetime));
                map.set("TP3", Math.max(map.get("TP3") ?? 0, s.lifecycle.tp3HitsLifetime));
                // v9.0: lifetime AFTERLIFE = 48h trackers still running + resolved outcomes
                map.set("AFTERLIFE", Math.max(map.get("AFTERLIFE") ?? 0, s.lifecycle.afterlifeTotal));
                // v9.0: BE_TRAIL — lifetime breakeven arms straight from SignalEvent
                map.set("BE_TRAIL", Math.max(map.get("BE_TRAIL") ?? 0, s.lifecycle.beTrail));
                // v9.0: TTL_EXTENDED — lifetime grants (events); TTL_EXT keeps distinct signals
                map.set("TTL_EXTENDED", Math.max(map.get("TTL_EXTENDED") ?? 0, s.lifecycle.ttlExtendedEvents));
                map.set("TTL_EXT", Math.max(map.get("TTL_EXT") ?? 0, s.lifecycle.ttlSignalsWithExt, s.pnlLedger.totals.ttlExtended));
                // lifetime TP rung hits from the live pulse slice — window can only RAISE the
                // DB aggregate when a rung landed within the last 30s memo horizon.
                const hit = {
                    "TerminalSection.useMemo[counts].hit": (pred, rungs)=>sigs.filter({
                            "TerminalSection.useMemo[counts].hit": (x)=>rungs.includes(x.status) || (x.afterlife ? pred(x.afterlife) : false)
                        }["TerminalSection.useMemo[counts].hit"]).length
                }["TerminalSection.useMemo[counts].hit"];
                map.set("TP1", Math.max(map.get("TP1") ?? 0, hit({
                    "TerminalSection.useMemo[counts]": (a)=>a.includes("TP1")
                }["TerminalSection.useMemo[counts]"], [
                    "TP1",
                    "TP2",
                    "TP3"
                ])));
                map.set("TP2", Math.max(map.get("TP2") ?? 0, hit({
                    "TerminalSection.useMemo[counts]": (a)=>a === "TP2_HIT" || a === "TP3_HIT"
                }["TerminalSection.useMemo[counts]"], [
                    "TP2",
                    "TP3"
                ])));
                map.set("TP3", Math.max(map.get("TP3") ?? 0, hit({
                    "TerminalSection.useMemo[counts]": (a)=>a === "TP3_HIT"
                }["TerminalSection.useMemo[counts]"], [
                    "TP3"
                ])));
            }
            return map;
        }
    }["TerminalSection.useMemo[counts]"], [
        visible,
        pulse
    ]);
    const maxCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TerminalSection.useMemo[maxCount]": ()=>{
            let m = 1;
            for (const v of counts.values())if (v > m) m = v;
            return m;
        }
    }["TerminalSection.useMemo[maxCount]"], [
        counts
    ]);
    /* EPOCH-2 zero-state: ledger genuinely empty (no signals since reset) →
     the panel shows an explicit clean-state note instead of silent zeros */ const epochClean = (pulse?.stats?.totalSignals ?? 0) === 0 && (pulse?.signals ?? []).length === 0;
    /* v9.0 PUMP/DUMP RADAR — gate + tracks from the pulse feed (15s server memo) */ const pump = pulse?.feed?.pump ?? null;
    /* ── stream health — REAL engine/feed telemetry (Bug 3 fix: honest liq feed row) ── */ const health = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TerminalSection.useMemo[health]": ()=>{
            if (sorted.length < 2) return null;
            const newest = new Date(sorted[sorted.length - 1].createdAt).getTime();
            const oldest = new Date(sorted[0].createdAt).getTime();
            const spanMin = Math.max((newest - oldest) / 60_000, 0.5);
            return {
                perMin: sorted.length / spanMin
            };
        }
    }["TerminalSection.useMemo[health]"], [
        sorted
    ]);
    const feed = pulse?.feed ?? null;
    const liq = feed?.liq ?? null;
    const liqState = !liq ? {
        label: "OFFLINE",
        cls: "text-ink-3",
        tip: "liq-service :3010 unreachable — derived OI probe in use, no invented data"
    } : liq.dataStalled ? {
        label: "NO DATA",
        cls: "text-amber-neon",
        tip: "exchange frames blocked from this host — watchdog honest state; derived probe in use"
    } : liq.connected ? {
        label: `CONNECTED ${liq.buffered}`,
        cls: "text-neon",
        tip: "!forceOrder@arr streaming"
    } : {
        label: "RECONNECTING",
        cls: "text-amber-neon",
        tip: "auto-reconnect 5s"
    };
    const flowCovered = feed?.flow.covered ?? 0;
    const triggers = feed?.triggers ?? null;
    const regimes = feed?.regimes ?? [];
    const uptime = mounted && now >= bootTs ? fmtUptime(now - bootTs) : "--:--:--";
    const linked = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TerminalSection.useMemo[linked]": ()=>{
            // Bug 4 fix: prefer the dedicated linked-events query (any signal-attached event in DB),
            // fall back to scanning the visible buffer, then to recent signals from pulse.
            const fromApi = (data?.linked ?? []).slice(0, 5);
            if (fromApi.length > 0) return fromApi;
            const fromBuffer = sorted.filter({
                "TerminalSection.useMemo[linked].fromBuffer": (e)=>e.signalId
            }["TerminalSection.useMemo[linked].fromBuffer"]).slice(-5).reverse();
            if (fromBuffer.length > 0) return fromBuffer;
            return [];
        }
    }["TerminalSection.useMemo[linked]"], [
        data,
        sorted
    ]);
    const totalEvents = data?.events.length ?? 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "aria-label": "Engine terminal",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionHeader"], {
                index: "04",
                title: "ENGINE TERMINAL",
                subtitle: "CRT event feed — filter, freeze and stream the signal engine live",
                right: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                    tone: "violet",
                    children: "POLL 5S"
                }, void 0, false, {
                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                    lineNumber: 304,
                    columnNumber: 16
                }, void 0)
            }, void 0, false, {
                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                lineNumber: 300,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-4 xl:grid-cols-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
                        corners: true,
                        className: "overflow-hidden p-0 sm:p-0 xl:col-span-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 border-b border-white/5 bg-[rgba(255,255,255,0.02)] px-4 py-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "size-3 shrink-0 rounded-full bg-[#ff4d5e] shadow-[0_0_8px_rgba(255,77,94,0.6)]",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 312,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "size-3 shrink-0 rounded-full bg-[#ffb347] shadow-[0_0_8px_rgba(255,179,71,0.5)]",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 313,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "size-3 shrink-0 rounded-full bg-neon shadow-[0_0_8px_rgb(var(--neon-rgb)/0.6)]",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 314,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-2 truncate font-terminal text-xs text-ink-2",
                                        children: "flowradar@core:~ — engine.log"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 315,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-auto font-terminal text-[10px] uppercase tracking-[0.18em] text-ink-3",
                                        children: [
                                            String(totalEvents).padStart(3, "0"),
                                            " EV"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 316,
                                        columnNumber: 13
                                    }, this),
                                    paused ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                        tone: "amber",
                                        title: "این نشان فقط مکثِ اسکرولِ خودکارِ لاگ است — وضعیت موتور سیگنال یا اتصال صرافی را نشان نمی‌دهد؛ موتور مستقل از این دکمه به کارش ادامه می‌دهد",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {
                                                tone: "amber"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 321,
                                                columnNumber: 17
                                            }, this),
                                            " SCROLL-HOLD"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 320,
                                        columnNumber: 15
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                        tone: "neon",
                                        glow: true,
                                        title: "جریان زندهٔ لاگ — وضعیت موتور سیگنال را نشان نمی‌دهد؛ موتور همیشه مستقل از این پنل کار می‌کند",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 325,
                                                columnNumber: 17
                                            }, this),
                                            " STREAM"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 324,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 311,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap items-center gap-2 border-b border-white/5 px-3 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap items-center gap-1.5",
                                        role: "group",
                                        "aria-label": "Log level filters",
                                        children: FILTERS.map((f)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setFilter(f.id),
                                                "aria-pressed": filter === f.id,
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("min-h-11 rounded border px-3 font-terminal text-[10px] font-bold uppercase tracking-[0.14em] transition-colors", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon/60", filter === f.id ? "border-neon/50 bg-neon/10 text-neon" : "border-white/10 text-ink-3 hover:border-neon/30 hover:text-ink-2"),
                                                children: f.label
                                            }, f.id, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 334,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 332,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "ml-auto flex items-center gap-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setPaused((p)=>!p),
                                                "aria-pressed": paused,
                                                "aria-label": paused ? "Resume autoscroll" : "Pause autoscroll",
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("grid size-11 place-items-center rounded border transition-colors", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon/60", paused ? "border-amber-neon/50 bg-amber-neon/10 text-amber-neon" : "border-white/10 text-ink-2 hover:border-neon/40 hover:text-neon"),
                                                children: paused ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__["Play"], {
                                                    className: "size-4",
                                                    "aria-hidden": true
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 27
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pause$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pause$3e$__["Pause"], {
                                                    className: "size-4",
                                                    "aria-hidden": true
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 69
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 352,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: clearScreen,
                                                "aria-label": "Clear log buffer (local only)",
                                                title: "Clear screen (local)",
                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("grid size-11 place-items-center rounded border border-white/10 text-ink-2 transition-colors", "hover:border-danger-neon/50 hover:text-danger-neon", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-danger-neon/60"),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eraser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eraser$3e$__["Eraser"], {
                                                    className: "size-4",
                                                    "aria-hidden": true
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                    lineNumber: 378,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 367,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 351,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 331,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        ref: scrollRef,
                                        onScroll: handleScroll,
                                        role: "log",
                                        "aria-live": "polite",
                                        "aria-label": "Engine event log",
                                        className: "grid-bg-fine relative h-[62vh] overflow-y-auto px-4 py-3 font-terminal text-[12px] leading-relaxed",
                                        children: [
                                            filtered.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-ink-3",
                                                children: clearAt ? "── buffer flushed — awaiting new events ──" : "awaiting engine telemetry…"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 394,
                                                columnNumber: 17
                                            }, this),
                                            filtered.map((e)=>{
                                                const meta = LEVEL_META[e.level];
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                    initial: {
                                                        opacity: 0,
                                                        x: -10
                                                    },
                                                    animate: {
                                                        opacity: 1,
                                                        x: 0
                                                    },
                                                    transition: {
                                                        duration: 0.3,
                                                        ease: "easeOut"
                                                    },
                                                    className: "flex items-start gap-2 py-[3px]",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "shrink-0 tabular-nums text-ink-3",
                                                            children: [
                                                                "[",
                                                                mounted ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtClockLocal"])(new Date(e.createdAt).getTime()) : "--:--:--",
                                                                "]"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 408,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-10 shrink-0 font-bold", meta.cls),
                                                            children: meta.tag
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 411,
                                                            columnNumber: 21
                                                        }, this),
                                                        e.symbol && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "shrink-0 rounded border border-[rgba(255,78,205,0.35)] px-1 font-bold leading-5 text-magenta-neon",
                                                            children: e.symbol
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 413,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("min-w-0 flex-1 break-words", e.level === "ai" ? "text-violet-neon/90" : "text-ink-2"),
                                                            children: e.message
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 417,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, e.id, true, {
                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                    lineNumber: 401,
                                                    columnNumber: 19
                                                }, this);
                                            })
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 385,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "pointer-events-none absolute inset-0",
                                        "aria-hidden": true,
                                        style: {
                                            background: "repeating-linear-gradient(0deg, rgba(255,255,255,0.024) 0px, rgba(255,255,255,0.024) 1px, transparent 1px, transparent 3px)"
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 425,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "pointer-events-none absolute inset-x-0 top-0 h-10 bg-gradient-to-b from-[rgba(0,0,0,0.4)] to-transparent",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 433,
                                        columnNumber: 13
                                    }, this),
                                    (!stick || paused) && filtered.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: resume,
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("absolute bottom-3 right-4 z-10 flex min-h-11 items-center gap-1.5 rounded-full border border-neon/60 bg-[rgb(var(--neon-rgb)/0.14)] px-4", "font-terminal text-[10px] font-bold uppercase tracking-[0.18em] text-neon backdrop-blur-sm transition-colors hover:bg-[rgb(var(--neon-rgb)/0.24)]", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon/70"),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__["Play"], {
                                                className: "size-3",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 448,
                                                columnNumber: 17
                                            }, this),
                                            " RESUME"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 439,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 384,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 border-t border-white/5 bg-[rgba(0,0,0,0.35)] px-4 py-2.5 font-terminal text-xs",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "shrink-0 font-bold text-neon",
                                        children: "flowradar@core:~$"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 455,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "min-w-0 truncate text-ink-3",
                                        children: mounted ? PROMPT_STATUS[statusIdx] : "booting engine…"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 456,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "anim-caret ml-0.5 inline-block h-3.5 w-[7px] shrink-0 bg-neon",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 457,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 454,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 309,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
                                className: "p-4 sm:p-4",
                                delay: 0.05,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__["Activity"], {
                                                className: "size-3.5 text-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 469,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "label-tech",
                                                children: "Session Stats"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 470,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                tone: "muted",
                                                className: "ml-auto",
                                                children: "LIFETIME"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 471,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 468,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-2.5",
                                        children: [
                                            pulse?.stats?.sizing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between border-b border-white/5 pb-2 font-terminal text-[10px]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "uppercase tracking-[0.16em] text-ink-3",
                                                        children: "SIZING"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 480,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-bold uppercase tracking-[0.1em]", pulse.stats.sizing.mode === "ANTI_MARTINGALE" ? "text-neon" : pulse.stats.sizing.mode === "FLAT" ? "text-amber-neon" : "text-ink"),
                                                        title: `flat $${pulse.stats.sizing.flatBase} · anti-base $${pulse.stats.sizing.antiBase} ×${pulse.stats.sizing.decay} · floor $${pulse.stats.sizing.floor}`,
                                                        children: pulse.stats.sizing.mode === "ANTI_MARTINGALE" ? `ANTI-MART ×${pulse.stats.sizing.decay} · k=${pulse.stats.sizing.consecSl}/${pulse.stats.sizing.consecCap}` : pulse.stats.sizing.mode === "FLAT" ? `FLAT $${pulse.stats.sizing.flatBase.toFixed(2)}` : "CONFIDENCE 2-8%"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 481,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 479,
                                                columnNumber: 17
                                            }, this),
                                            STAT_TYPES.map((t)=>{
                                                const c = counts.get(t.type) ?? 0;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between font-terminal text-[10px]",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "uppercase tracking-[0.16em] text-ink-3",
                                                                    children: t.type
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 501,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "font-bold tabular-nums text-ink",
                                                                    children: String(c).padStart(2, "0")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 502,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 500,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mt-1 h-1 overflow-hidden rounded-full bg-white/5",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("h-full rounded-full transition-[width] duration-700", t.bar),
                                                                style: {
                                                                    width: `${c / maxCount * 100}%`,
                                                                    boxShadow: "0 0 6px currentColor"
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 505,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 504,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, t.type, true, {
                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                    lineNumber: 499,
                                                    columnNumber: 19
                                                }, this);
                                            }),
                                            epochClean && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "border-t border-white/5 pt-2 font-terminal text-[10px] leading-relaxed tracking-[0.08em] text-ink-3",
                                                children: "EPOCH-2 CLEAN — counters seed from the first deployed signal"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 514,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 475,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 467,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
                                className: "p-4 sm:p-4",
                                delay: 0.08,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$waves$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Waves$3e$__["Waves"], {
                                                className: "size-3.5 text-magenta-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 527,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "label-tech",
                                                children: "Pump/Dump Radar"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 528,
                                                columnNumber: 15
                                            }, this),
                                            pump && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                tone: pump.gate.unlocked ? "neon" : "amber",
                                                className: "ml-auto",
                                                glow: pump.gate.unlocked,
                                                children: pump.gate.unlocked ? "UNLOCKED" : `LOCKED ${pump.gate.successful}/${pump.gate.required}`
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 530,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 526,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-2 font-terminal text-[11px]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "learning gate"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 537,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-bold tabular-nums", pump?.gate.unlocked ? "text-neon" : "text-amber-neon"),
                                                        children: pump ? `${pump.gate.successful}✓ / ${pump.gate.failed}✕ of ${pump.gate.total} tracks` : "--"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 538,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 536,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "signal authority"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 543,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-bold uppercase tracking-[0.14em]", pump?.authority === "direct" ? "text-magenta-neon" : pump?.gate.unlocked ? "text-neon" : "text-ink-3"),
                                                        children: pump?.authority === "direct" ? "DIRECT (evidence ≥78)" : pump?.gate.unlocked ? "PUMP/DUMP CARDS ARMED" : "FORBIDDEN UNTIL 5 SUCCESSES"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 544,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 542,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "tape"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 549,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-bold tabular-nums text-ink",
                                                        children: pump ? `${pump.tapeSymbols} symbols ${pump.warm ? "· warm" : "· warming"}` : "--"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 550,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 548,
                                                columnNumber: 15
                                            }, this),
                                            (pump?.active.length ?? 0) > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-1 border-t border-white/5 pt-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "active tracks"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 556,
                                                        columnNumber: 19
                                                    }, this),
                                                    pump.active.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 rounded border px-1 font-bold", t.kind === "PUMP" ? "border-magenta-neon/40 text-magenta-neon" : "border-danger-neon/40 text-danger-neon"),
                                                                    children: t.kind
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 559,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "truncate font-bold text-ink",
                                                                    children: t.symbol
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 562,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "shrink-0 text-ink-3",
                                                                    children: t.phase.toLowerCase()
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 563,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 font-bold tabular-nums", t.mfePct >= 0 ? "text-neon" : "text-danger-neon"),
                                                                    children: [
                                                                        t.mfePct >= 0 ? "+" : "",
                                                                        t.mfePct.toFixed(1),
                                                                        "%"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 564,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "shrink-0 text-ink-3",
                                                                    children: [
                                                                        "s",
                                                                        t.score
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 567,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, t.id, true, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 558,
                                                            columnNumber: 21
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 555,
                                                columnNumber: 17
                                            }, this),
                                            (pump?.recent.length ?? 0) > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-1 border-t border-white/5 pt-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "recent resolutions"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 574,
                                                        columnNumber: 19
                                                    }, this),
                                                    pump.recent.slice(0, 4).map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 font-bold", t.outcome === "SUCCESS" ? "text-neon" : "text-danger-neon"),
                                                                    children: [
                                                                        t.outcome === "SUCCESS" ? "✓" : "✕",
                                                                        " ",
                                                                        t.kind
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 577,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "truncate font-bold text-ink",
                                                                    children: t.symbol
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 580,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "shrink-0 tabular-nums text-ink-3",
                                                                    children: [
                                                                        "MFE ",
                                                                        t.mfePct >= 0 ? "+" : "",
                                                                        t.mfePct.toFixed(1),
                                                                        "%"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 581,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, t.id, true, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 576,
                                                            columnNumber: 21
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 573,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 535,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 525,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$RawCalCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 595,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
                                className: "p-4 sm:p-4",
                                delay: 0.1,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gauge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gauge$3e$__["Gauge"], {
                                                className: "size-3.5 text-cyan-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 600,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "label-tech",
                                                children: "Event Stream Health"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 601,
                                                columnNumber: 15
                                            }, this),
                                            feed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                tone: feed.source === "LIVE" ? "neon" : "amber",
                                                className: "ml-auto",
                                                children: feed.source === "LIVE" ? `LIVE ${feed.latencyMs ?? "--"}MS` : feed.source === "STALE" ? "CACHED" : "SIM"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 603,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 599,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-2 font-terminal text-[11px]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "events / min"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 610,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-bold tabular-nums text-neon",
                                                        children: health ? health.perMin.toFixed(1) : "--"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 611,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 609,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "binance feed"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 614,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-bold tabular-nums text-cyan-neon",
                                                        children: feed?.host ? `${feed.host.replace("https://", "")}` : "--"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 615,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 613,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "futures ws"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 624,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-1.5 font-bold uppercase tracking-[0.14em]", feed?.futws?.fresh ? "text-neon" : "text-amber-neon"),
                                                        children: feed?.futws?.fresh ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 628,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " ",
                                                                feed.futws.rows,
                                                                " SYMBOLS"
                                                            ]
                                                        }, void 0, true) : "WARMING"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 625,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 623,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "5-ex consensus"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 636,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "flex items-center gap-1 font-bold tabular-nums text-cyan-neon",
                                                        children: [
                                                            (feed?.exchanges ?? []).filter((v)=>v.ok).length,
                                                            "/5",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {
                                                                tone: (feed?.exchanges ?? []).filter((v)=>v.ok).length >= 3 ? "neon" : "amber"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 639,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 637,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 635,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "flow data"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 643,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-1.5 font-bold uppercase tracking-[0.14em]", flowCovered > 0 ? "text-neon" : "text-amber-neon"),
                                                        children: flowCovered > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 647,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " ",
                                                                flowCovered,
                                                                " SYMBOLS"
                                                            ]
                                                        }, void 0, true) : "WARMING"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 644,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 642,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                title: liqState.tip,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "liq feed"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 655,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-1.5 font-bold uppercase tracking-[0.14em]", liqState.cls),
                                                        children: [
                                                            liq && !liq.dataStalled && liq.connected ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 657,
                                                                columnNumber: 63
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {
                                                                tone: "amber"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 657,
                                                                columnNumber: 77
                                                            }, this),
                                                            " ",
                                                            liqState.label
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 656,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 654,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "session uptime"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 661,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-bold tabular-nums text-ink",
                                                        children: uptime
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 662,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 660,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                title: "your device system clock — matches the OS taskbar",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "system clock"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 667,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-bold tabular-nums text-ink",
                                                        children: mounted ? `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtClockLocal"])(deviceNow)} ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["localTzLabel"])()}` : "--:--:--"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 668,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 666,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "label-tech",
                                                        children: "feed status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 673,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "flex items-center gap-1.5 font-bold uppercase tracking-[0.16em] text-neon",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {}, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 675,
                                                                columnNumber: 19
                                                            }, this),
                                                            " streaming"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 674,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 672,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 608,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 598,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
                                className: "p-4 sm:p-4",
                                delay: 0.12,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__["Radio"], {
                                                className: "size-3.5 text-violet-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 684,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "label-tech",
                                                children: "Trigger Bus"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 685,
                                                columnNumber: 15
                                            }, this),
                                            triggers && triggers.lastCycleAt && Date.now() - triggers.lastCycleAt < 10 * 60_000 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                tone: "violet",
                                                glow: true,
                                                className: "ml-auto",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LiveDot"], {
                                                        tone: "violet"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 688,
                                                        columnNumber: 19
                                                    }, this),
                                                    " EVENT-DRIVEN"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 687,
                                                columnNumber: 17
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                tone: "muted",
                                                className: "ml-auto",
                                                children: "WARMING"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 691,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 683,
                                        columnNumber: 13
                                    }, this),
                                    !triggers || triggers.last.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-terminal text-[11px] leading-relaxed text-ink-3",
                                        children: "Bus rotating through the universe — taker sweeps, OBI extremes, vacuums and cascades fire as THEY happen, not on a scan schedule."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 697,
                                        columnNumber: 15
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mb-2.5 grid grid-cols-3 gap-1.5",
                                                children: LAYER_CELLS.map((l)=>{
                                                    const n = triggers.counts[l.key] ?? 0;
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        title: l.tip,
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-lg border px-2 py-1.5", n > 0 ? l.borderCls : "border-white/8 bg-white/[0.02]"),
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-terminal text-[9px] font-bold uppercase tracking-[0.1em]", n > 0 ? l.textCls : "text-ink-3"),
                                                                children: l.label
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 708,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-terminal text-base font-bold tabular-nums", n > 0 ? l.textCls : "text-ink-3"),
                                                                children: String(n).padStart(2, "0")
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 709,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, l.key, true, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 707,
                                                        columnNumber: 23
                                                    }, this);
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 703,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "max-h-40 space-y-1 overflow-y-auto pr-1",
                                                "aria-label": "Recent trigger events",
                                                children: triggers.last.slice(0, 8).map((t, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        className: "flex items-start gap-1.5 font-terminal text-[10px] leading-relaxed",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 rounded border px-1 font-bold leading-5", t.acted ? "border-[rgb(var(--neon-rgb)/0.5)] text-neon" : "border-white/10 text-ink-3"),
                                                                children: LAYER_SHORT[t.layer] ?? t.layer
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 718,
                                                                columnNumber: 23
                                                            }, this),
                                                            t.symbol !== "—" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "shrink-0 font-bold text-ink",
                                                                children: t.symbol.replace("USDT", "")
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 721,
                                                                columnNumber: 44
                                                            }, this),
                                                            t.side !== "NEUTRAL" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 font-bold", t.side === "LONG" ? "text-neon" : "text-magenta-neon"),
                                                                children: t.side
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 722,
                                                                columnNumber: 48
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "min-w-0 flex-1 text-ink-3",
                                                                children: t.detail
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 723,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, `${t.at}-${t.layer}-${i}`, true, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 717,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 715,
                                                columnNumber: 17
                                            }, this),
                                            (triggers.suppressed.length > 0 || triggers.crowdCut.length > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-2 flex flex-wrap gap-1",
                                                children: [
                                                    triggers.suppressed.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            title: "L3 anti-cascade suppression window",
                                                            className: "rounded border border-danger-neon/40 px-1.5 py-0.5 font-terminal text-[9px] font-bold tracking-[0.08em] text-danger-neon",
                                                            children: [
                                                                "CASCADE-VETO ",
                                                                s.replace("USDT", "")
                                                            ]
                                                        }, `sup-${s}`, true, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 730,
                                                            columnNumber: 23
                                                        }, this)),
                                                    triggers.crowdCut.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            title: "L3.5 leverage-crowding size cut",
                                                            className: "rounded border border-amber-neon/40 px-1.5 py-0.5 font-terminal text-[9px] font-bold tracking-[0.08em] text-amber-neon",
                                                            children: [
                                                                "CROWD-CUT ",
                                                                s.replace("USDT", "")
                                                            ]
                                                        }, `cut-${s}`, true, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 733,
                                                            columnNumber: 23
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 728,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 682,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
                                className: "p-4 sm:p-4",
                                delay: 0.14,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$waves$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Waves$3e$__["Waves"], {
                                                className: "size-3.5 text-cyan-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 744,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "label-tech",
                                                children: "Market Regimes"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 745,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                tone: "cyan",
                                                className: "ml-auto",
                                                children: "LAYER-0 FILTER"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 746,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 743,
                                        columnNumber: 13
                                    }, this),
                                    regimes.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-terminal text-[11px] text-ink-3",
                                        children: "regime classifier warming — klines caching…"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 751,
                                        columnNumber: 15
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1",
                                        children: regimes.slice(0, 8).map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2 font-terminal text-[10px]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-14 shrink-0 font-bold tracking-[0.08em] text-ink",
                                                        children: r.symbol.replace("USDT", "")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 756,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 rounded border px-1.5 py-0.5 font-bold tracking-[0.08em]", REGIME_CLS[r.regime] ?? "border-white/10 text-ink-3"),
                                                        children: r.label
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 757,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "h-1 flex-1 overflow-hidden rounded-full bg-white/5",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("h-full rounded-full", REGIME_BAR[r.regime] ?? "bg-white/20"),
                                                            style: {
                                                                width: `${Math.round(r.strength * 100)}%`,
                                                                boxShadow: "0 0 6px currentColor"
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 759,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 758,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "w-8 shrink-0 text-right tabular-nums text-ink-3",
                                                        children: [
                                                            Math.round(r.strength * 100),
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 761,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, r.symbol, true, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 755,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 753,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-2 font-terminal text-[9px] leading-relaxed text-ink-3",
                                        children: "TREND vetoes counter-trend mean-revert · CHOP penalizes breakouts · VOLATILE cuts size ×0.6, widens stops ×1.3"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 766,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 742,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BentoCard"], {
                                className: "p-4 sm:p-4",
                                delay: 0.15,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link2$3e$__["Link2"], {
                                                className: "size-3.5 text-magenta-neon",
                                                "aria-hidden": true
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 774,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "label-tech",
                                                children: "Signal Links"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 775,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                                                tone: "muted",
                                                className: "ml-auto",
                                                children: "last 5"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 776,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                        lineNumber: 773,
                                        columnNumber: 13
                                    }, this),
                                    (()=>{
                                        const recentSignals = (pulse?.signals ?? []).slice(0, 5);
                                        const showEvents = recentSignals.length === 0;
                                        if (showEvents && linked.length === 0) {
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-terminal text-[11px] text-ink-3",
                                                children: "— awaiting first deployments —"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 784,
                                                columnNumber: 24
                                            }, this);
                                        }
                                        if (showEvents) {
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "space-y-1",
                                                children: linked.map((e)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            onClick: ()=>e.signalId && setOpenSignal(e.signalId),
                                                            disabled: !e.signalId,
                                                            "aria-label": `Open signal detail for ${e.symbol ?? "event"} ${e.type}`,
                                                            className: "group flex w-full items-center gap-2 rounded-md px-1.5 py-1 text-left font-terminal text-[11px] transition-colors hover:bg-[rgb(var(--neon-rgb)/0.06)] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[rgb(var(--neon-rgb)/0.5)] disabled:cursor-default disabled:hover:bg-transparent",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "shrink-0 tabular-nums text-ink-3",
                                                                    children: mounted ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtClockLocal"])(new Date(e.createdAt).getTime()) : "--:--:--"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 798,
                                                                    columnNumber: 27
                                                                }, this),
                                                                e.symbol && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "shrink-0 rounded border border-[rgba(255,78,205,0.35)] px-1 font-bold leading-5 text-magenta-neon transition-all group-hover:border-[rgb(var(--neon-rgb)/0.45)] group-hover:text-neon",
                                                                    children: e.symbol
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 800,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "min-w-0 truncate uppercase tracking-[0.1em] text-ink-2 transition-colors group-hover:text-ink",
                                                                    children: e.type
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 804,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mouse$2d$pointer$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MousePointerClick$3e$__["MousePointerClick"], {
                                                                    size: 11,
                                                                    "aria-hidden": true,
                                                                    className: "ml-auto shrink-0 text-ink-3 opacity-0 transition-all duration-200 group-hover:text-neon group-hover:opacity-100"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                    lineNumber: 805,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                            lineNumber: 791,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, e.id, false, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 790,
                                                        columnNumber: 23
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                lineNumber: 788,
                                                columnNumber: 19
                                            }, this);
                                        }
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "space-y-1",
                                            children: recentSignals.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>setOpenSignal(s.id),
                                                        "aria-label": `Open signal detail for ${s.symbol} NX-${s.serial}`,
                                                        title: "Open signal detail",
                                                        className: "group flex w-full items-center gap-2 rounded-md px-1.5 py-1 text-left font-terminal text-[11px] transition-colors hover:bg-[rgb(var(--neon-rgb)/0.06)] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[rgb(var(--neon-rgb)/0.5)]",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "shrink-0 rounded border border-[rgba(178,107,255,0.35)] px-1 font-bold leading-5 tabular-nums text-violet-neon",
                                                                children: [
                                                                    "NX-",
                                                                    String(s.serial).padStart(4, "0")
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 823,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "shrink-0 font-bold tracking-[0.08em] text-ink",
                                                                children: s.symbol.replace("USDT", "")
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 826,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 font-bold", s.direction === "LONG" ? "text-neon" : "text-magenta-neon"),
                                                                children: s.direction
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 827,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("ml-auto shrink-0 font-bold uppercase tracking-[0.1em]", s.status === "ACTIVE" ? "text-cyan-neon" : [
                                                                    "TP1",
                                                                    "TP2",
                                                                    "TP3"
                                                                ].includes(s.status) ? "text-neon" : s.status === "SL" ? "text-danger-neon" : s.status === "EXPIRED" ? "text-amber-neon" : "text-ink-3"),
                                                                children: s.status
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 828,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mouse$2d$pointer$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MousePointerClick$3e$__["MousePointerClick"], {
                                                                size: 11,
                                                                "aria-hidden": true,
                                                                className: "ml-1 shrink-0 text-ink-3 opacity-0 transition-all duration-200 group-hover:text-neon group-hover:opacity-100"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                                lineNumber: 836,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                        lineNumber: 816,
                                                        columnNumber: 23
                                                    }, this)
                                                }, s.id, false, {
                                                    fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                                    lineNumber: 815,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                            lineNumber: 813,
                                            columnNumber: 17
                                        }, this);
                                    })()
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                                lineNumber: 772,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 462,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                lineNumber: 307,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 flex items-center gap-3",
                "aria-hidden": true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "label-tech whitespace-nowrap",
                        children: "gate gauge // decision layer"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 851,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "h-px flex-1 bg-gradient-to-r from-neon/40 to-transparent"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 852,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                        tone: "violet",
                        children: "LIVE AUDIT"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 853,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                lineNumber: 850,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$GateGaugeCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 856,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$ShadowVetoCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 861,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$EntryLeversCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 867,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$GoldenLaneCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 872,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                lineNumber: 855,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 flex items-center gap-3",
                "aria-hidden": true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "label-tech whitespace-nowrap",
                        children: "sensor matrix // module bus"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 879,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "h-px flex-1 bg-gradient-to-r from-violet-neon/40 to-transparent"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 880,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$primitives$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NeonBadge"], {
                        tone: "violet",
                        children: "3 MODULES LIVE"
                    }, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 881,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                lineNumber: 878,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$FuturesRadarCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 886,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$FlowScannerCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 887,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$LiqDepthRadarCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 888,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$terminal$2f$VolRiskCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                        lineNumber: 889,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/terminal/TerminalSection.tsx",
                lineNumber: 883,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/terminal/TerminalSection.tsx",
        lineNumber: 299,
        columnNumber: 5
    }, this);
}
_s(TerminalSection, "RqQeLrFKstnMGwSOLbWjMFKtxV4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMounted"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUi"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNow"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeviceNow"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = TerminalSection;
var _c;
__turbopack_context__.k.register(_c, "TerminalSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_terminal_b2f21ae8._.js.map