(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_3846b34a._.css",
  "static/chunks/src_921a65ac._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_@tanstack_query-core_build_modern_1505144a._.js",
  "static/chunks/node_modules_motion-dom_dist_es_b195f008._.js",
  "static/chunks/node_modules_framer-motion_dist_es_afea34c2._.js",
  "static/chunks/node_modules_df8046fc._.js"
],
    source: "dynamic"
});
