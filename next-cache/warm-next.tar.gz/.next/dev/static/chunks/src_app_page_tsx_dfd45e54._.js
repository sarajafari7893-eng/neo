(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_fx_f28cb0f1._.js",
  "static/chunks/src_components_layout_c7fbc0e7._.js",
  "static/chunks/src_components_dashboard_c4e99f95._.js",
  "static/chunks/src_components_terminal_b2f21ae8._.js",
  "static/chunks/src_components_signals_c4fb4ade._.js",
  "static/chunks/src_components_analytics_5fb638c1._.js",
  "static/chunks/src_components_ai_0e19b248._.js",
  "static/chunks/src_components_afc637b6._.js",
  "static/chunks/src_2c331d74._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_b8fd4afc._.js",
  "static/chunks/node_modules_lodash_05b2184c._.js",
  "static/chunks/node_modules_recharts_es6_93c935d9._.js",
  "static/chunks/node_modules_@radix-ui_984b338f._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_1cf5b35e._.js"
],
    source: "dynamic"
});
