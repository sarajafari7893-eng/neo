(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/fx/BackgroundFX.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackgroundFX",
    ()=>BackgroundFX
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function BackgroundFX() {
    _s();
    const particles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BackgroundFX.useMemo[particles]": ()=>{
            const arr = [];
            const colors = [
                "#00ffa3",
                "#b26bff",
                "#ff4ecd",
                "#45f0df",
                "#ffb347"
            ];
            // deterministic pseudo-random (stable across SSR/CSR)
            let seed = 42;
            const rnd = {
                "BackgroundFX.useMemo[particles].rnd": ()=>{
                    seed = seed * 16807 % 2147483647;
                    return (seed - 1) / 2147483646;
                }
            }["BackgroundFX.useMemo[particles].rnd"];
            for(let i = 0; i < 26; i++){
                arr.push({
                    x: rnd() * 100,
                    y: rnd() * 100,
                    s: 1 + rnd() * 2.2,
                    d: 5 + rnd() * 9,
                    delay: rnd() * 8,
                    c: colors[Math.floor(rnd() * colors.length)]
                });
            }
            return arr;
        }
    }["BackgroundFX.useMemo[particles]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "aria-hidden": true,
        className: "pointer-events-none fixed inset-0 z-0 overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-[radial-gradient(ellipse_120%_80%_at_50%_-10%,rgb(var(--neon-rgb)/0.07),transparent_55%),radial-gradient(ellipse_80%_60%_at_100%_100%,rgba(178,107,255,0.06),transparent_60%)]"
            }, void 0, false, {
                fileName: "[project]/src/components/fx/BackgroundFX.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 grid-bg opacity-60 [mask-image:radial-gradient(ellipse_75%_65%_at_50%_40%,black,transparent)]"
            }, void 0, false, {
                fileName: "[project]/src/components/fx/BackgroundFX.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute -top-32 -left-32 h-[34rem] w-[34rem] rounded-full bg-[radial-gradient(circle,rgb(var(--neon-rgb)/0.13),transparent_65%)] blur-3xl anim-drift"
            }, void 0, false, {
                fileName: "[project]/src/components/fx/BackgroundFX.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-1/3 -right-40 h-[38rem] w-[38rem] rounded-full bg-[radial-gradient(circle,rgba(178,107,255,0.11),transparent_65%)] blur-3xl anim-drift",
                style: {
                    animationDelay: "-6s"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/fx/BackgroundFX.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute bottom-0 left-1/4 h-[30rem] w-[30rem] rounded-full bg-[radial-gradient(circle,rgba(255,78,205,0.08),transparent_65%)] blur-3xl anim-drift",
                style: {
                    animationDelay: "-12s"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/fx/BackgroundFX.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            particles.map((p, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "absolute rounded-full anim-float",
                    style: {
                        left: `${p.x}%`,
                        top: `${p.y}%`,
                        width: p.s,
                        height: p.s,
                        background: p.c,
                        opacity: 0.35,
                        boxShadow: `0 0 ${p.s * 4}px ${p.c}`,
                        animationDuration: `${p.d}s`,
                        animationDelay: `-${p.delay}s`
                    }
                }, i, false, {
                    fileName: "[project]/src/components/fx/BackgroundFX.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute left-0 h-px w-full bg-gradient-to-r from-transparent via-[rgb(var(--neon-rgb)/0.5)] to-transparent",
                style: {
                    animation: "scanline-sweep 9s linear infinite"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/fx/BackgroundFX.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#05070a] to-transparent"
            }, void 0, false, {
                fileName: "[project]/src/components/fx/BackgroundFX.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/fx/BackgroundFX.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(BackgroundFX, "4A8/E2ZKMQMOCuaGnTg4x6kwo4w=");
_c = BackgroundFX;
var _c;
__turbopack_context__.k.register(_c, "BackgroundFX");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/fx/CommandPalette.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CommandPalette",
    ()=>CommandPalette
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$dashboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutDashboard$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layout-dashboard.js [app-client] (ecmascript) <export default as LayoutDashboard>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/radar.js [app-client] (ecmascript) <export default as Radar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LineChart$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-line.js [app-client] (ecmascript) <export default as LineChart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$terminal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TerminalSquare$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/square-terminal.js [app-client] (ecmascript) <export default as TerminalSquare>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/zap.js [app-client] (ecmascript) <export default as Zap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scan$2d$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ScanLine$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/scan-line.js [app-client] (ecmascript) <export default as ScanLine>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$command$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/command.js [app-client] (ecmascript) <export default as Command>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calculator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calculator$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calculator.js [app-client] (ecmascript) <export default as Calculator>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ImageDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/image-down.js [app-client] (ecmascript) <export default as ImageDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$spreadsheet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileSpreadsheet$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/file-spreadsheet.js [app-client] (ecmascript) <export default as FileSpreadsheet>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BellOff$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell-off.js [app-client] (ecmascript) <export default as BellOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell.js [app-client] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/volume-2.js [app-client] (ecmascript) <export default as Volume2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__VolumeX$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/volume-x.js [app-client] (ecmascript) <export default as VolumeX>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Keyboard$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/keyboard.js [app-client] (ecmascript) <export default as Keyboard>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$palette$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Palette$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/palette.js [app-client] (ecmascript) <export default as Palette>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$telescope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Telescope$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/telescope.js [app-client] (ecmascript) <export default as Telescope>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/notebook-pen.js [app-client] (ecmascript) <export default as NotebookPen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scroll$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ScrollText$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/scroll-text.js [app-client] (ecmascript) <export default as ScrollText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$copy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Copy$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/copy.js [app-client] (ecmascript) <export default as Copy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rows$2d$3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Rows3$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/rows-3.js [app-client] (ecmascript) <export default as Rows3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/command.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/ui.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/alerts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/usePulse.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sounds.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accent.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/brand.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const NAV_ITEMS = [
    {
        id: "dashboard",
        label: "Go to Dashboard",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$dashboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutDashboard$3e$__["LayoutDashboard"],
        shortcut: "1"
    },
    {
        id: "signals",
        label: "Go to Signal Matrix",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radar$3e$__["Radar"],
        shortcut: "2"
    },
    {
        id: "analytics",
        label: "Go to Performance Intel",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LineChart$3e$__["LineChart"],
        shortcut: "3"
    },
    {
        id: "terminal",
        label: "Go to Engine Terminal",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$terminal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TerminalSquare$3e$__["TerminalSquare"],
        shortcut: "4"
    },
    {
        id: "ai",
        label: "Go to AI Core",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"],
        shortcut: "5"
    }
];
function CommandPalette() {
    _s();
    const { paletteOpen, setPaletteOpen, setView, setActiveSymbol, setCalcOpen, setShortcutsOpen, setSpotlightSymbol, requestAnalyticsExport, requestAnalyticsCsv, requestOperatorLog } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUi"])();
    const alertsMuted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "CommandPalette.useAlerts[alertsMuted]": (s)=>s.alertsMuted
    }["CommandPalette.useAlerts[alertsMuted]"]);
    const setAlertsMuted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "CommandPalette.useAlerts[setAlertsMuted]": (s)=>s.setAlertsMuted
    }["CommandPalette.useAlerts[setAlertsMuted]"]);
    const soundEnabled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "CommandPalette.useAlerts[soundEnabled]": (s)=>s.soundEnabled
    }["CommandPalette.useAlerts[soundEnabled]"]);
    const setSoundEnabled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "CommandPalette.useAlerts[setSoundEnabled]": (s)=>s.setSoundEnabled
    }["CommandPalette.useAlerts[setSoundEnabled]"]);
    const accent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "CommandPalette.useAlerts[accent]": (s)=>s.accent
    }["CommandPalette.useAlerts[accent]"]);
    const setAccent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "CommandPalette.useAlerts[setAccent]": (s)=>s.setAccent
    }["CommandPalette.useAlerts[setAccent]"]);
    const viewMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "CommandPalette.useAlerts[viewMode]": (s)=>s.viewMode
    }["CommandPalette.useAlerts[viewMode]"]);
    const setViewMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "CommandPalette.useAlerts[setViewMode]": (s)=>s.setViewMode
    }["CommandPalette.useAlerts[setViewMode]"]);
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    /* journal-digest preview dialog (replaces blind clipboard copy) */ const [digest, setDigest] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [digestCopied, setDigestCopied] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // global hotkeys: ⌘K palette, 1-5 views, ? keymap, / search,
    // C calculator, M mute, S sounds, A accent cycle
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CommandPalette.useEffect": ()=>{
            const down = {
                "CommandPalette.useEffect.down": (e)=>{
                    if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
                        e.preventDefault();
                        setPaletteOpen(!paletteOpen);
                        return;
                    }
                    if (paletteOpen || e.metaKey || e.ctrlKey || e.altKey) return;
                    const target = e.target;
                    const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable);
                    if (typing) return;
                    if ([
                        "1",
                        "2",
                        "3",
                        "4",
                        "5"
                    ].includes(e.key)) {
                        const item = NAV_ITEMS.find({
                            "CommandPalette.useEffect.down.item": (n)=>n.shortcut === e.key
                        }["CommandPalette.useEffect.down.item"]);
                        if (item) setView(item.id);
                        return;
                    }
                    switch(e.key){
                        case "?":
                            e.preventDefault();
                            setShortcutsOpen(true);
                            break;
                        case "/":
                            e.preventDefault();
                            setView("signals");
                            requestAnimationFrame({
                                "CommandPalette.useEffect.down": ()=>{
                                    const input = document.querySelector('input[aria-label="Search signals"]');
                                    input?.focus();
                                }
                            }["CommandPalette.useEffect.down"]);
                            break;
                        case "c":
                        case "C":
                            setView("signals");
                            setCalcOpen(true);
                            break;
                        case "m":
                        case "M":
                            setAlertsMuted(!alertsMuted);
                            break;
                        case "s":
                        case "S":
                            setSoundEnabled(!soundEnabled);
                            break;
                        case "a":
                        case "A":
                            setAccent((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nextAccent"])(accent));
                            break;
                        default:
                            break;
                    }
                }
            }["CommandPalette.useEffect.down"];
            document.addEventListener("keydown", down);
            return ({
                "CommandPalette.useEffect": ()=>document.removeEventListener("keydown", down)
            })["CommandPalette.useEffect"];
        }
    }["CommandPalette.useEffect"], [
        paletteOpen,
        setPaletteOpen,
        setView,
        setShortcutsOpen,
        setCalcOpen,
        alertsMuted,
        setAlertsMuted,
        soundEnabled,
        setSoundEnabled,
        accent,
        setAccent
    ]);
    /* v6.0 TOTAL AUTONOMY: the manual "deploy new AI signal" command was REMOVED —
     deployment is 100% autonomous via the trigger-bus → governor-gated engine
     (POST /api/signals returns 423 by design; zero manual deployment modes). */ function scanSymbol(symbol) {
        setActiveSymbol(symbol);
        setView("ai");
        setPaletteOpen(false);
    }
    /* build (not copy) a terminal-style digest of every journaled deployment;
     the preview dialog offers an explicit COPY affordance */ const { data: pulseForDigest } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"])(15000);
    function openJournalDigest() {
        setPaletteOpen(false);
        const built = buildJournalDigest(pulseForDigest?.signals ?? []);
        if (!built) {
            toast({
                title: "JOURNAL EMPTY",
                description: "No operator notes yet — write one from any signal detail dialog."
            });
            return;
        }
        setDigestCopied(false);
        setDigest(built);
    }
    async function copyDigest() {
        if (!digest) return;
        try {
            await navigator.clipboard.writeText(digest.text);
            setDigestCopied(true);
            setTimeout(()=>setDigestCopied(false), 1600);
            toast({
                title: "JOURNAL DIGEST COPIED",
                description: `${digest.count} entr${digest.count === 1 ? "y" : "ies"} on the clipboard — paste into your log.`
            });
        } catch  {
            toast({
                title: "COPY BLOCKED",
                description: "Clipboard access denied by the browser.",
                variant: "destructive"
            });
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandDialog"], {
                open: paletteOpen,
                onOpenChange: setPaletteOpen,
                className: "border-[rgb(var(--neon-rgb)/0.25)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 border-b border-white/5 px-4 pt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$command$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__["Command"], {
                                size: 14,
                                className: "text-neon",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 199,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "label-tech",
                                children: "FLOWRADAR COMMAND"
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 200,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "ml-auto font-terminal text-[9px] tracking-[0.18em] text-ink-3",
                                children: "ESC TO CLOSE"
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 201,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                        lineNumber: 198,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandInput"], {
                        placeholder: "Type a command or search symbols…",
                        className: "font-terminal"
                    }, void 0, false, {
                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                        lineNumber: 203,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandList"], {
                        className: "font-terminal",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandEmpty"], {
                                children: "NO MATCHING COMMAND."
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 205,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandGroup"], {
                                heading: "NAVIGATE",
                                children: NAV_ITEMS.map((item)=>{
                                    const Icon = item.icon;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: `${item.label} ${item.id}`,
                                        onSelect: ()=>{
                                            setView(item.id);
                                            setPaletteOpen(false);
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgb(var(--neon-rgb)/0.08)] data-[selected=true]:text-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 220,
                                                columnNumber: 17
                                            }, this),
                                            item.label,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandShortcut"], {
                                                className: "text-ink-3",
                                                children: item.shortcut
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 222,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, item.id, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 211,
                                        columnNumber: 15
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 207,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandSeparator"], {}, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 228,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandGroup"], {
                                heading: "ENGINE",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "autonomous deployment status ai core",
                                        onSelect: ()=>{
                                            setView("ai");
                                            setPaletteOpen(false);
                                        },
                                        className: "gap-2.5 text-violet-neon data-[selected=true]:bg-[rgba(178,107,255,0.1)]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__["Zap"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 239,
                                                columnNumber: 13
                                            }, this),
                                            "Autonomous deployment — AI core (no manual deploy)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 231,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "open risk calculator position sizing",
                                        onSelect: ()=>{
                                            setView("signals");
                                            setCalcOpen(true);
                                            setPaletteOpen(false);
                                        },
                                        className: "gap-2.5 text-amber-neon data-[selected=true]:bg-[rgba(255,179,71,0.1)]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calculator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calculator$3e$__["Calculator"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 251,
                                                columnNumber: 13
                                            }, this),
                                            "Open risk calculator"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 242,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "toggle event alert notifications mute",
                                        onSelect: ()=>{
                                            setAlertsMuted(!alertsMuted);
                                            setPaletteOpen(false);
                                            toast({
                                                title: alertsMuted ? "ALERTS LIVE" : "ALERTS MUTED",
                                                description: alertsMuted ? "Live signal events will pop as toasts again." : "Live event toasts silenced — inbox keeps tracking."
                                            });
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgba(69,240,223,0.08)] data-[selected=true]:text-cyan-neon",
                                        children: [
                                            alertsMuted ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BellOff$3e$__["BellOff"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 268,
                                                columnNumber: 28
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 268,
                                                columnNumber: 52
                                            }, this),
                                            alertsMuted ? "Unmute event alerts" : "Mute event alerts"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 254,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "toggle event sounds audio blips",
                                        onSelect: ()=>{
                                            const next = !soundEnabled;
                                            setSoundEnabled(next);
                                            if (next) {
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["primeAudio"])();
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["playConfirmChirp"])();
                                            }
                                            setPaletteOpen(false);
                                            toast({
                                                title: next ? "EVENT SOUNDS ON" : "EVENT SOUNDS OFF",
                                                description: next ? "Synth blips armed — TP hits chirp, stop-outs buzz." : "Audio disabled — silent terminal mode."
                                            });
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgba(69,240,223,0.08)] data-[selected=true]:text-cyan-neon",
                                        children: [
                                            soundEnabled ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 290,
                                                columnNumber: 29
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__VolumeX$3e$__["VolumeX"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 290,
                                                columnNumber: 53
                                            }, this),
                                            soundEnabled ? "Disable event sounds" : "Enable event sounds"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 271,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "open operator log journal analytics notebook",
                                        onSelect: ()=>{
                                            setView("analytics");
                                            requestOperatorLog();
                                            setPaletteOpen(false);
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgba(69,240,223,0.08)] data-[selected=true]:text-cyan-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__["NotebookPen"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 302,
                                                columnNumber: 13
                                            }, this),
                                            "Open operator log"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 293,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "journal digest operator notes clipboard preview log",
                                        onSelect: ()=>{
                                            openJournalDigest();
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgba(69,240,223,0.08)] data-[selected=true]:text-cyan-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scroll$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ScrollText$3e$__["ScrollText"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 312,
                                                columnNumber: 13
                                            }, this),
                                            "Open journal digest preview"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 305,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "toggle signal matrix view grid table layout density",
                                        onSelect: ()=>{
                                            const next = viewMode === "GRID" ? "TABLE" : "GRID";
                                            setViewMode(next);
                                            setView("signals");
                                            setPaletteOpen(false);
                                            toast({
                                                title: `MATRIX → ${next}`,
                                                description: next === "TABLE" ? "Dense terminal rows — scan mode." : "Signal cards — full detail mode."
                                            });
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgb(var(--neon-rgb)/0.08)] data-[selected=true]:text-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rows$2d$3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Rows3$3e$__["Rows3"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 329,
                                                columnNumber: 13
                                            }, this),
                                            "Toggle matrix grid / table",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandShortcut"], {
                                                className: "text-ink-3",
                                                children: viewMode
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 331,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 315,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "export analytics performance intel png image snapshot",
                                        onSelect: ()=>{
                                            setView("analytics");
                                            requestAnalyticsExport();
                                            setPaletteOpen(false);
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgb(var(--neon-rgb)/0.08)] data-[selected=true]:text-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ImageDown$3e$__["ImageDown"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 342,
                                                columnNumber: 13
                                            }, this),
                                            "Export analytics PNG"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 333,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "export analytics performance intel csv spreadsheet data",
                                        onSelect: ()=>{
                                            setView("analytics");
                                            requestAnalyticsCsv();
                                            setPaletteOpen(false);
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgba(69,240,223,0.08)] data-[selected=true]:text-cyan-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$spreadsheet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileSpreadsheet$3e$__["FileSpreadsheet"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 354,
                                                columnNumber: 13
                                            }, this),
                                            "Export analytics CSV"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 345,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "open keyboard shortcuts keymap help",
                                        onSelect: ()=>{
                                            setPaletteOpen(false);
                                            setShortcutsOpen(true);
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgb(var(--neon-rgb)/0.08)] data-[selected=true]:text-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Keyboard$3e$__["Keyboard"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 365,
                                                columnNumber: 13
                                            }, this),
                                            "Keyboard shortcuts",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandShortcut"], {
                                                className: "text-ink-3",
                                                children: "?"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 367,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 357,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                        value: "cycle accent color identity theme",
                                        onSelect: ()=>{
                                            const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nextAccent"])(accent);
                                            setAccent(next);
                                            setPaletteOpen(false);
                                            toast({
                                                title: `ACCENT → ${next.toUpperCase()}`,
                                                description: "Terminal identity re-tuned."
                                            });
                                        },
                                        className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgb(var(--neon-rgb)/0.08)] data-[selected=true]:text-neon",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$palette$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Palette$3e$__["Palette"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 379,
                                                columnNumber: 13
                                            }, this),
                                            "Cycle accent identity",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandShortcut"], {
                                                className: "text-ink-3",
                                                children: "A"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                                lineNumber: 381,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                        lineNumber: 369,
                                        columnNumber: 11
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 230,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandSeparator"], {}, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 385,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TopMoverSpotlight, {
                                onSpot: (sym)=>{
                                    setSpotlightSymbol(sym);
                                    setPaletteOpen(false);
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 387,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SymbolScanGroup, {
                                onScan: scanSymbol
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 389,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandSeparator"], {}, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 391,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AccentGroup, {
                                accent: accent,
                                onPick: (id)=>{
                                    setAccent(id);
                                    setPaletteOpen(false);
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                lineNumber: 393,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                        lineNumber: 204,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                lineNumber: 193,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DigestPreviewDialog, {
                digest: digest,
                onOpenChange: (v)=>{
                    if (!v) setDigest(null);
                },
                copied: digestCopied,
                onCopy: ()=>void copyDigest()
            }, void 0, false, {
                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                lineNumber: 396,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true);
}
_s(CommandPalette, "WtcgpxUf7PFfzYum79dcUsRPpCE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUi"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"]
    ];
});
_c = CommandPalette;
/** pure digest builder — ASCII-only (clipboard-safe), newest entries first */ function buildJournalDigest(signals) {
    const journaled = signals.filter((s)=>(s.operatorNotes ?? "").trim().length > 0).sort((a, b)=>(b.notesUpdatedAt ?? "").localeCompare(a.notesUpdatedAt ?? ""));
    if (journaled.length === 0) return null;
    const lines = [
        `< ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].head}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].sep}${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$brand$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_TERMINAL"].tail} - OPERATOR JOURNAL DIGEST >`,
        `${journaled.length} ENTRIES - ${new Date().toISOString().slice(0, 16).replace("T", " ")}Z`,
        "-".repeat(44)
    ];
    for (const s of journaled){
        const meta = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STATUS_META"][s.status] ?? {
            label: s.status
        };
        const note = s.operatorNotes.trim().replace(/\s+/g, " ");
        lines.push(`> ${s.symbol} ${s.direction} | ${meta.label} | ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtPct"])(s.pnlPercent)} @ ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fmtPrice"])(s.entryPrice)}`, `  ${note.slice(0, 180)}${note.length > 180 ? "..." : ""}`);
    }
    return {
        text: lines.join("\n"),
        count: journaled.length
    };
}
/** digest preview dialog — read before you copy (terminal render + counts) */ function DigestPreviewDialog({ digest, onOpenChange, copied, onCopy }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: digest !== null,
        onOpenChange: onOpenChange,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "max-h-[92vh] gap-0 overflow-hidden rounded-xl border-[rgba(69,240,223,0.25)] bg-[rgba(7,11,14,0.97)] p-0 backdrop-blur-2xl sm:max-w-xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                    className: "sr-only",
                    children: "Preview of the operator journal digest before copying it to the clipboard."
                }, void 0, false, {
                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                    lineNumber: 445,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-5 sm:p-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scroll$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ScrollText$3e$__["ScrollText"], {
                                    className: "h-4 w-4 text-cyan-neon",
                                    "aria-hidden": true
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                    lineNumber: 450,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                    className: "font-terminal text-sm font-bold uppercase tracking-[0.18em] text-ink",
                                    children: "JOURNAL DIGEST"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                    lineNumber: 451,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "ml-auto font-terminal text-[9px] tabular-nums tracking-[0.14em] text-ink-3",
                                    children: [
                                        digest?.count ?? 0,
                                        " ",
                                        (digest?.count ?? 0) === 1 ? "ENTRY" : "ENTRIES",
                                        " · ",
                                        digest?.text.length ?? 0,
                                        " CHARS"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                    lineNumber: 454,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 449,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                            className: "mt-4 max-h-[46vh] overflow-auto whitespace-pre-wrap break-words rounded-lg border border-white/8 bg-[rgba(5,8,10,0.75)] p-3.5 font-terminal text-[11px] leading-relaxed text-ink-2 scrollbar-thin",
                            "aria-label": "Journal digest plaintext preview",
                            children: digest?.text ?? ""
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 458,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-2 font-terminal text-[9px] tracking-[0.12em] text-ink-3",
                            children: "NEWEST FIRST · TRIMMED TO 180 CHARS PER NOTE · PASTE INTO ANY LOG"
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 464,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                    lineNumber: 448,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-end gap-2 border-t border-[rgba(69,240,223,0.12)] bg-[rgba(5,8,10,0.6)] p-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            type: "button",
                            variant: "outline",
                            onClick: ()=>onOpenChange(false),
                            className: "h-11 border-white/10 bg-transparent font-terminal text-[11px] tracking-[0.16em] text-ink-2 hover:bg-white/5",
                            children: "CLOSE"
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 469,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            type: "button",
                            onClick: onCopy,
                            className: "h-11 min-w-[130px] border border-[rgba(69,240,223,0.4)] bg-[rgba(69,240,223,0.12)] font-terminal text-[11px] font-bold tracking-[0.2em] text-cyan-neon hover:bg-[rgba(69,240,223,0.22)]",
                            children: [
                                copied ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                    className: "h-4 w-4",
                                    strokeWidth: 2.5
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                    lineNumber: 482,
                                    columnNumber: 23
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$copy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Copy$3e$__["Copy"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                                    lineNumber: 482,
                                    columnNumber: 73
                                }, this),
                                copied ? "COPIED" : "COPY"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 477,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                    lineNumber: 468,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/fx/CommandPalette.tsx",
            lineNumber: 444,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/fx/CommandPalette.tsx",
        lineNumber: 443,
        columnNumber: 5
    }, this);
}
_c1 = DigestPreviewDialog;
/* one-click spotlight on the current #1 volatility mover */ function TopMoverSpotlight({ onSpot }) {
    _s1();
    const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"])(15000);
    const top = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TopMoverSpotlight.useMemo[top]": ()=>{
            const m = [
                ...data?.market ?? []
            ].sort({
                "TopMoverSpotlight.useMemo[top].m": (a, b)=>Math.abs(b.change24h) - Math.abs(a.change24h)
            }["TopMoverSpotlight.useMemo[top].m"]);
            return m[0];
        }
    }["TopMoverSpotlight.useMemo[top]"], [
        data?.market
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandGroup"], {
        heading: "SPOTLIGHT",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
            value: "symbol spotlight top mover market drilldown",
            onSelect: ()=>top && onSpot(top.symbol),
            className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgb(var(--neon-rgb)/0.08)] data-[selected=true]:text-neon",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$telescope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Telescope$3e$__["Telescope"], {
                    size: 14
                }, void 0, false, {
                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                    lineNumber: 505,
                    columnNumber: 9
                }, this),
                "Spotlight top mover",
                top && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "ml-auto font-terminal text-[10px] font-bold tracking-[0.12em] text-ink-3",
                    children: [
                        top.symbol,
                        " · ",
                        top.change24h >= 0 ? "+" : "",
                        top.change24h.toFixed(1),
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                    lineNumber: 508,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/fx/CommandPalette.tsx",
            lineNumber: 500,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/fx/CommandPalette.tsx",
        lineNumber: 499,
        columnNumber: 5
    }, this);
}
_s1(TopMoverSpotlight, "0MDUVYUXkPYCfF3i1zQTszZiXNc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"]
    ];
});
_c2 = TopMoverSpotlight;
/* accent identity picker — live preview chips */ function AccentGroup({ accent, onPick }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandGroup"], {
        heading: "IDENTITY / ACCENT",
        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ACCENT_ORDER"].map((id)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                value: `accent ${id}`,
                onSelect: ()=>onPick(id),
                className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgb(var(--neon-rgb)/0.08)] data-[selected=true]:text-neon",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": true,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-block h-3 w-3 shrink-0 rounded-full border", id === accent ? "border-white/60" : "border-black/50"),
                        style: {
                            background: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ACCENTS"][id].hex,
                            boxShadow: id === accent ? `0 0 10px ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ACCENTS"][id].hex}` : undefined
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                        lineNumber: 528,
                        columnNumber: 11
                    }, this),
                    id.charAt(0).toUpperCase() + id.slice(1),
                    " accent",
                    id === accent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-auto font-terminal text-[9px] tracking-[0.18em] text-neon",
                        children: "ACTIVE"
                    }, void 0, false, {
                        fileName: "[project]/src/components/fx/CommandPalette.tsx",
                        lineNumber: 540,
                        columnNumber: 29
                    }, this)
                ]
            }, id, true, {
                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                lineNumber: 522,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/fx/CommandPalette.tsx",
        lineNumber: 520,
        columnNumber: 5
    }, this);
}
_c3 = AccentGroup;
/* symbols group pulled from pulse cache (no extra fetch) */ function SymbolScanGroup({ onScan }) {
    _s2();
    const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"])(15000);
    const symbols = data?.market ?? [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandGroup"], {
        heading: "AI SYMBOL SCAN",
        children: [
            symbols.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-3 py-2 text-xs text-ink-3",
                children: "loading markets…"
            }, void 0, false, {
                fileName: "[project]/src/components/fx/CommandPalette.tsx",
                lineNumber: 554,
                columnNumber: 9
            }, this),
            symbols.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                    value: `scan ${m.symbol} ${m.name}`,
                    onSelect: ()=>onScan(m.symbol),
                    className: "gap-2.5 text-ink-2 data-[selected=true]:bg-[rgba(69,240,223,0.08)] data-[selected=true]:text-cyan-neon",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scan$2d$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ScanLine$3e$__["ScanLine"], {
                            size: 14
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 563,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-semibold",
                            children: m.symbol
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 564,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs text-ink-3",
                            children: m.name
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 565,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "ml-auto text-[10px] text-ink-3 tabular-nums",
                            children: m.price >= 1000 ? m.price.toFixed(0) : m.price.toFixed(m.price >= 1 ? 2 : 4)
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/CommandPalette.tsx",
                            lineNumber: 566,
                            columnNumber: 11
                        }, this)
                    ]
                }, m.symbol, true, {
                    fileName: "[project]/src/components/fx/CommandPalette.tsx",
                    lineNumber: 557,
                    columnNumber: 9
                }, this))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/fx/CommandPalette.tsx",
        lineNumber: 552,
        columnNumber: 5
    }, this);
}
_s2(SymbolScanGroup, "kG13Ansk5XT50i1noSZ6LvLk5FQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"]
    ];
});
_c4 = SymbolScanGroup;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "CommandPalette");
__turbopack_context__.k.register(_c1, "DigestPreviewDialog");
__turbopack_context__.k.register(_c2, "TopMoverSpotlight");
__turbopack_context__.k.register(_c3, "AccentGroup");
__turbopack_context__.k.register(_c4, "SymbolScanGroup");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/fx/EventAlerts.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventAlerts",
    ()=>EventAlerts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/usePulse.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/alerts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sounds.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2d$ring$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BellRing$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell-ring.js [app-client] (ecmascript) <export default as BellRing>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check.js [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$history$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/history.js [app-client] (ecmascript) <export default as History>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rocket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Rocket$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/rocket.js [app-client] (ecmascript) <export default as Rocket>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield-check.js [app-client] (ecmascript) <export default as ShieldCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$timer$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TimerOff$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/timer-off.js [app-client] (ecmascript) <export default as TimerOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [app-client] (ecmascript) <export default as XCircle>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
/**
 * Headless bridge: watches the pulse feed and raises a styled sonner toast
 * for every NEW engine event (signal created, TP hit, SL, TTL expiry).
 * Mounted once in the app shell — renders nothing.
 */ const LEVEL_STYLE = {
    CREATED: {
        border: "rgba(178,107,255,0.55)",
        bg: "rgba(178,107,255,0.10)",
        text: "#b26bff",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rocket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Rocket$3e$__["Rocket"]
    },
    TP1: {
        border: "rgb(var(--neon-rgb)/0.55)",
        bg: "rgb(var(--neon-rgb)/0.10)",
        text: "var(--neon)",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"]
    },
    TP2: {
        border: "rgb(var(--neon-rgb)/0.55)",
        bg: "rgb(var(--neon-rgb)/0.10)",
        text: "var(--neon)",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"]
    },
    TP3: {
        border: "rgba(69,240,223,0.6)",
        bg: "rgba(69,240,223,0.10)",
        text: "#45f0df",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"]
    },
    SL: {
        border: "rgba(255,77,94,0.55)",
        bg: "rgba(255,77,94,0.10)",
        text: "#ff4d5e",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"]
    },
    TTL_EXPIRED: {
        border: "rgba(255,179,71,0.55)",
        bg: "rgba(255,179,71,0.10)",
        text: "#ffb347",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$timer$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TimerOff$3e$__["TimerOff"]
    },
    // v6.1.1: dynamic expiry gate GRANTS now alert the operator (were silent ENGINE events)
    TTL_EXTENDED: {
        border: "rgba(69,240,223,0.55)",
        bg: "rgba(69,240,223,0.10)",
        text: "#45f0df",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$history$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__["History"]
    },
    // v6.5: mid-ladder breakeven arm is operator-visible (perf-forensics fix — round-trip stops)
    BE_TRAIL: {
        border: "rgba(69,240,223,0.5)",
        bg: "rgba(69,240,223,0.08)",
        text: "#45f0df",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"]
    },
    // v6.1: post-expiry follow-up reports now alert the operator too (previously bell-inbox only)
    AFTERLIFE: {
        border: "rgba(69,240,223,0.5)",
        bg: "rgba(69,240,223,0.08)",
        text: "#45f0df",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2d$ring$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BellRing$3e$__["BellRing"]
    }
};
const ALERTABLE = new Set(Object.keys(LEVEL_STYLE));
function EventAlerts() {
    _s();
    const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"])(5000);
    const baselineRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EventAlerts.useEffect": ()=>{
            if (!data?.events?.length) return;
            const events = data.events;
            const newest = Math.max(...events.map({
                "EventAlerts.useEffect.newest": (e)=>new Date(e.createdAt).getTime()
            }["EventAlerts.useEffect.newest"]));
            // first load → just set baseline, no toast storm
            if (baselineRef.current === null) {
                baselineRef.current = newest;
                return;
            }
            const fresh = events.filter({
                "EventAlerts.useEffect.fresh": (e)=>ALERTABLE.has(e.type) && new Date(e.createdAt).getTime() > baselineRef.current
            }["EventAlerts.useEffect.fresh"]).sort({
                "EventAlerts.useEffect.fresh": (a, b)=>a.createdAt.localeCompare(b.createdAt)
            }["EventAlerts.useEffect.fresh"]);
            if (baselineRef.current !== newest) baselineRef.current = newest;
            if (fresh.length === 0) return;
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"].getState();
            const playSound = !state.alertsMuted && state.soundEnabled;
            // cap burst to 3 most recent per tick
            for (const ev of fresh.slice(-3)){
                const style = LEVEL_STYLE[ev.type];
                if (!style) continue;
                if (playSound) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["playEventSound"])(ev.type);
                if (state.alertsMuted) continue;
                const { Icon } = style;
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].custom({
                    "EventAlerts.useEffect": ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            "aria-label": `Alert: ${ev.message}`,
                            onClick: {
                                "EventAlerts.useEffect": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].dismiss()
                            }["EventAlerts.useEffect"],
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("pointer-events-auto flex w-[min(92vw,380px)] cursor-pointer items-start gap-3 rounded-xl border px-3.5 py-3 text-left backdrop-blur-xl", "shadow-[0_8px_32px_-8px_rgba(0,0,0,0.85)] transition-transform hover:scale-[1.015]"),
                            style: {
                                borderColor: style.border,
                                background: `linear-gradient(135deg, ${style.bg}, rgba(7,11,14,0.96) 55%)`
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border",
                                    style: {
                                        borderColor: style.border,
                                        color: style.text,
                                        background: style.bg
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                        size: 14
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/fx/EventAlerts.tsx",
                                        lineNumber: 86,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/EventAlerts.tsx",
                                    lineNumber: 82,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "min-w-0 flex-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-terminal text-[10px] font-bold uppercase tracking-[0.2em]",
                                                    style: {
                                                        color: style.text
                                                    },
                                                    children: ev.type === "CREATED" ? "NEW SIGNAL" : ev.type === "TTL_EXPIRED" ? "TTL EXPIRED" : ev.type === "TTL_EXTENDED" ? "EXPIRY GATE — TTL EXTENDED" : ev.type === "BE_TRAIL" ? "BREAKEVEN ARMED — RISK OFF" : ev.type === "AFTERLIFE" ? "EXPIRY FOLLOW-UP" : ev.type
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/fx/EventAlerts.tsx",
                                                    lineNumber: 90,
                                                    columnNumber: 17
                                                }, this),
                                                ev.symbol && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "rounded border border-white/10 bg-white/[0.04] px-1.5 py-px font-terminal text-[9px] font-bold tracking-[0.14em] text-ink",
                                                    children: ev.symbol
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/fx/EventAlerts.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/fx/EventAlerts.tsx",
                                            lineNumber: 89,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mt-1 line-clamp-2 block text-[11px] leading-snug text-ink-2",
                                            children: ev.message
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/fx/EventAlerts.tsx",
                                            lineNumber: 102,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/fx/EventAlerts.tsx",
                                    lineNumber: 88,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "anim-pulse-dot mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full",
                                    style: {
                                        background: style.text
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/EventAlerts.tsx",
                                    lineNumber: 104,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/fx/EventAlerts.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this)
                }["EventAlerts.useEffect"], {
                    duration: 5600
                });
            }
        }
    }["EventAlerts.useEffect"], [
        data
    ]);
    return null;
}
_s(EventAlerts, "bxGW+XilTp7GE9jIceGH/Pz26Io=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"]
    ];
});
_c = EventAlerts;
var _c;
__turbopack_context__.k.register(_c, "EventAlerts");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/fx/TtlSentinel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TtlSentinel",
    ()=>TtlSentinel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$alarm$2d$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlarmClock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/alarm-clock.js [app-client] (ecmascript) <export default as AlarmClock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hourglass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Hourglass$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/hourglass.js [app-client] (ecmascript) <export default as Hourglass>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/usePulse.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/alerts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sounds.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/format.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
/**
 * TtlSentinel — headless bridge that watches open positions and escalates
 * through TWO TTL tiers:
 *
 *   ⏳ WARN   @ T-5min  → calm amber toast + soft double-ping (heads-up)
 *   🚨 CRIT   @ T-60s   → hot amber toast + triple urgency blip
 *
 * Each tier fires once per signal id (tracked per-tier); entries reset when
 * the signal resolves or leaves the open window, so redeploys re-arm.
 * Mounted once in the app shell — renders nothing.
 */ const OPEN_STATUSES = new Set([
    "ACTIVE",
    "TP1",
    "TP2"
]);
/** tier thresholds (ms before expiry) */ const WARN_MS = 5 * 60_000;
const CRIT_MS = 60_000;
/** shared glass toast shell — tier supplies color + copy */ function TtlToast({ tier, symbol, secs, onDismiss }) {
    const c = tier === "crit" ? "#ffb347" : "#e8c468";
    const crit = tier === "crit";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        "aria-label": `TTL ${tier === "crit" ? "critical" : "warning"}: ${symbol} expires in ${secs >= 90 ? `${Math.round(secs / 60)} minutes` : `${secs} seconds`}`,
        onClick: onDismiss,
        className: "pointer-events-auto flex w-[min(92vw,380px)] cursor-pointer items-start gap-3 rounded-xl border px-3.5 py-3 text-left backdrop-blur-xl shadow-[0_8px_32px_-8px_rgba(0,0,0,0.85)] transition-transform hover:scale-[1.015]",
        style: {
            borderColor: crit ? "rgba(255,179,71,0.6)" : "rgba(232,196,104,0.42)",
            background: crit ? "linear-gradient(135deg, rgba(255,179,71,0.12), rgba(7,11,14,0.96) 55%)" : "linear-gradient(135deg, rgba(232,196,104,0.07), rgba(7,11,14,0.96) 55%)"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border ${crit ? "anim-pulse-dot" : ""}`,
                style: {
                    borderColor: crit ? "rgba(255,179,71,0.6)" : "rgba(232,196,104,0.4)",
                    color: c,
                    background: crit ? "rgba(255,179,71,0.10)" : "rgba(232,196,104,0.06)"
                },
                children: crit ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$alarm$2d$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlarmClock$3e$__["AlarmClock"], {
                    size: 14
                }, void 0, false, {
                    fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                    lineNumber: 60,
                    columnNumber: 17
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hourglass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Hourglass$3e$__["Hourglass"], {
                    size: 13
                }, void 0, false, {
                    fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                    lineNumber: 60,
                    columnNumber: 44
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "min-w-0 flex-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-terminal text-[10px] font-bold uppercase tracking-[0.2em]",
                                style: {
                                    color: c
                                },
                                children: crit ? "TTL CRITICAL — FINAL 60S" : "TTL WARNING — 5M TO EXPIRY"
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                                lineNumber: 64,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "rounded border border-white/10 bg-white/[0.04] px-1.5 py-px font-terminal text-[9px] font-bold tracking-[0.14em] text-ink",
                                children: symbol
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                                lineNumber: 70,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "mt-1 block text-[11px] leading-snug text-ink-2",
                        children: crit ? `Expires in ${secs}s — plan your exit now.` : `${Math.round(secs / 60)}m until expiry — tighten stops or take profit early.`
                    }, void 0, false, {
                        fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full",
                style: {
                    background: c
                }
            }, void 0, false, {
                fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/fx/TtlSentinel.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_c = TtlToast;
function TtlSentinel() {
    _s();
    const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"])(3000);
    /** per-tier fired map: signalId → expiresAt the tier fired for. An expiry-gate
   *  TTL extension moves expiresAt forward — the map re-arms automatically (v6.1). */ const firedWarnRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const firedCritRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    /** clock guard: TTL math is meaningless before the first client tick */ const bootedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TtlSentinel.useEffect": ()=>{
            if (!data?.signals?.length) return;
            const now = Date.now();
            if (!bootedRef.current) {
                // first load — arm sentinels for anything already inside a threshold
                // WITHOUT firing (no toast storm on mount/refresh)
                for (const s of data.signals){
                    if (!OPEN_STATUSES.has(s.status) || s.closedAt) continue;
                    const remaining = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ttlRemainingMs"])(s.expiresAt, now);
                    if (remaining <= CRIT_MS) firedCritRef.current.set(s.id, s.expiresAt);
                    if (remaining <= WARN_MS) firedWarnRef.current.set(s.id, s.expiresAt);
                }
                bootedRef.current = true;
                return;
            }
            const open = data.signals.filter({
                "TtlSentinel.useEffect.open": (s)=>OPEN_STATUSES.has(s.status) && !s.closedAt
            }["TtlSentinel.useEffect.open"]);
            const openIds = new Set(open.map({
                "TtlSentinel.useEffect": (s)=>s.id
            }["TtlSentinel.useEffect"]));
            // prune resolved ids so a redeployed symbol re-arms cleanly
            for (const id of firedWarnRef.current.keys())if (!openIds.has(id.split("|")[0])) firedWarnRef.current.delete(id);
            for (const id of firedCritRef.current.keys())if (!openIds.has(id.split("|")[0])) firedCritRef.current.delete(id);
            const state = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"].getState();
            const soundAllowed = state.soundEnabled && !state.alertsMuted;
            const toastAllowed = !state.alertsMuted;
            const warnEnabled = state.ttlWarnEnabled;
            for (const s of open){
                const remaining = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ttlRemainingMs"])(s.expiresAt, now);
                if (remaining <= 0 || remaining > WARN_MS) continue;
                /* ── CRIT tier: final 60s ───────────────────────────── */ const critKey = `${s.id}|${s.expiresAt}`;
                if (remaining <= CRIT_MS && firedCritRef.current.get(critKey) !== s.expiresAt) {
                    firedCritRef.current.set(critKey, s.expiresAt);
                    if (soundAllowed) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["playTtlUrgency"])();
                    if (!toastAllowed) continue;
                    const secs = Math.max(1, Math.round(remaining / 1000));
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].custom({
                        "TtlSentinel.useEffect": ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TtlToast, {
                                tier: "crit",
                                symbol: s.symbol,
                                secs: secs,
                                onDismiss: {
                                    "TtlSentinel.useEffect": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].dismiss()
                                }["TtlSentinel.useEffect"]
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                                lineNumber: 133,
                                columnNumber: 17
                            }, this)
                    }["TtlSentinel.useEffect"], {
                        duration: 5200
                    });
                    continue;
                }
                /* ── WARN tier: T-5min heads-up ─────────────────────── */ if (remaining > CRIT_MS && firedWarnRef.current.get(critKey) !== s.expiresAt) {
                    firedWarnRef.current.set(critKey, s.expiresAt);
                    if (!warnEnabled) continue;
                    if (soundAllowed) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sounds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["playTtlWarning"])();
                    if (!toastAllowed) continue;
                    const secs = Math.max(61, Math.round(remaining / 1000));
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].custom({
                        "TtlSentinel.useEffect": ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TtlToast, {
                                tier: "warn",
                                symbol: s.symbol,
                                secs: secs,
                                onDismiss: {
                                    "TtlSentinel.useEffect": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].dismiss()
                                }["TtlSentinel.useEffect"]
                            }, void 0, false, {
                                fileName: "[project]/src/components/fx/TtlSentinel.tsx",
                                lineNumber: 147,
                                columnNumber: 17
                            }, this)
                    }["TtlSentinel.useEffect"], {
                        duration: 4600
                    });
                }
            }
        }
    }["TtlSentinel.useEffect"], [
        data
    ]);
    return null;
}
_s(TtlSentinel, "yQKl8ZiQL8XIMxyGV5JiPAozno0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePulse$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePulse"]
    ];
});
_c1 = TtlSentinel;
var _c, _c1;
__turbopack_context__.k.register(_c, "TtlToast");
__turbopack_context__.k.register(_c1, "TtlSentinel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/fx/KeyboardShortcuts.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KeyboardShortcuts",
    ()=>KeyboardShortcuts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__KeyboardIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/keyboard.js [app-client] (ecmascript) <export default as KeyboardIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/ui.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/accent.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/alerts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
/**
 * KeyboardShortcuts — operator legend overlay. Open via `?`, the header
 * keyboard button, or the ⌘K palette. Lists every global hotkey.
 */ function Row({ keys, label, hint }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2.5 rounded-lg px-2 py-1.5 transition-colors hover:bg-white/[0.03]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex w-14 shrink-0 items-center gap-1",
                children: keys.map((k)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("kbd", {
                        className: "kbd",
                        children: k
                    }, k, false, {
                        fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                        lineNumber: 20,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "min-w-0 flex-1 font-terminal text-[10.5px] font-semibold uppercase leading-snug tracking-[0.1em] text-ink",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            hint && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "hidden shrink-0 text-[10px] text-ink-3 md:block",
                children: hint
            }, void 0, false, {
                fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                lineNumber: 28,
                columnNumber: 16
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_c = Row;
function Group({ title, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "min-w-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "label-tech mb-1.5 border-b border-white/8 pb-1.5 text-neon/70",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-0.5",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
_c1 = Group;
function KeyboardShortcuts() {
    _s();
    const { shortcutsOpen, setShortcutsOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUi"])();
    const accent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"])({
        "KeyboardShortcuts.useAlerts[accent]": (s)=>s.accent
    }["KeyboardShortcuts.useAlerts[accent]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: shortcutsOpen,
        onOpenChange: setShortcutsOpen,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "max-w-[min(94vw,640px)] gap-0 overflow-hidden border-[rgb(var(--neon-rgb)/0.22)] bg-[linear-gradient(150deg,rgba(14,21,27,0.98),rgba(6,10,13,0.97))] p-0 shadow-[0_0_60px_-12px_rgb(var(--neon-rgb)/0.3)]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 border-b border-white/8 px-5 py-3.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__KeyboardIcon$3e$__["KeyboardIcon"], {
                            size: 14,
                            className: "text-neon",
                            "aria-hidden": true
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 52,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-terminal text-xs font-bold uppercase tracking-[0.22em] text-foreground",
                            children: "OPERATOR KEYMAP"
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 53,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "ml-auto hidden font-terminal text-[9px] tracking-[0.18em] text-ink-3 sm:block",
                            children: [
                                "PRESS ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("kbd", {
                                    className: "kbd",
                                    children: "ESC"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 57,
                                    columnNumber: 19
                                }, this),
                                " TO CLOSE"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                    className: "sr-only",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                            children: "Keyboard shortcuts"
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                            children: "All available keyboard shortcuts"
                        }, void 0, false, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 63,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                    lineNumber: 61,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid max-h-[62vh] grid-cols-1 gap-x-6 gap-y-4 overflow-y-auto p-5 sm:grid-cols-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Group, {
                            title: "NAVIGATION",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "1"
                                    ],
                                    label: "Command Deck",
                                    hint: "dashboard"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "2"
                                    ],
                                    label: "Signal Matrix",
                                    hint: "signals"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 69,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "3"
                                    ],
                                    label: "Performance Intel",
                                    hint: "analytics"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "4"
                                    ],
                                    label: "Engine Terminal",
                                    hint: "feed"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 71,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "5"
                                    ],
                                    label: "AI Core",
                                    hint: "llm analyst"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 72,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "⌘",
                                        "K"
                                    ],
                                    label: "Command palette",
                                    hint: "any view"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 73,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Group, {
                            title: "ACTIONS",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "/"
                                    ],
                                    label: "Focus symbol search",
                                    hint: "signal matrix"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "C"
                                    ],
                                    label: "Risk calculator",
                                    hint: "position sizing"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 78,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "M"
                                    ],
                                    label: "Mute / unmute alerts"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "S"
                                    ],
                                    label: "Event sounds on / off"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 80,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "A"
                                    ],
                                    label: "Cycle accent identity",
                                    hint: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ACCENT_ORDER"].length} identities`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 81,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Group, {
                            title: "SYSTEM",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "?"
                                    ],
                                    label: "This keymap"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 85,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                    keys: [
                                        "ESC"
                                    ],
                                    label: "Close overlays"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 86,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 84,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Group, {
                            title: "CURRENT IDENTITY",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-wrap items-center gap-1.5 px-2 py-1.5",
                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$accent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ACCENT_ORDER"].map((id)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            "aria-current": id === accent,
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-md border px-2 py-0.5 font-terminal text-[9px] font-bold tracking-[0.16em]", id === accent ? "border-[rgb(var(--neon-rgb)/0.5)] bg-[rgb(var(--neon-rgb)/0.1)] text-neon" : "border-white/8 text-ink-3"),
                                            children: id.toUpperCase()
                                        }, id, false, {
                                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                            lineNumber: 92,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 90,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "px-2 pt-1 text-[11px] leading-relaxed text-ink-3",
                                    children: [
                                        "Tap ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("kbd", {
                                            className: "kbd",
                                            children: "A"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                            lineNumber: 107,
                                            columnNumber: 19
                                        }, this),
                                        " to cycle the terminal identity — borders, glows, charts and the logo re-tune instantly. Preference is persisted per browser."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                                    lineNumber: 106,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                            lineNumber: 89,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
            lineNumber: 48,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/fx/KeyboardShortcuts.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, this);
}
_s(KeyboardShortcuts, "9T7AKHsMepa5DZJ0UWZuZa9yoG0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$ui$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUi"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$alerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAlerts"]
    ];
});
_c2 = KeyboardShortcuts;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Row");
__turbopack_context__.k.register(_c1, "Group");
__turbopack_context__.k.register(_c2, "KeyboardShortcuts");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_fx_f28cb0f1._.js.map